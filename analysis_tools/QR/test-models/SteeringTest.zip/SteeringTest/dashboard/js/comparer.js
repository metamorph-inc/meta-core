$(function(){
	ko.applyBindings(vm, $('#tabpage')[0]);
})