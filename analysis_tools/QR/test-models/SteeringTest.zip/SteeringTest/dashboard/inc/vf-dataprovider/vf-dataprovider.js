// This code will dynamically build the vf_dataprovider class based on the
// information contained in the vf-dataprovider-components.json file

// Dependancies:
	// jquery
	// knockoutjs
	
