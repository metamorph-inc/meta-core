# ./_cad.py
# -*- coding: utf-8 -*-
# PyXB bindings for NM:462c18d5b89050fb1b7f8fca1e535af868009675
# Generated 2013-05-03 08:47:09.516311 by PyXB version 1.2.2
# Namespace cad [xmlns:cad]

import pyxb
import pyxb.binding
import pyxb.binding.saxer
import StringIO
import pyxb.utils.utility
import pyxb.utils.domutils
import sys

# Unique identifier for bindings created at the same time
_GenerationUID = pyxb.utils.utility.UniqueIdentifier('urn:uuid:f33d236b-b3f7-11e2-82f9-20c9d02b76f3')

# Version of PyXB used to generate the bindings
_PyXBVersion = '1.2.2'
# Generated bindings are not compatible across PyXB versions
if pyxb.__version__ != _PyXBVersion:
    raise pyxb.PyXBVersionError(_PyXBVersion)

# Import bindings for namespaces imported into schema
import _avm as _ImportedBinding__avm
import pyxb.binding.datatypes

# NOTE: All namespace declarations are reserved within the binding
Namespace = pyxb.namespace.NamespaceForURI(u'cad', create_if_missing=True)
Namespace.configureCategories(['typeBinding', 'elementBinding'])

def CreateFromDocument (xml_text, default_namespace=None, location_base=None):
    """Parse the given XML and use the document element to create a
    Python instance.
    
    @kw default_namespace The L{pyxb.Namespace} instance to use as the
    default namespace where there is no default namespace in scope.
    If unspecified or C{None}, the namespace of the module containing
    this function will be used.

    @keyword location_base: An object to be recorded as the base of all
    L{pyxb.utils.utility.Location} instances associated with events and
    objects handled by the parser.  You might pass the URI from which
    the document was obtained.
    """

    if pyxb.XMLStyle_saxer != pyxb._XMLStyle:
        dom = pyxb.utils.domutils.StringToDOM(xml_text)
        return CreateFromDOM(dom.documentElement)
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    saxer = pyxb.binding.saxer.make_parser(fallback_namespace=default_namespace, location_base=location_base)
    handler = saxer.getContentHandler()
    saxer.parse(StringIO.StringIO(xml_text))
    instance = handler.rootObject()
    return instance

def CreateFromDOM (node, default_namespace=None):
    """Create a Python instance from the given DOM node.
    The node tag must correspond to an element declaration in this module.

    @deprecated: Forcing use of DOM interface is unnecessary; use L{CreateFromDocument}."""
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    return pyxb.binding.basis.element.AnyCreateFromDOM(node, default_namespace)


# Complex type {cad}CADModel with content type ELEMENT_ONLY
class CADModel_ (_ImportedBinding__avm.DomainModel_):
    """Complex type {cad}CADModel with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'CADModel')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 12, 2)
    _ElementMap = _ImportedBinding__avm.DomainModel_._ElementMap.copy()
    _AttributeMap = _ImportedBinding__avm.DomainModel_._AttributeMap.copy()
    # Base type is _ImportedBinding__avm.DomainModel_
    
    # Element Datum uses Python identifier Datum
    __Datum = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Datum'), 'Datum', '__cad_CADModel__Datum', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 16, 10), )

    
    Datum = property(__Datum.value, __Datum.set, None, None)

    
    # Element Parameter uses Python identifier Parameter
    __Parameter = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Parameter'), 'Parameter', '__cad_CADModel__Parameter', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 17, 10), )

    
    Parameter = property(__Parameter.value, __Parameter.set, None, None)

    
    # Element Metric uses Python identifier Metric
    __Metric = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Metric'), 'Metric', '__cad_CADModel__Metric', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 18, 10), )

    
    Metric = property(__Metric.value, __Metric.set, None, None)

    
    # Attribute UsesResource inherited from {avm}DomainModel
    
    # Attribute FilePathWithinResource inherited from {avm}DomainModel
    
    # Attribute Author inherited from {avm}DomainModel
    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__cad_CADModel__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 20, 8)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 20, 8)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        __Datum.name() : __Datum,
        __Parameter.name() : __Parameter,
        __Metric.name() : __Metric
    })
    _AttributeMap.update({
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'CADModel', CADModel_)


# Complex type {cad}Datum with content type EMPTY
class Datum_ (_ImportedBinding__avm.DomainModelPort_):
    """Complex type {cad}Datum with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Datum')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 24, 2)
    _ElementMap = _ImportedBinding__avm.DomainModelPort_._ElementMap.copy()
    _AttributeMap = _ImportedBinding__avm.DomainModelPort_._AttributeMap.copy()
    # Base type is _ImportedBinding__avm.DomainModelPort_
    
    # Attribute ID inherited from {avm}DomainModelPort
    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__cad_Datum__Name', pyxb.binding.datatypes.string, required=True)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 27, 8)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 27, 8)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__cad_Datum__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 28, 8)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 28, 8)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'Datum', Datum_)


# Complex type {cad}Parameter with content type ELEMENT_ONLY
class Parameter_ (_ImportedBinding__avm.DomainModelParameter_):
    """Complex type {cad}Parameter with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Parameter')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 32, 2)
    _ElementMap = _ImportedBinding__avm.DomainModelParameter_._ElementMap.copy()
    _AttributeMap = _ImportedBinding__avm.DomainModelParameter_._AttributeMap.copy()
    # Base type is _ImportedBinding__avm.DomainModelParameter_
    
    # Element Value uses Python identifier Value
    __Value = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Value'), 'Value', '__cad_Parameter__Value', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 36, 10), )

    
    Value = property(__Value.value, __Value.set, None, None)

    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__cad_Parameter__Name', pyxb.binding.datatypes.string, required=True)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 38, 8)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 38, 8)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__cad_Parameter__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 39, 8)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 39, 8)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        __Value.name() : __Value
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'Parameter', Parameter_)


# Complex type {cad}Metric with content type EMPTY
class Metric_ (_ImportedBinding__avm.DomainModelMetric_):
    """Complex type {cad}Metric with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Metric')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 63, 2)
    _ElementMap = _ImportedBinding__avm.DomainModelMetric_._ElementMap.copy()
    _AttributeMap = _ImportedBinding__avm.DomainModelMetric_._AttributeMap.copy()
    # Base type is _ImportedBinding__avm.DomainModelMetric_
    
    # Attribute ID inherited from {avm}DomainModelMetric
    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__cad_Metric__Name', pyxb.binding.datatypes.string, required=True)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 66, 8)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 66, 8)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__cad_Metric__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 67, 8)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 67, 8)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'Metric', Metric_)


# Complex type {cad}Point with content type EMPTY
class Point_ (Datum_):
    """Complex type {cad}Point with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Point')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 43, 2)
    _ElementMap = Datum_._ElementMap.copy()
    _AttributeMap = Datum_._AttributeMap.copy()
    # Base type is Datum_
    
    # Attribute ID inherited from {avm}DomainModelPort
    
    # Attribute Name inherited from {cad}Datum
    
    # Attribute Notes inherited from {cad}Datum
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'Point', Point_)


# Complex type {cad}Axis with content type EMPTY
class Axis_ (Datum_):
    """Complex type {cad}Axis with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Axis')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 48, 2)
    _ElementMap = Datum_._ElementMap.copy()
    _AttributeMap = Datum_._AttributeMap.copy()
    # Base type is Datum_
    
    # Attribute ID inherited from {avm}DomainModelPort
    
    # Attribute Name inherited from {cad}Datum
    
    # Attribute Notes inherited from {cad}Datum
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'Axis', Axis_)


# Complex type {cad}Plane with content type EMPTY
class Plane_ (Datum_):
    """Complex type {cad}Plane with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Plane')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 53, 2)
    _ElementMap = Datum_._ElementMap.copy()
    _AttributeMap = Datum_._AttributeMap.copy()
    # Base type is Datum_
    
    # Attribute ID inherited from {avm}DomainModelPort
    
    # Attribute Name inherited from {cad}Datum
    
    # Attribute Notes inherited from {cad}Datum
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'Plane', Plane_)


# Complex type {cad}CoordinateSystem with content type EMPTY
class CoordinateSystem_ (Datum_):
    """Complex type {cad}CoordinateSystem with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'CoordinateSystem')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 58, 2)
    _ElementMap = Datum_._ElementMap.copy()
    _AttributeMap = Datum_._AttributeMap.copy()
    # Base type is Datum_
    
    # Attribute ID inherited from {avm}DomainModelPort
    
    # Attribute Name inherited from {cad}Datum
    
    # Attribute Notes inherited from {cad}Datum
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'CoordinateSystem', CoordinateSystem_)


CADModel = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'CADModel'), CADModel_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 4, 2))
Namespace.addCategoryObject('elementBinding', CADModel.name().localName(), CADModel)

Datum = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Datum'), Datum_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 5, 2))
Namespace.addCategoryObject('elementBinding', Datum.name().localName(), Datum)

Parameter = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Parameter'), Parameter_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 6, 2))
Namespace.addCategoryObject('elementBinding', Parameter.name().localName(), Parameter)

Metric = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Metric'), Metric_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 11, 2))
Namespace.addCategoryObject('elementBinding', Metric.name().localName(), Metric)

Point = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Point'), Point_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 7, 2))
Namespace.addCategoryObject('elementBinding', Point.name().localName(), Point)

Axis = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Axis'), Axis_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 8, 2))
Namespace.addCategoryObject('elementBinding', Axis.name().localName(), Axis)

Plane = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Plane'), Plane_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 9, 2))
Namespace.addCategoryObject('elementBinding', Plane.name().localName(), Plane)

CoordinateSystem = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'CoordinateSystem'), CoordinateSystem_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 10, 2))
Namespace.addCategoryObject('elementBinding', CoordinateSystem.name().localName(), CoordinateSystem)



CADModel_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Datum'), Datum_, scope=CADModel_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 16, 10)))

CADModel_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Parameter'), Parameter_, scope=CADModel_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 17, 10)))

CADModel_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Metric'), Metric_, scope=CADModel_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 18, 10)))

def _BuildAutomaton ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton
    del _BuildAutomaton
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 16, 10))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 17, 10))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 18, 10))
    counters.add(cc_2)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(CADModel_._UseForTag(pyxb.namespace.ExpandedName(None, u'Datum')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 16, 10))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(CADModel_._UseForTag(pyxb.namespace.ExpandedName(None, u'Parameter')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 17, 10))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_2, False))
    symbol = pyxb.binding.content.ElementUse(CADModel_._UseForTag(pyxb.namespace.ExpandedName(None, u'Metric')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 18, 10))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    st_2._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
CADModel_._Automaton = _BuildAutomaton()




Parameter_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Value'), _ImportedBinding__avm.Value_, scope=Parameter_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 36, 10)))

def _BuildAutomaton_ ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_
    del _BuildAutomaton_
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=1, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 36, 10))
    counters.add(cc_0)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(Parameter_._UseForTag(pyxb.namespace.ExpandedName(None, u'Value')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.cad.xsd', 36, 10))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
Parameter_._Automaton = _BuildAutomaton_()

