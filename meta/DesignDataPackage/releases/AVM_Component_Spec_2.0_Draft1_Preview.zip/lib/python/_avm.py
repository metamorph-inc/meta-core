# ./_avm.py
# -*- coding: utf-8 -*-
# PyXB bindings for NM:8c3bce54577a879cd94d42789711c9f5d444aa71
# Generated 2013-05-03 08:47:09.515138 by PyXB version 1.2.2
# Namespace avm [xmlns:avm]

import pyxb
import pyxb.binding
import pyxb.binding.saxer
import StringIO
import pyxb.utils.utility
import pyxb.utils.domutils
import sys

# Unique identifier for bindings created at the same time
_GenerationUID = pyxb.utils.utility.UniqueIdentifier('urn:uuid:f33d236b-b3f7-11e2-82f9-20c9d02b76f3')

# Version of PyXB used to generate the bindings
_PyXBVersion = '1.2.2'
# Generated bindings are not compatible across PyXB versions
if pyxb.__version__ != _PyXBVersion:
    raise pyxb.PyXBVersionError(_PyXBVersion)

# Import bindings for namespaces imported into schema
import pyxb.binding.datatypes

# NOTE: All namespace declarations are reserved within the binding
Namespace = pyxb.namespace.NamespaceForURI(u'avm', create_if_missing=True)
Namespace.configureCategories(['typeBinding', 'elementBinding'])

def CreateFromDocument (xml_text, default_namespace=None, location_base=None):
    """Parse the given XML and use the document element to create a
    Python instance.
    
    @kw default_namespace The L{pyxb.Namespace} instance to use as the
    default namespace where there is no default namespace in scope.
    If unspecified or C{None}, the namespace of the module containing
    this function will be used.

    @keyword location_base: An object to be recorded as the base of all
    L{pyxb.utils.utility.Location} instances associated with events and
    objects handled by the parser.  You might pass the URI from which
    the document was obtained.
    """

    if pyxb.XMLStyle_saxer != pyxb._XMLStyle:
        dom = pyxb.utils.domutils.StringToDOM(xml_text)
        return CreateFromDOM(dom.documentElement)
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    saxer = pyxb.binding.saxer.make_parser(fallback_namespace=default_namespace, location_base=location_base)
    handler = saxer.getContentHandler()
    saxer.parse(StringIO.StringIO(xml_text))
    instance = handler.rootObject()
    return instance

def CreateFromDOM (node, default_namespace=None):
    """Create a Python instance from the given DOM node.
    The node tag must correspond to an element declaration in this module.

    @deprecated: Forcing use of DOM interface is unnecessary; use L{CreateFromDocument}."""
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    return pyxb.binding.basis.element.AnyCreateFromDOM(node, default_namespace)


# Atomic simple type: {avm}CalculationTypeEnum
class CalculationTypeEnum (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """An atomic simple type."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'CalculationTypeEnum')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 140, 2)
    _Documentation = None
CalculationTypeEnum._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=CalculationTypeEnum, enum_prefix=None)
CalculationTypeEnum.Declarative = CalculationTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Declarative', tag=u'Declarative')
CalculationTypeEnum.Python = CalculationTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Python', tag=u'Python')
CalculationTypeEnum._InitializeFacetMap(CalculationTypeEnum._CF_enumeration)
Namespace.addCategoryObject('typeBinding', u'CalculationTypeEnum', CalculationTypeEnum)

# Atomic simple type: {avm}DataTypeEnum
class DataTypeEnum (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """An atomic simple type."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DataTypeEnum')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 146, 2)
    _Documentation = None
DataTypeEnum._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=DataTypeEnum, enum_prefix=None)
DataTypeEnum.Boolean = DataTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Boolean', tag=u'Boolean')
DataTypeEnum.Integer = DataTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Integer', tag=u'Integer')
DataTypeEnum.Real = DataTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Real', tag=u'Real')
DataTypeEnum.String = DataTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'String', tag=u'String')
DataTypeEnum._InitializeFacetMap(DataTypeEnum._CF_enumeration)
Namespace.addCategoryObject('typeBinding', u'DataTypeEnum', DataTypeEnum)

# Atomic simple type: {avm}DimensionTypeEnum
class DimensionTypeEnum (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """An atomic simple type."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DimensionTypeEnum')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 154, 2)
    _Documentation = None
DimensionTypeEnum._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=DimensionTypeEnum, enum_prefix=None)
DimensionTypeEnum.Matrix = DimensionTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Matrix', tag=u'Matrix')
DimensionTypeEnum.Vector = DimensionTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Vector', tag=u'Vector')
DimensionTypeEnum.Scalar = DimensionTypeEnum._CF_enumeration.addEnumeration(unicode_value=u'Scalar', tag=u'Scalar')
DimensionTypeEnum._InitializeFacetMap(DimensionTypeEnum._CF_enumeration)
Namespace.addCategoryObject('typeBinding', u'DimensionTypeEnum', DimensionTypeEnum)

# Atomic simple type: {avm}ITARRestrictionLevelEnum
class ITARRestrictionLevelEnum (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """An atomic simple type."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'ITARRestrictionLevelEnum')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 185, 2)
    _Documentation = None
ITARRestrictionLevelEnum._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=ITARRestrictionLevelEnum, enum_prefix=None)
ITARRestrictionLevelEnum.ITAR = ITARRestrictionLevelEnum._CF_enumeration.addEnumeration(unicode_value=u'ITAR', tag=u'ITAR')
ITARRestrictionLevelEnum.ITARDistributionD = ITARRestrictionLevelEnum._CF_enumeration.addEnumeration(unicode_value=u'ITARDistributionD', tag=u'ITARDistributionD')
ITARRestrictionLevelEnum.NotITAR = ITARRestrictionLevelEnum._CF_enumeration.addEnumeration(unicode_value=u'NotITAR', tag=u'NotITAR')
ITARRestrictionLevelEnum._InitializeFacetMap(ITARRestrictionLevelEnum._CF_enumeration)
Namespace.addCategoryObject('typeBinding', u'ITARRestrictionLevelEnum', ITARRestrictionLevelEnum)

# Complex type {avm}Component with content type ELEMENT_ONLY
class Component_ (pyxb.binding.basis.complexTypeDefinition):
    """Test documentation for Component type. Yep."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Component')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 25, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element DomainModel uses Python identifier DomainModel
    __DomainModel = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'DomainModel'), 'DomainModel', '__avm_Component__DomainModel', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 30, 6), )

    
    DomainModel = property(__DomainModel.value, __DomainModel.set, None, None)

    
    # Element NamedValue uses Python identifier NamedValue
    __NamedValue = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'NamedValue'), 'NamedValue', '__avm_Component__NamedValue', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 31, 6), )

    
    NamedValue = property(__NamedValue.value, __NamedValue.set, None, None)

    
    # Element ResourceDependency uses Python identifier ResourceDependency
    __ResourceDependency = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'ResourceDependency'), 'ResourceDependency', '__avm_Component__ResourceDependency', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 32, 6), )

    
    ResourceDependency = property(__ResourceDependency.value, __ResourceDependency.set, None, None)

    
    # Element Interface uses Python identifier Interface
    __Interface = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Interface'), 'Interface', '__avm_Component__Interface', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 33, 6), )

    
    Interface = property(__Interface.value, __Interface.set, None, None)

    
    # Element DistributionRestriction uses Python identifier DistributionRestriction
    __DistributionRestriction = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'DistributionRestriction'), 'DistributionRestriction', '__avm_Component__DistributionRestriction', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 34, 6), )

    
    DistributionRestriction = property(__DistributionRestriction.value, __DistributionRestriction.set, None, None)

    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__avm_Component__Name', pyxb.binding.datatypes.string)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 36, 4)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 36, 4)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute Version uses Python identifier Version
    __Version = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Version'), 'Version', '__avm_Component__Version', pyxb.binding.datatypes.string)
    __Version._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 37, 4)
    __Version._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 37, 4)
    
    Version = property(__Version.value, __Version.set, None, None)

    
    # Attribute SchemaVersion uses Python identifier SchemaVersion
    __SchemaVersion = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'SchemaVersion'), 'SchemaVersion', '__avm_Component__SchemaVersion', pyxb.binding.datatypes.string)
    __SchemaVersion._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 38, 4)
    __SchemaVersion._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 38, 4)
    
    SchemaVersion = property(__SchemaVersion.value, __SchemaVersion.set, None, None)

    _ElementMap.update({
        __DomainModel.name() : __DomainModel,
        __NamedValue.name() : __NamedValue,
        __ResourceDependency.name() : __ResourceDependency,
        __Interface.name() : __Interface,
        __DistributionRestriction.name() : __DistributionRestriction
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __Version.name() : __Version,
        __SchemaVersion.name() : __SchemaVersion
    })
Namespace.addCategoryObject('typeBinding', u'Component', Component_)


# Complex type {avm}DomainModel with content type EMPTY
class DomainModel_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}DomainModel with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DomainModel')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 40, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute UsesResource uses Python identifier UsesResource
    __UsesResource = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'UsesResource'), 'UsesResource', '__avm_DomainModel__UsesResource', pyxb.binding.datatypes.IDREFS)
    __UsesResource._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 41, 4)
    __UsesResource._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 41, 4)
    
    UsesResource = property(__UsesResource.value, __UsesResource.set, None, None)

    
    # Attribute FilePathWithinResource uses Python identifier FilePathWithinResource
    __FilePathWithinResource = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'FilePathWithinResource'), 'FilePathWithinResource', '__avm_DomainModel__FilePathWithinResource', pyxb.binding.datatypes.string)
    __FilePathWithinResource._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 42, 4)
    __FilePathWithinResource._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 42, 4)
    
    FilePathWithinResource = property(__FilePathWithinResource.value, __FilePathWithinResource.set, None, None)

    
    # Attribute Author uses Python identifier Author
    __Author = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Author'), 'Author', '__avm_DomainModel__Author', pyxb.binding.datatypes.string)
    __Author._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 43, 4)
    __Author._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 43, 4)
    
    Author = property(__Author.value, __Author.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __UsesResource.name() : __UsesResource,
        __FilePathWithinResource.name() : __FilePathWithinResource,
        __Author.name() : __Author
    })
Namespace.addCategoryObject('typeBinding', u'DomainModel', DomainModel_)


# Complex type {avm}NamedValue with content type ELEMENT_ONLY
class NamedValue_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}NamedValue with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'NamedValue')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 45, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element Value uses Python identifier Value
    __Value = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Value'), 'Value', '__avm_NamedValue__Value', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 47, 6), )

    
    Value = property(__Value.value, __Value.set, None, None)

    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__avm_NamedValue__Name', pyxb.binding.datatypes.string)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 49, 4)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 49, 4)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute OnDataSheet uses Python identifier OnDataSheet
    __OnDataSheet = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'OnDataSheet'), 'OnDataSheet', '__avm_NamedValue__OnDataSheet', pyxb.binding.datatypes.boolean)
    __OnDataSheet._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 50, 4)
    __OnDataSheet._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 50, 4)
    
    OnDataSheet = property(__OnDataSheet.value, __OnDataSheet.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__avm_NamedValue__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 51, 4)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 51, 4)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        __Value.name() : __Value
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __OnDataSheet.name() : __OnDataSheet,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'NamedValue', NamedValue_)


# Complex type {avm}Resource with content type EMPTY
class Resource_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}Resource with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Resource')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 89, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__avm_Resource__Name', pyxb.binding.datatypes.string)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 90, 4)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 90, 4)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute Path uses Python identifier Path
    __Path = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Path'), 'Path', '__avm_Resource__Path', pyxb.binding.datatypes.anyURI)
    __Path._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 91, 4)
    __Path._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 91, 4)
    
    Path = property(__Path.value, __Path.set, None, None)

    
    # Attribute Hash uses Python identifier Hash
    __Hash = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Hash'), 'Hash', '__avm_Resource__Hash', pyxb.binding.datatypes.string)
    __Hash._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 92, 4)
    __Hash._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 92, 4)
    
    Hash = property(__Hash.value, __Hash.set, None, None)

    
    # Attribute ID uses Python identifier ID
    __ID = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'ID'), 'ID', '__avm_Resource__ID', pyxb.binding.datatypes.ID)
    __ID._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 93, 4)
    __ID._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 93, 4)
    
    ID = property(__ID.value, __ID.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__avm_Resource__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 94, 4)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 94, 4)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __Path.name() : __Path,
        __Hash.name() : __Hash,
        __ID.name() : __ID,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'Resource', Resource_)


# Complex type {avm}Interface with content type ELEMENT_ONLY
class Interface_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}Interface with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Interface')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 96, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element Role uses Python identifier Role
    __Role = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Role'), 'Role', '__avm_Interface__Role', True, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 98, 6), )

    
    Role = property(__Role.value, __Role.set, None, None)

    
    # Attribute Definition uses Python identifier Definition
    __Definition = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Definition'), 'Definition', '__avm_Interface__Definition', pyxb.binding.datatypes.anyURI)
    __Definition._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 100, 4)
    __Definition._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 100, 4)
    
    Definition = property(__Definition.value, __Definition.set, None, None)

    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__avm_Interface__Name', pyxb.binding.datatypes.string)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 101, 4)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 101, 4)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__avm_Interface__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 102, 4)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 102, 4)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        __Role.name() : __Role
    })
    _AttributeMap.update({
        __Definition.name() : __Definition,
        __Name.name() : __Name,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'Interface', Interface_)


# Complex type {avm}Role with content type EMPTY
class Role_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}Role with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Role')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 104, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute Name uses Python identifier Name
    __Name = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Name'), 'Name', '__avm_Role__Name', pyxb.binding.datatypes.string)
    __Name._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 105, 4)
    __Name._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 105, 4)
    
    Name = property(__Name.value, __Name.set, None, None)

    
    # Attribute DomainPort uses Python identifier DomainPort
    __DomainPort = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'DomainPort'), 'DomainPort', '__avm_Role__DomainPort', pyxb.binding.datatypes.IDREF)
    __DomainPort._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 106, 4)
    __DomainPort._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 106, 4)
    
    DomainPort = property(__DomainPort.value, __DomainPort.set, None, None)

    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__avm_Role__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 107, 4)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 107, 4)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Name.name() : __Name,
        __DomainPort.name() : __DomainPort,
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'Role', Role_)


# Complex type {avm}DomainModelPort with content type EMPTY
class DomainModelPort_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}DomainModelPort with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DomainModelPort')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 109, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute ID uses Python identifier ID
    __ID = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'ID'), 'ID', '__avm_DomainModelPort__ID', pyxb.binding.datatypes.ID, required=True)
    __ID._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 110, 4)
    __ID._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 110, 4)
    
    ID = property(__ID.value, __ID.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __ID.name() : __ID
    })
Namespace.addCategoryObject('typeBinding', u'DomainModelPort', DomainModelPort_)


# Complex type {avm}DomainModelParameter with content type EMPTY
class DomainModelParameter_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}DomainModelParameter with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DomainModelParameter')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 112, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'DomainModelParameter', DomainModelParameter_)


# Complex type {avm}ValueExpressionType with content type EMPTY
class ValueExpressionType_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}ValueExpressionType with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'ValueExpressionType')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 124, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'ValueExpressionType', ValueExpressionType_)


# Complex type {avm}DistributionRestriction with content type EMPTY
class DistributionRestriction_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}DistributionRestriction with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DistributionRestriction')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 161, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute Notes uses Python identifier Notes
    __Notes = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Notes'), 'Notes', '__avm_DistributionRestriction__Notes', pyxb.binding.datatypes.string)
    __Notes._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 162, 4)
    __Notes._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 162, 4)
    
    Notes = property(__Notes.value, __Notes.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Notes.name() : __Notes
    })
Namespace.addCategoryObject('typeBinding', u'DistributionRestriction', DistributionRestriction_)


# Complex type {avm}DomainModelMetric with content type EMPTY
class DomainModelMetric_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}DomainModelMetric with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DomainModelMetric')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 192, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Attribute ID uses Python identifier ID
    __ID = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'ID'), 'ID', '__avm_DomainModelMetric__ID', pyxb.binding.datatypes.ID, required=True)
    __ID._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 193, 4)
    __ID._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 193, 4)
    
    ID = property(__ID.value, __ID.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __ID.name() : __ID
    })
Namespace.addCategoryObject('typeBinding', u'DomainModelMetric', DomainModelMetric_)


# Complex type {avm}Value with content type ELEMENT_ONLY
class Value_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {avm}Value with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Value')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 53, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element ValueExpression uses Python identifier ValueExpression
    __ValueExpression = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'ValueExpression'), 'ValueExpression', '__avm_Value__ValueExpression', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 55, 6), )

    
    ValueExpression = property(__ValueExpression.value, __ValueExpression.set, None, None)

    
    # Attribute Unit uses Python identifier Unit
    __Unit = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Unit'), 'Unit', '__avm_Value__Unit', pyxb.binding.datatypes.string)
    __Unit._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 57, 4)
    __Unit._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 57, 4)
    
    Unit = property(__Unit.value, __Unit.set, None, None)

    
    # Attribute ID uses Python identifier ID
    __ID = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'ID'), 'ID', '__avm_Value__ID', pyxb.binding.datatypes.ID, required=True)
    __ID._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 58, 4)
    __ID._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 58, 4)
    
    ID = property(__ID.value, __ID.set, None, None)

    
    # Attribute DataType uses Python identifier DataType
    __DataType = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'DataType'), 'DataType', '__avm_Value__DataType', DataTypeEnum)
    __DataType._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 59, 4)
    __DataType._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 59, 4)
    
    DataType = property(__DataType.value, __DataType.set, None, None)

    
    # Attribute DimensionType uses Python identifier DimensionType
    __DimensionType = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'DimensionType'), 'DimensionType', '__avm_Value__DimensionType', DimensionTypeEnum)
    __DimensionType._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 60, 4)
    __DimensionType._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 60, 4)
    
    DimensionType = property(__DimensionType.value, __DimensionType.set, None, None)

    
    # Attribute Dimensions uses Python identifier Dimensions
    __Dimensions = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Dimensions'), 'Dimensions', '__avm_Value__Dimensions', pyxb.binding.datatypes.string)
    __Dimensions._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 61, 4)
    __Dimensions._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 61, 4)
    
    Dimensions = property(__Dimensions.value, __Dimensions.set, None, None)

    _ElementMap.update({
        __ValueExpression.name() : __ValueExpression
    })
    _AttributeMap.update({
        __Unit.name() : __Unit,
        __ID.name() : __ID,
        __DataType.name() : __DataType,
        __DimensionType.name() : __DimensionType,
        __Dimensions.name() : __Dimensions
    })
Namespace.addCategoryObject('typeBinding', u'Value', Value_)


# Complex type {avm}FixedValue with content type ELEMENT_ONLY
class FixedValue_ (ValueExpressionType_):
    """Complex type {avm}FixedValue with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'FixedValue')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 63, 2)
    _ElementMap = ValueExpressionType_._ElementMap.copy()
    _AttributeMap = ValueExpressionType_._AttributeMap.copy()
    # Base type is ValueExpressionType_
    
    # Element Value uses Python identifier Value
    __Value = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Value'), 'Value', '__avm_FixedValue__Value', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 67, 10), )

    
    Value = property(__Value.value, __Value.set, None, None)

    _ElementMap.update({
        __Value.name() : __Value
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'FixedValue', FixedValue_)


# Complex type {avm}CalculatedValue with content type ELEMENT_ONLY
class CalculatedValue_ (ValueExpressionType_):
    """Complex type {avm}CalculatedValue with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'CalculatedValue')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 72, 2)
    _ElementMap = ValueExpressionType_._ElementMap.copy()
    _AttributeMap = ValueExpressionType_._AttributeMap.copy()
    # Base type is ValueExpressionType_
    
    # Element Expression uses Python identifier Expression
    __Expression = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Expression'), 'Expression', '__avm_CalculatedValue__Expression', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 76, 10), )

    
    Expression = property(__Expression.value, __Expression.set, None, None)

    
    # Attribute Type uses Python identifier Type
    __Type = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Type'), 'Type', '__avm_CalculatedValue__Type', CalculationTypeEnum, required=True)
    __Type._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 78, 8)
    __Type._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 78, 8)
    
    Type = property(__Type.value, __Type.set, None, None)

    _ElementMap.update({
        __Expression.name() : __Expression
    })
    _AttributeMap.update({
        __Type.name() : __Type
    })
Namespace.addCategoryObject('typeBinding', u'CalculatedValue', CalculatedValue_)


# Complex type {avm}DerivedValue with content type EMPTY
class DerivedValue_ (ValueExpressionType_):
    """Complex type {avm}DerivedValue with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'DerivedValue')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 82, 2)
    _ElementMap = ValueExpressionType_._ElementMap.copy()
    _AttributeMap = ValueExpressionType_._AttributeMap.copy()
    # Base type is ValueExpressionType_
    
    # Attribute ValueSource uses Python identifier ValueSource
    __ValueSource = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'ValueSource'), 'ValueSource', '__avm_DerivedValue__ValueSource', pyxb.binding.datatypes.IDREF, required=True)
    __ValueSource._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 85, 8)
    __ValueSource._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 85, 8)
    
    ValueSource = property(__ValueSource.value, __ValueSource.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __ValueSource.name() : __ValueSource
    })
Namespace.addCategoryObject('typeBinding', u'DerivedValue', DerivedValue_)


# Complex type {avm}ParametricValue with content type ELEMENT_ONLY
class ParametricValue_ (ValueExpressionType_):
    """Complex type {avm}ParametricValue with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'ParametricValue')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 113, 2)
    _ElementMap = ValueExpressionType_._ElementMap.copy()
    _AttributeMap = ValueExpressionType_._AttributeMap.copy()
    # Base type is ValueExpressionType_
    
    # Element Default uses Python identifier Default
    __Default = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Default'), 'Default', '__avm_ParametricValue__Default', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 117, 10), )

    
    Default = property(__Default.value, __Default.set, None, None)

    
    # Element Maximum uses Python identifier Maximum
    __Maximum = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Maximum'), 'Maximum', '__avm_ParametricValue__Maximum', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 118, 10), )

    
    Maximum = property(__Maximum.value, __Maximum.set, None, None)

    
    # Element Minimum uses Python identifier Minimum
    __Minimum = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Minimum'), 'Minimum', '__avm_ParametricValue__Minimum', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 119, 10), )

    
    Minimum = property(__Minimum.value, __Minimum.set, None, None)

    _ElementMap.update({
        __Default.name() : __Default,
        __Maximum.name() : __Maximum,
        __Minimum.name() : __Minimum
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'ParametricValue', ParametricValue_)


# Complex type {avm}ProbabilisticValue with content type EMPTY
class ProbabilisticValue_ (ValueExpressionType_):
    """Complex type {avm}ProbabilisticValue with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'ProbabilisticValue')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 125, 2)
    _ElementMap = ValueExpressionType_._ElementMap.copy()
    _AttributeMap = ValueExpressionType_._AttributeMap.copy()
    # Base type is ValueExpressionType_
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'ProbabilisticValue', ProbabilisticValue_)


# Complex type {avm}SecurityClassification with content type EMPTY
class SecurityClassification_ (DistributionRestriction_):
    """Complex type {avm}SecurityClassification with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'SecurityClassification')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 164, 2)
    _ElementMap = DistributionRestriction_._ElementMap.copy()
    _AttributeMap = DistributionRestriction_._AttributeMap.copy()
    # Base type is DistributionRestriction_
    
    # Attribute Notes inherited from {avm}DistributionRestriction
    
    # Attribute Level uses Python identifier Level
    __Level = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Level'), 'Level', '__avm_SecurityClassification__Level', pyxb.binding.datatypes.string)
    __Level._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 167, 8)
    __Level._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 167, 8)
    
    Level = property(__Level.value, __Level.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Level.name() : __Level
    })
Namespace.addCategoryObject('typeBinding', u'SecurityClassification', SecurityClassification_)


# Complex type {avm}Proprietary with content type EMPTY
class Proprietary_ (DistributionRestriction_):
    """Complex type {avm}Proprietary with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'Proprietary')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 171, 2)
    _ElementMap = DistributionRestriction_._ElementMap.copy()
    _AttributeMap = DistributionRestriction_._AttributeMap.copy()
    # Base type is DistributionRestriction_
    
    # Attribute Notes inherited from {avm}DistributionRestriction
    
    # Attribute Organization uses Python identifier Organization
    __Organization = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Organization'), 'Organization', '__avm_Proprietary__Organization', pyxb.binding.datatypes.string, required=True)
    __Organization._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 174, 8)
    __Organization._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 174, 8)
    
    Organization = property(__Organization.value, __Organization.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Organization.name() : __Organization
    })
Namespace.addCategoryObject('typeBinding', u'Proprietary', Proprietary_)


# Complex type {avm}ITAR with content type EMPTY
class ITAR_ (DistributionRestriction_):
    """Complex type {avm}ITAR with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'ITAR')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 178, 2)
    _ElementMap = DistributionRestriction_._ElementMap.copy()
    _AttributeMap = DistributionRestriction_._AttributeMap.copy()
    # Base type is DistributionRestriction_
    
    # Attribute Notes inherited from {avm}DistributionRestriction
    
    # Attribute Level uses Python identifier Level
    __Level = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, u'Level'), 'Level', '__avm_ITAR__Level', ITARRestrictionLevelEnum, required=True)
    __Level._DeclarationLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 181, 8)
    __Level._UseLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 181, 8)
    
    Level = property(__Level.value, __Level.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __Level.name() : __Level
    })
Namespace.addCategoryObject('typeBinding', u'ITAR', ITAR_)


# Complex type {avm}NormalDistribution with content type ELEMENT_ONLY
class NormalDistribution_ (ProbabilisticValue_):
    """Complex type {avm}NormalDistribution with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'NormalDistribution')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 130, 2)
    _ElementMap = ProbabilisticValue_._ElementMap.copy()
    _AttributeMap = ProbabilisticValue_._AttributeMap.copy()
    # Base type is ProbabilisticValue_
    
    # Element Mean uses Python identifier Mean
    __Mean = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'Mean'), 'Mean', '__avm_NormalDistribution__Mean', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 134, 10), )

    
    Mean = property(__Mean.value, __Mean.set, None, None)

    
    # Element StandardDeviation uses Python identifier StandardDeviation
    __StandardDeviation = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(None, u'StandardDeviation'), 'StandardDeviation', '__avm_NormalDistribution__StandardDeviation', False, pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 135, 10), )

    
    StandardDeviation = property(__StandardDeviation.value, __StandardDeviation.set, None, None)

    _ElementMap.update({
        __Mean.name() : __Mean,
        __StandardDeviation.name() : __StandardDeviation
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'NormalDistribution', NormalDistribution_)


# Complex type {avm}UniformDistribution with content type EMPTY
class UniformDistribution_ (ProbabilisticValue_):
    """Complex type {avm}UniformDistribution with content type EMPTY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_EMPTY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, u'UniformDistribution')
    _XSDLocation = pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 195, 2)
    _ElementMap = ProbabilisticValue_._ElementMap.copy()
    _AttributeMap = ProbabilisticValue_._AttributeMap.copy()
    # Base type is ProbabilisticValue_
    _ElementMap.update({
        
    })
    _AttributeMap.update({
        
    })
Namespace.addCategoryObject('typeBinding', u'UniformDistribution', UniformDistribution_)


Component = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Component'), Component_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 3, 2))
Namespace.addCategoryObject('elementBinding', Component.name().localName(), Component)

DomainModel = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'DomainModel'), DomainModel_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 4, 2))
Namespace.addCategoryObject('elementBinding', DomainModel.name().localName(), DomainModel)

NamedValue = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'NamedValue'), NamedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 5, 2))
Namespace.addCategoryObject('elementBinding', NamedValue.name().localName(), NamedValue)

Resource = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Resource'), Resource_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 10, 2))
Namespace.addCategoryObject('elementBinding', Resource.name().localName(), Resource)

Interface = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Interface'), Interface_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 11, 2))
Namespace.addCategoryObject('elementBinding', Interface.name().localName(), Interface)

Role = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Role'), Role_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 12, 2))
Namespace.addCategoryObject('elementBinding', Role.name().localName(), Role)

DomainModelPort = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'DomainModelPort'), DomainModelPort_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 13, 2))
Namespace.addCategoryObject('elementBinding', DomainModelPort.name().localName(), DomainModelPort)

DomainModelParameter = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'DomainModelParameter'), DomainModelParameter_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 14, 2))
Namespace.addCategoryObject('elementBinding', DomainModelParameter.name().localName(), DomainModelParameter)

ValueExpressionType = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'ValueExpressionType'), ValueExpressionType_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 16, 2))
Namespace.addCategoryObject('elementBinding', ValueExpressionType.name().localName(), ValueExpressionType)

DistributionRestriction = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'DistributionRestriction'), DistributionRestriction_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 19, 2))
Namespace.addCategoryObject('elementBinding', DistributionRestriction.name().localName(), DistributionRestriction)

DomainModelMetric = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'DomainModelMetric'), DomainModelMetric_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 23, 2))
Namespace.addCategoryObject('elementBinding', DomainModelMetric.name().localName(), DomainModelMetric)

Value = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Value'), Value_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 6, 2))
Namespace.addCategoryObject('elementBinding', Value.name().localName(), Value)

FixedValue = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'FixedValue'), FixedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 7, 2))
Namespace.addCategoryObject('elementBinding', FixedValue.name().localName(), FixedValue)

CalculatedValue = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'CalculatedValue'), CalculatedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 8, 2))
Namespace.addCategoryObject('elementBinding', CalculatedValue.name().localName(), CalculatedValue)

DerivedValue = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'DerivedValue'), DerivedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 9, 2))
Namespace.addCategoryObject('elementBinding', DerivedValue.name().localName(), DerivedValue)

ParametricValue = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'ParametricValue'), ParametricValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 15, 2))
Namespace.addCategoryObject('elementBinding', ParametricValue.name().localName(), ParametricValue)

ProbabilisticValue = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'ProbabilisticValue'), ProbabilisticValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 17, 2))
Namespace.addCategoryObject('elementBinding', ProbabilisticValue.name().localName(), ProbabilisticValue)

SecurityClassification = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'SecurityClassification'), SecurityClassification_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 20, 2))
Namespace.addCategoryObject('elementBinding', SecurityClassification.name().localName(), SecurityClassification)

Proprietary = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'Proprietary'), Proprietary_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 21, 2))
Namespace.addCategoryObject('elementBinding', Proprietary.name().localName(), Proprietary)

ITAR = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'ITAR'), ITAR_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 22, 2))
Namespace.addCategoryObject('elementBinding', ITAR.name().localName(), ITAR)

NormalDistribution = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'NormalDistribution'), NormalDistribution_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 18, 2))
Namespace.addCategoryObject('elementBinding', NormalDistribution.name().localName(), NormalDistribution)

UniformDistribution = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, u'UniformDistribution'), UniformDistribution_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 24, 2))
Namespace.addCategoryObject('elementBinding', UniformDistribution.name().localName(), UniformDistribution)



Component_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'DomainModel'), DomainModel_, scope=Component_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 30, 6)))

Component_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'NamedValue'), NamedValue_, scope=Component_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 31, 6)))

Component_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'ResourceDependency'), Resource_, scope=Component_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 32, 6)))

Component_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Interface'), Interface_, scope=Component_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 33, 6)))

Component_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'DistributionRestriction'), DistributionRestriction_, scope=Component_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 34, 6)))

def _BuildAutomaton ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton
    del _BuildAutomaton
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 30, 6))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 31, 6))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 32, 6))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 33, 6))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 34, 6))
    counters.add(cc_4)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(Component_._UseForTag(pyxb.namespace.ExpandedName(None, u'DomainModel')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 30, 6))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(Component_._UseForTag(pyxb.namespace.ExpandedName(None, u'NamedValue')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 31, 6))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_2, False))
    symbol = pyxb.binding.content.ElementUse(Component_._UseForTag(pyxb.namespace.ExpandedName(None, u'ResourceDependency')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 32, 6))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_3, False))
    symbol = pyxb.binding.content.ElementUse(Component_._UseForTag(pyxb.namespace.ExpandedName(None, u'Interface')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 33, 6))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_4, False))
    symbol = pyxb.binding.content.ElementUse(Component_._UseForTag(pyxb.namespace.ExpandedName(None, u'DistributionRestriction')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 34, 6))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    st_4._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
Component_._Automaton = _BuildAutomaton()




NamedValue_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Value'), Value_, scope=NamedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 47, 6)))

def _BuildAutomaton_ ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_
    del _BuildAutomaton_
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=1, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 47, 6))
    counters.add(cc_0)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(NamedValue_._UseForTag(pyxb.namespace.ExpandedName(None, u'Value')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 47, 6))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
NamedValue_._Automaton = _BuildAutomaton_()




Interface_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Role'), Role_, scope=Interface_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 98, 6)))

def _BuildAutomaton_2 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_2
    del _BuildAutomaton_2
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=None, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 98, 6))
    counters.add(cc_0)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(Interface_._UseForTag(pyxb.namespace.ExpandedName(None, u'Role')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 98, 6))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
Interface_._Automaton = _BuildAutomaton_2()




Value_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'ValueExpression'), ValueExpressionType_, scope=Value_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 55, 6)))

def _BuildAutomaton_3 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_3
    del _BuildAutomaton_3
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=1, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 55, 6))
    counters.add(cc_0)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(Value_._UseForTag(pyxb.namespace.ExpandedName(None, u'ValueExpression')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 55, 6))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
Value_._Automaton = _BuildAutomaton_3()




FixedValue_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Value'), pyxb.binding.datatypes.string, scope=FixedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 67, 10)))

def _BuildAutomaton_4 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_4
    del _BuildAutomaton_4
    import pyxb.utils.fac as fac

    counters = set()
    states = []
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(FixedValue_._UseForTag(pyxb.namespace.ExpandedName(None, u'Value')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 67, 10))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
FixedValue_._Automaton = _BuildAutomaton_4()




CalculatedValue_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Expression'), pyxb.binding.datatypes.string, scope=CalculatedValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 76, 10)))

def _BuildAutomaton_5 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_5
    del _BuildAutomaton_5
    import pyxb.utils.fac as fac

    counters = set()
    states = []
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(CalculatedValue_._UseForTag(pyxb.namespace.ExpandedName(None, u'Expression')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 76, 10))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
CalculatedValue_._Automaton = _BuildAutomaton_5()




ParametricValue_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Default'), ValueExpressionType_, scope=ParametricValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 117, 10)))

ParametricValue_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Maximum'), ValueExpressionType_, scope=ParametricValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 118, 10)))

ParametricValue_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Minimum'), ValueExpressionType_, scope=ParametricValue_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 119, 10)))

def _BuildAutomaton_6 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_6
    del _BuildAutomaton_6
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0L, max=1, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 118, 10))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0L, max=1, metadata=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 119, 10))
    counters.add(cc_1)
    states = []
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(ParametricValue_._UseForTag(pyxb.namespace.ExpandedName(None, u'Default')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 117, 10))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(ParametricValue_._UseForTag(pyxb.namespace.ExpandedName(None, u'Maximum')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 118, 10))
    st_1 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(ParametricValue_._UseForTag(pyxb.namespace.ExpandedName(None, u'Minimum')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 119, 10))
    st_2 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    transitions = []
    transitions.append(fac.Transition(st_1, [
         ]))
    transitions.append(fac.Transition(st_2, [
         ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, True) ]))
    st_2._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
ParametricValue_._Automaton = _BuildAutomaton_6()




NormalDistribution_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'Mean'), ValueExpressionType_, scope=NormalDistribution_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 134, 10)))

NormalDistribution_._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(None, u'StandardDeviation'), ValueExpressionType_, scope=NormalDistribution_, location=pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 135, 10)))

def _BuildAutomaton_7 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_7
    del _BuildAutomaton_7
    import pyxb.utils.fac as fac

    counters = set()
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(NormalDistribution_._UseForTag(pyxb.namespace.ExpandedName(None, u'Mean')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 134, 10))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(NormalDistribution_._UseForTag(pyxb.namespace.ExpandedName(None, u'StandardDeviation')), pyxb.utils.utility.Location(u'/Users/adam/Documents/svn/meta/sandbox/adam/DDP_2/EMF_Metamodel/model/avm.xsd', 135, 10))
    st_1 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    transitions = []
    transitions.append(fac.Transition(st_1, [
         ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    st_1._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
NormalDistribution_._Automaton = _BuildAutomaton_7()

