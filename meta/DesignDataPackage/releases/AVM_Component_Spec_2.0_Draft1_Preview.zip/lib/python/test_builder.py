import _avm as avm
import _modelica as modelica
import _cad as cad
import xml.dom.minidom

if __name__ == "__main__":
    c = avm.Component()
    c.Name = "Example Component"
    c.Version = "1.0"

    ### Build a NamedValue that represents a property of the component.
    ### With "OnDataSheet" set to true, it will not be hidden from the user
    ### while they are browsing components.
    ### The unit will be meters, and will be given as an integer.
    ### By using a FixedValue ValueExpression, we are saying that this
    ### is unchangeable.
    nv = avm.NamedValue()
    nv.Name = "NamedValue1"
    nv.OnDataSheet = 1
    c.NamedValue.append(nv)

    v = avm.Value()
    v.Unit = "m"
    v.ID = "ID4"
    v.DataType = avm.DataTypeEnum.Integer
    nv.Value = v

    fv = avm.FixedValue()
    fv.Value = "34513"
    v.ValueExpression = fv

    ### Build a NamedValue that will derive its value from the previous one.
    ### This is accomplished by using a DerivedValue object for the ValueExpression,
    ### and pointing back to the first one's ID.
    nv2 = avm.NamedValue()
    nv2.Name = "ADerivedValue"
    nv2.OnDataSheet = 0
    c.NamedValue.append(nv2)

    v2 = avm.Value()
    v2.Unit = "m"
    v2.ID = "ID5"
    v2.DataType = avm.DataTypeEnum.Integer
    nv2.Value = v2

    dv2 = avm.DerivedValue()
    dv2.ValueSource = v.ID
    v2.ValueExpression = dv2

    ### Build a NamedValue that is parametric -- the user will be able to go in
    ### and assign a value for it.
    ### We do this by using a ParametricValue ValueExpression. Specification
    ### of the allowed minimum, maximum, default, and assigned values are done
    ### using ValueExpressions themselves.
    ### In this case, we will say that the Default value is derived from the
    ### value of the first NamedValue object we chose.
    ### We will also use an alternative constructor technique in building objects.
    nv3 = avm.NamedValue(Name = "AParametricValue",OnDataSheet=0)
    c.NamedValue.append(nv3)

    v3 = avm.Value(Unit = "m", ID = "ID20",DataType = avm.DataTypeEnum.Real)
    nv3.Value = v3

    pv3 = avm.ParametricValue()
    v3.ValueExpression = pv3

    ve3_2 = avm.DerivedValue(ValueSource = v.ID)
    pv3.Default = ve3_2

    ve3_3 = avm.FixedValue(Value = "1.0")
    pv3.Minimum = ve3_3


    ### Build a Component Interface, and give it one role.
    i = avm.Interface()
    i.Name = "BogusInterface"
    c.Interface.append(i)

    r1 = avm.Role()
    r1.Name = "Role1 for Modelica Connector"
    i.Role.append(r1)

    r2 = avm.Role(Name = "Role2 for CAD CoordinateSystem")
    i.Role.append(r2)


    ### Create a DomainModel of type ModelicaModel.
    ### Then add one Metric and two Connectors, of different types.
    mm = modelica.ModelicaModel()
    mm.Class = "path.to.class"
    c.DomainModel.append(mm)

    mm_metric = modelica.Metric()
    mm_metric.Locator = "subsystem.max_force"
    mm_metric.ID = "ID3"
    mm_metric.Notes = "maximum force exerted over simulation"
    mm.Metric.append(mm_metric)

    mm_connector = modelica.Connector()
    mm_connector.Class = "Modelica.Mechanics.Rotational.Interfaces.Flange_a"
    mm_connector.Locator = "RotationalOut"
    mm_connector.ID = "ID1"
    mm.Connector.append(mm_connector)

    mm_translational = modelica.Connector()
    mm_translational.ID = "ID10"
    mm_translational.Class = "Modelica.Mechanics.Translational.Interfaces.Flange_a"
    mm_translational.Locator = "TranslationalInput"
    mm.Connector.append(mm_translational)


    ### Create a DomainModel of type CADModel.
    ### It has one parameter, the value of which will be derived from
    ### the first NamedValue of the Component.
    cm = cad.CADModel(Notes="A detailed CAD representation of the component")
    c.DomainModel.append(cm)

    csys = cad.CoordinateSystem(Name="MATING_POINT",ID="ID22")
    cm.Datum.append(csys)

    cparam = cad.Parameter(Name="LENGTH")
    cparam.Value = avm.Value(Unit="m",ID="ID21",DataType=avm.DataTypeEnum.Real,DimensionType=avm.DimensionTypeEnum.Scalar)
    cparam.Value.ValueExpression = avm.DerivedValue(ValueSource=v.ID)
    cm.Parameter.append(cparam)


    ### Map the roles on the Component Interface to Domain Model Ports.
    r1.DomainPort = mm_connector.ID
    r2.DomainPort = csys.ID


    ### Use minidom to pretty-print the xml
    dom_c = xml.dom.minidom.parseString(c.toxml("utf-8"))
    xml_c = dom_c.toprettyxml()
    print xml_c


    ### Deserialize the component and print its details
    dom_c_ = xml.dom.minidom.parseString(xml_c)
    c_deserialized = avm.Component.createFromDOM(dom_c_)
    print "----------------------"
    print "Deserialized Component"
    print "Name:", c_deserialized.Name
    for nv in c_deserialized.NamedValue:
        print "NamedValue:", nv.Name