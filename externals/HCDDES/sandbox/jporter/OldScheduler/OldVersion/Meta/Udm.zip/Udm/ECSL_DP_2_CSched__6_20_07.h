#ifndef MOBIES_ECSL_DP_2_CSCHED__6_20_07_H
#define MOBIES_ECSL_DP_2_CSCHED__6_20_07_H
// header file ECSL_DP_2_CSched__6_20_07.h generated from diagram ECSL_DP_2_CSched__6_20_07
// generated on Fri Jun 22 10:35:52 2007

#ifndef MOBIES_UDMBASE_H
#include "UdmBase.h"
#endif

#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif
namespace ECSL_DP_2_CSched__6_20_07 {
	extern  Udm::UdmDiagram diagram;
	 void Initialize(const ::Uml::Diagram &dgr);
	 void Initialize();

		class  _gen_cont;


		 void CreateMetaObjs();
		 void InitCrossNSInheritence();
		 void InitCrossNSCompositions();
		class  _gen_cont :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			_gen_cont() { }
			_gen_cont(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			_gen_cont(const _gen_cont &master) : UDM_OBJECT(master) { }
			static _gen_cont Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static _gen_cont Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			_gen_cont CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			_gen_cont CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont> Derived() { return Udm::DerivedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP_2_CSched__6_20_07::_gen_cont>(impl);}

			Udm::ParentAttr<Udm::Object> parent() const { return Udm::ParentAttr<Udm::Object>(impl, Udm::NULLPARENTROLE); }
		};



}

#endif //MOBIES_ECSL_DP_2_CSCHED__6_20_07_H
