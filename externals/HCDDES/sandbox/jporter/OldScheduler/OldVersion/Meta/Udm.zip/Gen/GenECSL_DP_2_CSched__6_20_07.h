/* GenECSL_DP_2_CSched__6_20_07.h generated on Wed Jun 20 15:39:44 2007
 */

#include <UdmBase.h>
#include <cint_string.h>
#include "CSched__6_20_07.h"
#include "ECSL_DP_2_CSched__6_20_07.h"
#include "ECSL_DP__6_20_07.h"

typedef std::list< Udm::Object> Packets_t;

// Forward declarations.
class TopBlock_0;
class CreateLinks_5;
class CreateProcs_53;
class CreateBuses_91;
class CreateSystems_cf;

// Class declarations.
class TopBlock_0
{
public:
	void operator()( const Packets_t& cSchedIns_1, const Packets_t& eCSLIns_3);

protected:
	void callCreateSystems_101( const Packets_t& rootFolders_d0, const Packets_t& rootFolders_d4);
	void callCreateProcs_104( const Packets_t& hardwareSheets_54, const Packets_t& rootFolders_57, const Packets_t& rootFolders_5a, const Packets_t& tTSystems_5d);
	void callCreateBuses_109( const Packets_t& hardwareSheets_92, const Packets_t& rootFolders_95, const Packets_t& rootFolders_98, const Packets_t& tTSystems_9b);
	void callCreateLinks_10e( const Packets_t& hardwareSheets_6, const Packets_t& rootFolders_8, const Packets_t& rootFolders_a, const Packets_t& tTSystems_c);
};

class CreateLinks_5
{
public:
	void operator()( const Packets_t& hardwareSheets_6, const Packets_t& rootFolders_8, const Packets_t& rootFolders_a, const Packets_t& tTSystems_c);

protected:
	bool isInputUnique( const Udm::Object& hardwareSheet_12, const Udm::Object& rootFolder_1b, const Udm::Object& rootFolder_24, const Udm::Object& tTSystem_2d);
	void processInputPackets( const Packets_t& hardwareSheets_6, const Packets_t& rootFolders_8, const Packets_t& rootFolders_a, const Packets_t& tTSystems_c);
	bool patternMatcher( const Udm::Object& hardwareSheet_10, const Udm::Object& rootFolder_19, const Udm::Object& rootFolder_22, const Udm::Object& tTSystem_2b);
	void effector();

private:
	Packets_t _hardwareSheet_e;
	Packets_t _rootFolder_17;
	Packets_t _rootFolder_20;
	Packets_t _tTSystem_29;
	class Match
	{
	public:
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_48;
		ECSL_DP__6_20_07::RootFolder rootFolder_49;
		ECSL_DP__6_20_07::ECU eCU_4a;
		ECSL_DP__6_20_07::Bus bus_4b;
		ECSL_DP__6_20_07::Wire wire_4c;
		ECSL_DP__6_20_07::BusChan busChan_4d;
		CSched__6_20_07::RootFolder rootFolder_4e;
		CSched__6_20_07::TTSystem tTSystem_4f;
		CSched__6_20_07::Bus newBus_50;
		CSched__6_20_07::Processor processor_51;
	};

	std::list< Match> _matches;
};

class CreateProcs_53
{
public:
	void operator()( const Packets_t& hardwareSheets_54, const Packets_t& rootFolders_57, const Packets_t& rootFolders_5a, const Packets_t& tTSystems_5d, Packets_t& hardwareSheets_56, Packets_t& rootFolders_59, Packets_t& rootFolders_5c, Packets_t& tTSystems_5f);

protected:
	bool isInputUnique( const Udm::Object& hardwareSheet_68, const Udm::Object& rootFolder_71, const Udm::Object& rootFolder_7a, const Udm::Object& tTSystem_83);
	void processInputPackets( const Packets_t& hardwareSheets_54, const Packets_t& rootFolders_57, const Packets_t& rootFolders_5a, const Packets_t& tTSystems_5d);
	bool patternMatcher( const Udm::Object& hardwareSheet_66, const Udm::Object& rootFolder_6f, const Udm::Object& rootFolder_78, const Udm::Object& tTSystem_81);
	void effector();
	void forwardInputs();

private:
	Packets_t* _hardwareSheet_60;
	Packets_t* _rootFolder_61;
	Packets_t* _rootFolder_62;
	Packets_t* _tTSystem_63;
	Packets_t _hardwareSheet_64;
	Packets_t _rootFolder_6d;
	Packets_t _rootFolder_76;
	Packets_t _tTSystem_7f;
	class Match
	{
	public:
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_8b;
		ECSL_DP__6_20_07::RootFolder rootFolder_8c;
		ECSL_DP__6_20_07::ECU eCU_8d;
		CSched__6_20_07::RootFolder rootFolder_8e;
		CSched__6_20_07::TTSystem tTSystem_8f;
	};

	std::list< Match> _matches;
};

class CreateBuses_91
{
public:
	void operator()( const Packets_t& hardwareSheets_92, const Packets_t& rootFolders_95, const Packets_t& rootFolders_98, const Packets_t& tTSystems_9b, Packets_t& hardwareSheets_94, Packets_t& rootFolders_97, Packets_t& rootFolders_9a, Packets_t& tTSystems_9d);

protected:
	bool isInputUnique( const Udm::Object& hardwareSheet_a6, const Udm::Object& rootFolder_af, const Udm::Object& rootFolder_b8, const Udm::Object& tTSystem_c1);
	void processInputPackets( const Packets_t& hardwareSheets_92, const Packets_t& rootFolders_95, const Packets_t& rootFolders_98, const Packets_t& tTSystems_9b);
	bool patternMatcher( const Udm::Object& hardwareSheet_a4, const Udm::Object& rootFolder_ad, const Udm::Object& rootFolder_b6, const Udm::Object& tTSystem_bf);
	void effector();
	void forwardInputs();

private:
	Packets_t* _hardwareSheet_9e;
	Packets_t* _rootFolder_9f;
	Packets_t* _rootFolder_a0;
	Packets_t* _tTSystem_a1;
	Packets_t _hardwareSheet_a2;
	Packets_t _rootFolder_ab;
	Packets_t _rootFolder_b4;
	Packets_t _tTSystem_bd;
	class Match
	{
	public:
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_c9;
		ECSL_DP__6_20_07::RootFolder rootFolder_ca;
		ECSL_DP__6_20_07::Bus bus_cb;
		CSched__6_20_07::RootFolder rootFolder_cc;
		CSched__6_20_07::TTSystem tTSystem_cd;
	};

	std::list< Match> _matches;
};

class CreateSystems_cf
{
public:
	void operator()( const Packets_t& rootFolders_d0, const Packets_t& rootFolders_d4, Packets_t& rootFolders_d2, Packets_t& hardwareSheets_d3, Packets_t& rootFolders_d6, Packets_t& tTSystems_d7);

protected:
	bool isInputUnique( const Udm::Object& rootFolder_e0, const Udm::Object& rootFolder_e9);
	void processInputPackets( const Packets_t& rootFolders_d0, const Packets_t& rootFolders_d4);
	bool patternMatcher( const Udm::Object& rootFolder_de, const Udm::Object& rootFolder_e7);
	void effector();
	void outputAppender( const ECSL_DP__6_20_07::RootFolder& rootFolder_f9, const ECSL_DP__6_20_07::HardwareSheet& hardwareSheet_fb, const CSched__6_20_07::RootFolder& rootFolder_fd, const CSched__6_20_07::TTSystem& tTSystem_ff);

private:
	Packets_t* _rootFolder_d8;
	Packets_t* _hardwareSheet_d9;
	Packets_t* _rootFolder_da;
	Packets_t* _tTSystem_db;
	Packets_t _rootFolder_dc;
	Packets_t _rootFolder_e5;
	class Match
	{
	public:
		ECSL_DP__6_20_07::HardwareModels hardwareModels_f4;
		ECSL_DP__6_20_07::RootFolder rootFolder_f5;
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_f6;
		CSched__6_20_07::RootFolder rootFolder_f7;
	};

	std::list< Match> _matches;
};

