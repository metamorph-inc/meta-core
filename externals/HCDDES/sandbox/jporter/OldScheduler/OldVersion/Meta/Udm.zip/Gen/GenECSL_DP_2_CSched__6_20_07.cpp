/* GenECSL_DP_2_CSched__6_20_07.cpp generated on Wed Jun 20 15:39:44 2007
 */

#include "GenECSL_DP_2_CSched__6_20_07.h"
#include <UmlExt.h>
#include <UdmUtil.h>
#include "GReATSort.h"
#include "ECSL_DP_2_CSched__6_20_07-gr_cmptempl.h"

void TopBlock_0::operator()( const Packets_t& cSchedIns_1, const Packets_t& eCSLIns_3)
{
#ifdef PRINT_INFO
	std::cout << "TopBlock_0" << std::endl;
#endif
	if( ( !eCSLIns_3.empty())&& ( !cSchedIns_1.empty()))
		callCreateSystems_101( eCSLIns_3, cSchedIns_1);
}

void TopBlock_0::callCreateSystems_101( const Packets_t& rootFolders_d0, const Packets_t& rootFolders_d4)
{
	Packets_t rootFolders_d2;
	Packets_t hardwareSheets_d3;
	Packets_t rootFolders_d6;
	Packets_t tTSystems_d7;
	CreateSystems_cf createSystems_cf;
	createSystems_cf( rootFolders_d0, rootFolders_d4, rootFolders_d2, hardwareSheets_d3, rootFolders_d6, tTSystems_d7);
	if( ( !hardwareSheets_d3.empty())&& ( !rootFolders_d2.empty())&& ( !rootFolders_d6.empty())&& ( !tTSystems_d7.empty()))
		callCreateProcs_104( hardwareSheets_d3, rootFolders_d2, rootFolders_d6, tTSystems_d7);
}

void TopBlock_0::callCreateProcs_104( const Packets_t& hardwareSheets_54, const Packets_t& rootFolders_57, const Packets_t& rootFolders_5a, const Packets_t& tTSystems_5d)
{
	Packets_t hardwareSheets_56;
	Packets_t rootFolders_59;
	Packets_t rootFolders_5c;
	Packets_t tTSystems_5f;
	CreateProcs_53 createProcs_53;
	createProcs_53( hardwareSheets_54, rootFolders_57, rootFolders_5a, tTSystems_5d, hardwareSheets_56, rootFolders_59, rootFolders_5c, tTSystems_5f);
	if( ( !hardwareSheets_56.empty())&& ( !rootFolders_59.empty())&& ( !rootFolders_5c.empty())&& ( !tTSystems_5f.empty()))
		callCreateBuses_109( hardwareSheets_56, rootFolders_59, rootFolders_5c, tTSystems_5f);
}

void TopBlock_0::callCreateBuses_109( const Packets_t& hardwareSheets_92, const Packets_t& rootFolders_95, const Packets_t& rootFolders_98, const Packets_t& tTSystems_9b)
{
	Packets_t hardwareSheets_94;
	Packets_t rootFolders_97;
	Packets_t rootFolders_9a;
	Packets_t tTSystems_9d;
	CreateBuses_91 createBuses_91;
	createBuses_91( hardwareSheets_92, rootFolders_95, rootFolders_98, tTSystems_9b, hardwareSheets_94, rootFolders_97, rootFolders_9a, tTSystems_9d);
	if( ( !hardwareSheets_94.empty())&& ( !rootFolders_97.empty())&& ( !rootFolders_9a.empty())&& ( !tTSystems_9d.empty()))
		callCreateLinks_10e( hardwareSheets_94, rootFolders_97, rootFolders_9a, tTSystems_9d);
}

void TopBlock_0::callCreateLinks_10e( const Packets_t& hardwareSheets_6, const Packets_t& rootFolders_8, const Packets_t& rootFolders_a, const Packets_t& tTSystems_c)
{
	CreateLinks_5 createLinks_5;
	createLinks_5( hardwareSheets_6, rootFolders_8, rootFolders_a, tTSystems_c);
}

void CreateLinks_5::operator()( const Packets_t& hardwareSheets_6, const Packets_t& rootFolders_8, const Packets_t& rootFolders_a, const Packets_t& tTSystems_c)
{
#ifdef PRINT_INFO
	std::cout << "CreateLinks_5" << std::endl;
#endif
	processInputPackets( hardwareSheets_6, rootFolders_8, rootFolders_a, tTSystems_c);
}

bool CreateLinks_5::isInputUnique( const Udm::Object& hardwareSheet_12, const Udm::Object& rootFolder_1b, const Udm::Object& rootFolder_24, const Udm::Object& tTSystem_2d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itHardwareSheet_14= _hardwareSheet_e.begin(), itRootFolder_1d= _rootFolder_17.begin(), itRootFolder_26= _rootFolder_20.begin(), itTTSystem_2f= _tTSystem_29.begin(); itHardwareSheet_14!= _hardwareSheet_e.end(), itRootFolder_1d!= _rootFolder_17.end(), itRootFolder_26!= _rootFolder_20.end(), itTTSystem_2f!= _tTSystem_29.end(); ++itHardwareSheet_14, ++itRootFolder_1d, ++itRootFolder_26, ++itTTSystem_2f)
	{
		if( ( *itHardwareSheet_14== hardwareSheet_12)&& ( *itRootFolder_1d== rootFolder_1b)&& ( *itRootFolder_26== rootFolder_24)&& ( *itTTSystem_2f== tTSystem_2d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_hardwareSheet_e.push_back( hardwareSheet_12);
		_rootFolder_17.push_back( rootFolder_1b);
		_rootFolder_20.push_back( rootFolder_24);
		_tTSystem_29.push_back( tTSystem_2d);
	}
	return isUnique;
}

void CreateLinks_5::processInputPackets( const Packets_t& hardwareSheets_6, const Packets_t& rootFolders_8, const Packets_t& rootFolders_a, const Packets_t& tTSystems_c)
{
	for( Packets_t::const_iterator itHardwareSheet_f= hardwareSheets_6.begin(), itRootFolder_18= rootFolders_8.begin(), itRootFolder_21= rootFolders_a.begin(), itTTSystem_2a= tTSystems_c.begin(); itHardwareSheet_f!= hardwareSheets_6.end(), itRootFolder_18!= rootFolders_8.end(), itRootFolder_21!= rootFolders_a.end(), itTTSystem_2a!= tTSystems_c.end(); ++itHardwareSheet_f, ++itRootFolder_18, ++itRootFolder_21, ++itTTSystem_2a)
	{
		bool isUnique= isInputUnique( *itHardwareSheet_f, *itRootFolder_18, *itRootFolder_21, *itTTSystem_2a);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itHardwareSheet_f, *itRootFolder_18, *itRootFolder_21, *itTTSystem_2a);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateLinks_5::patternMatcher( const Udm::Object& hardwareSheet_10, const Udm::Object& rootFolder_19, const Udm::Object& rootFolder_22, const Udm::Object& tTSystem_2b)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( hardwareSheet_10.type(), ECSL_DP__6_20_07::HardwareSheet::meta))
			continue;
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_15= ECSL_DP__6_20_07::HardwareSheet::Cast( hardwareSheet_10);
		if( false== Uml::IsDerivedFrom( rootFolder_19.type(), ECSL_DP__6_20_07::RootFolder::meta))
			continue;
		ECSL_DP__6_20_07::RootFolder rootFolder_1e= ECSL_DP__6_20_07::RootFolder::Cast( rootFolder_19);
		if( false== Uml::IsDerivedFrom( rootFolder_22.type(), CSched__6_20_07::RootFolder::meta))
			continue;
		CSched__6_20_07::RootFolder rootFolder_27= CSched__6_20_07::RootFolder::Cast( rootFolder_22);
		if( false== Uml::IsDerivedFrom( tTSystem_2b.type(), CSched__6_20_07::TTSystem::meta))
			continue;
		CSched__6_20_07::TTSystem tTSystem_30= CSched__6_20_07::TTSystem::Cast( tTSystem_2b);
		set< ECSL_DP__6_20_07::ECU> eCUs_32= hardwareSheet_15.ECU_kind_children();
		for( set< ECSL_DP__6_20_07::ECU>::const_iterator itECU_33= eCUs_32.begin(); itECU_33!= eCUs_32.end(); ++itECU_33)
		{
			ECSL_DP__6_20_07::ECU currECU_34= *itECU_33;
			set< CSched__6_20_07::Processor> processors_35= tTSystem_30.Processor_kind_children();
			for( set< CSched__6_20_07::Processor>::const_iterator itProcessor_36= processors_35.begin(); itProcessor_36!= processors_35.end(); ++itProcessor_36)
			{
				CSched__6_20_07::Processor currProcessor_37= *itProcessor_36;
				set< ECSL_DP__6_20_07::Bus> buss_38= hardwareSheet_15.Bus_kind_children();
				for( set< ECSL_DP__6_20_07::Bus>::const_iterator itBus_39= buss_38.begin(); itBus_39!= buss_38.end(); ++itBus_39)
				{
					ECSL_DP__6_20_07::Bus currBus_3a= *itBus_39;
					set< CSched__6_20_07::Bus> newBuss_3b= tTSystem_30.Bus_kind_children();
					for( set< CSched__6_20_07::Bus>::const_iterator itNewBus_3c= newBuss_3b.begin(); itNewBus_3c!= newBuss_3b.end(); ++itNewBus_3c)
					{
						CSched__6_20_07::Bus currNewBus_3d= *itNewBus_3c;
						set< ECSL_DP__6_20_07::BusChan> busChans_3e= currECU_34.BusChan_kind_children();
						for( set< ECSL_DP__6_20_07::BusChan>::const_iterator itBusChan_3f= busChans_3e.begin(); itBusChan_3f!= busChans_3e.end(); ++itBusChan_3f)
						{
							ECSL_DP__6_20_07::BusChan currBusChan_40= *itBusChan_3f;
							set< ECSL_DP__6_20_07::Wire> wires_41= hardwareSheet_15.Wire_kind_children();
							for( set< ECSL_DP__6_20_07::Wire>::const_iterator itWire_42= wires_41.begin(); itWire_42!= wires_41.end(); ++itWire_42)
							{
								ECSL_DP__6_20_07::Wire currWire_43= *itWire_42;
								ECSL_DP__6_20_07::CommElement busChan_44= currWire_43.srcWire_end();
								if( false== Uml::IsDerivedFrom( busChan_44.type(), ECSL_DP__6_20_07::BusChan::meta))
									continue;
								ECSL_DP__6_20_07::BusChan currBusChan_45= ECSL_DP__6_20_07::BusChan::Cast( busChan_44);
								if( currBusChan_40!= currBusChan_45)
									continue;
								ECSL_DP__6_20_07::CommElement bus_46= currWire_43.dstWire_end();
								if( false== Uml::IsDerivedFrom( bus_46.type(), ECSL_DP__6_20_07::Bus::meta))
									continue;
								ECSL_DP__6_20_07::Bus currBus_47= ECSL_DP__6_20_07::Bus::Cast( bus_46);
								if( currBus_3a!= currBus_47)
									continue;
								Match currMatch;
								currMatch.hardwareSheet_48= hardwareSheet_15;
								currMatch.rootFolder_49= rootFolder_1e;
								currMatch.eCU_4a= currECU_34;
								currMatch.bus_4b= currBus_3a;
								currMatch.wire_4c= currWire_43;
								currMatch.busChan_4d= currBusChan_40;
								currMatch.rootFolder_4e= rootFolder_27;
								currMatch.tTSystem_4f= tTSystem_30;
								currMatch.newBus_50= currNewBus_3d;
								currMatch.processor_51= currProcessor_37;
								_matches.push_back( currMatch);
							}
						}
					}
				}
			}
		}
	}
	return !_matches.empty();
}

void CreateLinks_5::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		CSched__6_20_07::Link newLink_52= CSched__6_20_07::Link::Create( currMatch.tTSystem_4f);
		newLink_52.srcLink_end()= currMatch.processor_51;
		newLink_52.dstLink_end()= currMatch.newBus_50;
	}
}

void CreateProcs_53::operator()( const Packets_t& hardwareSheets_54, const Packets_t& rootFolders_57, const Packets_t& rootFolders_5a, const Packets_t& tTSystems_5d, Packets_t& hardwareSheets_56, Packets_t& rootFolders_59, Packets_t& rootFolders_5c, Packets_t& tTSystems_5f)
{
#ifdef PRINT_INFO
	std::cout << "CreateProcs_53" << std::endl;
#endif
	_hardwareSheet_60= &hardwareSheets_56;
	_rootFolder_61= &rootFolders_59;
	_rootFolder_62= &rootFolders_5c;
	_tTSystem_63= &tTSystems_5f;
	processInputPackets( hardwareSheets_54, rootFolders_57, rootFolders_5a, tTSystems_5d);
	forwardInputs( );
}

bool CreateProcs_53::isInputUnique( const Udm::Object& hardwareSheet_68, const Udm::Object& rootFolder_71, const Udm::Object& rootFolder_7a, const Udm::Object& tTSystem_83)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itHardwareSheet_6a= _hardwareSheet_64.begin(), itRootFolder_73= _rootFolder_6d.begin(), itRootFolder_7c= _rootFolder_76.begin(), itTTSystem_85= _tTSystem_7f.begin(); itHardwareSheet_6a!= _hardwareSheet_64.end(), itRootFolder_73!= _rootFolder_6d.end(), itRootFolder_7c!= _rootFolder_76.end(), itTTSystem_85!= _tTSystem_7f.end(); ++itHardwareSheet_6a, ++itRootFolder_73, ++itRootFolder_7c, ++itTTSystem_85)
	{
		if( ( *itHardwareSheet_6a== hardwareSheet_68)&& ( *itRootFolder_73== rootFolder_71)&& ( *itRootFolder_7c== rootFolder_7a)&& ( *itTTSystem_85== tTSystem_83))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_hardwareSheet_64.push_back( hardwareSheet_68);
		_rootFolder_6d.push_back( rootFolder_71);
		_rootFolder_76.push_back( rootFolder_7a);
		_tTSystem_7f.push_back( tTSystem_83);
	}
	return isUnique;
}

void CreateProcs_53::processInputPackets( const Packets_t& hardwareSheets_54, const Packets_t& rootFolders_57, const Packets_t& rootFolders_5a, const Packets_t& tTSystems_5d)
{
	for( Packets_t::const_iterator itHardwareSheet_65= hardwareSheets_54.begin(), itRootFolder_6e= rootFolders_57.begin(), itRootFolder_77= rootFolders_5a.begin(), itTTSystem_80= tTSystems_5d.begin(); itHardwareSheet_65!= hardwareSheets_54.end(), itRootFolder_6e!= rootFolders_57.end(), itRootFolder_77!= rootFolders_5a.end(), itTTSystem_80!= tTSystems_5d.end(); ++itHardwareSheet_65, ++itRootFolder_6e, ++itRootFolder_77, ++itTTSystem_80)
	{
		bool isUnique= isInputUnique( *itHardwareSheet_65, *itRootFolder_6e, *itRootFolder_77, *itTTSystem_80);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itHardwareSheet_65, *itRootFolder_6e, *itRootFolder_77, *itTTSystem_80);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateProcs_53::patternMatcher( const Udm::Object& hardwareSheet_66, const Udm::Object& rootFolder_6f, const Udm::Object& rootFolder_78, const Udm::Object& tTSystem_81)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( hardwareSheet_66.type(), ECSL_DP__6_20_07::HardwareSheet::meta))
			continue;
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_6b= ECSL_DP__6_20_07::HardwareSheet::Cast( hardwareSheet_66);
		if( false== Uml::IsDerivedFrom( rootFolder_6f.type(), ECSL_DP__6_20_07::RootFolder::meta))
			continue;
		ECSL_DP__6_20_07::RootFolder rootFolder_74= ECSL_DP__6_20_07::RootFolder::Cast( rootFolder_6f);
		if( false== Uml::IsDerivedFrom( rootFolder_78.type(), CSched__6_20_07::RootFolder::meta))
			continue;
		CSched__6_20_07::RootFolder rootFolder_7d= CSched__6_20_07::RootFolder::Cast( rootFolder_78);
		if( false== Uml::IsDerivedFrom( tTSystem_81.type(), CSched__6_20_07::TTSystem::meta))
			continue;
		CSched__6_20_07::TTSystem tTSystem_86= CSched__6_20_07::TTSystem::Cast( tTSystem_81);
		set< ECSL_DP__6_20_07::ECU> eCUs_88= hardwareSheet_6b.ECU_kind_children();
		for( set< ECSL_DP__6_20_07::ECU>::const_iterator itECU_89= eCUs_88.begin(); itECU_89!= eCUs_88.end(); ++itECU_89)
		{
			ECSL_DP__6_20_07::ECU currECU_8a= *itECU_89;
			Match currMatch;
			currMatch.hardwareSheet_8b= hardwareSheet_6b;
			currMatch.rootFolder_8c= rootFolder_74;
			currMatch.eCU_8d= currECU_8a;
			currMatch.rootFolder_8e= rootFolder_7d;
			currMatch.tTSystem_8f= tTSystem_86;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void CreateProcs_53::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		CSched__6_20_07::Processor newProcessor_90= CSched__6_20_07::Processor::Create( currMatch.tTSystem_8f);
		ECSL_DP__6_20_07::ECU& ECU= currMatch.eCU_8d;
		ECSL_DP__6_20_07::HardwareSheet& HardwareSheet= currMatch.hardwareSheet_8b;
		CSched__6_20_07::Processor& Processor= newProcessor_90;
		CSched__6_20_07::TTSystem& TTSystem= currMatch.tTSystem_8f;
		{Processor.name() = ECU.name();};
	}
}

void CreateProcs_53::forwardInputs()
{
	*_hardwareSheet_60= _hardwareSheet_64;
	*_rootFolder_61= _rootFolder_6d;
	*_rootFolder_62= _rootFolder_76;
	*_tTSystem_63= _tTSystem_7f;
}

void CreateBuses_91::operator()( const Packets_t& hardwareSheets_92, const Packets_t& rootFolders_95, const Packets_t& rootFolders_98, const Packets_t& tTSystems_9b, Packets_t& hardwareSheets_94, Packets_t& rootFolders_97, Packets_t& rootFolders_9a, Packets_t& tTSystems_9d)
{
#ifdef PRINT_INFO
	std::cout << "CreateBuses_91" << std::endl;
#endif
	_hardwareSheet_9e= &hardwareSheets_94;
	_rootFolder_9f= &rootFolders_97;
	_rootFolder_a0= &rootFolders_9a;
	_tTSystem_a1= &tTSystems_9d;
	processInputPackets( hardwareSheets_92, rootFolders_95, rootFolders_98, tTSystems_9b);
	forwardInputs( );
}

bool CreateBuses_91::isInputUnique( const Udm::Object& hardwareSheet_a6, const Udm::Object& rootFolder_af, const Udm::Object& rootFolder_b8, const Udm::Object& tTSystem_c1)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itHardwareSheet_a8= _hardwareSheet_a2.begin(), itRootFolder_b1= _rootFolder_ab.begin(), itRootFolder_ba= _rootFolder_b4.begin(), itTTSystem_c3= _tTSystem_bd.begin(); itHardwareSheet_a8!= _hardwareSheet_a2.end(), itRootFolder_b1!= _rootFolder_ab.end(), itRootFolder_ba!= _rootFolder_b4.end(), itTTSystem_c3!= _tTSystem_bd.end(); ++itHardwareSheet_a8, ++itRootFolder_b1, ++itRootFolder_ba, ++itTTSystem_c3)
	{
		if( ( *itHardwareSheet_a8== hardwareSheet_a6)&& ( *itRootFolder_b1== rootFolder_af)&& ( *itRootFolder_ba== rootFolder_b8)&& ( *itTTSystem_c3== tTSystem_c1))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_hardwareSheet_a2.push_back( hardwareSheet_a6);
		_rootFolder_ab.push_back( rootFolder_af);
		_rootFolder_b4.push_back( rootFolder_b8);
		_tTSystem_bd.push_back( tTSystem_c1);
	}
	return isUnique;
}

void CreateBuses_91::processInputPackets( const Packets_t& hardwareSheets_92, const Packets_t& rootFolders_95, const Packets_t& rootFolders_98, const Packets_t& tTSystems_9b)
{
	for( Packets_t::const_iterator itHardwareSheet_a3= hardwareSheets_92.begin(), itRootFolder_ac= rootFolders_95.begin(), itRootFolder_b5= rootFolders_98.begin(), itTTSystem_be= tTSystems_9b.begin(); itHardwareSheet_a3!= hardwareSheets_92.end(), itRootFolder_ac!= rootFolders_95.end(), itRootFolder_b5!= rootFolders_98.end(), itTTSystem_be!= tTSystems_9b.end(); ++itHardwareSheet_a3, ++itRootFolder_ac, ++itRootFolder_b5, ++itTTSystem_be)
	{
		bool isUnique= isInputUnique( *itHardwareSheet_a3, *itRootFolder_ac, *itRootFolder_b5, *itTTSystem_be);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itHardwareSheet_a3, *itRootFolder_ac, *itRootFolder_b5, *itTTSystem_be);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateBuses_91::patternMatcher( const Udm::Object& hardwareSheet_a4, const Udm::Object& rootFolder_ad, const Udm::Object& rootFolder_b6, const Udm::Object& tTSystem_bf)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( hardwareSheet_a4.type(), ECSL_DP__6_20_07::HardwareSheet::meta))
			continue;
		ECSL_DP__6_20_07::HardwareSheet hardwareSheet_a9= ECSL_DP__6_20_07::HardwareSheet::Cast( hardwareSheet_a4);
		if( false== Uml::IsDerivedFrom( rootFolder_ad.type(), ECSL_DP__6_20_07::RootFolder::meta))
			continue;
		ECSL_DP__6_20_07::RootFolder rootFolder_b2= ECSL_DP__6_20_07::RootFolder::Cast( rootFolder_ad);
		if( false== Uml::IsDerivedFrom( rootFolder_b6.type(), CSched__6_20_07::RootFolder::meta))
			continue;
		CSched__6_20_07::RootFolder rootFolder_bb= CSched__6_20_07::RootFolder::Cast( rootFolder_b6);
		if( false== Uml::IsDerivedFrom( tTSystem_bf.type(), CSched__6_20_07::TTSystem::meta))
			continue;
		CSched__6_20_07::TTSystem tTSystem_c4= CSched__6_20_07::TTSystem::Cast( tTSystem_bf);
		set< ECSL_DP__6_20_07::Bus> buss_c6= hardwareSheet_a9.Bus_kind_children();
		for( set< ECSL_DP__6_20_07::Bus>::const_iterator itBus_c7= buss_c6.begin(); itBus_c7!= buss_c6.end(); ++itBus_c7)
		{
			ECSL_DP__6_20_07::Bus currBus_c8= *itBus_c7;
			Match currMatch;
			currMatch.hardwareSheet_c9= hardwareSheet_a9;
			currMatch.rootFolder_ca= rootFolder_b2;
			currMatch.bus_cb= currBus_c8;
			currMatch.rootFolder_cc= rootFolder_bb;
			currMatch.tTSystem_cd= tTSystem_c4;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void CreateBuses_91::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		CSched__6_20_07::Bus newNewBus_ce= CSched__6_20_07::Bus::Create( currMatch.tTSystem_cd);
		ECSL_DP__6_20_07::Bus& Bus= currMatch.bus_cb;
		ECSL_DP__6_20_07::HardwareSheet& HardwareSheet= currMatch.hardwareSheet_c9;
		CSched__6_20_07::Bus& NewBus= newNewBus_ce;
		CSched__6_20_07::TTSystem& TTSystem= currMatch.tTSystem_cd;
		{NewBus.name() = Bus.name();};
	}
}

void CreateBuses_91::forwardInputs()
{
	*_hardwareSheet_9e= _hardwareSheet_a2;
	*_rootFolder_9f= _rootFolder_ab;
	*_rootFolder_a0= _rootFolder_b4;
	*_tTSystem_a1= _tTSystem_bd;
}

void CreateSystems_cf::operator()( const Packets_t& rootFolders_d0, const Packets_t& rootFolders_d4, Packets_t& rootFolders_d2, Packets_t& hardwareSheets_d3, Packets_t& rootFolders_d6, Packets_t& tTSystems_d7)
{
#ifdef PRINT_INFO
	std::cout << "CreateSystems_cf" << std::endl;
#endif
	_rootFolder_d8= &rootFolders_d2;
	_hardwareSheet_d9= &hardwareSheets_d3;
	_rootFolder_da= &rootFolders_d6;
	_tTSystem_db= &tTSystems_d7;
	processInputPackets( rootFolders_d0, rootFolders_d4);
}

bool CreateSystems_cf::isInputUnique( const Udm::Object& rootFolder_e0, const Udm::Object& rootFolder_e9)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itRootFolder_e2= _rootFolder_dc.begin(), itRootFolder_eb= _rootFolder_e5.begin(); itRootFolder_e2!= _rootFolder_dc.end(), itRootFolder_eb!= _rootFolder_e5.end(); ++itRootFolder_e2, ++itRootFolder_eb)
	{
		if( ( *itRootFolder_e2== rootFolder_e0)&& ( *itRootFolder_eb== rootFolder_e9))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_rootFolder_dc.push_back( rootFolder_e0);
		_rootFolder_e5.push_back( rootFolder_e9);
	}
	return isUnique;
}

void CreateSystems_cf::processInputPackets( const Packets_t& rootFolders_d0, const Packets_t& rootFolders_d4)
{
	for( Packets_t::const_iterator itRootFolder_dd= rootFolders_d0.begin(), itRootFolder_e6= rootFolders_d4.begin(); itRootFolder_dd!= rootFolders_d0.end(), itRootFolder_e6!= rootFolders_d4.end(); ++itRootFolder_dd, ++itRootFolder_e6)
	{
		bool isUnique= isInputUnique( *itRootFolder_dd, *itRootFolder_e6);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itRootFolder_dd, *itRootFolder_e6);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateSystems_cf::patternMatcher( const Udm::Object& rootFolder_de, const Udm::Object& rootFolder_e7)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( rootFolder_de.type(), ECSL_DP__6_20_07::RootFolder::meta))
			continue;
		ECSL_DP__6_20_07::RootFolder rootFolder_e3= ECSL_DP__6_20_07::RootFolder::Cast( rootFolder_de);
		if( false== Uml::IsDerivedFrom( rootFolder_e7.type(), CSched__6_20_07::RootFolder::meta))
			continue;
		CSched__6_20_07::RootFolder rootFolder_ec= CSched__6_20_07::RootFolder::Cast( rootFolder_e7);
		set< ECSL_DP__6_20_07::HardwareModels> hardwareModelss_ee= rootFolder_e3.HardwareModels_kind_children();
		for( set< ECSL_DP__6_20_07::HardwareModels>::const_iterator itHardwareModels_ef= hardwareModelss_ee.begin(); itHardwareModels_ef!= hardwareModelss_ee.end(); ++itHardwareModels_ef)
		{
			ECSL_DP__6_20_07::HardwareModels currHardwareModels_f0= *itHardwareModels_ef;
			set< ECSL_DP__6_20_07::HardwareSheet> hardwareSheets_f1= currHardwareModels_f0.HardwareSheet_kind_children();
			for( set< ECSL_DP__6_20_07::HardwareSheet>::const_iterator itHardwareSheet_f2= hardwareSheets_f1.begin(); itHardwareSheet_f2!= hardwareSheets_f1.end(); ++itHardwareSheet_f2)
			{
				ECSL_DP__6_20_07::HardwareSheet currHardwareSheet_f3= *itHardwareSheet_f2;
				Match currMatch;
				currMatch.hardwareModels_f4= currHardwareModels_f0;
				currMatch.rootFolder_f5= rootFolder_e3;
				currMatch.hardwareSheet_f6= currHardwareSheet_f3;
				currMatch.rootFolder_f7= rootFolder_ec;
				_matches.push_back( currMatch);
			}
		}
	}
	return !_matches.empty();
}

void CreateSystems_cf::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		CSched__6_20_07::TTSystem newTTSystem_f8= CSched__6_20_07::TTSystem::Create( currMatch.rootFolder_f7);
		ECSL_DP__6_20_07::HardwareModels& HardwareModels= currMatch.hardwareModels_f4;
		ECSL_DP__6_20_07::HardwareSheet& HardwareSheet= currMatch.hardwareSheet_f6;
		CSched__6_20_07::TTSystem& TTSystem= newTTSystem_f8;
		{TTSystem.name() = HardwareSheet.name();};
		outputAppender( currMatch.rootFolder_f5, currMatch.hardwareSheet_f6, currMatch.rootFolder_f7, newTTSystem_f8);
	}
}

void CreateSystems_cf::outputAppender( const ECSL_DP__6_20_07::RootFolder& rootFolder_f9, const ECSL_DP__6_20_07::HardwareSheet& hardwareSheet_fb, const CSched__6_20_07::RootFolder& rootFolder_fd, const CSched__6_20_07::TTSystem& tTSystem_ff)
{
	_rootFolder_d8->push_back( rootFolder_f9);
	_hardwareSheet_d9->push_back( hardwareSheet_fb);
	_rootFolder_da->push_back( rootFolder_fd);
	_tTSystem_db->push_back( tTSystem_ff);
}

