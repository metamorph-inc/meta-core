// cpp(meta datanetwork format) source file ECSL_DP_2_CSched__6_20_07.cpp generated from diagram ECSL_DP_2_CSched__6_20_07
// generated on Fri Jun 22 10:35:52 2007

#include "ECSL_DP_2_CSched__6_20_07.h"
#include "UmlExt.h"

#include "UdmStatic.h"

namespace ECSL_DP_2_CSched__6_20_07 {

	::Uml::Diagram umldiagram;

		::Uml::Class _gen_cont::meta;
		void Creates()
		{
			_gen_cont::meta = ::Uml::Class::Create(umldiagram);
		}
		void InitClassesAttributes()
		{
			_gen_cont::meta.name() = "_gen_cont";
			_gen_cont::meta.isAbstract() = false;
			
			
		}
		void CreatesNamespaces()
		{
		}
		void InitNamespaces()
		{
		}
		void InitCrossNSCompositions()
		{
		}
		void InitInheritence()
		{
		}
		void InitCrossNSInheritence()
		{
		}
	 void InitializeDgr()
	{
		Creates();
		InitClassesAttributes();
		CreatesNamespaces();
		InitNamespaces();
		InitInheritence();
		
	}
		 void InitializeDgr(const ::Uml::Diagram & dgr)
		{
			::Uml::SetClass(_gen_cont::meta, dgr, "_gen_cont");
			//composition child roles 
			// composition parentroles 
			// Association roles 

			// namespaces

			
		}
	 void Initialize()
	{
		static bool first = true;
		if(!first) return;
		first = false;
		::Uml::Initialize();

		ASSERT( umldiagram == Udm::null );
		UdmStatic::StaticDataNetwork * meta_dn = new UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("ECSL_DP_2_CSched__6_20_07.mem", "", ::Uml::Diagram::meta, Udm::CHANGES_LOST_DEFAULT);
		umldiagram = ::Uml::Diagram::Cast(meta_dn->GetRootObject());
		umldiagram.name() ="ECSL_DP_2_CSched__6_20_07";
		umldiagram.version() ="1.00";
		InitializeDgr();

		InitCrossNSInheritence();
		InitCrossNSCompositions();

	};

	 void Initialize(const ::Uml::Diagram &dgr)
	{
		umldiagram = dgr;
		InitializeDgr(dgr);

	};

	 Udm::UdmDiagram diagram = { &umldiagram, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			Udm::MetaDepository::StoreDiagram("ECSL_DP_2_CSched__6_20_07", diagram);
		};
		~_regClass()
		{
			Udm::MetaDepository::RemoveDiagram("ECSL_DP_2_CSched__6_20_07");
		};
	} __regUnUsed;

}
// END ECSL_DP_2_CSched__6_20_07.cpp
