#ifndef MOBIES_ECSL_DP__6_20_07_H
#define MOBIES_ECSL_DP__6_20_07_H
// header file ECSL_DP__6_20_07.h generated from diagram ECSL_DP__6_20_07
// generated on Fri Jun 22 10:35:53 2007

#ifndef MOBIES_UDMBASE_H
#include "UdmBase.h"
#endif

#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif
namespace ECSL_DP__6_20_07 {
	extern  Udm::UdmDiagram diagram;
	 void Initialize(const ::Uml::Diagram &dgr);
	 void Initialize();

		class  RTCOut;
		class  RTConstraint;
		class  RTCIn;
		class  SystemRef;
		class  InPortMapping;
		class  ComponentShortcut;
		class  ComponentSheet;
		class  Signal;
		class  COutPort;
		class  CInPort;
		class  ComponentModels;
		class  OutPortMapping;
		class  CPort;
		class  Component;
		class  COM;
		class  FirmwareLink;
		class  FirmwareModule;
		class  OS;
		class  CommElement;
		class  HWElement;
		class  Channel;
		class  IChan;
		class  OChan;
		class  BusMessage;
		class  BusMessageRef;
		class  HardwareSheet;
		class  HardwareModels;
		class  Wire;
		class  BusChan;
		class  ECU;
		class  Bus;
		class  MgaObject;
		class  TypeBaseRef;
		class  Types;
		class  TypeStruct;
		class  Matrix;
		class  TypeBase;
		class  Primitive;
		class  Block;
		class  TriggerPort;
		class  Parameter;
		class  Reference;
		class  Annotation;
		class  Line;
		class  InputPort;
		class  Dataflow;
		class  EnablePort;
		class  System;
		class  OutputPort;
		class  Port;
		class  TypedPort;
		class  StatePort;
		class  OutCommMapping;
		class  Task;
		class  ComponentRef;
		class  Order;
		class  CommDst;
		class  CommMapping;
		class  InCommMapping;
		class  RootFolder;
		class  State;
		class  Transition;
		class  Event;
		class  History;
		class  TransStart;
		class  Junction;
		class  ConnectorRef;
		class  Stateflow;
		class  Data;
		class  TransConnector;


		 void CreateMetaObjs();
		 void InitCrossNSInheritence();
		 void InitCrossNSCompositions();
		class  ComponentModels :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			ComponentModels() { }
			ComponentModels(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			ComponentModels(const ComponentModels &master) : UDM_OBJECT(master) { }
			static ComponentModels Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static ComponentModels Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			ComponentModels CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			ComponentModels CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentModels> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentModels> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentModels> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl);}

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			static ::Uml::CompositionChildRole meta_ComponentSheet_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet> ComponentSheet_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl, meta_ComponentSheet_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred> ComponentSheet_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred>(impl, meta_ComponentSheet_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet> ComponentSheet_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred> ComponentSheet_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_RootFolder_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLPARENTROLE); }
		};

		class  HardwareModels :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			HardwareModels() { }
			HardwareModels(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			HardwareModels(const HardwareModels &master) : UDM_OBJECT(master) { }
			static HardwareModels Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static HardwareModels Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			HardwareModels CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			HardwareModels CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareModels> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareModels> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::HardwareModels> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl);}

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			static ::Uml::CompositionChildRole meta_HardwareSheet_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet> HardwareSheet_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet>(impl, meta_HardwareSheet_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred> HardwareSheet_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred>(impl, meta_HardwareSheet_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet> HardwareSheet_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred> HardwareSheet_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_RootFolder_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLPARENTROLE); }
		};

		class  MgaObject :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			MgaObject() { }
			MgaObject(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			MgaObject(const MgaObject &master) : UDM_OBJECT(master) { }
			static MgaObject Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static MgaObject Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			MgaObject CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			MgaObject CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::MgaObject> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::MgaObject>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::MgaObject> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::MgaObject>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::MgaObject> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::MgaObject>(impl);}

			static ::Uml::Attribute meta_position;
			Udm::StringAttr position() const { return Udm::StringAttr(impl, meta_position); }

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			Udm::ParentAttr<Udm::Object> parent() const { return Udm::ParentAttr<Udm::Object>(impl, Udm::NULLPARENTROLE); }
		};

		class  RTCOut :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			RTCOut() { }
			RTCOut(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			RTCOut(const RTCOut &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static RTCOut Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static RTCOut Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			RTCOut CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			RTCOut CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCOut> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCOut>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCOut, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCOut, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCOut> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCOut>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCOut, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCOut, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RTCOut> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RTCOut>(impl);}

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstRTCOut_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::RTConstraint> dstRTCOut_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl, meta_dstRTCOut_end_); }

			static ::Uml::AssociationRole meta_srcRTCOut_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CInPort> srcRTCOut_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CInPort>(impl, meta_srcRTCOut_end_); }

		};

		class  RTConstraint :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			RTConstraint() { }
			RTConstraint(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			RTConstraint(const RTConstraint &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static RTConstraint Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static RTConstraint Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			RTConstraint CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			RTConstraint CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTConstraint> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTConstraint> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RTConstraint> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl);}

			static ::Uml::Attribute meta_Latency;
			Udm::IntegerAttr Latency() const { return Udm::IntegerAttr(impl, meta_Latency); }

			static ::Uml::AssociationRole meta_srcRTCOut;
			static ::Uml::AssociationRole meta_srcRTCOut_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::CInPort> srcRTCOut() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::CInPort>(impl, meta_srcRTCOut, meta_srcRTCOut_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::CInPort, Pred> srcRTCOut_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::CInPort, Pred>(impl, meta_srcRTCOut, meta_srcRTCOut_rev); }

			static ::Uml::AssociationRole meta_dstRTCIn;
			static ::Uml::AssociationRole meta_dstRTCIn_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::COutPort> dstRTCIn() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::COutPort>(impl, meta_dstRTCIn, meta_dstRTCIn_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::COutPort, Pred> dstRTCIn_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::COutPort, Pred>(impl, meta_dstRTCIn, meta_dstRTCIn_rev); }

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  RTCIn :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			RTCIn() { }
			RTCIn(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			RTCIn(const RTCIn &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static RTCIn Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static RTCIn Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			RTCIn CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			RTCIn CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCIn> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCIn>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCIn, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RTCIn, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCIn> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCIn>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCIn, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RTCIn, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RTCIn> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RTCIn>(impl);}

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_srcRTCIn_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::RTConstraint> srcRTCIn_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl, meta_srcRTCIn_end_); }

			static ::Uml::AssociationRole meta_dstRTCIn_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::COutPort> dstRTCIn_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::COutPort>(impl, meta_dstRTCIn_end_); }

		};

		class  SystemRef :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			SystemRef() { }
			SystemRef(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			SystemRef(const SystemRef &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static SystemRef Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static SystemRef Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			SystemRef CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			SystemRef CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::SystemRef> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::SystemRef>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::SystemRef, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::SystemRef, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::SystemRef> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::SystemRef>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::SystemRef, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::SystemRef, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::SystemRef> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::SystemRef>(impl);}

			static ::Uml::AssociationRole meta_ref;
			Udm::PointerAttr< ::ECSL_DP__6_20_07::System> ref() const { return Udm::PointerAttr< ::ECSL_DP__6_20_07::System>(impl, meta_ref); }

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  InPortMapping :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			InPortMapping() { }
			InPortMapping(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			InPortMapping(const InPortMapping &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static InPortMapping Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static InPortMapping Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			InPortMapping CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			InPortMapping CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InPortMapping> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InPortMapping>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::InPortMapping> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::InPortMapping>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::InPortMapping> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::InPortMapping>(impl);}

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstInPortMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::InputPort> dstInPortMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::InputPort>(impl, meta_dstInPortMapping_end_); }

			static ::Uml::AssociationRole meta_srcInPortMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CInPort> srcInPortMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CInPort>(impl, meta_srcInPortMapping_end_); }

		};

		class  ComponentShortcut :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			ComponentShortcut() { }
			ComponentShortcut(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			ComponentShortcut(const ComponentShortcut &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static ComponentShortcut Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static ComponentShortcut Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			ComponentShortcut CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			ComponentShortcut CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentShortcut> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentShortcut>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentShortcut> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentShortcut>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentShortcut> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentShortcut>(impl);}

			static ::Uml::AssociationRole meta_ref;
			Udm::PointerAttr< ::ECSL_DP__6_20_07::Component> ref() const { return Udm::PointerAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_ref); }

			static ::Uml::CompositionParentRole meta_ComponentSheet_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentSheet> ComponentSheet_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl, meta_ComponentSheet_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  ComponentSheet :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			ComponentSheet() { }
			ComponentSheet(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			ComponentSheet(const ComponentSheet &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static ComponentSheet Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static ComponentSheet Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			ComponentSheet CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			ComponentSheet CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentSheet> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentSheet> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentSheet, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentSheet> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl);}

			static ::Uml::CompositionChildRole meta_Component_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component> Component_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component, Pred> Component_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component, Pred>(impl, meta_Component_children); }

			static ::Uml::CompositionChildRole meta_ComponentShortcut_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut> ComponentShortcut_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut>(impl, meta_ComponentShortcut_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred> ComponentShortcut_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred>(impl, meta_ComponentShortcut_children); }

			static ::Uml::CompositionChildRole meta_Signal_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal> Signal_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal>(impl, meta_Signal_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal, Pred> Signal_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal, Pred>(impl, meta_Signal_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut> ComponentShortcut_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred> ComponentShortcut_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal> Signal_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal, Pred> Signal_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Signal, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component> Component_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component, Pred> Component_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Component, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_ComponentModels_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentModels> ComponentModels_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl, meta_ComponentModels_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentModels> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl, Udm::NULLPARENTROLE); }
		};

		class  Signal :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Signal() { }
			Signal(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Signal(const Signal &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Signal Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Signal Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Signal CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Signal CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Signal> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Signal>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Signal, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Signal, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Signal> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Signal>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Signal, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Signal, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Signal> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Signal>(impl);}

			static ::Uml::CompositionParentRole meta_ComponentSheet_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentSheet> ComponentSheet_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl, meta_ComponentSheet_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstSignal_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CInPort> dstSignal_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CInPort>(impl, meta_dstSignal_end_); }

			static ::Uml::AssociationRole meta_srcSignal_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::COutPort> srcSignal_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::COutPort>(impl, meta_srcSignal_end_); }

		};

		class  OutPortMapping :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			OutPortMapping() { }
			OutPortMapping(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			OutPortMapping(const OutPortMapping &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static OutPortMapping Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static OutPortMapping Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			OutPortMapping CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			OutPortMapping CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutPortMapping> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutPortMapping>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutPortMapping> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutPortMapping>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OutPortMapping> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OutPortMapping>(impl);}

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstOutPortMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::COutPort> dstOutPortMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::COutPort>(impl, meta_dstOutPortMapping_end_); }

			static ::Uml::AssociationRole meta_srcOutPortMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::OutputPort> srcOutPortMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::OutputPort>(impl, meta_srcOutPortMapping_end_); }

		};

		class  CPort :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			CPort() { }
			CPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			CPort(const CPort &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static CPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static CPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			CPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			CPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::CPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::CPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CPort>(impl);}

			static ::Uml::Attribute meta_Min;
			Udm::IntegerAttr Min() const { return Udm::IntegerAttr(impl, meta_Min); }

			static ::Uml::Attribute meta_Max;
			Udm::IntegerAttr Max() const { return Udm::IntegerAttr(impl, meta_Max); }

			static ::Uml::Attribute meta_CName;
			Udm::StringAttr CName() const { return Udm::StringAttr(impl, meta_CName); }

			static ::Uml::Attribute meta_DataOffset;
			Udm::RealAttr DataOffset() const { return Udm::RealAttr(impl, meta_DataOffset); }

			static ::Uml::Attribute meta_DataScale;
			Udm::RealAttr DataScale() const { return Udm::RealAttr(impl, meta_DataScale); }

			static ::Uml::Attribute meta_DataInit;
			Udm::StringAttr DataInit() const { return Udm::StringAttr(impl, meta_DataInit); }

			static ::Uml::Attribute meta_DataSign;
			Udm::BooleanAttr DataSign() const { return Udm::BooleanAttr(impl, meta_DataSign); }

			static ::Uml::Attribute meta_DataSize;
			Udm::StringAttr DataSize() const { return Udm::StringAttr(impl, meta_DataSize); }

			static ::Uml::Attribute meta_DataType;
			Udm::StringAttr DataType() const { return Udm::StringAttr(impl, meta_DataType); }

			static ::Uml::AssociationRole meta_srcInCommMapping;
			static ::Uml::AssociationRole meta_srcInCommMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CommDst> srcInCommMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CommDst>(impl, meta_srcInCommMapping, meta_srcInCommMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CommDst, Pred> srcInCommMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CommDst, Pred>(impl, meta_srcInCommMapping, meta_srcInCommMapping_rev); }

			static ::Uml::AssociationRole meta_dstOutCommMapping;
			static ::Uml::AssociationRole meta_dstOutCommMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CommDst> dstOutCommMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CommDst>(impl, meta_dstOutCommMapping, meta_dstOutCommMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CommDst, Pred> dstOutCommMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CommDst, Pred>(impl, meta_dstOutCommMapping, meta_dstOutCommMapping_rev); }

			static ::Uml::CompositionParentRole meta_Component_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Component> Component_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_Component_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  COutPort :  public ::ECSL_DP__6_20_07::CPort {
		public:
			static ::Uml::Class meta;

			COutPort() { }
			COutPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CPort(impl) { }
			COutPort(const COutPort &master) : ::ECSL_DP__6_20_07::CPort(master) { }
			static COutPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static COutPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			COutPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			COutPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COutPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COutPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COutPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COutPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::COutPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::COutPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::COutPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::COutPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::COutPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::COutPort>(impl);}

			static ::Uml::AssociationRole meta_srcRTCIn;
			static ::Uml::AssociationRole meta_srcRTCIn_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::RTConstraint> srcRTCIn() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::RTConstraint>(impl, meta_srcRTCIn, meta_srcRTCIn_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::RTConstraint, Pred> srcRTCIn_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCIn, ::ECSL_DP__6_20_07::RTConstraint, Pred>(impl, meta_srcRTCIn, meta_srcRTCIn_rev); }

			static ::Uml::AssociationRole meta_dstSignal;
			static ::Uml::AssociationRole meta_dstSignal_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::CInPort> dstSignal() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::CInPort>(impl, meta_dstSignal, meta_dstSignal_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::CInPort, Pred> dstSignal_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::CInPort, Pred>(impl, meta_dstSignal, meta_dstSignal_rev); }

			static ::Uml::AssociationRole meta_srcOutPortMapping;
			static ::Uml::AssociationRole meta_srcOutPortMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::OutputPort> srcOutPortMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::OutputPort>(impl, meta_srcOutPortMapping, meta_srcOutPortMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::OutputPort, Pred> srcOutPortMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::OutputPort, Pred>(impl, meta_srcOutPortMapping, meta_srcOutPortMapping_rev); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  CInPort :  public ::ECSL_DP__6_20_07::CPort {
		public:
			static ::Uml::Class meta;

			CInPort() { }
			CInPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CPort(impl) { }
			CInPort(const CInPort &master) : ::ECSL_DP__6_20_07::CPort(master) { }
			static CInPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static CInPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			CInPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			CInPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CInPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CInPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CInPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CInPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::CInPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CInPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::CInPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CInPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CInPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CInPort>(impl);}

			static ::Uml::AssociationRole meta_dstRTCOut;
			static ::Uml::AssociationRole meta_dstRTCOut_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::RTConstraint> dstRTCOut() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::RTConstraint>(impl, meta_dstRTCOut, meta_dstRTCOut_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::RTConstraint, Pred> dstRTCOut_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::RTCOut, ::ECSL_DP__6_20_07::RTConstraint, Pred>(impl, meta_dstRTCOut, meta_dstRTCOut_rev); }

			static ::Uml::AssociationRole meta_dstInPortMapping;
			static ::Uml::AssociationRole meta_dstInPortMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::InputPort> dstInPortMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::InputPort>(impl, meta_dstInPortMapping, meta_dstInPortMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::InputPort, Pred> dstInPortMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::InputPort, Pred>(impl, meta_dstInPortMapping, meta_dstInPortMapping_rev); }

			static ::Uml::AssociationRole meta_srcSignal;
			static ::Uml::AssociationRole meta_srcSignal_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::COutPort> srcSignal() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::COutPort>(impl, meta_srcSignal, meta_srcSignal_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::COutPort, Pred> srcSignal_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Signal, ::ECSL_DP__6_20_07::COutPort, Pred>(impl, meta_srcSignal, meta_srcSignal_rev); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Component :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Component() { }
			Component(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Component(const Component &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Component Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Component Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Component CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Component CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Component> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Component>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Component, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Component, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Component> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Component>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Component, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Component, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Component> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Component>(impl);}

			static ::Uml::Attribute meta_WCET;
			Udm::IntegerAttr WCET() const { return Udm::IntegerAttr(impl, meta_WCET); }

			static ::Uml::Attribute meta_CName;
			Udm::StringAttr CName() const { return Udm::StringAttr(impl, meta_CName); }

			static ::Uml::AssociationRole meta_referedbyComponentShortcut;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentShortcut> referedbyComponentShortcut() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentShortcut>(impl, meta_referedbyComponentShortcut); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred > referedbyComponentShortcut_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentShortcut, Pred>(impl, meta_referedbyComponentShortcut); }

			static ::Uml::AssociationRole meta_referedbyComponentRef;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef> referedbyComponentRef() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_referedbyComponentRef); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred > referedbyComponentRef_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl, meta_referedbyComponentRef); }

			static ::Uml::CompositionChildRole meta_CPort_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort> CPort_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort>(impl, meta_CPort_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort, Pred> CPort_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort, Pred>(impl, meta_CPort_children); }

			static ::Uml::CompositionChildRole meta_SystemRef_child;
			Udm::ChildAttr< ::ECSL_DP__6_20_07::SystemRef> SystemRef_child() const { return Udm::ChildAttr< ::ECSL_DP__6_20_07::SystemRef>(impl, meta_SystemRef_child); }

			static ::Uml::CompositionChildRole meta_InPortMapping_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping> InPortMapping_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping>(impl, meta_InPortMapping_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred> InPortMapping_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred>(impl, meta_InPortMapping_children); }

			static ::Uml::CompositionChildRole meta_OutPortMapping_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping> OutPortMapping_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping>(impl, meta_OutPortMapping_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred> OutPortMapping_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred>(impl, meta_OutPortMapping_children); }

			static ::Uml::CompositionChildRole meta_RTConstraint_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint> RTConstraint_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl, meta_RTConstraint_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred> RTConstraint_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred>(impl, meta_RTConstraint_children); }

			static ::Uml::CompositionChildRole meta_RTCIn_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn> RTCIn_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn>(impl, meta_RTCIn_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn, Pred> RTCIn_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn, Pred>(impl, meta_RTCIn_children); }

			static ::Uml::CompositionChildRole meta_RTCOut_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut> RTCOut_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut>(impl, meta_RTCOut_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut, Pred> RTCOut_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut, Pred>(impl, meta_RTCOut_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut> RTCOut_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut, Pred> RTCOut_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCOut, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint> RTConstraint_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred> RTConstraint_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTConstraint, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn> RTCIn_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn, Pred> RTCIn_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RTCIn, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::SystemRef> SystemRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::SystemRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::SystemRef, Pred> SystemRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::SystemRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping> InPortMapping_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred> InPortMapping_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InPortMapping, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COutPort> COutPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COutPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COutPort, Pred> COutPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COutPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CInPort> CInPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CInPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CInPort, Pred> CInPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CInPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping> OutPortMapping_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred> OutPortMapping_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutPortMapping, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort> CPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort, Pred> CPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_ComponentSheet_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentSheet> ComponentSheet_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ComponentSheet>(impl, meta_ComponentSheet_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  COM :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			COM() { }
			COM(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			COM(const COM &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static COM Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static COM Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			COM CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			COM CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COM> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COM>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COM, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::COM, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::COM> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::COM>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::COM, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::COM, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::COM> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::COM>(impl);}

			static ::Uml::Attribute meta_HandleRX;
			Udm::BooleanAttr HandleRX() const { return Udm::BooleanAttr(impl, meta_HandleRX); }

			static ::Uml::Attribute meta_HandleTX;
			Udm::BooleanAttr HandleTX() const { return Udm::BooleanAttr(impl, meta_HandleTX); }

			static ::Uml::Attribute meta_HandleCCL;
			Udm::BooleanAttr HandleCCL() const { return Udm::BooleanAttr(impl, meta_HandleCCL); }

			static ::Uml::Attribute meta_HandleNM;
			Udm::BooleanAttr HandleNM() const { return Udm::BooleanAttr(impl, meta_HandleNM); }

			static ::Uml::Attribute meta_CycleTime;
			Udm::StringAttr CycleTime() const { return Udm::StringAttr(impl, meta_CycleTime); }

			static ::Uml::Attribute meta_GenerateTask;
			Udm::BooleanAttr GenerateTask() const { return Udm::BooleanAttr(impl, meta_GenerateTask); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  FirmwareLink :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			FirmwareLink() { }
			FirmwareLink(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			FirmwareLink(const FirmwareLink &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static FirmwareLink Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static FirmwareLink Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			FirmwareLink CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			FirmwareLink CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareLink> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareLink>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareLink> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareLink>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::FirmwareLink> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::FirmwareLink>(impl);}

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstFirmwareLink_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::Channel> dstFirmwareLink_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::Channel>(impl, meta_dstFirmwareLink_end_); }

			static ::Uml::AssociationRole meta_srcFirmwareLink_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::FirmwareModule> srcFirmwareLink_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::FirmwareModule>(impl, meta_srcFirmwareLink_end_); }

		};

		class  FirmwareModule :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			FirmwareModule() { }
			FirmwareModule(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			FirmwareModule(const FirmwareModule &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static FirmwareModule Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static FirmwareModule Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			FirmwareModule CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			FirmwareModule CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareModule> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareModule>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareModule> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareModule>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::FirmwareModule> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::FirmwareModule>(impl);}

			static ::Uml::Attribute meta_EventPublished;
			Udm::StringAttr EventPublished() const { return Udm::StringAttr(impl, meta_EventPublished); }

			static ::Uml::Attribute meta_WriteAccessor;
			Udm::StringAttr WriteAccessor() const { return Udm::StringAttr(impl, meta_WriteAccessor); }

			static ::Uml::Attribute meta_ReadAccessor;
			Udm::StringAttr ReadAccessor() const { return Udm::StringAttr(impl, meta_ReadAccessor); }

			static ::Uml::Attribute meta_SourceFile;
			Udm::StringAttr SourceFile() const { return Udm::StringAttr(impl, meta_SourceFile); }

			static ::Uml::Attribute meta_ISR;
			Udm::StringAttr ISR() const { return Udm::StringAttr(impl, meta_ISR); }

			static ::Uml::Attribute meta_LibraryFile;
			Udm::StringAttr LibraryFile() const { return Udm::StringAttr(impl, meta_LibraryFile); }

			static ::Uml::Attribute meta_OSBinding;
			Udm::StringAttr OSBinding() const { return Udm::StringAttr(impl, meta_OSBinding); }

			static ::Uml::AssociationRole meta_dstFirmwareLink;
			static ::Uml::AssociationRole meta_dstFirmwareLink_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::Channel> dstFirmwareLink() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::Channel>(impl, meta_dstFirmwareLink, meta_dstFirmwareLink_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::Channel, Pred> dstFirmwareLink_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::Channel, Pred>(impl, meta_dstFirmwareLink, meta_dstFirmwareLink_rev); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  OS :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			OS() { }
			OS(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			OS(const OS &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static OS Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static OS Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			OS CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			OS CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OS> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OS>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OS, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OS, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::OS> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OS>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::OS, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OS, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OS> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OS>(impl);}

			static ::Uml::Attribute meta_Compiler;
			Udm::StringAttr Compiler() const { return Udm::StringAttr(impl, meta_Compiler); }

			static ::Uml::Attribute meta_Conformance;
			Udm::StringAttr Conformance() const { return Udm::StringAttr(impl, meta_Conformance); }

			static ::Uml::Attribute meta_Schedule;
			Udm::StringAttr Schedule() const { return Udm::StringAttr(impl, meta_Schedule); }

			static ::Uml::Attribute meta_TickTime;
			Udm::IntegerAttr TickTime() const { return Udm::IntegerAttr(impl, meta_TickTime); }

			static ::Uml::Attribute meta_Status;
			Udm::StringAttr Status() const { return Udm::StringAttr(impl, meta_Status); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  CommElement :  virtual public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			CommElement() { }
			CommElement(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			CommElement(const CommElement &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static CommElement Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static CommElement Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			CommElement CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			CommElement CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommElement> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommElement>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommElement, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommElement, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommElement> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommElement>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommElement, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommElement, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CommElement> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CommElement>(impl);}

			static ::Uml::AssociationRole meta_srcWire;
			static ::Uml::AssociationRole meta_srcWire_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement> srcWire() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement>(impl, meta_srcWire, meta_srcWire_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement, Pred> srcWire_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement, Pred>(impl, meta_srcWire, meta_srcWire_rev); }

			static ::Uml::AssociationRole meta_dstWire;
			static ::Uml::AssociationRole meta_dstWire_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement> dstWire() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement>(impl, meta_dstWire, meta_dstWire_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement, Pred> dstWire_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Wire, ::ECSL_DP__6_20_07::CommElement, Pred>(impl, meta_dstWire, meta_dstWire_rev); }

			Udm::ParentAttr<Udm::Object> parent() const { return Udm::ParentAttr<Udm::Object>(impl, Udm::NULLPARENTROLE); }
		};

		class  HWElement :  virtual public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			HWElement() { }
			HWElement(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			HWElement(const HWElement &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static HWElement Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static HWElement Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			HWElement CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			HWElement CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HWElement> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HWElement>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HWElement, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HWElement, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::HWElement> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::HWElement>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::HWElement, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::HWElement, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::HWElement> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::HWElement>(impl);}

			static ::Uml::CompositionParentRole meta_HardwareSheet_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::HardwareSheet> HardwareSheet_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::HardwareSheet>(impl, meta_HardwareSheet_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Channel :  virtual public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Channel() { }
			Channel(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Channel(const Channel &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Channel Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Channel Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Channel CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Channel CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Channel> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Channel>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Channel, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Channel, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Channel> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Channel>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Channel, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Channel, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Channel> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Channel>(impl);}

			static ::Uml::Attribute meta_InterruptNum;
			Udm::StringAttr InterruptNum() const { return Udm::StringAttr(impl, meta_InterruptNum); }

			static ::Uml::Attribute meta_CName;
			Udm::StringAttr CName() const { return Udm::StringAttr(impl, meta_CName); }

			static ::Uml::AssociationRole meta_srcFirmwareLink;
			static ::Uml::AssociationRole meta_srcFirmwareLink_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::FirmwareModule> srcFirmwareLink() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::FirmwareModule>(impl, meta_srcFirmwareLink, meta_srcFirmwareLink_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::FirmwareModule, Pred> srcFirmwareLink_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::FirmwareLink, ::ECSL_DP__6_20_07::FirmwareModule, Pred>(impl, meta_srcFirmwareLink, meta_srcFirmwareLink_rev); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  HardwareSheet :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			HardwareSheet() { }
			HardwareSheet(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			HardwareSheet(const HardwareSheet &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static HardwareSheet Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static HardwareSheet Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			HardwareSheet CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			HardwareSheet CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareSheet> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareSheet>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareSheet> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareSheet>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::HardwareSheet, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::HardwareSheet> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::HardwareSheet>(impl);}

			static ::Uml::CompositionChildRole meta_HWElement_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement> HWElement_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement>(impl, meta_HWElement_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement, Pred> HWElement_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement, Pred>(impl, meta_HWElement_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement> HWElement_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement, Pred> HWElement_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HWElement, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Wire> Wire_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Wire>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Wire, Pred> Wire_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Wire, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ECU> ECU_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ECU>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ECU, Pred> ECU_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ECU, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Bus> Bus_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Bus>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Bus, Pred> Bus_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Bus, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_HardwareModels_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::HardwareModels> HardwareModels_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl, meta_HardwareModels_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::HardwareModels> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl, Udm::NULLPARENTROLE); }
		};

		class  Wire :  public ::ECSL_DP__6_20_07::HWElement {
		public:
			static ::Uml::Class meta;

			Wire() { }
			Wire(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::HWElement(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Wire(const Wire &master) : ::ECSL_DP__6_20_07::HWElement(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Wire Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Wire Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Wire CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Wire CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Wire> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Wire>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Wire, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Wire, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Wire> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Wire>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Wire, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Wire, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Wire> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Wire>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstWire_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommElement> dstWire_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommElement>(impl, meta_dstWire_end_); }

			static ::Uml::AssociationRole meta_srcWire_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommElement> srcWire_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommElement>(impl, meta_srcWire_end_); }

		};

		class  BusChan :  public ::ECSL_DP__6_20_07::CommElement, public ::ECSL_DP__6_20_07::Channel {
		public:
			static ::Uml::Class meta;

			BusChan() { }
			BusChan(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CommElement(impl),::ECSL_DP__6_20_07::Channel(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			BusChan(const BusChan &master) : ::ECSL_DP__6_20_07::CommElement(master),::ECSL_DP__6_20_07::Channel(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static BusChan Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static BusChan Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			BusChan CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			BusChan CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusChan> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusChan>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusChan, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusChan, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusChan> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusChan>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusChan, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusChan, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::BusChan> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::BusChan>(impl);}

			static ::Uml::AssociationRole meta_members;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessage> members() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessage>(impl, meta_members); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessage, Pred > members_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessage, Pred>(impl, meta_members); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  ECU :  public ::ECSL_DP__6_20_07::HWElement {
		public:
			static ::Uml::Class meta;

			ECU() { }
			ECU(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::HWElement(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			ECU(const ECU &master) : ::ECSL_DP__6_20_07::HWElement(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static ECU Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static ECU Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			ECU CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			ECU CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ECU> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ECU>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ECU, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ECU, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::ECU> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ECU>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::ECU, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ECU, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ECU> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ECU>(impl);}

			static ::Uml::Attribute meta_Simulator;
			Udm::StringAttr Simulator() const { return Udm::StringAttr(impl, meta_Simulator); }

			static ::Uml::Attribute meta_CName;
			Udm::StringAttr CName() const { return Udm::StringAttr(impl, meta_CName); }

			static ::Uml::Attribute meta_ROM;
			Udm::IntegerAttr ROM() const { return Udm::IntegerAttr(impl, meta_ROM); }

			static ::Uml::Attribute meta_RAM;
			Udm::IntegerAttr RAM() const { return Udm::IntegerAttr(impl, meta_RAM); }

			static ::Uml::Attribute meta_Speed;
			Udm::IntegerAttr Speed() const { return Udm::IntegerAttr(impl, meta_Speed); }

			static ::Uml::Attribute meta_CPU;
			Udm::StringAttr CPU() const { return Udm::StringAttr(impl, meta_CPU); }

			static ::Uml::CompositionChildRole meta_OS_child;
			Udm::ChildAttr< ::ECSL_DP__6_20_07::OS> OS_child() const { return Udm::ChildAttr< ::ECSL_DP__6_20_07::OS>(impl, meta_OS_child); }

			static ::Uml::CompositionChildRole meta_COM_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM> COM_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM>(impl, meta_COM_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM, Pred> COM_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM, Pred>(impl, meta_COM_children); }

			static ::Uml::CompositionChildRole meta_Channel_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel> Channel_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel>(impl, meta_Channel_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel, Pred> Channel_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel, Pred>(impl, meta_Channel_children); }

			static ::Uml::CompositionChildRole meta_FirmwareModule_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule> FirmwareModule_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule>(impl, meta_FirmwareModule_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred> FirmwareModule_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred>(impl, meta_FirmwareModule_children); }

			static ::Uml::CompositionChildRole meta_FirmwareLink_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink> FirmwareLink_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink>(impl, meta_FirmwareLink_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred> FirmwareLink_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred>(impl, meta_FirmwareLink_children); }

			static ::Uml::CompositionChildRole meta_BusMessage_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage> BusMessage_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage>(impl, meta_BusMessage_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage, Pred> BusMessage_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage, Pred>(impl, meta_BusMessage_children); }

			static ::Uml::CompositionChildRole meta_BusMessageRef_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef> BusMessageRef_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef>(impl, meta_BusMessageRef_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred> BusMessageRef_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred>(impl, meta_BusMessageRef_children); }

			static ::Uml::CompositionChildRole meta_ComponentRef_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef> ComponentRef_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_ComponentRef_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred> ComponentRef_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl, meta_ComponentRef_children); }

			static ::Uml::CompositionChildRole meta_Task_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task> Task_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task>(impl, meta_Task_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task, Pred> Task_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task, Pred>(impl, meta_Task_children); }

			static ::Uml::CompositionChildRole meta_CommMapping_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping> CommMapping_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping>(impl, meta_CommMapping_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping, Pred> CommMapping_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping, Pred>(impl, meta_CommMapping_children); }

			static ::Uml::CompositionChildRole meta_Order_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order> Order_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order>(impl, meta_Order_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order, Pred> Order_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order, Pred>(impl, meta_Order_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM> COM_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM, Pred> COM_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::COM, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink> FirmwareLink_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred> FirmwareLink_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareLink, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule> FirmwareModule_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred> FirmwareModule_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::FirmwareModule, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OS> OS_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OS>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OS, Pred> OS_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OS, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel> Channel_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel, Pred> Channel_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Channel, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::IChan> IChan_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::IChan>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::IChan, Pred> IChan_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::IChan, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OChan> OChan_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OChan>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OChan, Pred> OChan_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OChan, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage> BusMessage_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage, Pred> BusMessage_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessage, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef> BusMessageRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred> BusMessageRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusChan> BusChan_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusChan>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusChan, Pred> BusChan_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::BusChan, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutCommMapping> OutCommMapping_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutCommMapping>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutCommMapping, Pred> OutCommMapping_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutCommMapping, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task> Task_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task, Pred> Task_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Task, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef> ComponentRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred> ComponentRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order> Order_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order, Pred> Order_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Order, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommDst> CommDst_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommDst>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommDst, Pred> CommDst_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommDst, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping> CommMapping_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping, Pred> CommMapping_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::CommMapping, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InCommMapping> InCommMapping_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InCommMapping>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InCommMapping, Pred> InCommMapping_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InCommMapping, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Bus :  public ::ECSL_DP__6_20_07::CommElement, public ::ECSL_DP__6_20_07::HWElement {
		public:
			static ::Uml::Class meta;

			Bus() { }
			Bus(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CommElement(impl),::ECSL_DP__6_20_07::HWElement(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Bus(const Bus &master) : ::ECSL_DP__6_20_07::CommElement(master),::ECSL_DP__6_20_07::HWElement(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Bus Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Bus Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Bus CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Bus CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Bus> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Bus>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Bus, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Bus, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Bus> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Bus>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Bus, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Bus, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Bus> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Bus>(impl);}

			static ::Uml::Attribute meta_NM;
			Udm::BooleanAttr NM() const { return Udm::BooleanAttr(impl, meta_NM); }

			static ::Uml::Attribute meta_CName;
			Udm::StringAttr CName() const { return Udm::StringAttr(impl, meta_CName); }

			static ::Uml::Attribute meta_Medium;
			Udm::StringAttr Medium() const { return Udm::StringAttr(impl, meta_Medium); }

			static ::Uml::Attribute meta_FrameSize;
			Udm::IntegerAttr FrameSize() const { return Udm::IntegerAttr(impl, meta_FrameSize); }

			static ::Uml::Attribute meta_BitRate;
			Udm::IntegerAttr BitRate() const { return Udm::IntegerAttr(impl, meta_BitRate); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  TypeBaseRef :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			TypeBaseRef() { }
			TypeBaseRef(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			TypeBaseRef(const TypeBaseRef &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static TypeBaseRef Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TypeBaseRef Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TypeBaseRef CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TypeBaseRef CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBaseRef> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBaseRef> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypeBaseRef> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl);}

			static ::Uml::Attribute meta_MemberIndex;
			Udm::IntegerAttr MemberIndex() const { return Udm::IntegerAttr(impl, meta_MemberIndex); }

			static ::Uml::AssociationRole meta_ref;
			Udm::PointerAttr< ::ECSL_DP__6_20_07::TypeBase> ref() const { return Udm::PointerAttr< ::ECSL_DP__6_20_07::TypeBase>(impl, meta_ref); }

			static ::Uml::CompositionParentRole meta_TypedPort_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::TypedPort> TypedPort_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::TypedPort>(impl, meta_TypedPort_parent); }

			static ::Uml::CompositionParentRole meta_TypeStruct_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::TypeStruct> TypeStruct_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::TypeStruct>(impl, meta_TypeStruct_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Types :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			Types() { }
			Types(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			Types(const Types &master) : UDM_OBJECT(master) { }
			static Types Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Types Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Types CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Types CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Types> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Types>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Types, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Types, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Types> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Types>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Types, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Types, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Types> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Types>(impl);}

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			static ::Uml::CompositionChildRole meta_TypeBase_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase> TypeBase_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase>(impl, meta_TypeBase_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase, Pred> TypeBase_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase, Pred>(impl, meta_TypeBase_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeStruct> TypeStruct_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeStruct>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeStruct, Pred> TypeStruct_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeStruct, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Matrix> Matrix_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Matrix>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Matrix, Pred> Matrix_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Matrix, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase> TypeBase_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase, Pred> TypeBase_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBase, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_RootFolder_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLPARENTROLE); }
		};

		class  TypeBase :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			TypeBase() { }
			TypeBase(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			TypeBase(const TypeBase &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static TypeBase Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TypeBase Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TypeBase CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TypeBase CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBase> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBase>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBase, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeBase, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBase> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBase>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBase, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeBase, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypeBase> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypeBase>(impl);}

			static ::Uml::AssociationRole meta_referedbyTypeStructRef;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::TypeBaseRef> referedbyTypeStructRef() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl, meta_referedbyTypeStructRef); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred > referedbyTypeStructRef_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred>(impl, meta_referedbyTypeStructRef); }

			static ::Uml::CompositionParentRole meta_Types_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Types> Types_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Types>(impl, meta_Types_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::Types> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Types>(impl, Udm::NULLPARENTROLE); }
		};

		class  TypeStruct :  public ::ECSL_DP__6_20_07::TypeBase {
		public:
			static ::Uml::Class meta;

			TypeStruct() { }
			TypeStruct(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TypeBase(impl) { }
			TypeStruct(const TypeStruct &master) : ::ECSL_DP__6_20_07::TypeBase(master) { }
			static TypeStruct Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TypeStruct Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TypeStruct CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TypeStruct CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeStruct> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeStruct>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeStruct, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypeStruct, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeStruct> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeStruct>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeStruct, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypeStruct, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypeStruct> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypeStruct>(impl);}

			static ::Uml::Attribute meta_MemberCount;
			Udm::IntegerAttr MemberCount() const { return Udm::IntegerAttr(impl, meta_MemberCount); }

			static ::Uml::CompositionChildRole meta_TypeBaseRef_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef> TypeBaseRef_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl, meta_TypeBaseRef_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred> TypeBaseRef_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred>(impl, meta_TypeBaseRef_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef> TypeBaseRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred> TypeBaseRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::Types> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Types>(impl, Udm::NULLPARENTROLE); }
		};

		class  Matrix :  public ::ECSL_DP__6_20_07::TypeBase {
		public:
			static ::Uml::Class meta;

			Matrix() { }
			Matrix(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TypeBase(impl) { }
			Matrix(const Matrix &master) : ::ECSL_DP__6_20_07::TypeBase(master) { }
			static Matrix Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Matrix Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Matrix CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Matrix CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Matrix> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Matrix>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Matrix, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Matrix, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Matrix> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Matrix>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Matrix, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Matrix, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Matrix> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Matrix>(impl);}

			static ::Uml::Attribute meta_rows;
			Udm::IntegerAttr rows() const { return Udm::IntegerAttr(impl, meta_rows); }

			static ::Uml::Attribute meta_Type;
			Udm::StringAttr Type() const { return Udm::StringAttr(impl, meta_Type); }

			static ::Uml::Attribute meta_columns;
			Udm::IntegerAttr columns() const { return Udm::IntegerAttr(impl, meta_columns); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::Types> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Types>(impl, Udm::NULLPARENTROLE); }
		};

		class  Block :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Block() { }
			Block(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Block(const Block &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Block Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Block Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Block CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Block CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Block> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Block>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Block, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Block, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Block> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Block>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Block, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Block, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Block> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Block>(impl);}

			static ::Uml::Attribute meta_Tag;
			Udm::StringAttr Tag() const { return Udm::StringAttr(impl, meta_Tag); }

			static ::Uml::Attribute meta_BlockType;
			Udm::StringAttr BlockType() const { return Udm::StringAttr(impl, meta_BlockType); }

			static ::Uml::Attribute meta_Name;
			Udm::StringAttr Name() const { return Udm::StringAttr(impl, meta_Name); }

			static ::Uml::Attribute meta_Description;
			Udm::StringAttr Description() const { return Udm::StringAttr(impl, meta_Description); }

			static ::Uml::Attribute meta_Priority;
			Udm::IntegerAttr Priority() const { return Udm::IntegerAttr(impl, meta_Priority); }

			static ::Uml::Attribute meta_SampleTime;
			Udm::RealAttr SampleTime() const { return Udm::RealAttr(impl, meta_SampleTime); }

			static ::Uml::CompositionChildRole meta_Line;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line> Line() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line>(impl, meta_Line); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line, Pred> Line_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line, Pred>(impl, meta_Line); }

			static ::Uml::CompositionChildRole meta_Parameter;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter> Parameter() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter>(impl, meta_Parameter); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter, Pred> Parameter_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter, Pred>(impl, meta_Parameter); }

			static ::Uml::CompositionChildRole meta_Annotation_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation> Annotation_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation>(impl, meta_Annotation_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation, Pred> Annotation_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation, Pred>(impl, meta_Annotation_children); }

			static ::Uml::CompositionChildRole meta_ConnectorRef_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef> ConnectorRef_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl, meta_ConnectorRef_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred> ConnectorRef_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred>(impl, meta_ConnectorRef_children); }

			static ::Uml::CompositionChildRole meta_Port_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port> Port_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port>(impl, meta_Port_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port, Pred> Port_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port, Pred>(impl, meta_Port_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TriggerPort> TriggerPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TriggerPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TriggerPort, Pred> TriggerPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TriggerPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter> Parameter_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter, Pred> Parameter_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Parameter, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation> Annotation_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation, Pred> Annotation_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Annotation, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line> Line_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line, Pred> Line_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Line, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InputPort> InputPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InputPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InputPort, Pred> InputPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::InputPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::EnablePort> EnablePort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::EnablePort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::EnablePort, Pred> EnablePort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::EnablePort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutputPort> OutputPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutputPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutputPort, Pred> OutputPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::OutputPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port> Port_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port, Pred> Port_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Port, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypedPort> TypedPort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypedPort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypedPort, Pred> TypedPort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypedPort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::StatePort> StatePort_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::StatePort>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::StatePort, Pred> StatePort_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::StatePort, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef> ConnectorRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred> ConnectorRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector> TransConnector_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred> TransConnector_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_System_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::System> System_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::System>(impl, meta_System_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Primitive :  public ::ECSL_DP__6_20_07::Block {
		public:
			static ::Uml::Class meta;

			Primitive() { }
			Primitive(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Block(impl) { }
			Primitive(const Primitive &master) : ::ECSL_DP__6_20_07::Block(master) { }
			static Primitive Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Primitive Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Primitive CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Primitive CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Primitive> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Primitive>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Primitive, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Primitive, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Primitive> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Primitive>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Primitive, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Primitive, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Primitive> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Primitive>(impl);}

			static ::Uml::Attribute meta_Deadline;
			Udm::IntegerAttr Deadline() const { return Udm::IntegerAttr(impl, meta_Deadline); }

			static ::Uml::Attribute meta_ExecutionTime;
			Udm::IntegerAttr ExecutionTime() const { return Udm::IntegerAttr(impl, meta_ExecutionTime); }

			static ::Uml::Attribute meta_Period;
			Udm::IntegerAttr Period() const { return Udm::IntegerAttr(impl, meta_Period); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Parameter :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Parameter() { }
			Parameter(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Parameter(const Parameter &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Parameter Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Parameter Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Parameter CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Parameter CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Parameter> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Parameter>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Parameter, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Parameter, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Parameter> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Parameter>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Parameter, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Parameter, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Parameter> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Parameter>(impl);}

			static ::Uml::Attribute meta_Value;
			Udm::StringAttr Value() const { return Udm::StringAttr(impl, meta_Value); }

			static ::Uml::CompositionParentRole meta_Parameter_Block_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Block> Parameter_Block_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Block>(impl, meta_Parameter_Block_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Reference :  public ::ECSL_DP__6_20_07::Block {
		public:
			static ::Uml::Class meta;

			Reference() { }
			Reference(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Block(impl) { }
			Reference(const Reference &master) : ::ECSL_DP__6_20_07::Block(master) { }
			static Reference Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Reference Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Reference CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Reference CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Reference> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Reference>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Reference, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Reference, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Reference> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Reference>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Reference, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Reference, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Reference> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Reference>(impl);}

			static ::Uml::Attribute meta_SourceBlock;
			Udm::StringAttr SourceBlock() const { return Udm::StringAttr(impl, meta_SourceBlock); }

			static ::Uml::Attribute meta_SourceType;
			Udm::StringAttr SourceType() const { return Udm::StringAttr(impl, meta_SourceType); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Annotation :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Annotation() { }
			Annotation(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Annotation(const Annotation &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Annotation Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Annotation Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Annotation CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Annotation CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Annotation> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Annotation>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Annotation, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Annotation, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Annotation> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Annotation>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Annotation, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Annotation, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Annotation> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Annotation>(impl);}

			static ::Uml::Attribute meta_Text;
			Udm::StringAttr Text() const { return Udm::StringAttr(impl, meta_Text); }

			static ::Uml::CompositionParentRole meta_Block_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Block> Block_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Block>(impl, meta_Block_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Line :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Line() { }
			Line(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Line(const Line &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Line Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Line Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Line CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Line CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Line> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Line>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Line, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Line, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Line> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Line>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Line, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Line, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Line> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Line>(impl);}

			static ::Uml::Attribute meta_Name;
			Udm::StringAttr Name() const { return Udm::StringAttr(impl, meta_Name); }

			static ::Uml::CompositionParentRole meta_Line_Block_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Block> Line_Block_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Block>(impl, meta_Line_Block_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstLine_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::Port> dstLine_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::Port>(impl, meta_dstLine_end_); }

			static ::Uml::AssociationRole meta_srcLine_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::Port> srcLine_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::Port>(impl, meta_srcLine_end_); }

		};

		class  Dataflow :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			Dataflow() { }
			Dataflow(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			Dataflow(const Dataflow &master) : UDM_OBJECT(master) { }
			static Dataflow Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Dataflow Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Dataflow CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Dataflow CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Dataflow> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Dataflow>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Dataflow, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Dataflow, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Dataflow> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Dataflow>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Dataflow, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Dataflow, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Dataflow> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Dataflow>(impl);}

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			static ::Uml::CompositionChildRole meta_System_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System> System_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System>(impl, meta_System_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System, Pred> System_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System, Pred>(impl, meta_System_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block> Block_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block, Pred> Block_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System> System_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System, Pred> System_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_RootFolder_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLPARENTROLE); }
		};

		class  System :  public ::ECSL_DP__6_20_07::Block {
		public:
			static ::Uml::Class meta;

			System() { }
			System(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Block(impl) { }
			System(const System &master) : ::ECSL_DP__6_20_07::Block(master) { }
			static System Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static System Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			System CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			System CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::System> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::System>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::System, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::System, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::System> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::System>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::System, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::System, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::System> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::System>(impl);}

			static ::Uml::AssociationRole meta_referedbySystemRef;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::SystemRef> referedbySystemRef() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::SystemRef>(impl, meta_referedbySystemRef); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::SystemRef, Pred > referedbySystemRef_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::SystemRef, Pred>(impl, meta_referedbySystemRef); }

			static ::Uml::CompositionChildRole meta_Block_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block> Block_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block>(impl, meta_Block_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block, Pred> Block_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block, Pred>(impl, meta_Block_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Primitive> Primitive_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Primitive>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Primitive, Pred> Primitive_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Primitive, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block> Block_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block, Pred> Block_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Block, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Reference> Reference_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Reference>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Reference, Pred> Reference_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Reference, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System> System_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System, Pred> System_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::System, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_Dataflow_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Dataflow> Dataflow_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Dataflow>(impl, meta_Dataflow_parent); }

			Udm::ParentAttr<Udm::Object> parent() const { return Udm::ParentAttr<Udm::Object>(impl, Udm::NULLPARENTROLE); }
		};

		class  Port :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Port() { }
			Port(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Port(const Port &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Port Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Port Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Port CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Port CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Port> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Port>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Port, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Port, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Port> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Port>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Port, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Port, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Port> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Port>(impl);}

			static ::Uml::AssociationRole meta_srcLine;
			static ::Uml::AssociationRole meta_srcLine_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port> srcLine() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port>(impl, meta_srcLine, meta_srcLine_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port, Pred> srcLine_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port, Pred>(impl, meta_srcLine, meta_srcLine_rev); }

			static ::Uml::AssociationRole meta_dstLine;
			static ::Uml::AssociationRole meta_dstLine_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port> dstLine() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port>(impl, meta_dstLine, meta_dstLine_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port, Pred> dstLine_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Line, ::ECSL_DP__6_20_07::Port, Pred>(impl, meta_dstLine, meta_dstLine_rev); }

			static ::Uml::CompositionParentRole meta_Block_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Block> Block_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Block>(impl, meta_Block_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  TriggerPort :  public ::ECSL_DP__6_20_07::Port {
		public:
			static ::Uml::Class meta;

			TriggerPort() { }
			TriggerPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Port(impl) { }
			TriggerPort(const TriggerPort &master) : ::ECSL_DP__6_20_07::Port(master) { }
			static TriggerPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TriggerPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TriggerPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TriggerPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TriggerPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TriggerPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TriggerPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TriggerPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TriggerPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TriggerPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TriggerPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TriggerPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TriggerPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TriggerPort>(impl);}

			static ::Uml::Attribute meta_TriggerType;
			Udm::StringAttr TriggerType() const { return Udm::StringAttr(impl, meta_TriggerType); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  InputPort :  public ::ECSL_DP__6_20_07::Port {
		public:
			static ::Uml::Class meta;

			InputPort() { }
			InputPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Port(impl) { }
			InputPort(const InputPort &master) : ::ECSL_DP__6_20_07::Port(master) { }
			static InputPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static InputPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			InputPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			InputPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InputPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InputPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InputPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InputPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::InputPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::InputPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::InputPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::InputPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::InputPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::InputPort>(impl);}

			static ::Uml::Attribute meta_Number;
			Udm::IntegerAttr Number() const { return Udm::IntegerAttr(impl, meta_Number); }

			static ::Uml::AssociationRole meta_srcInPortMapping;
			static ::Uml::AssociationRole meta_srcInPortMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::CInPort> srcInPortMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::CInPort>(impl, meta_srcInPortMapping, meta_srcInPortMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::CInPort, Pred> srcInPortMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InPortMapping, ::ECSL_DP__6_20_07::CInPort, Pred>(impl, meta_srcInPortMapping, meta_srcInPortMapping_rev); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  EnablePort :  public ::ECSL_DP__6_20_07::Port {
		public:
			static ::Uml::Class meta;

			EnablePort() { }
			EnablePort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Port(impl) { }
			EnablePort(const EnablePort &master) : ::ECSL_DP__6_20_07::Port(master) { }
			static EnablePort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static EnablePort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			EnablePort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			EnablePort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::EnablePort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::EnablePort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::EnablePort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::EnablePort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::EnablePort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::EnablePort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::EnablePort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::EnablePort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::EnablePort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::EnablePort>(impl);}

			static ::Uml::Attribute meta_StatesWhenEnabling;
			Udm::StringAttr StatesWhenEnabling() const { return Udm::StringAttr(impl, meta_StatesWhenEnabling); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  TypedPort :  public ::ECSL_DP__6_20_07::Port {
		public:
			static ::Uml::Class meta;

			TypedPort() { }
			TypedPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Port(impl) { }
			TypedPort(const TypedPort &master) : ::ECSL_DP__6_20_07::Port(master) { }
			static TypedPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TypedPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TypedPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TypedPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypedPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypedPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypedPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TypedPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypedPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypedPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypedPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TypedPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypedPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TypedPort>(impl);}

			static ::Uml::CompositionChildRole meta_TypeBaseRef_child;
			Udm::ChildAttr< ::ECSL_DP__6_20_07::TypeBaseRef> TypeBaseRef_child() const { return Udm::ChildAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl, meta_TypeBaseRef_child); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef> TypeBaseRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred> TypeBaseRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TypeBaseRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  OutputPort :  public ::ECSL_DP__6_20_07::TypedPort {
		public:
			static ::Uml::Class meta;

			OutputPort() { }
			OutputPort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TypedPort(impl) { }
			OutputPort(const OutputPort &master) : ::ECSL_DP__6_20_07::TypedPort(master) { }
			static OutputPort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static OutputPort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			OutputPort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			OutputPort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutputPort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutputPort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutputPort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutputPort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutputPort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutputPort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutputPort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutputPort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OutputPort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OutputPort>(impl);}

			static ::Uml::Attribute meta_Number;
			Udm::IntegerAttr Number() const { return Udm::IntegerAttr(impl, meta_Number); }

			static ::Uml::AssociationRole meta_dstOutPortMapping;
			static ::Uml::AssociationRole meta_dstOutPortMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::COutPort> dstOutPortMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::COutPort>(impl, meta_dstOutPortMapping, meta_dstOutPortMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::COutPort, Pred> dstOutPortMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutPortMapping, ::ECSL_DP__6_20_07::COutPort, Pred>(impl, meta_dstOutPortMapping, meta_dstOutPortMapping_rev); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  StatePort :  public ::ECSL_DP__6_20_07::TypedPort {
		public:
			static ::Uml::Class meta;

			StatePort() { }
			StatePort(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TypedPort(impl) { }
			StatePort(const StatePort &master) : ::ECSL_DP__6_20_07::TypedPort(master) { }
			static StatePort Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static StatePort Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			StatePort CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			StatePort CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::StatePort> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::StatePort>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::StatePort, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::StatePort, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::StatePort> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::StatePort>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::StatePort, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::StatePort, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::StatePort> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::StatePort>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Task :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Task() { }
			Task(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Task(const Task &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Task Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Task Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Task CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Task CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Task> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Task>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Task, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Task, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Task> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Task>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Task, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Task, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Task> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Task>(impl);}

			static ::Uml::Attribute meta_CycleTime;
			Udm::IntegerAttr CycleTime() const { return Udm::IntegerAttr(impl, meta_CycleTime); }

			static ::Uml::Attribute meta_Activation;
			Udm::IntegerAttr Activation() const { return Udm::IntegerAttr(impl, meta_Activation); }

			static ::Uml::Attribute meta_Cyclic;
			Udm::BooleanAttr Cyclic() const { return Udm::BooleanAttr(impl, meta_Cyclic); }

			static ::Uml::Attribute meta_Type;
			Udm::StringAttr Type() const { return Udm::StringAttr(impl, meta_Type); }

			static ::Uml::Attribute meta_Preemption;
			Udm::StringAttr Preemption() const { return Udm::StringAttr(impl, meta_Preemption); }

			static ::Uml::Attribute meta_Comment;
			Udm::StringAttr Comment() const { return Udm::StringAttr(impl, meta_Comment); }

			static ::Uml::Attribute meta_AutoStart;
			Udm::BooleanAttr AutoStart() const { return Udm::BooleanAttr(impl, meta_AutoStart); }

			static ::Uml::Attribute meta_Priority;
			Udm::IntegerAttr Priority() const { return Udm::IntegerAttr(impl, meta_Priority); }

			static ::Uml::AssociationRole meta_members;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef> members() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_members); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred > members_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl, meta_members); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  ComponentRef :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			ComponentRef() { }
			ComponentRef(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			ComponentRef(const ComponentRef &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static ComponentRef Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static ComponentRef Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			ComponentRef CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			ComponentRef CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentRef> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentRef> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentRef> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl);}

			static ::Uml::AssociationRole meta_ref;
			Udm::PointerAttr< ::ECSL_DP__6_20_07::Component> ref() const { return Udm::PointerAttr< ::ECSL_DP__6_20_07::Component>(impl, meta_ref); }

			static ::Uml::AssociationRole meta_setTask;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::Task> setTask() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::Task>(impl, meta_setTask); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::Task, Pred > setTask_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::Task, Pred>(impl, meta_setTask); }

			static ::Uml::AssociationRole meta_srcOrder;
			static ::Uml::AssociationRole meta_srcOrder_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef> srcOrder() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_srcOrder, meta_srcOrder_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef, Pred> srcOrder_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl, meta_srcOrder, meta_srcOrder_rev); }

			static ::Uml::AssociationRole meta_dstOrder;
			static ::Uml::AssociationRole meta_dstOrder_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef> dstOrder() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_dstOrder, meta_dstOrder_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef, Pred> dstOrder_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Order, ::ECSL_DP__6_20_07::ComponentRef, Pred>(impl, meta_dstOrder, meta_dstOrder_rev); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Order :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Order() { }
			Order(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Order(const Order &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Order Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Order Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Order CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Order CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Order> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Order>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Order, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Order, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Order> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Order>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Order, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Order, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Order> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Order>(impl);}

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstOrder_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::ComponentRef> dstOrder_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_dstOrder_end_); }

			static ::Uml::AssociationRole meta_srcOrder_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::ComponentRef> srcOrder_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::ComponentRef>(impl, meta_srcOrder_end_); }

		};

		class  CommDst :  virtual public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			CommDst() { }
			CommDst(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			CommDst(const CommDst &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static CommDst Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static CommDst Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			CommDst CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			CommDst CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommDst> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommDst>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommDst, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommDst, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommDst> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommDst>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommDst, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommDst, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CommDst> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CommDst>(impl);}

			static ::Uml::AssociationRole meta_dstInCommMapping;
			static ::Uml::AssociationRole meta_dstInCommMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CPort> dstInCommMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CPort>(impl, meta_dstInCommMapping, meta_dstInCommMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CPort, Pred> dstInCommMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::InCommMapping, ::ECSL_DP__6_20_07::CPort, Pred>(impl, meta_dstInCommMapping, meta_dstInCommMapping_rev); }

			static ::Uml::AssociationRole meta_srcOutCommMapping;
			static ::Uml::AssociationRole meta_srcOutCommMapping_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CPort> srcOutCommMapping() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CPort>(impl, meta_srcOutCommMapping, meta_srcOutCommMapping_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CPort, Pred> srcOutCommMapping_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::OutCommMapping, ::ECSL_DP__6_20_07::CPort, Pred>(impl, meta_srcOutCommMapping, meta_srcOutCommMapping_rev); }

			Udm::ParentAttr<Udm::Object> parent() const { return Udm::ParentAttr<Udm::Object>(impl, Udm::NULLPARENTROLE); }
		};

		class  IChan :  public ::ECSL_DP__6_20_07::Channel, public ::ECSL_DP__6_20_07::CommDst {
		public:
			static ::Uml::Class meta;

			IChan() { }
			IChan(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Channel(impl),::ECSL_DP__6_20_07::CommDst(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			IChan(const IChan &master) : ::ECSL_DP__6_20_07::Channel(master),::ECSL_DP__6_20_07::CommDst(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static IChan Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static IChan Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			IChan CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			IChan CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::IChan> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::IChan>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::IChan, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::IChan, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::IChan> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::IChan>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::IChan, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::IChan, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::IChan> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::IChan>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  OChan :  public ::ECSL_DP__6_20_07::Channel, public ::ECSL_DP__6_20_07::CommDst {
		public:
			static ::Uml::Class meta;

			OChan() { }
			OChan(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::Channel(impl),::ECSL_DP__6_20_07::CommDst(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			OChan(const OChan &master) : ::ECSL_DP__6_20_07::Channel(master),::ECSL_DP__6_20_07::CommDst(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static OChan Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static OChan Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			OChan CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			OChan CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OChan> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OChan>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OChan, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OChan, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::OChan> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OChan>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::OChan, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OChan, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OChan> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OChan>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  BusMessage :  public ::ECSL_DP__6_20_07::CommDst {
		public:
			static ::Uml::Class meta;

			BusMessage() { }
			BusMessage(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CommDst(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			BusMessage(const BusMessage &master) : ::ECSL_DP__6_20_07::CommDst(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static BusMessage Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static BusMessage Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			BusMessage CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			BusMessage CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessage> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessage>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessage, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessage, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessage> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessage>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessage, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessage, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::BusMessage> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::BusMessage>(impl);}

			static ::Uml::Attribute meta_CycleTime;
			Udm::IntegerAttr CycleTime() const { return Udm::IntegerAttr(impl, meta_CycleTime); }

			static ::Uml::Attribute meta_CName;
			Udm::StringAttr CName() const { return Udm::StringAttr(impl, meta_CName); }

			static ::Uml::Attribute meta_SendType;
			Udm::StringAttr SendType() const { return Udm::StringAttr(impl, meta_SendType); }

			static ::Uml::Attribute meta_Size;
			Udm::StringAttr Size() const { return Udm::StringAttr(impl, meta_Size); }

			static ::Uml::Attribute meta_ID;
			Udm::StringAttr ID() const { return Udm::StringAttr(impl, meta_ID); }

			static ::Uml::AssociationRole meta_referedbyBusMessageRef;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessageRef> referedbyBusMessageRef() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessageRef>(impl, meta_referedbyBusMessageRef); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred > referedbyBusMessageRef_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred>(impl, meta_referedbyBusMessageRef); }

			static ::Uml::AssociationRole meta_setBusChan;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::BusChan> setBusChan() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::BusChan>(impl, meta_setBusChan); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::BusChan, Pred > setBusChan_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::BusChan, Pred>(impl, meta_setBusChan); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  BusMessageRef :  public ::ECSL_DP__6_20_07::CommDst {
		public:
			static ::Uml::Class meta;

			BusMessageRef() { }
			BusMessageRef(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CommDst(impl), ::ECSL_DP__6_20_07::MgaObject(impl) { }
			BusMessageRef(const BusMessageRef &master) : ::ECSL_DP__6_20_07::CommDst(master), ::ECSL_DP__6_20_07::MgaObject(master) { }
			static BusMessageRef Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static BusMessageRef Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			BusMessageRef CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			BusMessageRef CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessageRef> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessageRef>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessageRef> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessageRef>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::BusMessageRef, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::BusMessageRef> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::BusMessageRef>(impl);}

			static ::Uml::AssociationRole meta_ref;
			Udm::PointerAttr< ::ECSL_DP__6_20_07::BusMessage> ref() const { return Udm::PointerAttr< ::ECSL_DP__6_20_07::BusMessage>(impl, meta_ref); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  CommMapping :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			CommMapping() { }
			CommMapping(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			CommMapping(const CommMapping &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static CommMapping Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static CommMapping Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			CommMapping CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			CommMapping CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommMapping> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommMapping>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommMapping, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::CommMapping, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommMapping> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommMapping>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommMapping, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::CommMapping, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CommMapping> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::CommMapping>(impl);}

			static ::Uml::Attribute meta_StartBit;
			Udm::StringAttr StartBit() const { return Udm::StringAttr(impl, meta_StartBit); }

			static ::Uml::Attribute meta_NumBits;
			Udm::StringAttr NumBits() const { return Udm::StringAttr(impl, meta_NumBits); }

			static ::Uml::CompositionParentRole meta_ECU_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU> ECU_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::ECU>(impl, meta_ECU_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  OutCommMapping :  public ::ECSL_DP__6_20_07::CommMapping {
		public:
			static ::Uml::Class meta;

			OutCommMapping() { }
			OutCommMapping(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CommMapping(impl) { }
			OutCommMapping(const OutCommMapping &master) : ::ECSL_DP__6_20_07::CommMapping(master) { }
			static OutCommMapping Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static OutCommMapping Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			OutCommMapping CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			OutCommMapping CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutCommMapping> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutCommMapping>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutCommMapping, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::OutCommMapping, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutCommMapping> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutCommMapping>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutCommMapping, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::OutCommMapping, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OutCommMapping> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::OutCommMapping>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_srcOutCommMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CPort> srcOutCommMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CPort>(impl, meta_srcOutCommMapping_end_); }

			static ::Uml::AssociationRole meta_dstOutCommMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommDst> dstOutCommMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommDst>(impl, meta_dstOutCommMapping_end_); }

		};

		class  InCommMapping :  public ::ECSL_DP__6_20_07::CommMapping {
		public:
			static ::Uml::Class meta;

			InCommMapping() { }
			InCommMapping(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::CommMapping(impl) { }
			InCommMapping(const InCommMapping &master) : ::ECSL_DP__6_20_07::CommMapping(master) { }
			static InCommMapping Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static InCommMapping Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			InCommMapping CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			InCommMapping CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InCommMapping> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InCommMapping>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InCommMapping, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::InCommMapping, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::InCommMapping> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::InCommMapping>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::InCommMapping, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::InCommMapping, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::InCommMapping> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::InCommMapping>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_dstInCommMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CPort> dstInCommMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CPort>(impl, meta_dstInCommMapping_end_); }

			static ::Uml::AssociationRole meta_srcInCommMapping_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommDst> srcInCommMapping_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::CommDst>(impl, meta_srcInCommMapping_end_); }

		};

		class  RootFolder :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			RootFolder() { }
			RootFolder(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			RootFolder(const RootFolder &master) : UDM_OBJECT(master) { }
			static RootFolder Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static RootFolder Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			RootFolder CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			RootFolder CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RootFolder> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RootFolder>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RootFolder, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::RootFolder, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::RootFolder> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RootFolder>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::RootFolder, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::RootFolder, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RootFolder> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::RootFolder>(impl);}

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			static ::Uml::CompositionChildRole meta_ComponentModels_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels> ComponentModels_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl, meta_ComponentModels_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred> ComponentModels_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred>(impl, meta_ComponentModels_children); }

			static ::Uml::CompositionChildRole meta_HardwareModels_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels> HardwareModels_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl, meta_HardwareModels_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred> HardwareModels_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred>(impl, meta_HardwareModels_children); }

			static ::Uml::CompositionChildRole meta_Types_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types> Types_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types>(impl, meta_Types_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types, Pred> Types_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types, Pred>(impl, meta_Types_children); }

			static ::Uml::CompositionChildRole meta_Dataflow_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow> Dataflow_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow>(impl, meta_Dataflow_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow, Pred> Dataflow_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow, Pred>(impl, meta_Dataflow_children); }

			static ::Uml::CompositionChildRole meta_Stateflow_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow> Stateflow_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow>(impl, meta_Stateflow_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow, Pred> Stateflow_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow, Pred>(impl, meta_Stateflow_children); }

			static ::Uml::CompositionChildRole meta_RootFolder_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder, Pred> RootFolder_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder, Pred>(impl, meta_RootFolder_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels> ComponentModels_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred> ComponentModels_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ComponentModels, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels> HardwareModels_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred> HardwareModels_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::HardwareModels, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types> Types_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types, Pred> Types_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Types, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow> Dataflow_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow, Pred> Dataflow_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Dataflow, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder, Pred> RootFolder_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::RootFolder, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow> Stateflow_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow, Pred> Stateflow_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Stateflow, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_RootFolder_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLPARENTROLE); }
		};

		class  Transition :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Transition() { }
			Transition(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Transition(const Transition &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Transition Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Transition Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Transition CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Transition CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Transition> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Transition>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Transition, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Transition, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Transition> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Transition>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Transition, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Transition, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Transition> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Transition>(impl);}

			static ::Uml::Attribute meta_Guard;
			Udm::StringAttr Guard() const { return Udm::StringAttr(impl, meta_Guard); }

			static ::Uml::Attribute meta_Trigger;
			Udm::StringAttr Trigger() const { return Udm::StringAttr(impl, meta_Trigger); }

			static ::Uml::Attribute meta_Action;
			Udm::StringAttr Action() const { return Udm::StringAttr(impl, meta_Action); }

			static ::Uml::Attribute meta_ConditionAction;
			Udm::StringAttr ConditionAction() const { return Udm::StringAttr(impl, meta_ConditionAction); }

			static ::Uml::Attribute meta_Order;
			Udm::StringAttr Order() const { return Udm::StringAttr(impl, meta_Order); }

			static ::Uml::CompositionParentRole meta_Transition_State_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::State> Transition_State_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::State>(impl, meta_Transition_State_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
			static ::Uml::AssociationRole meta_srcTransition_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::TransConnector> srcTransition_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, meta_srcTransition_end_); }

			static ::Uml::AssociationRole meta_dstTransition_end_;
			Udm::AssocEndAttr< ::ECSL_DP__6_20_07::TransConnector> dstTransition_end() const { return Udm::AssocEndAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, meta_dstTransition_end_); }

		};

		class  Event :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Event() { }
			Event(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Event(const Event &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Event Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Event Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Event CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Event CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Event> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Event>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Event, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Event, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Event> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Event>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Event, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Event, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Event> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Event>(impl);}

			static ::Uml::Attribute meta_Name;
			Udm::StringAttr Name() const { return Udm::StringAttr(impl, meta_Name); }

			static ::Uml::Attribute meta_Trigger;
			Udm::StringAttr Trigger() const { return Udm::StringAttr(impl, meta_Trigger); }

			static ::Uml::Attribute meta_Scope;
			Udm::StringAttr Scope() const { return Udm::StringAttr(impl, meta_Scope); }

			static ::Uml::Attribute meta_Description;
			Udm::StringAttr Description() const { return Udm::StringAttr(impl, meta_Description); }

			static ::Uml::CompositionParentRole meta_State_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::State> State_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::State>(impl, meta_State_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Stateflow :  public Udm::Object {
		public:
			static ::Uml::Class meta;

			Stateflow() { }
			Stateflow(Udm::ObjectImpl *impl) : UDM_OBJECT(impl) { }
			Stateflow(const Stateflow &master) : UDM_OBJECT(master) { }
			static Stateflow Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Stateflow Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Stateflow CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Stateflow CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Stateflow> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Stateflow>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Stateflow, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Stateflow, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Stateflow> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Stateflow>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Stateflow, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Stateflow, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Stateflow> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Stateflow>(impl);}

			static ::Uml::Attribute meta_name;
			Udm::StringAttr name() const { return Udm::StringAttr(impl, meta_name); }

			static ::Uml::CompositionChildRole meta_State_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State> State_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State>(impl, meta_State_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State, Pred> State_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State, Pred>(impl, meta_State_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State> State_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State, Pred> State_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector> TransConnector_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred> TransConnector_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_RootFolder_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> RootFolder_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, meta_RootFolder_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::RootFolder>(impl, Udm::NULLPARENTROLE); }
		};

		class  Data :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			Data() { }
			Data(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			Data(const Data &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static Data Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Data Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Data CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Data CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Data> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Data>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Data, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Data, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Data> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Data>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Data, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Data, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Data> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Data>(impl);}

			static ::Uml::Attribute meta_ArrayFirstIndex;
			Udm::IntegerAttr ArrayFirstIndex() const { return Udm::IntegerAttr(impl, meta_ArrayFirstIndex); }

			static ::Uml::Attribute meta_ArraySize;
			Udm::IntegerAttr ArraySize() const { return Udm::IntegerAttr(impl, meta_ArraySize); }

			static ::Uml::Attribute meta_InitialValue;
			Udm::StringAttr InitialValue() const { return Udm::StringAttr(impl, meta_InitialValue); }

			static ::Uml::Attribute meta_Min;
			Udm::StringAttr Min() const { return Udm::StringAttr(impl, meta_Min); }

			static ::Uml::Attribute meta_Max;
			Udm::StringAttr Max() const { return Udm::StringAttr(impl, meta_Max); }

			static ::Uml::Attribute meta_Units;
			Udm::StringAttr Units() const { return Udm::StringAttr(impl, meta_Units); }

			static ::Uml::Attribute meta_DataType;
			Udm::StringAttr DataType() const { return Udm::StringAttr(impl, meta_DataType); }

			static ::Uml::Attribute meta_Name;
			Udm::StringAttr Name() const { return Udm::StringAttr(impl, meta_Name); }

			static ::Uml::Attribute meta_Scope;
			Udm::StringAttr Scope() const { return Udm::StringAttr(impl, meta_Scope); }

			static ::Uml::Attribute meta_Description;
			Udm::StringAttr Description() const { return Udm::StringAttr(impl, meta_Description); }

			static ::Uml::Attribute meta_Port;
			Udm::IntegerAttr Port() const { return Udm::IntegerAttr(impl, meta_Port); }

			static ::Uml::CompositionParentRole meta_State_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::State> State_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::State>(impl, meta_State_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  TransConnector :  public ::ECSL_DP__6_20_07::MgaObject {
		public:
			static ::Uml::Class meta;

			TransConnector() { }
			TransConnector(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::MgaObject(impl) { }
			TransConnector(const TransConnector &master) : ::ECSL_DP__6_20_07::MgaObject(master) { }
			static TransConnector Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TransConnector Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TransConnector CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TransConnector CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransConnector> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransConnector>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransConnector, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransConnector, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransConnector> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransConnector>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransConnector, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransConnector, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TransConnector> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TransConnector>(impl);}

			static ::Uml::AssociationRole meta_dstTransition;
			static ::Uml::AssociationRole meta_dstTransition_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector> dstTransition() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector>(impl, meta_dstTransition, meta_dstTransition_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector, Pred> dstTransition_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector, Pred>(impl, meta_dstTransition, meta_dstTransition_rev); }

			static ::Uml::AssociationRole meta_referedbyConnectorRef;
			Udm::AssocAttr< ::ECSL_DP__6_20_07::ConnectorRef> referedbyConnectorRef() const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl, meta_referedbyConnectorRef); }
			template <class Pred> Udm::AssocAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred > referedbyConnectorRef_sorted(const Pred &) const { return Udm::AssocAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred>(impl, meta_referedbyConnectorRef); }

			static ::Uml::AssociationRole meta_srcTransition;
			static ::Uml::AssociationRole meta_srcTransition_rev;
			Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector> srcTransition() const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector>(impl, meta_srcTransition, meta_srcTransition_rev); }
			template<class Pred> Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector, Pred> srcTransition_sorted(const Pred &) const { return Udm::AClassAssocAttr< ::ECSL_DP__6_20_07::Transition, ::ECSL_DP__6_20_07::TransConnector, Pred>(impl, meta_srcTransition, meta_srcTransition_rev); }

			static ::Uml::CompositionParentRole meta_State_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::State> State_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::State>(impl, meta_State_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  State :  public ::ECSL_DP__6_20_07::TransConnector {
		public:
			static ::Uml::Class meta;

			State() { }
			State(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TransConnector(impl) { }
			State(const State &master) : ::ECSL_DP__6_20_07::TransConnector(master) { }
			static State Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static State Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			State CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			State CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::State> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::State>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::State, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::State, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::State> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::State>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::State, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::State, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::State> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::State>(impl);}

			static ::Uml::Attribute meta_Name;
			Udm::StringAttr Name() const { return Udm::StringAttr(impl, meta_Name); }

			static ::Uml::Attribute meta_Decomposition;
			Udm::StringAttr Decomposition() const { return Udm::StringAttr(impl, meta_Decomposition); }

			static ::Uml::Attribute meta_EnterAction;
			Udm::StringAttr EnterAction() const { return Udm::StringAttr(impl, meta_EnterAction); }

			static ::Uml::Attribute meta_DuringAction;
			Udm::StringAttr DuringAction() const { return Udm::StringAttr(impl, meta_DuringAction); }

			static ::Uml::Attribute meta_ExitAction;
			Udm::StringAttr ExitAction() const { return Udm::StringAttr(impl, meta_ExitAction); }

			static ::Uml::Attribute meta_Order;
			Udm::StringAttr Order() const { return Udm::StringAttr(impl, meta_Order); }

			static ::Uml::CompositionChildRole meta_Event_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event> Event_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event>(impl, meta_Event_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event, Pred> Event_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event, Pred>(impl, meta_Event_children); }

			static ::Uml::CompositionChildRole meta_Transition;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition> Transition() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition>(impl, meta_Transition); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition, Pred> Transition_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition, Pred>(impl, meta_Transition); }

			static ::Uml::CompositionChildRole meta_Data_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data> Data_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data>(impl, meta_Data_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data, Pred> Data_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data, Pred>(impl, meta_Data_children); }

			static ::Uml::CompositionChildRole meta_TransConnector_children;
			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector> TransConnector_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, meta_TransConnector_children); }
			template <class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred> TransConnector_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred>(impl, meta_TransConnector_children); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject> MgaObject_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::MgaObject, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State> State_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State, Pred> State_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::State, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition> Transition_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition, Pred> Transition_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Transition, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event> Event_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event, Pred> Event_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Event, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::History> History_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::History>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::History, Pred> History_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::History, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransStart> TransStart_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransStart>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransStart, Pred> TransStart_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransStart, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Junction> Junction_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Junction>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Junction, Pred> Junction_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Junction, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef> ConnectorRef_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred> ConnectorRef_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data> Data_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data, Pred> Data_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::Data, Pred>(impl, Udm::NULLCHILDROLE); }

			Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector> TransConnector_kind_children() const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, Udm::NULLCHILDROLE); }
			template<class Pred> Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred> TransConnector_kind_children_sorted(const Pred &) const { return Udm::ChildrenAttr< ::ECSL_DP__6_20_07::TransConnector, Pred>(impl, Udm::NULLCHILDROLE); }

			static ::Uml::CompositionParentRole meta_Stateflow_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Stateflow> Stateflow_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Stateflow>(impl, meta_Stateflow_parent); }

			Udm::ParentAttr<Udm::Object> parent() const { return Udm::ParentAttr<Udm::Object>(impl, Udm::NULLPARENTROLE); }
		};

		class  History :  public ::ECSL_DP__6_20_07::TransConnector {
		public:
			static ::Uml::Class meta;

			History() { }
			History(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TransConnector(impl) { }
			History(const History &master) : ::ECSL_DP__6_20_07::TransConnector(master) { }
			static History Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static History Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			History CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			History CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::History> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::History>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::History, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::History, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::History> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::History>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::History, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::History, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::History> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::History>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  TransStart :  public ::ECSL_DP__6_20_07::TransConnector {
		public:
			static ::Uml::Class meta;

			TransStart() { }
			TransStart(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TransConnector(impl) { }
			TransStart(const TransStart &master) : ::ECSL_DP__6_20_07::TransConnector(master) { }
			static TransStart Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static TransStart Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			TransStart CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			TransStart CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransStart> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransStart>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransStart, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::TransStart, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransStart> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransStart>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransStart, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::TransStart, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TransStart> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::TransStart>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  Junction :  public ::ECSL_DP__6_20_07::TransConnector {
		public:
			static ::Uml::Class meta;

			Junction() { }
			Junction(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TransConnector(impl) { }
			Junction(const Junction &master) : ::ECSL_DP__6_20_07::TransConnector(master) { }
			static Junction Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static Junction Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			Junction CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			Junction CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Junction> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Junction>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Junction, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::Junction, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::Junction> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Junction>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::Junction, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::Junction, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Junction> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::Junction>(impl);}

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};

		class  ConnectorRef :  public ::ECSL_DP__6_20_07::TransConnector {
		public:
			static ::Uml::Class meta;

			ConnectorRef() { }
			ConnectorRef(Udm::ObjectImpl *impl) : ::ECSL_DP__6_20_07::TransConnector(impl) { }
			ConnectorRef(const ConnectorRef &master) : ::ECSL_DP__6_20_07::TransConnector(master) { }
			static ConnectorRef Cast(const Udm::Object &a) { return __Cast(a, meta); }

			static ConnectorRef Create(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role); }

			ConnectorRef CreateInstance(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl); }

			ConnectorRef CreateDerived(const Udm::Object &parent, const ::Uml::CompositionChildRole &role = Udm::NULLCHILDROLE) { return __Create(meta, parent, role, impl, true); }

			Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ConnectorRef> Instances() { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl);}
			template <class Pred> Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred> Instances_sorted(const Pred &) { return Udm::InstantiatedAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred>(impl);}

			Udm::DerivedAttr< ::ECSL_DP__6_20_07::ConnectorRef> Derived() { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl);}
			template <class Pred> Udm::DerivedAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred> Derived_sorted(const Pred &) { return Udm::DerivedAttr< ::ECSL_DP__6_20_07::ConnectorRef, Pred>(impl);}

			Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ConnectorRef> Archetype() { return Udm::ArchetypeAttr< ::ECSL_DP__6_20_07::ConnectorRef>(impl);}

			static ::Uml::AssociationRole meta_ref;
			Udm::PointerAttr< ::ECSL_DP__6_20_07::TransConnector> ref() const { return Udm::PointerAttr< ::ECSL_DP__6_20_07::TransConnector>(impl, meta_ref); }

			static ::Uml::CompositionParentRole meta_Block_parent;
			Udm::ParentAttr< ::ECSL_DP__6_20_07::Block> Block_parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::Block>(impl, meta_Block_parent); }

			Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject> parent() const { return Udm::ParentAttr< ::ECSL_DP__6_20_07::MgaObject>(impl, Udm::NULLPARENTROLE); }
		};



}

#endif //MOBIES_ECSL_DP__6_20_07_H
