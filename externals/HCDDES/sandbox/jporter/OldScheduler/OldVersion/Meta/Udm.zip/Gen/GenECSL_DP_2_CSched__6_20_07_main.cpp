/* GenECSL_DP_2_CSched__6_20_07_main.cpp generated on Wed Jun 20 15:39:44 2007
 */
#define _SECURE_SCL 0

#include "GenECSL_DP_2_CSched__6_20_07.h"
#include "InputFileRegistry.h"
UDM_USE_DOM
UDM_USE_MGA

// Extern global temporary root object(s).
void usage()
{
	std::cout << "Usage:  TopBlock.exe ECSLFileType=\"Ecsl_Input.mga\"!\"Udm\\\"  CSchedFileType=\"C:\\src\\svn\\HCDDES\\trunk\\Scheduler\\Meta\\CSchedOut.mga\"!\"Udm\\\"  or\n\tTopBlock -d\n\n";
}

int main( int argc, char* argv[])
{
	InputFileRegistry ifr;
	ifr.registerFile( "ECSLFileType=\"C:\\src\\svn\\HCDDES\\trunk\\Scheduler\\Meta\\Ecsl_Input.mga\"!\"Udm\\\" ");
	ifr.registerFile( "CSchedFileType=\"C:\\src\\svn\\HCDDES\\trunk\\Scheduler\\Meta\\CSchedOut.mga\"!\"Udm\\\" ");
	if( argc== 1)
	{
		usage( );
		return -1;
	}
	else
		if( ( argc== 2)&& ( std::string( argv[ 1])== "-d"))
			std::cout << "Executing with default arguments." << std::endl;
		else
			for( int i= 1; i<argc; ++i)
			{
				if( false== ifr.registerFile( argv[ i]))
					throw InputFileEx( std::string( "Invalid input file expression: ") + argv[ i]);
			}
	try
	{
		std::vector< Udm::StaticDataNetworkSpecifier> dnsvec;
		// Open CSchedFileType w
		Udm::SmartDataNetwork sdnCSched__6_20_07_116( CSched__6_20_07::diagram);
		sdnCSched__6_20_07_116.CreateNew( ifr.getFileName( "CSchedFileType"), UseXSD()( ifr.getFileName( "CSchedFileType")) ? ifr.getXsdName( "CSchedFileType") : "CSched__6_20_07", CSched__6_20_07::RootFolder::meta, Udm::CHANGES_LOST_DEFAULT);
		Udm::StaticDataNetworkSpecifier sdns_CSched__6_20_07_117( ifr.getFileName( "CSchedFileType"), &sdnCSched__6_20_07_116);
		dnsvec.push_back( sdns_CSched__6_20_07_117);
		// Open ECSLFileType r
		Udm::SmartDataNetwork sdnECSL_DP__6_20_07_113( ECSL_DP__6_20_07::diagram);
		sdnECSL_DP__6_20_07_113.OpenExisting( ifr.getFileName( "ECSLFileType"), UseXSD()( ifr.getFileName( "ECSLFileType")) ? ifr.getXsdName( "ECSLFileType") : "ECSL_DP__6_20_07", Udm::CHANGES_LOST_DEFAULT);
		Udm::StaticDataNetworkSpecifier sdns_ECSL_DP__6_20_07_114( ifr.getFileName( "ECSLFileType"), &sdnECSL_DP__6_20_07_113);
		dnsvec.push_back( sdns_ECSL_DP__6_20_07_114);
		// Create the project
		Udm::StaticUdmProject prj( dnsvec, ECSL_DP_2_CSched__6_20_07::diagram);
		Udm::DataNetwork& cSched__6_20_07_ref_118= prj.GetDataNetwork( ifr.getFileName( "CSchedFileType"));
		Udm::DataNetwork& eCSL_DP__6_20_07_ref_115= prj.GetDataNetwork( ifr.getFileName( "ECSLFileType"));
		Packets_t cSchedIns_1;
		Packets_t eCSLIns_3;
		// get objects from DNs
		ECSL_DP__6_20_07::RootFolder rootECSL_DP__6_20_07_119= ECSL_DP__6_20_07::RootFolder::Cast( eCSL_DP__6_20_07_ref_115.GetRootObject());
		CSched__6_20_07::RootFolder rootCSched__6_20_07_11a= CSched__6_20_07::RootFolder::Cast( cSched__6_20_07_ref_118.GetRootObject());
		// Add objects to input packets.
		cSchedIns_1.push_back( rootCSched__6_20_07_11a);
		eCSLIns_3.push_back( rootECSL_DP__6_20_07_119);
		// Get access to temporary root object(s).
		// transformation
		TopBlock_0 topBlock_0;
		topBlock_0( cSchedIns_1, eCSLIns_3);
		// Close the project
		prj.Close();
		// Close CSchedFileType w
		sdnCSched__6_20_07_116.CloseWithUpdate();
		// Close ECSLFileType r
		sdnECSL_DP__6_20_07_113.CloseNoUpdate();
	}
	catch( udm_exception &e)
	{
		cout << e.what() << endl;
	}
	return 0;
}

