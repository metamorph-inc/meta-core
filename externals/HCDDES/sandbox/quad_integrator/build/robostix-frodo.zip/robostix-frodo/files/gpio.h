#ifndef _GPIO_H_
#define _GPIO_H_

#include "robostix-frodo.h"

void GPIO_Move(per_entry *pper);
unsigned int GPIO_Init(per_entry *pper);

#endif // _GPIO_H_
