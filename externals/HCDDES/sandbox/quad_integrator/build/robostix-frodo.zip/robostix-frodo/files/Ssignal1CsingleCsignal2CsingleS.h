
#ifndef Ssignal1CsingleCsignal2CsingleS_GUARD
#define Ssignal1CsingleCsignal2CsingleS_GUARD
typedef struct {
  float signal1;
  float signal2;
} Ssignal1CsingleCsignal2CsingleS;
#endif

