#include "RefHandler_sl.h"


/* SIMPLIFIED PROGRAM FUNCTIONS */
void RefHandler_main( RefHandler_100000666_context *context, float pos_ref_in_2, float *pos_ref_out_3 ) {
  RefHandler_100000666_main( context, pos_ref_in_2, pos_ref_out_3 );
}

void RefHandler_init( RefHandler_100000666_context *context ) {
  RefHandler_100000666_init( context );
}

void RefHandler_100000666_main( RefHandler_100000666_context *context, float pos_ref_in_2, float *pos_ref_out_3 )
{
  static float counter = 0.0;

  // Case 1: Sine wave input
  *pos_ref_out_3 = 0.3 * sin( 2.0 * 3.14159265 * (1.0/30.0) * (counter/50.0) );

  // Case 2: +-5.0 square wave at 30Hz - exercises some problematic 
  //    aliasing effects
  /*static int flag = 0;

  if ( flag == 0 && counter < (50.0 * 20.0) )
  { 
    *pos_ref_out_3 = 0.0;
  }
  else if ( flag == 0 )
  {
    flag = 1;
    counter = 0.0;
  }

  if ( (flag == 1) && (counter >= 0.0) && (counter < 749.0) )
  {
    *pos_ref_out_3 = 0.5;
  }

  if ( (flag == 1) && (counter >= 749.0) && (counter < 1499.0) )
  {
    *pos_ref_out_3 = -0.5;
  }

  if ( (flag == 1) && (counter >= 1499.0) )
  {
    counter = 0.0;
  }*/

  // Case 3: Constant signal
  //*pos_ref_out_3 = 3.0;

  // Case 4: Original code ( unity gain from an external signal )
  //*pos_ref_out_3 = ( *context ).Gain130 * pos_ref_in_2;

  // Don't forget to update the counter
  counter += 1.0;
  
}

void RefHandler_100000666_init( RefHandler_100000666_context *context )
{
  ( *context ).Gain130 = 1;
}

