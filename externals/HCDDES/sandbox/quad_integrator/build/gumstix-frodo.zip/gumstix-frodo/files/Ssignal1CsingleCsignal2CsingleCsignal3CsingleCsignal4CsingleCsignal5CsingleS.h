
#ifndef Ssignal1CsingleCsignal2CsingleCsignal3CsingleCsignal4CsingleCsignal5CsingleS_GUARD
#define Ssignal1CsingleCsignal2CsingleCsignal3CsingleCsignal4CsingleCsignal5CsingleS_GUARD
typedef struct {
  float signal1;
  float signal2;
  float signal3;
  float signal4;
  float signal5;
} Ssignal1CsingleCsignal2CsingleCsignal3CsingleCsignal4CsingleCsignal5CsingleS;
#endif

