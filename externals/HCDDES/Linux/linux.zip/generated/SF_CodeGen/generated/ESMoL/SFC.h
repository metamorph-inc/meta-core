#ifndef MOBIES_SFC_H
#define MOBIES_SFC_H

// header file SFC.h generated from diagram SFC
// generated with Udm version 3.31 on Mon Jul 23 16:51:11 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace ESMoL {
	class TypeStruct;
	class Matrix;
	class TypeBase;
	class TypeBaseRef;
	class State;
	class Data;
	class Event;

}

namespace SFC {

	extern ::Uml::Diagram meta;
	class Condition;
	class Arg;
	class Function;
	class SimpleStatement;
	class ConditionalBlock;
	class Return;
	class Program;
	class CompoundStatement;
	class Statement;
	class UserCode;
	class Block;
	class OperationalStatement;
	class ConditionalGroup;
	class IterativeBlock;
	class LocalVar;
	class StateVar;
	class StateLabel;
	class FunctionCall;
	class ArgVal;
	class Var;
	class StateRel;
	class CheckArg;
	class SetState;
	class CheckState;
	class SetVar;
	class Str;
	class Double;
	class Int;
	class BinaryExprs;
	class UnaryExprs;
	class NullaryExprs;
	class Exprs;
	class Declaration;
	class ArgDeclRef;
	class DT;
	class Struct;
	class ArgDeclBase;
	class Class;
	class Project;
	class Array;
	class TypedEntity;
	class BasicType;
	class Comment;

	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

	class Condition :  virtual public ::Udm::Object {
	public:
		Condition();
		Condition(::Udm::ObjectImpl *impl);
		Condition(const Condition &master);

#ifdef UDM_RVALUE
		Condition(Condition &&master);

		static Condition Cast(::Udm::Object &&a);
		Condition& operator=(Condition &&a);

#endif
		static Condition Cast(const ::Udm::Object &a);
		static Condition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Condition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Condition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Condition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Condition, Pred>(impl); };
		Condition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Condition> Derived();
		template <class Pred> ::Udm::DerivedAttr< Condition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Condition, Pred>(impl); };
		::Udm::ArchetypeAttr< Condition> Archetype() const;
		::Udm::ParentAttr< ::SFC::ConditionalBlock> cbPar() const;
		::Udm::ParentAttr< ::SFC::IterativeBlock> ibPar() const;
		::Udm::ParentAttr< ::SFC::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_cbPar;
		static ::Uml::CompositionParentRole meta_ibPar;

	};

	class Statement :  virtual public ::Udm::Object {
	public:
		Statement();
		Statement(::Udm::ObjectImpl *impl);
		Statement(const Statement &master);

#ifdef UDM_RVALUE
		Statement(Statement &&master);

		static Statement Cast(::Udm::Object &&a);
		Statement& operator=(Statement &&a);

#endif
		static Statement Cast(const ::Udm::Object &a);
		static Statement Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Statement CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Statement> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Statement, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Statement, Pred>(impl); };
		Statement CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Statement> Derived();
		template <class Pred> ::Udm::DerivedAttr< Statement, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Statement, Pred>(impl); };
		::Udm::ArchetypeAttr< Statement> Archetype() const;
		::Udm::IntegerAttr statementIndex() const;
		::Udm::StringAttr RefId() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> csPar() const;
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_statementIndex;
		static ::Uml::Attribute meta_RefId;
		static ::Uml::CompositionParentRole meta_csPar;

	};

	class OperationalStatement :  public Statement {
	public:
		OperationalStatement();
		OperationalStatement(::Udm::ObjectImpl *impl);
		OperationalStatement(const OperationalStatement &master);

#ifdef UDM_RVALUE
		OperationalStatement(OperationalStatement &&master);

		static OperationalStatement Cast(::Udm::Object &&a);
		OperationalStatement& operator=(OperationalStatement &&a);

#endif
		static OperationalStatement Cast(const ::Udm::Object &a);
		static OperationalStatement Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OperationalStatement CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OperationalStatement> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OperationalStatement, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OperationalStatement, Pred>(impl); };
		OperationalStatement CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OperationalStatement> Derived();
		template <class Pred> ::Udm::DerivedAttr< OperationalStatement, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OperationalStatement, Pred>(impl); };
		::Udm::ArchetypeAttr< OperationalStatement> Archetype() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;

	};

	class SimpleStatement :  public OperationalStatement {
	public:
		SimpleStatement();
		SimpleStatement(::Udm::ObjectImpl *impl);
		SimpleStatement(const SimpleStatement &master);

#ifdef UDM_RVALUE
		SimpleStatement(SimpleStatement &&master);

		static SimpleStatement Cast(::Udm::Object &&a);
		SimpleStatement& operator=(SimpleStatement &&a);

#endif
		static SimpleStatement Cast(const ::Udm::Object &a);
		static SimpleStatement Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SimpleStatement CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SimpleStatement> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SimpleStatement, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SimpleStatement, Pred>(impl); };
		SimpleStatement CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SimpleStatement> Derived();
		template <class Pred> ::Udm::DerivedAttr< SimpleStatement, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SimpleStatement, Pred>(impl); };
		::Udm::ArchetypeAttr< SimpleStatement> Archetype() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;

	};

	class Return :  public SimpleStatement {
	public:
		Return();
		Return(::Udm::ObjectImpl *impl);
		Return(const Return &master);

#ifdef UDM_RVALUE
		Return(Return &&master);

		static Return Cast(::Udm::Object &&a);
		Return& operator=(Return &&a);

#endif
		static Return Cast(const ::Udm::Object &a);
		static Return Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Return CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Return> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Return, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Return, Pred>(impl); };
		Return CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Return> Derived();
		template <class Pred> ::Udm::DerivedAttr< Return, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Return, Pred>(impl); };
		::Udm::ArchetypeAttr< Return> Archetype() const;
		::Udm::StringAttr val() const;
		::Udm::ChildAttr< ::SFC::Exprs> retexpr() const;
		::Udm::ChildrenAttr< ::SFC::FunctionCall> FunctionCall_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred> FunctionCall_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Str> Str_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Str, Pred> Str_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Str, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Double> Double_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Double, Pred> Double_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Double, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Int> Int_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Int, Pred> Int_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Int, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BinaryExprs> BinaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred> BinaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UnaryExprs> UnaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred> UnaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::NullaryExprs> NullaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred> NullaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Exprs> Exprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Exprs, Pred> Exprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Exprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclRef> ArgDeclRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred> ArgDeclRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_val;
		static ::Uml::CompositionChildRole meta_retexpr;

	};

	class CompoundStatement :  public OperationalStatement {
	public:
		CompoundStatement();
		CompoundStatement(::Udm::ObjectImpl *impl);
		CompoundStatement(const CompoundStatement &master);

#ifdef UDM_RVALUE
		CompoundStatement(CompoundStatement &&master);

		static CompoundStatement Cast(::Udm::Object &&a);
		CompoundStatement& operator=(CompoundStatement &&a);

#endif
		static CompoundStatement Cast(const ::Udm::Object &a);
		static CompoundStatement Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CompoundStatement CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CompoundStatement> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CompoundStatement, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CompoundStatement, Pred>(impl); };
		CompoundStatement CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CompoundStatement> Derived();
		template <class Pred> ::Udm::DerivedAttr< CompoundStatement, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CompoundStatement, Pred>(impl); };
		::Udm::ArchetypeAttr< CompoundStatement> Archetype() const;
		::Udm::IntegerAttr statementCount() const;
		::Udm::CrossPointerAttr< ::ESMoL::State> immChild() const;
		::Udm::CrossPointerAttr< ::ESMoL::State> commPar() const;
		::Udm::ChildrenAttr< ::SFC::Statement> stmnt() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Statement, Pred> stmnt_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Statement, Pred>(impl, meta_stmnt); };
		::Udm::ChildrenAttr< ::SFC::Function> Function_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Function, Pred> Function_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Function, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::SimpleStatement> SimpleStatement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::SimpleStatement, Pred> SimpleStatement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::SimpleStatement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ConditionalBlock> ConditionalBlock_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ConditionalBlock, Pred> ConditionalBlock_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ConditionalBlock, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Return> Return_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Return, Pred> Return_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Return, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Program> Program_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Program, Pred> Program_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Program, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::CompoundStatement> CompoundStatement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::CompoundStatement, Pred> CompoundStatement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::CompoundStatement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Statement> Statement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Statement, Pred> Statement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Statement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UserCode> UserCode_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UserCode, Pred> UserCode_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UserCode, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Block> Block_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Block, Pred> Block_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Block, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::OperationalStatement> OperationalStatement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::OperationalStatement, Pred> OperationalStatement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::OperationalStatement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ConditionalGroup> ConditionalGroup_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ConditionalGroup, Pred> ConditionalGroup_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ConditionalGroup, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::IterativeBlock> IterativeBlock_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::IterativeBlock, Pred> IterativeBlock_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::IterativeBlock, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::LocalVar> LocalVar_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::LocalVar, Pred> LocalVar_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::LocalVar, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::StateVar> StateVar_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::StateVar, Pred> StateVar_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::StateVar, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::StateLabel> StateLabel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::StateLabel, Pred> StateLabel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::StateLabel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::FunctionCall> FunctionCall_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred> FunctionCall_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Var> Var_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Var, Pred> Var_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Var, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::SetState> SetState_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::SetState, Pred> SetState_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::SetState, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::SetVar> SetVar_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::SetVar, Pred> SetVar_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::SetVar, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Declaration> Declaration_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Declaration, Pred> Declaration_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Declaration, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::DT> DT_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::DT, Pred> DT_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::DT, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Struct> Struct_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Struct, Pred> Struct_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Struct, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Class> Class_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Class, Pred> Class_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Class, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Project> Project_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Project, Pred> Project_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Project, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Array> Array_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Array, Pred> Array_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Array, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BasicType> BasicType_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BasicType, Pred> BasicType_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BasicType, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Comment> Comment_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Comment, Pred> Comment_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Comment, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_statementCount;
		static ::Uml::AssociationRole meta_immChild;
		static ::Uml::AssociationRole meta_commPar;
		static ::Uml::CompositionChildRole meta_stmnt;

	};

	class Program :  public CompoundStatement {
	public:
		Program();
		Program(::Udm::ObjectImpl *impl);
		Program(const Program &master);

#ifdef UDM_RVALUE
		Program(Program &&master);

		static Program Cast(::Udm::Object &&a);
		Program& operator=(Program &&a);

#endif
		static Program Cast(const ::Udm::Object &a);
		static Program Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Program CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Program> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Program, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Program, Pred>(impl); };
		Program CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Program> Derived();
		template <class Pred> ::Udm::DerivedAttr< Program, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Program, Pred>(impl); };
		::Udm::ArchetypeAttr< Program> Archetype() const;
		::Udm::StringAttr filename() const;
		::Udm::IntegerAttr stateCount() const;
		::Udm::IntegerAttr numInstance() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_filename;
		static ::Uml::Attribute meta_stateCount;
		static ::Uml::Attribute meta_numInstance;

	};

	class UserCode :  public Condition,  public SimpleStatement {
	public:
		UserCode();
		UserCode(::Udm::ObjectImpl *impl);
		UserCode(const UserCode &master);

#ifdef UDM_RVALUE
		UserCode(UserCode &&master);

		static UserCode Cast(::Udm::Object &&a);
		UserCode& operator=(UserCode &&a);

#endif
		static UserCode Cast(const ::Udm::Object &a);
		static UserCode Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		UserCode CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< UserCode> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< UserCode, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< UserCode, Pred>(impl); };
		UserCode CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< UserCode> Derived();
		template <class Pred> ::Udm::DerivedAttr< UserCode, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< UserCode, Pred>(impl); };
		::Udm::ArchetypeAttr< UserCode> Archetype() const;
		::Udm::StringAttr expr() const;
		::Udm::ChildAttr< ::SFC::Exprs> codeexpr() const;
		::Udm::ChildrenAttr< ::SFC::FunctionCall> FunctionCall_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred> FunctionCall_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Str> Str_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Str, Pred> Str_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Str, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Double> Double_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Double, Pred> Double_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Double, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Int> Int_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Int, Pred> Int_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Int, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BinaryExprs> BinaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred> BinaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UnaryExprs> UnaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred> UnaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::NullaryExprs> NullaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred> NullaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Exprs> Exprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Exprs, Pred> Exprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Exprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclRef> ArgDeclRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred> ArgDeclRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_expr;
		static ::Uml::CompositionChildRole meta_codeexpr;

	};

	class Block :  public CompoundStatement {
	public:
		Block();
		Block(::Udm::ObjectImpl *impl);
		Block(const Block &master);

#ifdef UDM_RVALUE
		Block(Block &&master);

		static Block Cast(::Udm::Object &&a);
		Block& operator=(Block &&a);

#endif
		static Block Cast(const ::Udm::Object &a);
		static Block Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Block CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Block> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Block, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Block, Pred>(impl); };
		Block CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Block> Derived();
		template <class Pred> ::Udm::DerivedAttr< Block, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Block, Pred>(impl); };
		::Udm::ArchetypeAttr< Block> Archetype() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;

	};

	class ConditionalBlock :  public Block {
	public:
		ConditionalBlock();
		ConditionalBlock(::Udm::ObjectImpl *impl);
		ConditionalBlock(const ConditionalBlock &master);

#ifdef UDM_RVALUE
		ConditionalBlock(ConditionalBlock &&master);

		static ConditionalBlock Cast(::Udm::Object &&a);
		ConditionalBlock& operator=(ConditionalBlock &&a);

#endif
		static ConditionalBlock Cast(const ::Udm::Object &a);
		static ConditionalBlock Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ConditionalBlock CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ConditionalBlock> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ConditionalBlock, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ConditionalBlock, Pred>(impl); };
		ConditionalBlock CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ConditionalBlock> Derived();
		template <class Pred> ::Udm::DerivedAttr< ConditionalBlock, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ConditionalBlock, Pred>(impl); };
		::Udm::ArchetypeAttr< ConditionalBlock> Archetype() const;
		::Udm::ChildrenAttr< ::SFC::Condition> cond() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Condition, Pred> cond_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Condition, Pred>(impl, meta_cond); };
		::Udm::ChildrenAttr< ::SFC::Condition> Condition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Condition, Pred> Condition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Condition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UserCode> UserCode_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UserCode, Pred> UserCode_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UserCode, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::CheckArg> CheckArg_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::CheckArg, Pred> CheckArg_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::CheckArg, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::CheckState> CheckState_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::CheckState, Pred> CheckState_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::CheckState, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_cond;

	};

	class ConditionalGroup :  public CompoundStatement {
	public:
		ConditionalGroup();
		ConditionalGroup(::Udm::ObjectImpl *impl);
		ConditionalGroup(const ConditionalGroup &master);

#ifdef UDM_RVALUE
		ConditionalGroup(ConditionalGroup &&master);

		static ConditionalGroup Cast(::Udm::Object &&a);
		ConditionalGroup& operator=(ConditionalGroup &&a);

#endif
		static ConditionalGroup Cast(const ::Udm::Object &a);
		static ConditionalGroup Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ConditionalGroup CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ConditionalGroup> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ConditionalGroup, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ConditionalGroup, Pred>(impl); };
		ConditionalGroup CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ConditionalGroup> Derived();
		template <class Pred> ::Udm::DerivedAttr< ConditionalGroup, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ConditionalGroup, Pred>(impl); };
		::Udm::ArchetypeAttr< ConditionalGroup> Archetype() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;

	};

	class IterativeBlock :  public Block {
	public:
		IterativeBlock();
		IterativeBlock(::Udm::ObjectImpl *impl);
		IterativeBlock(const IterativeBlock &master);

#ifdef UDM_RVALUE
		IterativeBlock(IterativeBlock &&master);

		static IterativeBlock Cast(::Udm::Object &&a);
		IterativeBlock& operator=(IterativeBlock &&a);

#endif
		static IterativeBlock Cast(const ::Udm::Object &a);
		static IterativeBlock Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IterativeBlock CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IterativeBlock> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IterativeBlock, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IterativeBlock, Pred>(impl); };
		IterativeBlock CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IterativeBlock> Derived();
		template <class Pred> ::Udm::DerivedAttr< IterativeBlock, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IterativeBlock, Pred>(impl); };
		::Udm::ArchetypeAttr< IterativeBlock> Archetype() const;
		::Udm::ChildrenAttr< ::SFC::Condition> cond() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Condition, Pred> cond_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Condition, Pred>(impl, meta_cond); };
		::Udm::ChildrenAttr< ::SFC::Condition> Condition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Condition, Pred> Condition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Condition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UserCode> UserCode_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UserCode, Pred> UserCode_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UserCode, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::CheckArg> CheckArg_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::CheckArg, Pred> CheckArg_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::CheckArg, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::CheckState> CheckState_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::CheckState, Pred> CheckState_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::CheckState, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_cond;

	};

	class ArgVal : public ::Udm::Object {
	public:
		ArgVal();
		ArgVal(::Udm::ObjectImpl *impl);
		ArgVal(const ArgVal &master);

#ifdef UDM_RVALUE
		ArgVal(ArgVal &&master);

		static ArgVal Cast(::Udm::Object &&a);
		ArgVal& operator=(ArgVal &&a);

#endif
		static ArgVal Cast(const ::Udm::Object &a);
		static ArgVal Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ArgVal CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ArgVal> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ArgVal, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ArgVal, Pred>(impl); };
		ArgVal CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ArgVal> Derived();
		template <class Pred> ::Udm::DerivedAttr< ArgVal, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ArgVal, Pred>(impl); };
		::Udm::ArchetypeAttr< ArgVal> Archetype() const;
		::Udm::StringAttr val() const;
		::Udm::IntegerAttr argIndex() const;
		::Udm::AssocAttr< Arg> arg() const;
		template <class Pred> ::Udm::AssocAttr< Arg, Pred> arg_sorted(const Pred &) const { return ::Udm::AssocAttr< Arg, Pred>(impl, meta_arg); };
		::Udm::ChildAttr< ::SFC::Exprs> argexpr() const;
		::Udm::ChildrenAttr< ::SFC::FunctionCall> FunctionCall_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred> FunctionCall_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Str> Str_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Str, Pred> Str_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Str, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Double> Double_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Double, Pred> Double_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Double, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Int> Int_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Int, Pred> Int_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Int, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BinaryExprs> BinaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred> BinaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UnaryExprs> UnaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred> UnaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::NullaryExprs> NullaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred> NullaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Exprs> Exprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Exprs, Pred> Exprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Exprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclRef> ArgDeclRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred> ArgDeclRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::FunctionCall> FunctionCall_parent() const;
		::Udm::ParentAttr< ::SFC::FunctionCall> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_val;
		static ::Uml::Attribute meta_argIndex;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::CompositionChildRole meta_argexpr;
		static ::Uml::CompositionParentRole meta_FunctionCall_parent;

	};

	class StateRel :  virtual public ::Udm::Object {
	public:
		StateRel();
		StateRel(::Udm::ObjectImpl *impl);
		StateRel(const StateRel &master);

#ifdef UDM_RVALUE
		StateRel(StateRel &&master);

		static StateRel Cast(::Udm::Object &&a);
		StateRel& operator=(StateRel &&a);

#endif
		static StateRel Cast(const ::Udm::Object &a);
		static StateRel Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateRel CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateRel> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateRel, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateRel, Pred>(impl); };
		StateRel CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateRel> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateRel, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateRel, Pred>(impl); };
		::Udm::ArchetypeAttr< StateRel> Archetype() const;
		::Udm::BooleanAttr andState() const;
		::Udm::BooleanAttr invert() const;
		::Udm::PointerAttr< StateLabel> value() const;
		::Udm::PointerAttr< StateLabel> index() const;
		::Udm::PointerAttr< StateVar> svar() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_andState;
		static ::Uml::Attribute meta_invert;
		static ::Uml::AssociationRole meta_value;
		static ::Uml::AssociationRole meta_index;
		static ::Uml::AssociationRole meta_svar;

	};

	class CheckArg :  public Condition {
	public:
		CheckArg();
		CheckArg(::Udm::ObjectImpl *impl);
		CheckArg(const CheckArg &master);

#ifdef UDM_RVALUE
		CheckArg(CheckArg &&master);

		static CheckArg Cast(::Udm::Object &&a);
		CheckArg& operator=(CheckArg &&a);

#endif
		static CheckArg Cast(const ::Udm::Object &a);
		static CheckArg Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CheckArg CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CheckArg> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CheckArg, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CheckArg, Pred>(impl); };
		CheckArg CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CheckArg> Derived();
		template <class Pred> ::Udm::DerivedAttr< CheckArg, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CheckArg, Pred>(impl); };
		::Udm::ArchetypeAttr< CheckArg> Archetype() const;
		::Udm::ParentAttr< ::SFC::Block> parent() const;
		::Udm::AssocEndAttr< ::SFC::Arg> arg_end() const;
		::Udm::AssocEndAttr< ::SFC::StateLabel> slab_end() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_arg_end_;
		static ::Uml::AssociationRole meta_slab_end_;

	};

	class SetState :  public SimpleStatement,  public StateRel {
	public:
		SetState();
		SetState(::Udm::ObjectImpl *impl);
		SetState(const SetState &master);

#ifdef UDM_RVALUE
		SetState(SetState &&master);

		static SetState Cast(::Udm::Object &&a);
		SetState& operator=(SetState &&a);

#endif
		static SetState Cast(const ::Udm::Object &a);
		static SetState Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SetState CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SetState> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SetState, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SetState, Pred>(impl); };
		SetState CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SetState> Derived();
		template <class Pred> ::Udm::DerivedAttr< SetState, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SetState, Pred>(impl); };
		::Udm::ArchetypeAttr< SetState> Archetype() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;

	};

	class CheckState :  public Condition,  public StateRel {
	public:
		CheckState();
		CheckState(::Udm::ObjectImpl *impl);
		CheckState(const CheckState &master);

#ifdef UDM_RVALUE
		CheckState(CheckState &&master);

		static CheckState Cast(::Udm::Object &&a);
		CheckState& operator=(CheckState &&a);

#endif
		static CheckState Cast(const ::Udm::Object &a);
		static CheckState Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CheckState CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CheckState> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CheckState, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CheckState, Pred>(impl); };
		CheckState CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CheckState> Derived();
		template <class Pred> ::Udm::DerivedAttr< CheckState, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CheckState, Pred>(impl); };
		::Udm::ArchetypeAttr< CheckState> Archetype() const;
		::Udm::ParentAttr< ::SFC::Block> parent() const;

		static ::Uml::Class meta;

	};

	class SetVar :  public SimpleStatement {
	public:
		SetVar();
		SetVar(::Udm::ObjectImpl *impl);
		SetVar(const SetVar &master);

#ifdef UDM_RVALUE
		SetVar(SetVar &&master);

		static SetVar Cast(::Udm::Object &&a);
		SetVar& operator=(SetVar &&a);

#endif
		static SetVar Cast(const ::Udm::Object &a);
		static SetVar Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SetVar CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SetVar> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SetVar, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SetVar, Pred>(impl); };
		SetVar CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SetVar> Derived();
		template <class Pred> ::Udm::DerivedAttr< SetVar, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SetVar, Pred>(impl); };
		::Udm::ArchetypeAttr< SetVar> Archetype() const;
		::Udm::BooleanAttr invert() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;
		::Udm::AssocEndAttr< ::SFC::Arg> arg_end() const;
		::Udm::AssocEndAttr< ::SFC::LocalVar> lvar_end() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_invert;
		static ::Uml::AssociationRole meta_arg_end_;
		static ::Uml::AssociationRole meta_lvar_end_;

	};

	class Exprs :  virtual public ::Udm::Object {
	public:
		Exprs();
		Exprs(::Udm::ObjectImpl *impl);
		Exprs(const Exprs &master);

#ifdef UDM_RVALUE
		Exprs(Exprs &&master);

		static Exprs Cast(::Udm::Object &&a);
		Exprs& operator=(Exprs &&a);

#endif
		static Exprs Cast(const ::Udm::Object &a);
		static Exprs Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Exprs CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Exprs> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Exprs, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Exprs, Pred>(impl); };
		Exprs CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Exprs> Derived();
		template <class Pred> ::Udm::DerivedAttr< Exprs, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Exprs, Pred>(impl); };
		::Udm::ArchetypeAttr< Exprs> Archetype() const;
		::Udm::ParentAttr< ::SFC::Return> retexprpar() const;
		::Udm::ParentAttr< ::SFC::UserCode> codeexprpar() const;
		::Udm::ParentAttr< ::SFC::ArgVal> argexprpar() const;
		::Udm::ParentAttr< ::SFC::BinaryExprs> rightexprpar() const;
		::Udm::ParentAttr< ::SFC::BinaryExprs> leftexprpar() const;
		::Udm::ParentAttr< ::SFC::UnaryExprs> subexprpar() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_retexprpar;
		static ::Uml::CompositionParentRole meta_codeexprpar;
		static ::Uml::CompositionParentRole meta_argexprpar;
		static ::Uml::CompositionParentRole meta_rightexprpar;
		static ::Uml::CompositionParentRole meta_leftexprpar;
		static ::Uml::CompositionParentRole meta_subexprpar;

	};

	class BinaryExprs :  public Exprs {
	public:
		BinaryExprs();
		BinaryExprs(::Udm::ObjectImpl *impl);
		BinaryExprs(const BinaryExprs &master);

#ifdef UDM_RVALUE
		BinaryExprs(BinaryExprs &&master);

		static BinaryExprs Cast(::Udm::Object &&a);
		BinaryExprs& operator=(BinaryExprs &&a);

#endif
		static BinaryExprs Cast(const ::Udm::Object &a);
		static BinaryExprs Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BinaryExprs CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BinaryExprs> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BinaryExprs, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BinaryExprs, Pred>(impl); };
		BinaryExprs CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BinaryExprs> Derived();
		template <class Pred> ::Udm::DerivedAttr< BinaryExprs, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BinaryExprs, Pred>(impl); };
		::Udm::ArchetypeAttr< BinaryExprs> Archetype() const;
		::Udm::StringAttr op() const;
		::Udm::ChildAttr< ::SFC::Exprs> rightexpr() const;
		::Udm::ChildAttr< ::SFC::Exprs> leftexpr() const;
		::Udm::ChildrenAttr< ::SFC::FunctionCall> FunctionCall_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred> FunctionCall_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Str> Str_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Str, Pred> Str_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Str, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Double> Double_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Double, Pred> Double_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Double, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Int> Int_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Int, Pred> Int_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Int, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BinaryExprs> BinaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred> BinaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UnaryExprs> UnaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred> UnaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::NullaryExprs> NullaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred> NullaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Exprs> Exprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Exprs, Pred> Exprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Exprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclRef> ArgDeclRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred> ArgDeclRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_op;
		static ::Uml::CompositionChildRole meta_rightexpr;
		static ::Uml::CompositionChildRole meta_leftexpr;

	};

	class UnaryExprs :  public Exprs {
	public:
		UnaryExprs();
		UnaryExprs(::Udm::ObjectImpl *impl);
		UnaryExprs(const UnaryExprs &master);

#ifdef UDM_RVALUE
		UnaryExprs(UnaryExprs &&master);

		static UnaryExprs Cast(::Udm::Object &&a);
		UnaryExprs& operator=(UnaryExprs &&a);

#endif
		static UnaryExprs Cast(const ::Udm::Object &a);
		static UnaryExprs Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		UnaryExprs CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< UnaryExprs> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< UnaryExprs, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< UnaryExprs, Pred>(impl); };
		UnaryExprs CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< UnaryExprs> Derived();
		template <class Pred> ::Udm::DerivedAttr< UnaryExprs, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< UnaryExprs, Pred>(impl); };
		::Udm::ArchetypeAttr< UnaryExprs> Archetype() const;
		::Udm::StringAttr op() const;
		::Udm::ChildAttr< ::SFC::Exprs> subexpr() const;
		::Udm::ChildrenAttr< ::SFC::FunctionCall> FunctionCall_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred> FunctionCall_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Str> Str_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Str, Pred> Str_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Str, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Double> Double_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Double, Pred> Double_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Double, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Int> Int_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Int, Pred> Int_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Int, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BinaryExprs> BinaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred> BinaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::UnaryExprs> UnaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred> UnaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::NullaryExprs> NullaryExprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred> NullaryExprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Exprs> Exprs_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Exprs, Pred> Exprs_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Exprs, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclRef> ArgDeclRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred> ArgDeclRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_op;
		static ::Uml::CompositionChildRole meta_subexpr;

	};

	class NullaryExprs :  public Exprs {
	public:
		NullaryExprs();
		NullaryExprs(::Udm::ObjectImpl *impl);
		NullaryExprs(const NullaryExprs &master);

#ifdef UDM_RVALUE
		NullaryExprs(NullaryExprs &&master);

		static NullaryExprs Cast(::Udm::Object &&a);
		NullaryExprs& operator=(NullaryExprs &&a);

#endif
		static NullaryExprs Cast(const ::Udm::Object &a);
		static NullaryExprs Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		NullaryExprs CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< NullaryExprs> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< NullaryExprs, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< NullaryExprs, Pred>(impl); };
		NullaryExprs CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< NullaryExprs> Derived();
		template <class Pred> ::Udm::DerivedAttr< NullaryExprs, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< NullaryExprs, Pred>(impl); };
		::Udm::ArchetypeAttr< NullaryExprs> Archetype() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;

	};

	class FunctionCall :  public NullaryExprs,  public SimpleStatement {
	public:
		FunctionCall();
		FunctionCall(::Udm::ObjectImpl *impl);
		FunctionCall(const FunctionCall &master);

#ifdef UDM_RVALUE
		FunctionCall(FunctionCall &&master);

		static FunctionCall Cast(::Udm::Object &&a);
		FunctionCall& operator=(FunctionCall &&a);

#endif
		static FunctionCall Cast(const ::Udm::Object &a);
		static FunctionCall Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FunctionCall CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FunctionCall> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FunctionCall, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FunctionCall, Pred>(impl); };
		FunctionCall CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FunctionCall> Derived();
		template <class Pred> ::Udm::DerivedAttr< FunctionCall, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FunctionCall, Pred>(impl); };
		::Udm::ArchetypeAttr< FunctionCall> Archetype() const;
		::Udm::IntegerAttr argCount() const;
		::Udm::StringAttr libFuncName() const;
		::Udm::PointerAttr< Function> callee() const;
		::Udm::ChildrenAttr< ::SFC::ArgVal> ArgVal_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgVal, Pred> ArgVal_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgVal, Pred>(impl, meta_ArgVal_children); };
		::Udm::ChildrenAttr< ::SFC::ArgVal> ArgVal_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgVal, Pred> ArgVal_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgVal, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_argCount;
		static ::Uml::Attribute meta_libFuncName;
		static ::Uml::AssociationRole meta_callee;
		static ::Uml::CompositionChildRole meta_ArgVal_children;

	};

	class Str :  public NullaryExprs {
	public:
		Str();
		Str(::Udm::ObjectImpl *impl);
		Str(const Str &master);

#ifdef UDM_RVALUE
		Str(Str &&master);

		static Str Cast(::Udm::Object &&a);
		Str& operator=(Str &&a);

#endif
		static Str Cast(const ::Udm::Object &a);
		static Str Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Str CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Str> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Str, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Str, Pred>(impl); };
		Str CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Str> Derived();
		template <class Pred> ::Udm::DerivedAttr< Str, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Str, Pred>(impl); };
		::Udm::ArchetypeAttr< Str> Archetype() const;
		::Udm::StringAttr val() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_val;

	};

	class Double :  public NullaryExprs {
	public:
		Double();
		Double(::Udm::ObjectImpl *impl);
		Double(const Double &master);

#ifdef UDM_RVALUE
		Double(Double &&master);

		static Double Cast(::Udm::Object &&a);
		Double& operator=(Double &&a);

#endif
		static Double Cast(const ::Udm::Object &a);
		static Double Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Double CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Double> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Double, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Double, Pred>(impl); };
		Double CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Double> Derived();
		template <class Pred> ::Udm::DerivedAttr< Double, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Double, Pred>(impl); };
		::Udm::ArchetypeAttr< Double> Archetype() const;
		::Udm::RealAttr val() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_val;

	};

	class Int :  public NullaryExprs {
	public:
		Int();
		Int(::Udm::ObjectImpl *impl);
		Int(const Int &master);

#ifdef UDM_RVALUE
		Int(Int &&master);

		static Int Cast(::Udm::Object &&a);
		Int& operator=(Int &&a);

#endif
		static Int Cast(const ::Udm::Object &a);
		static Int Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Int CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Int> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Int, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Int, Pred>(impl); };
		Int CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Int> Derived();
		template <class Pred> ::Udm::DerivedAttr< Int, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Int, Pred>(impl); };
		::Udm::ArchetypeAttr< Int> Archetype() const;
		::Udm::IntegerAttr val() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_val;

	};

	class ArgDeclRef :  public NullaryExprs {
	public:
		ArgDeclRef();
		ArgDeclRef(::Udm::ObjectImpl *impl);
		ArgDeclRef(const ArgDeclRef &master);

#ifdef UDM_RVALUE
		ArgDeclRef(ArgDeclRef &&master);

		static ArgDeclRef Cast(::Udm::Object &&a);
		ArgDeclRef& operator=(ArgDeclRef &&a);

#endif
		static ArgDeclRef Cast(const ::Udm::Object &a);
		static ArgDeclRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ArgDeclRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ArgDeclRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ArgDeclRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ArgDeclRef, Pred>(impl); };
		ArgDeclRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ArgDeclRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< ArgDeclRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ArgDeclRef, Pred>(impl); };
		::Udm::ArchetypeAttr< ArgDeclRef> Archetype() const;
		::Udm::StringAttr unres() const;
		::Udm::PointerAttr< ArgDeclBase> argdecl() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_unres;
		static ::Uml::AssociationRole meta_argdecl;

	};

	class Class :  public CompoundStatement {
	public:
		Class();
		Class(::Udm::ObjectImpl *impl);
		Class(const Class &master);

#ifdef UDM_RVALUE
		Class(Class &&master);

		static Class Cast(::Udm::Object &&a);
		Class& operator=(Class &&a);

#endif
		static Class Cast(const ::Udm::Object &a);
		static Class Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Class CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Class> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Class, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Class, Pred>(impl); };
		Class CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Class> Derived();
		template <class Pred> ::Udm::DerivedAttr< Class, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Class, Pred>(impl); };
		::Udm::ArchetypeAttr< Class> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::StringAttr annotation() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::Attribute meta_annotation;

	};

	class Project :  public CompoundStatement {
	public:
		Project();
		Project(::Udm::ObjectImpl *impl);
		Project(const Project &master);

#ifdef UDM_RVALUE
		Project(Project &&master);

		static Project Cast(::Udm::Object &&a);
		Project& operator=(Project &&a);

#endif
		static Project Cast(const ::Udm::Object &a);
		static Project Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Project CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Project> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Project, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Project, Pred>(impl); };
		Project CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Project> Derived();
		template <class Pred> ::Udm::DerivedAttr< Project, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Project, Pred>(impl); };
		::Udm::ArchetypeAttr< Project> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;

	};

	class TypedEntity :  virtual public ::Udm::Object {
	public:
		TypedEntity();
		TypedEntity(::Udm::ObjectImpl *impl);
		TypedEntity(const TypedEntity &master);

#ifdef UDM_RVALUE
		TypedEntity(TypedEntity &&master);

		static TypedEntity Cast(::Udm::Object &&a);
		TypedEntity& operator=(TypedEntity &&a);

#endif
		static TypedEntity Cast(const ::Udm::Object &a);
		static TypedEntity Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypedEntity CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypedEntity> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypedEntity, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypedEntity, Pred>(impl); };
		TypedEntity CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypedEntity> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypedEntity, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypedEntity, Pred>(impl); };
		::Udm::ArchetypeAttr< TypedEntity> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::StringAttr scope() const;
		::Udm::PointerAttr< DT> dt() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;
		::Udm::ParentAttr< ::SFC::Statement> Statement_parent() const;
		::Udm::ParentAttr< ::SFC::TypedEntity> TypedEntity_parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::Attribute meta_scope;
		static ::Uml::AssociationRole meta_dt;

	};

	class Function :  public Block,  public TypedEntity {
	public:
		Function();
		Function(::Udm::ObjectImpl *impl);
		Function(const Function &master);

#ifdef UDM_RVALUE
		Function(Function &&master);

		static Function Cast(::Udm::Object &&a);
		Function& operator=(Function &&a);

#endif
		static Function Cast(const ::Udm::Object &a);
		static Function Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Function CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Function> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Function, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Function, Pred>(impl); };
		Function CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Function> Derived();
		template <class Pred> ::Udm::DerivedAttr< Function, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Function, Pred>(impl); };
		::Udm::ArchetypeAttr< Function> Archetype() const;
		::Udm::StringAttr annotation() const;
		::Udm::StringAttr returnType() const;
		::Udm::IntegerAttr argCount() const;
		::Udm::AssocAttr< FunctionCall> caller() const;
		template <class Pred> ::Udm::AssocAttr< FunctionCall, Pred> caller_sorted(const Pred &) const { return ::Udm::AssocAttr< FunctionCall, Pred>(impl, meta_caller); };
		::Udm::CrossAssocAttr< ::ESMoL::State> statusSt() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::State, Pred> statusSt_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::State, Pred>(impl, meta_statusSt); };
		::Udm::CrossAssocAttr< ::ESMoL::State> execSt() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::State, Pred> execSt_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::State, Pred>(impl, meta_execSt); };
		::Udm::CrossAssocAttr< ::ESMoL::State> exitSt() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::State, Pred> exitSt_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::State, Pred>(impl, meta_exitSt); };
		::Udm::CrossAssocAttr< ::ESMoL::State> enterSt() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::State, Pred> enterSt_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::State, Pred>(impl, meta_enterSt); };
		::Udm::ChildrenAttr< ::SFC::Arg> Arg_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Arg, Pred> Arg_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Arg, Pred>(impl, meta_Arg_children); };
		::Udm::ChildrenAttr< ::SFC::Arg> Arg_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Arg, Pred> Arg_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Arg, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclBase> ArgDeclBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclBase, Pred> ArgDeclBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::TypedEntity> TypedEntity_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::TypedEntity, Pred> TypedEntity_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::TypedEntity, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_annotation;
		static ::Uml::Attribute meta_returnType;
		static ::Uml::Attribute meta_argCount;
		static ::Uml::AssociationRole meta_caller;
		static ::Uml::AssociationRole meta_statusSt;
		static ::Uml::AssociationRole meta_execSt;
		static ::Uml::AssociationRole meta_exitSt;
		static ::Uml::AssociationRole meta_enterSt;
		static ::Uml::CompositionChildRole meta_Arg_children;

	};

	class ArgDeclBase :  virtual  public TypedEntity {
	public:
		ArgDeclBase();
		ArgDeclBase(::Udm::ObjectImpl *impl);
		ArgDeclBase(const ArgDeclBase &master);

#ifdef UDM_RVALUE
		ArgDeclBase(ArgDeclBase &&master);

		static ArgDeclBase Cast(::Udm::Object &&a);
		ArgDeclBase& operator=(ArgDeclBase &&a);

#endif
		static ArgDeclBase Cast(const ::Udm::Object &a);
		static ArgDeclBase Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ArgDeclBase CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ArgDeclBase> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ArgDeclBase, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ArgDeclBase, Pred>(impl); };
		ArgDeclBase CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ArgDeclBase> Derived();
		template <class Pred> ::Udm::DerivedAttr< ArgDeclBase, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ArgDeclBase, Pred>(impl); };
		::Udm::ArchetypeAttr< ArgDeclBase> Archetype() const;
		::Udm::StringAttr indexBase() const;
		::Udm::AssocAttr< ArgDeclRef> ref() const;
		template <class Pred> ::Udm::AssocAttr< ArgDeclRef, Pred> ref_sorted(const Pred &) const { return ::Udm::AssocAttr< ArgDeclRef, Pred>(impl, meta_ref); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;
		::Udm::ParentAttr< ::SFC::Statement> Statement_parent() const;
		::Udm::ParentAttr< ::SFC::TypedEntity> TypedEntity_parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_indexBase;
		static ::Uml::AssociationRole meta_ref;

	};

	class Arg :  public ArgDeclBase {
	public:
		Arg();
		Arg(::Udm::ObjectImpl *impl);
		Arg(const Arg &master);

#ifdef UDM_RVALUE
		Arg(Arg &&master);

		static Arg Cast(::Udm::Object &&a);
		Arg& operator=(Arg &&a);

#endif
		static Arg Cast(const ::Udm::Object &a);
		static Arg Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Arg CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Arg> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Arg, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Arg, Pred>(impl); };
		Arg CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Arg> Derived();
		template <class Pred> ::Udm::DerivedAttr< Arg, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Arg, Pred>(impl); };
		::Udm::ArchetypeAttr< Arg> Archetype() const;
		::Udm::StringAttr type() const;
		::Udm::IntegerAttr size() const;
		::Udm::BooleanAttr ptr() const;
		::Udm::IntegerAttr argIndex() const;
		::Udm::AClassAssocAttr< CheckArg, StateLabel> slab() const;
		template <class Pred> ::Udm::AClassAssocAttr< CheckArg, StateLabel, Pred> slab_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< CheckArg, StateLabel, Pred>(impl, meta_slab, meta_slab_rev); };
		::Udm::AClassAssocAttr< SetVar, LocalVar> lvar() const;
		template <class Pred> ::Udm::AClassAssocAttr< SetVar, LocalVar, Pred> lvar_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< SetVar, LocalVar, Pred>(impl, meta_lvar, meta_lvar_rev); };
		::Udm::AssocAttr< ArgVal> val() const;
		template <class Pred> ::Udm::AssocAttr< ArgVal, Pred> val_sorted(const Pred &) const { return ::Udm::AssocAttr< ArgVal, Pred>(impl, meta_val); };
		::Udm::ParentAttr< ::SFC::Function> Function_parent() const;
		::Udm::ParentAttr< ::SFC::Function> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_type;
		static ::Uml::Attribute meta_size;
		static ::Uml::Attribute meta_ptr;
		static ::Uml::Attribute meta_argIndex;
		static ::Uml::AssociationRole meta_slab;
		static ::Uml::AssociationRole meta_slab_rev;
		static ::Uml::AssociationRole meta_lvar;
		static ::Uml::AssociationRole meta_lvar_rev;
		static ::Uml::AssociationRole meta_val;
		static ::Uml::CompositionParentRole meta_Function_parent;

	};

	class Declaration :  public ArgDeclBase,  public Statement {
	public:
		Declaration();
		Declaration(::Udm::ObjectImpl *impl);
		Declaration(const Declaration &master);

#ifdef UDM_RVALUE
		Declaration(Declaration &&master);

		static Declaration Cast(::Udm::Object &&a);
		Declaration& operator=(Declaration &&a);

#endif
		static Declaration Cast(const ::Udm::Object &a);
		static Declaration Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Declaration CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Declaration> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Declaration, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Declaration, Pred>(impl); };
		Declaration CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Declaration> Derived();
		template <class Pred> ::Udm::DerivedAttr< Declaration, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Declaration, Pred>(impl); };
		::Udm::ArchetypeAttr< Declaration> Archetype() const;
		::Udm::ParentAttr< ::SFC::Struct> strct() const;
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_strct;

	};

	class StateLabel :  public Declaration {
	public:
		StateLabel();
		StateLabel(::Udm::ObjectImpl *impl);
		StateLabel(const StateLabel &master);

#ifdef UDM_RVALUE
		StateLabel(StateLabel &&master);

		static StateLabel Cast(::Udm::Object &&a);
		StateLabel& operator=(StateLabel &&a);

#endif
		static StateLabel Cast(const ::Udm::Object &a);
		static StateLabel Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateLabel CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateLabel> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateLabel, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateLabel, Pred>(impl); };
		StateLabel CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateLabel> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateLabel, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateLabel, Pred>(impl); };
		::Udm::ArchetypeAttr< StateLabel> Archetype() const;
		::Udm::StringAttr comment() const;
		::Udm::IntegerAttr value() const;
		::Udm::IntegerAttr andSS() const;
		::Udm::AClassAssocAttr< CheckArg, Arg> arg() const;
		template <class Pred> ::Udm::AClassAssocAttr< CheckArg, Arg, Pred> arg_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< CheckArg, Arg, Pred>(impl, meta_arg, meta_arg_rev); };
		::Udm::AssocAttr< StateRel> srv() const;
		template <class Pred> ::Udm::AssocAttr< StateRel, Pred> srv_sorted(const Pred &) const { return ::Udm::AssocAttr< StateRel, Pred>(impl, meta_srv); };
		::Udm::AssocAttr< StateRel> sri() const;
		template <class Pred> ::Udm::AssocAttr< StateRel, Pred> sri_sorted(const Pred &) const { return ::Udm::AssocAttr< StateRel, Pred>(impl, meta_sri); };
		::Udm::CrossAssocAttr< ::ESMoL::State> dst() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::State, Pred> dst_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::State, Pred>(impl, meta_dst); };
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_comment;
		static ::Uml::Attribute meta_value;
		static ::Uml::Attribute meta_andSS;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::AssociationRole meta_arg_rev;
		static ::Uml::AssociationRole meta_srv;
		static ::Uml::AssociationRole meta_sri;
		static ::Uml::AssociationRole meta_dst;

	};

	class Var :  public Declaration {
	public:
		Var();
		Var(::Udm::ObjectImpl *impl);
		Var(const Var &master);

#ifdef UDM_RVALUE
		Var(Var &&master);

		static Var Cast(::Udm::Object &&a);
		Var& operator=(Var &&a);

#endif
		static Var Cast(const ::Udm::Object &a);
		static Var Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Var CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Var> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Var, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Var, Pred>(impl); };
		Var CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Var> Derived();
		template <class Pred> ::Udm::DerivedAttr< Var, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Var, Pred>(impl); };
		::Udm::ArchetypeAttr< Var> Archetype() const;
		::Udm::StringAttr type() const;
		::Udm::IntegerAttr size() const;
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_type;
		static ::Uml::Attribute meta_size;

	};

	class LocalVar :  public Var {
	public:
		LocalVar();
		LocalVar(::Udm::ObjectImpl *impl);
		LocalVar(const LocalVar &master);

#ifdef UDM_RVALUE
		LocalVar(LocalVar &&master);

		static LocalVar Cast(::Udm::Object &&a);
		LocalVar& operator=(LocalVar &&a);

#endif
		static LocalVar Cast(const ::Udm::Object &a);
		static LocalVar Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		LocalVar CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< LocalVar> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< LocalVar, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< LocalVar, Pred>(impl); };
		LocalVar CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< LocalVar> Derived();
		template <class Pred> ::Udm::DerivedAttr< LocalVar, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< LocalVar, Pred>(impl); };
		::Udm::ArchetypeAttr< LocalVar> Archetype() const;
		::Udm::StringAttr initial() const;
		::Udm::BooleanAttr Static() const;
		::Udm::AClassAssocAttr< SetVar, Arg> arg() const;
		template <class Pred> ::Udm::AClassAssocAttr< SetVar, Arg, Pred> arg_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< SetVar, Arg, Pred>(impl, meta_arg, meta_arg_rev); };
		::Udm::CrossPointerAttr< ::ESMoL::TypeBaseRef> tbr() const;
		::Udm::CrossPointerAttr< ::ESMoL::State> topState() const;
		::Udm::CrossAssocAttr< ::ESMoL::Event> event() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::Event, Pred> event_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::Event, Pred>(impl, meta_event); };
		::Udm::CrossAssocAttr< ::ESMoL::Data> data() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::ESMoL::Data, Pred> data_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::ESMoL::Data, Pred>(impl, meta_data); };
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_initial;
		static ::Uml::Attribute meta_Static;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::AssociationRole meta_arg_rev;
		static ::Uml::AssociationRole meta_tbr;
		static ::Uml::AssociationRole meta_topState;
		static ::Uml::AssociationRole meta_event;
		static ::Uml::AssociationRole meta_data;

	};

	class StateVar :  public Var {
	public:
		StateVar();
		StateVar(::Udm::ObjectImpl *impl);
		StateVar(const StateVar &master);

#ifdef UDM_RVALUE
		StateVar(StateVar &&master);

		static StateVar Cast(::Udm::Object &&a);
		StateVar& operator=(StateVar &&a);

#endif
		static StateVar Cast(const ::Udm::Object &a);
		static StateVar Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateVar CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateVar> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateVar, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateVar, Pred>(impl); };
		StateVar CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateVar> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateVar, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateVar, Pred>(impl); };
		::Udm::ArchetypeAttr< StateVar> Archetype() const;
		::Udm::AssocAttr< StateRel> srs() const;
		template <class Pred> ::Udm::AssocAttr< StateRel, Pred> srs_sorted(const Pred &) const { return ::Udm::AssocAttr< StateRel, Pred>(impl, meta_srs); };
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srs;

	};

	class DT :  public Declaration {
	public:
		DT();
		DT(::Udm::ObjectImpl *impl);
		DT(const DT &master);

#ifdef UDM_RVALUE
		DT(DT &&master);

		static DT Cast(::Udm::Object &&a);
		DT& operator=(DT &&a);

#endif
		static DT Cast(const ::Udm::Object &a);
		static DT Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DT CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DT> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DT, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DT, Pred>(impl); };
		DT CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DT> Derived();
		template <class Pred> ::Udm::DerivedAttr< DT, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DT, Pred>(impl); };
		::Udm::ArchetypeAttr< DT> Archetype() const;
		::Udm::AssocAttr< TypedEntity> te() const;
		template <class Pred> ::Udm::AssocAttr< TypedEntity, Pred> te_sorted(const Pred &) const { return ::Udm::AssocAttr< TypedEntity, Pred>(impl, meta_te); };
		::Udm::CrossPointerAttr< ::ESMoL::TypeBase> tb() const;
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_te;
		static ::Uml::AssociationRole meta_tb;

	};

	class Struct :  public DT {
	public:
		Struct();
		Struct(::Udm::ObjectImpl *impl);
		Struct(const Struct &master);

#ifdef UDM_RVALUE
		Struct(Struct &&master);

		static Struct Cast(::Udm::Object &&a);
		Struct& operator=(Struct &&a);

#endif
		static Struct Cast(const ::Udm::Object &a);
		static Struct Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Struct CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Struct> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Struct, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Struct, Pred>(impl); };
		Struct CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Struct> Derived();
		template <class Pred> ::Udm::DerivedAttr< Struct, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Struct, Pred>(impl); };
		::Udm::ArchetypeAttr< Struct> Archetype() const;
		::Udm::IntegerAttr memberCount() const;
		::Udm::ChildrenAttr< ::SFC::Declaration> memb() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Declaration, Pred> memb_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Declaration, Pred>(impl, meta_memb); };
		::Udm::ChildrenAttr< ::SFC::Statement> Statement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Statement, Pred> Statement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Statement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::LocalVar> LocalVar_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::LocalVar, Pred> LocalVar_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::LocalVar, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::StateVar> StateVar_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::StateVar, Pred> StateVar_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::StateVar, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::StateLabel> StateLabel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::StateLabel, Pred> StateLabel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::StateLabel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Var> Var_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Var, Pred> Var_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Var, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Declaration> Declaration_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Declaration, Pred> Declaration_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Declaration, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::DT> DT_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::DT, Pred> DT_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::DT, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Struct> Struct_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Struct, Pred> Struct_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Struct, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::ArgDeclBase> ArgDeclBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::ArgDeclBase, Pred> ArgDeclBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::Array> Array_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::Array, Pred> Array_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::Array, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::TypedEntity> TypedEntity_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::TypedEntity, Pred> TypedEntity_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::TypedEntity, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::SFC::BasicType> BasicType_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::SFC::BasicType, Pred> BasicType_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::SFC::BasicType, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_memberCount;
		static ::Uml::CompositionChildRole meta_memb;

	};

	class Array :  public DT,  virtual  public TypedEntity {
	public:
		Array();
		Array(::Udm::ObjectImpl *impl);
		Array(const Array &master);

#ifdef UDM_RVALUE
		Array(Array &&master);

		static Array Cast(::Udm::Object &&a);
		Array& operator=(Array &&a);

#endif
		static Array Cast(const ::Udm::Object &a);
		static Array Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Array CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Array> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Array, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Array, Pred>(impl); };
		Array CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Array> Derived();
		template <class Pred> ::Udm::DerivedAttr< Array, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Array, Pred>(impl); };
		::Udm::ArchetypeAttr< Array> Archetype() const;
		::Udm::IntegerAttr noelem() const;
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_noelem;

	};

	class BasicType :  public DT {
	public:
		BasicType();
		BasicType(::Udm::ObjectImpl *impl);
		BasicType(const BasicType &master);

#ifdef UDM_RVALUE
		BasicType(BasicType &&master);

		static BasicType Cast(::Udm::Object &&a);
		BasicType& operator=(BasicType &&a);

#endif
		static BasicType Cast(const ::Udm::Object &a);
		static BasicType Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BasicType CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BasicType> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BasicType, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BasicType, Pred>(impl); };
		BasicType CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BasicType> Derived();
		template <class Pred> ::Udm::DerivedAttr< BasicType, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BasicType, Pred>(impl); };
		::Udm::ArchetypeAttr< BasicType> Archetype() const;
		::Udm::ParentAttr< ::SFC::Statement> parent() const;

		static ::Uml::Class meta;

	};

	class Comment :  public Statement {
	public:
		Comment();
		Comment(::Udm::ObjectImpl *impl);
		Comment(const Comment &master);

#ifdef UDM_RVALUE
		Comment(Comment &&master);

		static Comment Cast(::Udm::Object &&a);
		Comment& operator=(Comment &&a);

#endif
		static Comment Cast(const ::Udm::Object &a);
		static Comment Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Comment CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Comment> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Comment, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Comment, Pred>(impl); };
		Comment CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Comment> Derived();
		template <class Pred> ::Udm::DerivedAttr< Comment, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Comment, Pred>(impl); };
		::Udm::ArchetypeAttr< Comment> Archetype() const;
		::Udm::StringAttr content() const;
		::Udm::ParentAttr< ::SFC::CompoundStatement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_content;

	};

}

#endif // MOBIES_SFC_H
