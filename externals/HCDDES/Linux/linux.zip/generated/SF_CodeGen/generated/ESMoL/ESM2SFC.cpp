// cpp (meta datanetwork format) source file ESM2SFC.cpp
// generated from diagram ESM2SFC
// generated on Mon Jul 23 16:51:09 2012

#include "ESM2SFC.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "ESM2SFC_xsd.h"
using namespace std;

namespace ESM2SFC {

	_gen_cont::_gen_cont() {}
	_gen_cont::_gen_cont(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	_gen_cont::_gen_cont(const _gen_cont &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	_gen_cont::_gen_cont(_gen_cont &&master) : UDM_OBJECT(master) {};

	_gen_cont _gen_cont::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	_gen_cont& _gen_cont::operator=(_gen_cont &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	_gen_cont _gen_cont::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	_gen_cont _gen_cont::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	_gen_cont _gen_cont::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< _gen_cont> _gen_cont::Instances() { return ::Udm::InstantiatedAttr< _gen_cont>(impl); }
	_gen_cont _gen_cont::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< _gen_cont> _gen_cont::Derived() { return ::Udm::DerivedAttr< _gen_cont>(impl); }
	::Udm::ArchetypeAttr< _gen_cont> _gen_cont::Archetype() const { return ::Udm::ArchetypeAttr< _gen_cont>(impl); }
	::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC> _gen_cont::CompoundStatement_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC>(impl, meta_CompoundStatement_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC> _gen_cont::LocalVar_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC>(impl, meta_LocalVar_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC> _gen_cont::StateLabel_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC>(impl, meta_StateLabel_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC> _gen_cont::DT_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC>(impl, meta_DT_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL> _gen_cont::TypeBase_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL>(impl, meta_TypeBase_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL> _gen_cont::TypeBaseRef_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL>(impl, meta_TypeBaseRef_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL> _gen_cont::State_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL>(impl, meta_State_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL> _gen_cont::Data_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL>(impl, meta_Data_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL> _gen_cont::Event_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL>(impl, meta_Event_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SFC::Function_cross_ph_SFC> _gen_cont::Function_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Function_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::ConditionalBlock_cross_ph_SFC> _gen_cont::ConditionalBlock_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::ConditionalBlock_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Program_cross_ph_SFC> _gen_cont::Program_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Program_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC> _gen_cont::CompoundStatement_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Block_cross_ph_SFC> _gen_cont::Block_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Block_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::ConditionalGroup_cross_ph_SFC> _gen_cont::ConditionalGroup_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::ConditionalGroup_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::IterativeBlock_cross_ph_SFC> _gen_cont::IterativeBlock_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::IterativeBlock_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC> _gen_cont::LocalVar_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC> _gen_cont::StateLabel_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC> _gen_cont::DT_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Struct_cross_ph_SFC> _gen_cont::Struct_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Struct_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Class_cross_ph_SFC> _gen_cont::Class_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Class_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Project_cross_ph_SFC> _gen_cont::Project_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Project_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Array_cross_ph_SFC> _gen_cont::Array_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Array_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::BasicType_cross_ph_SFC> _gen_cont::BasicType_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::BasicType_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::TypeStruct_cross_ph_ESMoL> _gen_cont::TypeStruct_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeStruct_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Matrix_cross_ph_ESMoL> _gen_cont::Matrix_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Matrix_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL> _gen_cont::TypeBase_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL> _gen_cont::TypeBaseRef_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL> _gen_cont::State_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL> _gen_cont::Data_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL> _gen_cont::Event_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::Udm::Object> _gen_cont::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class _gen_cont::meta;
	::Uml::CompositionChildRole _gen_cont::meta_CompoundStatement_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_LocalVar_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_StateLabel_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_DT_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_State_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Data_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Event_cross_ph_ESMoL_childrole;

	Function_cross_ph_SFC::Function_cross_ph_SFC() {}
	Function_cross_ph_SFC::Function_cross_ph_SFC(::Udm::ObjectImpl *impl) : Block_cross_ph_SFC(impl) {}
	Function_cross_ph_SFC::Function_cross_ph_SFC(const Function_cross_ph_SFC &master) : Block_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Function_cross_ph_SFC::Function_cross_ph_SFC(Function_cross_ph_SFC &&master) : Block_cross_ph_SFC(master) {};

	Function_cross_ph_SFC Function_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Function_cross_ph_SFC& Function_cross_ph_SFC::operator=(Function_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Function_cross_ph_SFC Function_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Function_cross_ph_SFC Function_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Function_cross_ph_SFC Function_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Function_cross_ph_SFC>(impl); }
	Function_cross_ph_SFC Function_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Function_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Function_cross_ph_SFC>(impl); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> Function_cross_ph_SFC::statusSt() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_statusSt); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> Function_cross_ph_SFC::execSt() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_execSt); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> Function_cross_ph_SFC::exitSt() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_exitSt); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> Function_cross_ph_SFC::enterSt() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_enterSt); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Function_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Function_cross_ph_SFC::meta;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_statusSt;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_execSt;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_exitSt;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_enterSt;

	ConditionalBlock_cross_ph_SFC::ConditionalBlock_cross_ph_SFC() {}
	ConditionalBlock_cross_ph_SFC::ConditionalBlock_cross_ph_SFC(::Udm::ObjectImpl *impl) : Block_cross_ph_SFC(impl) {}
	ConditionalBlock_cross_ph_SFC::ConditionalBlock_cross_ph_SFC(const ConditionalBlock_cross_ph_SFC &master) : Block_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	ConditionalBlock_cross_ph_SFC::ConditionalBlock_cross_ph_SFC(ConditionalBlock_cross_ph_SFC &&master) : Block_cross_ph_SFC(master) {};

	ConditionalBlock_cross_ph_SFC ConditionalBlock_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ConditionalBlock_cross_ph_SFC& ConditionalBlock_cross_ph_SFC::operator=(ConditionalBlock_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ConditionalBlock_cross_ph_SFC ConditionalBlock_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ConditionalBlock_cross_ph_SFC ConditionalBlock_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ConditionalBlock_cross_ph_SFC ConditionalBlock_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ConditionalBlock_cross_ph_SFC> ConditionalBlock_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< ConditionalBlock_cross_ph_SFC>(impl); }
	ConditionalBlock_cross_ph_SFC ConditionalBlock_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ConditionalBlock_cross_ph_SFC> ConditionalBlock_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< ConditionalBlock_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< ConditionalBlock_cross_ph_SFC> ConditionalBlock_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< ConditionalBlock_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> ConditionalBlock_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ConditionalBlock_cross_ph_SFC::meta;

	Program_cross_ph_SFC::Program_cross_ph_SFC() {}
	Program_cross_ph_SFC::Program_cross_ph_SFC(::Udm::ObjectImpl *impl) : CompoundStatement_cross_ph_SFC(impl) {}
	Program_cross_ph_SFC::Program_cross_ph_SFC(const Program_cross_ph_SFC &master) : CompoundStatement_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Program_cross_ph_SFC::Program_cross_ph_SFC(Program_cross_ph_SFC &&master) : CompoundStatement_cross_ph_SFC(master) {};

	Program_cross_ph_SFC Program_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Program_cross_ph_SFC& Program_cross_ph_SFC::operator=(Program_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Program_cross_ph_SFC Program_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Program_cross_ph_SFC Program_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Program_cross_ph_SFC Program_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Program_cross_ph_SFC> Program_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Program_cross_ph_SFC>(impl); }
	Program_cross_ph_SFC Program_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Program_cross_ph_SFC> Program_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Program_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Program_cross_ph_SFC> Program_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Program_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Program_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Program_cross_ph_SFC::meta;

	CompoundStatement_cross_ph_SFC::CompoundStatement_cross_ph_SFC() {}
	CompoundStatement_cross_ph_SFC::CompoundStatement_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	CompoundStatement_cross_ph_SFC::CompoundStatement_cross_ph_SFC(const CompoundStatement_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CompoundStatement_cross_ph_SFC::CompoundStatement_cross_ph_SFC(CompoundStatement_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	CompoundStatement_cross_ph_SFC CompoundStatement_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CompoundStatement_cross_ph_SFC& CompoundStatement_cross_ph_SFC::operator=(CompoundStatement_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CompoundStatement_cross_ph_SFC CompoundStatement_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CompoundStatement_cross_ph_SFC CompoundStatement_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CompoundStatement_cross_ph_SFC CompoundStatement_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CompoundStatement_cross_ph_SFC> CompoundStatement_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< CompoundStatement_cross_ph_SFC>(impl); }
	CompoundStatement_cross_ph_SFC CompoundStatement_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CompoundStatement_cross_ph_SFC> CompoundStatement_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< CompoundStatement_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< CompoundStatement_cross_ph_SFC> CompoundStatement_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< CompoundStatement_cross_ph_SFC>(impl); }
	::Udm::StringAttr CompoundStatement_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr CompoundStatement_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< State_cross_ph_ESMoL> CompoundStatement_cross_ph_SFC::immChild() const { return ::Udm::PointerAttr< State_cross_ph_ESMoL>(impl, meta_immChild); }
	::Udm::PointerAttr< State_cross_ph_ESMoL> CompoundStatement_cross_ph_SFC::commPar() const { return ::Udm::PointerAttr< State_cross_ph_ESMoL>(impl, meta_commPar); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> CompoundStatement_cross_ph_SFC::CompoundStatement_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_CompoundStatement_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> CompoundStatement_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CompoundStatement_cross_ph_SFC::meta;
	::Uml::Attribute CompoundStatement_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute CompoundStatement_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole CompoundStatement_cross_ph_SFC::meta_immChild;
	::Uml::AssociationRole CompoundStatement_cross_ph_SFC::meta_commPar;
	::Uml::CompositionParentRole CompoundStatement_cross_ph_SFC::meta_CompoundStatement_cross_ph_SFC_parentrole;

	Block_cross_ph_SFC::Block_cross_ph_SFC() {}
	Block_cross_ph_SFC::Block_cross_ph_SFC(::Udm::ObjectImpl *impl) : CompoundStatement_cross_ph_SFC(impl) {}
	Block_cross_ph_SFC::Block_cross_ph_SFC(const Block_cross_ph_SFC &master) : CompoundStatement_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Block_cross_ph_SFC::Block_cross_ph_SFC(Block_cross_ph_SFC &&master) : CompoundStatement_cross_ph_SFC(master) {};

	Block_cross_ph_SFC Block_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Block_cross_ph_SFC& Block_cross_ph_SFC::operator=(Block_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Block_cross_ph_SFC Block_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Block_cross_ph_SFC Block_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Block_cross_ph_SFC Block_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Block_cross_ph_SFC> Block_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Block_cross_ph_SFC>(impl); }
	Block_cross_ph_SFC Block_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Block_cross_ph_SFC> Block_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Block_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Block_cross_ph_SFC> Block_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Block_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Block_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Block_cross_ph_SFC::meta;

	ConditionalGroup_cross_ph_SFC::ConditionalGroup_cross_ph_SFC() {}
	ConditionalGroup_cross_ph_SFC::ConditionalGroup_cross_ph_SFC(::Udm::ObjectImpl *impl) : CompoundStatement_cross_ph_SFC(impl) {}
	ConditionalGroup_cross_ph_SFC::ConditionalGroup_cross_ph_SFC(const ConditionalGroup_cross_ph_SFC &master) : CompoundStatement_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	ConditionalGroup_cross_ph_SFC::ConditionalGroup_cross_ph_SFC(ConditionalGroup_cross_ph_SFC &&master) : CompoundStatement_cross_ph_SFC(master) {};

	ConditionalGroup_cross_ph_SFC ConditionalGroup_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ConditionalGroup_cross_ph_SFC& ConditionalGroup_cross_ph_SFC::operator=(ConditionalGroup_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ConditionalGroup_cross_ph_SFC ConditionalGroup_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ConditionalGroup_cross_ph_SFC ConditionalGroup_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ConditionalGroup_cross_ph_SFC ConditionalGroup_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ConditionalGroup_cross_ph_SFC> ConditionalGroup_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< ConditionalGroup_cross_ph_SFC>(impl); }
	ConditionalGroup_cross_ph_SFC ConditionalGroup_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ConditionalGroup_cross_ph_SFC> ConditionalGroup_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< ConditionalGroup_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< ConditionalGroup_cross_ph_SFC> ConditionalGroup_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< ConditionalGroup_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> ConditionalGroup_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ConditionalGroup_cross_ph_SFC::meta;

	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC() {}
	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC(::Udm::ObjectImpl *impl) : Block_cross_ph_SFC(impl) {}
	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC(const IterativeBlock_cross_ph_SFC &master) : Block_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC(IterativeBlock_cross_ph_SFC &&master) : Block_cross_ph_SFC(master) {};

	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IterativeBlock_cross_ph_SFC& IterativeBlock_cross_ph_SFC::operator=(IterativeBlock_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC>(impl); }
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< IterativeBlock_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> IterativeBlock_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IterativeBlock_cross_ph_SFC::meta;

	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC() {}
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(const LocalVar_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(LocalVar_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	LocalVar_cross_ph_SFC& LocalVar_cross_ph_SFC::operator=(LocalVar_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC>(impl); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< LocalVar_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC>(impl); }
	::Udm::StringAttr LocalVar_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr LocalVar_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< TypeBaseRef_cross_ph_ESMoL> LocalVar_cross_ph_SFC::tbr() const { return ::Udm::PointerAttr< TypeBaseRef_cross_ph_ESMoL>(impl, meta_tbr); }
	::Udm::PointerAttr< State_cross_ph_ESMoL> LocalVar_cross_ph_SFC::topState() const { return ::Udm::PointerAttr< State_cross_ph_ESMoL>(impl, meta_topState); }
	::Udm::AssocAttr< Event_cross_ph_ESMoL> LocalVar_cross_ph_SFC::event() const { return ::Udm::AssocAttr< Event_cross_ph_ESMoL>(impl, meta_event); }
	::Udm::AssocAttr< Data_cross_ph_ESMoL> LocalVar_cross_ph_SFC::data() const { return ::Udm::AssocAttr< Data_cross_ph_ESMoL>(impl, meta_data); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_LocalVar_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> LocalVar_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class LocalVar_cross_ph_SFC::meta;
	::Uml::Attribute LocalVar_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute LocalVar_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_tbr;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_topState;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_event;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_data;
	::Uml::CompositionParentRole LocalVar_cross_ph_SFC::meta_LocalVar_cross_ph_SFC_parentrole;

	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC() {}
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(const StateLabel_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(StateLabel_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateLabel_cross_ph_SFC& StateLabel_cross_ph_SFC::operator=(StateLabel_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC>(impl); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< StateLabel_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC>(impl); }
	::Udm::StringAttr StateLabel_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr StateLabel_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> StateLabel_cross_ph_SFC::dst() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_dst); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_StateLabel_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> StateLabel_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateLabel_cross_ph_SFC::meta;
	::Uml::Attribute StateLabel_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute StateLabel_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole StateLabel_cross_ph_SFC::meta_dst;
	::Uml::CompositionParentRole StateLabel_cross_ph_SFC::meta_StateLabel_cross_ph_SFC_parentrole;

	DT_cross_ph_SFC::DT_cross_ph_SFC() {}
	DT_cross_ph_SFC::DT_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	DT_cross_ph_SFC::DT_cross_ph_SFC(const DT_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DT_cross_ph_SFC::DT_cross_ph_SFC(DT_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	DT_cross_ph_SFC DT_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DT_cross_ph_SFC& DT_cross_ph_SFC::operator=(DT_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DT_cross_ph_SFC DT_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DT_cross_ph_SFC DT_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DT_cross_ph_SFC DT_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< DT_cross_ph_SFC>(impl); }
	DT_cross_ph_SFC DT_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< DT_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< DT_cross_ph_SFC>(impl); }
	::Udm::StringAttr DT_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr DT_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< TypeBase_cross_ph_ESMoL> DT_cross_ph_SFC::tb() const { return ::Udm::PointerAttr< TypeBase_cross_ph_ESMoL>(impl, meta_tb); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> DT_cross_ph_SFC::DT_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_DT_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> DT_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DT_cross_ph_SFC::meta;
	::Uml::Attribute DT_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute DT_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole DT_cross_ph_SFC::meta_tb;
	::Uml::CompositionParentRole DT_cross_ph_SFC::meta_DT_cross_ph_SFC_parentrole;

	Struct_cross_ph_SFC::Struct_cross_ph_SFC() {}
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(const Struct_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(Struct_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	Struct_cross_ph_SFC Struct_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Struct_cross_ph_SFC& Struct_cross_ph_SFC::operator=(Struct_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Struct_cross_ph_SFC Struct_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Struct_cross_ph_SFC>(impl); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Struct_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Struct_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Struct_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Struct_cross_ph_SFC::meta;

	Class_cross_ph_SFC::Class_cross_ph_SFC() {}
	Class_cross_ph_SFC::Class_cross_ph_SFC(::Udm::ObjectImpl *impl) : CompoundStatement_cross_ph_SFC(impl) {}
	Class_cross_ph_SFC::Class_cross_ph_SFC(const Class_cross_ph_SFC &master) : CompoundStatement_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Class_cross_ph_SFC::Class_cross_ph_SFC(Class_cross_ph_SFC &&master) : CompoundStatement_cross_ph_SFC(master) {};

	Class_cross_ph_SFC Class_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Class_cross_ph_SFC& Class_cross_ph_SFC::operator=(Class_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Class_cross_ph_SFC Class_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Class_cross_ph_SFC Class_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Class_cross_ph_SFC Class_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Class_cross_ph_SFC>(impl); }
	Class_cross_ph_SFC Class_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Class_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Class_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Class_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Class_cross_ph_SFC::meta;

	Project_cross_ph_SFC::Project_cross_ph_SFC() {}
	Project_cross_ph_SFC::Project_cross_ph_SFC(::Udm::ObjectImpl *impl) : CompoundStatement_cross_ph_SFC(impl) {}
	Project_cross_ph_SFC::Project_cross_ph_SFC(const Project_cross_ph_SFC &master) : CompoundStatement_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Project_cross_ph_SFC::Project_cross_ph_SFC(Project_cross_ph_SFC &&master) : CompoundStatement_cross_ph_SFC(master) {};

	Project_cross_ph_SFC Project_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Project_cross_ph_SFC& Project_cross_ph_SFC::operator=(Project_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Project_cross_ph_SFC Project_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Project_cross_ph_SFC Project_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Project_cross_ph_SFC Project_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Project_cross_ph_SFC> Project_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Project_cross_ph_SFC>(impl); }
	Project_cross_ph_SFC Project_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Project_cross_ph_SFC> Project_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Project_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Project_cross_ph_SFC> Project_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Project_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Project_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Project_cross_ph_SFC::meta;

	Array_cross_ph_SFC::Array_cross_ph_SFC() {}
	Array_cross_ph_SFC::Array_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	Array_cross_ph_SFC::Array_cross_ph_SFC(const Array_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Array_cross_ph_SFC::Array_cross_ph_SFC(Array_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	Array_cross_ph_SFC Array_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Array_cross_ph_SFC& Array_cross_ph_SFC::operator=(Array_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Array_cross_ph_SFC Array_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Array_cross_ph_SFC Array_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Array_cross_ph_SFC Array_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Array_cross_ph_SFC>(impl); }
	Array_cross_ph_SFC Array_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Array_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Array_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Array_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Array_cross_ph_SFC::meta;

	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC() {}
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(const BasicType_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(BasicType_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BasicType_cross_ph_SFC& BasicType_cross_ph_SFC::operator=(BasicType_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC>(impl); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< BasicType_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< BasicType_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> BasicType_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BasicType_cross_ph_SFC::meta;

	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL() {}
	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : TypeBase_cross_ph_ESMoL(impl) {}
	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL(const TypeStruct_cross_ph_ESMoL &master) : TypeBase_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL(TypeStruct_cross_ph_ESMoL &&master) : TypeBase_cross_ph_ESMoL(master) {};

	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeStruct_cross_ph_ESMoL& TypeStruct_cross_ph_ESMoL::operator=(TypeStruct_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL>(impl); }
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TypeStruct_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeStruct_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeStruct_cross_ph_ESMoL::meta;

	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL() {}
	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : TypeBase_cross_ph_ESMoL(impl) {}
	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL(const Matrix_cross_ph_ESMoL &master) : TypeBase_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL(Matrix_cross_ph_ESMoL &&master) : TypeBase_cross_ph_ESMoL(master) {};

	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Matrix_cross_ph_ESMoL& Matrix_cross_ph_ESMoL::operator=(Matrix_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL>(impl); }
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Matrix_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Matrix_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Matrix_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Matrix_cross_ph_ESMoL::meta;

	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL() {}
	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL(const TypeBase_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL(TypeBase_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeBase_cross_ph_ESMoL& TypeBase_cross_ph_ESMoL::operator=(TypeBase_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL>(impl); }
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TypeBase_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr TypeBase_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr TypeBase_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< DT_cross_ph_SFC> TypeBase_cross_ph_ESMoL::dt() const { return ::Udm::PointerAttr< DT_cross_ph_SFC>(impl, meta_dt); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_TypeBase_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeBase_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeBase_cross_ph_ESMoL::meta;
	::Uml::Attribute TypeBase_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute TypeBase_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole TypeBase_cross_ph_ESMoL::meta_dt;
	::Uml::CompositionParentRole TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole;

	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL() {}
	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL(const TypeBaseRef_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL(TypeBaseRef_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeBaseRef_cross_ph_ESMoL& TypeBaseRef_cross_ph_ESMoL::operator=(TypeBaseRef_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL>(impl); }
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TypeBaseRef_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr TypeBaseRef_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr TypeBaseRef_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> TypeBaseRef_cross_ph_ESMoL::lvar() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_lvar); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_TypeBaseRef_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeBaseRef_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeBaseRef_cross_ph_ESMoL::meta;
	::Uml::Attribute TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute TypeBaseRef_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole TypeBaseRef_cross_ph_ESMoL::meta_lvar;
	::Uml::CompositionParentRole TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole;

	State_cross_ph_ESMoL::State_cross_ph_ESMoL() {}
	State_cross_ph_ESMoL::State_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	State_cross_ph_ESMoL::State_cross_ph_ESMoL(const State_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	State_cross_ph_ESMoL::State_cross_ph_ESMoL(State_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	State_cross_ph_ESMoL State_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	State_cross_ph_ESMoL& State_cross_ph_ESMoL::operator=(State_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	State_cross_ph_ESMoL State_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	State_cross_ph_ESMoL State_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	State_cross_ph_ESMoL State_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< State_cross_ph_ESMoL>(impl); }
	State_cross_ph_ESMoL State_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< State_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< State_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr State_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr State_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< Function_cross_ph_SFC> State_cross_ph_ESMoL::status() const { return ::Udm::AssocAttr< Function_cross_ph_SFC>(impl, meta_status); }
	::Udm::AssocAttr< Function_cross_ph_SFC> State_cross_ph_ESMoL::exec() const { return ::Udm::AssocAttr< Function_cross_ph_SFC>(impl, meta_exec); }
	::Udm::AssocAttr< Function_cross_ph_SFC> State_cross_ph_ESMoL::exit() const { return ::Udm::AssocAttr< Function_cross_ph_SFC>(impl, meta_exit); }
	::Udm::AssocAttr< Function_cross_ph_SFC> State_cross_ph_ESMoL::enter() const { return ::Udm::AssocAttr< Function_cross_ph_SFC>(impl, meta_enter); }
	::Udm::PointerAttr< CompoundStatement_cross_ph_SFC> State_cross_ph_ESMoL::xhic() const { return ::Udm::PointerAttr< CompoundStatement_cross_ph_SFC>(impl, meta_xhic); }
	::Udm::PointerAttr< CompoundStatement_cross_ph_SFC> State_cross_ph_ESMoL::xhcp() const { return ::Udm::PointerAttr< CompoundStatement_cross_ph_SFC>(impl, meta_xhcp); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> State_cross_ph_ESMoL::enterAtInitialization() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_enterAtInitialization); }
	::Udm::AssocAttr< StateLabel_cross_ph_SFC> State_cross_ph_ESMoL::src() const { return ::Udm::AssocAttr< StateLabel_cross_ph_SFC>(impl, meta_src); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::trPar() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_trPar); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::trSt() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_trSt); }
	::Udm::PointerAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::insTyp() const { return ::Udm::PointerAttr< State_cross_ph_ESMoL>(impl, meta_insTyp); }
	::Udm::AssocAttr< State_cross_ph_ESMoL> State_cross_ph_ESMoL::insts() const { return ::Udm::AssocAttr< State_cross_ph_ESMoL>(impl, meta_insts); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> State_cross_ph_ESMoL::State_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_State_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> State_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class State_cross_ph_ESMoL::meta;
	::Uml::Attribute State_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute State_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_status;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_exec;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_exit;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_enter;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_xhic;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_xhcp;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_enterAtInitialization;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_src;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_trPar;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_trSt;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_insTyp;
	::Uml::AssociationRole State_cross_ph_ESMoL::meta_insts;
	::Uml::CompositionParentRole State_cross_ph_ESMoL::meta_State_cross_ph_ESMoL_parentrole;

	Data_cross_ph_ESMoL::Data_cross_ph_ESMoL() {}
	Data_cross_ph_ESMoL::Data_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Data_cross_ph_ESMoL::Data_cross_ph_ESMoL(const Data_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Data_cross_ph_ESMoL::Data_cross_ph_ESMoL(Data_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	Data_cross_ph_ESMoL Data_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Data_cross_ph_ESMoL& Data_cross_ph_ESMoL::operator=(Data_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Data_cross_ph_ESMoL Data_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Data_cross_ph_ESMoL Data_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Data_cross_ph_ESMoL Data_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Data_cross_ph_ESMoL> Data_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Data_cross_ph_ESMoL>(impl); }
	Data_cross_ph_ESMoL Data_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Data_cross_ph_ESMoL> Data_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Data_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Data_cross_ph_ESMoL> Data_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Data_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr Data_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Data_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< LocalVar_cross_ph_SFC> Data_cross_ph_ESMoL::src() const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC>(impl, meta_src); }
	::Udm::PointerAttr< Data_cross_ph_ESMoL> Data_cross_ph_ESMoL::insTyp() const { return ::Udm::PointerAttr< Data_cross_ph_ESMoL>(impl, meta_insTyp); }
	::Udm::AssocAttr< Data_cross_ph_ESMoL> Data_cross_ph_ESMoL::insts() const { return ::Udm::AssocAttr< Data_cross_ph_ESMoL>(impl, meta_insts); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Data_cross_ph_ESMoL::Data_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_Data_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Data_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Data_cross_ph_ESMoL::meta;
	::Uml::Attribute Data_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute Data_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole Data_cross_ph_ESMoL::meta_src;
	::Uml::AssociationRole Data_cross_ph_ESMoL::meta_insTyp;
	::Uml::AssociationRole Data_cross_ph_ESMoL::meta_insts;
	::Uml::CompositionParentRole Data_cross_ph_ESMoL::meta_Data_cross_ph_ESMoL_parentrole;

	Event_cross_ph_ESMoL::Event_cross_ph_ESMoL() {}
	Event_cross_ph_ESMoL::Event_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Event_cross_ph_ESMoL::Event_cross_ph_ESMoL(const Event_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Event_cross_ph_ESMoL::Event_cross_ph_ESMoL(Event_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	Event_cross_ph_ESMoL Event_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Event_cross_ph_ESMoL& Event_cross_ph_ESMoL::operator=(Event_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Event_cross_ph_ESMoL Event_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Event_cross_ph_ESMoL Event_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Event_cross_ph_ESMoL Event_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Event_cross_ph_ESMoL> Event_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Event_cross_ph_ESMoL>(impl); }
	Event_cross_ph_ESMoL Event_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Event_cross_ph_ESMoL> Event_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Event_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Event_cross_ph_ESMoL> Event_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Event_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr Event_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Event_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< LocalVar_cross_ph_SFC> Event_cross_ph_ESMoL::src() const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC>(impl, meta_src); }
	::Udm::PointerAttr< Event_cross_ph_ESMoL> Event_cross_ph_ESMoL::insTyp() const { return ::Udm::PointerAttr< Event_cross_ph_ESMoL>(impl, meta_insTyp); }
	::Udm::AssocAttr< Event_cross_ph_ESMoL> Event_cross_ph_ESMoL::insts() const { return ::Udm::AssocAttr< Event_cross_ph_ESMoL>(impl, meta_insts); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Event_cross_ph_ESMoL::Event_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, meta_Event_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Event_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SFC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Event_cross_ph_ESMoL::meta;
	::Uml::Attribute Event_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute Event_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole Event_cross_ph_ESMoL::meta_src;
	::Uml::AssociationRole Event_cross_ph_ESMoL::meta_insTyp;
	::Uml::AssociationRole Event_cross_ph_ESMoL::meta_insts;
	::Uml::CompositionParentRole Event_cross_ph_ESMoL::meta_Event_cross_ph_ESMoL_parentrole;

	::Uml::Diagram meta;

	void CreateMeta() {
		// classes, with attributes, constraints and constraint definitions
		Array_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		BasicType_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Block_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Class_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		CompoundStatement_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		CompoundStatement_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(CompoundStatement_cross_ph_SFC::meta);
		CompoundStatement_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(CompoundStatement_cross_ph_SFC::meta);

		ConditionalBlock_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		ConditionalGroup_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		DT_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		DT_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(DT_cross_ph_SFC::meta);
		DT_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(DT_cross_ph_SFC::meta);

		Data_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		Data_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(Data_cross_ph_ESMoL::meta);
		Data_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(Data_cross_ph_ESMoL::meta);

		Event_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		Event_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(Event_cross_ph_ESMoL::meta);
		Event_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(Event_cross_ph_ESMoL::meta);

		Function_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		IterativeBlock_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		LocalVar_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		LocalVar_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(LocalVar_cross_ph_SFC::meta);
		LocalVar_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(LocalVar_cross_ph_SFC::meta);

		Matrix_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		Program_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Project_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		StateLabel_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		StateLabel_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(StateLabel_cross_ph_SFC::meta);
		StateLabel_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(StateLabel_cross_ph_SFC::meta);

		State_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		State_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(State_cross_ph_ESMoL::meta);
		State_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(State_cross_ph_ESMoL::meta);

		Struct_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		TypeBaseRef_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(TypeBaseRef_cross_ph_ESMoL::meta);
		TypeBaseRef_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(TypeBaseRef_cross_ph_ESMoL::meta);

		TypeBase_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		TypeBase_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(TypeBase_cross_ph_ESMoL::meta);
		TypeBase_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(TypeBase_cross_ph_ESMoL::meta);

		TypeStruct_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		_gen_cont::meta = ::Uml::Class::Create(meta);

	}

	void InitMeta() {
		// classes, with attributes, constraints and constraint definitions
		::Uml::InitClassProps(Array_cross_ph_SFC::meta, "Array_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(BasicType_cross_ph_SFC::meta, "BasicType_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Block_cross_ph_SFC::meta, "Block_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Class_cross_ph_SFC::meta, "Class_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(CompoundStatement_cross_ph_SFC::meta, "CompoundStatement_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(CompoundStatement_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(CompoundStatement_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ConditionalBlock_cross_ph_SFC::meta, "ConditionalBlock_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(ConditionalGroup_cross_ph_SFC::meta, "ConditionalGroup_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(DT_cross_ph_SFC::meta, "DT_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(DT_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(DT_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Data_cross_ph_ESMoL::meta, "Data_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(Data_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Event_cross_ph_ESMoL::meta, "Event_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(Event_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Event_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Function_cross_ph_SFC::meta, "Function_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(IterativeBlock_cross_ph_SFC::meta, "IterativeBlock_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(LocalVar_cross_ph_SFC::meta, "LocalVar_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(LocalVar_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(LocalVar_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Matrix_cross_ph_ESMoL::meta, "Matrix_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(Program_cross_ph_SFC::meta, "Program_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Project_cross_ph_SFC::meta, "Project_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(StateLabel_cross_ph_SFC::meta, "StateLabel_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(StateLabel_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(StateLabel_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(State_cross_ph_ESMoL::meta, "State_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(State_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Struct_cross_ph_SFC::meta, "Struct_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(TypeBaseRef_cross_ph_ESMoL::meta, "TypeBaseRef_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(TypeBaseRef_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TypeBase_cross_ph_ESMoL::meta, "TypeBase_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(TypeBase_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(TypeBase_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TypeStruct_cross_ph_ESMoL::meta, "TypeStruct_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(_gen_cont::meta, "_gen_cont", false, NULL, NULL);

		// associations
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_statusSt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_statusSt, "statusSt", true, false, 0, -1);
			State_cross_ph_ESMoL::meta_status = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_status, "status", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_execSt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_execSt, "execSt", true, false, 0, -1);
			State_cross_ph_ESMoL::meta_exec = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_exec, "exec", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_exitSt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_exitSt, "exitSt", true, false, 0, -1);
			State_cross_ph_ESMoL::meta_exit = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_exit, "exit", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_enterSt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_enterSt, "enterSt", true, false, 0, -1);
			State_cross_ph_ESMoL::meta_enter = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_enter, "enter", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			CompoundStatement_cross_ph_SFC::meta_immChild = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CompoundStatement_cross_ph_SFC::meta_immChild, "immChild", true, false, 0, 1);
			State_cross_ph_ESMoL::meta_xhic = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_xhic, "xhic", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			CompoundStatement_cross_ph_SFC::meta_commPar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CompoundStatement_cross_ph_SFC::meta_commPar, "commPar", true, false, 0, 1);
			State_cross_ph_ESMoL::meta_xhcp = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_xhcp, "xhcp", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_tbr = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_tbr, "tbr", true, false, 0, 1);
			TypeBaseRef_cross_ph_ESMoL::meta_lvar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypeBaseRef_cross_ph_ESMoL::meta_lvar, "lvar", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_topState = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_topState, "topState", true, false, 0, 1);
			State_cross_ph_ESMoL::meta_enterAtInitialization = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_enterAtInitialization, "enterAtInitialization", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_event = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_event, "event", true, false, 0, -1);
			Event_cross_ph_ESMoL::meta_src = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Event_cross_ph_ESMoL::meta_src, "src", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_data = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_data, "data", true, false, 0, -1);
			Data_cross_ph_ESMoL::meta_src = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Data_cross_ph_ESMoL::meta_src, "src", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			StateLabel_cross_ph_SFC::meta_dst = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateLabel_cross_ph_SFC::meta_dst, "dst", true, false, 0, -1);
			State_cross_ph_ESMoL::meta_src = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_src, "src", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			DT_cross_ph_SFC::meta_tb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(DT_cross_ph_SFC::meta_tb, "tb", true, false, 0, 1);
			TypeBase_cross_ph_ESMoL::meta_dt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypeBase_cross_ph_ESMoL::meta_dt, "dt", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			State_cross_ph_ESMoL::meta_trPar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_trPar, "trPar", true, false, 0, -1);
			State_cross_ph_ESMoL::meta_trSt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_trSt, "trSt", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			State_cross_ph_ESMoL::meta_insTyp = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_insTyp, "insTyp", true, false, 0, 1);
			State_cross_ph_ESMoL::meta_insts = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(State_cross_ph_ESMoL::meta_insts, "insts", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Data_cross_ph_ESMoL::meta_insTyp = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Data_cross_ph_ESMoL::meta_insTyp, "insTyp", true, false, 0, 1);
			Data_cross_ph_ESMoL::meta_insts = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Data_cross_ph_ESMoL::meta_insts, "insts", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Event_cross_ph_ESMoL::meta_insTyp = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Event_cross_ph_ESMoL::meta_insTyp, "insTyp", true, false, 0, 1);
			Event_cross_ph_ESMoL::meta_insts = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Event_cross_ph_ESMoL::meta_insts, "insts", true, false, 0, -1);

		}

		// compositions
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			CompoundStatement_cross_ph_SFC::meta_CompoundStatement_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(CompoundStatement_cross_ph_SFC::meta_CompoundStatement_cross_ph_SFC_parentrole, "CompoundStatement_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_CompoundStatement_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_CompoundStatement_cross_ph_SFC_childrole, "CompoundStatement_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			LocalVar_cross_ph_SFC::meta_LocalVar_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(LocalVar_cross_ph_SFC::meta_LocalVar_cross_ph_SFC_parentrole, "LocalVar_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_LocalVar_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_LocalVar_cross_ph_SFC_childrole, "LocalVar_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			StateLabel_cross_ph_SFC::meta_StateLabel_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(StateLabel_cross_ph_SFC::meta_StateLabel_cross_ph_SFC_parentrole, "StateLabel_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_StateLabel_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_StateLabel_cross_ph_SFC_childrole, "StateLabel_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			DT_cross_ph_SFC::meta_DT_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(DT_cross_ph_SFC::meta_DT_cross_ph_SFC_parentrole, "DT_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_DT_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_DT_cross_ph_SFC_childrole, "DT_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole, "TypeBase_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole, "TypeBase_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole, "TypeBaseRef_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole, "TypeBaseRef_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			State_cross_ph_ESMoL::meta_State_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(State_cross_ph_ESMoL::meta_State_cross_ph_ESMoL_parentrole, "State_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_State_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_State_cross_ph_ESMoL_childrole, "State_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Data_cross_ph_ESMoL::meta_Data_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Data_cross_ph_ESMoL::meta_Data_cross_ph_ESMoL_parentrole, "Data_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_Data_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Data_cross_ph_ESMoL_childrole, "Data_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Event_cross_ph_ESMoL::meta_Event_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Event_cross_ph_ESMoL::meta_Event_cross_ph_ESMoL_parentrole, "Event_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_Event_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Event_cross_ph_ESMoL_childrole, "Event_cross_ph_ESMoL_childrole", true, 0, -1);

		}

	}

	void InitMetaLinks() {
		Block_cross_ph_SFC::meta.subTypes() += Function_cross_ph_SFC::meta;
		Block_cross_ph_SFC::meta.subTypes() += ConditionalBlock_cross_ph_SFC::meta;
		Block_cross_ph_SFC::meta.subTypes() += IterativeBlock_cross_ph_SFC::meta;

		CompoundStatement_cross_ph_SFC::meta_immChild.target() = State_cross_ph_ESMoL::meta;
		CompoundStatement_cross_ph_SFC::meta_commPar.target() = State_cross_ph_ESMoL::meta;
		_gen_cont::meta_CompoundStatement_cross_ph_SFC_childrole.target() = CompoundStatement_cross_ph_SFC::meta;
		CompoundStatement_cross_ph_SFC::meta.subTypes() += Program_cross_ph_SFC::meta;
		CompoundStatement_cross_ph_SFC::meta.subTypes() += Block_cross_ph_SFC::meta;
		CompoundStatement_cross_ph_SFC::meta.subTypes() += ConditionalGroup_cross_ph_SFC::meta;
		CompoundStatement_cross_ph_SFC::meta.subTypes() += Class_cross_ph_SFC::meta;
		CompoundStatement_cross_ph_SFC::meta.subTypes() += Project_cross_ph_SFC::meta;

		DT_cross_ph_SFC::meta_tb.target() = TypeBase_cross_ph_ESMoL::meta;
		_gen_cont::meta_DT_cross_ph_SFC_childrole.target() = DT_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += Struct_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += Array_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += BasicType_cross_ph_SFC::meta;

		Data_cross_ph_ESMoL::meta_src.target() = LocalVar_cross_ph_SFC::meta;
		Data_cross_ph_ESMoL::meta_insTyp.target() = Data_cross_ph_ESMoL::meta;
		Data_cross_ph_ESMoL::meta_insts.target() = Data_cross_ph_ESMoL::meta;
		_gen_cont::meta_Data_cross_ph_ESMoL_childrole.target() = Data_cross_ph_ESMoL::meta;

		Event_cross_ph_ESMoL::meta_src.target() = LocalVar_cross_ph_SFC::meta;
		Event_cross_ph_ESMoL::meta_insTyp.target() = Event_cross_ph_ESMoL::meta;
		Event_cross_ph_ESMoL::meta_insts.target() = Event_cross_ph_ESMoL::meta;
		_gen_cont::meta_Event_cross_ph_ESMoL_childrole.target() = Event_cross_ph_ESMoL::meta;

		Function_cross_ph_SFC::meta_statusSt.target() = State_cross_ph_ESMoL::meta;
		Function_cross_ph_SFC::meta_execSt.target() = State_cross_ph_ESMoL::meta;
		Function_cross_ph_SFC::meta_exitSt.target() = State_cross_ph_ESMoL::meta;
		Function_cross_ph_SFC::meta_enterSt.target() = State_cross_ph_ESMoL::meta;

		LocalVar_cross_ph_SFC::meta_tbr.target() = TypeBaseRef_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_topState.target() = State_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_event.target() = Event_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_data.target() = Data_cross_ph_ESMoL::meta;
		_gen_cont::meta_LocalVar_cross_ph_SFC_childrole.target() = LocalVar_cross_ph_SFC::meta;

		StateLabel_cross_ph_SFC::meta_dst.target() = State_cross_ph_ESMoL::meta;
		_gen_cont::meta_StateLabel_cross_ph_SFC_childrole.target() = StateLabel_cross_ph_SFC::meta;

		State_cross_ph_ESMoL::meta_status.target() = Function_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_exec.target() = Function_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_exit.target() = Function_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_enter.target() = Function_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_xhic.target() = CompoundStatement_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_xhcp.target() = CompoundStatement_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_enterAtInitialization.target() = LocalVar_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_src.target() = StateLabel_cross_ph_SFC::meta;
		State_cross_ph_ESMoL::meta_trPar.target() = State_cross_ph_ESMoL::meta;
		State_cross_ph_ESMoL::meta_trSt.target() = State_cross_ph_ESMoL::meta;
		State_cross_ph_ESMoL::meta_insTyp.target() = State_cross_ph_ESMoL::meta;
		State_cross_ph_ESMoL::meta_insts.target() = State_cross_ph_ESMoL::meta;
		_gen_cont::meta_State_cross_ph_ESMoL_childrole.target() = State_cross_ph_ESMoL::meta;

		TypeBaseRef_cross_ph_ESMoL::meta_lvar.target() = LocalVar_cross_ph_SFC::meta;
		_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole.target() = TypeBaseRef_cross_ph_ESMoL::meta;

		TypeBase_cross_ph_ESMoL::meta_dt.target() = DT_cross_ph_SFC::meta;
		_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole.target() = TypeBase_cross_ph_ESMoL::meta;
		TypeBase_cross_ph_ESMoL::meta.subTypes() += TypeStruct_cross_ph_ESMoL::meta;
		TypeBase_cross_ph_ESMoL::meta.subTypes() += Matrix_cross_ph_ESMoL::meta;

		CompoundStatement_cross_ph_SFC::meta_CompoundStatement_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		LocalVar_cross_ph_SFC::meta_LocalVar_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		StateLabel_cross_ph_SFC::meta_StateLabel_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		DT_cross_ph_SFC::meta_DT_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		State_cross_ph_ESMoL::meta_State_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		Data_cross_ph_ESMoL::meta_Data_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		Event_cross_ph_ESMoL::meta_Event_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;

	}

	void InitMeta(const ::Uml::Diagram &parent) {
		// classes, with attributes, constraints and constraint definitions
		::Uml::SetClass(Array_cross_ph_SFC::meta, parent, "Array_cross_ph_SFC");

		::Uml::SetClass(BasicType_cross_ph_SFC::meta, parent, "BasicType_cross_ph_SFC");

		::Uml::SetClass(Block_cross_ph_SFC::meta, parent, "Block_cross_ph_SFC");

		::Uml::SetClass(Class_cross_ph_SFC::meta, parent, "Class_cross_ph_SFC");

		::Uml::SetClass(CompoundStatement_cross_ph_SFC::meta, parent, "CompoundStatement_cross_ph_SFC");
		::Uml::SetAttribute(CompoundStatement_cross_ph_SFC::meta_rem_sysname, CompoundStatement_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(CompoundStatement_cross_ph_SFC::meta_rem_id, CompoundStatement_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(ConditionalBlock_cross_ph_SFC::meta, parent, "ConditionalBlock_cross_ph_SFC");

		::Uml::SetClass(ConditionalGroup_cross_ph_SFC::meta, parent, "ConditionalGroup_cross_ph_SFC");

		::Uml::SetClass(DT_cross_ph_SFC::meta, parent, "DT_cross_ph_SFC");
		::Uml::SetAttribute(DT_cross_ph_SFC::meta_rem_sysname, DT_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(DT_cross_ph_SFC::meta_rem_id, DT_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(Data_cross_ph_ESMoL::meta, parent, "Data_cross_ph_ESMoL");
		::Uml::SetAttribute(Data_cross_ph_ESMoL::meta_rem_sysname, Data_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(Data_cross_ph_ESMoL::meta_rem_id, Data_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(Event_cross_ph_ESMoL::meta, parent, "Event_cross_ph_ESMoL");
		::Uml::SetAttribute(Event_cross_ph_ESMoL::meta_rem_sysname, Event_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(Event_cross_ph_ESMoL::meta_rem_id, Event_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(Function_cross_ph_SFC::meta, parent, "Function_cross_ph_SFC");

		::Uml::SetClass(IterativeBlock_cross_ph_SFC::meta, parent, "IterativeBlock_cross_ph_SFC");

		::Uml::SetClass(LocalVar_cross_ph_SFC::meta, parent, "LocalVar_cross_ph_SFC");
		::Uml::SetAttribute(LocalVar_cross_ph_SFC::meta_rem_sysname, LocalVar_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(LocalVar_cross_ph_SFC::meta_rem_id, LocalVar_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(Matrix_cross_ph_ESMoL::meta, parent, "Matrix_cross_ph_ESMoL");

		::Uml::SetClass(Program_cross_ph_SFC::meta, parent, "Program_cross_ph_SFC");

		::Uml::SetClass(Project_cross_ph_SFC::meta, parent, "Project_cross_ph_SFC");

		::Uml::SetClass(StateLabel_cross_ph_SFC::meta, parent, "StateLabel_cross_ph_SFC");
		::Uml::SetAttribute(StateLabel_cross_ph_SFC::meta_rem_sysname, StateLabel_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(StateLabel_cross_ph_SFC::meta_rem_id, StateLabel_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(State_cross_ph_ESMoL::meta, parent, "State_cross_ph_ESMoL");
		::Uml::SetAttribute(State_cross_ph_ESMoL::meta_rem_sysname, State_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(State_cross_ph_ESMoL::meta_rem_id, State_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(Struct_cross_ph_SFC::meta, parent, "Struct_cross_ph_SFC");

		::Uml::SetClass(TypeBaseRef_cross_ph_ESMoL::meta, parent, "TypeBaseRef_cross_ph_ESMoL");
		::Uml::SetAttribute(TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname, TypeBaseRef_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(TypeBaseRef_cross_ph_ESMoL::meta_rem_id, TypeBaseRef_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(TypeBase_cross_ph_ESMoL::meta, parent, "TypeBase_cross_ph_ESMoL");
		::Uml::SetAttribute(TypeBase_cross_ph_ESMoL::meta_rem_sysname, TypeBase_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(TypeBase_cross_ph_ESMoL::meta_rem_id, TypeBase_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(TypeStruct_cross_ph_ESMoL::meta, parent, "TypeStruct_cross_ph_ESMoL");

		::Uml::SetClass(_gen_cont::meta, parent, "_gen_cont");

	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
		// classes
		::Uml::SetAssocRole(CompoundStatement_cross_ph_SFC::meta_immChild, CompoundStatement_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "xhic");
		::Uml::SetAssocRole(CompoundStatement_cross_ph_SFC::meta_commPar, CompoundStatement_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "xhcp");
		::Uml::SetParentRole(CompoundStatement_cross_ph_SFC::meta_CompoundStatement_cross_ph_SFC_parentrole, CompoundStatement_cross_ph_SFC::meta, _gen_cont::meta, "CompoundStatement_cross_ph_SFC_childrole", "CompoundStatement_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(DT_cross_ph_SFC::meta_tb, DT_cross_ph_SFC::meta, TypeBase_cross_ph_ESMoL::meta, "dt");
		::Uml::SetParentRole(DT_cross_ph_SFC::meta_DT_cross_ph_SFC_parentrole, DT_cross_ph_SFC::meta, _gen_cont::meta, "DT_cross_ph_SFC_childrole", "DT_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(Data_cross_ph_ESMoL::meta_src, Data_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "data");
		::Uml::SetAssocRole(Data_cross_ph_ESMoL::meta_insTyp, Data_cross_ph_ESMoL::meta, Data_cross_ph_ESMoL::meta, "insts");
		::Uml::SetAssocRole(Data_cross_ph_ESMoL::meta_insts, Data_cross_ph_ESMoL::meta, Data_cross_ph_ESMoL::meta, "insTyp");
		::Uml::SetParentRole(Data_cross_ph_ESMoL::meta_Data_cross_ph_ESMoL_parentrole, Data_cross_ph_ESMoL::meta, _gen_cont::meta, "Data_cross_ph_ESMoL_childrole", "Data_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(Event_cross_ph_ESMoL::meta_src, Event_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "event");
		::Uml::SetAssocRole(Event_cross_ph_ESMoL::meta_insTyp, Event_cross_ph_ESMoL::meta, Event_cross_ph_ESMoL::meta, "insts");
		::Uml::SetAssocRole(Event_cross_ph_ESMoL::meta_insts, Event_cross_ph_ESMoL::meta, Event_cross_ph_ESMoL::meta, "insTyp");
		::Uml::SetParentRole(Event_cross_ph_ESMoL::meta_Event_cross_ph_ESMoL_parentrole, Event_cross_ph_ESMoL::meta, _gen_cont::meta, "Event_cross_ph_ESMoL_childrole", "Event_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_statusSt, Function_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "status");
		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_execSt, Function_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "exec");
		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_exitSt, Function_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "exit");
		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_enterSt, Function_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "enter");

		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_tbr, LocalVar_cross_ph_SFC::meta, TypeBaseRef_cross_ph_ESMoL::meta, "lvar");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_topState, LocalVar_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "enterAtInitialization");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_event, LocalVar_cross_ph_SFC::meta, Event_cross_ph_ESMoL::meta, "src");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_data, LocalVar_cross_ph_SFC::meta, Data_cross_ph_ESMoL::meta, "src");
		::Uml::SetParentRole(LocalVar_cross_ph_SFC::meta_LocalVar_cross_ph_SFC_parentrole, LocalVar_cross_ph_SFC::meta, _gen_cont::meta, "LocalVar_cross_ph_SFC_childrole", "LocalVar_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(StateLabel_cross_ph_SFC::meta_dst, StateLabel_cross_ph_SFC::meta, State_cross_ph_ESMoL::meta, "src");
		::Uml::SetParentRole(StateLabel_cross_ph_SFC::meta_StateLabel_cross_ph_SFC_parentrole, StateLabel_cross_ph_SFC::meta, _gen_cont::meta, "StateLabel_cross_ph_SFC_childrole", "StateLabel_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_status, State_cross_ph_ESMoL::meta, Function_cross_ph_SFC::meta, "statusSt");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_exec, State_cross_ph_ESMoL::meta, Function_cross_ph_SFC::meta, "execSt");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_exit, State_cross_ph_ESMoL::meta, Function_cross_ph_SFC::meta, "exitSt");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_enter, State_cross_ph_ESMoL::meta, Function_cross_ph_SFC::meta, "enterSt");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_xhic, State_cross_ph_ESMoL::meta, CompoundStatement_cross_ph_SFC::meta, "immChild");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_xhcp, State_cross_ph_ESMoL::meta, CompoundStatement_cross_ph_SFC::meta, "commPar");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_enterAtInitialization, State_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "topState");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_src, State_cross_ph_ESMoL::meta, StateLabel_cross_ph_SFC::meta, "dst");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_trPar, State_cross_ph_ESMoL::meta, State_cross_ph_ESMoL::meta, "trSt");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_trSt, State_cross_ph_ESMoL::meta, State_cross_ph_ESMoL::meta, "trPar");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_insTyp, State_cross_ph_ESMoL::meta, State_cross_ph_ESMoL::meta, "insts");
		::Uml::SetAssocRole(State_cross_ph_ESMoL::meta_insts, State_cross_ph_ESMoL::meta, State_cross_ph_ESMoL::meta, "insTyp");
		::Uml::SetParentRole(State_cross_ph_ESMoL::meta_State_cross_ph_ESMoL_parentrole, State_cross_ph_ESMoL::meta, _gen_cont::meta, "State_cross_ph_ESMoL_childrole", "State_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(TypeBaseRef_cross_ph_ESMoL::meta_lvar, TypeBaseRef_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "tbr");
		::Uml::SetParentRole(TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole, TypeBaseRef_cross_ph_ESMoL::meta, _gen_cont::meta, "TypeBaseRef_cross_ph_ESMoL_childrole", "TypeBaseRef_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(TypeBase_cross_ph_ESMoL::meta_dt, TypeBase_cross_ph_ESMoL::meta, DT_cross_ph_SFC::meta, "tb");
		::Uml::SetParentRole(TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole, TypeBase_cross_ph_ESMoL::meta, _gen_cont::meta, "TypeBase_cross_ph_ESMoL_childrole", "TypeBase_cross_ph_ESMoL_parentrole");

		::Uml::SetChildRole(_gen_cont::meta_CompoundStatement_cross_ph_SFC_childrole, _gen_cont::meta, CompoundStatement_cross_ph_SFC::meta, "CompoundStatement_cross_ph_SFC_parentrole", "CompoundStatement_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_LocalVar_cross_ph_SFC_childrole, _gen_cont::meta, LocalVar_cross_ph_SFC::meta, "LocalVar_cross_ph_SFC_parentrole", "LocalVar_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_StateLabel_cross_ph_SFC_childrole, _gen_cont::meta, StateLabel_cross_ph_SFC::meta, "StateLabel_cross_ph_SFC_parentrole", "StateLabel_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_DT_cross_ph_SFC_childrole, _gen_cont::meta, DT_cross_ph_SFC::meta, "DT_cross_ph_SFC_parentrole", "DT_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole, _gen_cont::meta, TypeBase_cross_ph_ESMoL::meta, "TypeBase_cross_ph_ESMoL_parentrole", "TypeBase_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole, _gen_cont::meta, TypeBaseRef_cross_ph_ESMoL::meta, "TypeBaseRef_cross_ph_ESMoL_parentrole", "TypeBaseRef_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_State_cross_ph_ESMoL_childrole, _gen_cont::meta, State_cross_ph_ESMoL::meta, "State_cross_ph_ESMoL_parentrole", "State_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Data_cross_ph_ESMoL_childrole, _gen_cont::meta, Data_cross_ph_ESMoL::meta, "Data_cross_ph_ESMoL_parentrole", "Data_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Event_cross_ph_ESMoL_childrole, _gen_cont::meta, Event_cross_ph_ESMoL::meta, "Event_cross_ph_ESMoL_parentrole", "Event_cross_ph_ESMoL_childrole");

	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("ESM2SFC.xsd", ESM2SFC_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("ESM2SFC.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "ESM2SFC", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("ESM2SFC", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("ESM2SFC");
		}
	} __regUnUsed;

}

