#ifndef MOBIES_ESM2SFC_H
#define MOBIES_ESM2SFC_H

// header file ESM2SFC.h generated from diagram ESM2SFC
// generated with Udm version 3.31 on Mon Jul 23 16:51:09 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace ESM2SFC {

	extern ::Uml::Diagram meta;
	class _gen_cont;
	class Function_cross_ph_SFC;
	class ConditionalBlock_cross_ph_SFC;
	class Program_cross_ph_SFC;
	class CompoundStatement_cross_ph_SFC;
	class Block_cross_ph_SFC;
	class ConditionalGroup_cross_ph_SFC;
	class IterativeBlock_cross_ph_SFC;
	class LocalVar_cross_ph_SFC;
	class StateLabel_cross_ph_SFC;
	class DT_cross_ph_SFC;
	class Struct_cross_ph_SFC;
	class Class_cross_ph_SFC;
	class Project_cross_ph_SFC;
	class Array_cross_ph_SFC;
	class BasicType_cross_ph_SFC;
	class TypeStruct_cross_ph_ESMoL;
	class Matrix_cross_ph_ESMoL;
	class TypeBase_cross_ph_ESMoL;
	class TypeBaseRef_cross_ph_ESMoL;
	class State_cross_ph_ESMoL;
	class Data_cross_ph_ESMoL;
	class Event_cross_ph_ESMoL;

	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

	class _gen_cont : public ::Udm::Object {
	public:
		_gen_cont();
		_gen_cont(::Udm::ObjectImpl *impl);
		_gen_cont(const _gen_cont &master);

#ifdef UDM_RVALUE
		_gen_cont(_gen_cont &&master);

		static _gen_cont Cast(::Udm::Object &&a);
		_gen_cont& operator=(_gen_cont &&a);

#endif
		static _gen_cont Cast(const ::Udm::Object &a);
		static _gen_cont Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		_gen_cont CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< _gen_cont> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< _gen_cont, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< _gen_cont, Pred>(impl); };
		_gen_cont CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< _gen_cont> Derived();
		template <class Pred> ::Udm::DerivedAttr< _gen_cont, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< _gen_cont, Pred>(impl); };
		::Udm::ArchetypeAttr< _gen_cont> Archetype() const;
		::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC> CompoundStatement_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC, Pred> CompoundStatement_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC, Pred>(impl, meta_CompoundStatement_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC, Pred> LocalVar_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC, Pred>(impl, meta_LocalVar_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC, Pred> StateLabel_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC, Pred>(impl, meta_StateLabel_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC> DT_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC, Pred> DT_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC, Pred>(impl, meta_DT_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL, Pred> TypeBase_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL, Pred>(impl, meta_TypeBase_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL, Pred> TypeBaseRef_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL, Pred>(impl, meta_TypeBaseRef_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL> State_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL, Pred> State_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL, Pred>(impl, meta_State_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL> Data_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL, Pred> Data_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL, Pred>(impl, meta_Data_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL> Event_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL, Pred> Event_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL, Pred>(impl, meta_Event_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SFC::Function_cross_ph_SFC> Function_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Function_cross_ph_SFC, Pred> Function_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Function_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::ConditionalBlock_cross_ph_SFC> ConditionalBlock_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::ConditionalBlock_cross_ph_SFC, Pred> ConditionalBlock_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::ConditionalBlock_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Program_cross_ph_SFC> Program_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Program_cross_ph_SFC, Pred> Program_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Program_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC> CompoundStatement_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC, Pred> CompoundStatement_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::CompoundStatement_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Block_cross_ph_SFC> Block_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Block_cross_ph_SFC, Pred> Block_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Block_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::ConditionalGroup_cross_ph_SFC> ConditionalGroup_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::ConditionalGroup_cross_ph_SFC, Pred> ConditionalGroup_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::ConditionalGroup_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::IterativeBlock_cross_ph_SFC, Pred> IterativeBlock_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::IterativeBlock_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC, Pred> LocalVar_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::LocalVar_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC, Pred> StateLabel_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::StateLabel_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC> DT_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC, Pred> DT_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::DT_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Struct_cross_ph_SFC> Struct_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Struct_cross_ph_SFC, Pred> Struct_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Struct_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Class_cross_ph_SFC> Class_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Class_cross_ph_SFC, Pred> Class_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Class_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Project_cross_ph_SFC> Project_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Project_cross_ph_SFC, Pred> Project_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Project_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Array_cross_ph_SFC> Array_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Array_cross_ph_SFC, Pred> Array_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Array_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::BasicType_cross_ph_SFC> BasicType_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::BasicType_cross_ph_SFC, Pred> BasicType_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::BasicType_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::TypeStruct_cross_ph_ESMoL, Pred> TypeStruct_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeStruct_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Matrix_cross_ph_ESMoL, Pred> Matrix_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Matrix_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL, Pred> TypeBase_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBase_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL, Pred> TypeBaseRef_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::TypeBaseRef_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL> State_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL, Pred> State_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::State_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL> Data_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL, Pred> Data_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Data_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL> Event_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL, Pred> Event_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SFC::Event_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_CompoundStatement_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_LocalVar_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_StateLabel_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_DT_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_TypeBase_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_TypeBaseRef_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_State_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_Data_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_Event_cross_ph_ESMoL_childrole;

	};

	class CompoundStatement_cross_ph_SFC : public ::Udm::Object {
	public:
		CompoundStatement_cross_ph_SFC();
		CompoundStatement_cross_ph_SFC(::Udm::ObjectImpl *impl);
		CompoundStatement_cross_ph_SFC(const CompoundStatement_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		CompoundStatement_cross_ph_SFC(CompoundStatement_cross_ph_SFC &&master);

		static CompoundStatement_cross_ph_SFC Cast(::Udm::Object &&a);
		CompoundStatement_cross_ph_SFC& operator=(CompoundStatement_cross_ph_SFC &&a);

#endif
		static CompoundStatement_cross_ph_SFC Cast(const ::Udm::Object &a);
		static CompoundStatement_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CompoundStatement_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CompoundStatement_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CompoundStatement_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CompoundStatement_cross_ph_SFC, Pred>(impl); };
		CompoundStatement_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CompoundStatement_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< CompoundStatement_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CompoundStatement_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< CompoundStatement_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< State_cross_ph_ESMoL> immChild() const;
		::Udm::PointerAttr< State_cross_ph_ESMoL> commPar() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> CompoundStatement_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_immChild;
		static ::Uml::AssociationRole meta_commPar;
		static ::Uml::CompositionParentRole meta_CompoundStatement_cross_ph_SFC_parentrole;

	};

	class Program_cross_ph_SFC :  public CompoundStatement_cross_ph_SFC {
	public:
		Program_cross_ph_SFC();
		Program_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Program_cross_ph_SFC(const Program_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Program_cross_ph_SFC(Program_cross_ph_SFC &&master);

		static Program_cross_ph_SFC Cast(::Udm::Object &&a);
		Program_cross_ph_SFC& operator=(Program_cross_ph_SFC &&a);

#endif
		static Program_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Program_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Program_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Program_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Program_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Program_cross_ph_SFC, Pred>(impl); };
		Program_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Program_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Program_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Program_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Program_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Block_cross_ph_SFC :  public CompoundStatement_cross_ph_SFC {
	public:
		Block_cross_ph_SFC();
		Block_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Block_cross_ph_SFC(const Block_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Block_cross_ph_SFC(Block_cross_ph_SFC &&master);

		static Block_cross_ph_SFC Cast(::Udm::Object &&a);
		Block_cross_ph_SFC& operator=(Block_cross_ph_SFC &&a);

#endif
		static Block_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Block_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Block_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Block_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Block_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Block_cross_ph_SFC, Pred>(impl); };
		Block_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Block_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Block_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Block_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Block_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Function_cross_ph_SFC :  public Block_cross_ph_SFC {
	public:
		Function_cross_ph_SFC();
		Function_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Function_cross_ph_SFC(const Function_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Function_cross_ph_SFC(Function_cross_ph_SFC &&master);

		static Function_cross_ph_SFC Cast(::Udm::Object &&a);
		Function_cross_ph_SFC& operator=(Function_cross_ph_SFC &&a);

#endif
		static Function_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Function_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Function_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Function_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Function_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Function_cross_ph_SFC, Pred>(impl); };
		Function_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Function_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Function_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Function_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Function_cross_ph_SFC> Archetype() const;
		::Udm::AssocAttr< State_cross_ph_ESMoL> statusSt() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> statusSt_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_statusSt); };
		::Udm::AssocAttr< State_cross_ph_ESMoL> execSt() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> execSt_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_execSt); };
		::Udm::AssocAttr< State_cross_ph_ESMoL> exitSt() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> exitSt_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_exitSt); };
		::Udm::AssocAttr< State_cross_ph_ESMoL> enterSt() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> enterSt_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_enterSt); };
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_statusSt;
		static ::Uml::AssociationRole meta_execSt;
		static ::Uml::AssociationRole meta_exitSt;
		static ::Uml::AssociationRole meta_enterSt;

	};

	class ConditionalBlock_cross_ph_SFC :  public Block_cross_ph_SFC {
	public:
		ConditionalBlock_cross_ph_SFC();
		ConditionalBlock_cross_ph_SFC(::Udm::ObjectImpl *impl);
		ConditionalBlock_cross_ph_SFC(const ConditionalBlock_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		ConditionalBlock_cross_ph_SFC(ConditionalBlock_cross_ph_SFC &&master);

		static ConditionalBlock_cross_ph_SFC Cast(::Udm::Object &&a);
		ConditionalBlock_cross_ph_SFC& operator=(ConditionalBlock_cross_ph_SFC &&a);

#endif
		static ConditionalBlock_cross_ph_SFC Cast(const ::Udm::Object &a);
		static ConditionalBlock_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ConditionalBlock_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ConditionalBlock_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ConditionalBlock_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ConditionalBlock_cross_ph_SFC, Pred>(impl); };
		ConditionalBlock_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ConditionalBlock_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< ConditionalBlock_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ConditionalBlock_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< ConditionalBlock_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class ConditionalGroup_cross_ph_SFC :  public CompoundStatement_cross_ph_SFC {
	public:
		ConditionalGroup_cross_ph_SFC();
		ConditionalGroup_cross_ph_SFC(::Udm::ObjectImpl *impl);
		ConditionalGroup_cross_ph_SFC(const ConditionalGroup_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		ConditionalGroup_cross_ph_SFC(ConditionalGroup_cross_ph_SFC &&master);

		static ConditionalGroup_cross_ph_SFC Cast(::Udm::Object &&a);
		ConditionalGroup_cross_ph_SFC& operator=(ConditionalGroup_cross_ph_SFC &&a);

#endif
		static ConditionalGroup_cross_ph_SFC Cast(const ::Udm::Object &a);
		static ConditionalGroup_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ConditionalGroup_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ConditionalGroup_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ConditionalGroup_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ConditionalGroup_cross_ph_SFC, Pred>(impl); };
		ConditionalGroup_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ConditionalGroup_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< ConditionalGroup_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ConditionalGroup_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< ConditionalGroup_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class IterativeBlock_cross_ph_SFC :  public Block_cross_ph_SFC {
	public:
		IterativeBlock_cross_ph_SFC();
		IterativeBlock_cross_ph_SFC(::Udm::ObjectImpl *impl);
		IterativeBlock_cross_ph_SFC(const IterativeBlock_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		IterativeBlock_cross_ph_SFC(IterativeBlock_cross_ph_SFC &&master);

		static IterativeBlock_cross_ph_SFC Cast(::Udm::Object &&a);
		IterativeBlock_cross_ph_SFC& operator=(IterativeBlock_cross_ph_SFC &&a);

#endif
		static IterativeBlock_cross_ph_SFC Cast(const ::Udm::Object &a);
		static IterativeBlock_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IterativeBlock_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC, Pred>(impl); };
		IterativeBlock_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< IterativeBlock_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class LocalVar_cross_ph_SFC : public ::Udm::Object {
	public:
		LocalVar_cross_ph_SFC();
		LocalVar_cross_ph_SFC(::Udm::ObjectImpl *impl);
		LocalVar_cross_ph_SFC(const LocalVar_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		LocalVar_cross_ph_SFC(LocalVar_cross_ph_SFC &&master);

		static LocalVar_cross_ph_SFC Cast(::Udm::Object &&a);
		LocalVar_cross_ph_SFC& operator=(LocalVar_cross_ph_SFC &&a);

#endif
		static LocalVar_cross_ph_SFC Cast(const ::Udm::Object &a);
		static LocalVar_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		LocalVar_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC, Pred>(impl); };
		LocalVar_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< LocalVar_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< LocalVar_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< LocalVar_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< TypeBaseRef_cross_ph_ESMoL> tbr() const;
		::Udm::PointerAttr< State_cross_ph_ESMoL> topState() const;
		::Udm::AssocAttr< Event_cross_ph_ESMoL> event() const;
		template <class Pred> ::Udm::AssocAttr< Event_cross_ph_ESMoL, Pred> event_sorted(const Pred &) const { return ::Udm::AssocAttr< Event_cross_ph_ESMoL, Pred>(impl, meta_event); };
		::Udm::AssocAttr< Data_cross_ph_ESMoL> data() const;
		template <class Pred> ::Udm::AssocAttr< Data_cross_ph_ESMoL, Pred> data_sorted(const Pred &) const { return ::Udm::AssocAttr< Data_cross_ph_ESMoL, Pred>(impl, meta_data); };
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> LocalVar_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_tbr;
		static ::Uml::AssociationRole meta_topState;
		static ::Uml::AssociationRole meta_event;
		static ::Uml::AssociationRole meta_data;
		static ::Uml::CompositionParentRole meta_LocalVar_cross_ph_SFC_parentrole;

	};

	class StateLabel_cross_ph_SFC : public ::Udm::Object {
	public:
		StateLabel_cross_ph_SFC();
		StateLabel_cross_ph_SFC(::Udm::ObjectImpl *impl);
		StateLabel_cross_ph_SFC(const StateLabel_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		StateLabel_cross_ph_SFC(StateLabel_cross_ph_SFC &&master);

		static StateLabel_cross_ph_SFC Cast(::Udm::Object &&a);
		StateLabel_cross_ph_SFC& operator=(StateLabel_cross_ph_SFC &&a);

#endif
		static StateLabel_cross_ph_SFC Cast(const ::Udm::Object &a);
		static StateLabel_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateLabel_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC, Pred>(impl); };
		StateLabel_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateLabel_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateLabel_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateLabel_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< State_cross_ph_ESMoL> dst() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> dst_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_dst); };
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> StateLabel_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_dst;
		static ::Uml::CompositionParentRole meta_StateLabel_cross_ph_SFC_parentrole;

	};

	class DT_cross_ph_SFC : public ::Udm::Object {
	public:
		DT_cross_ph_SFC();
		DT_cross_ph_SFC(::Udm::ObjectImpl *impl);
		DT_cross_ph_SFC(const DT_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		DT_cross_ph_SFC(DT_cross_ph_SFC &&master);

		static DT_cross_ph_SFC Cast(::Udm::Object &&a);
		DT_cross_ph_SFC& operator=(DT_cross_ph_SFC &&a);

#endif
		static DT_cross_ph_SFC Cast(const ::Udm::Object &a);
		static DT_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DT_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DT_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DT_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DT_cross_ph_SFC, Pred>(impl); };
		DT_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DT_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< DT_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DT_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< DT_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< TypeBase_cross_ph_ESMoL> tb() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> DT_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_tb;
		static ::Uml::CompositionParentRole meta_DT_cross_ph_SFC_parentrole;

	};

	class Struct_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		Struct_cross_ph_SFC();
		Struct_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Struct_cross_ph_SFC(const Struct_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Struct_cross_ph_SFC(Struct_cross_ph_SFC &&master);

		static Struct_cross_ph_SFC Cast(::Udm::Object &&a);
		Struct_cross_ph_SFC& operator=(Struct_cross_ph_SFC &&a);

#endif
		static Struct_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Struct_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Struct_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Struct_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Struct_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Struct_cross_ph_SFC, Pred>(impl); };
		Struct_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Struct_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Struct_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Struct_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Struct_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Class_cross_ph_SFC :  public CompoundStatement_cross_ph_SFC {
	public:
		Class_cross_ph_SFC();
		Class_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Class_cross_ph_SFC(const Class_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Class_cross_ph_SFC(Class_cross_ph_SFC &&master);

		static Class_cross_ph_SFC Cast(::Udm::Object &&a);
		Class_cross_ph_SFC& operator=(Class_cross_ph_SFC &&a);

#endif
		static Class_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Class_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Class_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Class_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Class_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Class_cross_ph_SFC, Pred>(impl); };
		Class_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Class_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Class_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Class_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Class_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Project_cross_ph_SFC :  public CompoundStatement_cross_ph_SFC {
	public:
		Project_cross_ph_SFC();
		Project_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Project_cross_ph_SFC(const Project_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Project_cross_ph_SFC(Project_cross_ph_SFC &&master);

		static Project_cross_ph_SFC Cast(::Udm::Object &&a);
		Project_cross_ph_SFC& operator=(Project_cross_ph_SFC &&a);

#endif
		static Project_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Project_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Project_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Project_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Project_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Project_cross_ph_SFC, Pred>(impl); };
		Project_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Project_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Project_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Project_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Project_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Array_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		Array_cross_ph_SFC();
		Array_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Array_cross_ph_SFC(const Array_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Array_cross_ph_SFC(Array_cross_ph_SFC &&master);

		static Array_cross_ph_SFC Cast(::Udm::Object &&a);
		Array_cross_ph_SFC& operator=(Array_cross_ph_SFC &&a);

#endif
		static Array_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Array_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Array_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Array_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Array_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Array_cross_ph_SFC, Pred>(impl); };
		Array_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Array_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Array_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Array_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Array_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class BasicType_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		BasicType_cross_ph_SFC();
		BasicType_cross_ph_SFC(::Udm::ObjectImpl *impl);
		BasicType_cross_ph_SFC(const BasicType_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		BasicType_cross_ph_SFC(BasicType_cross_ph_SFC &&master);

		static BasicType_cross_ph_SFC Cast(::Udm::Object &&a);
		BasicType_cross_ph_SFC& operator=(BasicType_cross_ph_SFC &&a);

#endif
		static BasicType_cross_ph_SFC Cast(const ::Udm::Object &a);
		static BasicType_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BasicType_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BasicType_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC, Pred>(impl); };
		BasicType_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BasicType_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< BasicType_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BasicType_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< BasicType_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class TypeBase_cross_ph_ESMoL : public ::Udm::Object {
	public:
		TypeBase_cross_ph_ESMoL();
		TypeBase_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TypeBase_cross_ph_ESMoL(const TypeBase_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TypeBase_cross_ph_ESMoL(TypeBase_cross_ph_ESMoL &&master);

		static TypeBase_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TypeBase_cross_ph_ESMoL& operator=(TypeBase_cross_ph_ESMoL &&a);

#endif
		static TypeBase_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TypeBase_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeBase_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL, Pred>(impl); };
		TypeBase_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeBase_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< DT_cross_ph_SFC> dt() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeBase_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_dt;
		static ::Uml::CompositionParentRole meta_TypeBase_cross_ph_ESMoL_parentrole;

	};

	class TypeStruct_cross_ph_ESMoL :  public TypeBase_cross_ph_ESMoL {
	public:
		TypeStruct_cross_ph_ESMoL();
		TypeStruct_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TypeStruct_cross_ph_ESMoL(const TypeStruct_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TypeStruct_cross_ph_ESMoL(TypeStruct_cross_ph_ESMoL &&master);

		static TypeStruct_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TypeStruct_cross_ph_ESMoL& operator=(TypeStruct_cross_ph_ESMoL &&a);

#endif
		static TypeStruct_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TypeStruct_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeStruct_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL, Pred>(impl); };
		TypeStruct_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeStruct_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Matrix_cross_ph_ESMoL :  public TypeBase_cross_ph_ESMoL {
	public:
		Matrix_cross_ph_ESMoL();
		Matrix_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Matrix_cross_ph_ESMoL(const Matrix_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Matrix_cross_ph_ESMoL(Matrix_cross_ph_ESMoL &&master);

		static Matrix_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Matrix_cross_ph_ESMoL& operator=(Matrix_cross_ph_ESMoL &&a);

#endif
		static Matrix_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Matrix_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Matrix_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL, Pred>(impl); };
		Matrix_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Matrix_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Matrix_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Matrix_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Matrix_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class TypeBaseRef_cross_ph_ESMoL : public ::Udm::Object {
	public:
		TypeBaseRef_cross_ph_ESMoL();
		TypeBaseRef_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TypeBaseRef_cross_ph_ESMoL(const TypeBaseRef_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TypeBaseRef_cross_ph_ESMoL(TypeBaseRef_cross_ph_ESMoL &&master);

		static TypeBaseRef_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TypeBaseRef_cross_ph_ESMoL& operator=(TypeBaseRef_cross_ph_ESMoL &&a);

#endif
		static TypeBaseRef_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TypeBaseRef_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeBaseRef_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL, Pred>(impl); };
		TypeBaseRef_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeBaseRef_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> lvar() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> TypeBaseRef_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_lvar;
		static ::Uml::CompositionParentRole meta_TypeBaseRef_cross_ph_ESMoL_parentrole;

	};

	class State_cross_ph_ESMoL : public ::Udm::Object {
	public:
		State_cross_ph_ESMoL();
		State_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		State_cross_ph_ESMoL(const State_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		State_cross_ph_ESMoL(State_cross_ph_ESMoL &&master);

		static State_cross_ph_ESMoL Cast(::Udm::Object &&a);
		State_cross_ph_ESMoL& operator=(State_cross_ph_ESMoL &&a);

#endif
		static State_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static State_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		State_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< State_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< State_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< State_cross_ph_ESMoL, Pred>(impl); };
		State_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< State_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< State_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< State_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< State_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< Function_cross_ph_SFC> status() const;
		template <class Pred> ::Udm::AssocAttr< Function_cross_ph_SFC, Pred> status_sorted(const Pred &) const { return ::Udm::AssocAttr< Function_cross_ph_SFC, Pred>(impl, meta_status); };
		::Udm::AssocAttr< Function_cross_ph_SFC> exec() const;
		template <class Pred> ::Udm::AssocAttr< Function_cross_ph_SFC, Pred> exec_sorted(const Pred &) const { return ::Udm::AssocAttr< Function_cross_ph_SFC, Pred>(impl, meta_exec); };
		::Udm::AssocAttr< Function_cross_ph_SFC> exit() const;
		template <class Pred> ::Udm::AssocAttr< Function_cross_ph_SFC, Pred> exit_sorted(const Pred &) const { return ::Udm::AssocAttr< Function_cross_ph_SFC, Pred>(impl, meta_exit); };
		::Udm::AssocAttr< Function_cross_ph_SFC> enter() const;
		template <class Pred> ::Udm::AssocAttr< Function_cross_ph_SFC, Pred> enter_sorted(const Pred &) const { return ::Udm::AssocAttr< Function_cross_ph_SFC, Pred>(impl, meta_enter); };
		::Udm::PointerAttr< CompoundStatement_cross_ph_SFC> xhic() const;
		::Udm::PointerAttr< CompoundStatement_cross_ph_SFC> xhcp() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> enterAtInitialization() const;
		::Udm::AssocAttr< StateLabel_cross_ph_SFC> src() const;
		template <class Pred> ::Udm::AssocAttr< StateLabel_cross_ph_SFC, Pred> src_sorted(const Pred &) const { return ::Udm::AssocAttr< StateLabel_cross_ph_SFC, Pred>(impl, meta_src); };
		::Udm::AssocAttr< State_cross_ph_ESMoL> trPar() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> trPar_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_trPar); };
		::Udm::AssocAttr< State_cross_ph_ESMoL> trSt() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> trSt_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_trSt); };
		::Udm::PointerAttr< State_cross_ph_ESMoL> insTyp() const;
		::Udm::AssocAttr< State_cross_ph_ESMoL> insts() const;
		template <class Pred> ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred> insts_sorted(const Pred &) const { return ::Udm::AssocAttr< State_cross_ph_ESMoL, Pred>(impl, meta_insts); };
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> State_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_status;
		static ::Uml::AssociationRole meta_exec;
		static ::Uml::AssociationRole meta_exit;
		static ::Uml::AssociationRole meta_enter;
		static ::Uml::AssociationRole meta_xhic;
		static ::Uml::AssociationRole meta_xhcp;
		static ::Uml::AssociationRole meta_enterAtInitialization;
		static ::Uml::AssociationRole meta_src;
		static ::Uml::AssociationRole meta_trPar;
		static ::Uml::AssociationRole meta_trSt;
		static ::Uml::AssociationRole meta_insTyp;
		static ::Uml::AssociationRole meta_insts;
		static ::Uml::CompositionParentRole meta_State_cross_ph_ESMoL_parentrole;

	};

	class Data_cross_ph_ESMoL : public ::Udm::Object {
	public:
		Data_cross_ph_ESMoL();
		Data_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Data_cross_ph_ESMoL(const Data_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Data_cross_ph_ESMoL(Data_cross_ph_ESMoL &&master);

		static Data_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Data_cross_ph_ESMoL& operator=(Data_cross_ph_ESMoL &&a);

#endif
		static Data_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Data_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Data_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Data_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Data_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Data_cross_ph_ESMoL, Pred>(impl); };
		Data_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Data_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Data_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Data_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Data_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< LocalVar_cross_ph_SFC> src() const;
		template <class Pred> ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred> src_sorted(const Pred &) const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred>(impl, meta_src); };
		::Udm::PointerAttr< Data_cross_ph_ESMoL> insTyp() const;
		::Udm::AssocAttr< Data_cross_ph_ESMoL> insts() const;
		template <class Pred> ::Udm::AssocAttr< Data_cross_ph_ESMoL, Pred> insts_sorted(const Pred &) const { return ::Udm::AssocAttr< Data_cross_ph_ESMoL, Pred>(impl, meta_insts); };
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Data_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_src;
		static ::Uml::AssociationRole meta_insTyp;
		static ::Uml::AssociationRole meta_insts;
		static ::Uml::CompositionParentRole meta_Data_cross_ph_ESMoL_parentrole;

	};

	class Event_cross_ph_ESMoL : public ::Udm::Object {
	public:
		Event_cross_ph_ESMoL();
		Event_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Event_cross_ph_ESMoL(const Event_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Event_cross_ph_ESMoL(Event_cross_ph_ESMoL &&master);

		static Event_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Event_cross_ph_ESMoL& operator=(Event_cross_ph_ESMoL &&a);

#endif
		static Event_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Event_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Event_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Event_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Event_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Event_cross_ph_ESMoL, Pred>(impl); };
		Event_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Event_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Event_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Event_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Event_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< LocalVar_cross_ph_SFC> src() const;
		template <class Pred> ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred> src_sorted(const Pred &) const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred>(impl, meta_src); };
		::Udm::PointerAttr< Event_cross_ph_ESMoL> insTyp() const;
		::Udm::AssocAttr< Event_cross_ph_ESMoL> insts() const;
		template <class Pred> ::Udm::AssocAttr< Event_cross_ph_ESMoL, Pred> insts_sorted(const Pred &) const { return ::Udm::AssocAttr< Event_cross_ph_ESMoL, Pred>(impl, meta_insts); };
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> Event_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SFC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_src;
		static ::Uml::AssociationRole meta_insTyp;
		static ::Uml::AssociationRole meta_insts;
		static ::Uml::CompositionParentRole meta_Event_cross_ph_ESMoL_parentrole;

	};

}

#endif // MOBIES_ESM2SFC_H
