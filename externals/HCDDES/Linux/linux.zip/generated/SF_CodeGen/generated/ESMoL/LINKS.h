#ifndef MOBIES_LINKS_H
#define MOBIES_LINKS_H

// header file LINKS.h generated from diagram LINKS
// generated with Udm version 3.31 on Mon Jul 23 16:51:11 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace ESMoL {
	class TypeStruct;
	class Matrix;
	class TypeBase;
	class TypeBaseRef;
	class State;
	class Data;
	class Event;

}

namespace SFC {
	class Function;
	class ConditionalBlock;
	class Program;
	class CompoundStatement;
	class Block;
	class ConditionalGroup;
	class IterativeBlock;
	class LocalVar;
	class StateLabel;
	class DT;
	class Struct;
	class Class;
	class Project;
	class Array;
	class BasicType;

}

namespace LINKS {

	extern ::Uml::Diagram meta;
	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

}

#endif // MOBIES_LINKS_H
