// cpp (meta datanetwork format) source file LINKS.cpp
// generated from diagram LINKS
// generated on Mon Jul 23 16:51:11 2012

#include "LINKS.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "LINKS_xsd.h"
using namespace std;

// cross-package metainformation header file
#include "ESM2SFC.h"

namespace LINKS {

	::Uml::Diagram meta;

	void CreateMeta() {
	}

	void InitMeta() {
	}

	void InitMetaLinks() {
	}

	void InitMeta(const ::Uml::Diagram &parent) {
	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("LINKS.xsd", LINKS_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

		ESM2SFC::Initialize();
	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("LINKS.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "LINKS", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		UDM_ASSERT(::ESM2SFC::meta != ::Udm::null);
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("LINKS", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("LINKS");
		}
	} __regUnUsed;

}

