/* ctestgen.h generated on Tue Jun 19 13:55:29 2012
 */

#include <UdmBase.h>
#include <UdmUtil.h>
#include <cint_string.h>
#include "Links.h"
#include "SFC.h"
#include "ctest.h"

typedef std::list< Udm::Object> Packets_t;

// Forward declarations.
class Start_0;
class GetMainClass_3;
class GetTopClass_8;
class MainCalled_14;
class MainNotCalled_30;
class GetClasses_4b;
class GetProgram_68;
class IncludeFiles_81;
class InsertIncludes_86;
class PrintContext_9a;
class PrintNewline_9f;
class PrintContext_b3;
class MakeLoops_bc;
class AddBooleanVar_de;
class BoolTest_118;
class IsBool_14d;
class Otherwise_196;
class BreakPath_1db;
class Break_206;
class ProcessStruct_229;
class StructExprs_24f;
class AddIndexes_28d;
class AddIndexes_2af;
class AddFirstIndex_2e3;
class AddIndex_342;
class SkipArray_3a5;
class ArrayTest_3fc;
class NullArray_448;
class Array_49f;
class Otherwise_4f1;
class GetStartLoop_55b;
class NextIterate_581;
class IterateTest_5d0;
class IterativeBlock_612;
class Otherwise_667;
class StartArray_6b9;
class SkipArray_716;
class ColumnMajor_74a;
class AddLoopBounds_775;
class AddBound_7a0;
class ArrayTest_7da;
class NullArray_7f5;
class Array_819;
class SkipArray_83b;
class MakeArrayLoop_868;
class SkipArray_8b6;
class ArrayTest_8fa;
class NullArray_937;
class Array_97d;
class Otherwise_9bf;
class MemberDataType_a15;
class MakeArrayLoop_a3d;
class StructTest_a7f;
class BasicType_ab3;
class NullArray_ae5;
class Array_b1a;
class Struct_b4c;
class BasicType_b7e;
class MakePath_bb9;
class AddVar_c28;
class GetDT_c46;
class GetVarsForArgs_c71;
class GetSortedArgs_c98;
class CreateLoop_cd9;
class IncrementCounter_ce4;
class IncrementCounter_cf5;
class CreateLoop_d0d;
class MarkInitAndMain_d51;
class MarkMain_d56;
class MarkInit_d6c;
class GetClassFunctions_d82;
class CallModelMain_da1;
class GetContext_dac;
class CreateCallWithContext_deb;
class CreateLocalsForCall_e2c;
class NeedsVar_e37;
class HasLocalVar_e59;
class VarNeeded_e84;
class CreateLocalVars_eb9;
class GetArgs_eef;
class CallInit_f40;
class MarkContext_f49;
class CallInits_f6b;
class CreateMain_fa4;
class GetProject_fc0;

// Class declarations.
class Start_0
{
public:
	void operator()( const Packets_t& ins_1);

protected:
	void callGetProject_fd3( const Packets_t& projects_fc1);
	void callGetProgram_fd5( const Packets_t& projects_6a);
	void callIncludeFiles_fd7( const Packets_t& programs_82);
	void callGetMainClass_fd9( const Packets_t& programs_4);
	void callMarkInitAndMain_fdb( const Packets_t& classs_d52);
	void callCreateMain_fdd( const Packets_t& classs_fa5);
	void callCallInit_fdf( const Packets_t& classs_f41, const Packets_t& mains_f43);
	void callCreateLoop_fe2( const Packets_t& classs_cda, const Packets_t& mains_cdc);
	void callCallModelMain_fe5( const Packets_t& modelMains_da2, const Packets_t& mains_da4, const Packets_t& loops_da6);
	void callPrintContext_fe9( const Packets_t& modelMains_9b, const Packets_t& mains_9d);
};

class GetMainClass_3
{
public:
	void operator()( const Packets_t& programs_4, Packets_t& classs_6);

protected:
	void callGetClasses_64( const Packets_t& programs_4c);
	void callGetTopClass_66( const Packets_t& classs_9);

private:
	Packets_t* _class_7;
};

class GetTopClass_8
{
public:
	void operator()( const Packets_t& classs_9, Packets_t& classs_b);

protected:
	void executeOne( const Packets_t& classs_9);
	bool isInputUnique( const Udm::Object& class_f);

private:
	Packets_t* _class_c;
	Packets_t _class_d;
};

class MainCalled_14
{
public:
	bool operator()( const Packets_t& classs_15);

protected:
	bool isInputUnique( const Udm::Object& class_1b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::FunctionCall& Caller, SFC::Class& Class, SFC::Function& Function);
	void processInputPackets( const Packets_t& classs_15);
	bool patternMatcher( const Udm::Object& class_19);
	void outputAppender();

private:
	Packets_t _class_17;
	class Match
	{
	public:
		SFC::Class class_2a;
		SFC::Function function_2b;
		SFC::FunctionCall caller_2c;
	};

	std::list< Match> _matches;
};

class MainNotCalled_30
{
public:
	bool operator()( const Packets_t& classs_31, Packets_t& classs_33);

protected:
	bool isInputUnique( const Udm::Object& class_39);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class, SFC::Function& Function);
	void processInputPackets( const Packets_t& classs_31);
	bool patternMatcher( const Udm::Object& class_37);
	void outputAppender( const SFC::Class& class_49);

private:
	Packets_t* _class_34;
	Packets_t _class_35;
	class Match
	{
	public:
		SFC::Class class_45;
		SFC::Function function_46;
	};

	std::list< Match> _matches;
};

class GetClasses_4b
{
public:
	void operator()( const Packets_t& programs_4c, Packets_t& classs_4e);

protected:
	bool isInputUnique( const Udm::Object& program_54);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& programs_4c);
	bool patternMatcher( const Udm::Object& program_52);
	void effector();
	void outputAppender( const SFC::Class& class_62);

private:
	Packets_t* _class_4f;
	Packets_t _program_50;
	class Match
	{
	public:
		SFC::Program program_60;
		SFC::Class class_61;
	};

	std::list< Match> _matches;
};

class GetProgram_68
{
public:
	void operator()( const Packets_t& projects_6a, Packets_t& programs_69);

protected:
	bool isInputUnique( const Udm::Object& project_71);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& projects_6a);
	bool patternMatcher( const Udm::Object& project_6f);
	void effector();
	void outputAppender( const SFC::Program& program_7f);

private:
	Packets_t* _program_6c;
	Packets_t _project_6d;
	class Match
	{
	public:
		SFC::Project project_7d;
		SFC::Program program_7e;
	};

	std::list< Match> _matches;
};

class IncludeFiles_81
{
public:
	void operator()( const Packets_t& programs_82, Packets_t& programs_84);

protected:
	void callInsertIncludes_98( const Packets_t& programs_87);

private:
	Packets_t* _program_85;
};

class InsertIncludes_86
{
public:
	void operator()( const Packets_t& programs_87);

protected:
	bool isInputUnique( const Udm::Object& program_8d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& programs_87);
	bool patternMatcher( const Udm::Object& program_8b);
	void effector();

private:
	Packets_t _program_89;
	class Match
	{
	public:
		SFC::Program program_96;
	};

	std::list< Match> _matches;
};

class PrintContext_9a
{
public:
	void operator()( const Packets_t& modelMains_9b, const Packets_t& mains_9d);

protected:
	void callPrintContext_cd4( const Packets_t& modelMains_b4, const Packets_t& mains_b6);
	void callPrintNewline_cd7( const Packets_t& mains_a0);
};

class PrintNewline_9f
{
public:
	void operator()( const Packets_t& mains_a0);

protected:
	bool isInputUnique( const Udm::Object& main_a6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& mains_a0);
	bool patternMatcher( const Udm::Object& main_a4);
	void effector();

private:
	Packets_t _main_a2;
	class Match
	{
	public:
		SFC::CompoundStatement main_af;
	};

	std::list< Match> _matches;
};

class PrintContext_b3
{
public:
	void operator()( const Packets_t& modelMains_b4, const Packets_t& mains_b6, Packets_t& modelMains_b8, Packets_t& mains_b9);

protected:
	void callGetSortedArgs_cc4( const Packets_t& modelMains_c9a, const Packets_t& mains_c9c);
	void callGetVarsForArgs_cc7( const Packets_t& args_c72, const Packets_t& mains_c75);
	void callGetDT_cca( const Packets_t& vars_c47, const Packets_t& mains_c4b);
	void callMakeLoops_ccd( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1);
	void callAddVar_cd1( const Packets_t& argDeclBases_c29, const Packets_t& unaryExprss_c2b);

private:
	Packets_t* _modelMain_ba;
	Packets_t* _main_bb;
};

class MakeLoops_bc
{
public:
	void operator()( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1, Packets_t& passADBs_c3, Packets_t& passCSs_c4, Packets_t& ues_c5);

protected:
	void executeOne( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1);
	bool isInputUnique( const Udm::Object& passADB_cb, const Udm::Object& dt_d2, const Udm::Object& main_d9);
	void callStructTest_be7( const Packets_t& passADBs_a80, const Packets_t& dts_a82, const Packets_t& mains_a84);
	void callSkipArray_beb( const Packets_t& argDeclBases_717, const Packets_t& arrays_71a, const Packets_t& mains_71d);
	void callBasicType_bef( const Packets_t& argDeclBases_b7f, const Packets_t& basicTypes_b82, const Packets_t& compoundStatements_b85);
	void callMakePath_bf3( const Packets_t& argDeclBases_bba, const Packets_t& structs_bbc, const Packets_t& mains_bbf);
	void callMakeArrayLoop_bf7( const Packets_t& argDeclBases_a3e, const Packets_t& arrays_a41, const Packets_t& mains_a45);
	void callMakeLoops_bfb( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1);
	void callBoolTest_bff( const Packets_t& passADBs_119, const Packets_t& basictypes_11b, const Packets_t& css_11d, const Packets_t& ues_11f);
	void callProcessStruct_c04( const Packets_t& structs_22b, const Packets_t& mains_22d);
	void callColumnMajor_c07( const Packets_t& passADBs_74b, const Packets_t& toparrays_74d, const Packets_t& dts_74f, const Packets_t& mains_751);
	void callAddBooleanVar_c0c( const Packets_t& argDeclBases_df, const Packets_t& compoundStatements_e2, const Packets_t& unaryExprss_e5);
	void callMemberDataType_c10( const Packets_t& localVars_a16, const Packets_t& mains_a1a);
	void callMakeLoops_c13( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1);
	void callMakeLoops_c17( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1);
	void callAddIndexes_c1b( const Packets_t& passADBs_28e, const Packets_t& passCSs_290, const Packets_t& ues_292);
	void callStructExprs_c1f( const Packets_t& localVars_252, const Packets_t& compoundStatements_254, const Packets_t& unaryExprss_257);
	void callBreakPath_c23( const Packets_t& passADBs_1dc, const Packets_t& structs_1de, const Packets_t& css_1e0, const Packets_t& ues_1e2);

private:
	Packets_t* _passADB_c6;
	Packets_t* _passCS_c7;
	Packets_t* _ue_c8;
	Packets_t _passADB_c9;
	Packets_t _dt_d0;
	Packets_t _main_d7;
};

class AddBooleanVar_de
{
public:
	void operator()( const Packets_t& argDeclBases_df, const Packets_t& compoundStatements_e2, const Packets_t& unaryExprss_e5, Packets_t& argDeclBases_e1, Packets_t& compoundStatements_e4, Packets_t& newUnaryExprss_e7);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_ef, const Udm::Object& compoundStatement_f8, const Udm::Object& unaryExprs_101);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_df, const Packets_t& compoundStatements_e2, const Packets_t& unaryExprss_e5);
	bool patternMatcher( const Udm::Object& argDeclBase_ed, const Udm::Object& compoundStatement_f6, const Udm::Object& unaryExprs_ff);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_112, const SFC::CompoundStatement& compoundStatement_114, const SFC::UnaryExprs& newUnaryExprs_116);

private:
	Packets_t* _argDeclBase_e8;
	Packets_t* _compoundStatement_e9;
	Packets_t* _newUnaryExprs_ea;
	Packets_t _argDeclBase_eb;
	Packets_t _compoundStatement_f4;
	Packets_t _unaryExprs_fd;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_10a;
		SFC::CompoundStatement compoundStatement_10b;
		SFC::UnaryExprs unaryExprs_10c;
	};

	std::list< Match> _matches;
};

class BoolTest_118
{
public:
	void operator()( const Packets_t& passADBs_119, const Packets_t& basictypes_11b, const Packets_t& css_11d, const Packets_t& ues_11f, Packets_t& passADBs_121, Packets_t& basictypes_122, Packets_t& css_123, Packets_t& ues_124, Packets_t& passADBs_125, Packets_t& basictypes_126, Packets_t& css_127, Packets_t& ues_128);

protected:
	void executeOne( const Packets_t& passADBs_119, const Packets_t& basictypes_11b, const Packets_t& css_11d, const Packets_t& ues_11f);
	bool isInputUnique( const Udm::Object& passADB_133, const Udm::Object& basictype_13a, const Udm::Object& cs_141, const Udm::Object& ue_148);

private:
	Packets_t* _passADB_129;
	Packets_t* _basictype_12a;
	Packets_t* _cs_12b;
	Packets_t* _ue_12c;
	Packets_t* _passADB_12d;
	Packets_t* _basictype_12e;
	Packets_t* _cs_12f;
	Packets_t* _ue_130;
	Packets_t _passADB_131;
	Packets_t _basictype_138;
	Packets_t _cs_13f;
	Packets_t _ue_146;
};

class IsBool_14d
{
public:
	bool operator()( const Packets_t& argDeclBases_14e, const Packets_t& basicTypes_151, const Packets_t& compoundStatements_154, const Packets_t& unaryExprss_157, Packets_t& argDeclBases_150, Packets_t& basicTypes_153, Packets_t& compoundStatements_156, Packets_t& unaryExprss_159);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_162, const Udm::Object& basicType_16b, const Udm::Object& compoundStatement_174, const Udm::Object& unaryExprs_17d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::BasicType& BasicType, SFC::CompoundStatement& CompoundStatement, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& argDeclBases_14e, const Packets_t& basicTypes_151, const Packets_t& compoundStatements_154, const Packets_t& unaryExprss_157);
	bool patternMatcher( const Udm::Object& argDeclBase_160, const Udm::Object& basicType_169, const Udm::Object& compoundStatement_172, const Udm::Object& unaryExprs_17b);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_18e, const SFC::BasicType& basicType_190, const SFC::CompoundStatement& compoundStatement_192, const SFC::UnaryExprs& unaryExprs_194);

private:
	Packets_t* _argDeclBase_15a;
	Packets_t* _basicType_15b;
	Packets_t* _compoundStatement_15c;
	Packets_t* _unaryExprs_15d;
	Packets_t _argDeclBase_15e;
	Packets_t _basicType_167;
	Packets_t _compoundStatement_170;
	Packets_t _unaryExprs_179;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_186;
		SFC::BasicType basicType_187;
		SFC::CompoundStatement compoundStatement_188;
		SFC::UnaryExprs unaryExprs_189;
	};

	std::list< Match> _matches;
};

class Otherwise_196
{
public:
	bool operator()( const Packets_t& argDeclBases_197, const Packets_t& basicTypes_19a, const Packets_t& compoundStatements_19d, const Packets_t& unaryExprss_1a0, Packets_t& argDeclBases_199, Packets_t& basicTypes_19c, Packets_t& compoundStatements_19f, Packets_t& unaryExprss_1a2);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_1ab, const Udm::Object& basicType_1b4, const Udm::Object& compoundStatement_1bd, const Udm::Object& unaryExprs_1c6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_197, const Packets_t& basicTypes_19a, const Packets_t& compoundStatements_19d, const Packets_t& unaryExprss_1a0);
	bool patternMatcher( const Udm::Object& argDeclBase_1a9, const Udm::Object& basicType_1b2, const Udm::Object& compoundStatement_1bb, const Udm::Object& unaryExprs_1c4);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_1d3, const SFC::BasicType& basicType_1d5, const SFC::CompoundStatement& compoundStatement_1d7, const SFC::UnaryExprs& unaryExprs_1d9);

private:
	Packets_t* _argDeclBase_1a3;
	Packets_t* _basicType_1a4;
	Packets_t* _compoundStatement_1a5;
	Packets_t* _unaryExprs_1a6;
	Packets_t _argDeclBase_1a7;
	Packets_t _basicType_1b0;
	Packets_t _compoundStatement_1b9;
	Packets_t _unaryExprs_1c2;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_1cf;
		SFC::BasicType basicType_1d0;
		SFC::CompoundStatement compoundStatement_1d1;
		SFC::UnaryExprs unaryExprs_1d2;
	};

	std::list< Match> _matches;
};

class BreakPath_1db
{
public:
	void operator()( const Packets_t& passADBs_1dc, const Packets_t& structs_1de, const Packets_t& css_1e0, const Packets_t& ues_1e2, Packets_t& passADBs_1e4, Packets_t& css_1e5, Packets_t& ues_1e6);

protected:
	void executeOne( const Packets_t& passADBs_1dc, const Packets_t& structs_1de, const Packets_t& css_1e0, const Packets_t& ues_1e2);
	bool isInputUnique( const Udm::Object& passADB_1ec, const Udm::Object& struct_1f3, const Udm::Object& cs_1fa, const Udm::Object& ue_201);
	void callBreak_226( const Packets_t& argDeclBases_207, const Packets_t& structs_209);

private:
	Packets_t* _passADB_1e7;
	Packets_t* _cs_1e8;
	Packets_t* _ue_1e9;
	Packets_t _passADB_1ea;
	Packets_t _struct_1f1;
	Packets_t _cs_1f8;
	Packets_t _ue_1ff;
};

class Break_206
{
public:
	void operator()( const Packets_t& argDeclBases_207, const Packets_t& structs_209);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_20f, const Udm::Object& struct_218);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_207, const Packets_t& structs_209);
	bool patternMatcher( const Udm::Object& argDeclBase_20d, const Udm::Object& struct_216);
	void effector();

private:
	Packets_t _argDeclBase_20b;
	Packets_t _struct_214;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_224;
		SFC::Struct struct_225;
	};

	std::list< Match> _matches;
};

class ProcessStruct_229
{
public:
	void operator()( const Packets_t& structs_22b, const Packets_t& mains_22d, Packets_t& localVars_22a, Packets_t& mains_22f);

protected:
	bool isInputUnique( const Udm::Object& struct_236, const Udm::Object& main_23f);
	void processInputPackets( const Packets_t& structs_22b, const Packets_t& mains_22d);
	bool patternMatcher( const Udm::Object& struct_234, const Udm::Object& main_23d);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar_24b, const SFC::CompoundStatement& main_24d);
	void sortOutputs();

private:
	Packets_t* _localVar_230;
	Packets_t* _main_231;
	Packets_t _struct_232;
	Packets_t _main_23b;
	class Match
	{
	public:
		SFC::Struct struct_248;
		SFC::CompoundStatement main_249;
		SFC::LocalVar localVar_24a;
	};

	std::list< Match> _matches;
};

class StructExprs_24f
{
public:
	void operator()( const Packets_t& localVars_252, const Packets_t& compoundStatements_254, const Packets_t& unaryExprss_257, Packets_t& argDeclBases_250, Packets_t& structs_251, Packets_t& compoundStatements_256, Packets_t& newUnaryExprss_259);

protected:
	bool isInputUnique( const Udm::Object& localVar_262, const Udm::Object& compoundStatement_26b, const Udm::Object& unaryExprs_274);
	void processInputPackets( const Packets_t& localVars_252, const Packets_t& compoundStatements_254, const Packets_t& unaryExprss_257);
	bool patternMatcher( const Udm::Object& localVar_260, const Udm::Object& compoundStatement_269, const Udm::Object& unaryExprs_272);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_285, const SFC::Struct& struct_287, const SFC::CompoundStatement& compoundStatement_289, const SFC::UnaryExprs& newUnaryExprs_28b);

private:
	Packets_t* _argDeclBase_25a;
	Packets_t* _struct_25b;
	Packets_t* _compoundStatement_25c;
	Packets_t* _newUnaryExprs_25d;
	Packets_t _localVar_25e;
	Packets_t _compoundStatement_267;
	Packets_t _unaryExprs_270;
	class Match
	{
	public:
		SFC::LocalVar localVar_27d;
		SFC::CompoundStatement compoundStatement_27e;
		SFC::UnaryExprs unaryExprs_27f;
		SFC::ArgDeclBase argDeclBase_280;
		SFC::Struct struct_281;
	};

	std::list< Match> _matches;
};

class AddIndexes_28d
{
public:
	void operator()( const Packets_t& passADBs_28e, const Packets_t& passCSs_290, const Packets_t& ues_292, Packets_t& passADBs_294, Packets_t& passCSs_295, Packets_t& ues_296);

protected:
	void executeOne( const Packets_t& passADBs_28e, const Packets_t& passCSs_290, const Packets_t& ues_292);
	bool isInputUnique( const Udm::Object& passADB_29c, const Udm::Object& passCS_2a3, const Udm::Object& ue_2aa);
	void callGetStartLoop_70c( const Packets_t& passADBs_55c, const Packets_t& passCSs_55e, const Packets_t& ues_560);
	void callAddIndexes_710( const Packets_t& passADBs_2b0, const Packets_t& arrays_2b2, const Packets_t& lastibs_2b4, const Packets_t& passCSs_2b6, const Packets_t& ues_2b8);

private:
	Packets_t* _passADB_297;
	Packets_t* _passCS_298;
	Packets_t* _ue_299;
	Packets_t _passADB_29a;
	Packets_t _passCS_2a1;
	Packets_t _ue_2a8;
};

class AddIndexes_2af
{
public:
	void operator()( const Packets_t& passADBs_2b0, const Packets_t& arrays_2b2, const Packets_t& lastibs_2b4, const Packets_t& passCSs_2b6, const Packets_t& ues_2b8, Packets_t& passADBs_2ba, Packets_t& passCSs_2bb, Packets_t& ues_2bc);

protected:
	void executeOne( const Packets_t& passADBs_2b0, const Packets_t& arrays_2b2, const Packets_t& lastibs_2b4, const Packets_t& passCSs_2b6, const Packets_t& ues_2b8);
	bool isInputUnique( const Udm::Object& passADB_2c2, const Udm::Object& array_2c9, const Udm::Object& lastib_2d0, const Udm::Object& passCS_2d7, const Udm::Object& ue_2de);
	void callAddFirstIndex_543( const Packets_t& argDeclBases_2e4, const Packets_t& arrays_2e7, const Packets_t& iterativeBlocks_2ea, const Packets_t& compoundStatements_2ed, const Packets_t& unaryExprss_2f0);
	void callArrayTest_549( const Packets_t& passADBs_3fd, const Packets_t& dts_3ff, const Packets_t& lastibs_401, const Packets_t& css_403, const Packets_t& ues_405);
	void callAddIndex_54f( const Packets_t& argDeclBases_343, const Packets_t& arrays_346, const Packets_t& iterativeBlocks_349, const Packets_t& compoundStatements_34c, const Packets_t& unaryExprss_34f);
	void callSkipArray_555( const Packets_t& argDeclBases_3a6, const Packets_t& arrays_3a9, const Packets_t& iterativeBlocks_3ac, const Packets_t& compoundStatements_3af, const Packets_t& unaryExprss_3b2);

private:
	Packets_t* _passADB_2bd;
	Packets_t* _passCS_2be;
	Packets_t* _ue_2bf;
	Packets_t _passADB_2c0;
	Packets_t _array_2c7;
	Packets_t _lastib_2ce;
	Packets_t _passCS_2d5;
	Packets_t _ue_2dc;
};

class AddFirstIndex_2e3
{
public:
	void operator()( const Packets_t& argDeclBases_2e4, const Packets_t& arrays_2e7, const Packets_t& iterativeBlocks_2ea, const Packets_t& compoundStatements_2ed, const Packets_t& unaryExprss_2f0, Packets_t& argDeclBases_2e6, Packets_t& dTs_2e9, Packets_t& iterativeBlocks_2ec, Packets_t& compoundStatements_2ef, Packets_t& newUnaryExprss_2f2);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_2fc, const Udm::Object& array_305, const Udm::Object& iterativeBlock_30e, const Udm::Object& compoundStatement_317, const Udm::Object& unaryExprs_320);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_2e4, const Packets_t& arrays_2e7, const Packets_t& iterativeBlocks_2ea, const Packets_t& compoundStatements_2ed, const Packets_t& unaryExprss_2f0);
	bool patternMatcher( const Udm::Object& argDeclBase_2fa, const Udm::Object& array_303, const Udm::Object& iterativeBlock_30c, const Udm::Object& compoundStatement_315, const Udm::Object& unaryExprs_31e);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_338, const SFC::DT& dT_33a, const SFC::IterativeBlock& iterativeBlock_33c, const SFC::CompoundStatement& compoundStatement_33e, const SFC::UnaryExprs& newUnaryExprs_340);

private:
	Packets_t* _argDeclBase_2f3;
	Packets_t* _dT_2f4;
	Packets_t* _iterativeBlock_2f5;
	Packets_t* _compoundStatement_2f6;
	Packets_t* _newUnaryExprs_2f7;
	Packets_t _argDeclBase_2f8;
	Packets_t _array_301;
	Packets_t _iterativeBlock_30a;
	Packets_t _compoundStatement_313;
	Packets_t _unaryExprs_31c;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_32b;
		SFC::Array array_32c;
		SFC::IterativeBlock iterativeBlock_32d;
		SFC::CompoundStatement compoundStatement_32e;
		SFC::UnaryExprs unaryExprs_32f;
		SFC::DT dT_330;
		SFC::LocalVar localVar_331;
	};

	std::list< Match> _matches;
};

class AddIndex_342
{
public:
	void operator()( const Packets_t& argDeclBases_343, const Packets_t& arrays_346, const Packets_t& iterativeBlocks_349, const Packets_t& compoundStatements_34c, const Packets_t& unaryExprss_34f, Packets_t& argDeclBases_345, Packets_t& dTs_348, Packets_t& lastIBs_34b, Packets_t& compoundStatements_34e, Packets_t& newUnaryExprss_351);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_35b, const Udm::Object& array_364, const Udm::Object& iterativeBlock_36d, const Udm::Object& compoundStatement_376, const Udm::Object& unaryExprs_37f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_343, const Packets_t& arrays_346, const Packets_t& iterativeBlocks_349, const Packets_t& compoundStatements_34c, const Packets_t& unaryExprss_34f);
	bool patternMatcher( const Udm::Object& argDeclBase_359, const Udm::Object& array_362, const Udm::Object& iterativeBlock_36b, const Udm::Object& compoundStatement_374, const Udm::Object& unaryExprs_37d);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_39b, const SFC::DT& dT_39d, const SFC::IterativeBlock& lastIB_39f, const SFC::CompoundStatement& compoundStatement_3a1, const SFC::UnaryExprs& newUnaryExprs_3a3);

private:
	Packets_t* _argDeclBase_352;
	Packets_t* _dT_353;
	Packets_t* _lastIB_354;
	Packets_t* _compoundStatement_355;
	Packets_t* _newUnaryExprs_356;
	Packets_t _argDeclBase_357;
	Packets_t _array_360;
	Packets_t _iterativeBlock_369;
	Packets_t _compoundStatement_372;
	Packets_t _unaryExprs_37b;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_38d;
		SFC::Array array_38e;
		SFC::IterativeBlock iterativeBlock_38f;
		SFC::CompoundStatement compoundStatement_390;
		SFC::UnaryExprs unaryExprs_391;
		SFC::DT dT_392;
		SFC::IterativeBlock lastIB_393;
		SFC::LocalVar localVar_394;
	};

	std::list< Match> _matches;
};

class SkipArray_3a5
{
public:
	void operator()( const Packets_t& argDeclBases_3a6, const Packets_t& arrays_3a9, const Packets_t& iterativeBlocks_3ac, const Packets_t& compoundStatements_3af, const Packets_t& unaryExprss_3b2, Packets_t& argDeclBases_3a8, Packets_t& dTs_3ab, Packets_t& iterativeBlocks_3ae, Packets_t& compoundStatements_3b1, Packets_t& unaryExprss_3b4);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_3be, const Udm::Object& array_3c7, const Udm::Object& iterativeBlock_3d0, const Udm::Object& compoundStatement_3d9, const Udm::Object& unaryExprs_3e2);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_3a6, const Packets_t& arrays_3a9, const Packets_t& iterativeBlocks_3ac, const Packets_t& compoundStatements_3af, const Packets_t& unaryExprss_3b2);
	bool patternMatcher( const Udm::Object& argDeclBase_3bc, const Udm::Object& array_3c5, const Udm::Object& iterativeBlock_3ce, const Udm::Object& compoundStatement_3d7, const Udm::Object& unaryExprs_3e0);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_3f2, const SFC::DT& dT_3f4, const SFC::IterativeBlock& iterativeBlock_3f6, const SFC::CompoundStatement& compoundStatement_3f8, const SFC::UnaryExprs& unaryExprs_3fa);

private:
	Packets_t* _argDeclBase_3b5;
	Packets_t* _dT_3b6;
	Packets_t* _iterativeBlock_3b7;
	Packets_t* _compoundStatement_3b8;
	Packets_t* _unaryExprs_3b9;
	Packets_t _argDeclBase_3ba;
	Packets_t _array_3c3;
	Packets_t _iterativeBlock_3cc;
	Packets_t _compoundStatement_3d5;
	Packets_t _unaryExprs_3de;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_3ec;
		SFC::Array array_3ed;
		SFC::IterativeBlock iterativeBlock_3ee;
		SFC::CompoundStatement compoundStatement_3ef;
		SFC::UnaryExprs unaryExprs_3f0;
		SFC::DT dT_3f1;
	};

	std::list< Match> _matches;
};

class ArrayTest_3fc
{
public:
	void operator()( const Packets_t& passADBs_3fd, const Packets_t& dts_3ff, const Packets_t& lastibs_401, const Packets_t& css_403, const Packets_t& ues_405, Packets_t& passADBs_407, Packets_t& arrays_408, Packets_t& lastibs_409, Packets_t& css_40a, Packets_t& ues_40b, Packets_t& passADBs_40c, Packets_t& arrays_40d, Packets_t& lastibs_40e, Packets_t& css_40f, Packets_t& ues_410, Packets_t& passADBs_411, Packets_t& arrays_412, Packets_t& lastibs_413, Packets_t& css_414, Packets_t& ues_415);

protected:
	void executeOne( const Packets_t& passADBs_3fd, const Packets_t& dts_3ff, const Packets_t& lastibs_401, const Packets_t& css_403, const Packets_t& ues_405);
	bool isInputUnique( const Udm::Object& passADB_427, const Udm::Object& dt_42e, const Udm::Object& lastib_435, const Udm::Object& cs_43c, const Udm::Object& ue_443);

private:
	Packets_t* _passADB_416;
	Packets_t* _array_417;
	Packets_t* _lastib_418;
	Packets_t* _cs_419;
	Packets_t* _ue_41a;
	Packets_t* _passADB_41b;
	Packets_t* _array_41c;
	Packets_t* _lastib_41d;
	Packets_t* _cs_41e;
	Packets_t* _ue_41f;
	Packets_t* _passADB_420;
	Packets_t* _array_421;
	Packets_t* _lastib_422;
	Packets_t* _cs_423;
	Packets_t* _ue_424;
	Packets_t _passADB_425;
	Packets_t _dt_42c;
	Packets_t _lastib_433;
	Packets_t _cs_43a;
	Packets_t _ue_441;
};

class NullArray_448
{
public:
	bool operator()( const Packets_t& argDeclBases_449, const Packets_t& arrays_44c, const Packets_t& iterativeBlocks_44f, const Packets_t& compoundStatements_452, const Packets_t& unaryExprss_455, Packets_t& argDeclBases_44b, Packets_t& arrays_44e, Packets_t& iterativeBlocks_451, Packets_t& compoundStatements_454, Packets_t& unaryExprss_457);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_461, const Udm::Object& array_46a, const Udm::Object& iterativeBlock_473, const Udm::Object& compoundStatement_47c, const Udm::Object& unaryExprs_485);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Array& Array, SFC::CompoundStatement& CompoundStatement, SFC::IterativeBlock& IterativeBlock, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& argDeclBases_449, const Packets_t& arrays_44c, const Packets_t& iterativeBlocks_44f, const Packets_t& compoundStatements_452, const Packets_t& unaryExprss_455);
	bool patternMatcher( const Udm::Object& argDeclBase_45f, const Udm::Object& array_468, const Udm::Object& iterativeBlock_471, const Udm::Object& compoundStatement_47a, const Udm::Object& unaryExprs_483);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_495, const SFC::Array& array_497, const SFC::IterativeBlock& iterativeBlock_499, const SFC::CompoundStatement& compoundStatement_49b, const SFC::UnaryExprs& unaryExprs_49d);

private:
	Packets_t* _argDeclBase_458;
	Packets_t* _array_459;
	Packets_t* _iterativeBlock_45a;
	Packets_t* _compoundStatement_45b;
	Packets_t* _unaryExprs_45c;
	Packets_t _argDeclBase_45d;
	Packets_t _array_466;
	Packets_t _iterativeBlock_46f;
	Packets_t _compoundStatement_478;
	Packets_t _unaryExprs_481;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_48b;
		SFC::Array array_48c;
		SFC::IterativeBlock iterativeBlock_48d;
		SFC::CompoundStatement compoundStatement_48e;
		SFC::UnaryExprs unaryExprs_48f;
	};

	std::list< Match> _matches;
};

class Array_49f
{
public:
	bool operator()( const Packets_t& argDeclBases_4a0, const Packets_t& arrays_4a3, const Packets_t& iterativeBlocks_4a6, const Packets_t& compoundStatements_4a9, const Packets_t& unaryExprss_4ac, Packets_t& argDeclBases_4a2, Packets_t& arrays_4a5, Packets_t& iterativeBlocks_4a8, Packets_t& compoundStatements_4ab, Packets_t& unaryExprss_4ae);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_4b8, const Udm::Object& array_4c1, const Udm::Object& iterativeBlock_4ca, const Udm::Object& compoundStatement_4d3, const Udm::Object& unaryExprs_4dc);
	void processInputPackets( const Packets_t& argDeclBases_4a0, const Packets_t& arrays_4a3, const Packets_t& iterativeBlocks_4a6, const Packets_t& compoundStatements_4a9, const Packets_t& unaryExprss_4ac);
	bool patternMatcher( const Udm::Object& argDeclBase_4b6, const Udm::Object& array_4bf, const Udm::Object& iterativeBlock_4c8, const Udm::Object& compoundStatement_4d1, const Udm::Object& unaryExprs_4da);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_4e7, const SFC::Array& array_4e9, const SFC::IterativeBlock& iterativeBlock_4eb, const SFC::CompoundStatement& compoundStatement_4ed, const SFC::UnaryExprs& unaryExprs_4ef);

private:
	Packets_t* _argDeclBase_4af;
	Packets_t* _array_4b0;
	Packets_t* _iterativeBlock_4b1;
	Packets_t* _compoundStatement_4b2;
	Packets_t* _unaryExprs_4b3;
	Packets_t _argDeclBase_4b4;
	Packets_t _array_4bd;
	Packets_t _iterativeBlock_4c6;
	Packets_t _compoundStatement_4cf;
	Packets_t _unaryExprs_4d8;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_4e2;
		SFC::Array array_4e3;
		SFC::IterativeBlock iterativeBlock_4e4;
		SFC::CompoundStatement compoundStatement_4e5;
		SFC::UnaryExprs unaryExprs_4e6;
	};

	std::list< Match> _matches;
};

class Otherwise_4f1
{
public:
	bool operator()( const Packets_t& argDeclBases_4f2, const Packets_t& dTs_4f5, const Packets_t& lastIBs_4f8, const Packets_t& compoundStatements_4fb, const Packets_t& unaryExprss_4fe, Packets_t& argDeclBases_4f4, Packets_t& dTs_4f7, Packets_t& lastIBs_4fa, Packets_t& compoundStatements_4fd, Packets_t& unaryExprss_500);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_50a, const Udm::Object& dT_513, const Udm::Object& lastIB_51c, const Udm::Object& compoundStatement_525, const Udm::Object& unaryExprs_52e);
	void processInputPackets( const Packets_t& argDeclBases_4f2, const Packets_t& dTs_4f5, const Packets_t& lastIBs_4f8, const Packets_t& compoundStatements_4fb, const Packets_t& unaryExprss_4fe);
	bool patternMatcher( const Udm::Object& argDeclBase_508, const Udm::Object& dT_511, const Udm::Object& lastIB_51a, const Udm::Object& compoundStatement_523, const Udm::Object& unaryExprs_52c);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_539, const SFC::DT& dT_53b, const SFC::IterativeBlock& lastIB_53d, const SFC::CompoundStatement& compoundStatement_53f, const SFC::UnaryExprs& unaryExprs_541);

private:
	Packets_t* _argDeclBase_501;
	Packets_t* _dT_502;
	Packets_t* _lastIB_503;
	Packets_t* _compoundStatement_504;
	Packets_t* _unaryExprs_505;
	Packets_t _argDeclBase_506;
	Packets_t _dT_50f;
	Packets_t _lastIB_518;
	Packets_t _compoundStatement_521;
	Packets_t _unaryExprs_52a;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_534;
		SFC::DT dT_535;
		SFC::IterativeBlock lastIB_536;
		SFC::CompoundStatement compoundStatement_537;
		SFC::UnaryExprs unaryExprs_538;
	};

	std::list< Match> _matches;
};

class GetStartLoop_55b
{
public:
	void operator()( const Packets_t& passADBs_55c, const Packets_t& passCSs_55e, const Packets_t& ues_560, Packets_t& passADBs_562, Packets_t& arrays_563, Packets_t& lastibs_564, Packets_t& passCSs_565, Packets_t& ues_566);

protected:
	void executeOne( const Packets_t& passADBs_55c, const Packets_t& passCSs_55e, const Packets_t& ues_560);
	bool isInputUnique( const Udm::Object& passADB_56e, const Udm::Object& passCS_575, const Udm::Object& ue_57c);
	void callStartArray_6fd( const Packets_t& argDeclBases_6ba, const Packets_t& iterativeBlocks_6be, const Packets_t& unaryExprss_6c2);
	void callIterateTest_701( const Packets_t& passADBs_5d1, const Packets_t& arrays_5d3, const Packets_t& outeribs_5d5, const Packets_t& css_5d7, const Packets_t& ues_5d9);
	void callNextIterate_707( const Packets_t& argDeclBases_582, const Packets_t& arrays_585, const Packets_t& iterativeBlocks_588, const Packets_t& unaryExprss_58c);

private:
	Packets_t* _passADB_567;
	Packets_t* _array_568;
	Packets_t* _lastib_569;
	Packets_t* _passCS_56a;
	Packets_t* _ue_56b;
	Packets_t _passADB_56c;
	Packets_t _passCS_573;
	Packets_t _ue_57a;
};

class NextIterate_581
{
public:
	void operator()( const Packets_t& argDeclBases_582, const Packets_t& arrays_585, const Packets_t& iterativeBlocks_588, const Packets_t& unaryExprss_58c, Packets_t& argDeclBases_584, Packets_t& arrays_587, Packets_t& iterativeBlocks_58a, Packets_t& compoundStatements_58b, Packets_t& unaryExprss_58e);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_598, const Udm::Object& array_5a1, const Udm::Object& iterativeBlock_5aa, const Udm::Object& unaryExprs_5b3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_582, const Packets_t& arrays_585, const Packets_t& iterativeBlocks_588, const Packets_t& unaryExprss_58c);
	bool patternMatcher( const Udm::Object& argDeclBase_596, const Udm::Object& array_59f, const Udm::Object& iterativeBlock_5a8, const Udm::Object& unaryExprs_5b1);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_5c6, const SFC::Array& array_5c8, const SFC::IterativeBlock& iterativeBlock_5ca, const SFC::CompoundStatement& compoundStatement_5cc, const SFC::UnaryExprs& unaryExprs_5ce);

private:
	Packets_t* _argDeclBase_58f;
	Packets_t* _array_590;
	Packets_t* _iterativeBlock_591;
	Packets_t* _compoundStatement_592;
	Packets_t* _unaryExprs_593;
	Packets_t _argDeclBase_594;
	Packets_t _array_59d;
	Packets_t _iterativeBlock_5a6;
	Packets_t _unaryExprs_5af;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_5c1;
		SFC::Array array_5c2;
		SFC::IterativeBlock iterativeBlock_5c3;
		SFC::UnaryExprs unaryExprs_5c4;
		SFC::CompoundStatement compoundStatement_5c5;
	};

	std::list< Match> _matches;
};

class IterateTest_5d0
{
public:
	void operator()( const Packets_t& passADBs_5d1, const Packets_t& arrays_5d3, const Packets_t& outeribs_5d5, const Packets_t& css_5d7, const Packets_t& ues_5d9, Packets_t& passADBs_5db, Packets_t& arrays_5dc, Packets_t& outeribs_5dd, Packets_t& css_5de, Packets_t& ues_5df, Packets_t& passADBs_5e0, Packets_t& arrays_5e1, Packets_t& outeribs_5e2, Packets_t& css_5e3, Packets_t& ues_5e4);

protected:
	void executeOne( const Packets_t& passADBs_5d1, const Packets_t& arrays_5d3, const Packets_t& outeribs_5d5, const Packets_t& css_5d7, const Packets_t& ues_5d9);
	bool isInputUnique( const Udm::Object& passADB_5f1, const Udm::Object& array_5f8, const Udm::Object& outerib_5ff, const Udm::Object& cs_606, const Udm::Object& ue_60d);

private:
	Packets_t* _passADB_5e5;
	Packets_t* _array_5e6;
	Packets_t* _outerib_5e7;
	Packets_t* _cs_5e8;
	Packets_t* _ue_5e9;
	Packets_t* _passADB_5ea;
	Packets_t* _array_5eb;
	Packets_t* _outerib_5ec;
	Packets_t* _cs_5ed;
	Packets_t* _ue_5ee;
	Packets_t _passADB_5ef;
	Packets_t _array_5f6;
	Packets_t _outerib_5fd;
	Packets_t _cs_604;
	Packets_t _ue_60b;
};

class IterativeBlock_612
{
public:
	bool operator()( const Packets_t& argDeclBases_613, const Packets_t& arrays_616, const Packets_t& outerIBs_619, const Packets_t& iterativeBlocks_61c, const Packets_t& unaryExprss_61f, Packets_t& argDeclBases_615, Packets_t& arrays_618, Packets_t& outerIBs_61b, Packets_t& iterativeBlocks_61e, Packets_t& unaryExprss_621);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_62b, const Udm::Object& array_634, const Udm::Object& outerIB_63d, const Udm::Object& iterativeBlock_646, const Udm::Object& unaryExprs_64f);
	void processInputPackets( const Packets_t& argDeclBases_613, const Packets_t& arrays_616, const Packets_t& outerIBs_619, const Packets_t& iterativeBlocks_61c, const Packets_t& unaryExprss_61f);
	bool patternMatcher( const Udm::Object& argDeclBase_629, const Udm::Object& array_632, const Udm::Object& outerIB_63b, const Udm::Object& iterativeBlock_644, const Udm::Object& unaryExprs_64d);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_65d, const SFC::Array& array_65f, const SFC::IterativeBlock& outerIB_661, const SFC::IterativeBlock& iterativeBlock_663, const SFC::UnaryExprs& unaryExprs_665);

private:
	Packets_t* _argDeclBase_622;
	Packets_t* _array_623;
	Packets_t* _outerIB_624;
	Packets_t* _iterativeBlock_625;
	Packets_t* _unaryExprs_626;
	Packets_t _argDeclBase_627;
	Packets_t _array_630;
	Packets_t _outerIB_639;
	Packets_t _iterativeBlock_642;
	Packets_t _unaryExprs_64b;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_658;
		SFC::Array array_659;
		SFC::IterativeBlock outerIB_65a;
		SFC::IterativeBlock iterativeBlock_65b;
		SFC::UnaryExprs unaryExprs_65c;
	};

	std::list< Match> _matches;
};

class Otherwise_667
{
public:
	bool operator()( const Packets_t& argDeclBases_668, const Packets_t& arrays_66b, const Packets_t& outerIBs_66e, const Packets_t& compoundStatements_671, const Packets_t& unaryExprss_674, Packets_t& argDeclBases_66a, Packets_t& arrays_66d, Packets_t& outerIBs_670, Packets_t& compoundStatements_673, Packets_t& unaryExprss_676);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_680, const Udm::Object& array_689, const Udm::Object& outerIB_692, const Udm::Object& compoundStatement_69b, const Udm::Object& unaryExprs_6a4);
	void processInputPackets( const Packets_t& argDeclBases_668, const Packets_t& arrays_66b, const Packets_t& outerIBs_66e, const Packets_t& compoundStatements_671, const Packets_t& unaryExprss_674);
	bool patternMatcher( const Udm::Object& argDeclBase_67e, const Udm::Object& array_687, const Udm::Object& outerIB_690, const Udm::Object& compoundStatement_699, const Udm::Object& unaryExprs_6a2);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_6af, const SFC::Array& array_6b1, const SFC::IterativeBlock& outerIB_6b3, const SFC::CompoundStatement& compoundStatement_6b5, const SFC::UnaryExprs& unaryExprs_6b7);

private:
	Packets_t* _argDeclBase_677;
	Packets_t* _array_678;
	Packets_t* _outerIB_679;
	Packets_t* _compoundStatement_67a;
	Packets_t* _unaryExprs_67b;
	Packets_t _argDeclBase_67c;
	Packets_t _array_685;
	Packets_t _outerIB_68e;
	Packets_t _compoundStatement_697;
	Packets_t _unaryExprs_6a0;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_6aa;
		SFC::Array array_6ab;
		SFC::IterativeBlock outerIB_6ac;
		SFC::CompoundStatement compoundStatement_6ad;
		SFC::UnaryExprs unaryExprs_6ae;
	};

	std::list< Match> _matches;
};

class StartArray_6b9
{
public:
	void operator()( const Packets_t& argDeclBases_6ba, const Packets_t& iterativeBlocks_6be, const Packets_t& unaryExprss_6c2, Packets_t& argDeclBases_6bc, Packets_t& arrays_6bd, Packets_t& iterativeBlocks_6c0, Packets_t& compoundStatements_6c1, Packets_t& unaryExprss_6c4);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_6ce, const Udm::Object& iterativeBlock_6d7, const Udm::Object& unaryExprs_6e0);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_6ba, const Packets_t& iterativeBlocks_6be, const Packets_t& unaryExprss_6c2);
	bool patternMatcher( const Udm::Object& argDeclBase_6cc, const Udm::Object& iterativeBlock_6d5, const Udm::Object& unaryExprs_6de);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_6f3, const SFC::Array& array_6f5, const SFC::IterativeBlock& iterativeBlock_6f7, const SFC::CompoundStatement& compoundStatement_6f9, const SFC::UnaryExprs& unaryExprs_6fb);

private:
	Packets_t* _argDeclBase_6c5;
	Packets_t* _array_6c6;
	Packets_t* _iterativeBlock_6c7;
	Packets_t* _compoundStatement_6c8;
	Packets_t* _unaryExprs_6c9;
	Packets_t _argDeclBase_6ca;
	Packets_t _iterativeBlock_6d3;
	Packets_t _unaryExprs_6dc;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_6ee;
		SFC::IterativeBlock iterativeBlock_6ef;
		SFC::UnaryExprs unaryExprs_6f0;
		SFC::Array array_6f1;
		SFC::CompoundStatement compoundStatement_6f2;
	};

	std::list< Match> _matches;
};

class SkipArray_716
{
public:
	void operator()( const Packets_t& argDeclBases_717, const Packets_t& arrays_71a, const Packets_t& mains_71d, Packets_t& argDeclBases_719, Packets_t& dTs_71c, Packets_t& mains_71f);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_727, const Udm::Object& array_730, const Udm::Object& main_739);
	void processInputPackets( const Packets_t& argDeclBases_717, const Packets_t& arrays_71a, const Packets_t& mains_71d);
	bool patternMatcher( const Udm::Object& argDeclBase_725, const Udm::Object& array_72e, const Udm::Object& main_737);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_744, const SFC::DT& dT_746, const SFC::CompoundStatement& main_748);

private:
	Packets_t* _argDeclBase_720;
	Packets_t* _dT_721;
	Packets_t* _main_722;
	Packets_t _argDeclBase_723;
	Packets_t _array_72c;
	Packets_t _main_735;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_740;
		SFC::Array array_741;
		SFC::CompoundStatement main_742;
		SFC::DT dT_743;
	};

	std::list< Match> _matches;
};

class ColumnMajor_74a
{
public:
	void operator()( const Packets_t& passADBs_74b, const Packets_t& toparrays_74d, const Packets_t& dts_74f, const Packets_t& mains_751, Packets_t& passADBs_753, Packets_t& dts_754, Packets_t& mains_755);

protected:
	void executeOne( const Packets_t& passADBs_74b, const Packets_t& toparrays_74d, const Packets_t& dts_74f, const Packets_t& mains_751);
	bool isInputUnique( const Udm::Object& passADB_75b, const Udm::Object& toparray_762, const Udm::Object& dt_769, const Udm::Object& main_770);
	void callArrayTest_a01( const Packets_t& passADBs_8fb, const Packets_t& topArrays_8fd, const Packets_t& dts_8ff, const Packets_t& mains_901);
	void callAddLoopBounds_a06( const Packets_t& passADBs_776, const Packets_t& toparrays_778, const Packets_t& dts_77a, const Packets_t& mains_77c);
	void callMakeArrayLoop_a0b( const Packets_t& argDeclBases_869, const Packets_t& topArrays_86c, const Packets_t& arrays_86f, const Packets_t& mains_872);
	void callSkipArray_a10( const Packets_t& argDeclBases_8b7, const Packets_t& topArrays_8ba, const Packets_t& arrays_8bd, const Packets_t& mains_8c0);

private:
	Packets_t* _passADB_756;
	Packets_t* _dt_757;
	Packets_t* _main_758;
	Packets_t _passADB_759;
	Packets_t _toparray_760;
	Packets_t _dt_767;
	Packets_t _main_76e;
};

class AddLoopBounds_775
{
public:
	void operator()( const Packets_t& passADBs_776, const Packets_t& toparrays_778, const Packets_t& dts_77a, const Packets_t& mains_77c, Packets_t& passADBs_77e, Packets_t& dts_77f, Packets_t& mains_780);

protected:
	void executeOne( const Packets_t& passADBs_776, const Packets_t& toparrays_778, const Packets_t& dts_77a, const Packets_t& mains_77c);
	bool isInputUnique( const Udm::Object& passADB_786, const Udm::Object& toparray_78d, const Udm::Object& dt_794, const Udm::Object& main_79b);
	void callArrayTest_85f( const Packets_t& dts_7db, const Packets_t& mains_7dd);
	void callAddBound_862( const Packets_t& arrays_7a1, const Packets_t& loops_7a5);
	void callSkipArray_865( const Packets_t& arrays_83c, const Packets_t& mains_83f);

private:
	Packets_t* _passADB_781;
	Packets_t* _dt_782;
	Packets_t* _main_783;
	Packets_t _passADB_784;
	Packets_t _toparray_78b;
	Packets_t _dt_792;
	Packets_t _main_799;
};

class AddBound_7a0
{
public:
	void operator()( const Packets_t& arrays_7a1, const Packets_t& loops_7a5, Packets_t& dTs_7a3, Packets_t& compoundStatements_7a4);

protected:
	bool isInputUnique( const Udm::Object& array_7ad, const Udm::Object& loop_7b6);
	bool isGuardTrue( SFC::Array& Array, SFC::CompoundStatement& CompoundStatement, SFC::DT& DT, SFC::BinaryExprs& LessThan, SFC::IterativeBlock& Loop, SFC::Int& LoopBound, SFC::UserCode& UserCode);
	void processInputPackets( const Packets_t& arrays_7a1, const Packets_t& loops_7a5);
	bool patternMatcher( const Udm::Object& array_7ab, const Udm::Object& loop_7b4);
	void effector();
	void outputAppender( const SFC::DT& dT_7d6, const SFC::CompoundStatement& compoundStatement_7d8);

private:
	Packets_t* _dT_7a7;
	Packets_t* _compoundStatement_7a8;
	Packets_t _array_7a9;
	Packets_t _loop_7b2;
	class Match
	{
	public:
		SFC::Array array_7c8;
		SFC::IterativeBlock loop_7c9;
		SFC::DT dT_7ca;
		SFC::CompoundStatement compoundStatement_7cb;
		SFC::UserCode userCode_7cc;
		SFC::BinaryExprs lessThan_7cd;
		SFC::Int loopBound_7ce;
	};

	std::list< Match> _matches;
};

class ArrayTest_7da
{
public:
	void operator()( const Packets_t& dts_7db, const Packets_t& mains_7dd, Packets_t& nullarrays_7df, Packets_t& mains_7e0, Packets_t& arrays_7e1, Packets_t& mains_7e2);

protected:
	void executeOne( const Packets_t& dts_7db, const Packets_t& mains_7dd);
	bool isInputUnique( const Udm::Object& dt_7e9, const Udm::Object& main_7f0);

private:
	Packets_t* _nullarray_7e3;
	Packets_t* _main_7e4;
	Packets_t* _array_7e5;
	Packets_t* _main_7e6;
	Packets_t _dt_7e7;
	Packets_t _main_7ee;
};

class NullArray_7f5
{
public:
	bool operator()( const Packets_t& arrays_7f6, const Packets_t& mains_7f9, Packets_t& arrays_7f8, Packets_t& mains_7fb);

protected:
	bool isInputUnique( const Udm::Object& array_802, const Udm::Object& main_80b);
	bool isGuardTrue( SFC::Array& Array, SFC::CompoundStatement& Main);
	void processInputPackets( const Packets_t& arrays_7f6, const Packets_t& mains_7f9);
	bool patternMatcher( const Udm::Object& array_800, const Udm::Object& main_809);
	void outputAppender( const SFC::Array& array_815, const SFC::CompoundStatement& main_817);

private:
	Packets_t* _array_7fc;
	Packets_t* _main_7fd;
	Packets_t _array_7fe;
	Packets_t _main_807;
	class Match
	{
	public:
		SFC::Array array_811;
		SFC::CompoundStatement main_812;
	};

	std::list< Match> _matches;
};

class Array_819
{
public:
	bool operator()( const Packets_t& arrays_81a, const Packets_t& mains_81d, Packets_t& arrays_81c, Packets_t& mains_81f);

protected:
	bool isInputUnique( const Udm::Object& array_826, const Udm::Object& main_82f);
	void processInputPackets( const Packets_t& arrays_81a, const Packets_t& mains_81d);
	bool patternMatcher( const Udm::Object& array_824, const Udm::Object& main_82d);
	void outputAppender( const SFC::Array& array_837, const SFC::CompoundStatement& main_839);

private:
	Packets_t* _array_820;
	Packets_t* _main_821;
	Packets_t _array_822;
	Packets_t _main_82b;
	class Match
	{
	public:
		SFC::Array array_835;
		SFC::CompoundStatement main_836;
	};

	std::list< Match> _matches;
};

class SkipArray_83b
{
public:
	void operator()( const Packets_t& arrays_83c, const Packets_t& mains_83f, Packets_t& dTs_83e, Packets_t& mains_841);

protected:
	bool isInputUnique( const Udm::Object& array_848, const Udm::Object& main_851);
	void processInputPackets( const Packets_t& arrays_83c, const Packets_t& mains_83f);
	bool patternMatcher( const Udm::Object& array_846, const Udm::Object& main_84f);
	void effector();
	void outputAppender( const SFC::DT& dT_85b, const SFC::CompoundStatement& main_85d);

private:
	Packets_t* _dT_842;
	Packets_t* _main_843;
	Packets_t _array_844;
	Packets_t _main_84d;
	class Match
	{
	public:
		SFC::Array array_858;
		SFC::CompoundStatement main_859;
		SFC::DT dT_85a;
	};

	std::list< Match> _matches;
};

class MakeArrayLoop_868
{
public:
	void operator()( const Packets_t& argDeclBases_869, const Packets_t& topArrays_86c, const Packets_t& arrays_86f, const Packets_t& mains_872, Packets_t& argDeclBases_86b, Packets_t& topArrays_86e, Packets_t& dTs_871, Packets_t& loops_874);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_87d, const Udm::Object& topArray_886, const Udm::Object& array_88f, const Udm::Object& main_898);
	void processInputPackets( const Packets_t& argDeclBases_869, const Packets_t& topArrays_86c, const Packets_t& arrays_86f, const Packets_t& mains_872);
	bool patternMatcher( const Udm::Object& argDeclBase_87b, const Udm::Object& topArray_884, const Udm::Object& array_88d, const Udm::Object& main_896);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_8ae, const SFC::Array& topArray_8b0, const SFC::DT& dT_8b2, const SFC::IterativeBlock& loop_8b4);

private:
	Packets_t* _argDeclBase_875;
	Packets_t* _topArray_876;
	Packets_t* _dT_877;
	Packets_t* _loop_878;
	Packets_t _argDeclBase_879;
	Packets_t _topArray_882;
	Packets_t _array_88b;
	Packets_t _main_894;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_89f;
		SFC::Array topArray_8a0;
		SFC::Array array_8a1;
		SFC::CompoundStatement main_8a2;
		SFC::DT dT_8a3;
	};

	std::list< Match> _matches;
};

class SkipArray_8b6
{
public:
	void operator()( const Packets_t& argDeclBases_8b7, const Packets_t& topArrays_8ba, const Packets_t& arrays_8bd, const Packets_t& mains_8c0, Packets_t& argDeclBases_8b9, Packets_t& topArrays_8bc, Packets_t& dTs_8bf, Packets_t& mains_8c2);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_8cb, const Udm::Object& topArray_8d4, const Udm::Object& array_8dd, const Udm::Object& main_8e6);
	void processInputPackets( const Packets_t& argDeclBases_8b7, const Packets_t& topArrays_8ba, const Packets_t& arrays_8bd, const Packets_t& mains_8c0);
	bool patternMatcher( const Udm::Object& argDeclBase_8c9, const Udm::Object& topArray_8d2, const Udm::Object& array_8db, const Udm::Object& main_8e4);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_8f2, const SFC::Array& topArray_8f4, const SFC::DT& dT_8f6, const SFC::CompoundStatement& main_8f8);

private:
	Packets_t* _argDeclBase_8c3;
	Packets_t* _topArray_8c4;
	Packets_t* _dT_8c5;
	Packets_t* _main_8c6;
	Packets_t _argDeclBase_8c7;
	Packets_t _topArray_8d0;
	Packets_t _array_8d9;
	Packets_t _main_8e2;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_8ed;
		SFC::Array topArray_8ee;
		SFC::Array array_8ef;
		SFC::CompoundStatement main_8f0;
		SFC::DT dT_8f1;
	};

	std::list< Match> _matches;
};

class ArrayTest_8fa
{
public:
	void operator()( const Packets_t& passADBs_8fb, const Packets_t& topArrays_8fd, const Packets_t& dts_8ff, const Packets_t& mains_901, Packets_t& passADBs_903, Packets_t& toparrays_904, Packets_t& nullarrays_905, Packets_t& mains_906, Packets_t& passADBs_907, Packets_t& toparrays_908, Packets_t& arrays_909, Packets_t& mains_90a, Packets_t& passADBs_90b, Packets_t& toparrays_90c, Packets_t& dts_90d, Packets_t& mains_90e);

protected:
	void executeOne( const Packets_t& passADBs_8fb, const Packets_t& topArrays_8fd, const Packets_t& dts_8ff, const Packets_t& mains_901);
	bool isInputUnique( const Udm::Object& passADB_91d, const Udm::Object& topArray_924, const Udm::Object& dt_92b, const Udm::Object& main_932);

private:
	Packets_t* _passADB_90f;
	Packets_t* _toparray_910;
	Packets_t* _nullarray_911;
	Packets_t* _main_912;
	Packets_t* _passADB_913;
	Packets_t* _toparray_914;
	Packets_t* _array_915;
	Packets_t* _main_916;
	Packets_t* _passADB_917;
	Packets_t* _toparray_918;
	Packets_t* _dt_919;
	Packets_t* _main_91a;
	Packets_t _passADB_91b;
	Packets_t _topArray_922;
	Packets_t _dt_929;
	Packets_t _main_930;
};

class NullArray_937
{
public:
	bool operator()( const Packets_t& argDeclBases_938, const Packets_t& topArrays_93b, const Packets_t& arrays_93e, const Packets_t& mains_941, Packets_t& argDeclBases_93a, Packets_t& topArrays_93d, Packets_t& arrays_940, Packets_t& mains_943);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_94c, const Udm::Object& topArray_955, const Udm::Object& array_95e, const Udm::Object& main_967);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Array& Array, SFC::CompoundStatement& Main, SFC::Array& TopArray);
	void processInputPackets( const Packets_t& argDeclBases_938, const Packets_t& topArrays_93b, const Packets_t& arrays_93e, const Packets_t& mains_941);
	bool patternMatcher( const Udm::Object& argDeclBase_94a, const Udm::Object& topArray_953, const Udm::Object& array_95c, const Udm::Object& main_965);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_975, const SFC::Array& topArray_977, const SFC::Array& array_979, const SFC::CompoundStatement& main_97b);

private:
	Packets_t* _argDeclBase_944;
	Packets_t* _topArray_945;
	Packets_t* _array_946;
	Packets_t* _main_947;
	Packets_t _argDeclBase_948;
	Packets_t _topArray_951;
	Packets_t _array_95a;
	Packets_t _main_963;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_96d;
		SFC::Array topArray_96e;
		SFC::Array array_96f;
		SFC::CompoundStatement main_970;
	};

	std::list< Match> _matches;
};

class Array_97d
{
public:
	bool operator()( const Packets_t& argDeclBases_97e, const Packets_t& topArrays_981, const Packets_t& arrays_984, const Packets_t& mains_987, Packets_t& argDeclBases_980, Packets_t& topArrays_983, Packets_t& arrays_986, Packets_t& mains_989);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_992, const Udm::Object& topArray_99b, const Udm::Object& array_9a4, const Udm::Object& main_9ad);
	void processInputPackets( const Packets_t& argDeclBases_97e, const Packets_t& topArrays_981, const Packets_t& arrays_984, const Packets_t& mains_987);
	bool patternMatcher( const Udm::Object& argDeclBase_990, const Udm::Object& topArray_999, const Udm::Object& array_9a2, const Udm::Object& main_9ab);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_9b7, const SFC::Array& topArray_9b9, const SFC::Array& array_9bb, const SFC::CompoundStatement& main_9bd);

private:
	Packets_t* _argDeclBase_98a;
	Packets_t* _topArray_98b;
	Packets_t* _array_98c;
	Packets_t* _main_98d;
	Packets_t _argDeclBase_98e;
	Packets_t _topArray_997;
	Packets_t _array_9a0;
	Packets_t _main_9a9;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_9b3;
		SFC::Array topArray_9b4;
		SFC::Array array_9b5;
		SFC::CompoundStatement main_9b6;
	};

	std::list< Match> _matches;
};

class Otherwise_9bf
{
public:
	bool operator()( const Packets_t& argDeclBases_9c0, const Packets_t& topArrays_9c3, const Packets_t& dTs_9c6, const Packets_t& mains_9c9, Packets_t& argDeclBases_9c2, Packets_t& topArrays_9c5, Packets_t& dTs_9c8, Packets_t& mains_9cb);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_9d4, const Udm::Object& topArray_9dd, const Udm::Object& dT_9e6, const Udm::Object& main_9ef);
	void processInputPackets( const Packets_t& argDeclBases_9c0, const Packets_t& topArrays_9c3, const Packets_t& dTs_9c6, const Packets_t& mains_9c9);
	bool patternMatcher( const Udm::Object& argDeclBase_9d2, const Udm::Object& topArray_9db, const Udm::Object& dT_9e4, const Udm::Object& main_9ed);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_9f9, const SFC::Array& topArray_9fb, const SFC::DT& dT_9fd, const SFC::CompoundStatement& main_9ff);

private:
	Packets_t* _argDeclBase_9cc;
	Packets_t* _topArray_9cd;
	Packets_t* _dT_9ce;
	Packets_t* _main_9cf;
	Packets_t _argDeclBase_9d0;
	Packets_t _topArray_9d9;
	Packets_t _dT_9e2;
	Packets_t _main_9eb;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_9f5;
		SFC::Array topArray_9f6;
		SFC::DT dT_9f7;
		SFC::CompoundStatement main_9f8;
	};

	std::list< Match> _matches;
};

class MemberDataType_a15
{
public:
	void operator()( const Packets_t& localVars_a16, const Packets_t& mains_a1a, Packets_t& localVars_a18, Packets_t& dTs_a19, Packets_t& mains_a1c);

protected:
	bool isInputUnique( const Udm::Object& localVar_a24, const Udm::Object& main_a2d);
	void processInputPackets( const Packets_t& localVars_a16, const Packets_t& mains_a1a);
	bool patternMatcher( const Udm::Object& localVar_a22, const Udm::Object& main_a2b);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar_a37, const SFC::DT& dT_a39, const SFC::CompoundStatement& main_a3b);

private:
	Packets_t* _localVar_a1d;
	Packets_t* _dT_a1e;
	Packets_t* _main_a1f;
	Packets_t _localVar_a20;
	Packets_t _main_a29;
	class Match
	{
	public:
		SFC::LocalVar localVar_a34;
		SFC::CompoundStatement main_a35;
		SFC::DT dT_a36;
	};

	std::list< Match> _matches;
};

class MakeArrayLoop_a3d
{
public:
	void operator()( const Packets_t& argDeclBases_a3e, const Packets_t& arrays_a41, const Packets_t& mains_a45, Packets_t& argDeclBases_a40, Packets_t& arrays_a43, Packets_t& dTs_a44, Packets_t& loops_a47);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_a50, const Udm::Object& array_a59, const Udm::Object& main_a62);
	void processInputPackets( const Packets_t& argDeclBases_a3e, const Packets_t& arrays_a41, const Packets_t& mains_a45);
	bool patternMatcher( const Udm::Object& argDeclBase_a4e, const Udm::Object& array_a57, const Udm::Object& main_a60);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_a77, const SFC::Array& array_a79, const SFC::DT& dT_a7b, const SFC::IterativeBlock& loop_a7d);

private:
	Packets_t* _argDeclBase_a48;
	Packets_t* _array_a49;
	Packets_t* _dT_a4a;
	Packets_t* _loop_a4b;
	Packets_t _argDeclBase_a4c;
	Packets_t _array_a55;
	Packets_t _main_a5e;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_a69;
		SFC::Array array_a6a;
		SFC::CompoundStatement main_a6b;
		SFC::DT dT_a6c;
	};

	std::list< Match> _matches;
};

class StructTest_a7f
{
public:
	void operator()( const Packets_t& passADBs_a80, const Packets_t& dts_a82, const Packets_t& mains_a84, Packets_t& passADBs_a86, Packets_t& basics_a87, Packets_t& mains_a88, Packets_t& passADBs_a89, Packets_t& nullarrays_a8a, Packets_t& mains_a8b, Packets_t& passADBs_a8c, Packets_t& arrays_a8d, Packets_t& mains_a8e, Packets_t& passADBs_a8f, Packets_t& structs_a90, Packets_t& mains_a91);

protected:
	void executeOne( const Packets_t& passADBs_a80, const Packets_t& dts_a82, const Packets_t& mains_a84);
	bool isInputUnique( const Udm::Object& passADB_aa0, const Udm::Object& dt_aa7, const Udm::Object& main_aae);

private:
	Packets_t* _passADB_a92;
	Packets_t* _basic_a93;
	Packets_t* _main_a94;
	Packets_t* _passADB_a95;
	Packets_t* _nullarray_a96;
	Packets_t* _main_a97;
	Packets_t* _passADB_a98;
	Packets_t* _array_a99;
	Packets_t* _main_a9a;
	Packets_t* _passADB_a9b;
	Packets_t* _struct_a9c;
	Packets_t* _main_a9d;
	Packets_t _passADB_a9e;
	Packets_t _dt_aa5;
	Packets_t _main_aac;
};

class BasicType_ab3
{
public:
	bool operator()( const Packets_t& argDeclBases_ab4, const Packets_t& basicTypes_ab7, const Packets_t& mains_aba, Packets_t& argDeclBases_ab6, Packets_t& basicTypes_ab9, Packets_t& mains_abc);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_ac4, const Udm::Object& basicType_acd, const Udm::Object& main_ad6);
	void processInputPackets( const Packets_t& argDeclBases_ab4, const Packets_t& basicTypes_ab7, const Packets_t& mains_aba);
	bool patternMatcher( const Udm::Object& argDeclBase_ac2, const Udm::Object& basicType_acb, const Udm::Object& main_ad4);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_adf, const SFC::BasicType& basicType_ae1, const SFC::CompoundStatement& main_ae3);

private:
	Packets_t* _argDeclBase_abd;
	Packets_t* _basicType_abe;
	Packets_t* _main_abf;
	Packets_t _argDeclBase_ac0;
	Packets_t _basicType_ac9;
	Packets_t _main_ad2;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_adc;
		SFC::BasicType basicType_add;
		SFC::CompoundStatement main_ade;
	};

	std::list< Match> _matches;
};

class NullArray_ae5
{
public:
	bool operator()( const Packets_t& argDeclBases_ae6, const Packets_t& arrays_ae9, const Packets_t& mains_aec, Packets_t& argDeclBases_ae8, Packets_t& arrays_aeb, Packets_t& mains_aee);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_af6, const Udm::Object& array_aff, const Udm::Object& main_b08);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Array& Array, SFC::CompoundStatement& Main);
	void processInputPackets( const Packets_t& argDeclBases_ae6, const Packets_t& arrays_ae9, const Packets_t& mains_aec);
	bool patternMatcher( const Udm::Object& argDeclBase_af4, const Udm::Object& array_afd, const Udm::Object& main_b06);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_b14, const SFC::Array& array_b16, const SFC::CompoundStatement& main_b18);

private:
	Packets_t* _argDeclBase_aef;
	Packets_t* _array_af0;
	Packets_t* _main_af1;
	Packets_t _argDeclBase_af2;
	Packets_t _array_afb;
	Packets_t _main_b04;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_b0e;
		SFC::Array array_b0f;
		SFC::CompoundStatement main_b10;
	};

	std::list< Match> _matches;
};

class Array_b1a
{
public:
	bool operator()( const Packets_t& argDeclBases_b1b, const Packets_t& arrays_b1e, const Packets_t& mains_b21, Packets_t& argDeclBases_b1d, Packets_t& arrays_b20, Packets_t& mains_b23);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_b2b, const Udm::Object& array_b34, const Udm::Object& main_b3d);
	void processInputPackets( const Packets_t& argDeclBases_b1b, const Packets_t& arrays_b1e, const Packets_t& mains_b21);
	bool patternMatcher( const Udm::Object& argDeclBase_b29, const Udm::Object& array_b32, const Udm::Object& main_b3b);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_b46, const SFC::Array& array_b48, const SFC::CompoundStatement& main_b4a);

private:
	Packets_t* _argDeclBase_b24;
	Packets_t* _array_b25;
	Packets_t* _main_b26;
	Packets_t _argDeclBase_b27;
	Packets_t _array_b30;
	Packets_t _main_b39;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_b43;
		SFC::Array array_b44;
		SFC::CompoundStatement main_b45;
	};

	std::list< Match> _matches;
};

class Struct_b4c
{
public:
	bool operator()( const Packets_t& argDeclBases_b4d, const Packets_t& structs_b50, const Packets_t& mains_b53, Packets_t& argDeclBases_b4f, Packets_t& structs_b52, Packets_t& mains_b55);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_b5d, const Udm::Object& struct_b66, const Udm::Object& main_b6f);
	void processInputPackets( const Packets_t& argDeclBases_b4d, const Packets_t& structs_b50, const Packets_t& mains_b53);
	bool patternMatcher( const Udm::Object& argDeclBase_b5b, const Udm::Object& struct_b64, const Udm::Object& main_b6d);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_b78, const SFC::Struct& struct_b7a, const SFC::CompoundStatement& main_b7c);

private:
	Packets_t* _argDeclBase_b56;
	Packets_t* _struct_b57;
	Packets_t* _main_b58;
	Packets_t _argDeclBase_b59;
	Packets_t _struct_b62;
	Packets_t _main_b6b;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_b75;
		SFC::Struct struct_b76;
		SFC::CompoundStatement main_b77;
	};

	std::list< Match> _matches;
};

class BasicType_b7e
{
public:
	void operator()( const Packets_t& argDeclBases_b7f, const Packets_t& basicTypes_b82, const Packets_t& compoundStatements_b85, Packets_t& argDeclBases_b81, Packets_t& basicTypes_b84, Packets_t& compoundStatements_b87, Packets_t& unaryExprss_b88);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_b91, const Udm::Object& basicType_b9a, const Udm::Object& compoundStatement_ba3);
	void processInputPackets( const Packets_t& argDeclBases_b7f, const Packets_t& basicTypes_b82, const Packets_t& compoundStatements_b85);
	bool patternMatcher( const Udm::Object& argDeclBase_b8f, const Udm::Object& basicType_b98, const Udm::Object& compoundStatement_ba1);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_bb1, const SFC::BasicType& basicType_bb3, const SFC::CompoundStatement& compoundStatement_bb5, const SFC::UnaryExprs& unaryExprs_bb7);

private:
	Packets_t* _argDeclBase_b89;
	Packets_t* _basicType_b8a;
	Packets_t* _compoundStatement_b8b;
	Packets_t* _unaryExprs_b8c;
	Packets_t _argDeclBase_b8d;
	Packets_t _basicType_b96;
	Packets_t _compoundStatement_b9f;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_ba9;
		SFC::BasicType basicType_baa;
		SFC::CompoundStatement compoundStatement_bab;
	};

	std::list< Match> _matches;
};

class MakePath_bb9
{
public:
	void operator()( const Packets_t& argDeclBases_bba, const Packets_t& structs_bbc, const Packets_t& mains_bbf, Packets_t& structs_bbe, Packets_t& mains_bc1);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_bc8, const Udm::Object& struct_bd1, const Udm::Object& main_bda);
	void processInputPackets( const Packets_t& argDeclBases_bba, const Packets_t& structs_bbc, const Packets_t& mains_bbf);
	bool patternMatcher( const Udm::Object& argDeclBase_bc6, const Udm::Object& struct_bcf, const Udm::Object& main_bd8);
	void effector();
	void outputAppender( const SFC::Struct& struct_be3, const SFC::CompoundStatement& main_be5);
	void sortOutputs();

private:
	Packets_t* _struct_bc2;
	Packets_t* _main_bc3;
	Packets_t _argDeclBase_bc4;
	Packets_t _struct_bcd;
	Packets_t _main_bd6;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_be0;
		SFC::Struct struct_be1;
		SFC::CompoundStatement main_be2;
	};

	std::list< Match> _matches;
};

class AddVar_c28
{
public:
	void operator()( const Packets_t& argDeclBases_c29, const Packets_t& unaryExprss_c2b);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_c31, const Udm::Object& unaryExprs_c3a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_c29, const Packets_t& unaryExprss_c2b);
	bool patternMatcher( const Udm::Object& argDeclBase_c2f, const Udm::Object& unaryExprs_c38);
	void effector();

private:
	Packets_t _argDeclBase_c2d;
	Packets_t _unaryExprs_c36;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_c43;
		SFC::UnaryExprs unaryExprs_c44;
	};

	std::list< Match> _matches;
};

class GetDT_c46
{
public:
	void operator()( const Packets_t& vars_c47, const Packets_t& mains_c4b, Packets_t& vars_c49, Packets_t& dTs_c4a, Packets_t& mains_c4d);

protected:
	bool isInputUnique( const Udm::Object& var_c55, const Udm::Object& main_c5e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& vars_c47, const Packets_t& mains_c4b);
	bool patternMatcher( const Udm::Object& var_c53, const Udm::Object& main_c5c);
	void effector();
	void outputAppender( const SFC::LocalVar& var_c6b, const SFC::DT& dT_c6d, const SFC::CompoundStatement& main_c6f);

private:
	Packets_t* _var_c4e;
	Packets_t* _dT_c4f;
	Packets_t* _main_c50;
	Packets_t _var_c51;
	Packets_t _main_c5a;
	class Match
	{
	public:
		SFC::LocalVar var_c68;
		SFC::CompoundStatement main_c69;
		SFC::DT dT_c6a;
	};

	std::list< Match> _matches;
};

class GetVarsForArgs_c71
{
public:
	void operator()( const Packets_t& args_c72, const Packets_t& mains_c75, Packets_t& vars_c74, Packets_t& mains_c77);

protected:
	bool isInputUnique( const Udm::Object& arg_c7e, const Udm::Object& main_c87);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& args_c72, const Packets_t& mains_c75);
	bool patternMatcher( const Udm::Object& arg_c7c, const Udm::Object& main_c85);
	void effector();
	void outputAppender( const SFC::LocalVar& var_c94, const SFC::CompoundStatement& main_c96);

private:
	Packets_t* _var_c78;
	Packets_t* _main_c79;
	Packets_t _arg_c7a;
	Packets_t _main_c83;
	class Match
	{
	public:
		SFC::Arg arg_c91;
		SFC::CompoundStatement main_c92;
		SFC::LocalVar var_c93;
	};

	std::list< Match> _matches;
};

class GetSortedArgs_c98
{
public:
	void operator()( const Packets_t& modelMains_c9a, const Packets_t& mains_c9c, Packets_t& args_c99, Packets_t& mains_c9e);

protected:
	bool isInputUnique( const Udm::Object& modelMain_ca5, const Udm::Object& main_cae);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::CompoundStatement& Main, SFC::Function& ModelMain);
	void processInputPackets( const Packets_t& modelMains_c9a, const Packets_t& mains_c9c);
	bool patternMatcher( const Udm::Object& modelMain_ca3, const Udm::Object& main_cac);
	void effector();
	void outputAppender( const SFC::Arg& arg_cc0, const SFC::CompoundStatement& main_cc2);
	void sortOutputs();

private:
	Packets_t* _arg_c9f;
	Packets_t* _main_ca0;
	Packets_t _modelMain_ca1;
	Packets_t _main_caa;
	class Match
	{
	public:
		SFC::Function modelMain_cba;
		SFC::CompoundStatement main_cbb;
		SFC::Arg arg_cbc;
	};

	std::list< Match> _matches;
};

class CreateLoop_cd9
{
public:
	void operator()( const Packets_t& classs_cda, const Packets_t& mains_cdc, Packets_t& modelMains_cde, Packets_t& mains_cdf, Packets_t& loops_ce0);

protected:
	void callCreateLoop_d49( const Packets_t& classs_d0f, const Packets_t& mains_d11);
	void callIncrementCounter_d4c( const Packets_t& modelMains_ce5, const Packets_t& mains_ce7, const Packets_t& iterativeBlocks_ce9, const Packets_t& counters_ceb);

private:
	Packets_t* _modelMain_ce1;
	Packets_t* _main_ce2;
	Packets_t* _loop_ce3;
};

class IncrementCounter_ce4
{
public:
	void operator()( const Packets_t& modelMains_ce5, const Packets_t& mains_ce7, const Packets_t& iterativeBlocks_ce9, const Packets_t& counters_ceb, Packets_t& modelMains_ced, Packets_t& mains_cee, Packets_t& loops_cef, Packets_t& counters_cf0);

protected:
	void callIncrementCounter_d0b( const Packets_t& iterativeBlocks_cf6);

private:
	Packets_t* _modelMain_cf1;
	Packets_t* _main_cf2;
	Packets_t* _loop_cf3;
	Packets_t* _counter_cf4;
};

class IncrementCounter_cf5
{
public:
	void operator()( const Packets_t& iterativeBlocks_cf6);

protected:
	bool isInputUnique( const Udm::Object& iterativeBlock_cfc);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& iterativeBlocks_cf6);
	bool patternMatcher( const Udm::Object& iterativeBlock_cfa);
	void effector();

private:
	Packets_t _iterativeBlock_cf8;
	class Match
	{
	public:
		SFC::IterativeBlock iterativeBlock_d06;
		SFC::LocalVar counter_d07;
	};

	std::list< Match> _matches;
};

class CreateLoop_d0d
{
public:
	void operator()( const Packets_t& classs_d0f, const Packets_t& mains_d11, Packets_t& modelMains_d0e, Packets_t& mains_d13, Packets_t& iterativeBlocks_d14, Packets_t& counters_d15);

protected:
	bool isInputUnique( const Udm::Object& class_d1e, const Udm::Object& main_d27);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_d0f, const Packets_t& mains_d11);
	bool patternMatcher( const Udm::Object& class_d1c, const Udm::Object& main_d25);
	void effector();
	void outputAppender( const SFC::Function& modelMain_d41, const SFC::Function& main_d43, const SFC::IterativeBlock& iterativeBlock_d45, const SFC::LocalVar& counter_d47);

private:
	Packets_t* _modelMain_d16;
	Packets_t* _main_d17;
	Packets_t* _iterativeBlock_d18;
	Packets_t* _counter_d19;
	Packets_t _class_d1a;
	Packets_t _main_d23;
	class Match
	{
	public:
		SFC::Class class_d34;
		SFC::Function main_d35;
		SFC::Function modelMain_d36;
	};

	std::list< Match> _matches;
};

class MarkInitAndMain_d51
{
public:
	void operator()( const Packets_t& classs_d52, Packets_t& classs_d54);

protected:
	void callGetClassFunctions_d9b( const Packets_t& classs_d84);
	void callMarkMain_d9d( const Packets_t& mains_d57);
	void callMarkInit_d9f( const Packets_t& inits_d6d);

private:
	Packets_t* _class_d55;
};

class MarkMain_d56
{
public:
	void operator()( const Packets_t& mains_d57);

protected:
	bool isInputUnique( const Udm::Object& main_d5d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class, SFC::Function& Main);
	void processInputPackets( const Packets_t& mains_d57);
	bool patternMatcher( const Udm::Object& main_d5b);
	void effector();

private:
	Packets_t _main_d59;
	class Match
	{
	public:
		SFC::Function main_d68;
		SFC::Class class_d69;
	};

	std::list< Match> _matches;
};

class MarkInit_d6c
{
public:
	void operator()( const Packets_t& inits_d6d);

protected:
	bool isInputUnique( const Udm::Object& init_d73);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class, SFC::Function& Init);
	void processInputPackets( const Packets_t& inits_d6d);
	bool patternMatcher( const Udm::Object& init_d71);
	void effector();

private:
	Packets_t _init_d6f;
	class Match
	{
	public:
		SFC::Function init_d7e;
		SFC::Class class_d7f;
	};

	std::list< Match> _matches;
};

class GetClassFunctions_d82
{
public:
	void operator()( const Packets_t& classs_d84, Packets_t& functions_d83);

protected:
	bool isInputUnique( const Udm::Object& class_d8b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_d84);
	bool patternMatcher( const Udm::Object& class_d89);
	void effector();
	void outputAppender( const SFC::Function& function_d99);

private:
	Packets_t* _function_d86;
	Packets_t _class_d87;
	class Match
	{
	public:
		SFC::Class class_d97;
		SFC::Function function_d98;
	};

	std::list< Match> _matches;
};

class CallModelMain_da1
{
public:
	void operator()( const Packets_t& modelMains_da2, const Packets_t& mains_da4, const Packets_t& loops_da6, Packets_t& modelMains_da8, Packets_t& loops_da9);

protected:
	void callGetContext_f34( const Packets_t& modelMains_dad, const Packets_t& mains_db0, const Packets_t& mains_db3);
	void callCreateCallWithContext_f38( const Packets_t& modelMains_dec, const Packets_t& contexts_def, const Packets_t& mains_df2);
	void callCreateLocalsForCall_f3c( const Packets_t& inits_e2d, const Packets_t& initCalls_e2f, const Packets_t& compoundStmnts_e31);

private:
	Packets_t* _modelMain_daa;
	Packets_t* _loop_dab;
};

class GetContext_dac
{
public:
	void operator()( const Packets_t& modelMains_dad, const Packets_t& mains_db0, const Packets_t& mains_db3, Packets_t& modelMains_daf, Packets_t& contexts_db2, Packets_t& mains_db5);

protected:
	bool isInputUnique( const Udm::Object& modelMain_dbd, const Udm::Object& main_dc6, const Udm::Object& main_dcf);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& modelMains_dad, const Packets_t& mains_db0, const Packets_t& mains_db3);
	bool patternMatcher( const Udm::Object& modelMain_dbb, const Udm::Object& main_dc4, const Udm::Object& main_dcd);
	void effector();
	void outputAppender( const SFC::Function& modelMain_de5, const SFC::LocalVar& context_de7, const SFC::CompoundStatement& main_de9);

private:
	Packets_t* _modelMain_db6;
	Packets_t* _context_db7;
	Packets_t* _main_db8;
	Packets_t _modelMain_db9;
	Packets_t _main_dc2;
	Packets_t _main_dcb;
	class Match
	{
	public:
		SFC::Function modelMain_de0;
		SFC::Function main_de1;
		SFC::CompoundStatement main_de2;
		SFC::Class class_de3;
		SFC::LocalVar context_de4;
	};

	std::list< Match> _matches;
};

class CreateCallWithContext_deb
{
public:
	void operator()( const Packets_t& modelMains_dec, const Packets_t& contexts_def, const Packets_t& mains_df2, Packets_t& modelMains_dee, Packets_t& modelMainCalls_df1, Packets_t& mains_df4);

protected:
	bool isInputUnique( const Udm::Object& modelMain_dfc, const Udm::Object& context_e05, const Udm::Object& main_e0e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& modelMains_dec, const Packets_t& contexts_def, const Packets_t& mains_df2);
	bool patternMatcher( const Udm::Object& modelMain_dfa, const Udm::Object& context_e03, const Udm::Object& main_e0c);
	void effector();
	void outputAppender( const SFC::Function& modelMain_e26, const SFC::FunctionCall& modelMainCall_e28, const SFC::CompoundStatement& main_e2a);

private:
	Packets_t* _modelMain_df5;
	Packets_t* _modelMainCall_df6;
	Packets_t* _main_df7;
	Packets_t _modelMain_df8;
	Packets_t _context_e01;
	Packets_t _main_e0a;
	class Match
	{
	public:
		SFC::Function modelMain_e1e;
		SFC::LocalVar context_e1f;
		SFC::CompoundStatement main_e20;
		SFC::Arg arg_e21;
		SFC::DT dataType_e22;
	};

	std::list< Match> _matches;
};

class CreateLocalsForCall_e2c
{
public:
	void operator()( const Packets_t& inits_e2d, const Packets_t& initCalls_e2f, const Packets_t& compoundStmnts_e31, Packets_t& vars_e33, Packets_t& calls_e34);

protected:
	void callGetArgs_f28( const Packets_t& inits_ef1, const Packets_t& initCalls_ef3, const Packets_t& mains_ef6);
	void callNeedsVar_f2c( const Packets_t& arguments_e38, const Packets_t& initCalls_e3a, const Packets_t& compoundStmnts_e3c);
	void callCreateLocalVars_f30( const Packets_t& args_eba, const Packets_t& initCalls_ebd, const Packets_t& mains_ec0);

private:
	Packets_t* _var_e35;
	Packets_t* _call_e36;
};

class NeedsVar_e37
{
public:
	void operator()( const Packets_t& arguments_e38, const Packets_t& initCalls_e3a, const Packets_t& compoundStmnts_e3c, Packets_t& arguments_e3e, Packets_t& initCalls_e3f, Packets_t& compoundStmnts_e40);

protected:
	void executeOne( const Packets_t& arguments_e38, const Packets_t& initCalls_e3a, const Packets_t& compoundStmnts_e3c);
	bool isInputUnique( const Udm::Object& argument_e46, const Udm::Object& initCall_e4d, const Udm::Object& compoundStmnt_e54);

private:
	Packets_t* _argument_e41;
	Packets_t* _initCall_e42;
	Packets_t* _compoundStmnt_e43;
	Packets_t _argument_e44;
	Packets_t _initCall_e4b;
	Packets_t _compoundStmnt_e52;
};

class HasLocalVar_e59
{
public:
	bool operator()( const Packets_t& args_e5a, const Packets_t& calls_e5c, const Packets_t& compoundStmnts_e5e);

protected:
	bool isInputUnique( const Udm::Object& arg_e64, const Udm::Object& call_e6d, const Udm::Object& compoundStmnt_e76);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& args_e5a, const Packets_t& calls_e5c, const Packets_t& compoundStmnts_e5e);
	bool patternMatcher( const Udm::Object& arg_e62, const Udm::Object& call_e6b, const Udm::Object& compoundStmnt_e74);
	void outputAppender();

private:
	Packets_t _arg_e60;
	Packets_t _call_e69;
	Packets_t _compoundStmnt_e72;
	class Match
	{
	public:
		SFC::Arg arg_e80;
		SFC::FunctionCall call_e81;
		SFC::CompoundStatement compoundStmnt_e82;
		SFC::LocalVar var_e83;
	};

	std::list< Match> _matches;
};

class VarNeeded_e84
{
public:
	bool operator()( const Packets_t& args_e85, const Packets_t& calls_e88, const Packets_t& mains_e8b, Packets_t& args_e87, Packets_t& calls_e8a, Packets_t& mains_e8d);

protected:
	bool isInputUnique( const Udm::Object& arg_e95, const Udm::Object& call_e9e, const Udm::Object& main_ea7);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& args_e85, const Packets_t& calls_e88, const Packets_t& mains_e8b);
	bool patternMatcher( const Udm::Object& arg_e93, const Udm::Object& call_e9c, const Udm::Object& main_ea5);
	void outputAppender( const SFC::Arg& arg_eb3, const SFC::FunctionCall& call_eb5, const SFC::CompoundStatement& main_eb7);

private:
	Packets_t* _arg_e8e;
	Packets_t* _call_e8f;
	Packets_t* _main_e90;
	Packets_t _arg_e91;
	Packets_t _call_e9a;
	Packets_t _main_ea3;
	class Match
	{
	public:
		SFC::Arg arg_eb0;
		SFC::FunctionCall call_eb1;
		SFC::CompoundStatement main_eb2;
	};

	std::list< Match> _matches;
};

class CreateLocalVars_eb9
{
public:
	void operator()( const Packets_t& args_eba, const Packets_t& initCalls_ebd, const Packets_t& mains_ec0, Packets_t& contexts_ebc, Packets_t& initCalls_ebf);

protected:
	bool isInputUnique( const Udm::Object& arg_ec8, const Udm::Object& initCall_ed1, const Udm::Object& main_eda);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& args_eba, const Packets_t& initCalls_ebd, const Packets_t& mains_ec0);
	bool patternMatcher( const Udm::Object& arg_ec6, const Udm::Object& initCall_ecf, const Udm::Object& main_ed8);
	void effector();
	void outputAppender( const SFC::LocalVar& context_eeb, const SFC::FunctionCall& initCall_eed);

private:
	Packets_t* _context_ec2;
	Packets_t* _initCall_ec3;
	Packets_t _arg_ec4;
	Packets_t _initCall_ecd;
	Packets_t _main_ed6;
	class Match
	{
	public:
		SFC::Arg arg_ee4;
		SFC::FunctionCall initCall_ee5;
		SFC::CompoundStatement main_ee6;
		SFC::DT dataType_ee7;
	};

	std::list< Match> _matches;
};

class GetArgs_eef
{
public:
	void operator()( const Packets_t& inits_ef1, const Packets_t& initCalls_ef3, const Packets_t& mains_ef6, Packets_t& args_ef0, Packets_t& initCalls_ef5, Packets_t& mains_ef8);

protected:
	bool isInputUnique( const Udm::Object& init_f00, const Udm::Object& initCall_f09, const Udm::Object& main_f12);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inits_ef1, const Packets_t& initCalls_ef3, const Packets_t& mains_ef6);
	bool patternMatcher( const Udm::Object& init_efe, const Udm::Object& initCall_f07, const Udm::Object& main_f10);
	void effector();
	void outputAppender( const SFC::Arg& arg_f22, const SFC::FunctionCall& initCall_f24, const SFC::CompoundStatement& main_f26);

private:
	Packets_t* _arg_ef9;
	Packets_t* _initCall_efa;
	Packets_t* _main_efb;
	Packets_t _init_efc;
	Packets_t _initCall_f05;
	Packets_t _main_f0e;
	class Match
	{
	public:
		SFC::Function init_f1e;
		SFC::FunctionCall initCall_f1f;
		SFC::CompoundStatement main_f20;
		SFC::Arg arg_f21;
	};

	std::list< Match> _matches;
};

class CallInit_f40
{
public:
	void operator()( const Packets_t& classs_f41, const Packets_t& mains_f43, Packets_t& classs_f45, Packets_t& mains_f46);

protected:
	void callCallInits_f9a( const Packets_t& classs_f6d, const Packets_t& mains_f70);
	void callCreateLocalsForCall_f9d( const Packets_t& inits_e2d, const Packets_t& initCalls_e2f, const Packets_t& compoundStmnts_e31);
	void callMarkContext_fa1( const Packets_t& vars_f4a, const Packets_t& calls_f4c);

private:
	Packets_t* _class_f47;
	Packets_t* _main_f48;
};

class MarkContext_f49
{
public:
	void operator()( const Packets_t& vars_f4a, const Packets_t& calls_f4c);

protected:
	bool isInputUnique( const Udm::Object& var_f52, const Udm::Object& call_f5b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& vars_f4a, const Packets_t& calls_f4c);
	bool patternMatcher( const Udm::Object& var_f50, const Udm::Object& call_f59);
	void effector();

private:
	Packets_t _var_f4e;
	Packets_t _call_f57;
	class Match
	{
	public:
		SFC::LocalVar var_f67;
		SFC::FunctionCall call_f68;
		SFC::Class class_f69;
		SFC::Function function_f6a;
	};

	std::list< Match> _matches;
};

class CallInits_f6b
{
public:
	void operator()( const Packets_t& classs_f6d, const Packets_t& mains_f70, Packets_t& inits_f6c, Packets_t& initCalls_f6f, Packets_t& mains_f72);

protected:
	bool isInputUnique( const Udm::Object& class_f7a, const Udm::Object& main_f83);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_f6d, const Packets_t& mains_f70);
	bool patternMatcher( const Udm::Object& class_f78, const Udm::Object& main_f81);
	void effector();
	void outputAppender( const SFC::Function& init_f94, const SFC::FunctionCall& initCall_f96, const SFC::Function& main_f98);

private:
	Packets_t* _init_f73;
	Packets_t* _initCall_f74;
	Packets_t* _main_f75;
	Packets_t _class_f76;
	Packets_t _main_f7f;
	class Match
	{
	public:
		SFC::Class class_f90;
		SFC::Function main_f91;
		SFC::Function init_f92;
	};

	std::list< Match> _matches;
};

class CreateMain_fa4
{
public:
	void operator()( const Packets_t& classs_fa5, Packets_t& classs_fa7, Packets_t& mainFunctions_fa8);

protected:
	bool isInputUnique( const Udm::Object& class_faf);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_fa5);
	bool patternMatcher( const Udm::Object& class_fad);
	void effector();
	void outputAppender( const SFC::Class& class_fbc, const SFC::Function& mainFunction_fbe);

private:
	Packets_t* _class_fa9;
	Packets_t* _mainFunction_faa;
	Packets_t _class_fab;
	class Match
	{
	public:
		SFC::Class class_fb8;
	};

	std::list< Match> _matches;
};

class GetProject_fc0
{
public:
	void operator()( const Packets_t& projects_fc1, Packets_t& projects_fc3);

protected:
	bool isInputUnique( const Udm::Object& project_fc9);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& projects_fc1);
	bool patternMatcher( const Udm::Object& project_fc7);
	void effector();
	void forwardInputs();

private:
	Packets_t* _project_fc4;
	Packets_t _project_fc5;
	class Match
	{
	public:
		SFC::Project project_fd2;
	};

	std::list< Match> _matches;
};

