// cpp (meta datanetwork format) source file Links.cpp
// generated from diagram Links
// generated on Mon Jul 23 16:51:14 2012

#include "Links.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "Links_xsd.h"
using namespace std;

// cross-package metainformation header file
#include "ctest.h"

namespace Links {

	::Uml::Diagram meta;

	void CreateMeta() {
	}

	void InitMeta() {
	}

	void InitMetaLinks() {
	}

	void InitMeta(const ::Uml::Diagram &parent) {
	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("Links.xsd", Links_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

		ctest::Initialize();
	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("Links.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "Links", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		UDM_ASSERT(::ctest::meta != ::Udm::null);
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("Links", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("Links");
		}
	} __regUnUsed;

}

