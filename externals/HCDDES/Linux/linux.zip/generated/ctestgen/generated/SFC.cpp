// cpp (meta datanetwork format) source file SFC.cpp
// generated from diagram SFC
// generated on Mon Jul 23 16:51:14 2012

#include "SFC.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "SFC_xsd.h"
using namespace std;

// cross-package metainformation header file
#include "ctest.h"

namespace SFC {

	Condition::Condition() {}
	Condition::Condition(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Condition::Condition(const Condition &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Condition::Condition(Condition &&master) : UDM_OBJECT(master) {};

	Condition Condition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Condition& Condition::operator=(Condition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Condition Condition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Condition Condition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Condition Condition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Condition> Condition::Instances() { return ::Udm::InstantiatedAttr< Condition>(impl); }
	Condition Condition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Condition> Condition::Derived() { return ::Udm::DerivedAttr< Condition>(impl); }
	::Udm::ArchetypeAttr< Condition> Condition::Archetype() const { return ::Udm::ArchetypeAttr< Condition>(impl); }
	::Udm::ParentAttr< ::SFC::ConditionalBlock> Condition::cbPar() const { return ::Udm::ParentAttr< ::SFC::ConditionalBlock>(impl, meta_cbPar); }
	::Udm::ParentAttr< ::SFC::IterativeBlock> Condition::ibPar() const { return ::Udm::ParentAttr< ::SFC::IterativeBlock>(impl, meta_ibPar); }
	::Udm::ParentAttr< ::SFC::Block> Condition::parent() const { return ::Udm::ParentAttr< ::SFC::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Condition::meta;
	::Uml::CompositionParentRole Condition::meta_cbPar;
	::Uml::CompositionParentRole Condition::meta_ibPar;

	Arg::Arg() {}
	Arg::Arg(::Udm::ObjectImpl *impl) : ArgDeclBase(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	Arg::Arg(const Arg &master) : ArgDeclBase(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Arg::Arg(Arg &&master) : ArgDeclBase(master), TypedEntity(master), UDM_OBJECT(master) {};

	Arg Arg::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Arg& Arg::operator=(Arg &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Arg Arg::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Arg Arg::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Arg Arg::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Arg> Arg::Instances() { return ::Udm::InstantiatedAttr< Arg>(impl); }
	Arg Arg::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Arg> Arg::Derived() { return ::Udm::DerivedAttr< Arg>(impl); }
	::Udm::ArchetypeAttr< Arg> Arg::Archetype() const { return ::Udm::ArchetypeAttr< Arg>(impl); }
	::Udm::StringAttr Arg::type() const { return ::Udm::StringAttr(impl, meta_type); }
	::Udm::IntegerAttr Arg::size() const { return ::Udm::IntegerAttr(impl, meta_size); }
	::Udm::BooleanAttr Arg::ptr() const { return ::Udm::BooleanAttr(impl, meta_ptr); }
	::Udm::IntegerAttr Arg::argIndex() const { return ::Udm::IntegerAttr(impl, meta_argIndex); }
	::Udm::AClassAssocAttr< CheckArg, StateLabel> Arg::slab() const { return ::Udm::AClassAssocAttr< CheckArg, StateLabel>(impl, meta_slab, meta_slab_rev); }
	::Udm::AClassAssocAttr< SetVar, LocalVar> Arg::lvar() const { return ::Udm::AClassAssocAttr< SetVar, LocalVar>(impl, meta_lvar, meta_lvar_rev); }
	::Udm::AssocAttr< ArgVal> Arg::val() const { return ::Udm::AssocAttr< ArgVal>(impl, meta_val); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> Arg::actual() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_actual); }
	::Udm::ParentAttr< ::SFC::Function> Arg::Function_parent() const { return ::Udm::ParentAttr< ::SFC::Function>(impl, meta_Function_parent); }
	::Udm::ParentAttr< ::SFC::Function> Arg::parent() const { return ::Udm::ParentAttr< ::SFC::Function>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Arg::meta;
	::Uml::Attribute Arg::meta_type;
	::Uml::Attribute Arg::meta_size;
	::Uml::Attribute Arg::meta_ptr;
	::Uml::Attribute Arg::meta_argIndex;
	::Uml::AssociationRole Arg::meta_slab;
	::Uml::AssociationRole Arg::meta_slab_rev;
	::Uml::AssociationRole Arg::meta_lvar;
	::Uml::AssociationRole Arg::meta_lvar_rev;
	::Uml::AssociationRole Arg::meta_val;
	::Uml::AssociationRole Arg::meta_actual;
	::Uml::CompositionParentRole Arg::meta_Function_parent;

	Function::Function() {}
	Function::Function(::Udm::ObjectImpl *impl) : Block(impl),TypedEntity(impl), UDM_OBJECT(impl) {}
	Function::Function(const Function &master) : Block(master),TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Function::Function(Function &&master) : Block(master),TypedEntity(master), UDM_OBJECT(master) {};

	Function Function::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Function& Function::operator=(Function &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Function Function::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Function Function::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Function Function::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Function> Function::Instances() { return ::Udm::InstantiatedAttr< Function>(impl); }
	Function Function::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Function> Function::Derived() { return ::Udm::DerivedAttr< Function>(impl); }
	::Udm::ArchetypeAttr< Function> Function::Archetype() const { return ::Udm::ArchetypeAttr< Function>(impl); }
	::Udm::StringAttr Function::annotation() const { return ::Udm::StringAttr(impl, meta_annotation); }
	::Udm::StringAttr Function::returnType() const { return ::Udm::StringAttr(impl, meta_returnType); }
	::Udm::IntegerAttr Function::argCount() const { return ::Udm::IntegerAttr(impl, meta_argCount); }
	::Udm::AssocAttr< FunctionCall> Function::caller() const { return ::Udm::AssocAttr< FunctionCall>(impl, meta_caller); }
	::Udm::CrossPointerAttr< ::SFC::Class> Function::klassinit() const { return ::Udm::CrossPointerAttr< ::SFC::Class>(impl, meta_klassinit); }
	::Udm::CrossPointerAttr< ::SFC::Class> Function::klassmain() const { return ::Udm::CrossPointerAttr< ::SFC::Class>(impl, meta_klassmain); }
	::Udm::ChildrenAttr< ::SFC::Arg> Function::Arg_children() const { return ::Udm::ChildrenAttr< ::SFC::Arg>(impl, meta_Arg_children); }
	::Udm::ChildrenAttr< ::SFC::Arg> Function::Arg_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Arg>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclBase> Function::ArgDeclBase_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::TypedEntity> Function::TypedEntity_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::TypedEntity>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Function::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Function::meta;
	::Uml::Attribute Function::meta_annotation;
	::Uml::Attribute Function::meta_returnType;
	::Uml::Attribute Function::meta_argCount;
	::Uml::AssociationRole Function::meta_caller;
	::Uml::AssociationRole Function::meta_klassinit;
	::Uml::AssociationRole Function::meta_klassmain;
	::Uml::CompositionChildRole Function::meta_Arg_children;

	SimpleStatement::SimpleStatement() {}
	SimpleStatement::SimpleStatement(::Udm::ObjectImpl *impl) : OperationalStatement(impl), UDM_OBJECT(impl) {}
	SimpleStatement::SimpleStatement(const SimpleStatement &master) : OperationalStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SimpleStatement::SimpleStatement(SimpleStatement &&master) : OperationalStatement(master), UDM_OBJECT(master) {};

	SimpleStatement SimpleStatement::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SimpleStatement& SimpleStatement::operator=(SimpleStatement &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SimpleStatement SimpleStatement::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SimpleStatement SimpleStatement::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SimpleStatement SimpleStatement::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SimpleStatement> SimpleStatement::Instances() { return ::Udm::InstantiatedAttr< SimpleStatement>(impl); }
	SimpleStatement SimpleStatement::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SimpleStatement> SimpleStatement::Derived() { return ::Udm::DerivedAttr< SimpleStatement>(impl); }
	::Udm::ArchetypeAttr< SimpleStatement> SimpleStatement::Archetype() const { return ::Udm::ArchetypeAttr< SimpleStatement>(impl); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> SimpleStatement::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class SimpleStatement::meta;

	ConditionalBlock::ConditionalBlock() {}
	ConditionalBlock::ConditionalBlock(::Udm::ObjectImpl *impl) : Block(impl), UDM_OBJECT(impl) {}
	ConditionalBlock::ConditionalBlock(const ConditionalBlock &master) : Block(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ConditionalBlock::ConditionalBlock(ConditionalBlock &&master) : Block(master), UDM_OBJECT(master) {};

	ConditionalBlock ConditionalBlock::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ConditionalBlock& ConditionalBlock::operator=(ConditionalBlock &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ConditionalBlock ConditionalBlock::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ConditionalBlock ConditionalBlock::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ConditionalBlock ConditionalBlock::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ConditionalBlock> ConditionalBlock::Instances() { return ::Udm::InstantiatedAttr< ConditionalBlock>(impl); }
	ConditionalBlock ConditionalBlock::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ConditionalBlock> ConditionalBlock::Derived() { return ::Udm::DerivedAttr< ConditionalBlock>(impl); }
	::Udm::ArchetypeAttr< ConditionalBlock> ConditionalBlock::Archetype() const { return ::Udm::ArchetypeAttr< ConditionalBlock>(impl); }
	::Udm::ChildrenAttr< ::SFC::Condition> ConditionalBlock::cond() const { return ::Udm::ChildrenAttr< ::SFC::Condition>(impl, meta_cond); }
	::Udm::ChildrenAttr< ::SFC::Condition> ConditionalBlock::Condition_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Condition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UserCode> ConditionalBlock::UserCode_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UserCode>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::CheckArg> ConditionalBlock::CheckArg_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::CheckArg>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::CheckState> ConditionalBlock::CheckState_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::CheckState>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> ConditionalBlock::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ConditionalBlock::meta;
	::Uml::CompositionChildRole ConditionalBlock::meta_cond;

	Return::Return() {}
	Return::Return(::Udm::ObjectImpl *impl) : SimpleStatement(impl), UDM_OBJECT(impl) {}
	Return::Return(const Return &master) : SimpleStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Return::Return(Return &&master) : SimpleStatement(master), UDM_OBJECT(master) {};

	Return Return::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Return& Return::operator=(Return &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Return Return::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Return Return::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Return Return::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Return> Return::Instances() { return ::Udm::InstantiatedAttr< Return>(impl); }
	Return Return::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Return> Return::Derived() { return ::Udm::DerivedAttr< Return>(impl); }
	::Udm::ArchetypeAttr< Return> Return::Archetype() const { return ::Udm::ArchetypeAttr< Return>(impl); }
	::Udm::StringAttr Return::val() const { return ::Udm::StringAttr(impl, meta_val); }
	::Udm::ChildAttr< ::SFC::Exprs> Return::retexpr() const { return ::Udm::ChildAttr< ::SFC::Exprs>(impl, meta_retexpr); }
	::Udm::ChildrenAttr< ::SFC::FunctionCall> Return::FunctionCall_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Str> Return::Str_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Str>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Double> Return::Double_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Double>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Int> Return::Int_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Int>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BinaryExprs> Return::BinaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UnaryExprs> Return::UnaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::NullaryExprs> Return::NullaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Exprs> Return::Exprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Exprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclRef> Return::ArgDeclRef_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Return::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Return::meta;
	::Uml::Attribute Return::meta_val;
	::Uml::CompositionChildRole Return::meta_retexpr;

	Program::Program() {}
	Program::Program(::Udm::ObjectImpl *impl) : CompoundStatement(impl), UDM_OBJECT(impl) {}
	Program::Program(const Program &master) : CompoundStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Program::Program(Program &&master) : CompoundStatement(master), UDM_OBJECT(master) {};

	Program Program::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Program& Program::operator=(Program &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Program Program::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Program Program::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Program Program::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Program> Program::Instances() { return ::Udm::InstantiatedAttr< Program>(impl); }
	Program Program::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Program> Program::Derived() { return ::Udm::DerivedAttr< Program>(impl); }
	::Udm::ArchetypeAttr< Program> Program::Archetype() const { return ::Udm::ArchetypeAttr< Program>(impl); }
	::Udm::StringAttr Program::filename() const { return ::Udm::StringAttr(impl, meta_filename); }
	::Udm::IntegerAttr Program::stateCount() const { return ::Udm::IntegerAttr(impl, meta_stateCount); }
	::Udm::IntegerAttr Program::numInstance() const { return ::Udm::IntegerAttr(impl, meta_numInstance); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Program::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Program::meta;
	::Uml::Attribute Program::meta_filename;
	::Uml::Attribute Program::meta_stateCount;
	::Uml::Attribute Program::meta_numInstance;

	CompoundStatement::CompoundStatement() {}
	CompoundStatement::CompoundStatement(::Udm::ObjectImpl *impl) : OperationalStatement(impl), UDM_OBJECT(impl) {}
	CompoundStatement::CompoundStatement(const CompoundStatement &master) : OperationalStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CompoundStatement::CompoundStatement(CompoundStatement &&master) : OperationalStatement(master), UDM_OBJECT(master) {};

	CompoundStatement CompoundStatement::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CompoundStatement& CompoundStatement::operator=(CompoundStatement &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CompoundStatement CompoundStatement::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CompoundStatement CompoundStatement::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CompoundStatement CompoundStatement::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CompoundStatement> CompoundStatement::Instances() { return ::Udm::InstantiatedAttr< CompoundStatement>(impl); }
	CompoundStatement CompoundStatement::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CompoundStatement> CompoundStatement::Derived() { return ::Udm::DerivedAttr< CompoundStatement>(impl); }
	::Udm::ArchetypeAttr< CompoundStatement> CompoundStatement::Archetype() const { return ::Udm::ArchetypeAttr< CompoundStatement>(impl); }
	::Udm::IntegerAttr CompoundStatement::statementCount() const { return ::Udm::IntegerAttr(impl, meta_statementCount); }
	::Udm::ChildrenAttr< ::SFC::Statement> CompoundStatement::stmnt() const { return ::Udm::ChildrenAttr< ::SFC::Statement>(impl, meta_stmnt); }
	::Udm::ChildrenAttr< ::SFC::Function> CompoundStatement::Function_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Function>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::SimpleStatement> CompoundStatement::SimpleStatement_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::SimpleStatement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ConditionalBlock> CompoundStatement::ConditionalBlock_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ConditionalBlock>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Return> CompoundStatement::Return_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Return>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Program> CompoundStatement::Program_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Program>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::CompoundStatement> CompoundStatement::CompoundStatement_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Statement> CompoundStatement::Statement_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Statement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UserCode> CompoundStatement::UserCode_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UserCode>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Block> CompoundStatement::Block_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Block>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::OperationalStatement> CompoundStatement::OperationalStatement_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::OperationalStatement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ConditionalGroup> CompoundStatement::ConditionalGroup_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ConditionalGroup>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::IterativeBlock> CompoundStatement::IterativeBlock_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::IterativeBlock>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::LocalVar> CompoundStatement::LocalVar_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::LocalVar>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::StateVar> CompoundStatement::StateVar_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::StateVar>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::StateLabel> CompoundStatement::StateLabel_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::StateLabel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::FunctionCall> CompoundStatement::FunctionCall_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Var> CompoundStatement::Var_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Var>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::SetState> CompoundStatement::SetState_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::SetState>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::SetVar> CompoundStatement::SetVar_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::SetVar>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Declaration> CompoundStatement::Declaration_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Declaration>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::DT> CompoundStatement::DT_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::DT>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Struct> CompoundStatement::Struct_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Struct>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Class> CompoundStatement::Class_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Class>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Project> CompoundStatement::Project_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Project>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Array> CompoundStatement::Array_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Array>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BasicType> CompoundStatement::BasicType_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BasicType>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Comment> CompoundStatement::Comment_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Comment>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> CompoundStatement::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CompoundStatement::meta;
	::Uml::Attribute CompoundStatement::meta_statementCount;
	::Uml::CompositionChildRole CompoundStatement::meta_stmnt;

	Statement::Statement() {}
	Statement::Statement(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Statement::Statement(const Statement &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Statement::Statement(Statement &&master) : UDM_OBJECT(master) {};

	Statement Statement::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Statement& Statement::operator=(Statement &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Statement Statement::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Statement Statement::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Statement Statement::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Statement> Statement::Instances() { return ::Udm::InstantiatedAttr< Statement>(impl); }
	Statement Statement::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Statement> Statement::Derived() { return ::Udm::DerivedAttr< Statement>(impl); }
	::Udm::ArchetypeAttr< Statement> Statement::Archetype() const { return ::Udm::ArchetypeAttr< Statement>(impl); }
	::Udm::IntegerAttr Statement::statementIndex() const { return ::Udm::IntegerAttr(impl, meta_statementIndex); }
	::Udm::StringAttr Statement::RefId() const { return ::Udm::StringAttr(impl, meta_RefId); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Statement::csPar() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, meta_csPar); }
	::Udm::ParentAttr< ::SFC::Statement> Statement::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Statement::meta;
	::Uml::Attribute Statement::meta_statementIndex;
	::Uml::Attribute Statement::meta_RefId;
	::Uml::CompositionParentRole Statement::meta_csPar;

	UserCode::UserCode() {}
	UserCode::UserCode(::Udm::ObjectImpl *impl) : Condition(impl),SimpleStatement(impl), UDM_OBJECT(impl) {}
	UserCode::UserCode(const UserCode &master) : Condition(master),SimpleStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	UserCode::UserCode(UserCode &&master) : Condition(master),SimpleStatement(master), UDM_OBJECT(master) {};

	UserCode UserCode::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	UserCode& UserCode::operator=(UserCode &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	UserCode UserCode::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	UserCode UserCode::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	UserCode UserCode::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< UserCode> UserCode::Instances() { return ::Udm::InstantiatedAttr< UserCode>(impl); }
	UserCode UserCode::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< UserCode> UserCode::Derived() { return ::Udm::DerivedAttr< UserCode>(impl); }
	::Udm::ArchetypeAttr< UserCode> UserCode::Archetype() const { return ::Udm::ArchetypeAttr< UserCode>(impl); }
	::Udm::StringAttr UserCode::expr() const { return ::Udm::StringAttr(impl, meta_expr); }
	::Udm::ChildAttr< ::SFC::Exprs> UserCode::codeexpr() const { return ::Udm::ChildAttr< ::SFC::Exprs>(impl, meta_codeexpr); }
	::Udm::ChildrenAttr< ::SFC::FunctionCall> UserCode::FunctionCall_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Str> UserCode::Str_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Str>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Double> UserCode::Double_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Double>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Int> UserCode::Int_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Int>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BinaryExprs> UserCode::BinaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UnaryExprs> UserCode::UnaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::NullaryExprs> UserCode::NullaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Exprs> UserCode::Exprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Exprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclRef> UserCode::ArgDeclRef_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> UserCode::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class UserCode::meta;
	::Uml::Attribute UserCode::meta_expr;
	::Uml::CompositionChildRole UserCode::meta_codeexpr;

	Block::Block() {}
	Block::Block(::Udm::ObjectImpl *impl) : CompoundStatement(impl), UDM_OBJECT(impl) {}
	Block::Block(const Block &master) : CompoundStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Block::Block(Block &&master) : CompoundStatement(master), UDM_OBJECT(master) {};

	Block Block::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Block& Block::operator=(Block &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Block Block::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Block Block::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Block Block::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Block> Block::Instances() { return ::Udm::InstantiatedAttr< Block>(impl); }
	Block Block::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Block> Block::Derived() { return ::Udm::DerivedAttr< Block>(impl); }
	::Udm::ArchetypeAttr< Block> Block::Archetype() const { return ::Udm::ArchetypeAttr< Block>(impl); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Block::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Block::meta;

	OperationalStatement::OperationalStatement() {}
	OperationalStatement::OperationalStatement(::Udm::ObjectImpl *impl) : Statement(impl), UDM_OBJECT(impl) {}
	OperationalStatement::OperationalStatement(const OperationalStatement &master) : Statement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OperationalStatement::OperationalStatement(OperationalStatement &&master) : Statement(master), UDM_OBJECT(master) {};

	OperationalStatement OperationalStatement::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OperationalStatement& OperationalStatement::operator=(OperationalStatement &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OperationalStatement OperationalStatement::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OperationalStatement OperationalStatement::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OperationalStatement OperationalStatement::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OperationalStatement> OperationalStatement::Instances() { return ::Udm::InstantiatedAttr< OperationalStatement>(impl); }
	OperationalStatement OperationalStatement::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OperationalStatement> OperationalStatement::Derived() { return ::Udm::DerivedAttr< OperationalStatement>(impl); }
	::Udm::ArchetypeAttr< OperationalStatement> OperationalStatement::Archetype() const { return ::Udm::ArchetypeAttr< OperationalStatement>(impl); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> OperationalStatement::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OperationalStatement::meta;

	ConditionalGroup::ConditionalGroup() {}
	ConditionalGroup::ConditionalGroup(::Udm::ObjectImpl *impl) : CompoundStatement(impl), UDM_OBJECT(impl) {}
	ConditionalGroup::ConditionalGroup(const ConditionalGroup &master) : CompoundStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ConditionalGroup::ConditionalGroup(ConditionalGroup &&master) : CompoundStatement(master), UDM_OBJECT(master) {};

	ConditionalGroup ConditionalGroup::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ConditionalGroup& ConditionalGroup::operator=(ConditionalGroup &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ConditionalGroup ConditionalGroup::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ConditionalGroup ConditionalGroup::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ConditionalGroup ConditionalGroup::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ConditionalGroup> ConditionalGroup::Instances() { return ::Udm::InstantiatedAttr< ConditionalGroup>(impl); }
	ConditionalGroup ConditionalGroup::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ConditionalGroup> ConditionalGroup::Derived() { return ::Udm::DerivedAttr< ConditionalGroup>(impl); }
	::Udm::ArchetypeAttr< ConditionalGroup> ConditionalGroup::Archetype() const { return ::Udm::ArchetypeAttr< ConditionalGroup>(impl); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> ConditionalGroup::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ConditionalGroup::meta;

	IterativeBlock::IterativeBlock() {}
	IterativeBlock::IterativeBlock(::Udm::ObjectImpl *impl) : Block(impl), UDM_OBJECT(impl) {}
	IterativeBlock::IterativeBlock(const IterativeBlock &master) : Block(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IterativeBlock::IterativeBlock(IterativeBlock &&master) : Block(master), UDM_OBJECT(master) {};

	IterativeBlock IterativeBlock::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IterativeBlock& IterativeBlock::operator=(IterativeBlock &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IterativeBlock IterativeBlock::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IterativeBlock IterativeBlock::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IterativeBlock IterativeBlock::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IterativeBlock> IterativeBlock::Instances() { return ::Udm::InstantiatedAttr< IterativeBlock>(impl); }
	IterativeBlock IterativeBlock::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IterativeBlock> IterativeBlock::Derived() { return ::Udm::DerivedAttr< IterativeBlock>(impl); }
	::Udm::ArchetypeAttr< IterativeBlock> IterativeBlock::Archetype() const { return ::Udm::ArchetypeAttr< IterativeBlock>(impl); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> IterativeBlock::counter() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_counter); }
	::Udm::CrossAssocAttr< ::SFC::Array> IterativeBlock::ary() const { return ::Udm::CrossAssocAttr< ::SFC::Array>(impl, meta_ary); }
	::Udm::ChildrenAttr< ::SFC::Condition> IterativeBlock::cond() const { return ::Udm::ChildrenAttr< ::SFC::Condition>(impl, meta_cond); }
	::Udm::ChildrenAttr< ::SFC::Condition> IterativeBlock::Condition_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Condition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UserCode> IterativeBlock::UserCode_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UserCode>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::CheckArg> IterativeBlock::CheckArg_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::CheckArg>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::CheckState> IterativeBlock::CheckState_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::CheckState>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> IterativeBlock::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IterativeBlock::meta;
	::Uml::AssociationRole IterativeBlock::meta_counter;
	::Uml::AssociationRole IterativeBlock::meta_ary;
	::Uml::CompositionChildRole IterativeBlock::meta_cond;

	LocalVar::LocalVar() {}
	LocalVar::LocalVar(::Udm::ObjectImpl *impl) : Var(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	LocalVar::LocalVar(const LocalVar &master) : Var(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	LocalVar::LocalVar(LocalVar &&master) : Var(master), TypedEntity(master), UDM_OBJECT(master) {};

	LocalVar LocalVar::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	LocalVar& LocalVar::operator=(LocalVar &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	LocalVar LocalVar::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	LocalVar LocalVar::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	LocalVar LocalVar::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< LocalVar> LocalVar::Instances() { return ::Udm::InstantiatedAttr< LocalVar>(impl); }
	LocalVar LocalVar::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< LocalVar> LocalVar::Derived() { return ::Udm::DerivedAttr< LocalVar>(impl); }
	::Udm::ArchetypeAttr< LocalVar> LocalVar::Archetype() const { return ::Udm::ArchetypeAttr< LocalVar>(impl); }
	::Udm::StringAttr LocalVar::initial() const { return ::Udm::StringAttr(impl, meta_initial); }
	::Udm::BooleanAttr LocalVar::Static() const { return ::Udm::BooleanAttr(impl, meta_Static); }
	::Udm::AClassAssocAttr< SetVar, Arg> LocalVar::arg() const { return ::Udm::AClassAssocAttr< SetVar, Arg>(impl, meta_arg, meta_arg_rev); }
	::Udm::CrossAssocAttr< ::SFC::Arg> LocalVar::argument() const { return ::Udm::CrossAssocAttr< ::SFC::Arg>(impl, meta_argument); }
	::Udm::CrossPointerAttr< ::SFC::IterativeBlock> LocalVar::loop() const { return ::Udm::CrossPointerAttr< ::SFC::IterativeBlock>(impl, meta_loop); }
	::Udm::CrossAssocAttr< ::SFC::Class> LocalVar::klass() const { return ::Udm::CrossAssocAttr< ::SFC::Class>(impl, meta_klass); }
	::Udm::ParentAttr< ::SFC::Statement> LocalVar::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class LocalVar::meta;
	::Uml::Attribute LocalVar::meta_initial;
	::Uml::Attribute LocalVar::meta_Static;
	::Uml::AssociationRole LocalVar::meta_arg;
	::Uml::AssociationRole LocalVar::meta_arg_rev;
	::Uml::AssociationRole LocalVar::meta_argument;
	::Uml::AssociationRole LocalVar::meta_loop;
	::Uml::AssociationRole LocalVar::meta_klass;

	StateVar::StateVar() {}
	StateVar::StateVar(::Udm::ObjectImpl *impl) : Var(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	StateVar::StateVar(const StateVar &master) : Var(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StateVar::StateVar(StateVar &&master) : Var(master), TypedEntity(master), UDM_OBJECT(master) {};

	StateVar StateVar::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateVar& StateVar::operator=(StateVar &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateVar StateVar::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateVar StateVar::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateVar StateVar::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateVar> StateVar::Instances() { return ::Udm::InstantiatedAttr< StateVar>(impl); }
	StateVar StateVar::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateVar> StateVar::Derived() { return ::Udm::DerivedAttr< StateVar>(impl); }
	::Udm::ArchetypeAttr< StateVar> StateVar::Archetype() const { return ::Udm::ArchetypeAttr< StateVar>(impl); }
	::Udm::AssocAttr< StateRel> StateVar::srs() const { return ::Udm::AssocAttr< StateRel>(impl, meta_srs); }
	::Udm::ParentAttr< ::SFC::Statement> StateVar::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateVar::meta;
	::Uml::AssociationRole StateVar::meta_srs;

	StateLabel::StateLabel() {}
	StateLabel::StateLabel(::Udm::ObjectImpl *impl) : Declaration(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	StateLabel::StateLabel(const StateLabel &master) : Declaration(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StateLabel::StateLabel(StateLabel &&master) : Declaration(master), TypedEntity(master), UDM_OBJECT(master) {};

	StateLabel StateLabel::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateLabel& StateLabel::operator=(StateLabel &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateLabel StateLabel::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateLabel StateLabel::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateLabel StateLabel::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateLabel> StateLabel::Instances() { return ::Udm::InstantiatedAttr< StateLabel>(impl); }
	StateLabel StateLabel::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateLabel> StateLabel::Derived() { return ::Udm::DerivedAttr< StateLabel>(impl); }
	::Udm::ArchetypeAttr< StateLabel> StateLabel::Archetype() const { return ::Udm::ArchetypeAttr< StateLabel>(impl); }
	::Udm::StringAttr StateLabel::comment() const { return ::Udm::StringAttr(impl, meta_comment); }
	::Udm::IntegerAttr StateLabel::value() const { return ::Udm::IntegerAttr(impl, meta_value); }
	::Udm::IntegerAttr StateLabel::andSS() const { return ::Udm::IntegerAttr(impl, meta_andSS); }
	::Udm::AClassAssocAttr< CheckArg, Arg> StateLabel::arg() const { return ::Udm::AClassAssocAttr< CheckArg, Arg>(impl, meta_arg, meta_arg_rev); }
	::Udm::AssocAttr< StateRel> StateLabel::srv() const { return ::Udm::AssocAttr< StateRel>(impl, meta_srv); }
	::Udm::AssocAttr< StateRel> StateLabel::sri() const { return ::Udm::AssocAttr< StateRel>(impl, meta_sri); }
	::Udm::ParentAttr< ::SFC::Statement> StateLabel::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateLabel::meta;
	::Uml::Attribute StateLabel::meta_comment;
	::Uml::Attribute StateLabel::meta_value;
	::Uml::Attribute StateLabel::meta_andSS;
	::Uml::AssociationRole StateLabel::meta_arg;
	::Uml::AssociationRole StateLabel::meta_arg_rev;
	::Uml::AssociationRole StateLabel::meta_srv;
	::Uml::AssociationRole StateLabel::meta_sri;

	FunctionCall::FunctionCall() {}
	FunctionCall::FunctionCall(::Udm::ObjectImpl *impl) : SimpleStatement(impl),NullaryExprs(impl), UDM_OBJECT(impl) {}
	FunctionCall::FunctionCall(const FunctionCall &master) : SimpleStatement(master),NullaryExprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FunctionCall::FunctionCall(FunctionCall &&master) : SimpleStatement(master),NullaryExprs(master), UDM_OBJECT(master) {};

	FunctionCall FunctionCall::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FunctionCall& FunctionCall::operator=(FunctionCall &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FunctionCall FunctionCall::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FunctionCall FunctionCall::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FunctionCall FunctionCall::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FunctionCall> FunctionCall::Instances() { return ::Udm::InstantiatedAttr< FunctionCall>(impl); }
	FunctionCall FunctionCall::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FunctionCall> FunctionCall::Derived() { return ::Udm::DerivedAttr< FunctionCall>(impl); }
	::Udm::ArchetypeAttr< FunctionCall> FunctionCall::Archetype() const { return ::Udm::ArchetypeAttr< FunctionCall>(impl); }
	::Udm::IntegerAttr FunctionCall::argCount() const { return ::Udm::IntegerAttr(impl, meta_argCount); }
	::Udm::StringAttr FunctionCall::libFuncName() const { return ::Udm::StringAttr(impl, meta_libFuncName); }
	::Udm::PointerAttr< Function> FunctionCall::callee() const { return ::Udm::PointerAttr< Function>(impl, meta_callee); }
	::Udm::ChildrenAttr< ::SFC::ArgVal> FunctionCall::ArgVal_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgVal>(impl, meta_ArgVal_children); }
	::Udm::ChildrenAttr< ::SFC::ArgVal> FunctionCall::ArgVal_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgVal>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::Udm::Object> FunctionCall::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FunctionCall::meta;
	::Uml::Attribute FunctionCall::meta_argCount;
	::Uml::Attribute FunctionCall::meta_libFuncName;
	::Uml::AssociationRole FunctionCall::meta_callee;
	::Uml::CompositionChildRole FunctionCall::meta_ArgVal_children;

	ArgVal::ArgVal() {}
	ArgVal::ArgVal(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ArgVal::ArgVal(const ArgVal &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ArgVal::ArgVal(ArgVal &&master) : UDM_OBJECT(master) {};

	ArgVal ArgVal::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ArgVal& ArgVal::operator=(ArgVal &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ArgVal ArgVal::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ArgVal ArgVal::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ArgVal ArgVal::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ArgVal> ArgVal::Instances() { return ::Udm::InstantiatedAttr< ArgVal>(impl); }
	ArgVal ArgVal::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ArgVal> ArgVal::Derived() { return ::Udm::DerivedAttr< ArgVal>(impl); }
	::Udm::ArchetypeAttr< ArgVal> ArgVal::Archetype() const { return ::Udm::ArchetypeAttr< ArgVal>(impl); }
	::Udm::StringAttr ArgVal::val() const { return ::Udm::StringAttr(impl, meta_val); }
	::Udm::IntegerAttr ArgVal::argIndex() const { return ::Udm::IntegerAttr(impl, meta_argIndex); }
	::Udm::AssocAttr< Arg> ArgVal::arg() const { return ::Udm::AssocAttr< Arg>(impl, meta_arg); }
	::Udm::ChildAttr< ::SFC::Exprs> ArgVal::argexpr() const { return ::Udm::ChildAttr< ::SFC::Exprs>(impl, meta_argexpr); }
	::Udm::ChildrenAttr< ::SFC::FunctionCall> ArgVal::FunctionCall_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Str> ArgVal::Str_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Str>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Double> ArgVal::Double_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Double>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Int> ArgVal::Int_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Int>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BinaryExprs> ArgVal::BinaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UnaryExprs> ArgVal::UnaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::NullaryExprs> ArgVal::NullaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Exprs> ArgVal::Exprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Exprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclRef> ArgVal::ArgDeclRef_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::FunctionCall> ArgVal::FunctionCall_parent() const { return ::Udm::ParentAttr< ::SFC::FunctionCall>(impl, meta_FunctionCall_parent); }
	::Udm::ParentAttr< ::SFC::FunctionCall> ArgVal::parent() const { return ::Udm::ParentAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ArgVal::meta;
	::Uml::Attribute ArgVal::meta_val;
	::Uml::Attribute ArgVal::meta_argIndex;
	::Uml::AssociationRole ArgVal::meta_arg;
	::Uml::CompositionChildRole ArgVal::meta_argexpr;
	::Uml::CompositionParentRole ArgVal::meta_FunctionCall_parent;

	Var::Var() {}
	Var::Var(::Udm::ObjectImpl *impl) : Declaration(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	Var::Var(const Var &master) : Declaration(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Var::Var(Var &&master) : Declaration(master), TypedEntity(master), UDM_OBJECT(master) {};

	Var Var::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Var& Var::operator=(Var &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Var Var::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Var Var::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Var Var::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Var> Var::Instances() { return ::Udm::InstantiatedAttr< Var>(impl); }
	Var Var::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Var> Var::Derived() { return ::Udm::DerivedAttr< Var>(impl); }
	::Udm::ArchetypeAttr< Var> Var::Archetype() const { return ::Udm::ArchetypeAttr< Var>(impl); }
	::Udm::StringAttr Var::type() const { return ::Udm::StringAttr(impl, meta_type); }
	::Udm::IntegerAttr Var::size() const { return ::Udm::IntegerAttr(impl, meta_size); }
	::Udm::ParentAttr< ::SFC::Statement> Var::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Var::meta;
	::Uml::Attribute Var::meta_type;
	::Uml::Attribute Var::meta_size;

	StateRel::StateRel() {}
	StateRel::StateRel(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	StateRel::StateRel(const StateRel &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StateRel::StateRel(StateRel &&master) : UDM_OBJECT(master) {};

	StateRel StateRel::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateRel& StateRel::operator=(StateRel &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateRel StateRel::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateRel StateRel::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateRel StateRel::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateRel> StateRel::Instances() { return ::Udm::InstantiatedAttr< StateRel>(impl); }
	StateRel StateRel::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateRel> StateRel::Derived() { return ::Udm::DerivedAttr< StateRel>(impl); }
	::Udm::ArchetypeAttr< StateRel> StateRel::Archetype() const { return ::Udm::ArchetypeAttr< StateRel>(impl); }
	::Udm::BooleanAttr StateRel::andState() const { return ::Udm::BooleanAttr(impl, meta_andState); }
	::Udm::BooleanAttr StateRel::invert() const { return ::Udm::BooleanAttr(impl, meta_invert); }
	::Udm::PointerAttr< StateLabel> StateRel::value() const { return ::Udm::PointerAttr< StateLabel>(impl, meta_value); }
	::Udm::PointerAttr< StateLabel> StateRel::index() const { return ::Udm::PointerAttr< StateLabel>(impl, meta_index); }
	::Udm::PointerAttr< StateVar> StateRel::svar() const { return ::Udm::PointerAttr< StateVar>(impl, meta_svar); }
	::Udm::ParentAttr< ::Udm::Object> StateRel::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateRel::meta;
	::Uml::Attribute StateRel::meta_andState;
	::Uml::Attribute StateRel::meta_invert;
	::Uml::AssociationRole StateRel::meta_value;
	::Uml::AssociationRole StateRel::meta_index;
	::Uml::AssociationRole StateRel::meta_svar;

	CheckArg::CheckArg() {}
	CheckArg::CheckArg(::Udm::ObjectImpl *impl) : Condition(impl), UDM_OBJECT(impl) {}
	CheckArg::CheckArg(const CheckArg &master) : Condition(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CheckArg::CheckArg(CheckArg &&master) : Condition(master), UDM_OBJECT(master) {};

	CheckArg CheckArg::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CheckArg& CheckArg::operator=(CheckArg &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CheckArg CheckArg::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CheckArg CheckArg::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CheckArg CheckArg::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CheckArg> CheckArg::Instances() { return ::Udm::InstantiatedAttr< CheckArg>(impl); }
	CheckArg CheckArg::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CheckArg> CheckArg::Derived() { return ::Udm::DerivedAttr< CheckArg>(impl); }
	::Udm::ArchetypeAttr< CheckArg> CheckArg::Archetype() const { return ::Udm::ArchetypeAttr< CheckArg>(impl); }
	::Udm::ParentAttr< ::SFC::Block> CheckArg::parent() const { return ::Udm::ParentAttr< ::SFC::Block>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::SFC::Arg> CheckArg::arg_end() const { return ::Udm::AssocEndAttr< ::SFC::Arg>(impl, meta_arg_end_); }
	::Udm::AssocEndAttr< ::SFC::StateLabel> CheckArg::slab_end() const { return ::Udm::AssocEndAttr< ::SFC::StateLabel>(impl, meta_slab_end_); }

	::Uml::Class CheckArg::meta;
	::Uml::AssociationRole CheckArg::meta_arg_end_;
	::Uml::AssociationRole CheckArg::meta_slab_end_;

	SetState::SetState() {}
	SetState::SetState(::Udm::ObjectImpl *impl) : SimpleStatement(impl),StateRel(impl), UDM_OBJECT(impl) {}
	SetState::SetState(const SetState &master) : SimpleStatement(master),StateRel(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SetState::SetState(SetState &&master) : SimpleStatement(master),StateRel(master), UDM_OBJECT(master) {};

	SetState SetState::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SetState& SetState::operator=(SetState &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SetState SetState::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SetState SetState::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SetState SetState::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SetState> SetState::Instances() { return ::Udm::InstantiatedAttr< SetState>(impl); }
	SetState SetState::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SetState> SetState::Derived() { return ::Udm::DerivedAttr< SetState>(impl); }
	::Udm::ArchetypeAttr< SetState> SetState::Archetype() const { return ::Udm::ArchetypeAttr< SetState>(impl); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> SetState::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class SetState::meta;

	CheckState::CheckState() {}
	CheckState::CheckState(::Udm::ObjectImpl *impl) : Condition(impl),StateRel(impl), UDM_OBJECT(impl) {}
	CheckState::CheckState(const CheckState &master) : Condition(master),StateRel(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CheckState::CheckState(CheckState &&master) : Condition(master),StateRel(master), UDM_OBJECT(master) {};

	CheckState CheckState::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CheckState& CheckState::operator=(CheckState &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CheckState CheckState::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CheckState CheckState::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CheckState CheckState::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CheckState> CheckState::Instances() { return ::Udm::InstantiatedAttr< CheckState>(impl); }
	CheckState CheckState::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CheckState> CheckState::Derived() { return ::Udm::DerivedAttr< CheckState>(impl); }
	::Udm::ArchetypeAttr< CheckState> CheckState::Archetype() const { return ::Udm::ArchetypeAttr< CheckState>(impl); }
	::Udm::ParentAttr< ::SFC::Block> CheckState::parent() const { return ::Udm::ParentAttr< ::SFC::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CheckState::meta;

	SetVar::SetVar() {}
	SetVar::SetVar(::Udm::ObjectImpl *impl) : SimpleStatement(impl), UDM_OBJECT(impl) {}
	SetVar::SetVar(const SetVar &master) : SimpleStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SetVar::SetVar(SetVar &&master) : SimpleStatement(master), UDM_OBJECT(master) {};

	SetVar SetVar::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SetVar& SetVar::operator=(SetVar &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SetVar SetVar::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SetVar SetVar::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SetVar SetVar::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SetVar> SetVar::Instances() { return ::Udm::InstantiatedAttr< SetVar>(impl); }
	SetVar SetVar::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SetVar> SetVar::Derived() { return ::Udm::DerivedAttr< SetVar>(impl); }
	::Udm::ArchetypeAttr< SetVar> SetVar::Archetype() const { return ::Udm::ArchetypeAttr< SetVar>(impl); }
	::Udm::BooleanAttr SetVar::invert() const { return ::Udm::BooleanAttr(impl, meta_invert); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> SetVar::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::SFC::Arg> SetVar::arg_end() const { return ::Udm::AssocEndAttr< ::SFC::Arg>(impl, meta_arg_end_); }
	::Udm::AssocEndAttr< ::SFC::LocalVar> SetVar::lvar_end() const { return ::Udm::AssocEndAttr< ::SFC::LocalVar>(impl, meta_lvar_end_); }

	::Uml::Class SetVar::meta;
	::Uml::Attribute SetVar::meta_invert;
	::Uml::AssociationRole SetVar::meta_arg_end_;
	::Uml::AssociationRole SetVar::meta_lvar_end_;

	Str::Str() {}
	Str::Str(::Udm::ObjectImpl *impl) : NullaryExprs(impl), UDM_OBJECT(impl) {}
	Str::Str(const Str &master) : NullaryExprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Str::Str(Str &&master) : NullaryExprs(master), UDM_OBJECT(master) {};

	Str Str::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Str& Str::operator=(Str &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Str Str::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Str Str::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Str Str::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Str> Str::Instances() { return ::Udm::InstantiatedAttr< Str>(impl); }
	Str Str::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Str> Str::Derived() { return ::Udm::DerivedAttr< Str>(impl); }
	::Udm::ArchetypeAttr< Str> Str::Archetype() const { return ::Udm::ArchetypeAttr< Str>(impl); }
	::Udm::StringAttr Str::val() const { return ::Udm::StringAttr(impl, meta_val); }
	::Udm::ParentAttr< ::Udm::Object> Str::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Str::meta;
	::Uml::Attribute Str::meta_val;

	Double::Double() {}
	Double::Double(::Udm::ObjectImpl *impl) : NullaryExprs(impl), UDM_OBJECT(impl) {}
	Double::Double(const Double &master) : NullaryExprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Double::Double(Double &&master) : NullaryExprs(master), UDM_OBJECT(master) {};

	Double Double::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Double& Double::operator=(Double &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Double Double::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Double Double::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Double Double::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Double> Double::Instances() { return ::Udm::InstantiatedAttr< Double>(impl); }
	Double Double::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Double> Double::Derived() { return ::Udm::DerivedAttr< Double>(impl); }
	::Udm::ArchetypeAttr< Double> Double::Archetype() const { return ::Udm::ArchetypeAttr< Double>(impl); }
	::Udm::RealAttr Double::val() const { return ::Udm::RealAttr(impl, meta_val); }
	::Udm::ParentAttr< ::Udm::Object> Double::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Double::meta;
	::Uml::Attribute Double::meta_val;

	Int::Int() {}
	Int::Int(::Udm::ObjectImpl *impl) : NullaryExprs(impl), UDM_OBJECT(impl) {}
	Int::Int(const Int &master) : NullaryExprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Int::Int(Int &&master) : NullaryExprs(master), UDM_OBJECT(master) {};

	Int Int::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Int& Int::operator=(Int &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Int Int::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Int Int::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Int Int::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Int> Int::Instances() { return ::Udm::InstantiatedAttr< Int>(impl); }
	Int Int::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Int> Int::Derived() { return ::Udm::DerivedAttr< Int>(impl); }
	::Udm::ArchetypeAttr< Int> Int::Archetype() const { return ::Udm::ArchetypeAttr< Int>(impl); }
	::Udm::IntegerAttr Int::val() const { return ::Udm::IntegerAttr(impl, meta_val); }
	::Udm::ParentAttr< ::Udm::Object> Int::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Int::meta;
	::Uml::Attribute Int::meta_val;

	BinaryExprs::BinaryExprs() {}
	BinaryExprs::BinaryExprs(::Udm::ObjectImpl *impl) : Exprs(impl), UDM_OBJECT(impl) {}
	BinaryExprs::BinaryExprs(const BinaryExprs &master) : Exprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	BinaryExprs::BinaryExprs(BinaryExprs &&master) : Exprs(master), UDM_OBJECT(master) {};

	BinaryExprs BinaryExprs::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BinaryExprs& BinaryExprs::operator=(BinaryExprs &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BinaryExprs BinaryExprs::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BinaryExprs BinaryExprs::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BinaryExprs BinaryExprs::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BinaryExprs> BinaryExprs::Instances() { return ::Udm::InstantiatedAttr< BinaryExprs>(impl); }
	BinaryExprs BinaryExprs::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BinaryExprs> BinaryExprs::Derived() { return ::Udm::DerivedAttr< BinaryExprs>(impl); }
	::Udm::ArchetypeAttr< BinaryExprs> BinaryExprs::Archetype() const { return ::Udm::ArchetypeAttr< BinaryExprs>(impl); }
	::Udm::StringAttr BinaryExprs::op() const { return ::Udm::StringAttr(impl, meta_op); }
	::Udm::ChildAttr< ::SFC::Exprs> BinaryExprs::rightexpr() const { return ::Udm::ChildAttr< ::SFC::Exprs>(impl, meta_rightexpr); }
	::Udm::ChildAttr< ::SFC::Exprs> BinaryExprs::leftexpr() const { return ::Udm::ChildAttr< ::SFC::Exprs>(impl, meta_leftexpr); }
	::Udm::ChildrenAttr< ::SFC::FunctionCall> BinaryExprs::FunctionCall_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Str> BinaryExprs::Str_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Str>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Double> BinaryExprs::Double_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Double>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Int> BinaryExprs::Int_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Int>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BinaryExprs> BinaryExprs::BinaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UnaryExprs> BinaryExprs::UnaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::NullaryExprs> BinaryExprs::NullaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Exprs> BinaryExprs::Exprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Exprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclRef> BinaryExprs::ArgDeclRef_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::Udm::Object> BinaryExprs::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BinaryExprs::meta;
	::Uml::Attribute BinaryExprs::meta_op;
	::Uml::CompositionChildRole BinaryExprs::meta_rightexpr;
	::Uml::CompositionChildRole BinaryExprs::meta_leftexpr;

	UnaryExprs::UnaryExprs() {}
	UnaryExprs::UnaryExprs(::Udm::ObjectImpl *impl) : Exprs(impl), UDM_OBJECT(impl) {}
	UnaryExprs::UnaryExprs(const UnaryExprs &master) : Exprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	UnaryExprs::UnaryExprs(UnaryExprs &&master) : Exprs(master), UDM_OBJECT(master) {};

	UnaryExprs UnaryExprs::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	UnaryExprs& UnaryExprs::operator=(UnaryExprs &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	UnaryExprs UnaryExprs::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	UnaryExprs UnaryExprs::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	UnaryExprs UnaryExprs::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< UnaryExprs> UnaryExprs::Instances() { return ::Udm::InstantiatedAttr< UnaryExprs>(impl); }
	UnaryExprs UnaryExprs::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< UnaryExprs> UnaryExprs::Derived() { return ::Udm::DerivedAttr< UnaryExprs>(impl); }
	::Udm::ArchetypeAttr< UnaryExprs> UnaryExprs::Archetype() const { return ::Udm::ArchetypeAttr< UnaryExprs>(impl); }
	::Udm::StringAttr UnaryExprs::op() const { return ::Udm::StringAttr(impl, meta_op); }
	::Udm::ChildAttr< ::SFC::Exprs> UnaryExprs::subexpr() const { return ::Udm::ChildAttr< ::SFC::Exprs>(impl, meta_subexpr); }
	::Udm::ChildrenAttr< ::SFC::FunctionCall> UnaryExprs::FunctionCall_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::FunctionCall>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Str> UnaryExprs::Str_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Str>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Double> UnaryExprs::Double_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Double>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Int> UnaryExprs::Int_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Int>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BinaryExprs> UnaryExprs::BinaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BinaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::UnaryExprs> UnaryExprs::UnaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::UnaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::NullaryExprs> UnaryExprs::NullaryExprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::NullaryExprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Exprs> UnaryExprs::Exprs_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Exprs>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclRef> UnaryExprs::ArgDeclRef_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::Udm::Object> UnaryExprs::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class UnaryExprs::meta;
	::Uml::Attribute UnaryExprs::meta_op;
	::Uml::CompositionChildRole UnaryExprs::meta_subexpr;

	NullaryExprs::NullaryExprs() {}
	NullaryExprs::NullaryExprs(::Udm::ObjectImpl *impl) : Exprs(impl), UDM_OBJECT(impl) {}
	NullaryExprs::NullaryExprs(const NullaryExprs &master) : Exprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	NullaryExprs::NullaryExprs(NullaryExprs &&master) : Exprs(master), UDM_OBJECT(master) {};

	NullaryExprs NullaryExprs::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	NullaryExprs& NullaryExprs::operator=(NullaryExprs &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	NullaryExprs NullaryExprs::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	NullaryExprs NullaryExprs::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	NullaryExprs NullaryExprs::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< NullaryExprs> NullaryExprs::Instances() { return ::Udm::InstantiatedAttr< NullaryExprs>(impl); }
	NullaryExprs NullaryExprs::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< NullaryExprs> NullaryExprs::Derived() { return ::Udm::DerivedAttr< NullaryExprs>(impl); }
	::Udm::ArchetypeAttr< NullaryExprs> NullaryExprs::Archetype() const { return ::Udm::ArchetypeAttr< NullaryExprs>(impl); }
	::Udm::ParentAttr< ::Udm::Object> NullaryExprs::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class NullaryExprs::meta;

	Exprs::Exprs() {}
	Exprs::Exprs(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Exprs::Exprs(const Exprs &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Exprs::Exprs(Exprs &&master) : UDM_OBJECT(master) {};

	Exprs Exprs::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Exprs& Exprs::operator=(Exprs &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Exprs Exprs::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Exprs Exprs::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Exprs Exprs::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Exprs> Exprs::Instances() { return ::Udm::InstantiatedAttr< Exprs>(impl); }
	Exprs Exprs::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Exprs> Exprs::Derived() { return ::Udm::DerivedAttr< Exprs>(impl); }
	::Udm::ArchetypeAttr< Exprs> Exprs::Archetype() const { return ::Udm::ArchetypeAttr< Exprs>(impl); }
	::Udm::ParentAttr< ::SFC::Return> Exprs::retexprpar() const { return ::Udm::ParentAttr< ::SFC::Return>(impl, meta_retexprpar); }
	::Udm::ParentAttr< ::SFC::UserCode> Exprs::codeexprpar() const { return ::Udm::ParentAttr< ::SFC::UserCode>(impl, meta_codeexprpar); }
	::Udm::ParentAttr< ::SFC::ArgVal> Exprs::argexprpar() const { return ::Udm::ParentAttr< ::SFC::ArgVal>(impl, meta_argexprpar); }
	::Udm::ParentAttr< ::SFC::BinaryExprs> Exprs::rightexprpar() const { return ::Udm::ParentAttr< ::SFC::BinaryExprs>(impl, meta_rightexprpar); }
	::Udm::ParentAttr< ::SFC::BinaryExprs> Exprs::leftexprpar() const { return ::Udm::ParentAttr< ::SFC::BinaryExprs>(impl, meta_leftexprpar); }
	::Udm::ParentAttr< ::SFC::UnaryExprs> Exprs::subexprpar() const { return ::Udm::ParentAttr< ::SFC::UnaryExprs>(impl, meta_subexprpar); }
	::Udm::ParentAttr< ::Udm::Object> Exprs::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Exprs::meta;
	::Uml::CompositionParentRole Exprs::meta_retexprpar;
	::Uml::CompositionParentRole Exprs::meta_codeexprpar;
	::Uml::CompositionParentRole Exprs::meta_argexprpar;
	::Uml::CompositionParentRole Exprs::meta_rightexprpar;
	::Uml::CompositionParentRole Exprs::meta_leftexprpar;
	::Uml::CompositionParentRole Exprs::meta_subexprpar;

	Declaration::Declaration() {}
	Declaration::Declaration(::Udm::ObjectImpl *impl) : Statement(impl),ArgDeclBase(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	Declaration::Declaration(const Declaration &master) : Statement(master),ArgDeclBase(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Declaration::Declaration(Declaration &&master) : Statement(master),ArgDeclBase(master), TypedEntity(master), UDM_OBJECT(master) {};

	Declaration Declaration::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Declaration& Declaration::operator=(Declaration &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Declaration Declaration::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Declaration Declaration::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Declaration Declaration::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Declaration> Declaration::Instances() { return ::Udm::InstantiatedAttr< Declaration>(impl); }
	Declaration Declaration::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Declaration> Declaration::Derived() { return ::Udm::DerivedAttr< Declaration>(impl); }
	::Udm::ArchetypeAttr< Declaration> Declaration::Archetype() const { return ::Udm::ArchetypeAttr< Declaration>(impl); }
	::Udm::ParentAttr< ::SFC::Struct> Declaration::strct() const { return ::Udm::ParentAttr< ::SFC::Struct>(impl, meta_strct); }
	::Udm::ParentAttr< ::SFC::Statement> Declaration::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Declaration::meta;
	::Uml::CompositionParentRole Declaration::meta_strct;

	ArgDeclRef::ArgDeclRef() {}
	ArgDeclRef::ArgDeclRef(::Udm::ObjectImpl *impl) : NullaryExprs(impl), UDM_OBJECT(impl) {}
	ArgDeclRef::ArgDeclRef(const ArgDeclRef &master) : NullaryExprs(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ArgDeclRef::ArgDeclRef(ArgDeclRef &&master) : NullaryExprs(master), UDM_OBJECT(master) {};

	ArgDeclRef ArgDeclRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ArgDeclRef& ArgDeclRef::operator=(ArgDeclRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ArgDeclRef ArgDeclRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ArgDeclRef ArgDeclRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ArgDeclRef ArgDeclRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ArgDeclRef> ArgDeclRef::Instances() { return ::Udm::InstantiatedAttr< ArgDeclRef>(impl); }
	ArgDeclRef ArgDeclRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ArgDeclRef> ArgDeclRef::Derived() { return ::Udm::DerivedAttr< ArgDeclRef>(impl); }
	::Udm::ArchetypeAttr< ArgDeclRef> ArgDeclRef::Archetype() const { return ::Udm::ArchetypeAttr< ArgDeclRef>(impl); }
	::Udm::StringAttr ArgDeclRef::unres() const { return ::Udm::StringAttr(impl, meta_unres); }
	::Udm::PointerAttr< ArgDeclBase> ArgDeclRef::argdecl() const { return ::Udm::PointerAttr< ArgDeclBase>(impl, meta_argdecl); }
	::Udm::ParentAttr< ::Udm::Object> ArgDeclRef::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ArgDeclRef::meta;
	::Uml::Attribute ArgDeclRef::meta_unres;
	::Uml::AssociationRole ArgDeclRef::meta_argdecl;

	DT::DT() {}
	DT::DT(::Udm::ObjectImpl *impl) : Declaration(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	DT::DT(const DT &master) : Declaration(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DT::DT(DT &&master) : Declaration(master), TypedEntity(master), UDM_OBJECT(master) {};

	DT DT::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DT& DT::operator=(DT &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DT DT::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DT DT::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DT DT::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DT> DT::Instances() { return ::Udm::InstantiatedAttr< DT>(impl); }
	DT DT::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DT> DT::Derived() { return ::Udm::DerivedAttr< DT>(impl); }
	::Udm::ArchetypeAttr< DT> DT::Archetype() const { return ::Udm::ArchetypeAttr< DT>(impl); }
	::Udm::AssocAttr< TypedEntity> DT::te() const { return ::Udm::AssocAttr< TypedEntity>(impl, meta_te); }
	::Udm::ParentAttr< ::SFC::Statement> DT::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DT::meta;
	::Uml::AssociationRole DT::meta_te;

	Struct::Struct() {}
	Struct::Struct(::Udm::ObjectImpl *impl) : DT(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	Struct::Struct(const Struct &master) : DT(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Struct::Struct(Struct &&master) : DT(master), TypedEntity(master), UDM_OBJECT(master) {};

	Struct Struct::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Struct& Struct::operator=(Struct &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Struct Struct::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Struct Struct::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Struct Struct::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Struct> Struct::Instances() { return ::Udm::InstantiatedAttr< Struct>(impl); }
	Struct Struct::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Struct> Struct::Derived() { return ::Udm::DerivedAttr< Struct>(impl); }
	::Udm::ArchetypeAttr< Struct> Struct::Archetype() const { return ::Udm::ArchetypeAttr< Struct>(impl); }
	::Udm::IntegerAttr Struct::memberCount() const { return ::Udm::IntegerAttr(impl, meta_memberCount); }
	::Udm::CrossPointerAttr< ::SFC::ArgDeclBase> Struct::adbpath() const { return ::Udm::CrossPointerAttr< ::SFC::ArgDeclBase>(impl, meta_adbpath); }
	::Udm::ChildrenAttr< ::SFC::Declaration> Struct::memb() const { return ::Udm::ChildrenAttr< ::SFC::Declaration>(impl, meta_memb); }
	::Udm::ChildrenAttr< ::SFC::Statement> Struct::Statement_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Statement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::LocalVar> Struct::LocalVar_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::LocalVar>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::StateVar> Struct::StateVar_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::StateVar>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::StateLabel> Struct::StateLabel_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::StateLabel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Var> Struct::Var_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Var>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Declaration> Struct::Declaration_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Declaration>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::DT> Struct::DT_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::DT>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Struct> Struct::Struct_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Struct>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::ArgDeclBase> Struct::ArgDeclBase_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::ArgDeclBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::Array> Struct::Array_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::Array>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::TypedEntity> Struct::TypedEntity_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::TypedEntity>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::SFC::BasicType> Struct::BasicType_kind_children() const { return ::Udm::ChildrenAttr< ::SFC::BasicType>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::SFC::Statement> Struct::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Struct::meta;
	::Uml::Attribute Struct::meta_memberCount;
	::Uml::AssociationRole Struct::meta_adbpath;
	::Uml::CompositionChildRole Struct::meta_memb;

	ArgDeclBase::ArgDeclBase() {}
	ArgDeclBase::ArgDeclBase(::Udm::ObjectImpl *impl) : TypedEntity(impl), UDM_OBJECT(impl) {}
	ArgDeclBase::ArgDeclBase(const ArgDeclBase &master) : TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ArgDeclBase::ArgDeclBase(ArgDeclBase &&master) : TypedEntity(master), UDM_OBJECT(master) {};

	ArgDeclBase ArgDeclBase::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ArgDeclBase& ArgDeclBase::operator=(ArgDeclBase &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ArgDeclBase ArgDeclBase::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ArgDeclBase ArgDeclBase::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ArgDeclBase ArgDeclBase::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ArgDeclBase> ArgDeclBase::Instances() { return ::Udm::InstantiatedAttr< ArgDeclBase>(impl); }
	ArgDeclBase ArgDeclBase::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ArgDeclBase> ArgDeclBase::Derived() { return ::Udm::DerivedAttr< ArgDeclBase>(impl); }
	::Udm::ArchetypeAttr< ArgDeclBase> ArgDeclBase::Archetype() const { return ::Udm::ArchetypeAttr< ArgDeclBase>(impl); }
	::Udm::StringAttr ArgDeclBase::indexBase() const { return ::Udm::StringAttr(impl, meta_indexBase); }
	::Udm::AssocAttr< ArgDeclRef> ArgDeclBase::ref() const { return ::Udm::AssocAttr< ArgDeclRef>(impl, meta_ref); }
	::Udm::CrossAssocAttr< ::SFC::Struct> ArgDeclBase::strctpath() const { return ::Udm::CrossAssocAttr< ::SFC::Struct>(impl, meta_strctpath); }
	::Udm::ParentAttr< ::Udm::Object> ArgDeclBase::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::ParentAttr< ::SFC::Statement> ArgDeclBase::Statement_parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::ParentAttr< ::SFC::TypedEntity> ArgDeclBase::TypedEntity_parent() const { return ::Udm::ParentAttr< ::SFC::TypedEntity>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ArgDeclBase::meta;
	::Uml::Attribute ArgDeclBase::meta_indexBase;
	::Uml::AssociationRole ArgDeclBase::meta_ref;
	::Uml::AssociationRole ArgDeclBase::meta_strctpath;

	Class::Class() {}
	Class::Class(::Udm::ObjectImpl *impl) : CompoundStatement(impl), UDM_OBJECT(impl) {}
	Class::Class(const Class &master) : CompoundStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Class::Class(Class &&master) : CompoundStatement(master), UDM_OBJECT(master) {};

	Class Class::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Class& Class::operator=(Class &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Class Class::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Class Class::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Class Class::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Class> Class::Instances() { return ::Udm::InstantiatedAttr< Class>(impl); }
	Class Class::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Class> Class::Derived() { return ::Udm::DerivedAttr< Class>(impl); }
	::Udm::ArchetypeAttr< Class> Class::Archetype() const { return ::Udm::ArchetypeAttr< Class>(impl); }
	::Udm::StringAttr Class::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::StringAttr Class::annotation() const { return ::Udm::StringAttr(impl, meta_annotation); }
	::Udm::CrossPointerAttr< ::SFC::Function> Class::init() const { return ::Udm::CrossPointerAttr< ::SFC::Function>(impl, meta_init); }
	::Udm::CrossAssocAttr< ::SFC::LocalVar> Class::context() const { return ::Udm::CrossAssocAttr< ::SFC::LocalVar>(impl, meta_context); }
	::Udm::CrossPointerAttr< ::SFC::Function> Class::main() const { return ::Udm::CrossPointerAttr< ::SFC::Function>(impl, meta_main); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Class::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Class::meta;
	::Uml::Attribute Class::meta_name;
	::Uml::Attribute Class::meta_annotation;
	::Uml::AssociationRole Class::meta_init;
	::Uml::AssociationRole Class::meta_context;
	::Uml::AssociationRole Class::meta_main;

	Project::Project() {}
	Project::Project(::Udm::ObjectImpl *impl) : CompoundStatement(impl), UDM_OBJECT(impl) {}
	Project::Project(const Project &master) : CompoundStatement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Project::Project(Project &&master) : CompoundStatement(master), UDM_OBJECT(master) {};

	Project Project::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Project& Project::operator=(Project &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Project Project::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Project Project::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Project Project::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Project> Project::Instances() { return ::Udm::InstantiatedAttr< Project>(impl); }
	Project Project::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Project> Project::Derived() { return ::Udm::DerivedAttr< Project>(impl); }
	::Udm::ArchetypeAttr< Project> Project::Archetype() const { return ::Udm::ArchetypeAttr< Project>(impl); }
	::Udm::StringAttr Project::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Project::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Project::meta;
	::Uml::Attribute Project::meta_name;

	Array::Array() {}
	Array::Array(::Udm::ObjectImpl *impl) : DT(impl),TypedEntity(impl), UDM_OBJECT(impl) {}
	Array::Array(const Array &master) : DT(master),TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Array::Array(Array &&master) : DT(master),TypedEntity(master), UDM_OBJECT(master) {};

	Array Array::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Array& Array::operator=(Array &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Array Array::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Array Array::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Array Array::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Array> Array::Instances() { return ::Udm::InstantiatedAttr< Array>(impl); }
	Array Array::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Array> Array::Derived() { return ::Udm::DerivedAttr< Array>(impl); }
	::Udm::ArchetypeAttr< Array> Array::Archetype() const { return ::Udm::ArchetypeAttr< Array>(impl); }
	::Udm::IntegerAttr Array::noelem() const { return ::Udm::IntegerAttr(impl, meta_noelem); }
	::Udm::CrossAssocAttr< ::SFC::IterativeBlock> Array::itb() const { return ::Udm::CrossAssocAttr< ::SFC::IterativeBlock>(impl, meta_itb); }
	::Udm::ParentAttr< ::SFC::Statement> Array::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Array::meta;
	::Uml::Attribute Array::meta_noelem;
	::Uml::AssociationRole Array::meta_itb;

	TypedEntity::TypedEntity() {}
	TypedEntity::TypedEntity(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	TypedEntity::TypedEntity(const TypedEntity &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypedEntity::TypedEntity(TypedEntity &&master) : UDM_OBJECT(master) {};

	TypedEntity TypedEntity::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypedEntity& TypedEntity::operator=(TypedEntity &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypedEntity TypedEntity::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypedEntity TypedEntity::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypedEntity TypedEntity::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypedEntity> TypedEntity::Instances() { return ::Udm::InstantiatedAttr< TypedEntity>(impl); }
	TypedEntity TypedEntity::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypedEntity> TypedEntity::Derived() { return ::Udm::DerivedAttr< TypedEntity>(impl); }
	::Udm::ArchetypeAttr< TypedEntity> TypedEntity::Archetype() const { return ::Udm::ArchetypeAttr< TypedEntity>(impl); }
	::Udm::StringAttr TypedEntity::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::StringAttr TypedEntity::scope() const { return ::Udm::StringAttr(impl, meta_scope); }
	::Udm::PointerAttr< DT> TypedEntity::dt() const { return ::Udm::PointerAttr< DT>(impl, meta_dt); }
	::Udm::ParentAttr< ::Udm::Object> TypedEntity::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::ParentAttr< ::SFC::Statement> TypedEntity::Statement_parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::ParentAttr< ::SFC::TypedEntity> TypedEntity::TypedEntity_parent() const { return ::Udm::ParentAttr< ::SFC::TypedEntity>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypedEntity::meta;
	::Uml::Attribute TypedEntity::meta_name;
	::Uml::Attribute TypedEntity::meta_scope;
	::Uml::AssociationRole TypedEntity::meta_dt;

	BasicType::BasicType() {}
	BasicType::BasicType(::Udm::ObjectImpl *impl) : DT(impl), TypedEntity(impl), UDM_OBJECT(impl) {}
	BasicType::BasicType(const BasicType &master) : DT(master), TypedEntity(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	BasicType::BasicType(BasicType &&master) : DT(master), TypedEntity(master), UDM_OBJECT(master) {};

	BasicType BasicType::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BasicType& BasicType::operator=(BasicType &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BasicType BasicType::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BasicType BasicType::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BasicType BasicType::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BasicType> BasicType::Instances() { return ::Udm::InstantiatedAttr< BasicType>(impl); }
	BasicType BasicType::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BasicType> BasicType::Derived() { return ::Udm::DerivedAttr< BasicType>(impl); }
	::Udm::ArchetypeAttr< BasicType> BasicType::Archetype() const { return ::Udm::ArchetypeAttr< BasicType>(impl); }
	::Udm::ParentAttr< ::SFC::Statement> BasicType::parent() const { return ::Udm::ParentAttr< ::SFC::Statement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BasicType::meta;

	Comment::Comment() {}
	Comment::Comment(::Udm::ObjectImpl *impl) : Statement(impl), UDM_OBJECT(impl) {}
	Comment::Comment(const Comment &master) : Statement(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Comment::Comment(Comment &&master) : Statement(master), UDM_OBJECT(master) {};

	Comment Comment::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Comment& Comment::operator=(Comment &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Comment Comment::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Comment Comment::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Comment Comment::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Comment> Comment::Instances() { return ::Udm::InstantiatedAttr< Comment>(impl); }
	Comment Comment::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Comment> Comment::Derived() { return ::Udm::DerivedAttr< Comment>(impl); }
	::Udm::ArchetypeAttr< Comment> Comment::Archetype() const { return ::Udm::ArchetypeAttr< Comment>(impl); }
	::Udm::StringAttr Comment::content() const { return ::Udm::StringAttr(impl, meta_content); }
	::Udm::ParentAttr< ::SFC::CompoundStatement> Comment::parent() const { return ::Udm::ParentAttr< ::SFC::CompoundStatement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Comment::meta;
	::Uml::Attribute Comment::meta_content;

	::Uml::Diagram meta;

	void CreateMeta() {
		// classes, with attributes, constraints and constraint definitions
		Arg::meta = ::Uml::Class::Create(meta);
		Arg::meta_type = ::Uml::Attribute::Create(Arg::meta);
		Arg::meta_size = ::Uml::Attribute::Create(Arg::meta);
		Arg::meta_ptr = ::Uml::Attribute::Create(Arg::meta);
		Arg::meta_argIndex = ::Uml::Attribute::Create(Arg::meta);

		ArgDeclBase::meta = ::Uml::Class::Create(meta);
		ArgDeclBase::meta_indexBase = ::Uml::Attribute::Create(ArgDeclBase::meta);

		ArgDeclRef::meta = ::Uml::Class::Create(meta);
		ArgDeclRef::meta_unres = ::Uml::Attribute::Create(ArgDeclRef::meta);

		ArgVal::meta = ::Uml::Class::Create(meta);
		ArgVal::meta_val = ::Uml::Attribute::Create(ArgVal::meta);
		ArgVal::meta_argIndex = ::Uml::Attribute::Create(ArgVal::meta);

		Array::meta = ::Uml::Class::Create(meta);
		Array::meta_noelem = ::Uml::Attribute::Create(Array::meta);

		BasicType::meta = ::Uml::Class::Create(meta);

		BinaryExprs::meta = ::Uml::Class::Create(meta);
		BinaryExprs::meta_op = ::Uml::Attribute::Create(BinaryExprs::meta);

		Block::meta = ::Uml::Class::Create(meta);

		CheckArg::meta = ::Uml::Class::Create(meta);

		CheckState::meta = ::Uml::Class::Create(meta);

		Class::meta = ::Uml::Class::Create(meta);
		Class::meta_name = ::Uml::Attribute::Create(Class::meta);
		Class::meta_annotation = ::Uml::Attribute::Create(Class::meta);

		Comment::meta = ::Uml::Class::Create(meta);
		Comment::meta_content = ::Uml::Attribute::Create(Comment::meta);

		CompoundStatement::meta = ::Uml::Class::Create(meta);
		CompoundStatement::meta_statementCount = ::Uml::Attribute::Create(CompoundStatement::meta);

		Condition::meta = ::Uml::Class::Create(meta);

		ConditionalBlock::meta = ::Uml::Class::Create(meta);

		ConditionalGroup::meta = ::Uml::Class::Create(meta);

		DT::meta = ::Uml::Class::Create(meta);

		Declaration::meta = ::Uml::Class::Create(meta);

		Double::meta = ::Uml::Class::Create(meta);
		Double::meta_val = ::Uml::Attribute::Create(Double::meta);

		Exprs::meta = ::Uml::Class::Create(meta);

		Function::meta = ::Uml::Class::Create(meta);
		Function::meta_annotation = ::Uml::Attribute::Create(Function::meta);
		Function::meta_returnType = ::Uml::Attribute::Create(Function::meta);
		Function::meta_argCount = ::Uml::Attribute::Create(Function::meta);

		FunctionCall::meta = ::Uml::Class::Create(meta);
		FunctionCall::meta_argCount = ::Uml::Attribute::Create(FunctionCall::meta);
		FunctionCall::meta_libFuncName = ::Uml::Attribute::Create(FunctionCall::meta);

		Int::meta = ::Uml::Class::Create(meta);
		Int::meta_val = ::Uml::Attribute::Create(Int::meta);

		IterativeBlock::meta = ::Uml::Class::Create(meta);

		LocalVar::meta = ::Uml::Class::Create(meta);
		LocalVar::meta_initial = ::Uml::Attribute::Create(LocalVar::meta);
		LocalVar::meta_Static = ::Uml::Attribute::Create(LocalVar::meta);

		NullaryExprs::meta = ::Uml::Class::Create(meta);

		OperationalStatement::meta = ::Uml::Class::Create(meta);

		Program::meta = ::Uml::Class::Create(meta);
		Program::meta_filename = ::Uml::Attribute::Create(Program::meta);
		Program::meta_stateCount = ::Uml::Attribute::Create(Program::meta);
		Program::meta_numInstance = ::Uml::Attribute::Create(Program::meta);

		Project::meta = ::Uml::Class::Create(meta);
		Project::meta_name = ::Uml::Attribute::Create(Project::meta);

		Return::meta = ::Uml::Class::Create(meta);
		Return::meta_val = ::Uml::Attribute::Create(Return::meta);

		SetState::meta = ::Uml::Class::Create(meta);

		SetVar::meta = ::Uml::Class::Create(meta);
		SetVar::meta_invert = ::Uml::Attribute::Create(SetVar::meta);

		SimpleStatement::meta = ::Uml::Class::Create(meta);

		StateLabel::meta = ::Uml::Class::Create(meta);
		StateLabel::meta_comment = ::Uml::Attribute::Create(StateLabel::meta);
		StateLabel::meta_value = ::Uml::Attribute::Create(StateLabel::meta);
		StateLabel::meta_andSS = ::Uml::Attribute::Create(StateLabel::meta);

		StateRel::meta = ::Uml::Class::Create(meta);
		StateRel::meta_andState = ::Uml::Attribute::Create(StateRel::meta);
		StateRel::meta_invert = ::Uml::Attribute::Create(StateRel::meta);

		StateVar::meta = ::Uml::Class::Create(meta);

		Statement::meta = ::Uml::Class::Create(meta);
		Statement::meta_statementIndex = ::Uml::Attribute::Create(Statement::meta);
		Statement::meta_RefId = ::Uml::Attribute::Create(Statement::meta);

		Str::meta = ::Uml::Class::Create(meta);
		Str::meta_val = ::Uml::Attribute::Create(Str::meta);

		Struct::meta = ::Uml::Class::Create(meta);
		Struct::meta_memberCount = ::Uml::Attribute::Create(Struct::meta);

		TypedEntity::meta = ::Uml::Class::Create(meta);
		TypedEntity::meta_name = ::Uml::Attribute::Create(TypedEntity::meta);
		TypedEntity::meta_scope = ::Uml::Attribute::Create(TypedEntity::meta);

		UnaryExprs::meta = ::Uml::Class::Create(meta);
		UnaryExprs::meta_op = ::Uml::Attribute::Create(UnaryExprs::meta);

		UserCode::meta = ::Uml::Class::Create(meta);
		UserCode::meta_expr = ::Uml::Attribute::Create(UserCode::meta);

		Var::meta = ::Uml::Class::Create(meta);
		Var::meta_type = ::Uml::Attribute::Create(Var::meta);
		Var::meta_size = ::Uml::Attribute::Create(Var::meta);

	}

	void InitMeta() {
		// classes, with attributes, constraints and constraint definitions
		::Uml::InitClassProps(Arg::meta, "Arg", false, NULL, NULL);
		::Uml::InitAttributeProps(Arg::meta_type, "type", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Arg_size_dva;
		Arg_size_dva.push_back("1");
		::Uml::InitAttributeProps(Arg::meta_size, "size", "Integer", false, false, 1, 1, false, "public", Arg_size_dva);
		vector<string> Arg_ptr_dva;
		Arg_ptr_dva.push_back("false");
		::Uml::InitAttributeProps(Arg::meta_ptr, "ptr", "Boolean", false, false, 1, 1, false, "public", Arg_ptr_dva);
		vector<string> Arg_argIndex_dva;
		Arg_argIndex_dva.push_back("0");
		::Uml::InitAttributeProps(Arg::meta_argIndex, "argIndex", "Integer", false, false, 1, 1, false, "public", Arg_argIndex_dva);

		::Uml::InitClassProps(ArgDeclBase::meta, "ArgDeclBase", true, NULL, NULL);
		::Uml::InitAttributeProps(ArgDeclBase::meta_indexBase, "indexBase", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ArgDeclRef::meta, "ArgDeclRef", false, NULL, NULL);
		::Uml::InitAttributeProps(ArgDeclRef::meta_unres, "unres", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ArgVal::meta, "ArgVal", false, NULL, NULL);
		::Uml::InitAttributeProps(ArgVal::meta_val, "val", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> ArgVal_argIndex_dva;
		ArgVal_argIndex_dva.push_back("0");
		::Uml::InitAttributeProps(ArgVal::meta_argIndex, "argIndex", "Integer", false, false, 1, 1, false, "public", ArgVal_argIndex_dva);

		::Uml::InitClassProps(Array::meta, "Array", false, NULL, NULL);
		::Uml::InitAttributeProps(Array::meta_noelem, "noelem", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(BasicType::meta, "BasicType", false, NULL, NULL);

		::Uml::InitClassProps(BinaryExprs::meta, "BinaryExprs", false, NULL, NULL);
		::Uml::InitAttributeProps(BinaryExprs::meta_op, "op", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Block::meta, "Block", true, NULL, NULL);

		::Uml::InitClassProps(CheckArg::meta, "CheckArg", false, NULL, NULL);

		::Uml::InitClassProps(CheckState::meta, "CheckState", false, NULL, NULL);

		::Uml::InitClassProps(Class::meta, "Class", false, NULL, NULL);
		::Uml::InitAttributeProps(Class::meta_name, "name", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Class::meta_annotation, "annotation", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Comment::meta, "Comment", false, NULL, NULL);
		::Uml::InitAttributeProps(Comment::meta_content, "content", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(CompoundStatement::meta, "CompoundStatement", true, NULL, NULL);
		vector<string> CompoundStatement_statementCount_dva;
		CompoundStatement_statementCount_dva.push_back("0");
		::Uml::InitAttributeProps(CompoundStatement::meta_statementCount, "statementCount", "Integer", false, false, 1, 1, false, "public", CompoundStatement_statementCount_dva);

		::Uml::InitClassProps(Condition::meta, "Condition", true, NULL, NULL);

		::Uml::InitClassProps(ConditionalBlock::meta, "ConditionalBlock", false, NULL, NULL);

		::Uml::InitClassProps(ConditionalGroup::meta, "ConditionalGroup", false, NULL, NULL);

		::Uml::InitClassProps(DT::meta, "DT", true, NULL, NULL);

		::Uml::InitClassProps(Declaration::meta, "Declaration", true, NULL, NULL);

		::Uml::InitClassProps(Double::meta, "Double", false, NULL, NULL);
		::Uml::InitAttributeProps(Double::meta_val, "val", "Real", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Exprs::meta, "Exprs", true, NULL, NULL);

		::Uml::InitClassProps(Function::meta, "Function", false, NULL, NULL);
		::Uml::InitAttributeProps(Function::meta_annotation, "annotation", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Function_returnType_dva;
		Function_returnType_dva.push_back("void");
		::Uml::InitAttributeProps(Function::meta_returnType, "returnType", "String", false, false, 1, 1, false, "public", Function_returnType_dva);
		vector<string> Function_argCount_dva;
		Function_argCount_dva.push_back("0");
		::Uml::InitAttributeProps(Function::meta_argCount, "argCount", "Integer", false, false, 1, 1, false, "public", Function_argCount_dva);

		::Uml::InitClassProps(FunctionCall::meta, "FunctionCall", false, NULL, NULL);
		vector<string> FunctionCall_argCount_dva;
		FunctionCall_argCount_dva.push_back("0");
		::Uml::InitAttributeProps(FunctionCall::meta_argCount, "argCount", "Integer", false, false, 1, 1, false, "public", FunctionCall_argCount_dva);
		::Uml::InitAttributeProps(FunctionCall::meta_libFuncName, "libFuncName", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Int::meta, "Int", false, NULL, NULL);
		::Uml::InitAttributeProps(Int::meta_val, "val", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(IterativeBlock::meta, "IterativeBlock", false, NULL, NULL);

		::Uml::InitClassProps(LocalVar::meta, "LocalVar", false, NULL, NULL);
		::Uml::InitAttributeProps(LocalVar::meta_initial, "initial", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> LocalVar_Static_dva;
		LocalVar_Static_dva.push_back("false");
		::Uml::InitAttributeProps(LocalVar::meta_Static, "Static", "Boolean", false, false, 1, 1, false, "public", LocalVar_Static_dva);

		::Uml::InitClassProps(NullaryExprs::meta, "NullaryExprs", true, NULL, NULL);

		::Uml::InitClassProps(OperationalStatement::meta, "OperationalStatement", true, NULL, NULL);

		::Uml::InitClassProps(Program::meta, "Program", false, NULL, NULL);
		::Uml::InitAttributeProps(Program::meta_filename, "filename", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Program::meta_stateCount, "stateCount", "Integer", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Program_numInstance_dva;
		Program_numInstance_dva.push_back("1");
		::Uml::InitAttributeProps(Program::meta_numInstance, "numInstance", "Integer", false, false, 1, 1, false, "public", Program_numInstance_dva);

		::Uml::InitClassProps(Project::meta, "Project", false, NULL, NULL);
		::Uml::InitAttributeProps(Project::meta_name, "name", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Return::meta, "Return", false, NULL, NULL);
		::Uml::InitAttributeProps(Return::meta_val, "val", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(SetState::meta, "SetState", false, NULL, NULL);

		::Uml::InitClassProps(SetVar::meta, "SetVar", false, NULL, NULL);
		vector<string> SetVar_invert_dva;
		SetVar_invert_dva.push_back("false");
		::Uml::InitAttributeProps(SetVar::meta_invert, "invert", "Boolean", false, false, 1, 1, false, "public", SetVar_invert_dva);

		::Uml::InitClassProps(SimpleStatement::meta, "SimpleStatement", true, NULL, NULL);

		::Uml::InitClassProps(StateLabel::meta, "StateLabel", false, NULL, NULL);
		::Uml::InitAttributeProps(StateLabel::meta_comment, "comment", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(StateLabel::meta_value, "value", "Integer", false, false, 1, 1, false, "public", vector<string>());
		vector<string> StateLabel_andSS_dva;
		StateLabel_andSS_dva.push_back("0");
		::Uml::InitAttributeProps(StateLabel::meta_andSS, "andSS", "Integer", false, false, 1, 1, false, "public", StateLabel_andSS_dva);

		::Uml::InitClassProps(StateRel::meta, "StateRel", true, NULL, NULL);
		::Uml::InitAttributeProps(StateRel::meta_andState, "andState", "Boolean", false, false, 1, 1, false, "public", vector<string>());
		vector<string> StateRel_invert_dva;
		StateRel_invert_dva.push_back("false");
		::Uml::InitAttributeProps(StateRel::meta_invert, "invert", "Boolean", false, false, 1, 1, false, "public", StateRel_invert_dva);

		::Uml::InitClassProps(StateVar::meta, "StateVar", false, NULL, NULL);

		::Uml::InitClassProps(Statement::meta, "Statement", true, NULL, NULL);
		vector<string> Statement_statementIndex_dva;
		Statement_statementIndex_dva.push_back("0");
		::Uml::InitAttributeProps(Statement::meta_statementIndex, "statementIndex", "Integer", false, false, 1, 1, false, "public", Statement_statementIndex_dva);
		vector<string> Statement_RefId_dva;
		Statement_RefId_dva.push_back("");
		::Uml::InitAttributeProps(Statement::meta_RefId, "RefId", "String", false, false, 1, 1, false, "public", Statement_RefId_dva);

		::Uml::InitClassProps(Str::meta, "Str", false, NULL, NULL);
		::Uml::InitAttributeProps(Str::meta_val, "val", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Struct::meta, "Struct", false, NULL, NULL);
		vector<string> Struct_memberCount_dva;
		Struct_memberCount_dva.push_back("0");
		::Uml::InitAttributeProps(Struct::meta_memberCount, "memberCount", "Integer", false, false, 1, 1, false, "public", Struct_memberCount_dva);

		::Uml::InitClassProps(TypedEntity::meta, "TypedEntity", false, NULL, NULL);
		::Uml::InitAttributeProps(TypedEntity::meta_name, "name", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(TypedEntity::meta_scope, "scope", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(UnaryExprs::meta, "UnaryExprs", false, NULL, NULL);
		::Uml::InitAttributeProps(UnaryExprs::meta_op, "op", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(UserCode::meta, "UserCode", false, NULL, NULL);
		::Uml::InitAttributeProps(UserCode::meta_expr, "expr", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Var::meta, "Var", true, NULL, NULL);
		::Uml::InitAttributeProps(Var::meta_type, "type", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Var_size_dva;
		Var_size_dva.push_back("1");
		::Uml::InitAttributeProps(Var::meta_size, "size", "Integer", false, false, 1, 1, false, "public", Var_size_dva);

		// associations
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "CheckArg");
			Arg::meta_slab = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Arg::meta_slab, "slab", true, false, 0, -1);
			StateLabel::meta_arg = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateLabel::meta_arg, "arg", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "SetVar");
			Arg::meta_lvar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Arg::meta_lvar, "lvar", true, false, 0, -1);
			LocalVar::meta_arg = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar::meta_arg, "arg", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			FunctionCall::meta_callee = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FunctionCall::meta_callee, "callee", true, false, 0, 1);
			Function::meta_caller = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function::meta_caller, "caller", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			ArgVal::meta_arg = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ArgVal::meta_arg, "arg", true, false, 0, -1);
			Arg::meta_val = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Arg::meta_val, "val", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			StateRel::meta_value = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateRel::meta_value, "value", true, false, 1, 1);
			StateLabel::meta_srv = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateLabel::meta_srv, "srv", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			StateRel::meta_index = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateRel::meta_index, "index", true, false, 1, 1);
			StateLabel::meta_sri = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateLabel::meta_sri, "sri", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			StateRel::meta_svar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateRel::meta_svar, "svar", true, false, 1, 1);
			StateVar::meta_srs = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(StateVar::meta_srs, "srs", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			ArgDeclRef::meta_argdecl = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ArgDeclRef::meta_argdecl, "argdecl", true, false, 0, 1);
			ArgDeclBase::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ArgDeclBase::meta_ref, "ref", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			TypedEntity::meta_dt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypedEntity::meta_dt, "dt", true, false, 0, 1);
			DT::meta_te = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(DT::meta_te, "te", true, false, 0, -1);

		}

		// compositions
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Arg::meta_Function_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Arg::meta_Function_parent, "Function_parent", true);
			Function::meta_Arg_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Function::meta_Arg_children, "Arg", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Condition::meta_cbPar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Condition::meta_cbPar, "cbPar", true);
			ConditionalBlock::meta_cond = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ConditionalBlock::meta_cond, "cond", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Exprs::meta_retexprpar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Exprs::meta_retexprpar, "retexprpar", true);
			Return::meta_retexpr = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Return::meta_retexpr, "retexpr", true, 0, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Statement::meta_csPar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Statement::meta_csPar, "csPar", true);
			CompoundStatement::meta_stmnt = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(CompoundStatement::meta_stmnt, "stmnt", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Exprs::meta_codeexprpar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Exprs::meta_codeexprpar, "codeexprpar", true);
			UserCode::meta_codeexpr = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(UserCode::meta_codeexpr, "codeexpr", true, 0, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Condition::meta_ibPar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Condition::meta_ibPar, "ibPar", true);
			IterativeBlock::meta_cond = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(IterativeBlock::meta_cond, "cond", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			ArgVal::meta_FunctionCall_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ArgVal::meta_FunctionCall_parent, "FunctionCall_parent", true);
			FunctionCall::meta_ArgVal_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FunctionCall::meta_ArgVal_children, "ArgVal", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Exprs::meta_argexprpar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Exprs::meta_argexprpar, "argexprpar", true);
			ArgVal::meta_argexpr = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ArgVal::meta_argexpr, "argexpr", true, 0, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Exprs::meta_rightexprpar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Exprs::meta_rightexprpar, "rightexprpar", true);
			BinaryExprs::meta_rightexpr = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(BinaryExprs::meta_rightexpr, "rightexpr", true, 1, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Exprs::meta_leftexprpar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Exprs::meta_leftexprpar, "leftexprpar", true);
			BinaryExprs::meta_leftexpr = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(BinaryExprs::meta_leftexpr, "leftexpr", true, 1, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Exprs::meta_subexprpar = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Exprs::meta_subexprpar, "subexprpar", true);
			UnaryExprs::meta_subexpr = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(UnaryExprs::meta_subexpr, "subexpr", true, 1, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "Composition", false);
			Declaration::meta_strct = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Declaration::meta_strct, "strct", true);
			Struct::meta_memb = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Struct::meta_memb, "memb", true, 0, -1);

		}

	}

	void InitMetaLinks() {
		Arg::meta_slab.target() = StateLabel::meta;
		Arg::meta_lvar.target() = LocalVar::meta;
		Arg::meta_val.target() = ArgVal::meta;
		Arg::meta_actual = ::ctest::Arg_cross_ph_SFC::meta_actual;
		Function::meta_Arg_children.target() = Arg::meta;

		ArgDeclBase::meta_ref.target() = ArgDeclRef::meta;
		ArgDeclBase::meta_strctpath = ::ctest::ArgDeclBase_cross_ph_SFC::meta_strctpath;
		ArgDeclBase::meta.subTypes() += Arg::meta;
		ArgDeclBase::meta.subTypes() += Declaration::meta;

		ArgDeclRef::meta_argdecl.target() = ArgDeclBase::meta;

		ArgVal::meta_arg.target() = Arg::meta;
		Exprs::meta_argexprpar.target() = ArgVal::meta;
		FunctionCall::meta_ArgVal_children.target() = ArgVal::meta;

		Array::meta_itb = ::ctest::Array_cross_ph_SFC::meta_itb;

		Exprs::meta_rightexprpar.target() = BinaryExprs::meta;
		Exprs::meta_leftexprpar.target() = BinaryExprs::meta;

		Block::meta.subTypes() += Function::meta;
		Block::meta.subTypes() += ConditionalBlock::meta;
		Block::meta.subTypes() += IterativeBlock::meta;

		CheckArg::meta.association() = Arg::meta_slab.parent();
		CheckArg::meta_slab_end_ = StateLabel::meta_arg_rev = Arg::meta_slab;
		CheckArg::meta_arg_end_ = Arg::meta_slab_rev = StateLabel::meta_arg;

		Class::meta_init = ::ctest::Class_cross_ph_SFC::meta_init;
		Class::meta_context = ::ctest::Class_cross_ph_SFC::meta_context;
		Class::meta_main = ::ctest::Class_cross_ph_SFC::meta_main;

		Statement::meta_csPar.target() = CompoundStatement::meta;
		CompoundStatement::meta.subTypes() += Program::meta;
		CompoundStatement::meta.subTypes() += Block::meta;
		CompoundStatement::meta.subTypes() += ConditionalGroup::meta;
		CompoundStatement::meta.subTypes() += Class::meta;
		CompoundStatement::meta.subTypes() += Project::meta;

		ConditionalBlock::meta_cond.target() = Condition::meta;
		IterativeBlock::meta_cond.target() = Condition::meta;
		Condition::meta.subTypes() += UserCode::meta;
		Condition::meta.subTypes() += CheckArg::meta;
		Condition::meta.subTypes() += CheckState::meta;

		Condition::meta_cbPar.target() = ConditionalBlock::meta;

		DT::meta_te.target() = TypedEntity::meta;
		DT::meta.subTypes() += Struct::meta;
		DT::meta.subTypes() += Array::meta;
		DT::meta.subTypes() += BasicType::meta;

		Struct::meta_memb.target() = Declaration::meta;
		Declaration::meta.subTypes() += StateLabel::meta;
		Declaration::meta.subTypes() += Var::meta;
		Declaration::meta.subTypes() += DT::meta;

		Return::meta_retexpr.target() = Exprs::meta;
		UserCode::meta_codeexpr.target() = Exprs::meta;
		ArgVal::meta_argexpr.target() = Exprs::meta;
		BinaryExprs::meta_rightexpr.target() = Exprs::meta;
		BinaryExprs::meta_leftexpr.target() = Exprs::meta;
		UnaryExprs::meta_subexpr.target() = Exprs::meta;
		Exprs::meta.subTypes() += BinaryExprs::meta;
		Exprs::meta.subTypes() += UnaryExprs::meta;
		Exprs::meta.subTypes() += NullaryExprs::meta;

		Function::meta_caller.target() = FunctionCall::meta;
		Function::meta_klassinit = ::ctest::Function_cross_ph_SFC::meta_klassinit;
		Function::meta_klassmain = ::ctest::Function_cross_ph_SFC::meta_klassmain;
		Arg::meta_Function_parent.target() = Function::meta;

		FunctionCall::meta_callee.target() = Function::meta;
		ArgVal::meta_FunctionCall_parent.target() = FunctionCall::meta;

		IterativeBlock::meta_counter = ::ctest::IterativeBlock_cross_ph_SFC::meta_counter;
		IterativeBlock::meta_ary = ::ctest::IterativeBlock_cross_ph_SFC::meta_ary;
		Condition::meta_ibPar.target() = IterativeBlock::meta;

		LocalVar::meta_arg.target() = Arg::meta;
		LocalVar::meta_argument = ::ctest::LocalVar_cross_ph_SFC::meta_argument;
		LocalVar::meta_loop = ::ctest::LocalVar_cross_ph_SFC::meta_loop;
		LocalVar::meta_klass = ::ctest::LocalVar_cross_ph_SFC::meta_klass;

		NullaryExprs::meta.subTypes() += FunctionCall::meta;
		NullaryExprs::meta.subTypes() += Str::meta;
		NullaryExprs::meta.subTypes() += Double::meta;
		NullaryExprs::meta.subTypes() += Int::meta;
		NullaryExprs::meta.subTypes() += ArgDeclRef::meta;

		OperationalStatement::meta.subTypes() += SimpleStatement::meta;
		OperationalStatement::meta.subTypes() += CompoundStatement::meta;

		Exprs::meta_retexprpar.target() = Return::meta;

		SetVar::meta.association() = Arg::meta_lvar.parent();
		SetVar::meta_lvar_end_ = LocalVar::meta_arg_rev = Arg::meta_lvar;
		SetVar::meta_arg_end_ = Arg::meta_lvar_rev = LocalVar::meta_arg;

		SimpleStatement::meta.subTypes() += Return::meta;
		SimpleStatement::meta.subTypes() += UserCode::meta;
		SimpleStatement::meta.subTypes() += FunctionCall::meta;
		SimpleStatement::meta.subTypes() += SetState::meta;
		SimpleStatement::meta.subTypes() += SetVar::meta;

		StateLabel::meta_arg.target() = Arg::meta;
		StateLabel::meta_srv.target() = StateRel::meta;
		StateLabel::meta_sri.target() = StateRel::meta;

		StateRel::meta_value.target() = StateLabel::meta;
		StateRel::meta_index.target() = StateLabel::meta;
		StateRel::meta_svar.target() = StateVar::meta;
		StateRel::meta.subTypes() += SetState::meta;
		StateRel::meta.subTypes() += CheckState::meta;

		StateVar::meta_srs.target() = StateRel::meta;

		CompoundStatement::meta_stmnt.target() = Statement::meta;
		Statement::meta.subTypes() += OperationalStatement::meta;
		Statement::meta.subTypes() += Declaration::meta;
		Statement::meta.subTypes() += Comment::meta;

		Struct::meta_adbpath = ::ctest::Struct_cross_ph_SFC::meta_adbpath;
		Declaration::meta_strct.target() = Struct::meta;

		TypedEntity::meta_dt.target() = DT::meta;
		TypedEntity::meta.subTypes() += Function::meta;
		TypedEntity::meta.subTypes() += ArgDeclBase::meta;
		TypedEntity::meta.subTypes() += Array::meta;

		Exprs::meta_subexprpar.target() = UnaryExprs::meta;

		Exprs::meta_codeexprpar.target() = UserCode::meta;

		Var::meta.subTypes() += LocalVar::meta;
		Var::meta.subTypes() += StateVar::meta;

	}

	void InitMeta(const ::Uml::Diagram &parent) {
		// classes, with attributes, constraints and constraint definitions
		::Uml::SetClass(Arg::meta, parent, "Arg");
		::Uml::SetAttribute(Arg::meta_type, Arg::meta, "type");
		::Uml::SetAttribute(Arg::meta_size, Arg::meta, "size");
		::Uml::SetAttribute(Arg::meta_ptr, Arg::meta, "ptr");
		::Uml::SetAttribute(Arg::meta_argIndex, Arg::meta, "argIndex");

		::Uml::SetClass(ArgDeclBase::meta, parent, "ArgDeclBase");
		::Uml::SetAttribute(ArgDeclBase::meta_indexBase, ArgDeclBase::meta, "indexBase");

		::Uml::SetClass(ArgDeclRef::meta, parent, "ArgDeclRef");
		::Uml::SetAttribute(ArgDeclRef::meta_unres, ArgDeclRef::meta, "unres");

		::Uml::SetClass(ArgVal::meta, parent, "ArgVal");
		::Uml::SetAttribute(ArgVal::meta_val, ArgVal::meta, "val");
		::Uml::SetAttribute(ArgVal::meta_argIndex, ArgVal::meta, "argIndex");

		::Uml::SetClass(Array::meta, parent, "Array");
		::Uml::SetAttribute(Array::meta_noelem, Array::meta, "noelem");

		::Uml::SetClass(BasicType::meta, parent, "BasicType");

		::Uml::SetClass(BinaryExprs::meta, parent, "BinaryExprs");
		::Uml::SetAttribute(BinaryExprs::meta_op, BinaryExprs::meta, "op");

		::Uml::SetClass(Block::meta, parent, "Block");

		::Uml::SetClass(CheckArg::meta, parent, "CheckArg");

		::Uml::SetClass(CheckState::meta, parent, "CheckState");

		::Uml::SetClass(Class::meta, parent, "Class");
		::Uml::SetAttribute(Class::meta_name, Class::meta, "name");
		::Uml::SetAttribute(Class::meta_annotation, Class::meta, "annotation");

		::Uml::SetClass(Comment::meta, parent, "Comment");
		::Uml::SetAttribute(Comment::meta_content, Comment::meta, "content");

		::Uml::SetClass(CompoundStatement::meta, parent, "CompoundStatement");
		::Uml::SetAttribute(CompoundStatement::meta_statementCount, CompoundStatement::meta, "statementCount");

		::Uml::SetClass(Condition::meta, parent, "Condition");

		::Uml::SetClass(ConditionalBlock::meta, parent, "ConditionalBlock");

		::Uml::SetClass(ConditionalGroup::meta, parent, "ConditionalGroup");

		::Uml::SetClass(DT::meta, parent, "DT");

		::Uml::SetClass(Declaration::meta, parent, "Declaration");

		::Uml::SetClass(Double::meta, parent, "Double");
		::Uml::SetAttribute(Double::meta_val, Double::meta, "val");

		::Uml::SetClass(Exprs::meta, parent, "Exprs");

		::Uml::SetClass(Function::meta, parent, "Function");
		::Uml::SetAttribute(Function::meta_annotation, Function::meta, "annotation");
		::Uml::SetAttribute(Function::meta_returnType, Function::meta, "returnType");
		::Uml::SetAttribute(Function::meta_argCount, Function::meta, "argCount");

		::Uml::SetClass(FunctionCall::meta, parent, "FunctionCall");
		::Uml::SetAttribute(FunctionCall::meta_argCount, FunctionCall::meta, "argCount");
		::Uml::SetAttribute(FunctionCall::meta_libFuncName, FunctionCall::meta, "libFuncName");

		::Uml::SetClass(Int::meta, parent, "Int");
		::Uml::SetAttribute(Int::meta_val, Int::meta, "val");

		::Uml::SetClass(IterativeBlock::meta, parent, "IterativeBlock");

		::Uml::SetClass(LocalVar::meta, parent, "LocalVar");
		::Uml::SetAttribute(LocalVar::meta_initial, LocalVar::meta, "initial");
		::Uml::SetAttribute(LocalVar::meta_Static, LocalVar::meta, "Static");

		::Uml::SetClass(NullaryExprs::meta, parent, "NullaryExprs");

		::Uml::SetClass(OperationalStatement::meta, parent, "OperationalStatement");

		::Uml::SetClass(Program::meta, parent, "Program");
		::Uml::SetAttribute(Program::meta_filename, Program::meta, "filename");
		::Uml::SetAttribute(Program::meta_stateCount, Program::meta, "stateCount");
		::Uml::SetAttribute(Program::meta_numInstance, Program::meta, "numInstance");

		::Uml::SetClass(Project::meta, parent, "Project");
		::Uml::SetAttribute(Project::meta_name, Project::meta, "name");

		::Uml::SetClass(Return::meta, parent, "Return");
		::Uml::SetAttribute(Return::meta_val, Return::meta, "val");

		::Uml::SetClass(SetState::meta, parent, "SetState");

		::Uml::SetClass(SetVar::meta, parent, "SetVar");
		::Uml::SetAttribute(SetVar::meta_invert, SetVar::meta, "invert");

		::Uml::SetClass(SimpleStatement::meta, parent, "SimpleStatement");

		::Uml::SetClass(StateLabel::meta, parent, "StateLabel");
		::Uml::SetAttribute(StateLabel::meta_comment, StateLabel::meta, "comment");
		::Uml::SetAttribute(StateLabel::meta_value, StateLabel::meta, "value");
		::Uml::SetAttribute(StateLabel::meta_andSS, StateLabel::meta, "andSS");

		::Uml::SetClass(StateRel::meta, parent, "StateRel");
		::Uml::SetAttribute(StateRel::meta_andState, StateRel::meta, "andState");
		::Uml::SetAttribute(StateRel::meta_invert, StateRel::meta, "invert");

		::Uml::SetClass(StateVar::meta, parent, "StateVar");

		::Uml::SetClass(Statement::meta, parent, "Statement");
		::Uml::SetAttribute(Statement::meta_statementIndex, Statement::meta, "statementIndex");
		::Uml::SetAttribute(Statement::meta_RefId, Statement::meta, "RefId");

		::Uml::SetClass(Str::meta, parent, "Str");
		::Uml::SetAttribute(Str::meta_val, Str::meta, "val");

		::Uml::SetClass(Struct::meta, parent, "Struct");
		::Uml::SetAttribute(Struct::meta_memberCount, Struct::meta, "memberCount");

		::Uml::SetClass(TypedEntity::meta, parent, "TypedEntity");
		::Uml::SetAttribute(TypedEntity::meta_name, TypedEntity::meta, "name");
		::Uml::SetAttribute(TypedEntity::meta_scope, TypedEntity::meta, "scope");

		::Uml::SetClass(UnaryExprs::meta, parent, "UnaryExprs");
		::Uml::SetAttribute(UnaryExprs::meta_op, UnaryExprs::meta, "op");

		::Uml::SetClass(UserCode::meta, parent, "UserCode");
		::Uml::SetAttribute(UserCode::meta_expr, UserCode::meta, "expr");

		::Uml::SetClass(Var::meta, parent, "Var");
		::Uml::SetAttribute(Var::meta_type, Var::meta, "type");
		::Uml::SetAttribute(Var::meta_size, Var::meta, "size");

	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
		// classes
		::Uml::SetAssocRole(Arg::meta_slab, Arg::meta, StateLabel::meta, "arg");
		CheckArg::meta_slab_end_ = StateLabel::meta_arg_rev = Arg::meta_slab;
		::Uml::SetAssocRole(Arg::meta_lvar, Arg::meta, LocalVar::meta, "arg");
		SetVar::meta_lvar_end_ = LocalVar::meta_arg_rev = Arg::meta_lvar;
		::Uml::SetAssocRole(Arg::meta_val, Arg::meta, ArgVal::meta, "arg");
		Arg::meta_actual = ::ctest::Arg_cross_ph_SFC::meta_actual;
		::Uml::SetParentRole(Arg::meta_Function_parent, Arg::meta, Function::meta, "", "");

		::Uml::SetAssocRole(ArgDeclBase::meta_ref, ArgDeclBase::meta, ArgDeclRef::meta, "argdecl");
		ArgDeclBase::meta_strctpath = ::ctest::ArgDeclBase_cross_ph_SFC::meta_strctpath;

		::Uml::SetAssocRole(ArgDeclRef::meta_argdecl, ArgDeclRef::meta, ArgDeclBase::meta, "ref");

		::Uml::SetAssocRole(ArgVal::meta_arg, ArgVal::meta, Arg::meta, "val");
		::Uml::SetChildRole(ArgVal::meta_argexpr, ArgVal::meta, Exprs::meta, "argexprpar", "argexpr");
		::Uml::SetParentRole(ArgVal::meta_FunctionCall_parent, ArgVal::meta, FunctionCall::meta, "", "");

		Array::meta_itb = ::ctest::Array_cross_ph_SFC::meta_itb;

		::Uml::SetChildRole(BinaryExprs::meta_rightexpr, BinaryExprs::meta, Exprs::meta, "rightexprpar", "rightexpr");
		::Uml::SetChildRole(BinaryExprs::meta_leftexpr, BinaryExprs::meta, Exprs::meta, "leftexprpar", "leftexpr");

		Class::meta_init = ::ctest::Class_cross_ph_SFC::meta_init;
		Class::meta_context = ::ctest::Class_cross_ph_SFC::meta_context;
		Class::meta_main = ::ctest::Class_cross_ph_SFC::meta_main;

		::Uml::SetChildRole(CompoundStatement::meta_stmnt, CompoundStatement::meta, Statement::meta, "csPar", "stmnt");

		::Uml::SetParentRole(Condition::meta_cbPar, Condition::meta, ConditionalBlock::meta, "cond", "cbPar");
		::Uml::SetParentRole(Condition::meta_ibPar, Condition::meta, IterativeBlock::meta, "cond", "ibPar");

		::Uml::SetChildRole(ConditionalBlock::meta_cond, ConditionalBlock::meta, Condition::meta, "cbPar", "cond");

		::Uml::SetAssocRole(DT::meta_te, DT::meta, TypedEntity::meta, "dt");

		::Uml::SetParentRole(Declaration::meta_strct, Declaration::meta, Struct::meta, "memb", "strct");

		::Uml::SetParentRole(Exprs::meta_retexprpar, Exprs::meta, Return::meta, "retexpr", "retexprpar");
		::Uml::SetParentRole(Exprs::meta_codeexprpar, Exprs::meta, UserCode::meta, "codeexpr", "codeexprpar");
		::Uml::SetParentRole(Exprs::meta_argexprpar, Exprs::meta, ArgVal::meta, "argexpr", "argexprpar");
		::Uml::SetParentRole(Exprs::meta_rightexprpar, Exprs::meta, BinaryExprs::meta, "rightexpr", "rightexprpar");
		::Uml::SetParentRole(Exprs::meta_leftexprpar, Exprs::meta, BinaryExprs::meta, "leftexpr", "leftexprpar");
		::Uml::SetParentRole(Exprs::meta_subexprpar, Exprs::meta, UnaryExprs::meta, "subexpr", "subexprpar");

		::Uml::SetAssocRole(Function::meta_caller, Function::meta, FunctionCall::meta, "callee");
		Function::meta_klassinit = ::ctest::Function_cross_ph_SFC::meta_klassinit;
		Function::meta_klassmain = ::ctest::Function_cross_ph_SFC::meta_klassmain;
		::Uml::SetChildRole(Function::meta_Arg_children, Function::meta, Arg::meta, "", "");

		::Uml::SetAssocRole(FunctionCall::meta_callee, FunctionCall::meta, Function::meta, "caller");
		::Uml::SetChildRole(FunctionCall::meta_ArgVal_children, FunctionCall::meta, ArgVal::meta, "", "");

		IterativeBlock::meta_counter = ::ctest::IterativeBlock_cross_ph_SFC::meta_counter;
		IterativeBlock::meta_ary = ::ctest::IterativeBlock_cross_ph_SFC::meta_ary;
		::Uml::SetChildRole(IterativeBlock::meta_cond, IterativeBlock::meta, Condition::meta, "ibPar", "cond");

		::Uml::SetAssocRole(LocalVar::meta_arg, LocalVar::meta, Arg::meta, "lvar");
		SetVar::meta_arg_end_ = Arg::meta_lvar_rev = LocalVar::meta_arg;
		LocalVar::meta_argument = ::ctest::LocalVar_cross_ph_SFC::meta_argument;
		LocalVar::meta_loop = ::ctest::LocalVar_cross_ph_SFC::meta_loop;
		LocalVar::meta_klass = ::ctest::LocalVar_cross_ph_SFC::meta_klass;

		::Uml::SetChildRole(Return::meta_retexpr, Return::meta, Exprs::meta, "retexprpar", "retexpr");

		::Uml::SetAssocRole(StateLabel::meta_arg, StateLabel::meta, Arg::meta, "slab");
		CheckArg::meta_arg_end_ = Arg::meta_slab_rev = StateLabel::meta_arg;
		::Uml::SetAssocRole(StateLabel::meta_srv, StateLabel::meta, StateRel::meta, "value");
		::Uml::SetAssocRole(StateLabel::meta_sri, StateLabel::meta, StateRel::meta, "index");

		::Uml::SetAssocRole(StateRel::meta_value, StateRel::meta, StateLabel::meta, "srv");
		::Uml::SetAssocRole(StateRel::meta_index, StateRel::meta, StateLabel::meta, "sri");
		::Uml::SetAssocRole(StateRel::meta_svar, StateRel::meta, StateVar::meta, "srs");

		::Uml::SetAssocRole(StateVar::meta_srs, StateVar::meta, StateRel::meta, "svar");

		::Uml::SetParentRole(Statement::meta_csPar, Statement::meta, CompoundStatement::meta, "stmnt", "csPar");

		Struct::meta_adbpath = ::ctest::Struct_cross_ph_SFC::meta_adbpath;
		::Uml::SetChildRole(Struct::meta_memb, Struct::meta, Declaration::meta, "strct", "memb");

		::Uml::SetAssocRole(TypedEntity::meta_dt, TypedEntity::meta, DT::meta, "te");

		::Uml::SetChildRole(UnaryExprs::meta_subexpr, UnaryExprs::meta, Exprs::meta, "subexprpar", "subexpr");

		::Uml::SetChildRole(UserCode::meta_codeexpr, UserCode::meta, Exprs::meta, "codeexprpar", "codeexpr");

	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("SFC.xsd", SFC_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

		ctest::Initialize();
	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("SFC.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "SFC", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		UDM_ASSERT(::ctest::meta != ::Udm::null);
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("SFC", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("SFC");
		}
	} __regUnUsed;

}

