/* ctestgen.cpp generated on Tue Jun 19 13:55:29 2012
 */

#include "ctestgen.h"
#include <UmlExt.h>
#include "GReATSort.h"
#include "RTTGenerator.h"
#include "ctest-gr_cmptempl.h"

void Start_0::operator()( const Packets_t& ins_1)
{
#ifdef PRINT_INFO
	std::cout << "Start_0" << std::endl;
#endif
	if( ( !ins_1.empty()))
		callGetProject_fd3( ins_1);
}

void Start_0::callGetProject_fd3( const Packets_t& projects_fc1)
{
	Packets_t projects_fc3;
	GetProject_fc0 getProject_fc0;
	getProject_fc0( projects_fc1, projects_fc3);
	if( ( !projects_fc3.empty()))
		callGetProgram_fd5( projects_fc3);
}

void Start_0::callGetProgram_fd5( const Packets_t& projects_6a)
{
	Packets_t programs_69;
	GetProgram_68 getProgram_68;
	getProgram_68( projects_6a, programs_69);
	if( ( !programs_69.empty()))
		callIncludeFiles_fd7( programs_69);
}

void Start_0::callIncludeFiles_fd7( const Packets_t& programs_82)
{
	Packets_t programs_84;
	IncludeFiles_81 includeFiles_81;
	includeFiles_81( programs_82, programs_84);
	if( ( !programs_84.empty()))
		callGetMainClass_fd9( programs_84);
}

void Start_0::callGetMainClass_fd9( const Packets_t& programs_4)
{
	Packets_t classs_6;
	GetMainClass_3 getMainClass_3;
	getMainClass_3( programs_4, classs_6);
	if( ( !classs_6.empty()))
		callMarkInitAndMain_fdb( classs_6);
}

void Start_0::callMarkInitAndMain_fdb( const Packets_t& classs_d52)
{
	Packets_t classs_d54;
	MarkInitAndMain_d51 markInitAndMain_d51;
	markInitAndMain_d51( classs_d52, classs_d54);
	if( ( !classs_d54.empty()))
		callCreateMain_fdd( classs_d54);
}

void Start_0::callCreateMain_fdd( const Packets_t& classs_fa5)
{
	Packets_t classs_fa7;
	Packets_t mainFunctions_fa8;
	CreateMain_fa4 createMain_fa4;
	createMain_fa4( classs_fa5, classs_fa7, mainFunctions_fa8);
	if( ( !classs_fa7.empty())&& ( !mainFunctions_fa8.empty()))
		callCallInit_fdf( classs_fa7, mainFunctions_fa8);
}

void Start_0::callCallInit_fdf( const Packets_t& classs_f41, const Packets_t& mains_f43)
{
	Packets_t classs_f45;
	Packets_t mains_f46;
	CallInit_f40 callInit_f40;
	callInit_f40( classs_f41, mains_f43, classs_f45, mains_f46);
	if( ( !classs_f45.empty())&& ( !mains_f46.empty()))
		callCreateLoop_fe2( classs_f45, mains_f46);
}

void Start_0::callCreateLoop_fe2( const Packets_t& classs_cda, const Packets_t& mains_cdc)
{
	Packets_t modelMains_cde;
	Packets_t mains_cdf;
	Packets_t loops_ce0;
	CreateLoop_cd9 createLoop_cd9;
	createLoop_cd9( classs_cda, mains_cdc, modelMains_cde, mains_cdf, loops_ce0);
	if( ( !modelMains_cde.empty())&& ( !mains_cdf.empty())&& ( !loops_ce0.empty()))
		callCallModelMain_fe5( modelMains_cde, mains_cdf, loops_ce0);
}

void Start_0::callCallModelMain_fe5( const Packets_t& modelMains_da2, const Packets_t& mains_da4, const Packets_t& loops_da6)
{
	Packets_t modelMains_da8;
	Packets_t loops_da9;
	CallModelMain_da1 callModelMain_da1;
	callModelMain_da1( modelMains_da2, mains_da4, loops_da6, modelMains_da8, loops_da9);
	if( ( !modelMains_da8.empty())&& ( !loops_da9.empty()))
		callPrintContext_fe9( modelMains_da8, loops_da9);
}

void Start_0::callPrintContext_fe9( const Packets_t& modelMains_9b, const Packets_t& mains_9d)
{
	PrintContext_9a printContext_9a;
	printContext_9a( modelMains_9b, mains_9d);
}

void GetMainClass_3::operator()( const Packets_t& programs_4, Packets_t& classs_6)
{
#ifdef PRINT_INFO
	std::cout << "GetMainClass_3" << std::endl;
#endif
	_class_7= &classs_6;
	if( ( !programs_4.empty()))
		callGetClasses_64( programs_4);
}

void GetMainClass_3::callGetClasses_64( const Packets_t& programs_4c)
{
	Packets_t classs_4e;
	GetClasses_4b getClasses_4b;
	getClasses_4b( programs_4c, classs_4e);
	if( ( !classs_4e.empty()))
		callGetTopClass_66( classs_4e);
}

void GetMainClass_3::callGetTopClass_66( const Packets_t& classs_9)
{
	Packets_t classs_b;
	GetTopClass_8 getTopClass_8;
	getTopClass_8( classs_9, classs_b);
	_class_7->insert( _class_7->end(), classs_b.begin(), classs_b.end());
}

void GetTopClass_8::operator()( const Packets_t& classs_9, Packets_t& classs_b)
{
#ifdef PRINT_INFO
	std::cout << "GetTopClass_8" << std::endl;
#endif
	_class_c= &classs_b;
	for( Packets_t::const_iterator itClass_e= classs_9.begin(); itClass_e!= classs_9.end(); ++itClass_e)
	{
		bool isUnique= isInputUnique( *itClass_e);
		if( !isUnique)
			continue;
		Packets_t oneClass_12( 1, *itClass_e);
		executeOne( oneClass_12);
	}
}

void GetTopClass_8::executeOne( const Packets_t& classs_9)
{
	MainCalled_14 mainCalled_14;
	bool isMatchMainCalled_14= mainCalled_14( classs_9);
	if( isMatchMainCalled_14)
		return;
	Packets_t classs_33;
	MainNotCalled_30 mainNotCalled_30;
	bool isMatchMainNotCalled_30= mainNotCalled_30( classs_9, classs_33);
	_class_c->insert( _class_c->end(), classs_33.begin(), classs_33.end());
	if( isMatchMainNotCalled_30)
		return;
}

bool GetTopClass_8::isInputUnique( const Udm::Object& class_f)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_11= _class_d.begin(); itClass_11!= _class_d.end(); ++itClass_11)
	{
		if( ( *itClass_11== class_f))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_class_d.push_back( class_f);
	return isUnique;
}

bool MainCalled_14::operator()( const Packets_t& classs_15)
{
#ifdef PRINT_INFO
	std::cout << "MainCalled_14" << std::endl;
#endif
	processInputPackets( classs_15);
	if( false== _matches.empty())
		return true;
	return false;
}

bool MainCalled_14::isInputUnique( const Udm::Object& class_1b)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_1d= _class_17.begin(); itClass_1d!= _class_17.end(); ++itClass_1d)
	{
		if( ( *itClass_1d== class_1b))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_class_17.push_back( class_1b);
	return isUnique;
}

bool MainCalled_14::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

bool MainCalled_14::isGuardTrue( SFC::FunctionCall& Caller, SFC::Class& Class, SFC::Function& Function)
{
	bool Gz_guard= false;
	std::string name = Function.name();
Gz_guard = name.substr( name.length() - 4 ) == "main";;
	return Gz_guard;
}

void MainCalled_14::processInputPackets( const Packets_t& classs_15)
{
	for( Packets_t::const_iterator itClass_18= classs_15.begin(); itClass_18!= classs_15.end(); ++itClass_18)
	{
		bool isUnique= isInputUnique( *itClass_18);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itClass_18);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( );
	}
}

bool MainCalled_14::patternMatcher( const Udm::Object& class_19)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( class_19.type(), SFC::Class::meta))
			continue;
		SFC::Class class_1e= SFC::Class::Cast( class_19);
		set< SFC::Function> functions_20= class_1e.Function_kind_children();
		for( set< SFC::Function>::const_iterator itFunction_21= functions_20.begin(); itFunction_21!= functions_20.end(); ++itFunction_21)
		{
			SFC::Function currFunction_22= *itFunction_21;
			set< SFC::FunctionCall> callers_23= currFunction_22.caller();
			for( set< SFC::FunctionCall>::const_iterator itCallers_24= callers_23.begin(); itCallers_24!= callers_23.end(); ++itCallers_24)
			{
				SFC::FunctionCall currCaller_25= *itCallers_24;
				Match currMatch;
				set< pair<int, Udm::Object> > boundObjs_29;
				if( !isValidBound(boundObjs_29, class_1e, true))
					continue;
				currMatch.class_2a= class_1e;
				if( !isValidBound(boundObjs_29, currFunction_22, false))
					continue;
				currMatch.function_2b= currFunction_22;
				if( !isValidBound(boundObjs_29, currCaller_25, false))
					continue;
				currMatch.caller_2c= currCaller_25;
				bool Gz_guard= isGuardTrue( currMatch.caller_2c, currMatch.class_2a, currMatch.function_2b);
				if( true== Gz_guard)
					_matches.push_back( currMatch);
			}
		}
	}
	return !_matches.empty();
}

void MainCalled_14::outputAppender()
{
}

bool MainNotCalled_30::operator()( const Packets_t& classs_31, Packets_t& classs_33)
{
#ifdef PRINT_INFO
	std::cout << "MainNotCalled_30" << std::endl;
#endif
	_class_34= &classs_33;
	processInputPackets( classs_31);
	if( false== _matches.empty())
		return true;
	return false;
}

bool MainNotCalled_30::isInputUnique( const Udm::Object& class_39)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_3b= _class_35.begin(); itClass_3b!= _class_35.end(); ++itClass_3b)
	{
		if( ( *itClass_3b== class_39))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_class_35.push_back( class_39);
	return isUnique;
}

bool MainNotCalled_30::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

bool MainNotCalled_30::isGuardTrue( SFC::Class& Class, SFC::Function& Function)
{
	bool Gz_guard= false;
	std::string name = Function.name();
Gz_guard = name.substr( name.length() - 4 ) == "main";;
	return Gz_guard;
}

void MainNotCalled_30::processInputPackets( const Packets_t& classs_31)
{
	for( Packets_t::const_iterator itClass_36= classs_31.begin(); itClass_36!= classs_31.end(); ++itClass_36)
	{
		bool isUnique= isInputUnique( *itClass_36);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itClass_36);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.class_45);
	}
}

bool MainNotCalled_30::patternMatcher( const Udm::Object& class_37)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( class_37.type(), SFC::Class::meta))
			continue;
		SFC::Class class_3c= SFC::Class::Cast( class_37);
		set< SFC::Function> functions_3e= class_3c.Function_kind_children();
		for( set< SFC::Function>::const_iterator itFunction_3f= functions_3e.begin(); itFunction_3f!= functions_3e.end(); ++itFunction_3f)
		{
			SFC::Function currFunction_40= *itFunction_3f;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_44;
			if( !isValidBound(boundObjs_44, class_3c, true))
				continue;
			currMatch.class_45= class_3c;
			if( !isValidBound(boundObjs_44, currFunction_40, false))
				continue;
			currMatch.function_46= currFunction_40;
			bool Gz_guard= isGuardTrue( currMatch.class_45, currMatch.function_46);
			if( true== Gz_guard)
				_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void MainNotCalled_30::outputAppender( const SFC::Class& class_49)
{
	_class_34->push_back( class_49);
}

void GetClasses_4b::operator()( const Packets_t& programs_4c, Packets_t& classs_4e)
{
#ifdef PRINT_INFO
	std::cout << "GetClasses_4b" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(21, "GetClasses");
	_class_4f= &classs_4e;
	processInputPackets( programs_4c);
}

bool GetClasses_4b::isInputUnique( const Udm::Object& program_54)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itProgram_56= _program_50.begin(); itProgram_56!= _program_50.end(); ++itProgram_56)
	{
		if( ( *itProgram_56== program_54))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_program_50.push_back( program_54);
	return isUnique;
}

bool GetClasses_4b::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetClasses_4b::processInputPackets( const Packets_t& programs_4c)
{
	for( Packets_t::const_iterator itProgram_51= programs_4c.begin(); itProgram_51!= programs_4c.end(); ++itProgram_51)
	{
		bool isUnique= isInputUnique( *itProgram_51);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itProgram_51);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetClasses_4b::patternMatcher( const Udm::Object& program_52)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( program_52.type(), SFC::Program::meta))
			continue;
		SFC::Program program_57= SFC::Program::Cast( program_52);
		set< SFC::Class> classs_59= program_57.Class_kind_children();
		for( set< SFC::Class>::const_iterator itClass_5a= classs_59.begin(); itClass_5a!= classs_59.end(); ++itClass_5a)
		{
			SFC::Class currClass_5b= *itClass_5a;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_5f;
			if( !isValidBound(boundObjs_5f, program_57, true))
				continue;
			currMatch.program_60= program_57;
			if( !isValidBound(boundObjs_5f, currClass_5b, false))
				continue;
			currMatch.class_61= currClass_5b;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void GetClasses_4b::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.class_61);
	}
}

void GetClasses_4b::outputAppender( const SFC::Class& class_62)
{
	_class_4f->push_back( class_62);
}

void GetProgram_68::operator()( const Packets_t& projects_6a, Packets_t& programs_69)
{
#ifdef PRINT_INFO
	std::cout << "GetProgram_68" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(25, "GetProgram");
	_program_6c= &programs_69;
	processInputPackets( projects_6a);
}

bool GetProgram_68::isInputUnique( const Udm::Object& project_71)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itProject_73= _project_6d.begin(); itProject_73!= _project_6d.end(); ++itProject_73)
	{
		if( ( *itProject_73== project_71))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_project_6d.push_back( project_71);
	return isUnique;
}

bool GetProgram_68::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetProgram_68::processInputPackets( const Packets_t& projects_6a)
{
	for( Packets_t::const_iterator itProject_6e= projects_6a.begin(); itProject_6e!= projects_6a.end(); ++itProject_6e)
	{
		bool isUnique= isInputUnique( *itProject_6e);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itProject_6e);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetProgram_68::patternMatcher( const Udm::Object& project_6f)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( project_6f.type(), SFC::Project::meta))
			continue;
		SFC::Project project_74= SFC::Project::Cast( project_6f);
		set< SFC::Program> programs_76= project_74.Program_kind_children();
		for( set< SFC::Program>::const_iterator itProgram_77= programs_76.begin(); itProgram_77!= programs_76.end(); ++itProgram_77)
		{
			SFC::Program currProgram_78= *itProgram_77;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_7c;
			if( !isValidBound(boundObjs_7c, project_74, true))
				continue;
			currMatch.project_7d= project_74;
			if( !isValidBound(boundObjs_7c, currProgram_78, false))
				continue;
			currMatch.program_7e= currProgram_78;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void GetProgram_68::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.program_7e);
	}
}

void GetProgram_68::outputAppender( const SFC::Program& program_7f)
{
	_program_6c->push_back( program_7f);
}

void IncludeFiles_81::operator()( const Packets_t& programs_82, Packets_t& programs_84)
{
#ifdef PRINT_INFO
	std::cout << "IncludeFiles_81" << std::endl;
#endif
	_program_85= &programs_84;
	if( ( !programs_82.empty()))
		callInsertIncludes_98( programs_82);
	_program_85->insert( _program_85->end(), programs_82.begin(), programs_82.end());
}

void IncludeFiles_81::callInsertIncludes_98( const Packets_t& programs_87)
{
	InsertIncludes_86 insertIncludes_86;
	insertIncludes_86( programs_87);
}

void InsertIncludes_86::operator()( const Packets_t& programs_87)
{
#ifdef PRINT_INFO
	std::cout << "InsertIncludes_86" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(32, "InsertIncludes");
	processInputPackets( programs_87);
}

bool InsertIncludes_86::isInputUnique( const Udm::Object& program_8d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itProgram_8f= _program_89.begin(); itProgram_8f!= _program_89.end(); ++itProgram_8f)
	{
		if( ( *itProgram_8f== program_8d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_program_89.push_back( program_8d);
	return isUnique;
}

bool InsertIncludes_86::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void InsertIncludes_86::processInputPackets( const Packets_t& programs_87)
{
	for( Packets_t::const_iterator itProgram_8a= programs_87.begin(); itProgram_8a!= programs_87.end(); ++itProgram_8a)
	{
		bool isUnique= isInputUnique( *itProgram_8a);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itProgram_8a);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool InsertIncludes_86::patternMatcher( const Udm::Object& program_8b)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( program_8b.type(), SFC::Program::meta))
			continue;
		SFC::Program program_90= SFC::Program::Cast( program_8b);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_95;
		if( !isValidBound(boundObjs_95, program_90, true))
			continue;
		currMatch.program_96= program_90;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void InsertIncludes_86::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::UserCode newmprint_97= SFC::UserCode::Create( currMatch.program_96);
		SFC::Program& Program= currMatch.program_96;
		SFC::UserCode& mprint= newmprint_97;
		{
mprint.expr() = "#include \"mprint.h\"";
};
	}
}

void PrintContext_9a::operator()( const Packets_t& modelMains_9b, const Packets_t& mains_9d)
{
#ifdef PRINT_INFO
	std::cout << "PrintContext_9a" << std::endl;
#endif
	if( ( !modelMains_9b.empty())&& ( !mains_9d.empty()))
		callPrintContext_cd4( modelMains_9b, mains_9d);
}

void PrintContext_9a::callPrintContext_cd4( const Packets_t& modelMains_b4, const Packets_t& mains_b6)
{
	Packets_t modelMains_b8;
	Packets_t mains_b9;
	PrintContext_b3 printContext_b3;
	printContext_b3( modelMains_b4, mains_b6, modelMains_b8, mains_b9);
	if( ( !mains_b9.empty()))
		callPrintNewline_cd7( mains_b9);
}

void PrintContext_9a::callPrintNewline_cd7( const Packets_t& mains_a0)
{
	PrintNewline_9f printNewline_9f;
	printNewline_9f( mains_a0);
}

void PrintNewline_9f::operator()( const Packets_t& mains_a0)
{
#ifdef PRINT_INFO
	std::cout << "PrintNewline_9f" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(40, "PrintNewline");
	processInputPackets( mains_a0);
}

bool PrintNewline_9f::isInputUnique( const Udm::Object& main_a6)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itMain_a8= _main_a2.begin(); itMain_a8!= _main_a2.end(); ++itMain_a8)
	{
		if( ( *itMain_a8== main_a6))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_main_a2.push_back( main_a6);
	return isUnique;
}

bool PrintNewline_9f::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void PrintNewline_9f::processInputPackets( const Packets_t& mains_a0)
{
	for( Packets_t::const_iterator itMain_a3= mains_a0.begin(); itMain_a3!= mains_a0.end(); ++itMain_a3)
	{
		bool isUnique= isInputUnique( *itMain_a3);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itMain_a3);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool PrintNewline_9f::patternMatcher( const Udm::Object& main_a4)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( main_a4.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_a9= SFC::CompoundStatement::Cast( main_a4);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_ae;
		if( !isValidBound(boundObjs_ae, main_a9, true))
			continue;
		currMatch.main_af= main_a9;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void PrintNewline_9f::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::FunctionCall newPrintf_b0= SFC::FunctionCall::Create( currMatch.main_af, SFC::CompoundStatement::meta_stmnt);
		SFC::ArgVal newFormatArgVal_b1= SFC::ArgVal::Create( newPrintf_b0);
		SFC::Str newFormat_b2= SFC::Str::Create( newFormatArgVal_b1, SFC::ArgVal::meta_argexpr);
		SFC::Str& Format= newFormat_b2;
		SFC::ArgVal& FormatArgVal= newFormatArgVal_b1;
		SFC::CompoundStatement& Main= currMatch.main_af;
		SFC::FunctionCall& Printf= newPrintf_b0;
		{
Format.val() = "\\n";
};
		{
FormatArgVal.argIndex() = 0;

};
		{
__int64 statementCount = Main.statementCount();
Printf.statementIndex() = statementCount++;
Main.statementCount() = statementCount;

Printf.libFuncName() = "printf";
Printf.argCount() = 1;
FormatArgVal.argIndex() = 1;
Format.val() = "\\n";
};
	}
}

void PrintContext_b3::operator()( const Packets_t& modelMains_b4, const Packets_t& mains_b6, Packets_t& modelMains_b8, Packets_t& mains_b9)
{
#ifdef PRINT_INFO
	std::cout << "PrintContext_b3" << std::endl;
#endif
	_modelMain_ba= &modelMains_b8;
	_main_bb= &mains_b9;
	_modelMain_ba->insert( _modelMain_ba->end(), modelMains_b4.begin(), modelMains_b4.end());
	_main_bb->insert( _main_bb->end(), mains_b6.begin(), mains_b6.end());
	if( ( !modelMains_b4.empty())&& ( !mains_b6.empty()))
		callGetSortedArgs_cc4( modelMains_b4, mains_b6);
}

void PrintContext_b3::callGetSortedArgs_cc4( const Packets_t& modelMains_c9a, const Packets_t& mains_c9c)
{
	Packets_t args_c99;
	Packets_t mains_c9e;
	GetSortedArgs_c98 getSortedArgs_c98;
	getSortedArgs_c98( modelMains_c9a, mains_c9c, args_c99, mains_c9e);
	if( ( !args_c99.empty())&& ( !mains_c9e.empty()))
		callGetVarsForArgs_cc7( args_c99, mains_c9e);
}

void PrintContext_b3::callGetVarsForArgs_cc7( const Packets_t& args_c72, const Packets_t& mains_c75)
{
	Packets_t vars_c74;
	Packets_t mains_c77;
	GetVarsForArgs_c71 getVarsForArgs_c71;
	getVarsForArgs_c71( args_c72, mains_c75, vars_c74, mains_c77);
	if( ( !vars_c74.empty())&& ( !mains_c77.empty()))
		callGetDT_cca( vars_c74, mains_c77);
}

void PrintContext_b3::callGetDT_cca( const Packets_t& vars_c47, const Packets_t& mains_c4b)
{
	Packets_t vars_c49;
	Packets_t dTs_c4a;
	Packets_t mains_c4d;
	GetDT_c46 getDT_c46;
	getDT_c46( vars_c47, mains_c4b, vars_c49, dTs_c4a, mains_c4d);
	if( ( !vars_c49.empty())&& ( !dTs_c4a.empty())&& ( !mains_c4d.empty()))
		callMakeLoops_ccd( vars_c49, dTs_c4a, mains_c4d);
}

void PrintContext_b3::callMakeLoops_ccd( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1)
{
	Packets_t passADBs_c3;
	Packets_t passCSs_c4;
	Packets_t ues_c5;
	MakeLoops_bc makeLoops_bc;
	makeLoops_bc( passADBs_bd, dts_bf, mains_c1, passADBs_c3, passCSs_c4, ues_c5);
	if( ( !passADBs_c3.empty())&& ( !ues_c5.empty()))
		callAddVar_cd1( passADBs_c3, ues_c5);
}

void PrintContext_b3::callAddVar_cd1( const Packets_t& argDeclBases_c29, const Packets_t& unaryExprss_c2b)
{
	AddVar_c28 addVar_c28;
	addVar_c28( argDeclBases_c29, unaryExprss_c2b);
}

void MakeLoops_bc::operator()( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1, Packets_t& passADBs_c3, Packets_t& passCSs_c4, Packets_t& ues_c5)
{
#ifdef PRINT_INFO
	std::cout << "MakeLoops_bc" << std::endl;
#endif
	_passADB_c6= &passADBs_c3;
	_passCS_c7= &passCSs_c4;
	_ue_c8= &ues_c5;
	for( Packets_t::const_iterator itPassADB_ca= passADBs_bd.begin(), itdt_d1= dts_bf.begin(), itMain_d8= mains_c1.begin(); itPassADB_ca!= passADBs_bd.end(), itdt_d1!= dts_bf.end(), itMain_d8!= mains_c1.end(); ++itPassADB_ca, ++itdt_d1, ++itMain_d8)
	{
		bool isUnique= isInputUnique( *itPassADB_ca, *itdt_d1, *itMain_d8);
		if( !isUnique)
			continue;
		Packets_t onePassADB_ce( 1, *itPassADB_ca);
		Packets_t onedt_d5( 1, *itdt_d1);
		Packets_t oneMain_dc( 1, *itMain_d8);
		executeOne( onePassADB_ce, onedt_d5, oneMain_dc);
	}
}

void MakeLoops_bc::executeOne( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1)
{
	if( ( !passADBs_bd.empty())&& ( !dts_bf.empty())&& ( !mains_c1.empty()))
		callStructTest_be7( passADBs_bd, dts_bf, mains_c1);
}

bool MakeLoops_bc::isInputUnique( const Udm::Object& passADB_cb, const Udm::Object& dt_d2, const Udm::Object& main_d9)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itPassADB_cd= _passADB_c9.begin(), itdt_d4= _dt_d0.begin(), itMain_db= _main_d7.begin(); itPassADB_cd!= _passADB_c9.end(), itdt_d4!= _dt_d0.end(), itMain_db!= _main_d7.end(); ++itPassADB_cd, ++itdt_d4, ++itMain_db)
	{
		if( ( *itPassADB_cd== passADB_cb)&& ( *itdt_d4== dt_d2)&& ( *itMain_db== main_d9))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_c9.push_back( passADB_cb);
		_dt_d0.push_back( dt_d2);
		_main_d7.push_back( main_d9);
	}
	return isUnique;
}

void MakeLoops_bc::callStructTest_be7( const Packets_t& passADBs_a80, const Packets_t& dts_a82, const Packets_t& mains_a84)
{
	Packets_t passADBs_a86;
	Packets_t basics_a87;
	Packets_t mains_a88;
	Packets_t passADBs_a89;
	Packets_t nullarrays_a8a;
	Packets_t mains_a8b;
	Packets_t passADBs_a8c;
	Packets_t arrays_a8d;
	Packets_t mains_a8e;
	Packets_t passADBs_a8f;
	Packets_t structs_a90;
	Packets_t mains_a91;
	StructTest_a7f structTest_a7f;
	structTest_a7f( passADBs_a80, dts_a82, mains_a84, passADBs_a86, basics_a87, mains_a88, passADBs_a89, nullarrays_a8a, mains_a8b, passADBs_a8c, arrays_a8d, mains_a8e, passADBs_a8f, structs_a90, mains_a91);
	if( ( !passADBs_a89.empty())&& ( !nullarrays_a8a.empty())&& ( !mains_a8b.empty()))
		callSkipArray_beb( passADBs_a89, nullarrays_a8a, mains_a8b);
	if( ( !passADBs_a86.empty())&& ( !basics_a87.empty())&& ( !mains_a88.empty()))
		callBasicType_bef( passADBs_a86, basics_a87, mains_a88);
	if( ( !passADBs_a8f.empty())&& ( !structs_a90.empty())&& ( !mains_a91.empty()))
		callMakePath_bf3( passADBs_a8f, structs_a90, mains_a91);
	if( ( !passADBs_a8c.empty())&& ( !arrays_a8d.empty())&& ( !mains_a8e.empty()))
		callMakeArrayLoop_bf7( passADBs_a8c, arrays_a8d, mains_a8e);
}

void MakeLoops_bc::callSkipArray_beb( const Packets_t& argDeclBases_717, const Packets_t& arrays_71a, const Packets_t& mains_71d)
{
	Packets_t argDeclBases_719;
	Packets_t dTs_71c;
	Packets_t mains_71f;
	SkipArray_716 skipArray_716;
	skipArray_716( argDeclBases_717, arrays_71a, mains_71d, argDeclBases_719, dTs_71c, mains_71f);
	if( ( !argDeclBases_719.empty())&& ( !dTs_71c.empty())&& ( !mains_71f.empty()))
		callMakeLoops_bfb( argDeclBases_719, dTs_71c, mains_71f);
}

void MakeLoops_bc::callBasicType_bef( const Packets_t& argDeclBases_b7f, const Packets_t& basicTypes_b82, const Packets_t& compoundStatements_b85)
{
	Packets_t argDeclBases_b81;
	Packets_t basicTypes_b84;
	Packets_t compoundStatements_b87;
	Packets_t unaryExprss_b88;
	BasicType_b7e basicType_b7e;
	basicType_b7e( argDeclBases_b7f, basicTypes_b82, compoundStatements_b85, argDeclBases_b81, basicTypes_b84, compoundStatements_b87, unaryExprss_b88);
	if( ( !argDeclBases_b81.empty())&& ( !basicTypes_b84.empty())&& ( !compoundStatements_b87.empty())&& ( !unaryExprss_b88.empty()))
		callBoolTest_bff( argDeclBases_b81, basicTypes_b84, compoundStatements_b87, unaryExprss_b88);
}

void MakeLoops_bc::callMakePath_bf3( const Packets_t& argDeclBases_bba, const Packets_t& structs_bbc, const Packets_t& mains_bbf)
{
	Packets_t structs_bbe;
	Packets_t mains_bc1;
	MakePath_bb9 makePath_bb9;
	makePath_bb9( argDeclBases_bba, structs_bbc, mains_bbf, structs_bbe, mains_bc1);
	if( ( !structs_bbe.empty())&& ( !mains_bc1.empty()))
		callProcessStruct_c04( structs_bbe, mains_bc1);
}

void MakeLoops_bc::callMakeArrayLoop_bf7( const Packets_t& argDeclBases_a3e, const Packets_t& arrays_a41, const Packets_t& mains_a45)
{
	Packets_t argDeclBases_a40;
	Packets_t arrays_a43;
	Packets_t dTs_a44;
	Packets_t loops_a47;
	MakeArrayLoop_a3d makeArrayLoop_a3d;
	makeArrayLoop_a3d( argDeclBases_a3e, arrays_a41, mains_a45, argDeclBases_a40, arrays_a43, dTs_a44, loops_a47);
	if( ( !argDeclBases_a40.empty())&& ( !arrays_a43.empty())&& ( !dTs_a44.empty())&& ( !loops_a47.empty()))
		callColumnMajor_c07( argDeclBases_a40, arrays_a43, dTs_a44, loops_a47);
}

void MakeLoops_bc::callMakeLoops_bfb( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1)
{
	Packets_t passADBs_c3;
	Packets_t passCSs_c4;
	Packets_t ues_c5;
	MakeLoops_bc makeLoops_bc;
	makeLoops_bc( passADBs_bd, dts_bf, mains_c1, passADBs_c3, passCSs_c4, ues_c5);
	_passADB_c6->insert( _passADB_c6->end(), passADBs_c3.begin(), passADBs_c3.end());
	_passCS_c7->insert( _passCS_c7->end(), passCSs_c4.begin(), passCSs_c4.end());
	_ue_c8->insert( _ue_c8->end(), ues_c5.begin(), ues_c5.end());
}

void MakeLoops_bc::callBoolTest_bff( const Packets_t& passADBs_119, const Packets_t& basictypes_11b, const Packets_t& css_11d, const Packets_t& ues_11f)
{
	Packets_t passADBs_121;
	Packets_t basictypes_122;
	Packets_t css_123;
	Packets_t ues_124;
	Packets_t passADBs_125;
	Packets_t basictypes_126;
	Packets_t css_127;
	Packets_t ues_128;
	BoolTest_118 boolTest_118;
	boolTest_118( passADBs_119, basictypes_11b, css_11d, ues_11f, passADBs_121, basictypes_122, css_123, ues_124, passADBs_125, basictypes_126, css_127, ues_128);
	if( ( !passADBs_121.empty())&& ( !css_123.empty())&& ( !ues_124.empty()))
		callAddBooleanVar_c0c( passADBs_121, css_123, ues_124);
	_passADB_c6->insert( _passADB_c6->end(), passADBs_125.begin(), passADBs_125.end());
	_passCS_c7->insert( _passCS_c7->end(), css_127.begin(), css_127.end());
	_ue_c8->insert( _ue_c8->end(), ues_128.begin(), ues_128.end());
}

void MakeLoops_bc::callProcessStruct_c04( const Packets_t& structs_22b, const Packets_t& mains_22d)
{
	Packets_t localVars_22a;
	Packets_t mains_22f;
	ProcessStruct_229 processStruct_229;
	processStruct_229( structs_22b, mains_22d, localVars_22a, mains_22f);
	if( ( !localVars_22a.empty())&& ( !mains_22f.empty()))
		callMemberDataType_c10( localVars_22a, mains_22f);
}

void MakeLoops_bc::callColumnMajor_c07( const Packets_t& passADBs_74b, const Packets_t& toparrays_74d, const Packets_t& dts_74f, const Packets_t& mains_751)
{
	Packets_t passADBs_753;
	Packets_t dts_754;
	Packets_t mains_755;
	ColumnMajor_74a columnMajor_74a;
	columnMajor_74a( passADBs_74b, toparrays_74d, dts_74f, mains_751, passADBs_753, dts_754, mains_755);
	if( ( !passADBs_753.empty())&& ( !dts_754.empty())&& ( !mains_755.empty()))
		callMakeLoops_c13( passADBs_753, dts_754, mains_755);
}

void MakeLoops_bc::callAddBooleanVar_c0c( const Packets_t& argDeclBases_df, const Packets_t& compoundStatements_e2, const Packets_t& unaryExprss_e5)
{
	Packets_t argDeclBases_e1;
	Packets_t compoundStatements_e4;
	Packets_t newUnaryExprss_e7;
	AddBooleanVar_de addBooleanVar_de;
	addBooleanVar_de( argDeclBases_df, compoundStatements_e2, unaryExprss_e5, argDeclBases_e1, compoundStatements_e4, newUnaryExprss_e7);
	_passADB_c6->insert( _passADB_c6->end(), argDeclBases_e1.begin(), argDeclBases_e1.end());
	_passCS_c7->insert( _passCS_c7->end(), compoundStatements_e4.begin(), compoundStatements_e4.end());
	_ue_c8->insert( _ue_c8->end(), newUnaryExprss_e7.begin(), newUnaryExprss_e7.end());
}

void MakeLoops_bc::callMemberDataType_c10( const Packets_t& localVars_a16, const Packets_t& mains_a1a)
{
	Packets_t localVars_a18;
	Packets_t dTs_a19;
	Packets_t mains_a1c;
	MemberDataType_a15 memberDataType_a15;
	memberDataType_a15( localVars_a16, mains_a1a, localVars_a18, dTs_a19, mains_a1c);
	if( ( !localVars_a18.empty())&& ( !dTs_a19.empty())&& ( !mains_a1c.empty()))
		callMakeLoops_c17( localVars_a18, dTs_a19, mains_a1c);
}

void MakeLoops_bc::callMakeLoops_c13( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1)
{
	Packets_t passADBs_c3;
	Packets_t passCSs_c4;
	Packets_t ues_c5;
	MakeLoops_bc makeLoops_bc;
	makeLoops_bc( passADBs_bd, dts_bf, mains_c1, passADBs_c3, passCSs_c4, ues_c5);
	if( ( !passADBs_c3.empty())&& ( !passCSs_c4.empty())&& ( !ues_c5.empty()))
		callAddIndexes_c1b( passADBs_c3, passCSs_c4, ues_c5);
}

void MakeLoops_bc::callMakeLoops_c17( const Packets_t& passADBs_bd, const Packets_t& dts_bf, const Packets_t& mains_c1)
{
	Packets_t passADBs_c3;
	Packets_t passCSs_c4;
	Packets_t ues_c5;
	MakeLoops_bc makeLoops_bc;
	makeLoops_bc( passADBs_bd, dts_bf, mains_c1, passADBs_c3, passCSs_c4, ues_c5);
	if( ( !passADBs_c3.empty())&& ( !passCSs_c4.empty())&& ( !ues_c5.empty()))
		callStructExprs_c1f( passADBs_c3, passCSs_c4, ues_c5);
}

void MakeLoops_bc::callAddIndexes_c1b( const Packets_t& passADBs_28e, const Packets_t& passCSs_290, const Packets_t& ues_292)
{
	Packets_t passADBs_294;
	Packets_t passCSs_295;
	Packets_t ues_296;
	AddIndexes_28d addIndexes_28d;
	addIndexes_28d( passADBs_28e, passCSs_290, ues_292, passADBs_294, passCSs_295, ues_296);
	_passADB_c6->insert( _passADB_c6->end(), passADBs_294.begin(), passADBs_294.end());
	_passCS_c7->insert( _passCS_c7->end(), passCSs_295.begin(), passCSs_295.end());
	_ue_c8->insert( _ue_c8->end(), ues_296.begin(), ues_296.end());
}

void MakeLoops_bc::callStructExprs_c1f( const Packets_t& localVars_252, const Packets_t& compoundStatements_254, const Packets_t& unaryExprss_257)
{
	Packets_t argDeclBases_250;
	Packets_t structs_251;
	Packets_t compoundStatements_256;
	Packets_t newUnaryExprss_259;
	StructExprs_24f structExprs_24f;
	structExprs_24f( localVars_252, compoundStatements_254, unaryExprss_257, argDeclBases_250, structs_251, compoundStatements_256, newUnaryExprss_259);
	if( ( !argDeclBases_250.empty())&& ( !structs_251.empty())&& ( !compoundStatements_256.empty())&& ( !newUnaryExprss_259.empty()))
		callBreakPath_c23( argDeclBases_250, structs_251, compoundStatements_256, newUnaryExprss_259);
}

void MakeLoops_bc::callBreakPath_c23( const Packets_t& passADBs_1dc, const Packets_t& structs_1de, const Packets_t& css_1e0, const Packets_t& ues_1e2)
{
	Packets_t passADBs_1e4;
	Packets_t css_1e5;
	Packets_t ues_1e6;
	BreakPath_1db breakPath_1db;
	breakPath_1db( passADBs_1dc, structs_1de, css_1e0, ues_1e2, passADBs_1e4, css_1e5, ues_1e6);
	_passADB_c6->insert( _passADB_c6->end(), passADBs_1e4.begin(), passADBs_1e4.end());
	_passCS_c7->insert( _passCS_c7->end(), css_1e5.begin(), css_1e5.end());
	_ue_c8->insert( _ue_c8->end(), ues_1e6.begin(), ues_1e6.end());
}

void AddBooleanVar_de::operator()( const Packets_t& argDeclBases_df, const Packets_t& compoundStatements_e2, const Packets_t& unaryExprss_e5, Packets_t& argDeclBases_e1, Packets_t& compoundStatements_e4, Packets_t& newUnaryExprss_e7)
{
#ifdef PRINT_INFO
	std::cout << "AddBooleanVar_de" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(63, "AddBooleanVar");
	_argDeclBase_e8= &argDeclBases_e1;
	_compoundStatement_e9= &compoundStatements_e4;
	_newUnaryExprs_ea= &newUnaryExprss_e7;
	processInputPackets( argDeclBases_df, compoundStatements_e2, unaryExprss_e5);
}

bool AddBooleanVar_de::isInputUnique( const Udm::Object& argDeclBase_ef, const Udm::Object& compoundStatement_f8, const Udm::Object& unaryExprs_101)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_f1= _argDeclBase_eb.begin(), itCompoundStatement_fa= _compoundStatement_f4.begin(), itUnaryExprs_103= _unaryExprs_fd.begin(); itArgDeclBase_f1!= _argDeclBase_eb.end(), itCompoundStatement_fa!= _compoundStatement_f4.end(), itUnaryExprs_103!= _unaryExprs_fd.end(); ++itArgDeclBase_f1, ++itCompoundStatement_fa, ++itUnaryExprs_103)
	{
		if( ( *itArgDeclBase_f1== argDeclBase_ef)&& ( *itCompoundStatement_fa== compoundStatement_f8)&& ( *itUnaryExprs_103== unaryExprs_101))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_eb.push_back( argDeclBase_ef);
		_compoundStatement_f4.push_back( compoundStatement_f8);
		_unaryExprs_fd.push_back( unaryExprs_101);
	}
	return isUnique;
}

bool AddBooleanVar_de::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void AddBooleanVar_de::processInputPackets( const Packets_t& argDeclBases_df, const Packets_t& compoundStatements_e2, const Packets_t& unaryExprss_e5)
{
	for( Packets_t::const_iterator itArgDeclBase_ec= argDeclBases_df.begin(), itCompoundStatement_f5= compoundStatements_e2.begin(), itUnaryExprs_fe= unaryExprss_e5.begin(); itArgDeclBase_ec!= argDeclBases_df.end(), itCompoundStatement_f5!= compoundStatements_e2.end(), itUnaryExprs_fe!= unaryExprss_e5.end(); ++itArgDeclBase_ec, ++itCompoundStatement_f5, ++itUnaryExprs_fe)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_ec, *itCompoundStatement_f5, *itUnaryExprs_fe);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_ec, *itCompoundStatement_f5, *itUnaryExprs_fe);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool AddBooleanVar_de::patternMatcher( const Udm::Object& argDeclBase_ed, const Udm::Object& compoundStatement_f6, const Udm::Object& unaryExprs_ff)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_ed.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_f2= SFC::ArgDeclBase::Cast( argDeclBase_ed);
		if( false== Uml::IsDerivedFrom( compoundStatement_f6.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_fb= SFC::CompoundStatement::Cast( compoundStatement_f6);
		if( false== Uml::IsDerivedFrom( unaryExprs_ff.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_104= SFC::UnaryExprs::Cast( unaryExprs_ff);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_109;
		if( !isValidBound(boundObjs_109, argDeclBase_f2, true))
			continue;
		currMatch.argDeclBase_10a= argDeclBase_f2;
		if( !isValidBound(boundObjs_109, compoundStatement_fb, true))
			continue;
		currMatch.compoundStatement_10b= compoundStatement_fb;
		if( !isValidBound(boundObjs_109, unaryExprs_104, true))
			continue;
		currMatch.unaryExprs_10c= unaryExprs_104;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void AddBooleanVar_de::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::BinaryExprs newQuestionMarkExprs_10d= SFC::BinaryExprs::Create( currMatch.unaryExprs_10c, SFC::UnaryExprs::meta_subexpr);
		SFC::BinaryExprs newColonExprs_10e= SFC::BinaryExprs::Create( newQuestionMarkExprs_10d, SFC::BinaryExprs::meta_rightexpr);
		SFC::UnaryExprs newNewUnaryExprs_10f= SFC::UnaryExprs::Create( newQuestionMarkExprs_10d, SFC::BinaryExprs::meta_leftexpr);
		SFC::Int newOne_110= SFC::Int::Create( newColonExprs_10e, SFC::BinaryExprs::meta_leftexpr);
		SFC::Int newZero_111= SFC::Int::Create( newColonExprs_10e, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_10a;
		SFC::BinaryExprs& ColonExprs= newColonExprs_10e;
		SFC::CompoundStatement& CompoundStatement= currMatch.compoundStatement_10b;
		SFC::UnaryExprs& NewUnaryExprs= newNewUnaryExprs_10f;
		SFC::Int& One= newOne_110;
		SFC::BinaryExprs& QuestionMarkExprs= newQuestionMarkExprs_10d;
		SFC::UnaryExprs& UnaryExprs= currMatch.unaryExprs_10c;
		SFC::Int& Zero= newZero_111;
		{
QuestionMarkExprs.op() = "?";
ColonExprs.op() = ":";
One.val() = 1;
Zero.val() = 0;
};
		outputAppender( currMatch.argDeclBase_10a, currMatch.compoundStatement_10b, newNewUnaryExprs_10f);
	}
}

void AddBooleanVar_de::outputAppender( const SFC::ArgDeclBase& argDeclBase_112, const SFC::CompoundStatement& compoundStatement_114, const SFC::UnaryExprs& newUnaryExprs_116)
{
	_argDeclBase_e8->push_back( argDeclBase_112);
	_compoundStatement_e9->push_back( compoundStatement_114);
	_newUnaryExprs_ea->push_back( newUnaryExprs_116);
}

void BoolTest_118::operator()( const Packets_t& passADBs_119, const Packets_t& basictypes_11b, const Packets_t& css_11d, const Packets_t& ues_11f, Packets_t& passADBs_121, Packets_t& basictypes_122, Packets_t& css_123, Packets_t& ues_124, Packets_t& passADBs_125, Packets_t& basictypes_126, Packets_t& css_127, Packets_t& ues_128)
{
#ifdef PRINT_INFO
	std::cout << "BoolTest_118" << std::endl;
#endif
	_passADB_129= &passADBs_121;
	_basictype_12a= &basictypes_122;
	_cs_12b= &css_123;
	_ue_12c= &ues_124;
	_passADB_12d= &passADBs_125;
	_basictype_12e= &basictypes_126;
	_cs_12f= &css_127;
	_ue_130= &ues_128;
	for( Packets_t::const_iterator itpassADB_132= passADBs_119.begin(), itbasictype_139= basictypes_11b.begin(), itcs_140= css_11d.begin(), itue_147= ues_11f.begin(); itpassADB_132!= passADBs_119.end(), itbasictype_139!= basictypes_11b.end(), itcs_140!= css_11d.end(), itue_147!= ues_11f.end(); ++itpassADB_132, ++itbasictype_139, ++itcs_140, ++itue_147)
	{
		bool isUnique= isInputUnique( *itpassADB_132, *itbasictype_139, *itcs_140, *itue_147);
		if( !isUnique)
			continue;
		Packets_t onepassADB_136( 1, *itpassADB_132);
		Packets_t onebasictype_13d( 1, *itbasictype_139);
		Packets_t onecs_144( 1, *itcs_140);
		Packets_t oneue_14b( 1, *itue_147);
		executeOne( onepassADB_136, onebasictype_13d, onecs_144, oneue_14b);
	}
}

void BoolTest_118::executeOne( const Packets_t& passADBs_119, const Packets_t& basictypes_11b, const Packets_t& css_11d, const Packets_t& ues_11f)
{
	Packets_t argDeclBases_150;
	Packets_t basicTypes_153;
	Packets_t compoundStatements_156;
	Packets_t unaryExprss_159;
	IsBool_14d isBool_14d;
	bool isMatchIsBool_14d= isBool_14d( passADBs_119, basictypes_11b, css_11d, ues_11f, argDeclBases_150, basicTypes_153, compoundStatements_156, unaryExprss_159);
	_passADB_129->insert( _passADB_129->end(), argDeclBases_150.begin(), argDeclBases_150.end());
	_basictype_12a->insert( _basictype_12a->end(), basicTypes_153.begin(), basicTypes_153.end());
	_cs_12b->insert( _cs_12b->end(), compoundStatements_156.begin(), compoundStatements_156.end());
	_ue_12c->insert( _ue_12c->end(), unaryExprss_159.begin(), unaryExprss_159.end());
	if( isMatchIsBool_14d)
		return;
	Packets_t argDeclBases_199;
	Packets_t basicTypes_19c;
	Packets_t compoundStatements_19f;
	Packets_t unaryExprss_1a2;
	Otherwise_196 otherwise_196;
	bool isMatchOtherwise_196= otherwise_196( passADBs_119, basictypes_11b, css_11d, ues_11f, argDeclBases_199, basicTypes_19c, compoundStatements_19f, unaryExprss_1a2);
	_passADB_12d->insert( _passADB_12d->end(), argDeclBases_199.begin(), argDeclBases_199.end());
	_basictype_12e->insert( _basictype_12e->end(), basicTypes_19c.begin(), basicTypes_19c.end());
	_cs_12f->insert( _cs_12f->end(), compoundStatements_19f.begin(), compoundStatements_19f.end());
	_ue_130->insert( _ue_130->end(), unaryExprss_1a2.begin(), unaryExprss_1a2.end());
	if( isMatchOtherwise_196)
		return;
}

bool BoolTest_118::isInputUnique( const Udm::Object& passADB_133, const Udm::Object& basictype_13a, const Udm::Object& cs_141, const Udm::Object& ue_148)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_135= _passADB_131.begin(), itbasictype_13c= _basictype_138.begin(), itcs_143= _cs_13f.begin(), itue_14a= _ue_146.begin(); itpassADB_135!= _passADB_131.end(), itbasictype_13c!= _basictype_138.end(), itcs_143!= _cs_13f.end(), itue_14a!= _ue_146.end(); ++itpassADB_135, ++itbasictype_13c, ++itcs_143, ++itue_14a)
	{
		if( ( *itpassADB_135== passADB_133)&& ( *itbasictype_13c== basictype_13a)&& ( *itcs_143== cs_141)&& ( *itue_14a== ue_148))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_131.push_back( passADB_133);
		_basictype_138.push_back( basictype_13a);
		_cs_13f.push_back( cs_141);
		_ue_146.push_back( ue_148);
	}
	return isUnique;
}

bool IsBool_14d::operator()( const Packets_t& argDeclBases_14e, const Packets_t& basicTypes_151, const Packets_t& compoundStatements_154, const Packets_t& unaryExprss_157, Packets_t& argDeclBases_150, Packets_t& basicTypes_153, Packets_t& compoundStatements_156, Packets_t& unaryExprss_159)
{
#ifdef PRINT_INFO
	std::cout << "IsBool_14d" << std::endl;
#endif
	_argDeclBase_15a= &argDeclBases_150;
	_basicType_15b= &basicTypes_153;
	_compoundStatement_15c= &compoundStatements_156;
	_unaryExprs_15d= &unaryExprss_159;
	processInputPackets( argDeclBases_14e, basicTypes_151, compoundStatements_154, unaryExprss_157);
	if( false== _matches.empty())
		return true;
	return false;
}

bool IsBool_14d::isInputUnique( const Udm::Object& argDeclBase_162, const Udm::Object& basicType_16b, const Udm::Object& compoundStatement_174, const Udm::Object& unaryExprs_17d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_164= _argDeclBase_15e.begin(), itBasicType_16d= _basicType_167.begin(), itCompoundStatement_176= _compoundStatement_170.begin(), itUnaryExprs_17f= _unaryExprs_179.begin(); itArgDeclBase_164!= _argDeclBase_15e.end(), itBasicType_16d!= _basicType_167.end(), itCompoundStatement_176!= _compoundStatement_170.end(), itUnaryExprs_17f!= _unaryExprs_179.end(); ++itArgDeclBase_164, ++itBasicType_16d, ++itCompoundStatement_176, ++itUnaryExprs_17f)
	{
		if( ( *itArgDeclBase_164== argDeclBase_162)&& ( *itBasicType_16d== basicType_16b)&& ( *itCompoundStatement_176== compoundStatement_174)&& ( *itUnaryExprs_17f== unaryExprs_17d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_15e.push_back( argDeclBase_162);
		_basicType_167.push_back( basicType_16b);
		_compoundStatement_170.push_back( compoundStatement_174);
		_unaryExprs_179.push_back( unaryExprs_17d);
	}
	return isUnique;
}

bool IsBool_14d::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

bool IsBool_14d::isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::BasicType& BasicType, SFC::CompoundStatement& CompoundStatement, SFC::UnaryExprs& UnaryExprs)
{
	bool Gz_guard= false;
	std::string sub4 = static_cast< std::string >( BasicType.name() ).substr( 0, 4 );
return sub4 == "bool" || sub4 == "Bool";;
	return Gz_guard;
}

void IsBool_14d::processInputPackets( const Packets_t& argDeclBases_14e, const Packets_t& basicTypes_151, const Packets_t& compoundStatements_154, const Packets_t& unaryExprss_157)
{
	for( Packets_t::const_iterator itArgDeclBase_15f= argDeclBases_14e.begin(), itBasicType_168= basicTypes_151.begin(), itCompoundStatement_171= compoundStatements_154.begin(), itUnaryExprs_17a= unaryExprss_157.begin(); itArgDeclBase_15f!= argDeclBases_14e.end(), itBasicType_168!= basicTypes_151.end(), itCompoundStatement_171!= compoundStatements_154.end(), itUnaryExprs_17a!= unaryExprss_157.end(); ++itArgDeclBase_15f, ++itBasicType_168, ++itCompoundStatement_171, ++itUnaryExprs_17a)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_15f, *itBasicType_168, *itCompoundStatement_171, *itUnaryExprs_17a);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_15f, *itBasicType_168, *itCompoundStatement_171, *itUnaryExprs_17a);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_186, currMatch.basicType_187, currMatch.compoundStatement_188, currMatch.unaryExprs_189);
	}
}

bool IsBool_14d::patternMatcher( const Udm::Object& argDeclBase_160, const Udm::Object& basicType_169, const Udm::Object& compoundStatement_172, const Udm::Object& unaryExprs_17b)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_160.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_165= SFC::ArgDeclBase::Cast( argDeclBase_160);
		if( false== Uml::IsDerivedFrom( basicType_169.type(), SFC::BasicType::meta))
			continue;
		SFC::BasicType basicType_16e= SFC::BasicType::Cast( basicType_169);
		if( false== Uml::IsDerivedFrom( compoundStatement_172.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_177= SFC::CompoundStatement::Cast( compoundStatement_172);
		if( false== Uml::IsDerivedFrom( unaryExprs_17b.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_180= SFC::UnaryExprs::Cast( unaryExprs_17b);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_185;
		if( !isValidBound(boundObjs_185, argDeclBase_165, true))
			continue;
		currMatch.argDeclBase_186= argDeclBase_165;
		if( !isValidBound(boundObjs_185, basicType_16e, true))
			continue;
		currMatch.basicType_187= basicType_16e;
		if( !isValidBound(boundObjs_185, compoundStatement_177, true))
			continue;
		currMatch.compoundStatement_188= compoundStatement_177;
		if( !isValidBound(boundObjs_185, unaryExprs_180, true))
			continue;
		currMatch.unaryExprs_189= unaryExprs_180;
		bool Gz_guard= isGuardTrue( currMatch.argDeclBase_186, currMatch.basicType_187, currMatch.compoundStatement_188, currMatch.unaryExprs_189);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void IsBool_14d::outputAppender( const SFC::ArgDeclBase& argDeclBase_18e, const SFC::BasicType& basicType_190, const SFC::CompoundStatement& compoundStatement_192, const SFC::UnaryExprs& unaryExprs_194)
{
	_argDeclBase_15a->push_back( argDeclBase_18e);
	_basicType_15b->push_back( basicType_190);
	_compoundStatement_15c->push_back( compoundStatement_192);
	_unaryExprs_15d->push_back( unaryExprs_194);
}

bool Otherwise_196::operator()( const Packets_t& argDeclBases_197, const Packets_t& basicTypes_19a, const Packets_t& compoundStatements_19d, const Packets_t& unaryExprss_1a0, Packets_t& argDeclBases_199, Packets_t& basicTypes_19c, Packets_t& compoundStatements_19f, Packets_t& unaryExprss_1a2)
{
#ifdef PRINT_INFO
	std::cout << "Otherwise_196" << std::endl;
#endif
	_argDeclBase_1a3= &argDeclBases_199;
	_basicType_1a4= &basicTypes_19c;
	_compoundStatement_1a5= &compoundStatements_19f;
	_unaryExprs_1a6= &unaryExprss_1a2;
	processInputPackets( argDeclBases_197, basicTypes_19a, compoundStatements_19d, unaryExprss_1a0);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Otherwise_196::isInputUnique( const Udm::Object& argDeclBase_1ab, const Udm::Object& basicType_1b4, const Udm::Object& compoundStatement_1bd, const Udm::Object& unaryExprs_1c6)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_1ad= _argDeclBase_1a7.begin(), itBasicType_1b6= _basicType_1b0.begin(), itCompoundStatement_1bf= _compoundStatement_1b9.begin(), itUnaryExprs_1c8= _unaryExprs_1c2.begin(); itArgDeclBase_1ad!= _argDeclBase_1a7.end(), itBasicType_1b6!= _basicType_1b0.end(), itCompoundStatement_1bf!= _compoundStatement_1b9.end(), itUnaryExprs_1c8!= _unaryExprs_1c2.end(); ++itArgDeclBase_1ad, ++itBasicType_1b6, ++itCompoundStatement_1bf, ++itUnaryExprs_1c8)
	{
		if( ( *itArgDeclBase_1ad== argDeclBase_1ab)&& ( *itBasicType_1b6== basicType_1b4)&& ( *itCompoundStatement_1bf== compoundStatement_1bd)&& ( *itUnaryExprs_1c8== unaryExprs_1c6))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_1a7.push_back( argDeclBase_1ab);
		_basicType_1b0.push_back( basicType_1b4);
		_compoundStatement_1b9.push_back( compoundStatement_1bd);
		_unaryExprs_1c2.push_back( unaryExprs_1c6);
	}
	return isUnique;
}

bool Otherwise_196::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void Otherwise_196::processInputPackets( const Packets_t& argDeclBases_197, const Packets_t& basicTypes_19a, const Packets_t& compoundStatements_19d, const Packets_t& unaryExprss_1a0)
{
	for( Packets_t::const_iterator itArgDeclBase_1a8= argDeclBases_197.begin(), itBasicType_1b1= basicTypes_19a.begin(), itCompoundStatement_1ba= compoundStatements_19d.begin(), itUnaryExprs_1c3= unaryExprss_1a0.begin(); itArgDeclBase_1a8!= argDeclBases_197.end(), itBasicType_1b1!= basicTypes_19a.end(), itCompoundStatement_1ba!= compoundStatements_19d.end(), itUnaryExprs_1c3!= unaryExprss_1a0.end(); ++itArgDeclBase_1a8, ++itBasicType_1b1, ++itCompoundStatement_1ba, ++itUnaryExprs_1c3)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_1a8, *itBasicType_1b1, *itCompoundStatement_1ba, *itUnaryExprs_1c3);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_1a8, *itBasicType_1b1, *itCompoundStatement_1ba, *itUnaryExprs_1c3);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_1cf, currMatch.basicType_1d0, currMatch.compoundStatement_1d1, currMatch.unaryExprs_1d2);
	}
}

bool Otherwise_196::patternMatcher( const Udm::Object& argDeclBase_1a9, const Udm::Object& basicType_1b2, const Udm::Object& compoundStatement_1bb, const Udm::Object& unaryExprs_1c4)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_1a9.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_1ae= SFC::ArgDeclBase::Cast( argDeclBase_1a9);
		if( false== Uml::IsDerivedFrom( basicType_1b2.type(), SFC::BasicType::meta))
			continue;
		SFC::BasicType basicType_1b7= SFC::BasicType::Cast( basicType_1b2);
		if( false== Uml::IsDerivedFrom( compoundStatement_1bb.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_1c0= SFC::CompoundStatement::Cast( compoundStatement_1bb);
		if( false== Uml::IsDerivedFrom( unaryExprs_1c4.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_1c9= SFC::UnaryExprs::Cast( unaryExprs_1c4);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_1ce;
		if( !isValidBound(boundObjs_1ce, argDeclBase_1ae, true))
			continue;
		currMatch.argDeclBase_1cf= argDeclBase_1ae;
		if( !isValidBound(boundObjs_1ce, basicType_1b7, true))
			continue;
		currMatch.basicType_1d0= basicType_1b7;
		if( !isValidBound(boundObjs_1ce, compoundStatement_1c0, true))
			continue;
		currMatch.compoundStatement_1d1= compoundStatement_1c0;
		if( !isValidBound(boundObjs_1ce, unaryExprs_1c9, true))
			continue;
		currMatch.unaryExprs_1d2= unaryExprs_1c9;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Otherwise_196::outputAppender( const SFC::ArgDeclBase& argDeclBase_1d3, const SFC::BasicType& basicType_1d5, const SFC::CompoundStatement& compoundStatement_1d7, const SFC::UnaryExprs& unaryExprs_1d9)
{
	_argDeclBase_1a3->push_back( argDeclBase_1d3);
	_basicType_1a4->push_back( basicType_1d5);
	_compoundStatement_1a5->push_back( compoundStatement_1d7);
	_unaryExprs_1a6->push_back( unaryExprs_1d9);
}

void BreakPath_1db::operator()( const Packets_t& passADBs_1dc, const Packets_t& structs_1de, const Packets_t& css_1e0, const Packets_t& ues_1e2, Packets_t& passADBs_1e4, Packets_t& css_1e5, Packets_t& ues_1e6)
{
#ifdef PRINT_INFO
	std::cout << "BreakPath_1db" << std::endl;
#endif
	_passADB_1e7= &passADBs_1e4;
	_cs_1e8= &css_1e5;
	_ue_1e9= &ues_1e6;
	for( Packets_t::const_iterator itpassADB_1eb= passADBs_1dc.begin(), itstruct_1f2= structs_1de.begin(), itcs_1f9= css_1e0.begin(), itue_200= ues_1e2.begin(); itpassADB_1eb!= passADBs_1dc.end(), itstruct_1f2!= structs_1de.end(), itcs_1f9!= css_1e0.end(), itue_200!= ues_1e2.end(); ++itpassADB_1eb, ++itstruct_1f2, ++itcs_1f9, ++itue_200)
	{
		bool isUnique= isInputUnique( *itpassADB_1eb, *itstruct_1f2, *itcs_1f9, *itue_200);
		if( !isUnique)
			continue;
		Packets_t onepassADB_1ef( 1, *itpassADB_1eb);
		Packets_t onestruct_1f6( 1, *itstruct_1f2);
		Packets_t onecs_1fd( 1, *itcs_1f9);
		Packets_t oneue_204( 1, *itue_200);
		executeOne( onepassADB_1ef, onestruct_1f6, onecs_1fd, oneue_204);
	}
}

void BreakPath_1db::executeOne( const Packets_t& passADBs_1dc, const Packets_t& structs_1de, const Packets_t& css_1e0, const Packets_t& ues_1e2)
{
	if( ( !passADBs_1dc.empty())&& ( !structs_1de.empty()))
		callBreak_226( passADBs_1dc, structs_1de);
	_passADB_1e7->insert( _passADB_1e7->end(), passADBs_1dc.begin(), passADBs_1dc.end());
	_cs_1e8->insert( _cs_1e8->end(), css_1e0.begin(), css_1e0.end());
	_ue_1e9->insert( _ue_1e9->end(), ues_1e2.begin(), ues_1e2.end());
}

bool BreakPath_1db::isInputUnique( const Udm::Object& passADB_1ec, const Udm::Object& struct_1f3, const Udm::Object& cs_1fa, const Udm::Object& ue_201)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_1ee= _passADB_1ea.begin(), itstruct_1f5= _struct_1f1.begin(), itcs_1fc= _cs_1f8.begin(), itue_203= _ue_1ff.begin(); itpassADB_1ee!= _passADB_1ea.end(), itstruct_1f5!= _struct_1f1.end(), itcs_1fc!= _cs_1f8.end(), itue_203!= _ue_1ff.end(); ++itpassADB_1ee, ++itstruct_1f5, ++itcs_1fc, ++itue_203)
	{
		if( ( *itpassADB_1ee== passADB_1ec)&& ( *itstruct_1f5== struct_1f3)&& ( *itcs_1fc== cs_1fa)&& ( *itue_203== ue_201))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_1ea.push_back( passADB_1ec);
		_struct_1f1.push_back( struct_1f3);
		_cs_1f8.push_back( cs_1fa);
		_ue_1ff.push_back( ue_201);
	}
	return isUnique;
}

void BreakPath_1db::callBreak_226( const Packets_t& argDeclBases_207, const Packets_t& structs_209)
{
	Break_206 break_206;
	break_206( argDeclBases_207, structs_209);
}

void Break_206::operator()( const Packets_t& argDeclBases_207, const Packets_t& structs_209)
{
#ifdef PRINT_INFO
	std::cout << "Break_206" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(109, "Break");
	processInputPackets( argDeclBases_207, structs_209);
}

bool Break_206::isInputUnique( const Udm::Object& argDeclBase_20f, const Udm::Object& struct_218)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_211= _argDeclBase_20b.begin(), itStruct_21a= _struct_214.begin(); itArgDeclBase_211!= _argDeclBase_20b.end(), itStruct_21a!= _struct_214.end(); ++itArgDeclBase_211, ++itStruct_21a)
	{
		if( ( *itArgDeclBase_211== argDeclBase_20f)&& ( *itStruct_21a== struct_218))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_20b.push_back( argDeclBase_20f);
		_struct_214.push_back( struct_218);
	}
	return isUnique;
}

bool Break_206::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void Break_206::processInputPackets( const Packets_t& argDeclBases_207, const Packets_t& structs_209)
{
	for( Packets_t::const_iterator itArgDeclBase_20c= argDeclBases_207.begin(), itStruct_215= structs_209.begin(); itArgDeclBase_20c!= argDeclBases_207.end(), itStruct_215!= structs_209.end(); ++itArgDeclBase_20c, ++itStruct_215)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_20c, *itStruct_215);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_20c, *itStruct_215);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool Break_206::patternMatcher( const Udm::Object& argDeclBase_20d, const Udm::Object& struct_216)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_20d.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_212= SFC::ArgDeclBase::Cast( argDeclBase_20d);
		if( false== Uml::IsDerivedFrom( struct_216.type(), SFC::Struct::meta))
			continue;
		SFC::Struct struct_21b= SFC::Struct::Cast( struct_216);
		set< SFC::Struct> structs_21d= argDeclBase_212.strctpath();
		for( set< SFC::Struct>::const_iterator itStructs_21e= structs_21d.begin(); itStructs_21e!= structs_21d.end(); ++itStructs_21e)
		{
			SFC::Struct currStruct_21f= *itStructs_21e;
			if( struct_21b!= currStruct_21f)
				continue;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_223;
			if( !isValidBound(boundObjs_223, argDeclBase_212, true))
				continue;
			currMatch.argDeclBase_224= argDeclBase_212;
			if( !isValidBound(boundObjs_223, struct_21b, true))
				continue;
			currMatch.struct_225= struct_21b;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void Break_206::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		currMatch.argDeclBase_224.strctpath()-= currMatch.struct_225;
	}
}

void ProcessStruct_229::operator()( const Packets_t& structs_22b, const Packets_t& mains_22d, Packets_t& localVars_22a, Packets_t& mains_22f)
{
#ifdef PRINT_INFO
	std::cout << "ProcessStruct_229" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(113, "ProcessStruct");
	_localVar_230= &localVars_22a;
	_main_231= &mains_22f;
	processInputPackets( structs_22b, mains_22d);
	sortOutputs( );
}

bool ProcessStruct_229::isInputUnique( const Udm::Object& struct_236, const Udm::Object& main_23f)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itStruct_238= _struct_232.begin(), itMain_241= _main_23b.begin(); itStruct_238!= _struct_232.end(), itMain_241!= _main_23b.end(); ++itStruct_238, ++itMain_241)
	{
		if( ( *itStruct_238== struct_236)&& ( *itMain_241== main_23f))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_struct_232.push_back( struct_236);
		_main_23b.push_back( main_23f);
	}
	return isUnique;
}

void ProcessStruct_229::processInputPackets( const Packets_t& structs_22b, const Packets_t& mains_22d)
{
	for( Packets_t::const_iterator itStruct_233= structs_22b.begin(), itMain_23c= mains_22d.begin(); itStruct_233!= structs_22b.end(), itMain_23c!= mains_22d.end(); ++itStruct_233, ++itMain_23c)
	{
		bool isUnique= isInputUnique( *itStruct_233, *itMain_23c);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itStruct_233, *itMain_23c);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool ProcessStruct_229::patternMatcher( const Udm::Object& struct_234, const Udm::Object& main_23d)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( struct_234.type(), SFC::Struct::meta))
			continue;
		SFC::Struct struct_239= SFC::Struct::Cast( struct_234);
		if( false== Uml::IsDerivedFrom( main_23d.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_242= SFC::CompoundStatement::Cast( main_23d);
		set< SFC::LocalVar> localVars_244= struct_239.LocalVar_kind_children();
		for( set< SFC::LocalVar>::const_iterator itLocalVar_245= localVars_244.begin(); itLocalVar_245!= localVars_244.end(); ++itLocalVar_245)
		{
			SFC::LocalVar currLocalVar_246= *itLocalVar_245;
			Match currMatch;
			currMatch.struct_248= struct_239;
			currMatch.main_249= main_242;
			currMatch.localVar_24a= currLocalVar_246;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void ProcessStruct_229::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.localVar_24a, currMatch.main_249);
	}
}

void ProcessStruct_229::outputAppender( const SFC::LocalVar& localVar_24b, const SFC::CompoundStatement& main_24d)
{
	_localVar_230->push_back( localVar_24b);
	_main_231->push_back( main_24d);
}

void ProcessStruct_229::sortOutputs()
{
	typedef std::multiset< SFC::LocalVar, std::pointer_to_binary_function< const SFC::LocalVar&, const SFC::LocalVar&, bool> > SortedSet_t;
	std::pointer_to_binary_function< const SFC::LocalVar&, const SFC::LocalVar&, bool> ptr_StatementOrder( StatementOrder< SFC::LocalVar>);
	SortedSet_t sortedSet( ptr_StatementOrder);
	std::vector< int> permutationVector( _localVar_230->size());
	int currStep= 0;
	for( Packets_t::const_iterator it= _localVar_230->begin(); it!= _localVar_230->end(); ++it, ++currStep)
	{
		SortedSet_t::const_iterator inserted= sortedSet.insert( SFC::LocalVar::Cast(*it));
		SortedSet_t::difference_type pos= std::distance( SortedSet_t::const_iterator( sortedSet.begin()), inserted);
		permutationVector[ currStep]=  pos;
		for( int i= 0; i< currStep; ++i)
		{
			if( permutationVector[ i] >= pos)
				++permutationVector[ i];
		}
	}
	// order the primary container
	std::copy( sortedSet.begin(), sortedSet.end(), _localVar_230->begin());
	// order rest of the containers
	permutate( permutationVector, *_main_231);
}

void StructExprs_24f::operator()( const Packets_t& localVars_252, const Packets_t& compoundStatements_254, const Packets_t& unaryExprss_257, Packets_t& argDeclBases_250, Packets_t& structs_251, Packets_t& compoundStatements_256, Packets_t& newUnaryExprss_259)
{
#ifdef PRINT_INFO
	std::cout << "StructExprs_24f" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(118, "StructExprs");
	_argDeclBase_25a= &argDeclBases_250;
	_struct_25b= &structs_251;
	_compoundStatement_25c= &compoundStatements_256;
	_newUnaryExprs_25d= &newUnaryExprss_259;
	processInputPackets( localVars_252, compoundStatements_254, unaryExprss_257);
}

bool StructExprs_24f::isInputUnique( const Udm::Object& localVar_262, const Udm::Object& compoundStatement_26b, const Udm::Object& unaryExprs_274)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itLocalVar_264= _localVar_25e.begin(), itCompoundStatement_26d= _compoundStatement_267.begin(), itUnaryExprs_276= _unaryExprs_270.begin(); itLocalVar_264!= _localVar_25e.end(), itCompoundStatement_26d!= _compoundStatement_267.end(), itUnaryExprs_276!= _unaryExprs_270.end(); ++itLocalVar_264, ++itCompoundStatement_26d, ++itUnaryExprs_276)
	{
		if( ( *itLocalVar_264== localVar_262)&& ( *itCompoundStatement_26d== compoundStatement_26b)&& ( *itUnaryExprs_276== unaryExprs_274))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_localVar_25e.push_back( localVar_262);
		_compoundStatement_267.push_back( compoundStatement_26b);
		_unaryExprs_270.push_back( unaryExprs_274);
	}
	return isUnique;
}

void StructExprs_24f::processInputPackets( const Packets_t& localVars_252, const Packets_t& compoundStatements_254, const Packets_t& unaryExprss_257)
{
	for( Packets_t::const_iterator itLocalVar_25f= localVars_252.begin(), itCompoundStatement_268= compoundStatements_254.begin(), itUnaryExprs_271= unaryExprss_257.begin(); itLocalVar_25f!= localVars_252.end(), itCompoundStatement_268!= compoundStatements_254.end(), itUnaryExprs_271!= unaryExprss_257.end(); ++itLocalVar_25f, ++itCompoundStatement_268, ++itUnaryExprs_271)
	{
		bool isUnique= isInputUnique( *itLocalVar_25f, *itCompoundStatement_268, *itUnaryExprs_271);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itLocalVar_25f, *itCompoundStatement_268, *itUnaryExprs_271);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool StructExprs_24f::patternMatcher( const Udm::Object& localVar_260, const Udm::Object& compoundStatement_269, const Udm::Object& unaryExprs_272)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( localVar_260.type(), SFC::LocalVar::meta))
			continue;
		SFC::LocalVar localVar_265= SFC::LocalVar::Cast( localVar_260);
		if( false== Uml::IsDerivedFrom( compoundStatement_269.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_26e= SFC::CompoundStatement::Cast( compoundStatement_269);
		if( false== Uml::IsDerivedFrom( unaryExprs_272.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_277= SFC::UnaryExprs::Cast( unaryExprs_272);
		Udm::Object localVarParent_279= localVar_265.container();
		if( false== Uml::IsDerivedFrom( localVarParent_279.type(), SFC::Struct::meta))
			continue;
		SFC::Struct structLocalVar_27a= SFC::Struct::Cast( localVarParent_279);
		SFC::ArgDeclBase argDeclBase_27b= structLocalVar_27a.adbpath();
		if( !argDeclBase_27b)
			continue;
		Match currMatch;
		currMatch.localVar_27d= localVar_265;
		currMatch.compoundStatement_27e= compoundStatement_26e;
		currMatch.unaryExprs_27f= unaryExprs_277;
		currMatch.argDeclBase_280= argDeclBase_27b;
		currMatch.struct_281= structLocalVar_27a;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void StructExprs_24f::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::BinaryExprs newBinaryExprs_282= SFC::BinaryExprs::Create( currMatch.unaryExprs_27f, SFC::UnaryExprs::meta_subexpr);
		SFC::ArgDeclRef newArgDeclRef_283= SFC::ArgDeclRef::Create( newBinaryExprs_282, SFC::BinaryExprs::meta_rightexpr);
		SFC::UnaryExprs newNewUnaryExprs_284= SFC::UnaryExprs::Create( newBinaryExprs_282, SFC::BinaryExprs::meta_leftexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_280;
		SFC::ArgDeclRef& ArgDeclRef= newArgDeclRef_283;
		SFC::BinaryExprs& BinaryExprs= newBinaryExprs_282;
		SFC::CompoundStatement& CompoundStatement= currMatch.compoundStatement_27e;
		SFC::LocalVar& LocalVar= currMatch.localVar_27d;
		SFC::UnaryExprs& NewUnaryExprs= newNewUnaryExprs_284;
		SFC::Struct& Struct= currMatch.struct_281;
		SFC::UnaryExprs& UnaryExprs= currMatch.unaryExprs_27f;
		{
BinaryExprs.op() = ".";
};
		newArgDeclRef_283.argdecl()= currMatch.localVar_27d;
		outputAppender( currMatch.argDeclBase_280, currMatch.struct_281, currMatch.compoundStatement_27e, newNewUnaryExprs_284);
	}
}

void StructExprs_24f::outputAppender( const SFC::ArgDeclBase& argDeclBase_285, const SFC::Struct& struct_287, const SFC::CompoundStatement& compoundStatement_289, const SFC::UnaryExprs& newUnaryExprs_28b)
{
	_argDeclBase_25a->push_back( argDeclBase_285);
	_struct_25b->push_back( struct_287);
	_compoundStatement_25c->push_back( compoundStatement_289);
	_newUnaryExprs_25d->push_back( newUnaryExprs_28b);
}

void AddIndexes_28d::operator()( const Packets_t& passADBs_28e, const Packets_t& passCSs_290, const Packets_t& ues_292, Packets_t& passADBs_294, Packets_t& passCSs_295, Packets_t& ues_296)
{
#ifdef PRINT_INFO
	std::cout << "AddIndexes_28d" << std::endl;
#endif
	_passADB_297= &passADBs_294;
	_passCS_298= &passCSs_295;
	_ue_299= &ues_296;
	for( Packets_t::const_iterator itpassADB_29b= passADBs_28e.begin(), itpassCS_2a2= passCSs_290.begin(), itue_2a9= ues_292.begin(); itpassADB_29b!= passADBs_28e.end(), itpassCS_2a2!= passCSs_290.end(), itue_2a9!= ues_292.end(); ++itpassADB_29b, ++itpassCS_2a2, ++itue_2a9)
	{
		bool isUnique= isInputUnique( *itpassADB_29b, *itpassCS_2a2, *itue_2a9);
		if( !isUnique)
			continue;
		Packets_t onepassADB_29f( 1, *itpassADB_29b);
		Packets_t onepassCS_2a6( 1, *itpassCS_2a2);
		Packets_t oneue_2ad( 1, *itue_2a9);
		executeOne( onepassADB_29f, onepassCS_2a6, oneue_2ad);
	}
}

void AddIndexes_28d::executeOne( const Packets_t& passADBs_28e, const Packets_t& passCSs_290, const Packets_t& ues_292)
{
	if( ( !passADBs_28e.empty())&& ( !passCSs_290.empty())&& ( !ues_292.empty()))
		callGetStartLoop_70c( passADBs_28e, passCSs_290, ues_292);
}

bool AddIndexes_28d::isInputUnique( const Udm::Object& passADB_29c, const Udm::Object& passCS_2a3, const Udm::Object& ue_2aa)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_29e= _passADB_29a.begin(), itpassCS_2a5= _passCS_2a1.begin(), itue_2ac= _ue_2a8.begin(); itpassADB_29e!= _passADB_29a.end(), itpassCS_2a5!= _passCS_2a1.end(), itue_2ac!= _ue_2a8.end(); ++itpassADB_29e, ++itpassCS_2a5, ++itue_2ac)
	{
		if( ( *itpassADB_29e== passADB_29c)&& ( *itpassCS_2a5== passCS_2a3)&& ( *itue_2ac== ue_2aa))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_29a.push_back( passADB_29c);
		_passCS_2a1.push_back( passCS_2a3);
		_ue_2a8.push_back( ue_2aa);
	}
	return isUnique;
}

void AddIndexes_28d::callGetStartLoop_70c( const Packets_t& passADBs_55c, const Packets_t& passCSs_55e, const Packets_t& ues_560)
{
	Packets_t passADBs_562;
	Packets_t arrays_563;
	Packets_t lastibs_564;
	Packets_t passCSs_565;
	Packets_t ues_566;
	GetStartLoop_55b getStartLoop_55b;
	getStartLoop_55b( passADBs_55c, passCSs_55e, ues_560, passADBs_562, arrays_563, lastibs_564, passCSs_565, ues_566);
	if( ( !passADBs_562.empty())&& ( !arrays_563.empty())&& ( !lastibs_564.empty())&& ( !passCSs_565.empty())&& ( !ues_566.empty()))
		callAddIndexes_710( passADBs_562, arrays_563, lastibs_564, passCSs_565, ues_566);
}

void AddIndexes_28d::callAddIndexes_710( const Packets_t& passADBs_2b0, const Packets_t& arrays_2b2, const Packets_t& lastibs_2b4, const Packets_t& passCSs_2b6, const Packets_t& ues_2b8)
{
	Packets_t passADBs_2ba;
	Packets_t passCSs_2bb;
	Packets_t ues_2bc;
	AddIndexes_2af addIndexes_2af;
	addIndexes_2af( passADBs_2b0, arrays_2b2, lastibs_2b4, passCSs_2b6, ues_2b8, passADBs_2ba, passCSs_2bb, ues_2bc);
	_passADB_297->insert( _passADB_297->end(), passADBs_2ba.begin(), passADBs_2ba.end());
	_passCS_298->insert( _passCS_298->end(), passCSs_2bb.begin(), passCSs_2bb.end());
	_ue_299->insert( _ue_299->end(), ues_2bc.begin(), ues_2bc.end());
}

void AddIndexes_2af::operator()( const Packets_t& passADBs_2b0, const Packets_t& arrays_2b2, const Packets_t& lastibs_2b4, const Packets_t& passCSs_2b6, const Packets_t& ues_2b8, Packets_t& passADBs_2ba, Packets_t& passCSs_2bb, Packets_t& ues_2bc)
{
#ifdef PRINT_INFO
	std::cout << "AddIndexes_2af" << std::endl;
#endif
	_passADB_2bd= &passADBs_2ba;
	_passCS_2be= &passCSs_2bb;
	_ue_2bf= &ues_2bc;
	for( Packets_t::const_iterator itpassADB_2c1= passADBs_2b0.begin(), itarray_2c8= arrays_2b2.begin(), itlastib_2cf= lastibs_2b4.begin(), itpassCS_2d6= passCSs_2b6.begin(), itue_2dd= ues_2b8.begin(); itpassADB_2c1!= passADBs_2b0.end(), itarray_2c8!= arrays_2b2.end(), itlastib_2cf!= lastibs_2b4.end(), itpassCS_2d6!= passCSs_2b6.end(), itue_2dd!= ues_2b8.end(); ++itpassADB_2c1, ++itarray_2c8, ++itlastib_2cf, ++itpassCS_2d6, ++itue_2dd)
	{
		bool isUnique= isInputUnique( *itpassADB_2c1, *itarray_2c8, *itlastib_2cf, *itpassCS_2d6, *itue_2dd);
		if( !isUnique)
			continue;
		Packets_t onepassADB_2c5( 1, *itpassADB_2c1);
		Packets_t onearray_2cc( 1, *itarray_2c8);
		Packets_t onelastib_2d3( 1, *itlastib_2cf);
		Packets_t onepassCS_2da( 1, *itpassCS_2d6);
		Packets_t oneue_2e1( 1, *itue_2dd);
		executeOne( onepassADB_2c5, onearray_2cc, onelastib_2d3, onepassCS_2da, oneue_2e1);
	}
}

void AddIndexes_2af::executeOne( const Packets_t& passADBs_2b0, const Packets_t& arrays_2b2, const Packets_t& lastibs_2b4, const Packets_t& passCSs_2b6, const Packets_t& ues_2b8)
{
	if( ( !passADBs_2b0.empty())&& ( !arrays_2b2.empty())&& ( !lastibs_2b4.empty())&& ( !passCSs_2b6.empty())&& ( !ues_2b8.empty()))
		callAddFirstIndex_543( passADBs_2b0, arrays_2b2, lastibs_2b4, passCSs_2b6, ues_2b8);
}

bool AddIndexes_2af::isInputUnique( const Udm::Object& passADB_2c2, const Udm::Object& array_2c9, const Udm::Object& lastib_2d0, const Udm::Object& passCS_2d7, const Udm::Object& ue_2de)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_2c4= _passADB_2c0.begin(), itarray_2cb= _array_2c7.begin(), itlastib_2d2= _lastib_2ce.begin(), itpassCS_2d9= _passCS_2d5.begin(), itue_2e0= _ue_2dc.begin(); itpassADB_2c4!= _passADB_2c0.end(), itarray_2cb!= _array_2c7.end(), itlastib_2d2!= _lastib_2ce.end(), itpassCS_2d9!= _passCS_2d5.end(), itue_2e0!= _ue_2dc.end(); ++itpassADB_2c4, ++itarray_2cb, ++itlastib_2d2, ++itpassCS_2d9, ++itue_2e0)
	{
		if( ( *itpassADB_2c4== passADB_2c2)&& ( *itarray_2cb== array_2c9)&& ( *itlastib_2d2== lastib_2d0)&& ( *itpassCS_2d9== passCS_2d7)&& ( *itue_2e0== ue_2de))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_2c0.push_back( passADB_2c2);
		_array_2c7.push_back( array_2c9);
		_lastib_2ce.push_back( lastib_2d0);
		_passCS_2d5.push_back( passCS_2d7);
		_ue_2dc.push_back( ue_2de);
	}
	return isUnique;
}

void AddIndexes_2af::callAddFirstIndex_543( const Packets_t& argDeclBases_2e4, const Packets_t& arrays_2e7, const Packets_t& iterativeBlocks_2ea, const Packets_t& compoundStatements_2ed, const Packets_t& unaryExprss_2f0)
{
	Packets_t argDeclBases_2e6;
	Packets_t dTs_2e9;
	Packets_t iterativeBlocks_2ec;
	Packets_t compoundStatements_2ef;
	Packets_t newUnaryExprss_2f2;
	AddFirstIndex_2e3 addFirstIndex_2e3;
	addFirstIndex_2e3( argDeclBases_2e4, arrays_2e7, iterativeBlocks_2ea, compoundStatements_2ed, unaryExprss_2f0, argDeclBases_2e6, dTs_2e9, iterativeBlocks_2ec, compoundStatements_2ef, newUnaryExprss_2f2);
	if( ( !argDeclBases_2e6.empty())&& ( !dTs_2e9.empty())&& ( !iterativeBlocks_2ec.empty())&& ( !compoundStatements_2ef.empty())&& ( !newUnaryExprss_2f2.empty()))
		callArrayTest_549( argDeclBases_2e6, dTs_2e9, iterativeBlocks_2ec, compoundStatements_2ef, newUnaryExprss_2f2);
}

void AddIndexes_2af::callArrayTest_549( const Packets_t& passADBs_3fd, const Packets_t& dts_3ff, const Packets_t& lastibs_401, const Packets_t& css_403, const Packets_t& ues_405)
{
	Packets_t passADBs_407;
	Packets_t arrays_408;
	Packets_t lastibs_409;
	Packets_t css_40a;
	Packets_t ues_40b;
	Packets_t passADBs_40c;
	Packets_t arrays_40d;
	Packets_t lastibs_40e;
	Packets_t css_40f;
	Packets_t ues_410;
	Packets_t passADBs_411;
	Packets_t arrays_412;
	Packets_t lastibs_413;
	Packets_t css_414;
	Packets_t ues_415;
	ArrayTest_3fc arrayTest_3fc;
	arrayTest_3fc( passADBs_3fd, dts_3ff, lastibs_401, css_403, ues_405, passADBs_407, arrays_408, lastibs_409, css_40a, ues_40b, passADBs_40c, arrays_40d, lastibs_40e, css_40f, ues_410, passADBs_411, arrays_412, lastibs_413, css_414, ues_415);
	_passADB_2bd->insert( _passADB_2bd->end(), passADBs_411.begin(), passADBs_411.end());
	_passCS_2be->insert( _passCS_2be->end(), css_414.begin(), css_414.end());
	_ue_2bf->insert( _ue_2bf->end(), ues_415.begin(), ues_415.end());
	if( ( !passADBs_40c.empty())&& ( !arrays_40d.empty())&& ( !lastibs_40e.empty())&& ( !css_40f.empty())&& ( !ues_410.empty()))
		callAddIndex_54f( passADBs_40c, arrays_40d, lastibs_40e, css_40f, ues_410);
	if( ( !passADBs_407.empty())&& ( !arrays_408.empty())&& ( !lastibs_409.empty())&& ( !css_40a.empty())&& ( !ues_40b.empty()))
		callSkipArray_555( passADBs_407, arrays_408, lastibs_409, css_40a, ues_40b);
}

void AddIndexes_2af::callAddIndex_54f( const Packets_t& argDeclBases_343, const Packets_t& arrays_346, const Packets_t& iterativeBlocks_349, const Packets_t& compoundStatements_34c, const Packets_t& unaryExprss_34f)
{
	Packets_t argDeclBases_345;
	Packets_t dTs_348;
	Packets_t lastIBs_34b;
	Packets_t compoundStatements_34e;
	Packets_t newUnaryExprss_351;
	AddIndex_342 addIndex_342;
	addIndex_342( argDeclBases_343, arrays_346, iterativeBlocks_349, compoundStatements_34c, unaryExprss_34f, argDeclBases_345, dTs_348, lastIBs_34b, compoundStatements_34e, newUnaryExprss_351);
	if( ( !argDeclBases_345.empty())&& ( !dTs_348.empty())&& ( !lastIBs_34b.empty())&& ( !compoundStatements_34e.empty())&& ( !newUnaryExprss_351.empty()))
		callArrayTest_549( argDeclBases_345, dTs_348, lastIBs_34b, compoundStatements_34e, newUnaryExprss_351);
}

void AddIndexes_2af::callSkipArray_555( const Packets_t& argDeclBases_3a6, const Packets_t& arrays_3a9, const Packets_t& iterativeBlocks_3ac, const Packets_t& compoundStatements_3af, const Packets_t& unaryExprss_3b2)
{
	Packets_t argDeclBases_3a8;
	Packets_t dTs_3ab;
	Packets_t iterativeBlocks_3ae;
	Packets_t compoundStatements_3b1;
	Packets_t unaryExprss_3b4;
	SkipArray_3a5 skipArray_3a5;
	skipArray_3a5( argDeclBases_3a6, arrays_3a9, iterativeBlocks_3ac, compoundStatements_3af, unaryExprss_3b2, argDeclBases_3a8, dTs_3ab, iterativeBlocks_3ae, compoundStatements_3b1, unaryExprss_3b4);
	if( ( !argDeclBases_3a8.empty())&& ( !dTs_3ab.empty())&& ( !iterativeBlocks_3ae.empty())&& ( !compoundStatements_3b1.empty())&& ( !unaryExprss_3b4.empty()))
		callArrayTest_549( argDeclBases_3a8, dTs_3ab, iterativeBlocks_3ae, compoundStatements_3b1, unaryExprss_3b4);
}

void AddFirstIndex_2e3::operator()( const Packets_t& argDeclBases_2e4, const Packets_t& arrays_2e7, const Packets_t& iterativeBlocks_2ea, const Packets_t& compoundStatements_2ed, const Packets_t& unaryExprss_2f0, Packets_t& argDeclBases_2e6, Packets_t& dTs_2e9, Packets_t& iterativeBlocks_2ec, Packets_t& compoundStatements_2ef, Packets_t& newUnaryExprss_2f2)
{
#ifdef PRINT_INFO
	std::cout << "AddFirstIndex_2e3" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(150, "AddFirstIndex");
	_argDeclBase_2f3= &argDeclBases_2e6;
	_dT_2f4= &dTs_2e9;
	_iterativeBlock_2f5= &iterativeBlocks_2ec;
	_compoundStatement_2f6= &compoundStatements_2ef;
	_newUnaryExprs_2f7= &newUnaryExprss_2f2;
	processInputPackets( argDeclBases_2e4, arrays_2e7, iterativeBlocks_2ea, compoundStatements_2ed, unaryExprss_2f0);
}

bool AddFirstIndex_2e3::isInputUnique( const Udm::Object& argDeclBase_2fc, const Udm::Object& array_305, const Udm::Object& iterativeBlock_30e, const Udm::Object& compoundStatement_317, const Udm::Object& unaryExprs_320)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_2fe= _argDeclBase_2f8.begin(), itArray_307= _array_301.begin(), itIterativeBlock_310= _iterativeBlock_30a.begin(), itCompoundStatement_319= _compoundStatement_313.begin(), itUnaryExprs_322= _unaryExprs_31c.begin(); itArgDeclBase_2fe!= _argDeclBase_2f8.end(), itArray_307!= _array_301.end(), itIterativeBlock_310!= _iterativeBlock_30a.end(), itCompoundStatement_319!= _compoundStatement_313.end(), itUnaryExprs_322!= _unaryExprs_31c.end(); ++itArgDeclBase_2fe, ++itArray_307, ++itIterativeBlock_310, ++itCompoundStatement_319, ++itUnaryExprs_322)
	{
		if( ( *itArgDeclBase_2fe== argDeclBase_2fc)&& ( *itArray_307== array_305)&& ( *itIterativeBlock_310== iterativeBlock_30e)&& ( *itCompoundStatement_319== compoundStatement_317)&& ( *itUnaryExprs_322== unaryExprs_320))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_2f8.push_back( argDeclBase_2fc);
		_array_301.push_back( array_305);
		_iterativeBlock_30a.push_back( iterativeBlock_30e);
		_compoundStatement_313.push_back( compoundStatement_317);
		_unaryExprs_31c.push_back( unaryExprs_320);
	}
	return isUnique;
}

bool AddFirstIndex_2e3::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void AddFirstIndex_2e3::processInputPackets( const Packets_t& argDeclBases_2e4, const Packets_t& arrays_2e7, const Packets_t& iterativeBlocks_2ea, const Packets_t& compoundStatements_2ed, const Packets_t& unaryExprss_2f0)
{
	for( Packets_t::const_iterator itArgDeclBase_2f9= argDeclBases_2e4.begin(), itArray_302= arrays_2e7.begin(), itIterativeBlock_30b= iterativeBlocks_2ea.begin(), itCompoundStatement_314= compoundStatements_2ed.begin(), itUnaryExprs_31d= unaryExprss_2f0.begin(); itArgDeclBase_2f9!= argDeclBases_2e4.end(), itArray_302!= arrays_2e7.end(), itIterativeBlock_30b!= iterativeBlocks_2ea.end(), itCompoundStatement_314!= compoundStatements_2ed.end(), itUnaryExprs_31d!= unaryExprss_2f0.end(); ++itArgDeclBase_2f9, ++itArray_302, ++itIterativeBlock_30b, ++itCompoundStatement_314, ++itUnaryExprs_31d)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_2f9, *itArray_302, *itIterativeBlock_30b, *itCompoundStatement_314, *itUnaryExprs_31d);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_2f9, *itArray_302, *itIterativeBlock_30b, *itCompoundStatement_314, *itUnaryExprs_31d);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool AddFirstIndex_2e3::patternMatcher( const Udm::Object& argDeclBase_2fa, const Udm::Object& array_303, const Udm::Object& iterativeBlock_30c, const Udm::Object& compoundStatement_315, const Udm::Object& unaryExprs_31e)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_2fa.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_2ff= SFC::ArgDeclBase::Cast( argDeclBase_2fa);
		if( false== Uml::IsDerivedFrom( array_303.type(), SFC::Array::meta))
			continue;
		SFC::Array array_308= SFC::Array::Cast( array_303);
		if( false== Uml::IsDerivedFrom( iterativeBlock_30c.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_311= SFC::IterativeBlock::Cast( iterativeBlock_30c);
		if( false== Uml::IsDerivedFrom( compoundStatement_315.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_31a= SFC::CompoundStatement::Cast( compoundStatement_315);
		if( false== Uml::IsDerivedFrom( unaryExprs_31e.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_323= SFC::UnaryExprs::Cast( unaryExprs_31e);
		SFC::LocalVar localVar_325= iterativeBlock_311.counter();
		if( !localVar_325)
			continue;
		SFC::DT dT_326= array_308.dt();
		if( !dT_326)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_32a;
		if( !isValidBound(boundObjs_32a, argDeclBase_2ff, true))
			continue;
		currMatch.argDeclBase_32b= argDeclBase_2ff;
		if( !isValidBound(boundObjs_32a, array_308, true))
			continue;
		currMatch.array_32c= array_308;
		if( !isValidBound(boundObjs_32a, iterativeBlock_311, true))
			continue;
		currMatch.iterativeBlock_32d= iterativeBlock_311;
		if( !isValidBound(boundObjs_32a, compoundStatement_31a, true))
			continue;
		currMatch.compoundStatement_32e= compoundStatement_31a;
		if( !isValidBound(boundObjs_32a, unaryExprs_323, true))
			continue;
		currMatch.unaryExprs_32f= unaryExprs_323;
		if( !isValidBound(boundObjs_32a, dT_326, false))
			continue;
		currMatch.dT_330= dT_326;
		if( !isValidBound(boundObjs_32a, localVar_325, false))
			continue;
		currMatch.localVar_331= localVar_325;
		_matches.push_back( currMatch);
		return true;
	}
	return !_matches.empty();
}

void AddFirstIndex_2e3::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::UserCode newUserCode_332= SFC::UserCode::Create( currMatch.iterativeBlock_32d, SFC::IterativeBlock::meta_stmnt);
		SFC::UnaryExprs newIncrement_333= SFC::UnaryExprs::Create( newUserCode_332, SFC::UserCode::meta_codeexpr);
		SFC::ArgDeclRef newArgDeclRef2_334= SFC::ArgDeclRef::Create( newIncrement_333, SFC::UnaryExprs::meta_subexpr);
		SFC::BinaryExprs newBinaryExprs_335= SFC::BinaryExprs::Create( currMatch.unaryExprs_32f, SFC::UnaryExprs::meta_subexpr);
		SFC::UnaryExprs newNewUnaryExprs_336= SFC::UnaryExprs::Create( newBinaryExprs_335, SFC::BinaryExprs::meta_leftexpr);
		SFC::ArgDeclRef newArgDeclRef1_337= SFC::ArgDeclRef::Create( newBinaryExprs_335, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_32b;
		SFC::ArgDeclRef& ArgDeclRef1= newArgDeclRef1_337;
		SFC::ArgDeclRef& ArgDeclRef2= newArgDeclRef2_334;
		SFC::Array& Array= currMatch.array_32c;
		SFC::BinaryExprs& BinaryExprs= newBinaryExprs_335;
		SFC::CompoundStatement& CompoundStatement= currMatch.compoundStatement_32e;
		SFC::DT& DT= currMatch.dT_330;
		SFC::UnaryExprs& Increment= newIncrement_333;
		SFC::IterativeBlock& IterativeBlock= currMatch.iterativeBlock_32d;
		SFC::LocalVar& LocalVar= currMatch.localVar_331;
		SFC::UnaryExprs& NewUnaryExprs= newNewUnaryExprs_336;
		SFC::UnaryExprs& UnaryExprs= currMatch.unaryExprs_32f;
		SFC::UserCode& UserCode= newUserCode_332;
		{
Increment.op() = "++";
};
		{
__int64 statementCount = IterativeBlock.statementCount();
UserCode.statementIndex() = statementCount++;
IterativeBlock.statementCount() = statementCount;
};
		{
BinaryExprs.op() = "[";
};
		newArgDeclRef2_334.argdecl()= currMatch.localVar_331;
		newArgDeclRef1_337.argdecl()= currMatch.localVar_331;
		outputAppender( currMatch.argDeclBase_32b, currMatch.dT_330, currMatch.iterativeBlock_32d, currMatch.compoundStatement_32e, newNewUnaryExprs_336);
	}
}

void AddFirstIndex_2e3::outputAppender( const SFC::ArgDeclBase& argDeclBase_338, const SFC::DT& dT_33a, const SFC::IterativeBlock& iterativeBlock_33c, const SFC::CompoundStatement& compoundStatement_33e, const SFC::UnaryExprs& newUnaryExprs_340)
{
	_argDeclBase_2f3->push_back( argDeclBase_338);
	_dT_2f4->push_back( dT_33a);
	_iterativeBlock_2f5->push_back( iterativeBlock_33c);
	_compoundStatement_2f6->push_back( compoundStatement_33e);
	_newUnaryExprs_2f7->push_back( newUnaryExprs_340);
}

void AddIndex_342::operator()( const Packets_t& argDeclBases_343, const Packets_t& arrays_346, const Packets_t& iterativeBlocks_349, const Packets_t& compoundStatements_34c, const Packets_t& unaryExprss_34f, Packets_t& argDeclBases_345, Packets_t& dTs_348, Packets_t& lastIBs_34b, Packets_t& compoundStatements_34e, Packets_t& newUnaryExprss_351)
{
#ifdef PRINT_INFO
	std::cout << "AddIndex_342" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(177, "AddIndex");
	_argDeclBase_352= &argDeclBases_345;
	_dT_353= &dTs_348;
	_lastIB_354= &lastIBs_34b;
	_compoundStatement_355= &compoundStatements_34e;
	_newUnaryExprs_356= &newUnaryExprss_351;
	processInputPackets( argDeclBases_343, arrays_346, iterativeBlocks_349, compoundStatements_34c, unaryExprss_34f);
}

bool AddIndex_342::isInputUnique( const Udm::Object& argDeclBase_35b, const Udm::Object& array_364, const Udm::Object& iterativeBlock_36d, const Udm::Object& compoundStatement_376, const Udm::Object& unaryExprs_37f)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_35d= _argDeclBase_357.begin(), itArray_366= _array_360.begin(), itIterativeBlock_36f= _iterativeBlock_369.begin(), itCompoundStatement_378= _compoundStatement_372.begin(), itUnaryExprs_381= _unaryExprs_37b.begin(); itArgDeclBase_35d!= _argDeclBase_357.end(), itArray_366!= _array_360.end(), itIterativeBlock_36f!= _iterativeBlock_369.end(), itCompoundStatement_378!= _compoundStatement_372.end(), itUnaryExprs_381!= _unaryExprs_37b.end(); ++itArgDeclBase_35d, ++itArray_366, ++itIterativeBlock_36f, ++itCompoundStatement_378, ++itUnaryExprs_381)
	{
		if( ( *itArgDeclBase_35d== argDeclBase_35b)&& ( *itArray_366== array_364)&& ( *itIterativeBlock_36f== iterativeBlock_36d)&& ( *itCompoundStatement_378== compoundStatement_376)&& ( *itUnaryExprs_381== unaryExprs_37f))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_357.push_back( argDeclBase_35b);
		_array_360.push_back( array_364);
		_iterativeBlock_369.push_back( iterativeBlock_36d);
		_compoundStatement_372.push_back( compoundStatement_376);
		_unaryExprs_37b.push_back( unaryExprs_37f);
	}
	return isUnique;
}

bool AddIndex_342::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void AddIndex_342::processInputPackets( const Packets_t& argDeclBases_343, const Packets_t& arrays_346, const Packets_t& iterativeBlocks_349, const Packets_t& compoundStatements_34c, const Packets_t& unaryExprss_34f)
{
	for( Packets_t::const_iterator itArgDeclBase_358= argDeclBases_343.begin(), itArray_361= arrays_346.begin(), itIterativeBlock_36a= iterativeBlocks_349.begin(), itCompoundStatement_373= compoundStatements_34c.begin(), itUnaryExprs_37c= unaryExprss_34f.begin(); itArgDeclBase_358!= argDeclBases_343.end(), itArray_361!= arrays_346.end(), itIterativeBlock_36a!= iterativeBlocks_349.end(), itCompoundStatement_373!= compoundStatements_34c.end(), itUnaryExprs_37c!= unaryExprss_34f.end(); ++itArgDeclBase_358, ++itArray_361, ++itIterativeBlock_36a, ++itCompoundStatement_373, ++itUnaryExprs_37c)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_358, *itArray_361, *itIterativeBlock_36a, *itCompoundStatement_373, *itUnaryExprs_37c);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_358, *itArray_361, *itIterativeBlock_36a, *itCompoundStatement_373, *itUnaryExprs_37c);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool AddIndex_342::patternMatcher( const Udm::Object& argDeclBase_359, const Udm::Object& array_362, const Udm::Object& iterativeBlock_36b, const Udm::Object& compoundStatement_374, const Udm::Object& unaryExprs_37d)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_359.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_35e= SFC::ArgDeclBase::Cast( argDeclBase_359);
		if( false== Uml::IsDerivedFrom( array_362.type(), SFC::Array::meta))
			continue;
		SFC::Array array_367= SFC::Array::Cast( array_362);
		if( false== Uml::IsDerivedFrom( iterativeBlock_36b.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_370= SFC::IterativeBlock::Cast( iterativeBlock_36b);
		if( false== Uml::IsDerivedFrom( compoundStatement_374.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_379= SFC::CompoundStatement::Cast( compoundStatement_374);
		if( false== Uml::IsDerivedFrom( unaryExprs_37d.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_382= SFC::UnaryExprs::Cast( unaryExprs_37d);
		set< SFC::IterativeBlock> lastIBs_384= iterativeBlock_370.IterativeBlock_kind_children();
		for( set< SFC::IterativeBlock>::const_iterator itLastIB_385= lastIBs_384.begin(); itLastIB_385!= lastIBs_384.end(); ++itLastIB_385)
		{
			SFC::IterativeBlock currLastIB_386= *itLastIB_385;
			SFC::DT dT_387= array_367.dt();
			if( !dT_387)
				continue;
			SFC::LocalVar localVar_388= currLastIB_386.counter();
			if( !localVar_388)
				continue;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_38c;
			if( !isValidBound(boundObjs_38c, argDeclBase_35e, true))
				continue;
			currMatch.argDeclBase_38d= argDeclBase_35e;
			if( !isValidBound(boundObjs_38c, array_367, true))
				continue;
			currMatch.array_38e= array_367;
			if( !isValidBound(boundObjs_38c, iterativeBlock_370, true))
				continue;
			currMatch.iterativeBlock_38f= iterativeBlock_370;
			if( !isValidBound(boundObjs_38c, compoundStatement_379, true))
				continue;
			currMatch.compoundStatement_390= compoundStatement_379;
			if( !isValidBound(boundObjs_38c, unaryExprs_382, true))
				continue;
			currMatch.unaryExprs_391= unaryExprs_382;
			if( !isValidBound(boundObjs_38c, dT_387, false))
				continue;
			currMatch.dT_392= dT_387;
			if( !isValidBound(boundObjs_38c, currLastIB_386, false))
				continue;
			currMatch.lastIB_393= currLastIB_386;
			if( !isValidBound(boundObjs_38c, localVar_388, false))
				continue;
			currMatch.localVar_394= localVar_388;
			_matches.push_back( currMatch);
			return true;
		}
	}
	return !_matches.empty();
}

void AddIndex_342::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::UserCode newUserCode_395= SFC::UserCode::Create( currMatch.lastIB_393, SFC::IterativeBlock::meta_stmnt);
		SFC::UnaryExprs newIncrement_396= SFC::UnaryExprs::Create( newUserCode_395, SFC::UserCode::meta_codeexpr);
		SFC::ArgDeclRef newArgDeclRef2_397= SFC::ArgDeclRef::Create( newIncrement_396, SFC::UnaryExprs::meta_subexpr);
		SFC::BinaryExprs newBinaryExprs_398= SFC::BinaryExprs::Create( currMatch.unaryExprs_391, SFC::UnaryExprs::meta_subexpr);
		SFC::ArgDeclRef newArgDeclRef1_399= SFC::ArgDeclRef::Create( newBinaryExprs_398, SFC::BinaryExprs::meta_rightexpr);
		SFC::UnaryExprs newNewUnaryExprs_39a= SFC::UnaryExprs::Create( newBinaryExprs_398, SFC::BinaryExprs::meta_leftexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_38d;
		SFC::ArgDeclRef& ArgDeclRef1= newArgDeclRef1_399;
		SFC::ArgDeclRef& ArgDeclRef2= newArgDeclRef2_397;
		SFC::Array& Array= currMatch.array_38e;
		SFC::BinaryExprs& BinaryExprs= newBinaryExprs_398;
		SFC::CompoundStatement& CompoundStatement= currMatch.compoundStatement_390;
		SFC::DT& DT= currMatch.dT_392;
		SFC::UnaryExprs& Increment= newIncrement_396;
		SFC::IterativeBlock& IterativeBlock= currMatch.iterativeBlock_38f;
		SFC::IterativeBlock& LastIB= currMatch.lastIB_393;
		SFC::LocalVar& LocalVar= currMatch.localVar_394;
		SFC::UnaryExprs& NewUnaryExprs= newNewUnaryExprs_39a;
		SFC::UnaryExprs& UnaryExprs= currMatch.unaryExprs_391;
		SFC::UserCode& UserCode= newUserCode_395;
		{
Increment.op() = "++";
};
		{
__int64 statementCount = IterativeBlock.statementCount();
UserCode.statementIndex() = statementCount++;
IterativeBlock.statementCount() = statementCount;
};
		{
BinaryExprs.op() = "[";
};
		newArgDeclRef2_397.argdecl()= currMatch.localVar_394;
		newArgDeclRef1_399.argdecl()= currMatch.localVar_394;
		outputAppender( currMatch.argDeclBase_38d, currMatch.dT_392, currMatch.lastIB_393, currMatch.compoundStatement_390, newNewUnaryExprs_39a);
	}
}

void AddIndex_342::outputAppender( const SFC::ArgDeclBase& argDeclBase_39b, const SFC::DT& dT_39d, const SFC::IterativeBlock& lastIB_39f, const SFC::CompoundStatement& compoundStatement_3a1, const SFC::UnaryExprs& newUnaryExprs_3a3)
{
	_argDeclBase_352->push_back( argDeclBase_39b);
	_dT_353->push_back( dT_39d);
	_lastIB_354->push_back( lastIB_39f);
	_compoundStatement_355->push_back( compoundStatement_3a1);
	_newUnaryExprs_356->push_back( newUnaryExprs_3a3);
}

void SkipArray_3a5::operator()( const Packets_t& argDeclBases_3a6, const Packets_t& arrays_3a9, const Packets_t& iterativeBlocks_3ac, const Packets_t& compoundStatements_3af, const Packets_t& unaryExprss_3b2, Packets_t& argDeclBases_3a8, Packets_t& dTs_3ab, Packets_t& iterativeBlocks_3ae, Packets_t& compoundStatements_3b1, Packets_t& unaryExprss_3b4)
{
#ifdef PRINT_INFO
	std::cout << "SkipArray_3a5" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(206, "SkipArray");
	_argDeclBase_3b5= &argDeclBases_3a8;
	_dT_3b6= &dTs_3ab;
	_iterativeBlock_3b7= &iterativeBlocks_3ae;
	_compoundStatement_3b8= &compoundStatements_3b1;
	_unaryExprs_3b9= &unaryExprss_3b4;
	processInputPackets( argDeclBases_3a6, arrays_3a9, iterativeBlocks_3ac, compoundStatements_3af, unaryExprss_3b2);
}

bool SkipArray_3a5::isInputUnique( const Udm::Object& argDeclBase_3be, const Udm::Object& array_3c7, const Udm::Object& iterativeBlock_3d0, const Udm::Object& compoundStatement_3d9, const Udm::Object& unaryExprs_3e2)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_3c0= _argDeclBase_3ba.begin(), itArray_3c9= _array_3c3.begin(), itIterativeBlock_3d2= _iterativeBlock_3cc.begin(), itCompoundStatement_3db= _compoundStatement_3d5.begin(), itUnaryExprs_3e4= _unaryExprs_3de.begin(); itArgDeclBase_3c0!= _argDeclBase_3ba.end(), itArray_3c9!= _array_3c3.end(), itIterativeBlock_3d2!= _iterativeBlock_3cc.end(), itCompoundStatement_3db!= _compoundStatement_3d5.end(), itUnaryExprs_3e4!= _unaryExprs_3de.end(); ++itArgDeclBase_3c0, ++itArray_3c9, ++itIterativeBlock_3d2, ++itCompoundStatement_3db, ++itUnaryExprs_3e4)
	{
		if( ( *itArgDeclBase_3c0== argDeclBase_3be)&& ( *itArray_3c9== array_3c7)&& ( *itIterativeBlock_3d2== iterativeBlock_3d0)&& ( *itCompoundStatement_3db== compoundStatement_3d9)&& ( *itUnaryExprs_3e4== unaryExprs_3e2))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_3ba.push_back( argDeclBase_3be);
		_array_3c3.push_back( array_3c7);
		_iterativeBlock_3cc.push_back( iterativeBlock_3d0);
		_compoundStatement_3d5.push_back( compoundStatement_3d9);
		_unaryExprs_3de.push_back( unaryExprs_3e2);
	}
	return isUnique;
}

bool SkipArray_3a5::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void SkipArray_3a5::processInputPackets( const Packets_t& argDeclBases_3a6, const Packets_t& arrays_3a9, const Packets_t& iterativeBlocks_3ac, const Packets_t& compoundStatements_3af, const Packets_t& unaryExprss_3b2)
{
	for( Packets_t::const_iterator itArgDeclBase_3bb= argDeclBases_3a6.begin(), itArray_3c4= arrays_3a9.begin(), itIterativeBlock_3cd= iterativeBlocks_3ac.begin(), itCompoundStatement_3d6= compoundStatements_3af.begin(), itUnaryExprs_3df= unaryExprss_3b2.begin(); itArgDeclBase_3bb!= argDeclBases_3a6.end(), itArray_3c4!= arrays_3a9.end(), itIterativeBlock_3cd!= iterativeBlocks_3ac.end(), itCompoundStatement_3d6!= compoundStatements_3af.end(), itUnaryExprs_3df!= unaryExprss_3b2.end(); ++itArgDeclBase_3bb, ++itArray_3c4, ++itIterativeBlock_3cd, ++itCompoundStatement_3d6, ++itUnaryExprs_3df)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_3bb, *itArray_3c4, *itIterativeBlock_3cd, *itCompoundStatement_3d6, *itUnaryExprs_3df);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_3bb, *itArray_3c4, *itIterativeBlock_3cd, *itCompoundStatement_3d6, *itUnaryExprs_3df);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool SkipArray_3a5::patternMatcher( const Udm::Object& argDeclBase_3bc, const Udm::Object& array_3c5, const Udm::Object& iterativeBlock_3ce, const Udm::Object& compoundStatement_3d7, const Udm::Object& unaryExprs_3e0)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_3bc.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_3c1= SFC::ArgDeclBase::Cast( argDeclBase_3bc);
		if( false== Uml::IsDerivedFrom( array_3c5.type(), SFC::Array::meta))
			continue;
		SFC::Array array_3ca= SFC::Array::Cast( array_3c5);
		if( false== Uml::IsDerivedFrom( iterativeBlock_3ce.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_3d3= SFC::IterativeBlock::Cast( iterativeBlock_3ce);
		if( false== Uml::IsDerivedFrom( compoundStatement_3d7.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_3dc= SFC::CompoundStatement::Cast( compoundStatement_3d7);
		if( false== Uml::IsDerivedFrom( unaryExprs_3e0.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_3e5= SFC::UnaryExprs::Cast( unaryExprs_3e0);
		SFC::DT dT_3e7= array_3ca.dt();
		if( !dT_3e7)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_3eb;
		if( !isValidBound(boundObjs_3eb, argDeclBase_3c1, true))
			continue;
		currMatch.argDeclBase_3ec= argDeclBase_3c1;
		if( !isValidBound(boundObjs_3eb, array_3ca, true))
			continue;
		currMatch.array_3ed= array_3ca;
		if( !isValidBound(boundObjs_3eb, iterativeBlock_3d3, true))
			continue;
		currMatch.iterativeBlock_3ee= iterativeBlock_3d3;
		if( !isValidBound(boundObjs_3eb, compoundStatement_3dc, true))
			continue;
		currMatch.compoundStatement_3ef= compoundStatement_3dc;
		if( !isValidBound(boundObjs_3eb, unaryExprs_3e5, true))
			continue;
		currMatch.unaryExprs_3f0= unaryExprs_3e5;
		if( !isValidBound(boundObjs_3eb, dT_3e7, false))
			continue;
		currMatch.dT_3f1= dT_3e7;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void SkipArray_3a5::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_3ec, currMatch.dT_3f1, currMatch.iterativeBlock_3ee, currMatch.compoundStatement_3ef, currMatch.unaryExprs_3f0);
	}
}

void SkipArray_3a5::outputAppender( const SFC::ArgDeclBase& argDeclBase_3f2, const SFC::DT& dT_3f4, const SFC::IterativeBlock& iterativeBlock_3f6, const SFC::CompoundStatement& compoundStatement_3f8, const SFC::UnaryExprs& unaryExprs_3fa)
{
	_argDeclBase_3b5->push_back( argDeclBase_3f2);
	_dT_3b6->push_back( dT_3f4);
	_iterativeBlock_3b7->push_back( iterativeBlock_3f6);
	_compoundStatement_3b8->push_back( compoundStatement_3f8);
	_unaryExprs_3b9->push_back( unaryExprs_3fa);
}

void ArrayTest_3fc::operator()( const Packets_t& passADBs_3fd, const Packets_t& dts_3ff, const Packets_t& lastibs_401, const Packets_t& css_403, const Packets_t& ues_405, Packets_t& passADBs_407, Packets_t& arrays_408, Packets_t& lastibs_409, Packets_t& css_40a, Packets_t& ues_40b, Packets_t& passADBs_40c, Packets_t& arrays_40d, Packets_t& lastibs_40e, Packets_t& css_40f, Packets_t& ues_410, Packets_t& passADBs_411, Packets_t& arrays_412, Packets_t& lastibs_413, Packets_t& css_414, Packets_t& ues_415)
{
#ifdef PRINT_INFO
	std::cout << "ArrayTest_3fc" << std::endl;
#endif
	_passADB_416= &passADBs_407;
	_array_417= &arrays_408;
	_lastib_418= &lastibs_409;
	_cs_419= &css_40a;
	_ue_41a= &ues_40b;
	_passADB_41b= &passADBs_40c;
	_array_41c= &arrays_40d;
	_lastib_41d= &lastibs_40e;
	_cs_41e= &css_40f;
	_ue_41f= &ues_410;
	_passADB_420= &passADBs_411;
	_array_421= &arrays_412;
	_lastib_422= &lastibs_413;
	_cs_423= &css_414;
	_ue_424= &ues_415;
	for( Packets_t::const_iterator itpassADB_426= passADBs_3fd.begin(), itdt_42d= dts_3ff.begin(), itlastib_434= lastibs_401.begin(), itcs_43b= css_403.begin(), itue_442= ues_405.begin(); itpassADB_426!= passADBs_3fd.end(), itdt_42d!= dts_3ff.end(), itlastib_434!= lastibs_401.end(), itcs_43b!= css_403.end(), itue_442!= ues_405.end(); ++itpassADB_426, ++itdt_42d, ++itlastib_434, ++itcs_43b, ++itue_442)
	{
		bool isUnique= isInputUnique( *itpassADB_426, *itdt_42d, *itlastib_434, *itcs_43b, *itue_442);
		if( !isUnique)
			continue;
		Packets_t onepassADB_42a( 1, *itpassADB_426);
		Packets_t onedt_431( 1, *itdt_42d);
		Packets_t onelastib_438( 1, *itlastib_434);
		Packets_t onecs_43f( 1, *itcs_43b);
		Packets_t oneue_446( 1, *itue_442);
		executeOne( onepassADB_42a, onedt_431, onelastib_438, onecs_43f, oneue_446);
	}
}

void ArrayTest_3fc::executeOne( const Packets_t& passADBs_3fd, const Packets_t& dts_3ff, const Packets_t& lastibs_401, const Packets_t& css_403, const Packets_t& ues_405)
{
	Packets_t argDeclBases_44b;
	Packets_t arrays_44e;
	Packets_t iterativeBlocks_451;
	Packets_t compoundStatements_454;
	Packets_t unaryExprss_457;
	NullArray_448 nullArray_448;
	bool isMatchNullArray_448= nullArray_448( passADBs_3fd, dts_3ff, lastibs_401, css_403, ues_405, argDeclBases_44b, arrays_44e, iterativeBlocks_451, compoundStatements_454, unaryExprss_457);
	_passADB_416->insert( _passADB_416->end(), argDeclBases_44b.begin(), argDeclBases_44b.end());
	_array_417->insert( _array_417->end(), arrays_44e.begin(), arrays_44e.end());
	_lastib_418->insert( _lastib_418->end(), iterativeBlocks_451.begin(), iterativeBlocks_451.end());
	_cs_419->insert( _cs_419->end(), compoundStatements_454.begin(), compoundStatements_454.end());
	_ue_41a->insert( _ue_41a->end(), unaryExprss_457.begin(), unaryExprss_457.end());
	if( isMatchNullArray_448)
		return;
	Packets_t argDeclBases_4a2;
	Packets_t arrays_4a5;
	Packets_t iterativeBlocks_4a8;
	Packets_t compoundStatements_4ab;
	Packets_t unaryExprss_4ae;
	Array_49f array_49f;
	bool isMatchArray_49f= array_49f( passADBs_3fd, dts_3ff, lastibs_401, css_403, ues_405, argDeclBases_4a2, arrays_4a5, iterativeBlocks_4a8, compoundStatements_4ab, unaryExprss_4ae);
	_passADB_41b->insert( _passADB_41b->end(), argDeclBases_4a2.begin(), argDeclBases_4a2.end());
	_array_41c->insert( _array_41c->end(), arrays_4a5.begin(), arrays_4a5.end());
	_lastib_41d->insert( _lastib_41d->end(), iterativeBlocks_4a8.begin(), iterativeBlocks_4a8.end());
	_cs_41e->insert( _cs_41e->end(), compoundStatements_4ab.begin(), compoundStatements_4ab.end());
	_ue_41f->insert( _ue_41f->end(), unaryExprss_4ae.begin(), unaryExprss_4ae.end());
	if( isMatchArray_49f)
		return;
	Packets_t argDeclBases_4f4;
	Packets_t dTs_4f7;
	Packets_t lastIBs_4fa;
	Packets_t compoundStatements_4fd;
	Packets_t unaryExprss_500;
	Otherwise_4f1 otherwise_4f1;
	bool isMatchOtherwise_4f1= otherwise_4f1( passADBs_3fd, dts_3ff, lastibs_401, css_403, ues_405, argDeclBases_4f4, dTs_4f7, lastIBs_4fa, compoundStatements_4fd, unaryExprss_500);
	_passADB_420->insert( _passADB_420->end(), argDeclBases_4f4.begin(), argDeclBases_4f4.end());
	_array_421->insert( _array_421->end(), dTs_4f7.begin(), dTs_4f7.end());
	_lastib_422->insert( _lastib_422->end(), lastIBs_4fa.begin(), lastIBs_4fa.end());
	_cs_423->insert( _cs_423->end(), compoundStatements_4fd.begin(), compoundStatements_4fd.end());
	_ue_424->insert( _ue_424->end(), unaryExprss_500.begin(), unaryExprss_500.end());
	if( isMatchOtherwise_4f1)
		return;
}

bool ArrayTest_3fc::isInputUnique( const Udm::Object& passADB_427, const Udm::Object& dt_42e, const Udm::Object& lastib_435, const Udm::Object& cs_43c, const Udm::Object& ue_443)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_429= _passADB_425.begin(), itdt_430= _dt_42c.begin(), itlastib_437= _lastib_433.begin(), itcs_43e= _cs_43a.begin(), itue_445= _ue_441.begin(); itpassADB_429!= _passADB_425.end(), itdt_430!= _dt_42c.end(), itlastib_437!= _lastib_433.end(), itcs_43e!= _cs_43a.end(), itue_445!= _ue_441.end(); ++itpassADB_429, ++itdt_430, ++itlastib_437, ++itcs_43e, ++itue_445)
	{
		if( ( *itpassADB_429== passADB_427)&& ( *itdt_430== dt_42e)&& ( *itlastib_437== lastib_435)&& ( *itcs_43e== cs_43c)&& ( *itue_445== ue_443))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_425.push_back( passADB_427);
		_dt_42c.push_back( dt_42e);
		_lastib_433.push_back( lastib_435);
		_cs_43a.push_back( cs_43c);
		_ue_441.push_back( ue_443);
	}
	return isUnique;
}

bool NullArray_448::operator()( const Packets_t& argDeclBases_449, const Packets_t& arrays_44c, const Packets_t& iterativeBlocks_44f, const Packets_t& compoundStatements_452, const Packets_t& unaryExprss_455, Packets_t& argDeclBases_44b, Packets_t& arrays_44e, Packets_t& iterativeBlocks_451, Packets_t& compoundStatements_454, Packets_t& unaryExprss_457)
{
#ifdef PRINT_INFO
	std::cout << "NullArray_448" << std::endl;
#endif
	_argDeclBase_458= &argDeclBases_44b;
	_array_459= &arrays_44e;
	_iterativeBlock_45a= &iterativeBlocks_451;
	_compoundStatement_45b= &compoundStatements_454;
	_unaryExprs_45c= &unaryExprss_457;
	processInputPackets( argDeclBases_449, arrays_44c, iterativeBlocks_44f, compoundStatements_452, unaryExprss_455);
	if( false== _matches.empty())
		return true;
	return false;
}

bool NullArray_448::isInputUnique( const Udm::Object& argDeclBase_461, const Udm::Object& array_46a, const Udm::Object& iterativeBlock_473, const Udm::Object& compoundStatement_47c, const Udm::Object& unaryExprs_485)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_463= _argDeclBase_45d.begin(), itArray_46c= _array_466.begin(), itIterativeBlock_475= _iterativeBlock_46f.begin(), itCompoundStatement_47e= _compoundStatement_478.begin(), itUnaryExprs_487= _unaryExprs_481.begin(); itArgDeclBase_463!= _argDeclBase_45d.end(), itArray_46c!= _array_466.end(), itIterativeBlock_475!= _iterativeBlock_46f.end(), itCompoundStatement_47e!= _compoundStatement_478.end(), itUnaryExprs_487!= _unaryExprs_481.end(); ++itArgDeclBase_463, ++itArray_46c, ++itIterativeBlock_475, ++itCompoundStatement_47e, ++itUnaryExprs_487)
	{
		if( ( *itArgDeclBase_463== argDeclBase_461)&& ( *itArray_46c== array_46a)&& ( *itIterativeBlock_475== iterativeBlock_473)&& ( *itCompoundStatement_47e== compoundStatement_47c)&& ( *itUnaryExprs_487== unaryExprs_485))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_45d.push_back( argDeclBase_461);
		_array_466.push_back( array_46a);
		_iterativeBlock_46f.push_back( iterativeBlock_473);
		_compoundStatement_478.push_back( compoundStatement_47c);
		_unaryExprs_481.push_back( unaryExprs_485);
	}
	return isUnique;
}

bool NullArray_448::isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Array& Array, SFC::CompoundStatement& CompoundStatement, SFC::IterativeBlock& IterativeBlock, SFC::UnaryExprs& UnaryExprs)
{
	bool Gz_guard= false;
	Gz_guard = Array.noelem() <= 1;;
	return Gz_guard;
}

void NullArray_448::processInputPackets( const Packets_t& argDeclBases_449, const Packets_t& arrays_44c, const Packets_t& iterativeBlocks_44f, const Packets_t& compoundStatements_452, const Packets_t& unaryExprss_455)
{
	for( Packets_t::const_iterator itArgDeclBase_45e= argDeclBases_449.begin(), itArray_467= arrays_44c.begin(), itIterativeBlock_470= iterativeBlocks_44f.begin(), itCompoundStatement_479= compoundStatements_452.begin(), itUnaryExprs_482= unaryExprss_455.begin(); itArgDeclBase_45e!= argDeclBases_449.end(), itArray_467!= arrays_44c.end(), itIterativeBlock_470!= iterativeBlocks_44f.end(), itCompoundStatement_479!= compoundStatements_452.end(), itUnaryExprs_482!= unaryExprss_455.end(); ++itArgDeclBase_45e, ++itArray_467, ++itIterativeBlock_470, ++itCompoundStatement_479, ++itUnaryExprs_482)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_45e, *itArray_467, *itIterativeBlock_470, *itCompoundStatement_479, *itUnaryExprs_482);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_45e, *itArray_467, *itIterativeBlock_470, *itCompoundStatement_479, *itUnaryExprs_482);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_48b, currMatch.array_48c, currMatch.iterativeBlock_48d, currMatch.compoundStatement_48e, currMatch.unaryExprs_48f);
	}
}

bool NullArray_448::patternMatcher( const Udm::Object& argDeclBase_45f, const Udm::Object& array_468, const Udm::Object& iterativeBlock_471, const Udm::Object& compoundStatement_47a, const Udm::Object& unaryExprs_483)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_45f.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_464= SFC::ArgDeclBase::Cast( argDeclBase_45f);
		if( false== Uml::IsDerivedFrom( array_468.type(), SFC::Array::meta))
			continue;
		SFC::Array array_46d= SFC::Array::Cast( array_468);
		if( false== Uml::IsDerivedFrom( iterativeBlock_471.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_476= SFC::IterativeBlock::Cast( iterativeBlock_471);
		if( false== Uml::IsDerivedFrom( compoundStatement_47a.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_47f= SFC::CompoundStatement::Cast( compoundStatement_47a);
		if( false== Uml::IsDerivedFrom( unaryExprs_483.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_488= SFC::UnaryExprs::Cast( unaryExprs_483);
		Match currMatch;
		currMatch.argDeclBase_48b= argDeclBase_464;
		currMatch.array_48c= array_46d;
		currMatch.iterativeBlock_48d= iterativeBlock_476;
		currMatch.compoundStatement_48e= compoundStatement_47f;
		currMatch.unaryExprs_48f= unaryExprs_488;
		bool Gz_guard= isGuardTrue( currMatch.argDeclBase_48b, currMatch.array_48c, currMatch.compoundStatement_48e, currMatch.iterativeBlock_48d, currMatch.unaryExprs_48f);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void NullArray_448::outputAppender( const SFC::ArgDeclBase& argDeclBase_495, const SFC::Array& array_497, const SFC::IterativeBlock& iterativeBlock_499, const SFC::CompoundStatement& compoundStatement_49b, const SFC::UnaryExprs& unaryExprs_49d)
{
	_argDeclBase_458->push_back( argDeclBase_495);
	_array_459->push_back( array_497);
	_iterativeBlock_45a->push_back( iterativeBlock_499);
	_compoundStatement_45b->push_back( compoundStatement_49b);
	_unaryExprs_45c->push_back( unaryExprs_49d);
}

bool Array_49f::operator()( const Packets_t& argDeclBases_4a0, const Packets_t& arrays_4a3, const Packets_t& iterativeBlocks_4a6, const Packets_t& compoundStatements_4a9, const Packets_t& unaryExprss_4ac, Packets_t& argDeclBases_4a2, Packets_t& arrays_4a5, Packets_t& iterativeBlocks_4a8, Packets_t& compoundStatements_4ab, Packets_t& unaryExprss_4ae)
{
#ifdef PRINT_INFO
	std::cout << "Array_49f" << std::endl;
#endif
	_argDeclBase_4af= &argDeclBases_4a2;
	_array_4b0= &arrays_4a5;
	_iterativeBlock_4b1= &iterativeBlocks_4a8;
	_compoundStatement_4b2= &compoundStatements_4ab;
	_unaryExprs_4b3= &unaryExprss_4ae;
	processInputPackets( argDeclBases_4a0, arrays_4a3, iterativeBlocks_4a6, compoundStatements_4a9, unaryExprss_4ac);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Array_49f::isInputUnique( const Udm::Object& argDeclBase_4b8, const Udm::Object& array_4c1, const Udm::Object& iterativeBlock_4ca, const Udm::Object& compoundStatement_4d3, const Udm::Object& unaryExprs_4dc)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_4ba= _argDeclBase_4b4.begin(), itArray_4c3= _array_4bd.begin(), itIterativeBlock_4cc= _iterativeBlock_4c6.begin(), itCompoundStatement_4d5= _compoundStatement_4cf.begin(), itUnaryExprs_4de= _unaryExprs_4d8.begin(); itArgDeclBase_4ba!= _argDeclBase_4b4.end(), itArray_4c3!= _array_4bd.end(), itIterativeBlock_4cc!= _iterativeBlock_4c6.end(), itCompoundStatement_4d5!= _compoundStatement_4cf.end(), itUnaryExprs_4de!= _unaryExprs_4d8.end(); ++itArgDeclBase_4ba, ++itArray_4c3, ++itIterativeBlock_4cc, ++itCompoundStatement_4d5, ++itUnaryExprs_4de)
	{
		if( ( *itArgDeclBase_4ba== argDeclBase_4b8)&& ( *itArray_4c3== array_4c1)&& ( *itIterativeBlock_4cc== iterativeBlock_4ca)&& ( *itCompoundStatement_4d5== compoundStatement_4d3)&& ( *itUnaryExprs_4de== unaryExprs_4dc))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_4b4.push_back( argDeclBase_4b8);
		_array_4bd.push_back( array_4c1);
		_iterativeBlock_4c6.push_back( iterativeBlock_4ca);
		_compoundStatement_4cf.push_back( compoundStatement_4d3);
		_unaryExprs_4d8.push_back( unaryExprs_4dc);
	}
	return isUnique;
}

void Array_49f::processInputPackets( const Packets_t& argDeclBases_4a0, const Packets_t& arrays_4a3, const Packets_t& iterativeBlocks_4a6, const Packets_t& compoundStatements_4a9, const Packets_t& unaryExprss_4ac)
{
	for( Packets_t::const_iterator itArgDeclBase_4b5= argDeclBases_4a0.begin(), itArray_4be= arrays_4a3.begin(), itIterativeBlock_4c7= iterativeBlocks_4a6.begin(), itCompoundStatement_4d0= compoundStatements_4a9.begin(), itUnaryExprs_4d9= unaryExprss_4ac.begin(); itArgDeclBase_4b5!= argDeclBases_4a0.end(), itArray_4be!= arrays_4a3.end(), itIterativeBlock_4c7!= iterativeBlocks_4a6.end(), itCompoundStatement_4d0!= compoundStatements_4a9.end(), itUnaryExprs_4d9!= unaryExprss_4ac.end(); ++itArgDeclBase_4b5, ++itArray_4be, ++itIterativeBlock_4c7, ++itCompoundStatement_4d0, ++itUnaryExprs_4d9)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_4b5, *itArray_4be, *itIterativeBlock_4c7, *itCompoundStatement_4d0, *itUnaryExprs_4d9);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_4b5, *itArray_4be, *itIterativeBlock_4c7, *itCompoundStatement_4d0, *itUnaryExprs_4d9);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_4e2, currMatch.array_4e3, currMatch.iterativeBlock_4e4, currMatch.compoundStatement_4e5, currMatch.unaryExprs_4e6);
	}
}

bool Array_49f::patternMatcher( const Udm::Object& argDeclBase_4b6, const Udm::Object& array_4bf, const Udm::Object& iterativeBlock_4c8, const Udm::Object& compoundStatement_4d1, const Udm::Object& unaryExprs_4da)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_4b6.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_4bb= SFC::ArgDeclBase::Cast( argDeclBase_4b6);
		if( false== Uml::IsDerivedFrom( array_4bf.type(), SFC::Array::meta))
			continue;
		SFC::Array array_4c4= SFC::Array::Cast( array_4bf);
		if( false== Uml::IsDerivedFrom( iterativeBlock_4c8.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_4cd= SFC::IterativeBlock::Cast( iterativeBlock_4c8);
		if( false== Uml::IsDerivedFrom( compoundStatement_4d1.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_4d6= SFC::CompoundStatement::Cast( compoundStatement_4d1);
		if( false== Uml::IsDerivedFrom( unaryExprs_4da.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_4df= SFC::UnaryExprs::Cast( unaryExprs_4da);
		Match currMatch;
		currMatch.argDeclBase_4e2= argDeclBase_4bb;
		currMatch.array_4e3= array_4c4;
		currMatch.iterativeBlock_4e4= iterativeBlock_4cd;
		currMatch.compoundStatement_4e5= compoundStatement_4d6;
		currMatch.unaryExprs_4e6= unaryExprs_4df;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Array_49f::outputAppender( const SFC::ArgDeclBase& argDeclBase_4e7, const SFC::Array& array_4e9, const SFC::IterativeBlock& iterativeBlock_4eb, const SFC::CompoundStatement& compoundStatement_4ed, const SFC::UnaryExprs& unaryExprs_4ef)
{
	_argDeclBase_4af->push_back( argDeclBase_4e7);
	_array_4b0->push_back( array_4e9);
	_iterativeBlock_4b1->push_back( iterativeBlock_4eb);
	_compoundStatement_4b2->push_back( compoundStatement_4ed);
	_unaryExprs_4b3->push_back( unaryExprs_4ef);
}

bool Otherwise_4f1::operator()( const Packets_t& argDeclBases_4f2, const Packets_t& dTs_4f5, const Packets_t& lastIBs_4f8, const Packets_t& compoundStatements_4fb, const Packets_t& unaryExprss_4fe, Packets_t& argDeclBases_4f4, Packets_t& dTs_4f7, Packets_t& lastIBs_4fa, Packets_t& compoundStatements_4fd, Packets_t& unaryExprss_500)
{
#ifdef PRINT_INFO
	std::cout << "Otherwise_4f1" << std::endl;
#endif
	_argDeclBase_501= &argDeclBases_4f4;
	_dT_502= &dTs_4f7;
	_lastIB_503= &lastIBs_4fa;
	_compoundStatement_504= &compoundStatements_4fd;
	_unaryExprs_505= &unaryExprss_500;
	processInputPackets( argDeclBases_4f2, dTs_4f5, lastIBs_4f8, compoundStatements_4fb, unaryExprss_4fe);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Otherwise_4f1::isInputUnique( const Udm::Object& argDeclBase_50a, const Udm::Object& dT_513, const Udm::Object& lastIB_51c, const Udm::Object& compoundStatement_525, const Udm::Object& unaryExprs_52e)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_50c= _argDeclBase_506.begin(), itDT_515= _dT_50f.begin(), itLastIB_51e= _lastIB_518.begin(), itCompoundStatement_527= _compoundStatement_521.begin(), itUnaryExprs_530= _unaryExprs_52a.begin(); itArgDeclBase_50c!= _argDeclBase_506.end(), itDT_515!= _dT_50f.end(), itLastIB_51e!= _lastIB_518.end(), itCompoundStatement_527!= _compoundStatement_521.end(), itUnaryExprs_530!= _unaryExprs_52a.end(); ++itArgDeclBase_50c, ++itDT_515, ++itLastIB_51e, ++itCompoundStatement_527, ++itUnaryExprs_530)
	{
		if( ( *itArgDeclBase_50c== argDeclBase_50a)&& ( *itDT_515== dT_513)&& ( *itLastIB_51e== lastIB_51c)&& ( *itCompoundStatement_527== compoundStatement_525)&& ( *itUnaryExprs_530== unaryExprs_52e))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_506.push_back( argDeclBase_50a);
		_dT_50f.push_back( dT_513);
		_lastIB_518.push_back( lastIB_51c);
		_compoundStatement_521.push_back( compoundStatement_525);
		_unaryExprs_52a.push_back( unaryExprs_52e);
	}
	return isUnique;
}

void Otherwise_4f1::processInputPackets( const Packets_t& argDeclBases_4f2, const Packets_t& dTs_4f5, const Packets_t& lastIBs_4f8, const Packets_t& compoundStatements_4fb, const Packets_t& unaryExprss_4fe)
{
	for( Packets_t::const_iterator itArgDeclBase_507= argDeclBases_4f2.begin(), itDT_510= dTs_4f5.begin(), itLastIB_519= lastIBs_4f8.begin(), itCompoundStatement_522= compoundStatements_4fb.begin(), itUnaryExprs_52b= unaryExprss_4fe.begin(); itArgDeclBase_507!= argDeclBases_4f2.end(), itDT_510!= dTs_4f5.end(), itLastIB_519!= lastIBs_4f8.end(), itCompoundStatement_522!= compoundStatements_4fb.end(), itUnaryExprs_52b!= unaryExprss_4fe.end(); ++itArgDeclBase_507, ++itDT_510, ++itLastIB_519, ++itCompoundStatement_522, ++itUnaryExprs_52b)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_507, *itDT_510, *itLastIB_519, *itCompoundStatement_522, *itUnaryExprs_52b);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_507, *itDT_510, *itLastIB_519, *itCompoundStatement_522, *itUnaryExprs_52b);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_534, currMatch.dT_535, currMatch.lastIB_536, currMatch.compoundStatement_537, currMatch.unaryExprs_538);
	}
}

bool Otherwise_4f1::patternMatcher( const Udm::Object& argDeclBase_508, const Udm::Object& dT_511, const Udm::Object& lastIB_51a, const Udm::Object& compoundStatement_523, const Udm::Object& unaryExprs_52c)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_508.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_50d= SFC::ArgDeclBase::Cast( argDeclBase_508);
		if( false== Uml::IsDerivedFrom( dT_511.type(), SFC::DT::meta))
			continue;
		SFC::DT dT_516= SFC::DT::Cast( dT_511);
		if( false== Uml::IsDerivedFrom( lastIB_51a.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock lastIB_51f= SFC::IterativeBlock::Cast( lastIB_51a);
		if( false== Uml::IsDerivedFrom( compoundStatement_523.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_528= SFC::CompoundStatement::Cast( compoundStatement_523);
		if( false== Uml::IsDerivedFrom( unaryExprs_52c.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_531= SFC::UnaryExprs::Cast( unaryExprs_52c);
		Match currMatch;
		currMatch.argDeclBase_534= argDeclBase_50d;
		currMatch.dT_535= dT_516;
		currMatch.lastIB_536= lastIB_51f;
		currMatch.compoundStatement_537= compoundStatement_528;
		currMatch.unaryExprs_538= unaryExprs_531;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Otherwise_4f1::outputAppender( const SFC::ArgDeclBase& argDeclBase_539, const SFC::DT& dT_53b, const SFC::IterativeBlock& lastIB_53d, const SFC::CompoundStatement& compoundStatement_53f, const SFC::UnaryExprs& unaryExprs_541)
{
	_argDeclBase_501->push_back( argDeclBase_539);
	_dT_502->push_back( dT_53b);
	_lastIB_503->push_back( lastIB_53d);
	_compoundStatement_504->push_back( compoundStatement_53f);
	_unaryExprs_505->push_back( unaryExprs_541);
}

void GetStartLoop_55b::operator()( const Packets_t& passADBs_55c, const Packets_t& passCSs_55e, const Packets_t& ues_560, Packets_t& passADBs_562, Packets_t& arrays_563, Packets_t& lastibs_564, Packets_t& passCSs_565, Packets_t& ues_566)
{
#ifdef PRINT_INFO
	std::cout << "GetStartLoop_55b" << std::endl;
#endif
	_passADB_567= &passADBs_562;
	_array_568= &arrays_563;
	_lastib_569= &lastibs_564;
	_passCS_56a= &passCSs_565;
	_ue_56b= &ues_566;
	for( Packets_t::const_iterator itpassADB_56d= passADBs_55c.begin(), itpassCS_574= passCSs_55e.begin(), itue_57b= ues_560.begin(); itpassADB_56d!= passADBs_55c.end(), itpassCS_574!= passCSs_55e.end(), itue_57b!= ues_560.end(); ++itpassADB_56d, ++itpassCS_574, ++itue_57b)
	{
		bool isUnique= isInputUnique( *itpassADB_56d, *itpassCS_574, *itue_57b);
		if( !isUnique)
			continue;
		Packets_t onepassADB_571( 1, *itpassADB_56d);
		Packets_t onepassCS_578( 1, *itpassCS_574);
		Packets_t oneue_57f( 1, *itue_57b);
		executeOne( onepassADB_571, onepassCS_578, oneue_57f);
	}
}

void GetStartLoop_55b::executeOne( const Packets_t& passADBs_55c, const Packets_t& passCSs_55e, const Packets_t& ues_560)
{
	if( ( !passADBs_55c.empty())&& ( !passCSs_55e.empty())&& ( !ues_560.empty()))
		callStartArray_6fd( passADBs_55c, passCSs_55e, ues_560);
}

bool GetStartLoop_55b::isInputUnique( const Udm::Object& passADB_56e, const Udm::Object& passCS_575, const Udm::Object& ue_57c)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_570= _passADB_56c.begin(), itpassCS_577= _passCS_573.begin(), itue_57e= _ue_57a.begin(); itpassADB_570!= _passADB_56c.end(), itpassCS_577!= _passCS_573.end(), itue_57e!= _ue_57a.end(); ++itpassADB_570, ++itpassCS_577, ++itue_57e)
	{
		if( ( *itpassADB_570== passADB_56e)&& ( *itpassCS_577== passCS_575)&& ( *itue_57e== ue_57c))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_56c.push_back( passADB_56e);
		_passCS_573.push_back( passCS_575);
		_ue_57a.push_back( ue_57c);
	}
	return isUnique;
}

void GetStartLoop_55b::callStartArray_6fd( const Packets_t& argDeclBases_6ba, const Packets_t& iterativeBlocks_6be, const Packets_t& unaryExprss_6c2)
{
	Packets_t argDeclBases_6bc;
	Packets_t arrays_6bd;
	Packets_t iterativeBlocks_6c0;
	Packets_t compoundStatements_6c1;
	Packets_t unaryExprss_6c4;
	StartArray_6b9 startArray_6b9;
	startArray_6b9( argDeclBases_6ba, iterativeBlocks_6be, unaryExprss_6c2, argDeclBases_6bc, arrays_6bd, iterativeBlocks_6c0, compoundStatements_6c1, unaryExprss_6c4);
	if( ( !argDeclBases_6bc.empty())&& ( !arrays_6bd.empty())&& ( !iterativeBlocks_6c0.empty())&& ( !compoundStatements_6c1.empty())&& ( !unaryExprss_6c4.empty()))
		callIterateTest_701( argDeclBases_6bc, arrays_6bd, iterativeBlocks_6c0, compoundStatements_6c1, unaryExprss_6c4);
}

void GetStartLoop_55b::callIterateTest_701( const Packets_t& passADBs_5d1, const Packets_t& arrays_5d3, const Packets_t& outeribs_5d5, const Packets_t& css_5d7, const Packets_t& ues_5d9)
{
	Packets_t passADBs_5db;
	Packets_t arrays_5dc;
	Packets_t outeribs_5dd;
	Packets_t css_5de;
	Packets_t ues_5df;
	Packets_t passADBs_5e0;
	Packets_t arrays_5e1;
	Packets_t outeribs_5e2;
	Packets_t css_5e3;
	Packets_t ues_5e4;
	IterateTest_5d0 iterateTest_5d0;
	iterateTest_5d0( passADBs_5d1, arrays_5d3, outeribs_5d5, css_5d7, ues_5d9, passADBs_5db, arrays_5dc, outeribs_5dd, css_5de, ues_5df, passADBs_5e0, arrays_5e1, outeribs_5e2, css_5e3, ues_5e4);
	_passADB_567->insert( _passADB_567->end(), passADBs_5e0.begin(), passADBs_5e0.end());
	_array_568->insert( _array_568->end(), arrays_5e1.begin(), arrays_5e1.end());
	_lastib_569->insert( _lastib_569->end(), outeribs_5e2.begin(), outeribs_5e2.end());
	_passCS_56a->insert( _passCS_56a->end(), css_5e3.begin(), css_5e3.end());
	_ue_56b->insert( _ue_56b->end(), ues_5e4.begin(), ues_5e4.end());
	if( ( !passADBs_5db.empty())&& ( !arrays_5dc.empty())&& ( !css_5de.empty())&& ( !ues_5df.empty()))
		callNextIterate_707( passADBs_5db, arrays_5dc, css_5de, ues_5df);
}

void GetStartLoop_55b::callNextIterate_707( const Packets_t& argDeclBases_582, const Packets_t& arrays_585, const Packets_t& iterativeBlocks_588, const Packets_t& unaryExprss_58c)
{
	Packets_t argDeclBases_584;
	Packets_t arrays_587;
	Packets_t iterativeBlocks_58a;
	Packets_t compoundStatements_58b;
	Packets_t unaryExprss_58e;
	NextIterate_581 nextIterate_581;
	nextIterate_581( argDeclBases_582, arrays_585, iterativeBlocks_588, unaryExprss_58c, argDeclBases_584, arrays_587, iterativeBlocks_58a, compoundStatements_58b, unaryExprss_58e);
	if( ( !argDeclBases_584.empty())&& ( !arrays_587.empty())&& ( !iterativeBlocks_58a.empty())&& ( !compoundStatements_58b.empty())&& ( !unaryExprss_58e.empty()))
		callIterateTest_701( argDeclBases_584, arrays_587, iterativeBlocks_58a, compoundStatements_58b, unaryExprss_58e);
}

void NextIterate_581::operator()( const Packets_t& argDeclBases_582, const Packets_t& arrays_585, const Packets_t& iterativeBlocks_588, const Packets_t& unaryExprss_58c, Packets_t& argDeclBases_584, Packets_t& arrays_587, Packets_t& iterativeBlocks_58a, Packets_t& compoundStatements_58b, Packets_t& unaryExprss_58e)
{
#ifdef PRINT_INFO
	std::cout << "NextIterate_581" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(262, "NextIterate");
	_argDeclBase_58f= &argDeclBases_584;
	_array_590= &arrays_587;
	_iterativeBlock_591= &iterativeBlocks_58a;
	_compoundStatement_592= &compoundStatements_58b;
	_unaryExprs_593= &unaryExprss_58e;
	processInputPackets( argDeclBases_582, arrays_585, iterativeBlocks_588, unaryExprss_58c);
}

bool NextIterate_581::isInputUnique( const Udm::Object& argDeclBase_598, const Udm::Object& array_5a1, const Udm::Object& iterativeBlock_5aa, const Udm::Object& unaryExprs_5b3)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_59a= _argDeclBase_594.begin(), itArray_5a3= _array_59d.begin(), itIterativeBlock_5ac= _iterativeBlock_5a6.begin(), itUnaryExprs_5b5= _unaryExprs_5af.begin(); itArgDeclBase_59a!= _argDeclBase_594.end(), itArray_5a3!= _array_59d.end(), itIterativeBlock_5ac!= _iterativeBlock_5a6.end(), itUnaryExprs_5b5!= _unaryExprs_5af.end(); ++itArgDeclBase_59a, ++itArray_5a3, ++itIterativeBlock_5ac, ++itUnaryExprs_5b5)
	{
		if( ( *itArgDeclBase_59a== argDeclBase_598)&& ( *itArray_5a3== array_5a1)&& ( *itIterativeBlock_5ac== iterativeBlock_5aa)&& ( *itUnaryExprs_5b5== unaryExprs_5b3))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_594.push_back( argDeclBase_598);
		_array_59d.push_back( array_5a1);
		_iterativeBlock_5a6.push_back( iterativeBlock_5aa);
		_unaryExprs_5af.push_back( unaryExprs_5b3);
	}
	return isUnique;
}

bool NextIterate_581::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void NextIterate_581::processInputPackets( const Packets_t& argDeclBases_582, const Packets_t& arrays_585, const Packets_t& iterativeBlocks_588, const Packets_t& unaryExprss_58c)
{
	for( Packets_t::const_iterator itArgDeclBase_595= argDeclBases_582.begin(), itArray_59e= arrays_585.begin(), itIterativeBlock_5a7= iterativeBlocks_588.begin(), itUnaryExprs_5b0= unaryExprss_58c.begin(); itArgDeclBase_595!= argDeclBases_582.end(), itArray_59e!= arrays_585.end(), itIterativeBlock_5a7!= iterativeBlocks_588.end(), itUnaryExprs_5b0!= unaryExprss_58c.end(); ++itArgDeclBase_595, ++itArray_59e, ++itIterativeBlock_5a7, ++itUnaryExprs_5b0)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_595, *itArray_59e, *itIterativeBlock_5a7, *itUnaryExprs_5b0);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_595, *itArray_59e, *itIterativeBlock_5a7, *itUnaryExprs_5b0);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool NextIterate_581::patternMatcher( const Udm::Object& argDeclBase_596, const Udm::Object& array_59f, const Udm::Object& iterativeBlock_5a8, const Udm::Object& unaryExprs_5b1)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_596.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_59b= SFC::ArgDeclBase::Cast( argDeclBase_596);
		if( false== Uml::IsDerivedFrom( array_59f.type(), SFC::Array::meta))
			continue;
		SFC::Array array_5a4= SFC::Array::Cast( array_59f);
		if( false== Uml::IsDerivedFrom( iterativeBlock_5a8.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_5ad= SFC::IterativeBlock::Cast( iterativeBlock_5a8);
		if( false== Uml::IsDerivedFrom( unaryExprs_5b1.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_5b6= SFC::UnaryExprs::Cast( unaryExprs_5b1);
		set< SFC::IterativeBlock> iterativeBlocks_5b8= array_5a4.itb();
		for( set< SFC::IterativeBlock>::const_iterator itIterativeBlocks_5b9= iterativeBlocks_5b8.begin(); itIterativeBlocks_5b9!= iterativeBlocks_5b8.end(); ++itIterativeBlocks_5b9)
		{
			SFC::IterativeBlock currIterativeBlock_5ba= *itIterativeBlocks_5b9;
			if( iterativeBlock_5ad!= currIterativeBlock_5ba)
				continue;
			Udm::Object iterativeBlockParent_5bb= iterativeBlock_5ad.container();
			if( false== Uml::IsDerivedFrom( iterativeBlockParent_5bb.type(), SFC::CompoundStatement::meta))
				continue;
			SFC::CompoundStatement compoundStatementIterativeBlock_5bc= SFC::CompoundStatement::Cast( iterativeBlockParent_5bb);
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_5c0;
			if( !isValidBound(boundObjs_5c0, argDeclBase_59b, true))
				continue;
			currMatch.argDeclBase_5c1= argDeclBase_59b;
			if( !isValidBound(boundObjs_5c0, array_5a4, true))
				continue;
			currMatch.array_5c2= array_5a4;
			if( !isValidBound(boundObjs_5c0, iterativeBlock_5ad, true))
				continue;
			currMatch.iterativeBlock_5c3= iterativeBlock_5ad;
			if( !isValidBound(boundObjs_5c0, unaryExprs_5b6, true))
				continue;
			currMatch.unaryExprs_5c4= unaryExprs_5b6;
			if( !isValidBound(boundObjs_5c0, compoundStatementIterativeBlock_5bc, false))
				continue;
			currMatch.compoundStatement_5c5= compoundStatementIterativeBlock_5bc;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void NextIterate_581::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_5c1, currMatch.array_5c2, currMatch.iterativeBlock_5c3, currMatch.compoundStatement_5c5, currMatch.unaryExprs_5c4);
	}
}

void NextIterate_581::outputAppender( const SFC::ArgDeclBase& argDeclBase_5c6, const SFC::Array& array_5c8, const SFC::IterativeBlock& iterativeBlock_5ca, const SFC::CompoundStatement& compoundStatement_5cc, const SFC::UnaryExprs& unaryExprs_5ce)
{
	_argDeclBase_58f->push_back( argDeclBase_5c6);
	_array_590->push_back( array_5c8);
	_iterativeBlock_591->push_back( iterativeBlock_5ca);
	_compoundStatement_592->push_back( compoundStatement_5cc);
	_unaryExprs_593->push_back( unaryExprs_5ce);
}

void IterateTest_5d0::operator()( const Packets_t& passADBs_5d1, const Packets_t& arrays_5d3, const Packets_t& outeribs_5d5, const Packets_t& css_5d7, const Packets_t& ues_5d9, Packets_t& passADBs_5db, Packets_t& arrays_5dc, Packets_t& outeribs_5dd, Packets_t& css_5de, Packets_t& ues_5df, Packets_t& passADBs_5e0, Packets_t& arrays_5e1, Packets_t& outeribs_5e2, Packets_t& css_5e3, Packets_t& ues_5e4)
{
#ifdef PRINT_INFO
	std::cout << "IterateTest_5d0" << std::endl;
#endif
	_passADB_5e5= &passADBs_5db;
	_array_5e6= &arrays_5dc;
	_outerib_5e7= &outeribs_5dd;
	_cs_5e8= &css_5de;
	_ue_5e9= &ues_5df;
	_passADB_5ea= &passADBs_5e0;
	_array_5eb= &arrays_5e1;
	_outerib_5ec= &outeribs_5e2;
	_cs_5ed= &css_5e3;
	_ue_5ee= &ues_5e4;
	for( Packets_t::const_iterator itpassADB_5f0= passADBs_5d1.begin(), itarray_5f7= arrays_5d3.begin(), itouterib_5fe= outeribs_5d5.begin(), itcs_605= css_5d7.begin(), itue_60c= ues_5d9.begin(); itpassADB_5f0!= passADBs_5d1.end(), itarray_5f7!= arrays_5d3.end(), itouterib_5fe!= outeribs_5d5.end(), itcs_605!= css_5d7.end(), itue_60c!= ues_5d9.end(); ++itpassADB_5f0, ++itarray_5f7, ++itouterib_5fe, ++itcs_605, ++itue_60c)
	{
		bool isUnique= isInputUnique( *itpassADB_5f0, *itarray_5f7, *itouterib_5fe, *itcs_605, *itue_60c);
		if( !isUnique)
			continue;
		Packets_t onepassADB_5f4( 1, *itpassADB_5f0);
		Packets_t onearray_5fb( 1, *itarray_5f7);
		Packets_t oneouterib_602( 1, *itouterib_5fe);
		Packets_t onecs_609( 1, *itcs_605);
		Packets_t oneue_610( 1, *itue_60c);
		executeOne( onepassADB_5f4, onearray_5fb, oneouterib_602, onecs_609, oneue_610);
	}
}

void IterateTest_5d0::executeOne( const Packets_t& passADBs_5d1, const Packets_t& arrays_5d3, const Packets_t& outeribs_5d5, const Packets_t& css_5d7, const Packets_t& ues_5d9)
{
	Packets_t argDeclBases_615;
	Packets_t arrays_618;
	Packets_t outerIBs_61b;
	Packets_t iterativeBlocks_61e;
	Packets_t unaryExprss_621;
	IterativeBlock_612 iterativeBlock_612;
	bool isMatchIterativeBlock_612= iterativeBlock_612( passADBs_5d1, arrays_5d3, outeribs_5d5, css_5d7, ues_5d9, argDeclBases_615, arrays_618, outerIBs_61b, iterativeBlocks_61e, unaryExprss_621);
	_passADB_5e5->insert( _passADB_5e5->end(), argDeclBases_615.begin(), argDeclBases_615.end());
	_array_5e6->insert( _array_5e6->end(), arrays_618.begin(), arrays_618.end());
	_outerib_5e7->insert( _outerib_5e7->end(), outerIBs_61b.begin(), outerIBs_61b.end());
	_cs_5e8->insert( _cs_5e8->end(), iterativeBlocks_61e.begin(), iterativeBlocks_61e.end());
	_ue_5e9->insert( _ue_5e9->end(), unaryExprss_621.begin(), unaryExprss_621.end());
	if( isMatchIterativeBlock_612)
		return;
	Packets_t argDeclBases_66a;
	Packets_t arrays_66d;
	Packets_t outerIBs_670;
	Packets_t compoundStatements_673;
	Packets_t unaryExprss_676;
	Otherwise_667 otherwise_667;
	bool isMatchOtherwise_667= otherwise_667( passADBs_5d1, arrays_5d3, outeribs_5d5, css_5d7, ues_5d9, argDeclBases_66a, arrays_66d, outerIBs_670, compoundStatements_673, unaryExprss_676);
	_passADB_5ea->insert( _passADB_5ea->end(), argDeclBases_66a.begin(), argDeclBases_66a.end());
	_array_5eb->insert( _array_5eb->end(), arrays_66d.begin(), arrays_66d.end());
	_outerib_5ec->insert( _outerib_5ec->end(), outerIBs_670.begin(), outerIBs_670.end());
	_cs_5ed->insert( _cs_5ed->end(), compoundStatements_673.begin(), compoundStatements_673.end());
	_ue_5ee->insert( _ue_5ee->end(), unaryExprss_676.begin(), unaryExprss_676.end());
	if( isMatchOtherwise_667)
		return;
}

bool IterateTest_5d0::isInputUnique( const Udm::Object& passADB_5f1, const Udm::Object& array_5f8, const Udm::Object& outerib_5ff, const Udm::Object& cs_606, const Udm::Object& ue_60d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_5f3= _passADB_5ef.begin(), itarray_5fa= _array_5f6.begin(), itouterib_601= _outerib_5fd.begin(), itcs_608= _cs_604.begin(), itue_60f= _ue_60b.begin(); itpassADB_5f3!= _passADB_5ef.end(), itarray_5fa!= _array_5f6.end(), itouterib_601!= _outerib_5fd.end(), itcs_608!= _cs_604.end(), itue_60f!= _ue_60b.end(); ++itpassADB_5f3, ++itarray_5fa, ++itouterib_601, ++itcs_608, ++itue_60f)
	{
		if( ( *itpassADB_5f3== passADB_5f1)&& ( *itarray_5fa== array_5f8)&& ( *itouterib_601== outerib_5ff)&& ( *itcs_608== cs_606)&& ( *itue_60f== ue_60d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_5ef.push_back( passADB_5f1);
		_array_5f6.push_back( array_5f8);
		_outerib_5fd.push_back( outerib_5ff);
		_cs_604.push_back( cs_606);
		_ue_60b.push_back( ue_60d);
	}
	return isUnique;
}

bool IterativeBlock_612::operator()( const Packets_t& argDeclBases_613, const Packets_t& arrays_616, const Packets_t& outerIBs_619, const Packets_t& iterativeBlocks_61c, const Packets_t& unaryExprss_61f, Packets_t& argDeclBases_615, Packets_t& arrays_618, Packets_t& outerIBs_61b, Packets_t& iterativeBlocks_61e, Packets_t& unaryExprss_621)
{
#ifdef PRINT_INFO
	std::cout << "IterativeBlock_612" << std::endl;
#endif
	_argDeclBase_622= &argDeclBases_615;
	_array_623= &arrays_618;
	_outerIB_624= &outerIBs_61b;
	_iterativeBlock_625= &iterativeBlocks_61e;
	_unaryExprs_626= &unaryExprss_621;
	processInputPackets( argDeclBases_613, arrays_616, outerIBs_619, iterativeBlocks_61c, unaryExprss_61f);
	if( false== _matches.empty())
		return true;
	return false;
}

bool IterativeBlock_612::isInputUnique( const Udm::Object& argDeclBase_62b, const Udm::Object& array_634, const Udm::Object& outerIB_63d, const Udm::Object& iterativeBlock_646, const Udm::Object& unaryExprs_64f)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_62d= _argDeclBase_627.begin(), itArray_636= _array_630.begin(), itOuterIB_63f= _outerIB_639.begin(), itIterativeBlock_648= _iterativeBlock_642.begin(), itUnaryExprs_651= _unaryExprs_64b.begin(); itArgDeclBase_62d!= _argDeclBase_627.end(), itArray_636!= _array_630.end(), itOuterIB_63f!= _outerIB_639.end(), itIterativeBlock_648!= _iterativeBlock_642.end(), itUnaryExprs_651!= _unaryExprs_64b.end(); ++itArgDeclBase_62d, ++itArray_636, ++itOuterIB_63f, ++itIterativeBlock_648, ++itUnaryExprs_651)
	{
		if( ( *itArgDeclBase_62d== argDeclBase_62b)&& ( *itArray_636== array_634)&& ( *itOuterIB_63f== outerIB_63d)&& ( *itIterativeBlock_648== iterativeBlock_646)&& ( *itUnaryExprs_651== unaryExprs_64f))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_627.push_back( argDeclBase_62b);
		_array_630.push_back( array_634);
		_outerIB_639.push_back( outerIB_63d);
		_iterativeBlock_642.push_back( iterativeBlock_646);
		_unaryExprs_64b.push_back( unaryExprs_64f);
	}
	return isUnique;
}

void IterativeBlock_612::processInputPackets( const Packets_t& argDeclBases_613, const Packets_t& arrays_616, const Packets_t& outerIBs_619, const Packets_t& iterativeBlocks_61c, const Packets_t& unaryExprss_61f)
{
	for( Packets_t::const_iterator itArgDeclBase_628= argDeclBases_613.begin(), itArray_631= arrays_616.begin(), itOuterIB_63a= outerIBs_619.begin(), itIterativeBlock_643= iterativeBlocks_61c.begin(), itUnaryExprs_64c= unaryExprss_61f.begin(); itArgDeclBase_628!= argDeclBases_613.end(), itArray_631!= arrays_616.end(), itOuterIB_63a!= outerIBs_619.end(), itIterativeBlock_643!= iterativeBlocks_61c.end(), itUnaryExprs_64c!= unaryExprss_61f.end(); ++itArgDeclBase_628, ++itArray_631, ++itOuterIB_63a, ++itIterativeBlock_643, ++itUnaryExprs_64c)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_628, *itArray_631, *itOuterIB_63a, *itIterativeBlock_643, *itUnaryExprs_64c);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_628, *itArray_631, *itOuterIB_63a, *itIterativeBlock_643, *itUnaryExprs_64c);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_658, currMatch.array_659, currMatch.outerIB_65a, currMatch.iterativeBlock_65b, currMatch.unaryExprs_65c);
	}
}

bool IterativeBlock_612::patternMatcher( const Udm::Object& argDeclBase_629, const Udm::Object& array_632, const Udm::Object& outerIB_63b, const Udm::Object& iterativeBlock_644, const Udm::Object& unaryExprs_64d)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_629.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_62e= SFC::ArgDeclBase::Cast( argDeclBase_629);
		if( false== Uml::IsDerivedFrom( array_632.type(), SFC::Array::meta))
			continue;
		SFC::Array array_637= SFC::Array::Cast( array_632);
		if( false== Uml::IsDerivedFrom( outerIB_63b.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock outerIB_640= SFC::IterativeBlock::Cast( outerIB_63b);
		if( false== Uml::IsDerivedFrom( iterativeBlock_644.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_649= SFC::IterativeBlock::Cast( iterativeBlock_644);
		if( false== Uml::IsDerivedFrom( unaryExprs_64d.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_652= SFC::UnaryExprs::Cast( unaryExprs_64d);
		set< SFC::IterativeBlock> iterativeBlocks_654= array_637.itb();
		for( set< SFC::IterativeBlock>::const_iterator itIterativeBlocks_655= iterativeBlocks_654.begin(); itIterativeBlocks_655!= iterativeBlocks_654.end(); ++itIterativeBlocks_655)
		{
			SFC::IterativeBlock currIterativeBlock_656= *itIterativeBlocks_655;
			if( iterativeBlock_649!= currIterativeBlock_656)
				continue;
			Match currMatch;
			currMatch.argDeclBase_658= argDeclBase_62e;
			currMatch.array_659= array_637;
			currMatch.outerIB_65a= outerIB_640;
			currMatch.iterativeBlock_65b= iterativeBlock_649;
			currMatch.unaryExprs_65c= unaryExprs_652;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void IterativeBlock_612::outputAppender( const SFC::ArgDeclBase& argDeclBase_65d, const SFC::Array& array_65f, const SFC::IterativeBlock& outerIB_661, const SFC::IterativeBlock& iterativeBlock_663, const SFC::UnaryExprs& unaryExprs_665)
{
	_argDeclBase_622->push_back( argDeclBase_65d);
	_array_623->push_back( array_65f);
	_outerIB_624->push_back( outerIB_661);
	_iterativeBlock_625->push_back( iterativeBlock_663);
	_unaryExprs_626->push_back( unaryExprs_665);
}

bool Otherwise_667::operator()( const Packets_t& argDeclBases_668, const Packets_t& arrays_66b, const Packets_t& outerIBs_66e, const Packets_t& compoundStatements_671, const Packets_t& unaryExprss_674, Packets_t& argDeclBases_66a, Packets_t& arrays_66d, Packets_t& outerIBs_670, Packets_t& compoundStatements_673, Packets_t& unaryExprss_676)
{
#ifdef PRINT_INFO
	std::cout << "Otherwise_667" << std::endl;
#endif
	_argDeclBase_677= &argDeclBases_66a;
	_array_678= &arrays_66d;
	_outerIB_679= &outerIBs_670;
	_compoundStatement_67a= &compoundStatements_673;
	_unaryExprs_67b= &unaryExprss_676;
	processInputPackets( argDeclBases_668, arrays_66b, outerIBs_66e, compoundStatements_671, unaryExprss_674);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Otherwise_667::isInputUnique( const Udm::Object& argDeclBase_680, const Udm::Object& array_689, const Udm::Object& outerIB_692, const Udm::Object& compoundStatement_69b, const Udm::Object& unaryExprs_6a4)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_682= _argDeclBase_67c.begin(), itArray_68b= _array_685.begin(), itOuterIB_694= _outerIB_68e.begin(), itCompoundStatement_69d= _compoundStatement_697.begin(), itUnaryExprs_6a6= _unaryExprs_6a0.begin(); itArgDeclBase_682!= _argDeclBase_67c.end(), itArray_68b!= _array_685.end(), itOuterIB_694!= _outerIB_68e.end(), itCompoundStatement_69d!= _compoundStatement_697.end(), itUnaryExprs_6a6!= _unaryExprs_6a0.end(); ++itArgDeclBase_682, ++itArray_68b, ++itOuterIB_694, ++itCompoundStatement_69d, ++itUnaryExprs_6a6)
	{
		if( ( *itArgDeclBase_682== argDeclBase_680)&& ( *itArray_68b== array_689)&& ( *itOuterIB_694== outerIB_692)&& ( *itCompoundStatement_69d== compoundStatement_69b)&& ( *itUnaryExprs_6a6== unaryExprs_6a4))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_67c.push_back( argDeclBase_680);
		_array_685.push_back( array_689);
		_outerIB_68e.push_back( outerIB_692);
		_compoundStatement_697.push_back( compoundStatement_69b);
		_unaryExprs_6a0.push_back( unaryExprs_6a4);
	}
	return isUnique;
}

void Otherwise_667::processInputPackets( const Packets_t& argDeclBases_668, const Packets_t& arrays_66b, const Packets_t& outerIBs_66e, const Packets_t& compoundStatements_671, const Packets_t& unaryExprss_674)
{
	for( Packets_t::const_iterator itArgDeclBase_67d= argDeclBases_668.begin(), itArray_686= arrays_66b.begin(), itOuterIB_68f= outerIBs_66e.begin(), itCompoundStatement_698= compoundStatements_671.begin(), itUnaryExprs_6a1= unaryExprss_674.begin(); itArgDeclBase_67d!= argDeclBases_668.end(), itArray_686!= arrays_66b.end(), itOuterIB_68f!= outerIBs_66e.end(), itCompoundStatement_698!= compoundStatements_671.end(), itUnaryExprs_6a1!= unaryExprss_674.end(); ++itArgDeclBase_67d, ++itArray_686, ++itOuterIB_68f, ++itCompoundStatement_698, ++itUnaryExprs_6a1)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_67d, *itArray_686, *itOuterIB_68f, *itCompoundStatement_698, *itUnaryExprs_6a1);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_67d, *itArray_686, *itOuterIB_68f, *itCompoundStatement_698, *itUnaryExprs_6a1);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_6aa, currMatch.array_6ab, currMatch.outerIB_6ac, currMatch.compoundStatement_6ad, currMatch.unaryExprs_6ae);
	}
}

bool Otherwise_667::patternMatcher( const Udm::Object& argDeclBase_67e, const Udm::Object& array_687, const Udm::Object& outerIB_690, const Udm::Object& compoundStatement_699, const Udm::Object& unaryExprs_6a2)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_67e.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_683= SFC::ArgDeclBase::Cast( argDeclBase_67e);
		if( false== Uml::IsDerivedFrom( array_687.type(), SFC::Array::meta))
			continue;
		SFC::Array array_68c= SFC::Array::Cast( array_687);
		if( false== Uml::IsDerivedFrom( outerIB_690.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock outerIB_695= SFC::IterativeBlock::Cast( outerIB_690);
		if( false== Uml::IsDerivedFrom( compoundStatement_699.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_69e= SFC::CompoundStatement::Cast( compoundStatement_699);
		if( false== Uml::IsDerivedFrom( unaryExprs_6a2.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_6a7= SFC::UnaryExprs::Cast( unaryExprs_6a2);
		Match currMatch;
		currMatch.argDeclBase_6aa= argDeclBase_683;
		currMatch.array_6ab= array_68c;
		currMatch.outerIB_6ac= outerIB_695;
		currMatch.compoundStatement_6ad= compoundStatement_69e;
		currMatch.unaryExprs_6ae= unaryExprs_6a7;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Otherwise_667::outputAppender( const SFC::ArgDeclBase& argDeclBase_6af, const SFC::Array& array_6b1, const SFC::IterativeBlock& outerIB_6b3, const SFC::CompoundStatement& compoundStatement_6b5, const SFC::UnaryExprs& unaryExprs_6b7)
{
	_argDeclBase_677->push_back( argDeclBase_6af);
	_array_678->push_back( array_6b1);
	_outerIB_679->push_back( outerIB_6b3);
	_compoundStatement_67a->push_back( compoundStatement_6b5);
	_unaryExprs_67b->push_back( unaryExprs_6b7);
}

void StartArray_6b9::operator()( const Packets_t& argDeclBases_6ba, const Packets_t& iterativeBlocks_6be, const Packets_t& unaryExprss_6c2, Packets_t& argDeclBases_6bc, Packets_t& arrays_6bd, Packets_t& iterativeBlocks_6c0, Packets_t& compoundStatements_6c1, Packets_t& unaryExprss_6c4)
{
#ifdef PRINT_INFO
	std::cout << "StartArray_6b9" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(299, "StartArray");
	_argDeclBase_6c5= &argDeclBases_6bc;
	_array_6c6= &arrays_6bd;
	_iterativeBlock_6c7= &iterativeBlocks_6c0;
	_compoundStatement_6c8= &compoundStatements_6c1;
	_unaryExprs_6c9= &unaryExprss_6c4;
	processInputPackets( argDeclBases_6ba, iterativeBlocks_6be, unaryExprss_6c2);
}

bool StartArray_6b9::isInputUnique( const Udm::Object& argDeclBase_6ce, const Udm::Object& iterativeBlock_6d7, const Udm::Object& unaryExprs_6e0)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_6d0= _argDeclBase_6ca.begin(), itIterativeBlock_6d9= _iterativeBlock_6d3.begin(), itUnaryExprs_6e2= _unaryExprs_6dc.begin(); itArgDeclBase_6d0!= _argDeclBase_6ca.end(), itIterativeBlock_6d9!= _iterativeBlock_6d3.end(), itUnaryExprs_6e2!= _unaryExprs_6dc.end(); ++itArgDeclBase_6d0, ++itIterativeBlock_6d9, ++itUnaryExprs_6e2)
	{
		if( ( *itArgDeclBase_6d0== argDeclBase_6ce)&& ( *itIterativeBlock_6d9== iterativeBlock_6d7)&& ( *itUnaryExprs_6e2== unaryExprs_6e0))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_6ca.push_back( argDeclBase_6ce);
		_iterativeBlock_6d3.push_back( iterativeBlock_6d7);
		_unaryExprs_6dc.push_back( unaryExprs_6e0);
	}
	return isUnique;
}

bool StartArray_6b9::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void StartArray_6b9::processInputPackets( const Packets_t& argDeclBases_6ba, const Packets_t& iterativeBlocks_6be, const Packets_t& unaryExprss_6c2)
{
	for( Packets_t::const_iterator itArgDeclBase_6cb= argDeclBases_6ba.begin(), itIterativeBlock_6d4= iterativeBlocks_6be.begin(), itUnaryExprs_6dd= unaryExprss_6c2.begin(); itArgDeclBase_6cb!= argDeclBases_6ba.end(), itIterativeBlock_6d4!= iterativeBlocks_6be.end(), itUnaryExprs_6dd!= unaryExprss_6c2.end(); ++itArgDeclBase_6cb, ++itIterativeBlock_6d4, ++itUnaryExprs_6dd)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_6cb, *itIterativeBlock_6d4, *itUnaryExprs_6dd);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_6cb, *itIterativeBlock_6d4, *itUnaryExprs_6dd);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool StartArray_6b9::patternMatcher( const Udm::Object& argDeclBase_6cc, const Udm::Object& iterativeBlock_6d5, const Udm::Object& unaryExprs_6de)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_6cc.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_6d1= SFC::ArgDeclBase::Cast( argDeclBase_6cc);
		if( false== Uml::IsDerivedFrom( iterativeBlock_6d5.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_6da= SFC::IterativeBlock::Cast( iterativeBlock_6d5);
		if( false== Uml::IsDerivedFrom( unaryExprs_6de.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_6e3= SFC::UnaryExprs::Cast( unaryExprs_6de);
		Udm::Object iterativeBlockParent_6e5= iterativeBlock_6da.container();
		if( false== Uml::IsDerivedFrom( iterativeBlockParent_6e5.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatementIterativeBlock_6e6= SFC::CompoundStatement::Cast( iterativeBlockParent_6e5);
		set< SFC::Array> arrays_6e7= iterativeBlock_6da.ary();
		for( set< SFC::Array>::const_iterator itArrays_6e8= arrays_6e7.begin(); itArrays_6e8!= arrays_6e7.end(); ++itArrays_6e8)
		{
			SFC::Array currArray_6e9= *itArrays_6e8;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_6ed;
			if( !isValidBound(boundObjs_6ed, argDeclBase_6d1, true))
				continue;
			currMatch.argDeclBase_6ee= argDeclBase_6d1;
			if( !isValidBound(boundObjs_6ed, iterativeBlock_6da, true))
				continue;
			currMatch.iterativeBlock_6ef= iterativeBlock_6da;
			if( !isValidBound(boundObjs_6ed, unaryExprs_6e3, true))
				continue;
			currMatch.unaryExprs_6f0= unaryExprs_6e3;
			if( !isValidBound(boundObjs_6ed, currArray_6e9, false))
				continue;
			currMatch.array_6f1= currArray_6e9;
			if( !isValidBound(boundObjs_6ed, compoundStatementIterativeBlock_6e6, false))
				continue;
			currMatch.compoundStatement_6f2= compoundStatementIterativeBlock_6e6;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void StartArray_6b9::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_6ee, currMatch.array_6f1, currMatch.iterativeBlock_6ef, currMatch.compoundStatement_6f2, currMatch.unaryExprs_6f0);
	}
}

void StartArray_6b9::outputAppender( const SFC::ArgDeclBase& argDeclBase_6f3, const SFC::Array& array_6f5, const SFC::IterativeBlock& iterativeBlock_6f7, const SFC::CompoundStatement& compoundStatement_6f9, const SFC::UnaryExprs& unaryExprs_6fb)
{
	_argDeclBase_6c5->push_back( argDeclBase_6f3);
	_array_6c6->push_back( array_6f5);
	_iterativeBlock_6c7->push_back( iterativeBlock_6f7);
	_compoundStatement_6c8->push_back( compoundStatement_6f9);
	_unaryExprs_6c9->push_back( unaryExprs_6fb);
}

void SkipArray_716::operator()( const Packets_t& argDeclBases_717, const Packets_t& arrays_71a, const Packets_t& mains_71d, Packets_t& argDeclBases_719, Packets_t& dTs_71c, Packets_t& mains_71f)
{
#ifdef PRINT_INFO
	std::cout << "SkipArray_716" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(307, "SkipArray");
	_argDeclBase_720= &argDeclBases_719;
	_dT_721= &dTs_71c;
	_main_722= &mains_71f;
	processInputPackets( argDeclBases_717, arrays_71a, mains_71d);
}

bool SkipArray_716::isInputUnique( const Udm::Object& argDeclBase_727, const Udm::Object& array_730, const Udm::Object& main_739)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_729= _argDeclBase_723.begin(), itArray_732= _array_72c.begin(), itMain_73b= _main_735.begin(); itArgDeclBase_729!= _argDeclBase_723.end(), itArray_732!= _array_72c.end(), itMain_73b!= _main_735.end(); ++itArgDeclBase_729, ++itArray_732, ++itMain_73b)
	{
		if( ( *itArgDeclBase_729== argDeclBase_727)&& ( *itArray_732== array_730)&& ( *itMain_73b== main_739))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_723.push_back( argDeclBase_727);
		_array_72c.push_back( array_730);
		_main_735.push_back( main_739);
	}
	return isUnique;
}

void SkipArray_716::processInputPackets( const Packets_t& argDeclBases_717, const Packets_t& arrays_71a, const Packets_t& mains_71d)
{
	for( Packets_t::const_iterator itArgDeclBase_724= argDeclBases_717.begin(), itArray_72d= arrays_71a.begin(), itMain_736= mains_71d.begin(); itArgDeclBase_724!= argDeclBases_717.end(), itArray_72d!= arrays_71a.end(), itMain_736!= mains_71d.end(); ++itArgDeclBase_724, ++itArray_72d, ++itMain_736)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_724, *itArray_72d, *itMain_736);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_724, *itArray_72d, *itMain_736);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool SkipArray_716::patternMatcher( const Udm::Object& argDeclBase_725, const Udm::Object& array_72e, const Udm::Object& main_737)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_725.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_72a= SFC::ArgDeclBase::Cast( argDeclBase_725);
		if( false== Uml::IsDerivedFrom( array_72e.type(), SFC::Array::meta))
			continue;
		SFC::Array array_733= SFC::Array::Cast( array_72e);
		if( false== Uml::IsDerivedFrom( main_737.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_73c= SFC::CompoundStatement::Cast( main_737);
		SFC::DT dT_73e= array_733.dt();
		if( !dT_73e)
			continue;
		Match currMatch;
		currMatch.argDeclBase_740= argDeclBase_72a;
		currMatch.array_741= array_733;
		currMatch.main_742= main_73c;
		currMatch.dT_743= dT_73e;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void SkipArray_716::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_740, currMatch.dT_743, currMatch.main_742);
	}
}

void SkipArray_716::outputAppender( const SFC::ArgDeclBase& argDeclBase_744, const SFC::DT& dT_746, const SFC::CompoundStatement& main_748)
{
	_argDeclBase_720->push_back( argDeclBase_744);
	_dT_721->push_back( dT_746);
	_main_722->push_back( main_748);
}

void ColumnMajor_74a::operator()( const Packets_t& passADBs_74b, const Packets_t& toparrays_74d, const Packets_t& dts_74f, const Packets_t& mains_751, Packets_t& passADBs_753, Packets_t& dts_754, Packets_t& mains_755)
{
#ifdef PRINT_INFO
	std::cout << "ColumnMajor_74a" << std::endl;
#endif
	_passADB_756= &passADBs_753;
	_dt_757= &dts_754;
	_main_758= &mains_755;
	for( Packets_t::const_iterator itPassADB_75a= passADBs_74b.begin(), ittoparray_761= toparrays_74d.begin(), itdt_768= dts_74f.begin(), itMain_76f= mains_751.begin(); itPassADB_75a!= passADBs_74b.end(), ittoparray_761!= toparrays_74d.end(), itdt_768!= dts_74f.end(), itMain_76f!= mains_751.end(); ++itPassADB_75a, ++ittoparray_761, ++itdt_768, ++itMain_76f)
	{
		bool isUnique= isInputUnique( *itPassADB_75a, *ittoparray_761, *itdt_768, *itMain_76f);
		if( !isUnique)
			continue;
		Packets_t onePassADB_75e( 1, *itPassADB_75a);
		Packets_t onetoparray_765( 1, *ittoparray_761);
		Packets_t onedt_76c( 1, *itdt_768);
		Packets_t oneMain_773( 1, *itMain_76f);
		executeOne( onePassADB_75e, onetoparray_765, onedt_76c, oneMain_773);
	}
}

void ColumnMajor_74a::executeOne( const Packets_t& passADBs_74b, const Packets_t& toparrays_74d, const Packets_t& dts_74f, const Packets_t& mains_751)
{
	if( ( !passADBs_74b.empty())&& ( !toparrays_74d.empty())&& ( !dts_74f.empty())&& ( !mains_751.empty()))
		callArrayTest_a01( passADBs_74b, toparrays_74d, dts_74f, mains_751);
}

bool ColumnMajor_74a::isInputUnique( const Udm::Object& passADB_75b, const Udm::Object& toparray_762, const Udm::Object& dt_769, const Udm::Object& main_770)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itPassADB_75d= _passADB_759.begin(), ittoparray_764= _toparray_760.begin(), itdt_76b= _dt_767.begin(), itMain_772= _main_76e.begin(); itPassADB_75d!= _passADB_759.end(), ittoparray_764!= _toparray_760.end(), itdt_76b!= _dt_767.end(), itMain_772!= _main_76e.end(); ++itPassADB_75d, ++ittoparray_764, ++itdt_76b, ++itMain_772)
	{
		if( ( *itPassADB_75d== passADB_75b)&& ( *ittoparray_764== toparray_762)&& ( *itdt_76b== dt_769)&& ( *itMain_772== main_770))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_759.push_back( passADB_75b);
		_toparray_760.push_back( toparray_762);
		_dt_767.push_back( dt_769);
		_main_76e.push_back( main_770);
	}
	return isUnique;
}

void ColumnMajor_74a::callArrayTest_a01( const Packets_t& passADBs_8fb, const Packets_t& topArrays_8fd, const Packets_t& dts_8ff, const Packets_t& mains_901)
{
	Packets_t passADBs_903;
	Packets_t toparrays_904;
	Packets_t nullarrays_905;
	Packets_t mains_906;
	Packets_t passADBs_907;
	Packets_t toparrays_908;
	Packets_t arrays_909;
	Packets_t mains_90a;
	Packets_t passADBs_90b;
	Packets_t toparrays_90c;
	Packets_t dts_90d;
	Packets_t mains_90e;
	ArrayTest_8fa arrayTest_8fa;
	arrayTest_8fa( passADBs_8fb, topArrays_8fd, dts_8ff, mains_901, passADBs_903, toparrays_904, nullarrays_905, mains_906, passADBs_907, toparrays_908, arrays_909, mains_90a, passADBs_90b, toparrays_90c, dts_90d, mains_90e);
	if( ( !passADBs_90b.empty())&& ( !toparrays_90c.empty())&& ( !dts_90d.empty())&& ( !mains_90e.empty()))
		callAddLoopBounds_a06( passADBs_90b, toparrays_90c, dts_90d, mains_90e);
	if( ( !passADBs_907.empty())&& ( !toparrays_908.empty())&& ( !arrays_909.empty())&& ( !mains_90a.empty()))
		callMakeArrayLoop_a0b( passADBs_907, toparrays_908, arrays_909, mains_90a);
	if( ( !passADBs_903.empty())&& ( !toparrays_904.empty())&& ( !nullarrays_905.empty())&& ( !mains_906.empty()))
		callSkipArray_a10( passADBs_903, toparrays_904, nullarrays_905, mains_906);
}

void ColumnMajor_74a::callAddLoopBounds_a06( const Packets_t& passADBs_776, const Packets_t& toparrays_778, const Packets_t& dts_77a, const Packets_t& mains_77c)
{
	Packets_t passADBs_77e;
	Packets_t dts_77f;
	Packets_t mains_780;
	AddLoopBounds_775 addLoopBounds_775;
	addLoopBounds_775( passADBs_776, toparrays_778, dts_77a, mains_77c, passADBs_77e, dts_77f, mains_780);
	_passADB_756->insert( _passADB_756->end(), passADBs_77e.begin(), passADBs_77e.end());
	_dt_757->insert( _dt_757->end(), dts_77f.begin(), dts_77f.end());
	_main_758->insert( _main_758->end(), mains_780.begin(), mains_780.end());
}

void ColumnMajor_74a::callMakeArrayLoop_a0b( const Packets_t& argDeclBases_869, const Packets_t& topArrays_86c, const Packets_t& arrays_86f, const Packets_t& mains_872)
{
	Packets_t argDeclBases_86b;
	Packets_t topArrays_86e;
	Packets_t dTs_871;
	Packets_t loops_874;
	MakeArrayLoop_868 makeArrayLoop_868;
	makeArrayLoop_868( argDeclBases_869, topArrays_86c, arrays_86f, mains_872, argDeclBases_86b, topArrays_86e, dTs_871, loops_874);
	if( ( !argDeclBases_86b.empty())&& ( !topArrays_86e.empty())&& ( !dTs_871.empty())&& ( !loops_874.empty()))
		callArrayTest_a01( argDeclBases_86b, topArrays_86e, dTs_871, loops_874);
}

void ColumnMajor_74a::callSkipArray_a10( const Packets_t& argDeclBases_8b7, const Packets_t& topArrays_8ba, const Packets_t& arrays_8bd, const Packets_t& mains_8c0)
{
	Packets_t argDeclBases_8b9;
	Packets_t topArrays_8bc;
	Packets_t dTs_8bf;
	Packets_t mains_8c2;
	SkipArray_8b6 skipArray_8b6;
	skipArray_8b6( argDeclBases_8b7, topArrays_8ba, arrays_8bd, mains_8c0, argDeclBases_8b9, topArrays_8bc, dTs_8bf, mains_8c2);
	if( ( !argDeclBases_8b9.empty())&& ( !topArrays_8bc.empty())&& ( !dTs_8bf.empty())&& ( !mains_8c2.empty()))
		callArrayTest_a01( argDeclBases_8b9, topArrays_8bc, dTs_8bf, mains_8c2);
}

void AddLoopBounds_775::operator()( const Packets_t& passADBs_776, const Packets_t& toparrays_778, const Packets_t& dts_77a, const Packets_t& mains_77c, Packets_t& passADBs_77e, Packets_t& dts_77f, Packets_t& mains_780)
{
#ifdef PRINT_INFO
	std::cout << "AddLoopBounds_775" << std::endl;
#endif
	_passADB_781= &passADBs_77e;
	_dt_782= &dts_77f;
	_main_783= &mains_780;
	for( Packets_t::const_iterator itPassADB_785= passADBs_776.begin(), ittoparray_78c= toparrays_778.begin(), itdt_793= dts_77a.begin(), itMain_79a= mains_77c.begin(); itPassADB_785!= passADBs_776.end(), ittoparray_78c!= toparrays_778.end(), itdt_793!= dts_77a.end(), itMain_79a!= mains_77c.end(); ++itPassADB_785, ++ittoparray_78c, ++itdt_793, ++itMain_79a)
	{
		bool isUnique= isInputUnique( *itPassADB_785, *ittoparray_78c, *itdt_793, *itMain_79a);
		if( !isUnique)
			continue;
		Packets_t onePassADB_789( 1, *itPassADB_785);
		Packets_t onetoparray_790( 1, *ittoparray_78c);
		Packets_t onedt_797( 1, *itdt_793);
		Packets_t oneMain_79e( 1, *itMain_79a);
		executeOne( onePassADB_789, onetoparray_790, onedt_797, oneMain_79e);
	}
}

void AddLoopBounds_775::executeOne( const Packets_t& passADBs_776, const Packets_t& toparrays_778, const Packets_t& dts_77a, const Packets_t& mains_77c)
{
	_passADB_781->insert( _passADB_781->end(), passADBs_776.begin(), passADBs_776.end());
	_dt_782->insert( _dt_782->end(), dts_77a.begin(), dts_77a.end());
	_main_783->insert( _main_783->end(), mains_77c.begin(), mains_77c.end());
	if( ( !toparrays_778.empty())&& ( !mains_77c.empty()))
		callArrayTest_85f( toparrays_778, mains_77c);
}

bool AddLoopBounds_775::isInputUnique( const Udm::Object& passADB_786, const Udm::Object& toparray_78d, const Udm::Object& dt_794, const Udm::Object& main_79b)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itPassADB_788= _passADB_784.begin(), ittoparray_78f= _toparray_78b.begin(), itdt_796= _dt_792.begin(), itMain_79d= _main_799.begin(); itPassADB_788!= _passADB_784.end(), ittoparray_78f!= _toparray_78b.end(), itdt_796!= _dt_792.end(), itMain_79d!= _main_799.end(); ++itPassADB_788, ++ittoparray_78f, ++itdt_796, ++itMain_79d)
	{
		if( ( *itPassADB_788== passADB_786)&& ( *ittoparray_78f== toparray_78d)&& ( *itdt_796== dt_794)&& ( *itMain_79d== main_79b))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_784.push_back( passADB_786);
		_toparray_78b.push_back( toparray_78d);
		_dt_792.push_back( dt_794);
		_main_799.push_back( main_79b);
	}
	return isUnique;
}

void AddLoopBounds_775::callArrayTest_85f( const Packets_t& dts_7db, const Packets_t& mains_7dd)
{
	Packets_t nullarrays_7df;
	Packets_t mains_7e0;
	Packets_t arrays_7e1;
	Packets_t mains_7e2;
	ArrayTest_7da arrayTest_7da;
	arrayTest_7da( dts_7db, mains_7dd, nullarrays_7df, mains_7e0, arrays_7e1, mains_7e2);
	if( ( !arrays_7e1.empty())&& ( !mains_7e2.empty()))
		callAddBound_862( arrays_7e1, mains_7e2);
	if( ( !nullarrays_7df.empty())&& ( !mains_7e0.empty()))
		callSkipArray_865( nullarrays_7df, mains_7e0);
}

void AddLoopBounds_775::callAddBound_862( const Packets_t& arrays_7a1, const Packets_t& loops_7a5)
{
	Packets_t dTs_7a3;
	Packets_t compoundStatements_7a4;
	AddBound_7a0 addBound_7a0;
	addBound_7a0( arrays_7a1, loops_7a5, dTs_7a3, compoundStatements_7a4);
	if( ( !dTs_7a3.empty())&& ( !compoundStatements_7a4.empty()))
		callArrayTest_85f( dTs_7a3, compoundStatements_7a4);
}

void AddLoopBounds_775::callSkipArray_865( const Packets_t& arrays_83c, const Packets_t& mains_83f)
{
	Packets_t dTs_83e;
	Packets_t mains_841;
	SkipArray_83b skipArray_83b;
	skipArray_83b( arrays_83c, mains_83f, dTs_83e, mains_841);
	if( ( !dTs_83e.empty())&& ( !mains_841.empty()))
		callArrayTest_85f( dTs_83e, mains_841);
}

void AddBound_7a0::operator()( const Packets_t& arrays_7a1, const Packets_t& loops_7a5, Packets_t& dTs_7a3, Packets_t& compoundStatements_7a4)
{
#ifdef PRINT_INFO
	std::cout << "AddBound_7a0" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(329, "AddBound");
	_dT_7a7= &dTs_7a3;
	_compoundStatement_7a8= &compoundStatements_7a4;
	processInputPackets( arrays_7a1, loops_7a5);
}

bool AddBound_7a0::isInputUnique( const Udm::Object& array_7ad, const Udm::Object& loop_7b6)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArray_7af= _array_7a9.begin(), itLoop_7b8= _loop_7b2.begin(); itArray_7af!= _array_7a9.end(), itLoop_7b8!= _loop_7b2.end(); ++itArray_7af, ++itLoop_7b8)
	{
		if( ( *itArray_7af== array_7ad)&& ( *itLoop_7b8== loop_7b6))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_array_7a9.push_back( array_7ad);
		_loop_7b2.push_back( loop_7b6);
	}
	return isUnique;
}

bool AddBound_7a0::isGuardTrue( SFC::Array& Array, SFC::CompoundStatement& CompoundStatement, SFC::DT& DT, SFC::BinaryExprs& LessThan, SFC::IterativeBlock& Loop, SFC::Int& LoopBound, SFC::UserCode& UserCode)
{
	bool Gz_guard= false;
	Gz_guard = static_cast< std::string >( LessThan.op() ) == "<";;
	return Gz_guard;
}

void AddBound_7a0::processInputPackets( const Packets_t& arrays_7a1, const Packets_t& loops_7a5)
{
	for( Packets_t::const_iterator itArray_7aa= arrays_7a1.begin(), itLoop_7b3= loops_7a5.begin(); itArray_7aa!= arrays_7a1.end(), itLoop_7b3!= loops_7a5.end(); ++itArray_7aa, ++itLoop_7b3)
	{
		bool isUnique= isInputUnique( *itArray_7aa, *itLoop_7b3);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArray_7aa, *itLoop_7b3);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool AddBound_7a0::patternMatcher( const Udm::Object& array_7ab, const Udm::Object& loop_7b4)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( array_7ab.type(), SFC::Array::meta))
			continue;
		SFC::Array array_7b0= SFC::Array::Cast( array_7ab);
		if( false== Uml::IsDerivedFrom( loop_7b4.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock loop_7b9= SFC::IterativeBlock::Cast( loop_7b4);
		Udm::Object loopParent_7bb= loop_7b9.container();
		if( false== Uml::IsDerivedFrom( loopParent_7bb.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatementLoop_7bc= SFC::CompoundStatement::Cast( loopParent_7bb);
		set< SFC::UserCode> userCodes_7bd= loop_7b9.UserCode_kind_children();
		for( set< SFC::UserCode>::const_iterator itUserCode_7be= userCodes_7bd.begin(); itUserCode_7be!= userCodes_7bd.end(); ++itUserCode_7be)
		{
			SFC::UserCode currUserCode_7bf= *itUserCode_7be;
			set< SFC::BinaryExprs> lessThans_7c0= currUserCode_7bf.BinaryExprs_kind_children();
			for( set< SFC::BinaryExprs>::const_iterator itLessThan_7c1= lessThans_7c0.begin(); itLessThan_7c1!= lessThans_7c0.end(); ++itLessThan_7c1)
			{
				SFC::BinaryExprs currLessThan_7c2= *itLessThan_7c1;
				set< SFC::Int> loopBounds_7c3= currLessThan_7c2.Int_kind_children();
				for( set< SFC::Int>::const_iterator itLoopBound_7c4= loopBounds_7c3.begin(); itLoopBound_7c4!= loopBounds_7c3.end(); ++itLoopBound_7c4)
				{
					SFC::Int currLoopBound_7c5= *itLoopBound_7c4;
					SFC::DT dT_7c6= array_7b0.dt();
					if( !dT_7c6)
						continue;
					Match currMatch;
					currMatch.array_7c8= array_7b0;
					currMatch.loop_7c9= loop_7b9;
					currMatch.dT_7ca= dT_7c6;
					currMatch.compoundStatement_7cb= compoundStatementLoop_7bc;
					currMatch.userCode_7cc= currUserCode_7bf;
					currMatch.lessThan_7cd= currLessThan_7c2;
					currMatch.loopBound_7ce= currLoopBound_7c5;
					bool Gz_guard= isGuardTrue( currMatch.array_7c8, currMatch.compoundStatement_7cb, currMatch.dT_7ca, currMatch.lessThan_7cd, currMatch.loop_7c9, currMatch.loopBound_7ce, currMatch.userCode_7cc);
					if( true== Gz_guard)
						_matches.push_back( currMatch);
				}
			}
		}
	}
	return !_matches.empty();
}

void AddBound_7a0::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::Array& Array= currMatch.array_7c8;
		SFC::CompoundStatement& CompoundStatement= currMatch.compoundStatement_7cb;
		SFC::DT& DT= currMatch.dT_7ca;
		SFC::BinaryExprs& LessThan= currMatch.lessThan_7cd;
		SFC::IterativeBlock& Loop= currMatch.loop_7c9;
		SFC::Int& LoopBound= currMatch.loopBound_7ce;
		SFC::UserCode& UserCode= currMatch.userCode_7cc;
		{
LoopBound.val() = Array.noelem();
};
		outputAppender( currMatch.dT_7ca, currMatch.compoundStatement_7cb);
	}
}

void AddBound_7a0::outputAppender( const SFC::DT& dT_7d6, const SFC::CompoundStatement& compoundStatement_7d8)
{
	_dT_7a7->push_back( dT_7d6);
	_compoundStatement_7a8->push_back( compoundStatement_7d8);
}

void ArrayTest_7da::operator()( const Packets_t& dts_7db, const Packets_t& mains_7dd, Packets_t& nullarrays_7df, Packets_t& mains_7e0, Packets_t& arrays_7e1, Packets_t& mains_7e2)
{
#ifdef PRINT_INFO
	std::cout << "ArrayTest_7da" << std::endl;
#endif
	_nullarray_7e3= &nullarrays_7df;
	_main_7e4= &mains_7e0;
	_array_7e5= &arrays_7e1;
	_main_7e6= &mains_7e2;
	for( Packets_t::const_iterator itdt_7e8= dts_7db.begin(), itMain_7ef= mains_7dd.begin(); itdt_7e8!= dts_7db.end(), itMain_7ef!= mains_7dd.end(); ++itdt_7e8, ++itMain_7ef)
	{
		bool isUnique= isInputUnique( *itdt_7e8, *itMain_7ef);
		if( !isUnique)
			continue;
		Packets_t onedt_7ec( 1, *itdt_7e8);
		Packets_t oneMain_7f3( 1, *itMain_7ef);
		executeOne( onedt_7ec, oneMain_7f3);
	}
}

void ArrayTest_7da::executeOne( const Packets_t& dts_7db, const Packets_t& mains_7dd)
{
	Packets_t arrays_7f8;
	Packets_t mains_7fb;
	NullArray_7f5 nullArray_7f5;
	bool isMatchNullArray_7f5= nullArray_7f5( dts_7db, mains_7dd, arrays_7f8, mains_7fb);
	_nullarray_7e3->insert( _nullarray_7e3->end(), arrays_7f8.begin(), arrays_7f8.end());
	_main_7e4->insert( _main_7e4->end(), mains_7fb.begin(), mains_7fb.end());
	if( isMatchNullArray_7f5)
		return;
	Packets_t arrays_81c;
	Packets_t mains_81f;
	Array_819 array_819;
	bool isMatchArray_819= array_819( dts_7db, mains_7dd, arrays_81c, mains_81f);
	_array_7e5->insert( _array_7e5->end(), arrays_81c.begin(), arrays_81c.end());
	_main_7e6->insert( _main_7e6->end(), mains_81f.begin(), mains_81f.end());
	if( isMatchArray_819)
		return;
}

bool ArrayTest_7da::isInputUnique( const Udm::Object& dt_7e9, const Udm::Object& main_7f0)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itdt_7eb= _dt_7e7.begin(), itMain_7f2= _main_7ee.begin(); itdt_7eb!= _dt_7e7.end(), itMain_7f2!= _main_7ee.end(); ++itdt_7eb, ++itMain_7f2)
	{
		if( ( *itdt_7eb== dt_7e9)&& ( *itMain_7f2== main_7f0))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_dt_7e7.push_back( dt_7e9);
		_main_7ee.push_back( main_7f0);
	}
	return isUnique;
}

bool NullArray_7f5::operator()( const Packets_t& arrays_7f6, const Packets_t& mains_7f9, Packets_t& arrays_7f8, Packets_t& mains_7fb)
{
#ifdef PRINT_INFO
	std::cout << "NullArray_7f5" << std::endl;
#endif
	_array_7fc= &arrays_7f8;
	_main_7fd= &mains_7fb;
	processInputPackets( arrays_7f6, mains_7f9);
	if( false== _matches.empty())
		return true;
	return false;
}

bool NullArray_7f5::isInputUnique( const Udm::Object& array_802, const Udm::Object& main_80b)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArray_804= _array_7fe.begin(), itMain_80d= _main_807.begin(); itArray_804!= _array_7fe.end(), itMain_80d!= _main_807.end(); ++itArray_804, ++itMain_80d)
	{
		if( ( *itArray_804== array_802)&& ( *itMain_80d== main_80b))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_array_7fe.push_back( array_802);
		_main_807.push_back( main_80b);
	}
	return isUnique;
}

bool NullArray_7f5::isGuardTrue( SFC::Array& Array, SFC::CompoundStatement& Main)
{
	bool Gz_guard= false;
	Gz_guard = Array.noelem() <= 1;;
	return Gz_guard;
}

void NullArray_7f5::processInputPackets( const Packets_t& arrays_7f6, const Packets_t& mains_7f9)
{
	for( Packets_t::const_iterator itArray_7ff= arrays_7f6.begin(), itMain_808= mains_7f9.begin(); itArray_7ff!= arrays_7f6.end(), itMain_808!= mains_7f9.end(); ++itArray_7ff, ++itMain_808)
	{
		bool isUnique= isInputUnique( *itArray_7ff, *itMain_808);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArray_7ff, *itMain_808);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.array_811, currMatch.main_812);
	}
}

bool NullArray_7f5::patternMatcher( const Udm::Object& array_800, const Udm::Object& main_809)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( array_800.type(), SFC::Array::meta))
			continue;
		SFC::Array array_805= SFC::Array::Cast( array_800);
		if( false== Uml::IsDerivedFrom( main_809.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_80e= SFC::CompoundStatement::Cast( main_809);
		Match currMatch;
		currMatch.array_811= array_805;
		currMatch.main_812= main_80e;
		bool Gz_guard= isGuardTrue( currMatch.array_811, currMatch.main_812);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void NullArray_7f5::outputAppender( const SFC::Array& array_815, const SFC::CompoundStatement& main_817)
{
	_array_7fc->push_back( array_815);
	_main_7fd->push_back( main_817);
}

bool Array_819::operator()( const Packets_t& arrays_81a, const Packets_t& mains_81d, Packets_t& arrays_81c, Packets_t& mains_81f)
{
#ifdef PRINT_INFO
	std::cout << "Array_819" << std::endl;
#endif
	_array_820= &arrays_81c;
	_main_821= &mains_81f;
	processInputPackets( arrays_81a, mains_81d);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Array_819::isInputUnique( const Udm::Object& array_826, const Udm::Object& main_82f)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArray_828= _array_822.begin(), itMain_831= _main_82b.begin(); itArray_828!= _array_822.end(), itMain_831!= _main_82b.end(); ++itArray_828, ++itMain_831)
	{
		if( ( *itArray_828== array_826)&& ( *itMain_831== main_82f))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_array_822.push_back( array_826);
		_main_82b.push_back( main_82f);
	}
	return isUnique;
}

void Array_819::processInputPackets( const Packets_t& arrays_81a, const Packets_t& mains_81d)
{
	for( Packets_t::const_iterator itArray_823= arrays_81a.begin(), itMain_82c= mains_81d.begin(); itArray_823!= arrays_81a.end(), itMain_82c!= mains_81d.end(); ++itArray_823, ++itMain_82c)
	{
		bool isUnique= isInputUnique( *itArray_823, *itMain_82c);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArray_823, *itMain_82c);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.array_835, currMatch.main_836);
	}
}

bool Array_819::patternMatcher( const Udm::Object& array_824, const Udm::Object& main_82d)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( array_824.type(), SFC::Array::meta))
			continue;
		SFC::Array array_829= SFC::Array::Cast( array_824);
		if( false== Uml::IsDerivedFrom( main_82d.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_832= SFC::CompoundStatement::Cast( main_82d);
		Match currMatch;
		currMatch.array_835= array_829;
		currMatch.main_836= main_832;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Array_819::outputAppender( const SFC::Array& array_837, const SFC::CompoundStatement& main_839)
{
	_array_820->push_back( array_837);
	_main_821->push_back( main_839);
}

void SkipArray_83b::operator()( const Packets_t& arrays_83c, const Packets_t& mains_83f, Packets_t& dTs_83e, Packets_t& mains_841)
{
#ifdef PRINT_INFO
	std::cout << "SkipArray_83b" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(356, "SkipArray");
	_dT_842= &dTs_83e;
	_main_843= &mains_841;
	processInputPackets( arrays_83c, mains_83f);
}

bool SkipArray_83b::isInputUnique( const Udm::Object& array_848, const Udm::Object& main_851)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itarray_84a= _array_844.begin(), itMain_853= _main_84d.begin(); itarray_84a!= _array_844.end(), itMain_853!= _main_84d.end(); ++itarray_84a, ++itMain_853)
	{
		if( ( *itarray_84a== array_848)&& ( *itMain_853== main_851))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_array_844.push_back( array_848);
		_main_84d.push_back( main_851);
	}
	return isUnique;
}

void SkipArray_83b::processInputPackets( const Packets_t& arrays_83c, const Packets_t& mains_83f)
{
	for( Packets_t::const_iterator itarray_845= arrays_83c.begin(), itMain_84e= mains_83f.begin(); itarray_845!= arrays_83c.end(), itMain_84e!= mains_83f.end(); ++itarray_845, ++itMain_84e)
	{
		bool isUnique= isInputUnique( *itarray_845, *itMain_84e);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itarray_845, *itMain_84e);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool SkipArray_83b::patternMatcher( const Udm::Object& array_846, const Udm::Object& main_84f)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( array_846.type(), SFC::Array::meta))
			continue;
		SFC::Array array_84b= SFC::Array::Cast( array_846);
		if( false== Uml::IsDerivedFrom( main_84f.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_854= SFC::CompoundStatement::Cast( main_84f);
		SFC::DT dT_856= array_84b.dt();
		if( !dT_856)
			continue;
		Match currMatch;
		currMatch.array_858= array_84b;
		currMatch.main_859= main_854;
		currMatch.dT_85a= dT_856;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void SkipArray_83b::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.dT_85a, currMatch.main_859);
	}
}

void SkipArray_83b::outputAppender( const SFC::DT& dT_85b, const SFC::CompoundStatement& main_85d)
{
	_dT_842->push_back( dT_85b);
	_main_843->push_back( main_85d);
}

void MakeArrayLoop_868::operator()( const Packets_t& argDeclBases_869, const Packets_t& topArrays_86c, const Packets_t& arrays_86f, const Packets_t& mains_872, Packets_t& argDeclBases_86b, Packets_t& topArrays_86e, Packets_t& dTs_871, Packets_t& loops_874)
{
#ifdef PRINT_INFO
	std::cout << "MakeArrayLoop_868" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(361, "MakeArrayLoop");
	_argDeclBase_875= &argDeclBases_86b;
	_topArray_876= &topArrays_86e;
	_dT_877= &dTs_871;
	_loop_878= &loops_874;
	processInputPackets( argDeclBases_869, topArrays_86c, arrays_86f, mains_872);
}

bool MakeArrayLoop_868::isInputUnique( const Udm::Object& argDeclBase_87d, const Udm::Object& topArray_886, const Udm::Object& array_88f, const Udm::Object& main_898)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_87f= _argDeclBase_879.begin(), itTopArray_888= _topArray_882.begin(), itArray_891= _array_88b.begin(), itMain_89a= _main_894.begin(); itArgDeclBase_87f!= _argDeclBase_879.end(), itTopArray_888!= _topArray_882.end(), itArray_891!= _array_88b.end(), itMain_89a!= _main_894.end(); ++itArgDeclBase_87f, ++itTopArray_888, ++itArray_891, ++itMain_89a)
	{
		if( ( *itArgDeclBase_87f== argDeclBase_87d)&& ( *itTopArray_888== topArray_886)&& ( *itArray_891== array_88f)&& ( *itMain_89a== main_898))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_879.push_back( argDeclBase_87d);
		_topArray_882.push_back( topArray_886);
		_array_88b.push_back( array_88f);
		_main_894.push_back( main_898);
	}
	return isUnique;
}

void MakeArrayLoop_868::processInputPackets( const Packets_t& argDeclBases_869, const Packets_t& topArrays_86c, const Packets_t& arrays_86f, const Packets_t& mains_872)
{
	for( Packets_t::const_iterator itArgDeclBase_87a= argDeclBases_869.begin(), itTopArray_883= topArrays_86c.begin(), itArray_88c= arrays_86f.begin(), itMain_895= mains_872.begin(); itArgDeclBase_87a!= argDeclBases_869.end(), itTopArray_883!= topArrays_86c.end(), itArray_88c!= arrays_86f.end(), itMain_895!= mains_872.end(); ++itArgDeclBase_87a, ++itTopArray_883, ++itArray_88c, ++itMain_895)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_87a, *itTopArray_883, *itArray_88c, *itMain_895);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_87a, *itTopArray_883, *itArray_88c, *itMain_895);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MakeArrayLoop_868::patternMatcher( const Udm::Object& argDeclBase_87b, const Udm::Object& topArray_884, const Udm::Object& array_88d, const Udm::Object& main_896)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_87b.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_880= SFC::ArgDeclBase::Cast( argDeclBase_87b);
		if( false== Uml::IsDerivedFrom( topArray_884.type(), SFC::Array::meta))
			continue;
		SFC::Array topArray_889= SFC::Array::Cast( topArray_884);
		if( false== Uml::IsDerivedFrom( array_88d.type(), SFC::Array::meta))
			continue;
		SFC::Array array_892= SFC::Array::Cast( array_88d);
		if( false== Uml::IsDerivedFrom( main_896.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_89b= SFC::CompoundStatement::Cast( main_896);
		SFC::DT dT_89d= array_892.dt();
		if( !dT_89d)
			continue;
		Match currMatch;
		currMatch.argDeclBase_89f= argDeclBase_880;
		currMatch.topArray_8a0= topArray_889;
		currMatch.array_8a1= array_892;
		currMatch.main_8a2= main_89b;
		currMatch.dT_8a3= dT_89d;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MakeArrayLoop_868::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::UserCode newZeroLoopIndex_8a4= SFC::UserCode::Create( currMatch.main_8a2, SFC::CompoundStatement::meta_stmnt);
		SFC::BinaryExprs newAssignment_8a5= SFC::BinaryExprs::Create( newZeroLoopIndex_8a4, SFC::UserCode::meta_codeexpr);
		SFC::Int newZero_8a6= SFC::Int::Create( newAssignment_8a5, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclRef newArgDeclRef1_8a7= SFC::ArgDeclRef::Create( newAssignment_8a5, SFC::BinaryExprs::meta_leftexpr);
		SFC::LocalVar newLoopIndex_8a8= SFC::LocalVar::Create( currMatch.main_8a2);
		SFC::IterativeBlock newLoop_8a9= SFC::IterativeBlock::Create( currMatch.main_8a2);
		SFC::UserCode newUserCode_8aa= SFC::UserCode::Create( newLoop_8a9, SFC::IterativeBlock::meta_cond);
		SFC::BinaryExprs newLessThan_8ab= SFC::BinaryExprs::Create( newUserCode_8aa, SFC::UserCode::meta_codeexpr);
		SFC::Int newLoopBound_8ac= SFC::Int::Create( newLessThan_8ab, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclRef newArgDeclRef2_8ad= SFC::ArgDeclRef::Create( newLessThan_8ab, SFC::BinaryExprs::meta_leftexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_89f;
		SFC::ArgDeclRef& ArgDeclRef1= newArgDeclRef1_8a7;
		SFC::ArgDeclRef& ArgDeclRef2= newArgDeclRef2_8ad;
		SFC::Array& Array= currMatch.array_8a1;
		SFC::BinaryExprs& Assignment= newAssignment_8a5;
		SFC::DT& DT= currMatch.dT_8a3;
		SFC::BinaryExprs& LessThan= newLessThan_8ab;
		SFC::IterativeBlock& Loop= newLoop_8a9;
		SFC::Int& LoopBound= newLoopBound_8ac;
		SFC::LocalVar& LoopIndex= newLoopIndex_8a8;
		SFC::CompoundStatement& Main= currMatch.main_8a2;
		SFC::Array& TopArray= currMatch.topArray_8a0;
		SFC::UserCode& UserCode= newUserCode_8aa;
		SFC::Int& Zero= newZero_8a6;
		SFC::UserCode& ZeroLoopIndex= newZeroLoopIndex_8a4;
		{
LoopIndex.name() = std::string( "ix" ) + boost::lexical_cast< std::string >( LoopIndex.uniqueId() );
LoopIndex.type() = std::string( "int" );
};
		{
LessThan.op() = "<";
};
		{
Zero.val() = 0;
};
		{
Assignment.op() = "=";
};
		{
__int64 statementCount = Main.statementCount();

LoopIndex.statementIndex() = statementCount++;
ZeroLoopIndex.statementIndex() = statementCount++;
Loop.statementIndex() = statementCount++;

Main.statementCount() = statementCount;
};
		currMatch.topArray_8a0.itb()+= newLoop_8a9;
		newLoop_8a9.counter()= newLoopIndex_8a8;
		newArgDeclRef2_8ad.argdecl()= newLoopIndex_8a8;
		newArgDeclRef1_8a7.argdecl()= newLoopIndex_8a8;
		outputAppender( currMatch.argDeclBase_89f, currMatch.topArray_8a0, currMatch.dT_8a3, newLoop_8a9);
	}
}

void MakeArrayLoop_868::outputAppender( const SFC::ArgDeclBase& argDeclBase_8ae, const SFC::Array& topArray_8b0, const SFC::DT& dT_8b2, const SFC::IterativeBlock& loop_8b4)
{
	_argDeclBase_875->push_back( argDeclBase_8ae);
	_topArray_876->push_back( topArray_8b0);
	_dT_877->push_back( dT_8b2);
	_loop_878->push_back( loop_8b4);
}

void SkipArray_8b6::operator()( const Packets_t& argDeclBases_8b7, const Packets_t& topArrays_8ba, const Packets_t& arrays_8bd, const Packets_t& mains_8c0, Packets_t& argDeclBases_8b9, Packets_t& topArrays_8bc, Packets_t& dTs_8bf, Packets_t& mains_8c2)
{
#ifdef PRINT_INFO
	std::cout << "SkipArray_8b6" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(397, "SkipArray");
	_argDeclBase_8c3= &argDeclBases_8b9;
	_topArray_8c4= &topArrays_8bc;
	_dT_8c5= &dTs_8bf;
	_main_8c6= &mains_8c2;
	processInputPackets( argDeclBases_8b7, topArrays_8ba, arrays_8bd, mains_8c0);
}

bool SkipArray_8b6::isInputUnique( const Udm::Object& argDeclBase_8cb, const Udm::Object& topArray_8d4, const Udm::Object& array_8dd, const Udm::Object& main_8e6)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_8cd= _argDeclBase_8c7.begin(), itTopArray_8d6= _topArray_8d0.begin(), itArray_8df= _array_8d9.begin(), itMain_8e8= _main_8e2.begin(); itArgDeclBase_8cd!= _argDeclBase_8c7.end(), itTopArray_8d6!= _topArray_8d0.end(), itArray_8df!= _array_8d9.end(), itMain_8e8!= _main_8e2.end(); ++itArgDeclBase_8cd, ++itTopArray_8d6, ++itArray_8df, ++itMain_8e8)
	{
		if( ( *itArgDeclBase_8cd== argDeclBase_8cb)&& ( *itTopArray_8d6== topArray_8d4)&& ( *itArray_8df== array_8dd)&& ( *itMain_8e8== main_8e6))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_8c7.push_back( argDeclBase_8cb);
		_topArray_8d0.push_back( topArray_8d4);
		_array_8d9.push_back( array_8dd);
		_main_8e2.push_back( main_8e6);
	}
	return isUnique;
}

void SkipArray_8b6::processInputPackets( const Packets_t& argDeclBases_8b7, const Packets_t& topArrays_8ba, const Packets_t& arrays_8bd, const Packets_t& mains_8c0)
{
	for( Packets_t::const_iterator itArgDeclBase_8c8= argDeclBases_8b7.begin(), itTopArray_8d1= topArrays_8ba.begin(), itArray_8da= arrays_8bd.begin(), itMain_8e3= mains_8c0.begin(); itArgDeclBase_8c8!= argDeclBases_8b7.end(), itTopArray_8d1!= topArrays_8ba.end(), itArray_8da!= arrays_8bd.end(), itMain_8e3!= mains_8c0.end(); ++itArgDeclBase_8c8, ++itTopArray_8d1, ++itArray_8da, ++itMain_8e3)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_8c8, *itTopArray_8d1, *itArray_8da, *itMain_8e3);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_8c8, *itTopArray_8d1, *itArray_8da, *itMain_8e3);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool SkipArray_8b6::patternMatcher( const Udm::Object& argDeclBase_8c9, const Udm::Object& topArray_8d2, const Udm::Object& array_8db, const Udm::Object& main_8e4)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_8c9.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_8ce= SFC::ArgDeclBase::Cast( argDeclBase_8c9);
		if( false== Uml::IsDerivedFrom( topArray_8d2.type(), SFC::Array::meta))
			continue;
		SFC::Array topArray_8d7= SFC::Array::Cast( topArray_8d2);
		if( false== Uml::IsDerivedFrom( array_8db.type(), SFC::Array::meta))
			continue;
		SFC::Array array_8e0= SFC::Array::Cast( array_8db);
		if( false== Uml::IsDerivedFrom( main_8e4.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_8e9= SFC::CompoundStatement::Cast( main_8e4);
		SFC::DT dT_8eb= array_8e0.dt();
		if( !dT_8eb)
			continue;
		Match currMatch;
		currMatch.argDeclBase_8ed= argDeclBase_8ce;
		currMatch.topArray_8ee= topArray_8d7;
		currMatch.array_8ef= array_8e0;
		currMatch.main_8f0= main_8e9;
		currMatch.dT_8f1= dT_8eb;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void SkipArray_8b6::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_8ed, currMatch.topArray_8ee, currMatch.dT_8f1, currMatch.main_8f0);
	}
}

void SkipArray_8b6::outputAppender( const SFC::ArgDeclBase& argDeclBase_8f2, const SFC::Array& topArray_8f4, const SFC::DT& dT_8f6, const SFC::CompoundStatement& main_8f8)
{
	_argDeclBase_8c3->push_back( argDeclBase_8f2);
	_topArray_8c4->push_back( topArray_8f4);
	_dT_8c5->push_back( dT_8f6);
	_main_8c6->push_back( main_8f8);
}

void ArrayTest_8fa::operator()( const Packets_t& passADBs_8fb, const Packets_t& topArrays_8fd, const Packets_t& dts_8ff, const Packets_t& mains_901, Packets_t& passADBs_903, Packets_t& toparrays_904, Packets_t& nullarrays_905, Packets_t& mains_906, Packets_t& passADBs_907, Packets_t& toparrays_908, Packets_t& arrays_909, Packets_t& mains_90a, Packets_t& passADBs_90b, Packets_t& toparrays_90c, Packets_t& dts_90d, Packets_t& mains_90e)
{
#ifdef PRINT_INFO
	std::cout << "ArrayTest_8fa" << std::endl;
#endif
	_passADB_90f= &passADBs_903;
	_toparray_910= &toparrays_904;
	_nullarray_911= &nullarrays_905;
	_main_912= &mains_906;
	_passADB_913= &passADBs_907;
	_toparray_914= &toparrays_908;
	_array_915= &arrays_909;
	_main_916= &mains_90a;
	_passADB_917= &passADBs_90b;
	_toparray_918= &toparrays_90c;
	_dt_919= &dts_90d;
	_main_91a= &mains_90e;
	for( Packets_t::const_iterator itpassADB_91c= passADBs_8fb.begin(), ittopArray_923= topArrays_8fd.begin(), itdt_92a= dts_8ff.begin(), itMain_931= mains_901.begin(); itpassADB_91c!= passADBs_8fb.end(), ittopArray_923!= topArrays_8fd.end(), itdt_92a!= dts_8ff.end(), itMain_931!= mains_901.end(); ++itpassADB_91c, ++ittopArray_923, ++itdt_92a, ++itMain_931)
	{
		bool isUnique= isInputUnique( *itpassADB_91c, *ittopArray_923, *itdt_92a, *itMain_931);
		if( !isUnique)
			continue;
		Packets_t onepassADB_920( 1, *itpassADB_91c);
		Packets_t onetopArray_927( 1, *ittopArray_923);
		Packets_t onedt_92e( 1, *itdt_92a);
		Packets_t oneMain_935( 1, *itMain_931);
		executeOne( onepassADB_920, onetopArray_927, onedt_92e, oneMain_935);
	}
}

void ArrayTest_8fa::executeOne( const Packets_t& passADBs_8fb, const Packets_t& topArrays_8fd, const Packets_t& dts_8ff, const Packets_t& mains_901)
{
	Packets_t argDeclBases_93a;
	Packets_t topArrays_93d;
	Packets_t arrays_940;
	Packets_t mains_943;
	NullArray_937 nullArray_937;
	bool isMatchNullArray_937= nullArray_937( passADBs_8fb, topArrays_8fd, dts_8ff, mains_901, argDeclBases_93a, topArrays_93d, arrays_940, mains_943);
	_passADB_90f->insert( _passADB_90f->end(), argDeclBases_93a.begin(), argDeclBases_93a.end());
	_toparray_910->insert( _toparray_910->end(), topArrays_93d.begin(), topArrays_93d.end());
	_nullarray_911->insert( _nullarray_911->end(), arrays_940.begin(), arrays_940.end());
	_main_912->insert( _main_912->end(), mains_943.begin(), mains_943.end());
	if( isMatchNullArray_937)
		return;
	Packets_t argDeclBases_980;
	Packets_t topArrays_983;
	Packets_t arrays_986;
	Packets_t mains_989;
	Array_97d array_97d;
	bool isMatchArray_97d= array_97d( passADBs_8fb, topArrays_8fd, dts_8ff, mains_901, argDeclBases_980, topArrays_983, arrays_986, mains_989);
	_passADB_913->insert( _passADB_913->end(), argDeclBases_980.begin(), argDeclBases_980.end());
	_toparray_914->insert( _toparray_914->end(), topArrays_983.begin(), topArrays_983.end());
	_array_915->insert( _array_915->end(), arrays_986.begin(), arrays_986.end());
	_main_916->insert( _main_916->end(), mains_989.begin(), mains_989.end());
	if( isMatchArray_97d)
		return;
	Packets_t argDeclBases_9c2;
	Packets_t topArrays_9c5;
	Packets_t dTs_9c8;
	Packets_t mains_9cb;
	Otherwise_9bf otherwise_9bf;
	bool isMatchOtherwise_9bf= otherwise_9bf( passADBs_8fb, topArrays_8fd, dts_8ff, mains_901, argDeclBases_9c2, topArrays_9c5, dTs_9c8, mains_9cb);
	_passADB_917->insert( _passADB_917->end(), argDeclBases_9c2.begin(), argDeclBases_9c2.end());
	_toparray_918->insert( _toparray_918->end(), topArrays_9c5.begin(), topArrays_9c5.end());
	_dt_919->insert( _dt_919->end(), dTs_9c8.begin(), dTs_9c8.end());
	_main_91a->insert( _main_91a->end(), mains_9cb.begin(), mains_9cb.end());
	if( isMatchOtherwise_9bf)
		return;
}

bool ArrayTest_8fa::isInputUnique( const Udm::Object& passADB_91d, const Udm::Object& topArray_924, const Udm::Object& dt_92b, const Udm::Object& main_932)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_91f= _passADB_91b.begin(), ittopArray_926= _topArray_922.begin(), itdt_92d= _dt_929.begin(), itMain_934= _main_930.begin(); itpassADB_91f!= _passADB_91b.end(), ittopArray_926!= _topArray_922.end(), itdt_92d!= _dt_929.end(), itMain_934!= _main_930.end(); ++itpassADB_91f, ++ittopArray_926, ++itdt_92d, ++itMain_934)
	{
		if( ( *itpassADB_91f== passADB_91d)&& ( *ittopArray_926== topArray_924)&& ( *itdt_92d== dt_92b)&& ( *itMain_934== main_932))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_91b.push_back( passADB_91d);
		_topArray_922.push_back( topArray_924);
		_dt_929.push_back( dt_92b);
		_main_930.push_back( main_932);
	}
	return isUnique;
}

bool NullArray_937::operator()( const Packets_t& argDeclBases_938, const Packets_t& topArrays_93b, const Packets_t& arrays_93e, const Packets_t& mains_941, Packets_t& argDeclBases_93a, Packets_t& topArrays_93d, Packets_t& arrays_940, Packets_t& mains_943)
{
#ifdef PRINT_INFO
	std::cout << "NullArray_937" << std::endl;
#endif
	_argDeclBase_944= &argDeclBases_93a;
	_topArray_945= &topArrays_93d;
	_array_946= &arrays_940;
	_main_947= &mains_943;
	processInputPackets( argDeclBases_938, topArrays_93b, arrays_93e, mains_941);
	if( false== _matches.empty())
		return true;
	return false;
}

bool NullArray_937::isInputUnique( const Udm::Object& argDeclBase_94c, const Udm::Object& topArray_955, const Udm::Object& array_95e, const Udm::Object& main_967)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_94e= _argDeclBase_948.begin(), itTopArray_957= _topArray_951.begin(), itArray_960= _array_95a.begin(), itMain_969= _main_963.begin(); itArgDeclBase_94e!= _argDeclBase_948.end(), itTopArray_957!= _topArray_951.end(), itArray_960!= _array_95a.end(), itMain_969!= _main_963.end(); ++itArgDeclBase_94e, ++itTopArray_957, ++itArray_960, ++itMain_969)
	{
		if( ( *itArgDeclBase_94e== argDeclBase_94c)&& ( *itTopArray_957== topArray_955)&& ( *itArray_960== array_95e)&& ( *itMain_969== main_967))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_948.push_back( argDeclBase_94c);
		_topArray_951.push_back( topArray_955);
		_array_95a.push_back( array_95e);
		_main_963.push_back( main_967);
	}
	return isUnique;
}

bool NullArray_937::isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Array& Array, SFC::CompoundStatement& Main, SFC::Array& TopArray)
{
	bool Gz_guard= false;
	Gz_guard = Array.noelem() <= 1;;
	return Gz_guard;
}

void NullArray_937::processInputPackets( const Packets_t& argDeclBases_938, const Packets_t& topArrays_93b, const Packets_t& arrays_93e, const Packets_t& mains_941)
{
	for( Packets_t::const_iterator itArgDeclBase_949= argDeclBases_938.begin(), itTopArray_952= topArrays_93b.begin(), itArray_95b= arrays_93e.begin(), itMain_964= mains_941.begin(); itArgDeclBase_949!= argDeclBases_938.end(), itTopArray_952!= topArrays_93b.end(), itArray_95b!= arrays_93e.end(), itMain_964!= mains_941.end(); ++itArgDeclBase_949, ++itTopArray_952, ++itArray_95b, ++itMain_964)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_949, *itTopArray_952, *itArray_95b, *itMain_964);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_949, *itTopArray_952, *itArray_95b, *itMain_964);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_96d, currMatch.topArray_96e, currMatch.array_96f, currMatch.main_970);
	}
}

bool NullArray_937::patternMatcher( const Udm::Object& argDeclBase_94a, const Udm::Object& topArray_953, const Udm::Object& array_95c, const Udm::Object& main_965)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_94a.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_94f= SFC::ArgDeclBase::Cast( argDeclBase_94a);
		if( false== Uml::IsDerivedFrom( topArray_953.type(), SFC::Array::meta))
			continue;
		SFC::Array topArray_958= SFC::Array::Cast( topArray_953);
		if( false== Uml::IsDerivedFrom( array_95c.type(), SFC::Array::meta))
			continue;
		SFC::Array array_961= SFC::Array::Cast( array_95c);
		if( false== Uml::IsDerivedFrom( main_965.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_96a= SFC::CompoundStatement::Cast( main_965);
		Match currMatch;
		currMatch.argDeclBase_96d= argDeclBase_94f;
		currMatch.topArray_96e= topArray_958;
		currMatch.array_96f= array_961;
		currMatch.main_970= main_96a;
		bool Gz_guard= isGuardTrue( currMatch.argDeclBase_96d, currMatch.array_96f, currMatch.main_970, currMatch.topArray_96e);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void NullArray_937::outputAppender( const SFC::ArgDeclBase& argDeclBase_975, const SFC::Array& topArray_977, const SFC::Array& array_979, const SFC::CompoundStatement& main_97b)
{
	_argDeclBase_944->push_back( argDeclBase_975);
	_topArray_945->push_back( topArray_977);
	_array_946->push_back( array_979);
	_main_947->push_back( main_97b);
}

bool Array_97d::operator()( const Packets_t& argDeclBases_97e, const Packets_t& topArrays_981, const Packets_t& arrays_984, const Packets_t& mains_987, Packets_t& argDeclBases_980, Packets_t& topArrays_983, Packets_t& arrays_986, Packets_t& mains_989)
{
#ifdef PRINT_INFO
	std::cout << "Array_97d" << std::endl;
#endif
	_argDeclBase_98a= &argDeclBases_980;
	_topArray_98b= &topArrays_983;
	_array_98c= &arrays_986;
	_main_98d= &mains_989;
	processInputPackets( argDeclBases_97e, topArrays_981, arrays_984, mains_987);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Array_97d::isInputUnique( const Udm::Object& argDeclBase_992, const Udm::Object& topArray_99b, const Udm::Object& array_9a4, const Udm::Object& main_9ad)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_994= _argDeclBase_98e.begin(), itTopArray_99d= _topArray_997.begin(), itArray_9a6= _array_9a0.begin(), itMain_9af= _main_9a9.begin(); itArgDeclBase_994!= _argDeclBase_98e.end(), itTopArray_99d!= _topArray_997.end(), itArray_9a6!= _array_9a0.end(), itMain_9af!= _main_9a9.end(); ++itArgDeclBase_994, ++itTopArray_99d, ++itArray_9a6, ++itMain_9af)
	{
		if( ( *itArgDeclBase_994== argDeclBase_992)&& ( *itTopArray_99d== topArray_99b)&& ( *itArray_9a6== array_9a4)&& ( *itMain_9af== main_9ad))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_98e.push_back( argDeclBase_992);
		_topArray_997.push_back( topArray_99b);
		_array_9a0.push_back( array_9a4);
		_main_9a9.push_back( main_9ad);
	}
	return isUnique;
}

void Array_97d::processInputPackets( const Packets_t& argDeclBases_97e, const Packets_t& topArrays_981, const Packets_t& arrays_984, const Packets_t& mains_987)
{
	for( Packets_t::const_iterator itArgDeclBase_98f= argDeclBases_97e.begin(), itTopArray_998= topArrays_981.begin(), itArray_9a1= arrays_984.begin(), itMain_9aa= mains_987.begin(); itArgDeclBase_98f!= argDeclBases_97e.end(), itTopArray_998!= topArrays_981.end(), itArray_9a1!= arrays_984.end(), itMain_9aa!= mains_987.end(); ++itArgDeclBase_98f, ++itTopArray_998, ++itArray_9a1, ++itMain_9aa)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_98f, *itTopArray_998, *itArray_9a1, *itMain_9aa);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_98f, *itTopArray_998, *itArray_9a1, *itMain_9aa);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_9b3, currMatch.topArray_9b4, currMatch.array_9b5, currMatch.main_9b6);
	}
}

bool Array_97d::patternMatcher( const Udm::Object& argDeclBase_990, const Udm::Object& topArray_999, const Udm::Object& array_9a2, const Udm::Object& main_9ab)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_990.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_995= SFC::ArgDeclBase::Cast( argDeclBase_990);
		if( false== Uml::IsDerivedFrom( topArray_999.type(), SFC::Array::meta))
			continue;
		SFC::Array topArray_99e= SFC::Array::Cast( topArray_999);
		if( false== Uml::IsDerivedFrom( array_9a2.type(), SFC::Array::meta))
			continue;
		SFC::Array array_9a7= SFC::Array::Cast( array_9a2);
		if( false== Uml::IsDerivedFrom( main_9ab.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_9b0= SFC::CompoundStatement::Cast( main_9ab);
		Match currMatch;
		currMatch.argDeclBase_9b3= argDeclBase_995;
		currMatch.topArray_9b4= topArray_99e;
		currMatch.array_9b5= array_9a7;
		currMatch.main_9b6= main_9b0;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Array_97d::outputAppender( const SFC::ArgDeclBase& argDeclBase_9b7, const SFC::Array& topArray_9b9, const SFC::Array& array_9bb, const SFC::CompoundStatement& main_9bd)
{
	_argDeclBase_98a->push_back( argDeclBase_9b7);
	_topArray_98b->push_back( topArray_9b9);
	_array_98c->push_back( array_9bb);
	_main_98d->push_back( main_9bd);
}

bool Otherwise_9bf::operator()( const Packets_t& argDeclBases_9c0, const Packets_t& topArrays_9c3, const Packets_t& dTs_9c6, const Packets_t& mains_9c9, Packets_t& argDeclBases_9c2, Packets_t& topArrays_9c5, Packets_t& dTs_9c8, Packets_t& mains_9cb)
{
#ifdef PRINT_INFO
	std::cout << "Otherwise_9bf" << std::endl;
#endif
	_argDeclBase_9cc= &argDeclBases_9c2;
	_topArray_9cd= &topArrays_9c5;
	_dT_9ce= &dTs_9c8;
	_main_9cf= &mains_9cb;
	processInputPackets( argDeclBases_9c0, topArrays_9c3, dTs_9c6, mains_9c9);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Otherwise_9bf::isInputUnique( const Udm::Object& argDeclBase_9d4, const Udm::Object& topArray_9dd, const Udm::Object& dT_9e6, const Udm::Object& main_9ef)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_9d6= _argDeclBase_9d0.begin(), itTopArray_9df= _topArray_9d9.begin(), itDT_9e8= _dT_9e2.begin(), itMain_9f1= _main_9eb.begin(); itArgDeclBase_9d6!= _argDeclBase_9d0.end(), itTopArray_9df!= _topArray_9d9.end(), itDT_9e8!= _dT_9e2.end(), itMain_9f1!= _main_9eb.end(); ++itArgDeclBase_9d6, ++itTopArray_9df, ++itDT_9e8, ++itMain_9f1)
	{
		if( ( *itArgDeclBase_9d6== argDeclBase_9d4)&& ( *itTopArray_9df== topArray_9dd)&& ( *itDT_9e8== dT_9e6)&& ( *itMain_9f1== main_9ef))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_9d0.push_back( argDeclBase_9d4);
		_topArray_9d9.push_back( topArray_9dd);
		_dT_9e2.push_back( dT_9e6);
		_main_9eb.push_back( main_9ef);
	}
	return isUnique;
}

void Otherwise_9bf::processInputPackets( const Packets_t& argDeclBases_9c0, const Packets_t& topArrays_9c3, const Packets_t& dTs_9c6, const Packets_t& mains_9c9)
{
	for( Packets_t::const_iterator itArgDeclBase_9d1= argDeclBases_9c0.begin(), itTopArray_9da= topArrays_9c3.begin(), itDT_9e3= dTs_9c6.begin(), itMain_9ec= mains_9c9.begin(); itArgDeclBase_9d1!= argDeclBases_9c0.end(), itTopArray_9da!= topArrays_9c3.end(), itDT_9e3!= dTs_9c6.end(), itMain_9ec!= mains_9c9.end(); ++itArgDeclBase_9d1, ++itTopArray_9da, ++itDT_9e3, ++itMain_9ec)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_9d1, *itTopArray_9da, *itDT_9e3, *itMain_9ec);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_9d1, *itTopArray_9da, *itDT_9e3, *itMain_9ec);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_9f5, currMatch.topArray_9f6, currMatch.dT_9f7, currMatch.main_9f8);
	}
}

bool Otherwise_9bf::patternMatcher( const Udm::Object& argDeclBase_9d2, const Udm::Object& topArray_9db, const Udm::Object& dT_9e4, const Udm::Object& main_9ed)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_9d2.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_9d7= SFC::ArgDeclBase::Cast( argDeclBase_9d2);
		if( false== Uml::IsDerivedFrom( topArray_9db.type(), SFC::Array::meta))
			continue;
		SFC::Array topArray_9e0= SFC::Array::Cast( topArray_9db);
		if( false== Uml::IsDerivedFrom( dT_9e4.type(), SFC::DT::meta))
			continue;
		SFC::DT dT_9e9= SFC::DT::Cast( dT_9e4);
		if( false== Uml::IsDerivedFrom( main_9ed.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_9f2= SFC::CompoundStatement::Cast( main_9ed);
		Match currMatch;
		currMatch.argDeclBase_9f5= argDeclBase_9d7;
		currMatch.topArray_9f6= topArray_9e0;
		currMatch.dT_9f7= dT_9e9;
		currMatch.main_9f8= main_9f2;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Otherwise_9bf::outputAppender( const SFC::ArgDeclBase& argDeclBase_9f9, const SFC::Array& topArray_9fb, const SFC::DT& dT_9fd, const SFC::CompoundStatement& main_9ff)
{
	_argDeclBase_9cc->push_back( argDeclBase_9f9);
	_topArray_9cd->push_back( topArray_9fb);
	_dT_9ce->push_back( dT_9fd);
	_main_9cf->push_back( main_9ff);
}

void MemberDataType_a15::operator()( const Packets_t& localVars_a16, const Packets_t& mains_a1a, Packets_t& localVars_a18, Packets_t& dTs_a19, Packets_t& mains_a1c)
{
#ifdef PRINT_INFO
	std::cout << "MemberDataType_a15" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(436, "MemberDataType");
	_localVar_a1d= &localVars_a18;
	_dT_a1e= &dTs_a19;
	_main_a1f= &mains_a1c;
	processInputPackets( localVars_a16, mains_a1a);
}

bool MemberDataType_a15::isInputUnique( const Udm::Object& localVar_a24, const Udm::Object& main_a2d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itLocalVar_a26= _localVar_a20.begin(), itMain_a2f= _main_a29.begin(); itLocalVar_a26!= _localVar_a20.end(), itMain_a2f!= _main_a29.end(); ++itLocalVar_a26, ++itMain_a2f)
	{
		if( ( *itLocalVar_a26== localVar_a24)&& ( *itMain_a2f== main_a2d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_localVar_a20.push_back( localVar_a24);
		_main_a29.push_back( main_a2d);
	}
	return isUnique;
}

void MemberDataType_a15::processInputPackets( const Packets_t& localVars_a16, const Packets_t& mains_a1a)
{
	for( Packets_t::const_iterator itLocalVar_a21= localVars_a16.begin(), itMain_a2a= mains_a1a.begin(); itLocalVar_a21!= localVars_a16.end(), itMain_a2a!= mains_a1a.end(); ++itLocalVar_a21, ++itMain_a2a)
	{
		bool isUnique= isInputUnique( *itLocalVar_a21, *itMain_a2a);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itLocalVar_a21, *itMain_a2a);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MemberDataType_a15::patternMatcher( const Udm::Object& localVar_a22, const Udm::Object& main_a2b)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( localVar_a22.type(), SFC::LocalVar::meta))
			continue;
		SFC::LocalVar localVar_a27= SFC::LocalVar::Cast( localVar_a22);
		if( false== Uml::IsDerivedFrom( main_a2b.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_a30= SFC::CompoundStatement::Cast( main_a2b);
		SFC::DT dT_a32= localVar_a27.dt();
		if( !dT_a32)
			continue;
		Match currMatch;
		currMatch.localVar_a34= localVar_a27;
		currMatch.main_a35= main_a30;
		currMatch.dT_a36= dT_a32;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MemberDataType_a15::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.localVar_a34, currMatch.dT_a36, currMatch.main_a35);
	}
}

void MemberDataType_a15::outputAppender( const SFC::LocalVar& localVar_a37, const SFC::DT& dT_a39, const SFC::CompoundStatement& main_a3b)
{
	_localVar_a1d->push_back( localVar_a37);
	_dT_a1e->push_back( dT_a39);
	_main_a1f->push_back( main_a3b);
}

void MakeArrayLoop_a3d::operator()( const Packets_t& argDeclBases_a3e, const Packets_t& arrays_a41, const Packets_t& mains_a45, Packets_t& argDeclBases_a40, Packets_t& arrays_a43, Packets_t& dTs_a44, Packets_t& loops_a47)
{
#ifdef PRINT_INFO
	std::cout << "MakeArrayLoop_a3d" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(441, "MakeArrayLoop");
	_argDeclBase_a48= &argDeclBases_a40;
	_array_a49= &arrays_a43;
	_dT_a4a= &dTs_a44;
	_loop_a4b= &loops_a47;
	processInputPackets( argDeclBases_a3e, arrays_a41, mains_a45);
}

bool MakeArrayLoop_a3d::isInputUnique( const Udm::Object& argDeclBase_a50, const Udm::Object& array_a59, const Udm::Object& main_a62)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_a52= _argDeclBase_a4c.begin(), itArray_a5b= _array_a55.begin(), itMain_a64= _main_a5e.begin(); itArgDeclBase_a52!= _argDeclBase_a4c.end(), itArray_a5b!= _array_a55.end(), itMain_a64!= _main_a5e.end(); ++itArgDeclBase_a52, ++itArray_a5b, ++itMain_a64)
	{
		if( ( *itArgDeclBase_a52== argDeclBase_a50)&& ( *itArray_a5b== array_a59)&& ( *itMain_a64== main_a62))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_a4c.push_back( argDeclBase_a50);
		_array_a55.push_back( array_a59);
		_main_a5e.push_back( main_a62);
	}
	return isUnique;
}

void MakeArrayLoop_a3d::processInputPackets( const Packets_t& argDeclBases_a3e, const Packets_t& arrays_a41, const Packets_t& mains_a45)
{
	for( Packets_t::const_iterator itArgDeclBase_a4d= argDeclBases_a3e.begin(), itArray_a56= arrays_a41.begin(), itMain_a5f= mains_a45.begin(); itArgDeclBase_a4d!= argDeclBases_a3e.end(), itArray_a56!= arrays_a41.end(), itMain_a5f!= mains_a45.end(); ++itArgDeclBase_a4d, ++itArray_a56, ++itMain_a5f)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_a4d, *itArray_a56, *itMain_a5f);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_a4d, *itArray_a56, *itMain_a5f);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MakeArrayLoop_a3d::patternMatcher( const Udm::Object& argDeclBase_a4e, const Udm::Object& array_a57, const Udm::Object& main_a60)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_a4e.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_a53= SFC::ArgDeclBase::Cast( argDeclBase_a4e);
		if( false== Uml::IsDerivedFrom( array_a57.type(), SFC::Array::meta))
			continue;
		SFC::Array array_a5c= SFC::Array::Cast( array_a57);
		if( false== Uml::IsDerivedFrom( main_a60.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_a65= SFC::CompoundStatement::Cast( main_a60);
		SFC::DT dT_a67= array_a5c.dt();
		if( !dT_a67)
			continue;
		Match currMatch;
		currMatch.argDeclBase_a69= argDeclBase_a53;
		currMatch.array_a6a= array_a5c;
		currMatch.main_a6b= main_a65;
		currMatch.dT_a6c= dT_a67;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MakeArrayLoop_a3d::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::IterativeBlock newLoop_a6d= SFC::IterativeBlock::Create( currMatch.main_a6b);
		SFC::LocalVar newLoopIndex_a6e= SFC::LocalVar::Create( currMatch.main_a6b);
		SFC::UserCode newZeroLoopIndex_a6f= SFC::UserCode::Create( currMatch.main_a6b, SFC::CompoundStatement::meta_stmnt);
		SFC::BinaryExprs newAssignment_a70= SFC::BinaryExprs::Create( newZeroLoopIndex_a6f, SFC::UserCode::meta_codeexpr);
		SFC::ArgDeclRef newArgDeclRef1_a71= SFC::ArgDeclRef::Create( newAssignment_a70, SFC::BinaryExprs::meta_leftexpr);
		SFC::Int newZero_a72= SFC::Int::Create( newAssignment_a70, SFC::BinaryExprs::meta_rightexpr);
		SFC::UserCode newUserCode_a73= SFC::UserCode::Create( newLoop_a6d, SFC::IterativeBlock::meta_cond);
		SFC::BinaryExprs newLessThan_a74= SFC::BinaryExprs::Create( newUserCode_a73, SFC::UserCode::meta_codeexpr);
		SFC::ArgDeclRef newArgDeclRef2_a75= SFC::ArgDeclRef::Create( newLessThan_a74, SFC::BinaryExprs::meta_leftexpr);
		SFC::Int newLoopBound_a76= SFC::Int::Create( newLessThan_a74, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_a69;
		SFC::ArgDeclRef& ArgDeclRef1= newArgDeclRef1_a71;
		SFC::ArgDeclRef& ArgDeclRef2= newArgDeclRef2_a75;
		SFC::Array& Array= currMatch.array_a6a;
		SFC::BinaryExprs& Assignment= newAssignment_a70;
		SFC::DT& DT= currMatch.dT_a6c;
		SFC::BinaryExprs& LessThan= newLessThan_a74;
		SFC::IterativeBlock& Loop= newLoop_a6d;
		SFC::Int& LoopBound= newLoopBound_a76;
		SFC::LocalVar& LoopIndex= newLoopIndex_a6e;
		SFC::CompoundStatement& Main= currMatch.main_a6b;
		SFC::UserCode& UserCode= newUserCode_a73;
		SFC::Int& Zero= newZero_a72;
		SFC::UserCode& ZeroLoopIndex= newZeroLoopIndex_a6f;
		{
__int64 statementCount = Main.statementCount();

LoopIndex.statementIndex() = statementCount++;
ZeroLoopIndex.statementIndex() = statementCount++;
Loop.statementIndex() = statementCount++;

Main.statementCount() = statementCount;
};
		{
Assignment.op() = "=";
};
		{
Zero.val() = 0;
};
		{
LessThan.op() = "<";
};
		{
LoopIndex.name() = std::string( "ix" ) + boost::lexical_cast< std::string >( LoopIndex.uniqueId() );
LoopIndex.type() = std::string( "int" );
};
		currMatch.array_a6a.itb()+= newLoop_a6d;
		newArgDeclRef1_a71.argdecl()= newLoopIndex_a6e;
		newArgDeclRef2_a75.argdecl()= newLoopIndex_a6e;
		newLoop_a6d.counter()= newLoopIndex_a6e;
		outputAppender( currMatch.argDeclBase_a69, currMatch.array_a6a, currMatch.dT_a6c, newLoop_a6d);
	}
}

void MakeArrayLoop_a3d::outputAppender( const SFC::ArgDeclBase& argDeclBase_a77, const SFC::Array& array_a79, const SFC::DT& dT_a7b, const SFC::IterativeBlock& loop_a7d)
{
	_argDeclBase_a48->push_back( argDeclBase_a77);
	_array_a49->push_back( array_a79);
	_dT_a4a->push_back( dT_a7b);
	_loop_a4b->push_back( loop_a7d);
}

void StructTest_a7f::operator()( const Packets_t& passADBs_a80, const Packets_t& dts_a82, const Packets_t& mains_a84, Packets_t& passADBs_a86, Packets_t& basics_a87, Packets_t& mains_a88, Packets_t& passADBs_a89, Packets_t& nullarrays_a8a, Packets_t& mains_a8b, Packets_t& passADBs_a8c, Packets_t& arrays_a8d, Packets_t& mains_a8e, Packets_t& passADBs_a8f, Packets_t& structs_a90, Packets_t& mains_a91)
{
#ifdef PRINT_INFO
	std::cout << "StructTest_a7f" << std::endl;
#endif
	_passADB_a92= &passADBs_a86;
	_basic_a93= &basics_a87;
	_main_a94= &mains_a88;
	_passADB_a95= &passADBs_a89;
	_nullarray_a96= &nullarrays_a8a;
	_main_a97= &mains_a8b;
	_passADB_a98= &passADBs_a8c;
	_array_a99= &arrays_a8d;
	_main_a9a= &mains_a8e;
	_passADB_a9b= &passADBs_a8f;
	_struct_a9c= &structs_a90;
	_main_a9d= &mains_a91;
	for( Packets_t::const_iterator itpassADB_a9f= passADBs_a80.begin(), itdt_aa6= dts_a82.begin(), itMain_aad= mains_a84.begin(); itpassADB_a9f!= passADBs_a80.end(), itdt_aa6!= dts_a82.end(), itMain_aad!= mains_a84.end(); ++itpassADB_a9f, ++itdt_aa6, ++itMain_aad)
	{
		bool isUnique= isInputUnique( *itpassADB_a9f, *itdt_aa6, *itMain_aad);
		if( !isUnique)
			continue;
		Packets_t onepassADB_aa3( 1, *itpassADB_a9f);
		Packets_t onedt_aaa( 1, *itdt_aa6);
		Packets_t oneMain_ab1( 1, *itMain_aad);
		executeOne( onepassADB_aa3, onedt_aaa, oneMain_ab1);
	}
}

void StructTest_a7f::executeOne( const Packets_t& passADBs_a80, const Packets_t& dts_a82, const Packets_t& mains_a84)
{
	Packets_t argDeclBases_ab6;
	Packets_t basicTypes_ab9;
	Packets_t mains_abc;
	BasicType_ab3 basicType_ab3;
	bool isMatchBasicType_ab3= basicType_ab3( passADBs_a80, dts_a82, mains_a84, argDeclBases_ab6, basicTypes_ab9, mains_abc);
	_passADB_a92->insert( _passADB_a92->end(), argDeclBases_ab6.begin(), argDeclBases_ab6.end());
	_basic_a93->insert( _basic_a93->end(), basicTypes_ab9.begin(), basicTypes_ab9.end());
	_main_a94->insert( _main_a94->end(), mains_abc.begin(), mains_abc.end());
	if( isMatchBasicType_ab3)
		return;
	Packets_t argDeclBases_ae8;
	Packets_t arrays_aeb;
	Packets_t mains_aee;
	NullArray_ae5 nullArray_ae5;
	bool isMatchNullArray_ae5= nullArray_ae5( passADBs_a80, dts_a82, mains_a84, argDeclBases_ae8, arrays_aeb, mains_aee);
	_passADB_a95->insert( _passADB_a95->end(), argDeclBases_ae8.begin(), argDeclBases_ae8.end());
	_nullarray_a96->insert( _nullarray_a96->end(), arrays_aeb.begin(), arrays_aeb.end());
	_main_a97->insert( _main_a97->end(), mains_aee.begin(), mains_aee.end());
	if( isMatchNullArray_ae5)
		return;
	Packets_t argDeclBases_b1d;
	Packets_t arrays_b20;
	Packets_t mains_b23;
	Array_b1a array_b1a;
	bool isMatchArray_b1a= array_b1a( passADBs_a80, dts_a82, mains_a84, argDeclBases_b1d, arrays_b20, mains_b23);
	_passADB_a98->insert( _passADB_a98->end(), argDeclBases_b1d.begin(), argDeclBases_b1d.end());
	_array_a99->insert( _array_a99->end(), arrays_b20.begin(), arrays_b20.end());
	_main_a9a->insert( _main_a9a->end(), mains_b23.begin(), mains_b23.end());
	if( isMatchArray_b1a)
		return;
	Packets_t argDeclBases_b4f;
	Packets_t structs_b52;
	Packets_t mains_b55;
	Struct_b4c struct_b4c;
	bool isMatchStruct_b4c= struct_b4c( passADBs_a80, dts_a82, mains_a84, argDeclBases_b4f, structs_b52, mains_b55);
	_passADB_a9b->insert( _passADB_a9b->end(), argDeclBases_b4f.begin(), argDeclBases_b4f.end());
	_struct_a9c->insert( _struct_a9c->end(), structs_b52.begin(), structs_b52.end());
	_main_a9d->insert( _main_a9d->end(), mains_b55.begin(), mains_b55.end());
	if( isMatchStruct_b4c)
		return;
}

bool StructTest_a7f::isInputUnique( const Udm::Object& passADB_aa0, const Udm::Object& dt_aa7, const Udm::Object& main_aae)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itpassADB_aa2= _passADB_a9e.begin(), itdt_aa9= _dt_aa5.begin(), itMain_ab0= _main_aac.begin(); itpassADB_aa2!= _passADB_a9e.end(), itdt_aa9!= _dt_aa5.end(), itMain_ab0!= _main_aac.end(); ++itpassADB_aa2, ++itdt_aa9, ++itMain_ab0)
	{
		if( ( *itpassADB_aa2== passADB_aa0)&& ( *itdt_aa9== dt_aa7)&& ( *itMain_ab0== main_aae))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_passADB_a9e.push_back( passADB_aa0);
		_dt_aa5.push_back( dt_aa7);
		_main_aac.push_back( main_aae);
	}
	return isUnique;
}

bool BasicType_ab3::operator()( const Packets_t& argDeclBases_ab4, const Packets_t& basicTypes_ab7, const Packets_t& mains_aba, Packets_t& argDeclBases_ab6, Packets_t& basicTypes_ab9, Packets_t& mains_abc)
{
#ifdef PRINT_INFO
	std::cout << "BasicType_ab3" << std::endl;
#endif
	_argDeclBase_abd= &argDeclBases_ab6;
	_basicType_abe= &basicTypes_ab9;
	_main_abf= &mains_abc;
	processInputPackets( argDeclBases_ab4, basicTypes_ab7, mains_aba);
	if( false== _matches.empty())
		return true;
	return false;
}

bool BasicType_ab3::isInputUnique( const Udm::Object& argDeclBase_ac4, const Udm::Object& basicType_acd, const Udm::Object& main_ad6)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_ac6= _argDeclBase_ac0.begin(), itBasicType_acf= _basicType_ac9.begin(), itMain_ad8= _main_ad2.begin(); itArgDeclBase_ac6!= _argDeclBase_ac0.end(), itBasicType_acf!= _basicType_ac9.end(), itMain_ad8!= _main_ad2.end(); ++itArgDeclBase_ac6, ++itBasicType_acf, ++itMain_ad8)
	{
		if( ( *itArgDeclBase_ac6== argDeclBase_ac4)&& ( *itBasicType_acf== basicType_acd)&& ( *itMain_ad8== main_ad6))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_ac0.push_back( argDeclBase_ac4);
		_basicType_ac9.push_back( basicType_acd);
		_main_ad2.push_back( main_ad6);
	}
	return isUnique;
}

void BasicType_ab3::processInputPackets( const Packets_t& argDeclBases_ab4, const Packets_t& basicTypes_ab7, const Packets_t& mains_aba)
{
	for( Packets_t::const_iterator itArgDeclBase_ac1= argDeclBases_ab4.begin(), itBasicType_aca= basicTypes_ab7.begin(), itMain_ad3= mains_aba.begin(); itArgDeclBase_ac1!= argDeclBases_ab4.end(), itBasicType_aca!= basicTypes_ab7.end(), itMain_ad3!= mains_aba.end(); ++itArgDeclBase_ac1, ++itBasicType_aca, ++itMain_ad3)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_ac1, *itBasicType_aca, *itMain_ad3);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_ac1, *itBasicType_aca, *itMain_ad3);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_adc, currMatch.basicType_add, currMatch.main_ade);
	}
}

bool BasicType_ab3::patternMatcher( const Udm::Object& argDeclBase_ac2, const Udm::Object& basicType_acb, const Udm::Object& main_ad4)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_ac2.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_ac7= SFC::ArgDeclBase::Cast( argDeclBase_ac2);
		if( false== Uml::IsDerivedFrom( basicType_acb.type(), SFC::BasicType::meta))
			continue;
		SFC::BasicType basicType_ad0= SFC::BasicType::Cast( basicType_acb);
		if( false== Uml::IsDerivedFrom( main_ad4.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_ad9= SFC::CompoundStatement::Cast( main_ad4);
		Match currMatch;
		currMatch.argDeclBase_adc= argDeclBase_ac7;
		currMatch.basicType_add= basicType_ad0;
		currMatch.main_ade= main_ad9;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void BasicType_ab3::outputAppender( const SFC::ArgDeclBase& argDeclBase_adf, const SFC::BasicType& basicType_ae1, const SFC::CompoundStatement& main_ae3)
{
	_argDeclBase_abd->push_back( argDeclBase_adf);
	_basicType_abe->push_back( basicType_ae1);
	_main_abf->push_back( main_ae3);
}

bool NullArray_ae5::operator()( const Packets_t& argDeclBases_ae6, const Packets_t& arrays_ae9, const Packets_t& mains_aec, Packets_t& argDeclBases_ae8, Packets_t& arrays_aeb, Packets_t& mains_aee)
{
#ifdef PRINT_INFO
	std::cout << "NullArray_ae5" << std::endl;
#endif
	_argDeclBase_aef= &argDeclBases_ae8;
	_array_af0= &arrays_aeb;
	_main_af1= &mains_aee;
	processInputPackets( argDeclBases_ae6, arrays_ae9, mains_aec);
	if( false== _matches.empty())
		return true;
	return false;
}

bool NullArray_ae5::isInputUnique( const Udm::Object& argDeclBase_af6, const Udm::Object& array_aff, const Udm::Object& main_b08)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_af8= _argDeclBase_af2.begin(), itArray_b01= _array_afb.begin(), itMain_b0a= _main_b04.begin(); itArgDeclBase_af8!= _argDeclBase_af2.end(), itArray_b01!= _array_afb.end(), itMain_b0a!= _main_b04.end(); ++itArgDeclBase_af8, ++itArray_b01, ++itMain_b0a)
	{
		if( ( *itArgDeclBase_af8== argDeclBase_af6)&& ( *itArray_b01== array_aff)&& ( *itMain_b0a== main_b08))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_af2.push_back( argDeclBase_af6);
		_array_afb.push_back( array_aff);
		_main_b04.push_back( main_b08);
	}
	return isUnique;
}

bool NullArray_ae5::isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Array& Array, SFC::CompoundStatement& Main)
{
	bool Gz_guard= false;
	Gz_guard = Array.noelem() <= 1;;
	return Gz_guard;
}

void NullArray_ae5::processInputPackets( const Packets_t& argDeclBases_ae6, const Packets_t& arrays_ae9, const Packets_t& mains_aec)
{
	for( Packets_t::const_iterator itArgDeclBase_af3= argDeclBases_ae6.begin(), itArray_afc= arrays_ae9.begin(), itMain_b05= mains_aec.begin(); itArgDeclBase_af3!= argDeclBases_ae6.end(), itArray_afc!= arrays_ae9.end(), itMain_b05!= mains_aec.end(); ++itArgDeclBase_af3, ++itArray_afc, ++itMain_b05)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_af3, *itArray_afc, *itMain_b05);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_af3, *itArray_afc, *itMain_b05);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_b0e, currMatch.array_b0f, currMatch.main_b10);
	}
}

bool NullArray_ae5::patternMatcher( const Udm::Object& argDeclBase_af4, const Udm::Object& array_afd, const Udm::Object& main_b06)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_af4.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_af9= SFC::ArgDeclBase::Cast( argDeclBase_af4);
		if( false== Uml::IsDerivedFrom( array_afd.type(), SFC::Array::meta))
			continue;
		SFC::Array array_b02= SFC::Array::Cast( array_afd);
		if( false== Uml::IsDerivedFrom( main_b06.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_b0b= SFC::CompoundStatement::Cast( main_b06);
		Match currMatch;
		currMatch.argDeclBase_b0e= argDeclBase_af9;
		currMatch.array_b0f= array_b02;
		currMatch.main_b10= main_b0b;
		bool Gz_guard= isGuardTrue( currMatch.argDeclBase_b0e, currMatch.array_b0f, currMatch.main_b10);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void NullArray_ae5::outputAppender( const SFC::ArgDeclBase& argDeclBase_b14, const SFC::Array& array_b16, const SFC::CompoundStatement& main_b18)
{
	_argDeclBase_aef->push_back( argDeclBase_b14);
	_array_af0->push_back( array_b16);
	_main_af1->push_back( main_b18);
}

bool Array_b1a::operator()( const Packets_t& argDeclBases_b1b, const Packets_t& arrays_b1e, const Packets_t& mains_b21, Packets_t& argDeclBases_b1d, Packets_t& arrays_b20, Packets_t& mains_b23)
{
#ifdef PRINT_INFO
	std::cout << "Array_b1a" << std::endl;
#endif
	_argDeclBase_b24= &argDeclBases_b1d;
	_array_b25= &arrays_b20;
	_main_b26= &mains_b23;
	processInputPackets( argDeclBases_b1b, arrays_b1e, mains_b21);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Array_b1a::isInputUnique( const Udm::Object& argDeclBase_b2b, const Udm::Object& array_b34, const Udm::Object& main_b3d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_b2d= _argDeclBase_b27.begin(), itArray_b36= _array_b30.begin(), itMain_b3f= _main_b39.begin(); itArgDeclBase_b2d!= _argDeclBase_b27.end(), itArray_b36!= _array_b30.end(), itMain_b3f!= _main_b39.end(); ++itArgDeclBase_b2d, ++itArray_b36, ++itMain_b3f)
	{
		if( ( *itArgDeclBase_b2d== argDeclBase_b2b)&& ( *itArray_b36== array_b34)&& ( *itMain_b3f== main_b3d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_b27.push_back( argDeclBase_b2b);
		_array_b30.push_back( array_b34);
		_main_b39.push_back( main_b3d);
	}
	return isUnique;
}

void Array_b1a::processInputPackets( const Packets_t& argDeclBases_b1b, const Packets_t& arrays_b1e, const Packets_t& mains_b21)
{
	for( Packets_t::const_iterator itArgDeclBase_b28= argDeclBases_b1b.begin(), itArray_b31= arrays_b1e.begin(), itMain_b3a= mains_b21.begin(); itArgDeclBase_b28!= argDeclBases_b1b.end(), itArray_b31!= arrays_b1e.end(), itMain_b3a!= mains_b21.end(); ++itArgDeclBase_b28, ++itArray_b31, ++itMain_b3a)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_b28, *itArray_b31, *itMain_b3a);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_b28, *itArray_b31, *itMain_b3a);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_b43, currMatch.array_b44, currMatch.main_b45);
	}
}

bool Array_b1a::patternMatcher( const Udm::Object& argDeclBase_b29, const Udm::Object& array_b32, const Udm::Object& main_b3b)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_b29.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_b2e= SFC::ArgDeclBase::Cast( argDeclBase_b29);
		if( false== Uml::IsDerivedFrom( array_b32.type(), SFC::Array::meta))
			continue;
		SFC::Array array_b37= SFC::Array::Cast( array_b32);
		if( false== Uml::IsDerivedFrom( main_b3b.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_b40= SFC::CompoundStatement::Cast( main_b3b);
		Match currMatch;
		currMatch.argDeclBase_b43= argDeclBase_b2e;
		currMatch.array_b44= array_b37;
		currMatch.main_b45= main_b40;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Array_b1a::outputAppender( const SFC::ArgDeclBase& argDeclBase_b46, const SFC::Array& array_b48, const SFC::CompoundStatement& main_b4a)
{
	_argDeclBase_b24->push_back( argDeclBase_b46);
	_array_b25->push_back( array_b48);
	_main_b26->push_back( main_b4a);
}

bool Struct_b4c::operator()( const Packets_t& argDeclBases_b4d, const Packets_t& structs_b50, const Packets_t& mains_b53, Packets_t& argDeclBases_b4f, Packets_t& structs_b52, Packets_t& mains_b55)
{
#ifdef PRINT_INFO
	std::cout << "Struct_b4c" << std::endl;
#endif
	_argDeclBase_b56= &argDeclBases_b4f;
	_struct_b57= &structs_b52;
	_main_b58= &mains_b55;
	processInputPackets( argDeclBases_b4d, structs_b50, mains_b53);
	if( false== _matches.empty())
		return true;
	return false;
}

bool Struct_b4c::isInputUnique( const Udm::Object& argDeclBase_b5d, const Udm::Object& struct_b66, const Udm::Object& main_b6f)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_b5f= _argDeclBase_b59.begin(), itStruct_b68= _struct_b62.begin(), itMain_b71= _main_b6b.begin(); itArgDeclBase_b5f!= _argDeclBase_b59.end(), itStruct_b68!= _struct_b62.end(), itMain_b71!= _main_b6b.end(); ++itArgDeclBase_b5f, ++itStruct_b68, ++itMain_b71)
	{
		if( ( *itArgDeclBase_b5f== argDeclBase_b5d)&& ( *itStruct_b68== struct_b66)&& ( *itMain_b71== main_b6f))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_b59.push_back( argDeclBase_b5d);
		_struct_b62.push_back( struct_b66);
		_main_b6b.push_back( main_b6f);
	}
	return isUnique;
}

void Struct_b4c::processInputPackets( const Packets_t& argDeclBases_b4d, const Packets_t& structs_b50, const Packets_t& mains_b53)
{
	for( Packets_t::const_iterator itArgDeclBase_b5a= argDeclBases_b4d.begin(), itStruct_b63= structs_b50.begin(), itMain_b6c= mains_b53.begin(); itArgDeclBase_b5a!= argDeclBases_b4d.end(), itStruct_b63!= structs_b50.end(), itMain_b6c!= mains_b53.end(); ++itArgDeclBase_b5a, ++itStruct_b63, ++itMain_b6c)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_b5a, *itStruct_b63, *itMain_b6c);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_b5a, *itStruct_b63, *itMain_b6c);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.argDeclBase_b75, currMatch.struct_b76, currMatch.main_b77);
	}
}

bool Struct_b4c::patternMatcher( const Udm::Object& argDeclBase_b5b, const Udm::Object& struct_b64, const Udm::Object& main_b6d)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_b5b.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_b60= SFC::ArgDeclBase::Cast( argDeclBase_b5b);
		if( false== Uml::IsDerivedFrom( struct_b64.type(), SFC::Struct::meta))
			continue;
		SFC::Struct struct_b69= SFC::Struct::Cast( struct_b64);
		if( false== Uml::IsDerivedFrom( main_b6d.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_b72= SFC::CompoundStatement::Cast( main_b6d);
		Match currMatch;
		currMatch.argDeclBase_b75= argDeclBase_b60;
		currMatch.struct_b76= struct_b69;
		currMatch.main_b77= main_b72;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void Struct_b4c::outputAppender( const SFC::ArgDeclBase& argDeclBase_b78, const SFC::Struct& struct_b7a, const SFC::CompoundStatement& main_b7c)
{
	_argDeclBase_b56->push_back( argDeclBase_b78);
	_struct_b57->push_back( struct_b7a);
	_main_b58->push_back( main_b7c);
}

void BasicType_b7e::operator()( const Packets_t& argDeclBases_b7f, const Packets_t& basicTypes_b82, const Packets_t& compoundStatements_b85, Packets_t& argDeclBases_b81, Packets_t& basicTypes_b84, Packets_t& compoundStatements_b87, Packets_t& unaryExprss_b88)
{
#ifdef PRINT_INFO
	std::cout << "BasicType_b7e" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(508, "BasicType");
	_argDeclBase_b89= &argDeclBases_b81;
	_basicType_b8a= &basicTypes_b84;
	_compoundStatement_b8b= &compoundStatements_b87;
	_unaryExprs_b8c= &unaryExprss_b88;
	processInputPackets( argDeclBases_b7f, basicTypes_b82, compoundStatements_b85);
}

bool BasicType_b7e::isInputUnique( const Udm::Object& argDeclBase_b91, const Udm::Object& basicType_b9a, const Udm::Object& compoundStatement_ba3)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_b93= _argDeclBase_b8d.begin(), itBasicType_b9c= _basicType_b96.begin(), itCompoundStatement_ba5= _compoundStatement_b9f.begin(); itArgDeclBase_b93!= _argDeclBase_b8d.end(), itBasicType_b9c!= _basicType_b96.end(), itCompoundStatement_ba5!= _compoundStatement_b9f.end(); ++itArgDeclBase_b93, ++itBasicType_b9c, ++itCompoundStatement_ba5)
	{
		if( ( *itArgDeclBase_b93== argDeclBase_b91)&& ( *itBasicType_b9c== basicType_b9a)&& ( *itCompoundStatement_ba5== compoundStatement_ba3))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_b8d.push_back( argDeclBase_b91);
		_basicType_b96.push_back( basicType_b9a);
		_compoundStatement_b9f.push_back( compoundStatement_ba3);
	}
	return isUnique;
}

void BasicType_b7e::processInputPackets( const Packets_t& argDeclBases_b7f, const Packets_t& basicTypes_b82, const Packets_t& compoundStatements_b85)
{
	for( Packets_t::const_iterator itArgDeclBase_b8e= argDeclBases_b7f.begin(), itBasicType_b97= basicTypes_b82.begin(), itCompoundStatement_ba0= compoundStatements_b85.begin(); itArgDeclBase_b8e!= argDeclBases_b7f.end(), itBasicType_b97!= basicTypes_b82.end(), itCompoundStatement_ba0!= compoundStatements_b85.end(); ++itArgDeclBase_b8e, ++itBasicType_b97, ++itCompoundStatement_ba0)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_b8e, *itBasicType_b97, *itCompoundStatement_ba0);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_b8e, *itBasicType_b97, *itCompoundStatement_ba0);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool BasicType_b7e::patternMatcher( const Udm::Object& argDeclBase_b8f, const Udm::Object& basicType_b98, const Udm::Object& compoundStatement_ba1)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_b8f.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_b94= SFC::ArgDeclBase::Cast( argDeclBase_b8f);
		if( false== Uml::IsDerivedFrom( basicType_b98.type(), SFC::BasicType::meta))
			continue;
		SFC::BasicType basicType_b9d= SFC::BasicType::Cast( basicType_b98);
		if( false== Uml::IsDerivedFrom( compoundStatement_ba1.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStatement_ba6= SFC::CompoundStatement::Cast( compoundStatement_ba1);
		Match currMatch;
		currMatch.argDeclBase_ba9= argDeclBase_b94;
		currMatch.basicType_baa= basicType_b9d;
		currMatch.compoundStatement_bab= compoundStatement_ba6;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void BasicType_b7e::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::FunctionCall newFunctionCall_bac= SFC::FunctionCall::Create( currMatch.compoundStatement_bab);
		SFC::ArgVal newVarArgVal_bad= SFC::ArgVal::Create( newFunctionCall_bac);
		SFC::UnaryExprs newUnaryExprs_bae= SFC::UnaryExprs::Create( newVarArgVal_bad, SFC::ArgVal::meta_argexpr);
		SFC::ArgVal newFormatArgVal_baf= SFC::ArgVal::Create( newFunctionCall_bac);
		SFC::Str newFormat_bb0= SFC::Str::Create( newFormatArgVal_baf, SFC::ArgVal::meta_argexpr);
		SFC::ArgDeclBase& ArgDeclBase= currMatch.argDeclBase_ba9;
		SFC::BasicType& BasicType= currMatch.basicType_baa;
		SFC::CompoundStatement& CompoundStatement= currMatch.compoundStatement_bab;
		SFC::Str& Format= newFormat_bb0;
		SFC::ArgVal& FormatArgVal= newFormatArgVal_baf;
		SFC::FunctionCall& FunctionCall= newFunctionCall_bac;
		SFC::UnaryExprs& UnaryExprs= newUnaryExprs_bae;
		SFC::ArgVal& VarArgVal= newVarArgVal_bad;
		{
__int64 statementCount = CompoundStatement.statementCount();
FunctionCall.statementIndex() = statementCount++;
CompoundStatement.statementCount() = statementCount;

std::string type = CTypeMap::lookup(  static_cast< std::string >( BasicType.name() )  );

FunctionCall.libFuncName() = "printf";
FunctionCall.argCount() = 2;

FormatArgVal.argIndex() = 0;
VarArgVal.argIndex() = 1;

if ( type == "double" || type == "float" ) {
  FunctionCall.libFuncName() = "mprintf";
  Format.val() = "%.40g, ";
} else if ( type == "int" || type == "short" || type == "char" ) {
  Format.val() = "%d, ";
} else if ( type == "unsigned char" || type == "unsigned short" || type == "unsigned int" ) {
  Format.val() = "%u, ";
} else {
  throw udm_exception( "Unknown type " + type );
}
};
		outputAppender( currMatch.argDeclBase_ba9, currMatch.basicType_baa, currMatch.compoundStatement_bab, newUnaryExprs_bae);
	}
}

void BasicType_b7e::outputAppender( const SFC::ArgDeclBase& argDeclBase_bb1, const SFC::BasicType& basicType_bb3, const SFC::CompoundStatement& compoundStatement_bb5, const SFC::UnaryExprs& unaryExprs_bb7)
{
	_argDeclBase_b89->push_back( argDeclBase_bb1);
	_basicType_b8a->push_back( basicType_bb3);
	_compoundStatement_b8b->push_back( compoundStatement_bb5);
	_unaryExprs_b8c->push_back( unaryExprs_bb7);
}

void MakePath_bb9::operator()( const Packets_t& argDeclBases_bba, const Packets_t& structs_bbc, const Packets_t& mains_bbf, Packets_t& structs_bbe, Packets_t& mains_bc1)
{
#ifdef PRINT_INFO
	std::cout << "MakePath_bb9" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(523, "MakePath");
	_struct_bc2= &structs_bbe;
	_main_bc3= &mains_bc1;
	processInputPackets( argDeclBases_bba, structs_bbc, mains_bbf);
	sortOutputs( );
}

bool MakePath_bb9::isInputUnique( const Udm::Object& argDeclBase_bc8, const Udm::Object& struct_bd1, const Udm::Object& main_bda)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_bca= _argDeclBase_bc4.begin(), itStruct_bd3= _struct_bcd.begin(), itMain_bdc= _main_bd6.begin(); itArgDeclBase_bca!= _argDeclBase_bc4.end(), itStruct_bd3!= _struct_bcd.end(), itMain_bdc!= _main_bd6.end(); ++itArgDeclBase_bca, ++itStruct_bd3, ++itMain_bdc)
	{
		if( ( *itArgDeclBase_bca== argDeclBase_bc8)&& ( *itStruct_bd3== struct_bd1)&& ( *itMain_bdc== main_bda))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_bc4.push_back( argDeclBase_bc8);
		_struct_bcd.push_back( struct_bd1);
		_main_bd6.push_back( main_bda);
	}
	return isUnique;
}

void MakePath_bb9::processInputPackets( const Packets_t& argDeclBases_bba, const Packets_t& structs_bbc, const Packets_t& mains_bbf)
{
	for( Packets_t::const_iterator itArgDeclBase_bc5= argDeclBases_bba.begin(), itStruct_bce= structs_bbc.begin(), itMain_bd7= mains_bbf.begin(); itArgDeclBase_bc5!= argDeclBases_bba.end(), itStruct_bce!= structs_bbc.end(), itMain_bd7!= mains_bbf.end(); ++itArgDeclBase_bc5, ++itStruct_bce, ++itMain_bd7)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_bc5, *itStruct_bce, *itMain_bd7);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_bc5, *itStruct_bce, *itMain_bd7);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MakePath_bb9::patternMatcher( const Udm::Object& argDeclBase_bc6, const Udm::Object& struct_bcf, const Udm::Object& main_bd8)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_bc6.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_bcb= SFC::ArgDeclBase::Cast( argDeclBase_bc6);
		if( false== Uml::IsDerivedFrom( struct_bcf.type(), SFC::Struct::meta))
			continue;
		SFC::Struct struct_bd4= SFC::Struct::Cast( struct_bcf);
		if( false== Uml::IsDerivedFrom( main_bd8.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_bdd= SFC::CompoundStatement::Cast( main_bd8);
		Match currMatch;
		currMatch.argDeclBase_be0= argDeclBase_bcb;
		currMatch.struct_be1= struct_bd4;
		currMatch.main_be2= main_bdd;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MakePath_bb9::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		currMatch.argDeclBase_be0.strctpath()+= currMatch.struct_be1;
		outputAppender( currMatch.struct_be1, currMatch.main_be2);
	}
}

void MakePath_bb9::outputAppender( const SFC::Struct& struct_be3, const SFC::CompoundStatement& main_be5)
{
	_struct_bc2->push_back( struct_be3);
	_main_bc3->push_back( main_be5);
}

void MakePath_bb9::sortOutputs()
{
	typedef std::multiset< SFC::Struct, std::pointer_to_binary_function< const SFC::Struct&, const SFC::Struct&, bool> > SortedSet_t;
	std::pointer_to_binary_function< const SFC::Struct&, const SFC::Struct&, bool> ptr_StatementOrder( StatementOrder< SFC::Struct>);
	SortedSet_t sortedSet( ptr_StatementOrder);
	std::vector< int> permutationVector( _struct_bc2->size());
	int currStep= 0;
	for( Packets_t::const_iterator it= _struct_bc2->begin(); it!= _struct_bc2->end(); ++it, ++currStep)
	{
		SortedSet_t::const_iterator inserted= sortedSet.insert( SFC::Struct::Cast(*it));
		SortedSet_t::difference_type pos= std::distance( SortedSet_t::const_iterator( sortedSet.begin()), inserted);
		permutationVector[ currStep]=  pos;
		for( int i= 0; i< currStep; ++i)
		{
			if( permutationVector[ i] >= pos)
				++permutationVector[ i];
		}
	}
	// order the primary container
	std::copy( sortedSet.begin(), sortedSet.end(), _struct_bc2->begin());
	// order rest of the containers
	permutate( permutationVector, *_main_bc3);
}

void AddVar_c28::operator()( const Packets_t& argDeclBases_c29, const Packets_t& unaryExprss_c2b)
{
#ifdef PRINT_INFO
	std::cout << "AddVar_c28" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(528, "AddVar");
	processInputPackets( argDeclBases_c29, unaryExprss_c2b);
}

bool AddVar_c28::isInputUnique( const Udm::Object& argDeclBase_c31, const Udm::Object& unaryExprs_c3a)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgDeclBase_c33= _argDeclBase_c2d.begin(), itUnaryExprs_c3c= _unaryExprs_c36.begin(); itArgDeclBase_c33!= _argDeclBase_c2d.end(), itUnaryExprs_c3c!= _unaryExprs_c36.end(); ++itArgDeclBase_c33, ++itUnaryExprs_c3c)
	{
		if( ( *itArgDeclBase_c33== argDeclBase_c31)&& ( *itUnaryExprs_c3c== unaryExprs_c3a))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argDeclBase_c2d.push_back( argDeclBase_c31);
		_unaryExprs_c36.push_back( unaryExprs_c3a);
	}
	return isUnique;
}

bool AddVar_c28::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void AddVar_c28::processInputPackets( const Packets_t& argDeclBases_c29, const Packets_t& unaryExprss_c2b)
{
	for( Packets_t::const_iterator itArgDeclBase_c2e= argDeclBases_c29.begin(), itUnaryExprs_c37= unaryExprss_c2b.begin(); itArgDeclBase_c2e!= argDeclBases_c29.end(), itUnaryExprs_c37!= unaryExprss_c2b.end(); ++itArgDeclBase_c2e, ++itUnaryExprs_c37)
	{
		bool isUnique= isInputUnique( *itArgDeclBase_c2e, *itUnaryExprs_c37);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArgDeclBase_c2e, *itUnaryExprs_c37);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool AddVar_c28::patternMatcher( const Udm::Object& argDeclBase_c2f, const Udm::Object& unaryExprs_c38)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( argDeclBase_c2f.type(), SFC::ArgDeclBase::meta))
			continue;
		SFC::ArgDeclBase argDeclBase_c34= SFC::ArgDeclBase::Cast( argDeclBase_c2f);
		if( false== Uml::IsDerivedFrom( unaryExprs_c38.type(), SFC::UnaryExprs::meta))
			continue;
		SFC::UnaryExprs unaryExprs_c3d= SFC::UnaryExprs::Cast( unaryExprs_c38);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_c42;
		if( !isValidBound(boundObjs_c42, argDeclBase_c34, true))
			continue;
		currMatch.argDeclBase_c43= argDeclBase_c34;
		if( !isValidBound(boundObjs_c42, unaryExprs_c3d, true))
			continue;
		currMatch.unaryExprs_c44= unaryExprs_c3d;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void AddVar_c28::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::ArgDeclRef newArgDeclRef_c45= SFC::ArgDeclRef::Create( currMatch.unaryExprs_c44, SFC::UnaryExprs::meta_subexpr);
		newArgDeclRef_c45.argdecl()= currMatch.argDeclBase_c43;
	}
}

void GetDT_c46::operator()( const Packets_t& vars_c47, const Packets_t& mains_c4b, Packets_t& vars_c49, Packets_t& dTs_c4a, Packets_t& mains_c4d)
{
#ifdef PRINT_INFO
	std::cout << "GetDT_c46" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(534, "GetDT");
	_var_c4e= &vars_c49;
	_dT_c4f= &dTs_c4a;
	_main_c50= &mains_c4d;
	processInputPackets( vars_c47, mains_c4b);
}

bool GetDT_c46::isInputUnique( const Udm::Object& var_c55, const Udm::Object& main_c5e)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itVar_c57= _var_c51.begin(), itMain_c60= _main_c5a.begin(); itVar_c57!= _var_c51.end(), itMain_c60!= _main_c5a.end(); ++itVar_c57, ++itMain_c60)
	{
		if( ( *itVar_c57== var_c55)&& ( *itMain_c60== main_c5e))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_var_c51.push_back( var_c55);
		_main_c5a.push_back( main_c5e);
	}
	return isUnique;
}

bool GetDT_c46::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetDT_c46::processInputPackets( const Packets_t& vars_c47, const Packets_t& mains_c4b)
{
	for( Packets_t::const_iterator itVar_c52= vars_c47.begin(), itMain_c5b= mains_c4b.begin(); itVar_c52!= vars_c47.end(), itMain_c5b!= mains_c4b.end(); ++itVar_c52, ++itMain_c5b)
	{
		bool isUnique= isInputUnique( *itVar_c52, *itMain_c5b);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itVar_c52, *itMain_c5b);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetDT_c46::patternMatcher( const Udm::Object& var_c53, const Udm::Object& main_c5c)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( var_c53.type(), SFC::LocalVar::meta))
			continue;
		SFC::LocalVar var_c58= SFC::LocalVar::Cast( var_c53);
		if( false== Uml::IsDerivedFrom( main_c5c.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_c61= SFC::CompoundStatement::Cast( main_c5c);
		SFC::DT dT_c63= var_c58.dt();
		if( !dT_c63)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_c67;
		if( !isValidBound(boundObjs_c67, var_c58, true))
			continue;
		currMatch.var_c68= var_c58;
		if( !isValidBound(boundObjs_c67, main_c61, true))
			continue;
		currMatch.main_c69= main_c61;
		if( !isValidBound(boundObjs_c67, dT_c63, false))
			continue;
		currMatch.dT_c6a= dT_c63;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void GetDT_c46::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.var_c68, currMatch.dT_c6a, currMatch.main_c69);
	}
}

void GetDT_c46::outputAppender( const SFC::LocalVar& var_c6b, const SFC::DT& dT_c6d, const SFC::CompoundStatement& main_c6f)
{
	_var_c4e->push_back( var_c6b);
	_dT_c4f->push_back( dT_c6d);
	_main_c50->push_back( main_c6f);
}

void GetVarsForArgs_c71::operator()( const Packets_t& args_c72, const Packets_t& mains_c75, Packets_t& vars_c74, Packets_t& mains_c77)
{
#ifdef PRINT_INFO
	std::cout << "GetVarsForArgs_c71" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(539, "GetVarsForArgs");
	_var_c78= &vars_c74;
	_main_c79= &mains_c77;
	processInputPackets( args_c72, mains_c75);
}

bool GetVarsForArgs_c71::isInputUnique( const Udm::Object& arg_c7e, const Udm::Object& main_c87)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArg_c80= _arg_c7a.begin(), itMain_c89= _main_c83.begin(); itArg_c80!= _arg_c7a.end(), itMain_c89!= _main_c83.end(); ++itArg_c80, ++itMain_c89)
	{
		if( ( *itArg_c80== arg_c7e)&& ( *itMain_c89== main_c87))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_arg_c7a.push_back( arg_c7e);
		_main_c83.push_back( main_c87);
	}
	return isUnique;
}

bool GetVarsForArgs_c71::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetVarsForArgs_c71::processInputPackets( const Packets_t& args_c72, const Packets_t& mains_c75)
{
	for( Packets_t::const_iterator itArg_c7b= args_c72.begin(), itMain_c84= mains_c75.begin(); itArg_c7b!= args_c72.end(), itMain_c84!= mains_c75.end(); ++itArg_c7b, ++itMain_c84)
	{
		bool isUnique= isInputUnique( *itArg_c7b, *itMain_c84);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArg_c7b, *itMain_c84);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetVarsForArgs_c71::patternMatcher( const Udm::Object& arg_c7c, const Udm::Object& main_c85)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( arg_c7c.type(), SFC::Arg::meta))
			continue;
		SFC::Arg arg_c81= SFC::Arg::Cast( arg_c7c);
		if( false== Uml::IsDerivedFrom( main_c85.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_c8a= SFC::CompoundStatement::Cast( main_c85);
		SFC::LocalVar var_c8c= arg_c81.actual();
		if( !var_c8c)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_c90;
		if( !isValidBound(boundObjs_c90, arg_c81, true))
			continue;
		currMatch.arg_c91= arg_c81;
		if( !isValidBound(boundObjs_c90, main_c8a, true))
			continue;
		currMatch.main_c92= main_c8a;
		if( !isValidBound(boundObjs_c90, var_c8c, false))
			continue;
		currMatch.var_c93= var_c8c;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void GetVarsForArgs_c71::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.var_c93, currMatch.main_c92);
	}
}

void GetVarsForArgs_c71::outputAppender( const SFC::LocalVar& var_c94, const SFC::CompoundStatement& main_c96)
{
	_var_c78->push_back( var_c94);
	_main_c79->push_back( main_c96);
}

void GetSortedArgs_c98::operator()( const Packets_t& modelMains_c9a, const Packets_t& mains_c9c, Packets_t& args_c99, Packets_t& mains_c9e)
{
#ifdef PRINT_INFO
	std::cout << "GetSortedArgs_c98" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(544, "GetSortedArgs");
	_arg_c9f= &args_c99;
	_main_ca0= &mains_c9e;
	processInputPackets( modelMains_c9a, mains_c9c);
	sortOutputs( );
}

bool GetSortedArgs_c98::isInputUnique( const Udm::Object& modelMain_ca5, const Udm::Object& main_cae)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itModelMain_ca7= _modelMain_ca1.begin(), itMain_cb0= _main_caa.begin(); itModelMain_ca7!= _modelMain_ca1.end(), itMain_cb0!= _main_caa.end(); ++itModelMain_ca7, ++itMain_cb0)
	{
		if( ( *itModelMain_ca7== modelMain_ca5)&& ( *itMain_cb0== main_cae))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_modelMain_ca1.push_back( modelMain_ca5);
		_main_caa.push_back( main_cae);
	}
	return isUnique;
}

bool GetSortedArgs_c98::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

bool GetSortedArgs_c98::isGuardTrue( SFC::Arg& Arg, SFC::CompoundStatement& Main, SFC::Function& ModelMain)
{
	bool Gz_guard= false;
	Gz_guard = Arg.argIndex() != 0;;
	return Gz_guard;
}

void GetSortedArgs_c98::processInputPackets( const Packets_t& modelMains_c9a, const Packets_t& mains_c9c)
{
	for( Packets_t::const_iterator itModelMain_ca2= modelMains_c9a.begin(), itMain_cab= mains_c9c.begin(); itModelMain_ca2!= modelMains_c9a.end(), itMain_cab!= mains_c9c.end(); ++itModelMain_ca2, ++itMain_cab)
	{
		bool isUnique= isInputUnique( *itModelMain_ca2, *itMain_cab);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itModelMain_ca2, *itMain_cab);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetSortedArgs_c98::patternMatcher( const Udm::Object& modelMain_ca3, const Udm::Object& main_cac)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( modelMain_ca3.type(), SFC::Function::meta))
			continue;
		SFC::Function modelMain_ca8= SFC::Function::Cast( modelMain_ca3);
		if( false== Uml::IsDerivedFrom( main_cac.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_cb1= SFC::CompoundStatement::Cast( main_cac);
		set< SFC::Arg> args_cb3= modelMain_ca8.Arg_kind_children();
		for( set< SFC::Arg>::const_iterator itArg_cb4= args_cb3.begin(); itArg_cb4!= args_cb3.end(); ++itArg_cb4)
		{
			SFC::Arg currArg_cb5= *itArg_cb4;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_cb9;
			if( !isValidBound(boundObjs_cb9, modelMain_ca8, true))
				continue;
			currMatch.modelMain_cba= modelMain_ca8;
			if( !isValidBound(boundObjs_cb9, main_cb1, true))
				continue;
			currMatch.main_cbb= main_cb1;
			if( !isValidBound(boundObjs_cb9, currArg_cb5, false))
				continue;
			currMatch.arg_cbc= currArg_cb5;
			bool Gz_guard= isGuardTrue( currMatch.arg_cbc, currMatch.main_cbb, currMatch.modelMain_cba);
			if( true== Gz_guard)
				_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void GetSortedArgs_c98::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.arg_cbc, currMatch.main_cbb);
	}
}

void GetSortedArgs_c98::outputAppender( const SFC::Arg& arg_cc0, const SFC::CompoundStatement& main_cc2)
{
	_arg_c9f->push_back( arg_cc0);
	_main_ca0->push_back( main_cc2);
}

void GetSortedArgs_c98::sortOutputs()
{
	typedef std::multiset< SFC::Arg, std::pointer_to_binary_function< const SFC::Arg&, const SFC::Arg&, bool> > SortedSet_t;
	std::pointer_to_binary_function< const SFC::Arg&, const SFC::Arg&, bool> ptr_ArgOrder( ArgOrder< SFC::Arg>);
	SortedSet_t sortedSet( ptr_ArgOrder);
	std::vector< int> permutationVector( _arg_c9f->size());
	int currStep= 0;
	for( Packets_t::const_iterator it= _arg_c9f->begin(); it!= _arg_c9f->end(); ++it, ++currStep)
	{
		SortedSet_t::const_iterator inserted= sortedSet.insert( SFC::Arg::Cast(*it));
		SortedSet_t::difference_type pos= std::distance( SortedSet_t::const_iterator( sortedSet.begin()), inserted);
		permutationVector[ currStep]=  pos;
		for( int i= 0; i< currStep; ++i)
		{
			if( permutationVector[ i] >= pos)
				++permutationVector[ i];
		}
	}
	// order the primary container
	std::copy( sortedSet.begin(), sortedSet.end(), _arg_c9f->begin());
	// order rest of the containers
	permutate( permutationVector, *_main_ca0);
}

void CreateLoop_cd9::operator()( const Packets_t& classs_cda, const Packets_t& mains_cdc, Packets_t& modelMains_cde, Packets_t& mains_cdf, Packets_t& loops_ce0)
{
#ifdef PRINT_INFO
	std::cout << "CreateLoop_cd9" << std::endl;
#endif
	_modelMain_ce1= &modelMains_cde;
	_main_ce2= &mains_cdf;
	_loop_ce3= &loops_ce0;
	if( ( !classs_cda.empty())&& ( !mains_cdc.empty()))
		callCreateLoop_d49( classs_cda, mains_cdc);
}

void CreateLoop_cd9::callCreateLoop_d49( const Packets_t& classs_d0f, const Packets_t& mains_d11)
{
	Packets_t modelMains_d0e;
	Packets_t mains_d13;
	Packets_t iterativeBlocks_d14;
	Packets_t counters_d15;
	CreateLoop_d0d createLoop_d0d;
	createLoop_d0d( classs_d0f, mains_d11, modelMains_d0e, mains_d13, iterativeBlocks_d14, counters_d15);
	if( ( !modelMains_d0e.empty())&& ( !mains_d13.empty())&& ( !iterativeBlocks_d14.empty())&& ( !counters_d15.empty()))
		callIncrementCounter_d4c( modelMains_d0e, mains_d13, iterativeBlocks_d14, counters_d15);
}

void CreateLoop_cd9::callIncrementCounter_d4c( const Packets_t& modelMains_ce5, const Packets_t& mains_ce7, const Packets_t& iterativeBlocks_ce9, const Packets_t& counters_ceb)
{
	Packets_t modelMains_ced;
	Packets_t mains_cee;
	Packets_t loops_cef;
	Packets_t counters_cf0;
	IncrementCounter_ce4 incrementCounter_ce4;
	incrementCounter_ce4( modelMains_ce5, mains_ce7, iterativeBlocks_ce9, counters_ceb, modelMains_ced, mains_cee, loops_cef, counters_cf0);
	_modelMain_ce1->insert( _modelMain_ce1->end(), modelMains_ced.begin(), modelMains_ced.end());
	_main_ce2->insert( _main_ce2->end(), mains_cee.begin(), mains_cee.end());
	_loop_ce3->insert( _loop_ce3->end(), loops_cef.begin(), loops_cef.end());
}

void IncrementCounter_ce4::operator()( const Packets_t& modelMains_ce5, const Packets_t& mains_ce7, const Packets_t& iterativeBlocks_ce9, const Packets_t& counters_ceb, Packets_t& modelMains_ced, Packets_t& mains_cee, Packets_t& loops_cef, Packets_t& counters_cf0)
{
#ifdef PRINT_INFO
	std::cout << "IncrementCounter_ce4" << std::endl;
#endif
	_modelMain_cf1= &modelMains_ced;
	_main_cf2= &mains_cee;
	_loop_cf3= &loops_cef;
	_counter_cf4= &counters_cf0;
	_modelMain_cf1->insert( _modelMain_cf1->end(), modelMains_ce5.begin(), modelMains_ce5.end());
	_main_cf2->insert( _main_cf2->end(), mains_ce7.begin(), mains_ce7.end());
	_loop_cf3->insert( _loop_cf3->end(), iterativeBlocks_ce9.begin(), iterativeBlocks_ce9.end());
	_counter_cf4->insert( _counter_cf4->end(), counters_ceb.begin(), counters_ceb.end());
	if( ( !iterativeBlocks_ce9.empty()))
		callIncrementCounter_d0b( iterativeBlocks_ce9);
}

void IncrementCounter_ce4::callIncrementCounter_d0b( const Packets_t& iterativeBlocks_cf6)
{
	IncrementCounter_cf5 incrementCounter_cf5;
	incrementCounter_cf5( iterativeBlocks_cf6);
}

void IncrementCounter_cf5::operator()( const Packets_t& iterativeBlocks_cf6)
{
#ifdef PRINT_INFO
	std::cout << "IncrementCounter_cf5" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(564, "IncrementCounter");
	processInputPackets( iterativeBlocks_cf6);
}

bool IncrementCounter_cf5::isInputUnique( const Udm::Object& iterativeBlock_cfc)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itIterativeBlock_cfe= _iterativeBlock_cf8.begin(); itIterativeBlock_cfe!= _iterativeBlock_cf8.end(); ++itIterativeBlock_cfe)
	{
		if( ( *itIterativeBlock_cfe== iterativeBlock_cfc))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_iterativeBlock_cf8.push_back( iterativeBlock_cfc);
	return isUnique;
}

bool IncrementCounter_cf5::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void IncrementCounter_cf5::processInputPackets( const Packets_t& iterativeBlocks_cf6)
{
	for( Packets_t::const_iterator itIterativeBlock_cf9= iterativeBlocks_cf6.begin(); itIterativeBlock_cf9!= iterativeBlocks_cf6.end(); ++itIterativeBlock_cf9)
	{
		bool isUnique= isInputUnique( *itIterativeBlock_cf9);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itIterativeBlock_cf9);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool IncrementCounter_cf5::patternMatcher( const Udm::Object& iterativeBlock_cfa)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( iterativeBlock_cfa.type(), SFC::IterativeBlock::meta))
			continue;
		SFC::IterativeBlock iterativeBlock_cff= SFC::IterativeBlock::Cast( iterativeBlock_cfa);
		SFC::LocalVar counter_d01= iterativeBlock_cff.counter();
		if( !counter_d01)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_d05;
		if( !isValidBound(boundObjs_d05, iterativeBlock_cff, true))
			continue;
		currMatch.iterativeBlock_d06= iterativeBlock_cff;
		if( !isValidBound(boundObjs_d05, counter_d01, false))
			continue;
		currMatch.counter_d07= counter_d01;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void IncrementCounter_cf5::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::UserCode newUserCode_d08= SFC::UserCode::Create( currMatch.iterativeBlock_d06, SFC::IterativeBlock::meta_stmnt);
		SFC::UnaryExprs newIncrement_d09= SFC::UnaryExprs::Create( newUserCode_d08, SFC::UserCode::meta_codeexpr);
		SFC::ArgDeclRef newPlusCounterRef_d0a= SFC::ArgDeclRef::Create( newIncrement_d09, SFC::UnaryExprs::meta_subexpr);
		SFC::LocalVar& Counter= currMatch.counter_d07;
		SFC::UnaryExprs& Increment= newIncrement_d09;
		SFC::IterativeBlock& IterativeBlock= currMatch.iterativeBlock_d06;
		SFC::ArgDeclRef& PlusCounterRef= newPlusCounterRef_d0a;
		SFC::UserCode& UserCode= newUserCode_d08;
		{
Increment.op() = "++";
};
		{
__int64 statementCount = IterativeBlock.statementCount();
UserCode.statementIndex() = statementCount++;
IterativeBlock.statementCount() = statementCount;
};
		newPlusCounterRef_d0a.argdecl()= currMatch.counter_d07;
	}
}

void CreateLoop_d0d::operator()( const Packets_t& classs_d0f, const Packets_t& mains_d11, Packets_t& modelMains_d0e, Packets_t& mains_d13, Packets_t& iterativeBlocks_d14, Packets_t& counters_d15)
{
#ifdef PRINT_INFO
	std::cout << "CreateLoop_d0d" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(577, "CreateLoop");
	_modelMain_d16= &modelMains_d0e;
	_main_d17= &mains_d13;
	_iterativeBlock_d18= &iterativeBlocks_d14;
	_counter_d19= &counters_d15;
	processInputPackets( classs_d0f, mains_d11);
}

bool CreateLoop_d0d::isInputUnique( const Udm::Object& class_d1e, const Udm::Object& main_d27)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_d20= _class_d1a.begin(), itMain_d29= _main_d23.begin(); itClass_d20!= _class_d1a.end(), itMain_d29!= _main_d23.end(); ++itClass_d20, ++itMain_d29)
	{
		if( ( *itClass_d20== class_d1e)&& ( *itMain_d29== main_d27))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_class_d1a.push_back( class_d1e);
		_main_d23.push_back( main_d27);
	}
	return isUnique;
}

bool CreateLoop_d0d::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void CreateLoop_d0d::processInputPackets( const Packets_t& classs_d0f, const Packets_t& mains_d11)
{
	for( Packets_t::const_iterator itClass_d1b= classs_d0f.begin(), itMain_d24= mains_d11.begin(); itClass_d1b!= classs_d0f.end(), itMain_d24!= mains_d11.end(); ++itClass_d1b, ++itMain_d24)
	{
		bool isUnique= isInputUnique( *itClass_d1b, *itMain_d24);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itClass_d1b, *itMain_d24);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateLoop_d0d::patternMatcher( const Udm::Object& class_d1c, const Udm::Object& main_d25)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( class_d1c.type(), SFC::Class::meta))
			continue;
		SFC::Class class_d21= SFC::Class::Cast( class_d1c);
		if( false== Uml::IsDerivedFrom( main_d25.type(), SFC::Function::meta))
			continue;
		SFC::Function main_d2a= SFC::Function::Cast( main_d25);
		set< SFC::Function> modelMains_d2c= class_d21.Function_kind_children();
		for( set< SFC::Function>::const_iterator itModelMain_d2d= modelMains_d2c.begin(); itModelMain_d2d!= modelMains_d2c.end(); ++itModelMain_d2d)
		{
			SFC::Function currModelMain_d2e= *itModelMain_d2d;
			SFC::Function modelMain_d2f= class_d21.main();
			if( !modelMain_d2f)
				continue;
			if( currModelMain_d2e!= modelMain_d2f)
				continue;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_d33;
			if( !isValidBound(boundObjs_d33, class_d21, true))
				continue;
			currMatch.class_d34= class_d21;
			if( !isValidBound(boundObjs_d33, main_d2a, true))
				continue;
			currMatch.main_d35= main_d2a;
			if( !isValidBound(boundObjs_d33, currModelMain_d2e, false))
				continue;
			currMatch.modelMain_d36= currModelMain_d2e;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void CreateLoop_d0d::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::UserCode newAssignment_d37= SFC::UserCode::Create( currMatch.main_d35);
		SFC::BinaryExprs newEquals_d38= SFC::BinaryExprs::Create( newAssignment_d37, SFC::UserCode::meta_codeexpr);
		SFC::Int newZero_d39= SFC::Int::Create( newEquals_d38, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclRef newEqualsCounterRef_d3a= SFC::ArgDeclRef::Create( newEquals_d38, SFC::BinaryExprs::meta_leftexpr);
		SFC::IterativeBlock newIterativeBlock_d3b= SFC::IterativeBlock::Create( currMatch.main_d35);
		SFC::UserCode newCondition_d3c= SFC::UserCode::Create( newIterativeBlock_d3b, SFC::IterativeBlock::meta_cond);
		SFC::BinaryExprs newLessThan_d3d= SFC::BinaryExprs::Create( newCondition_d3c);
		SFC::Int newIntCondition_d3e= SFC::Int::Create( newLessThan_d3d, SFC::BinaryExprs::meta_rightexpr);
		SFC::ArgDeclRef newCounterRef_d3f= SFC::ArgDeclRef::Create( newLessThan_d3d, SFC::BinaryExprs::meta_leftexpr);
		SFC::LocalVar newCounter_d40= SFC::LocalVar::Create( currMatch.main_d35);
		SFC::UserCode& Assignment= newAssignment_d37;
		SFC::Class& Class= currMatch.class_d34;
		SFC::UserCode& Condition= newCondition_d3c;
		SFC::LocalVar& Counter= newCounter_d40;
		SFC::ArgDeclRef& CounterRef= newCounterRef_d3f;
		SFC::BinaryExprs& Equals= newEquals_d38;
		SFC::ArgDeclRef& EqualsCounterRef= newEqualsCounterRef_d3a;
		SFC::Int& IntCondition= newIntCondition_d3e;
		SFC::IterativeBlock& IterativeBlock= newIterativeBlock_d3b;
		SFC::BinaryExprs& LessThan= newLessThan_d3d;
		SFC::Function& Main= currMatch.main_d35;
		SFC::Function& ModelMain= currMatch.modelMain_d36;
		SFC::Int& Zero= newZero_d39;
		{
IntCondition.val() = 11;
};
		{
Counter.name() = "i";
Counter.type() = "int";
};
		{
LessThan.op() = "<";
};
		{
Equals.op() = "=";
};
		{
Zero.val() = 0;
};
		{
__int64 statementCount = Main.statementCount();

Counter.statementIndex() = statementCount++;
Assignment.statementIndex() = statementCount++;
IterativeBlock.statementIndex() = statementCount++;

Main.statementCount() = statementCount;
};
		newCounter_d40.loop()= newIterativeBlock_d3b;
		newEqualsCounterRef_d3a.argdecl()= newCounter_d40;
		newCounterRef_d3f.argdecl()= newCounter_d40;
		outputAppender( currMatch.modelMain_d36, currMatch.main_d35, newIterativeBlock_d3b, newCounter_d40);
	}
}

void CreateLoop_d0d::outputAppender( const SFC::Function& modelMain_d41, const SFC::Function& main_d43, const SFC::IterativeBlock& iterativeBlock_d45, const SFC::LocalVar& counter_d47)
{
	_modelMain_d16->push_back( modelMain_d41);
	_main_d17->push_back( main_d43);
	_iterativeBlock_d18->push_back( iterativeBlock_d45);
	_counter_d19->push_back( counter_d47);
}

void MarkInitAndMain_d51::operator()( const Packets_t& classs_d52, Packets_t& classs_d54)
{
#ifdef PRINT_INFO
	std::cout << "MarkInitAndMain_d51" << std::endl;
#endif
	_class_d55= &classs_d54;
	_class_d55->insert( _class_d55->end(), classs_d52.begin(), classs_d52.end());
	if( ( !classs_d52.empty()))
		callGetClassFunctions_d9b( classs_d52);
}

void MarkInitAndMain_d51::callGetClassFunctions_d9b( const Packets_t& classs_d84)
{
	Packets_t functions_d83;
	GetClassFunctions_d82 getClassFunctions_d82;
	getClassFunctions_d82( classs_d84, functions_d83);
	if( ( !functions_d83.empty()))
		callMarkMain_d9d( functions_d83);
	if( ( !functions_d83.empty()))
		callMarkInit_d9f( functions_d83);
}

void MarkInitAndMain_d51::callMarkMain_d9d( const Packets_t& mains_d57)
{
	MarkMain_d56 markMain_d56;
	markMain_d56( mains_d57);
}

void MarkInitAndMain_d51::callMarkInit_d9f( const Packets_t& inits_d6d)
{
	MarkInit_d6c markInit_d6c;
	markInit_d6c( inits_d6d);
}

void MarkMain_d56::operator()( const Packets_t& mains_d57)
{
#ifdef PRINT_INFO
	std::cout << "MarkMain_d56" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(615, "MarkMain");
	processInputPackets( mains_d57);
}

bool MarkMain_d56::isInputUnique( const Udm::Object& main_d5d)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itMain_d5f= _main_d59.begin(); itMain_d5f!= _main_d59.end(); ++itMain_d5f)
	{
		if( ( *itMain_d5f== main_d5d))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_main_d59.push_back( main_d5d);
	return isUnique;
}

bool MarkMain_d56::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

bool MarkMain_d56::isGuardTrue( SFC::Class& Class, SFC::Function& Main)
{
	bool Gz_guard= false;
	std::string name = Main.name();
Gz_guard = name.substr(name.length() - 4) == "main";;
	return Gz_guard;
}

void MarkMain_d56::processInputPackets( const Packets_t& mains_d57)
{
	for( Packets_t::const_iterator itMain_d5a= mains_d57.begin(); itMain_d5a!= mains_d57.end(); ++itMain_d5a)
	{
		bool isUnique= isInputUnique( *itMain_d5a);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itMain_d5a);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MarkMain_d56::patternMatcher( const Udm::Object& main_d5b)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( main_d5b.type(), SFC::Function::meta))
			continue;
		SFC::Function main_d60= SFC::Function::Cast( main_d5b);
		Udm::Object mainParent_d62= main_d60.container();
		if( false== Uml::IsDerivedFrom( mainParent_d62.type(), SFC::Class::meta))
			continue;
		SFC::Class classMain_d63= SFC::Class::Cast( mainParent_d62);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_d67;
		if( !isValidBound(boundObjs_d67, main_d60, true))
			continue;
		currMatch.main_d68= main_d60;
		if( !isValidBound(boundObjs_d67, classMain_d63, false))
			continue;
		currMatch.class_d69= classMain_d63;
		bool Gz_guard= isGuardTrue( currMatch.class_d69, currMatch.main_d68);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MarkMain_d56::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		currMatch.main_d68.klassmain()= currMatch.class_d69;
	}
}

void MarkInit_d6c::operator()( const Packets_t& inits_d6d)
{
#ifdef PRINT_INFO
	std::cout << "MarkInit_d6c" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(620, "MarkInit");
	processInputPackets( inits_d6d);
}

bool MarkInit_d6c::isInputUnique( const Udm::Object& init_d73)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itInit_d75= _init_d6f.begin(); itInit_d75!= _init_d6f.end(); ++itInit_d75)
	{
		if( ( *itInit_d75== init_d73))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_init_d6f.push_back( init_d73);
	return isUnique;
}

bool MarkInit_d6c::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

bool MarkInit_d6c::isGuardTrue( SFC::Class& Class, SFC::Function& Init)
{
	bool Gz_guard= false;
	std::string name = Init.name();
Gz_guard = name.substr(name.length() - 4) == "init";
;
	return Gz_guard;
}

void MarkInit_d6c::processInputPackets( const Packets_t& inits_d6d)
{
	for( Packets_t::const_iterator itInit_d70= inits_d6d.begin(); itInit_d70!= inits_d6d.end(); ++itInit_d70)
	{
		bool isUnique= isInputUnique( *itInit_d70);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itInit_d70);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MarkInit_d6c::patternMatcher( const Udm::Object& init_d71)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( init_d71.type(), SFC::Function::meta))
			continue;
		SFC::Function init_d76= SFC::Function::Cast( init_d71);
		Udm::Object initParent_d78= init_d76.container();
		if( false== Uml::IsDerivedFrom( initParent_d78.type(), SFC::Class::meta))
			continue;
		SFC::Class classInit_d79= SFC::Class::Cast( initParent_d78);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_d7d;
		if( !isValidBound(boundObjs_d7d, init_d76, true))
			continue;
		currMatch.init_d7e= init_d76;
		if( !isValidBound(boundObjs_d7d, classInit_d79, false))
			continue;
		currMatch.class_d7f= classInit_d79;
		bool Gz_guard= isGuardTrue( currMatch.class_d7f, currMatch.init_d7e);
		if( true== Gz_guard)
			_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MarkInit_d6c::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		currMatch.init_d7e.klassinit()= currMatch.class_d7f;
	}
}

void GetClassFunctions_d82::operator()( const Packets_t& classs_d84, Packets_t& functions_d83)
{
#ifdef PRINT_INFO
	std::cout << "GetClassFunctions_d82" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(625, "GetClassFunctions");
	_function_d86= &functions_d83;
	processInputPackets( classs_d84);
}

bool GetClassFunctions_d82::isInputUnique( const Udm::Object& class_d8b)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_d8d= _class_d87.begin(); itClass_d8d!= _class_d87.end(); ++itClass_d8d)
	{
		if( ( *itClass_d8d== class_d8b))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_class_d87.push_back( class_d8b);
	return isUnique;
}

bool GetClassFunctions_d82::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetClassFunctions_d82::processInputPackets( const Packets_t& classs_d84)
{
	for( Packets_t::const_iterator itClass_d88= classs_d84.begin(); itClass_d88!= classs_d84.end(); ++itClass_d88)
	{
		bool isUnique= isInputUnique( *itClass_d88);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itClass_d88);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetClassFunctions_d82::patternMatcher( const Udm::Object& class_d89)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( class_d89.type(), SFC::Class::meta))
			continue;
		SFC::Class class_d8e= SFC::Class::Cast( class_d89);
		set< SFC::Function> functions_d90= class_d8e.Function_kind_children();
		for( set< SFC::Function>::const_iterator itFunction_d91= functions_d90.begin(); itFunction_d91!= functions_d90.end(); ++itFunction_d91)
		{
			SFC::Function currFunction_d92= *itFunction_d91;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_d96;
			if( !isValidBound(boundObjs_d96, class_d8e, true))
				continue;
			currMatch.class_d97= class_d8e;
			if( !isValidBound(boundObjs_d96, currFunction_d92, false))
				continue;
			currMatch.function_d98= currFunction_d92;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void GetClassFunctions_d82::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.function_d98);
	}
}

void GetClassFunctions_d82::outputAppender( const SFC::Function& function_d99)
{
	_function_d86->push_back( function_d99);
}

void CallModelMain_da1::operator()( const Packets_t& modelMains_da2, const Packets_t& mains_da4, const Packets_t& loops_da6, Packets_t& modelMains_da8, Packets_t& loops_da9)
{
#ifdef PRINT_INFO
	std::cout << "CallModelMain_da1" << std::endl;
#endif
	_modelMain_daa= &modelMains_da8;
	_loop_dab= &loops_da9;
	if( ( !modelMains_da2.empty())&& ( !mains_da4.empty())&& ( !loops_da6.empty()))
		callGetContext_f34( modelMains_da2, mains_da4, loops_da6);
	_modelMain_daa->insert( _modelMain_daa->end(), modelMains_da2.begin(), modelMains_da2.end());
	_loop_dab->insert( _loop_dab->end(), loops_da6.begin(), loops_da6.end());
}

void CallModelMain_da1::callGetContext_f34( const Packets_t& modelMains_dad, const Packets_t& mains_db0, const Packets_t& mains_db3)
{
	Packets_t modelMains_daf;
	Packets_t contexts_db2;
	Packets_t mains_db5;
	GetContext_dac getContext_dac;
	getContext_dac( modelMains_dad, mains_db0, mains_db3, modelMains_daf, contexts_db2, mains_db5);
	if( ( !modelMains_daf.empty())&& ( !contexts_db2.empty())&& ( !mains_db5.empty()))
		callCreateCallWithContext_f38( modelMains_daf, contexts_db2, mains_db5);
}

void CallModelMain_da1::callCreateCallWithContext_f38( const Packets_t& modelMains_dec, const Packets_t& contexts_def, const Packets_t& mains_df2)
{
	Packets_t modelMains_dee;
	Packets_t modelMainCalls_df1;
	Packets_t mains_df4;
	CreateCallWithContext_deb createCallWithContext_deb;
	createCallWithContext_deb( modelMains_dec, contexts_def, mains_df2, modelMains_dee, modelMainCalls_df1, mains_df4);
	if( ( !modelMains_dee.empty())&& ( !modelMainCalls_df1.empty())&& ( !mains_df4.empty()))
		callCreateLocalsForCall_f3c( modelMains_dee, modelMainCalls_df1, mains_df4);
}

void CallModelMain_da1::callCreateLocalsForCall_f3c( const Packets_t& inits_e2d, const Packets_t& initCalls_e2f, const Packets_t& compoundStmnts_e31)
{
	Packets_t vars_e33;
	Packets_t calls_e34;
	CreateLocalsForCall_e2c createLocalsForCall_e2c;
	createLocalsForCall_e2c( inits_e2d, initCalls_e2f, compoundStmnts_e31, vars_e33, calls_e34);
}

void GetContext_dac::operator()( const Packets_t& modelMains_dad, const Packets_t& mains_db0, const Packets_t& mains_db3, Packets_t& modelMains_daf, Packets_t& contexts_db2, Packets_t& mains_db5)
{
#ifdef PRINT_INFO
	std::cout << "GetContext_dac" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(635, "GetContext");
	_modelMain_db6= &modelMains_daf;
	_context_db7= &contexts_db2;
	_main_db8= &mains_db5;
	processInputPackets( modelMains_dad, mains_db0, mains_db3);
}

bool GetContext_dac::isInputUnique( const Udm::Object& modelMain_dbd, const Udm::Object& main_dc6, const Udm::Object& main_dcf)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itModelMain_dbf= _modelMain_db9.begin(), itMain_dc8= _main_dc2.begin(), itMain_dd1= _main_dcb.begin(); itModelMain_dbf!= _modelMain_db9.end(), itMain_dc8!= _main_dc2.end(), itMain_dd1!= _main_dcb.end(); ++itModelMain_dbf, ++itMain_dc8, ++itMain_dd1)
	{
		if( ( *itModelMain_dbf== modelMain_dbd)&& ( *itMain_dc8== main_dc6)&& ( *itMain_dd1== main_dcf))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_modelMain_db9.push_back( modelMain_dbd);
		_main_dc2.push_back( main_dc6);
		_main_dcb.push_back( main_dcf);
	}
	return isUnique;
}

bool GetContext_dac::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetContext_dac::processInputPackets( const Packets_t& modelMains_dad, const Packets_t& mains_db0, const Packets_t& mains_db3)
{
	for( Packets_t::const_iterator itModelMain_dba= modelMains_dad.begin(), itMain_dc3= mains_db0.begin(), itMain_dcc= mains_db3.begin(); itModelMain_dba!= modelMains_dad.end(), itMain_dc3!= mains_db0.end(), itMain_dcc!= mains_db3.end(); ++itModelMain_dba, ++itMain_dc3, ++itMain_dcc)
	{
		bool isUnique= isInputUnique( *itModelMain_dba, *itMain_dc3, *itMain_dcc);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itModelMain_dba, *itMain_dc3, *itMain_dcc);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetContext_dac::patternMatcher( const Udm::Object& modelMain_dbb, const Udm::Object& main_dc4, const Udm::Object& main_dcd)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( modelMain_dbb.type(), SFC::Function::meta))
			continue;
		SFC::Function modelMain_dc0= SFC::Function::Cast( modelMain_dbb);
		if( false== Uml::IsDerivedFrom( main_dc4.type(), SFC::Function::meta))
			continue;
		SFC::Function main_dc9= SFC::Function::Cast( main_dc4);
		if( false== Uml::IsDerivedFrom( main_dcd.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_dd2= SFC::CompoundStatement::Cast( main_dcd);
		Udm::Object modelMainParent_dd4= modelMain_dc0.container();
		if( false== Uml::IsDerivedFrom( modelMainParent_dd4.type(), SFC::Class::meta))
			continue;
		SFC::Class classModelMain_dd5= SFC::Class::Cast( modelMainParent_dd4);
		set< SFC::LocalVar> contexts_dd6= main_dc9.LocalVar_kind_children();
		for( set< SFC::LocalVar>::const_iterator itContext_dd7= contexts_dd6.begin(); itContext_dd7!= contexts_dd6.end(); ++itContext_dd7)
		{
			SFC::LocalVar currContext_dd8= *itContext_dd7;
			set< SFC::Class> classs_dd9= currContext_dd8.klass();
			for( set< SFC::Class>::const_iterator itClasss_dda= classs_dd9.begin(); itClasss_dda!= classs_dd9.end(); ++itClasss_dda)
			{
				SFC::Class currClass_ddb= *itClasss_dda;
				if( classModelMain_dd5!= currClass_ddb)
					continue;
				Match currMatch;
				set< pair<int, Udm::Object> > boundObjs_ddf;
				if( !isValidBound(boundObjs_ddf, modelMain_dc0, true))
					continue;
				currMatch.modelMain_de0= modelMain_dc0;
				if( !isValidBound(boundObjs_ddf, main_dc9, true))
					continue;
				currMatch.main_de1= main_dc9;
				if( !isValidBound(boundObjs_ddf, main_dd2, true))
					continue;
				currMatch.main_de2= main_dd2;
				if( !isValidBound(boundObjs_ddf, classModelMain_dd5, false))
					continue;
				currMatch.class_de3= classModelMain_dd5;
				if( !isValidBound(boundObjs_ddf, currContext_dd8, false))
					continue;
				currMatch.context_de4= currContext_dd8;
				_matches.push_back( currMatch);
			}
		}
	}
	return !_matches.empty();
}

void GetContext_dac::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.modelMain_de0, currMatch.context_de4, currMatch.main_de2);
	}
}

void GetContext_dac::outputAppender( const SFC::Function& modelMain_de5, const SFC::LocalVar& context_de7, const SFC::CompoundStatement& main_de9)
{
	_modelMain_db6->push_back( modelMain_de5);
	_context_db7->push_back( context_de7);
	_main_db8->push_back( main_de9);
}

void CreateCallWithContext_deb::operator()( const Packets_t& modelMains_dec, const Packets_t& contexts_def, const Packets_t& mains_df2, Packets_t& modelMains_dee, Packets_t& modelMainCalls_df1, Packets_t& mains_df4)
{
#ifdef PRINT_INFO
	std::cout << "CreateCallWithContext_deb" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(644, "CreateCallWithContext");
	_modelMain_df5= &modelMains_dee;
	_modelMainCall_df6= &modelMainCalls_df1;
	_main_df7= &mains_df4;
	processInputPackets( modelMains_dec, contexts_def, mains_df2);
}

bool CreateCallWithContext_deb::isInputUnique( const Udm::Object& modelMain_dfc, const Udm::Object& context_e05, const Udm::Object& main_e0e)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itModelMain_dfe= _modelMain_df8.begin(), itContext_e07= _context_e01.begin(), itMain_e10= _main_e0a.begin(); itModelMain_dfe!= _modelMain_df8.end(), itContext_e07!= _context_e01.end(), itMain_e10!= _main_e0a.end(); ++itModelMain_dfe, ++itContext_e07, ++itMain_e10)
	{
		if( ( *itModelMain_dfe== modelMain_dfc)&& ( *itContext_e07== context_e05)&& ( *itMain_e10== main_e0e))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_modelMain_df8.push_back( modelMain_dfc);
		_context_e01.push_back( context_e05);
		_main_e0a.push_back( main_e0e);
	}
	return isUnique;
}

bool CreateCallWithContext_deb::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void CreateCallWithContext_deb::processInputPackets( const Packets_t& modelMains_dec, const Packets_t& contexts_def, const Packets_t& mains_df2)
{
	for( Packets_t::const_iterator itModelMain_df9= modelMains_dec.begin(), itContext_e02= contexts_def.begin(), itMain_e0b= mains_df2.begin(); itModelMain_df9!= modelMains_dec.end(), itContext_e02!= contexts_def.end(), itMain_e0b!= mains_df2.end(); ++itModelMain_df9, ++itContext_e02, ++itMain_e0b)
	{
		bool isUnique= isInputUnique( *itModelMain_df9, *itContext_e02, *itMain_e0b);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itModelMain_df9, *itContext_e02, *itMain_e0b);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateCallWithContext_deb::patternMatcher( const Udm::Object& modelMain_dfa, const Udm::Object& context_e03, const Udm::Object& main_e0c)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( modelMain_dfa.type(), SFC::Function::meta))
			continue;
		SFC::Function modelMain_dff= SFC::Function::Cast( modelMain_dfa);
		if( false== Uml::IsDerivedFrom( context_e03.type(), SFC::LocalVar::meta))
			continue;
		SFC::LocalVar context_e08= SFC::LocalVar::Cast( context_e03);
		if( false== Uml::IsDerivedFrom( main_e0c.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_e11= SFC::CompoundStatement::Cast( main_e0c);
		set< SFC::Arg> args_e13= modelMain_dff.Arg_kind_children();
		for( set< SFC::Arg>::const_iterator itArg_e14= args_e13.begin(); itArg_e14!= args_e13.end(); ++itArg_e14)
		{
			SFC::Arg currArg_e15= *itArg_e14;
			SFC::DT dataType_e16= currArg_e15.dt();
			if( !dataType_e16)
				continue;
			set< SFC::TypedEntity> contexts_e17= dataType_e16.te();
			for( set< SFC::TypedEntity>::const_iterator itContexts_e18= contexts_e17.begin(); itContexts_e18!= contexts_e17.end(); ++itContexts_e18)
			{
				if( false== Uml::IsDerivedFrom( (*itContexts_e18).type(), SFC::LocalVar::meta))
					continue;
				SFC::LocalVar currContext_e19= SFC::LocalVar::Cast( *itContexts_e18);
				if( context_e08!= currContext_e19)
					continue;
				Match currMatch;
				set< pair<int, Udm::Object> > boundObjs_e1d;
				if( !isValidBound(boundObjs_e1d, modelMain_dff, true))
					continue;
				currMatch.modelMain_e1e= modelMain_dff;
				if( !isValidBound(boundObjs_e1d, context_e08, true))
					continue;
				currMatch.context_e1f= context_e08;
				if( !isValidBound(boundObjs_e1d, main_e11, true))
					continue;
				currMatch.main_e20= main_e11;
				if( !isValidBound(boundObjs_e1d, currArg_e15, false))
					continue;
				currMatch.arg_e21= currArg_e15;
				if( !isValidBound(boundObjs_e1d, dataType_e16, false))
					continue;
				currMatch.dataType_e22= dataType_e16;
				_matches.push_back( currMatch);
			}
		}
	}
	return !_matches.empty();
}

void CreateCallWithContext_deb::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::FunctionCall newModelMainCall_e23= SFC::FunctionCall::Create( currMatch.main_e20, SFC::CompoundStatement::meta_stmnt);
		SFC::ArgVal newArgumentVal_e24= SFC::ArgVal::Create( newModelMainCall_e23);
		SFC::ArgDeclRef newVarRef_e25= SFC::ArgDeclRef::Create( newArgumentVal_e24);
		SFC::Arg& Arg= currMatch.arg_e21;
		SFC::ArgVal& ArgumentVal= newArgumentVal_e24;
		SFC::LocalVar& Context= currMatch.context_e1f;
		SFC::DT& DataType= currMatch.dataType_e22;
		SFC::CompoundStatement& Main= currMatch.main_e20;
		SFC::Function& ModelMain= currMatch.modelMain_e1e;
		SFC::FunctionCall& ModelMainCall= newModelMainCall_e23;
		SFC::ArgDeclRef& VarRef= newVarRef_e25;
		{
__int64 statementCount = Main.statementCount();
ModelMainCall.statementIndex() = statementCount++;
Main.statementCount() = statementCount;

std::cout << "Create main call\n";
};
		currMatch.modelMain_e1e.caller()+= newModelMainCall_e23;
		currMatch.context_e1f.argument()+= currMatch.arg_e21;
		currMatch.arg_e21.val()+= newArgumentVal_e24;
		newVarRef_e25.argdecl()= currMatch.context_e1f;
		outputAppender( currMatch.modelMain_e1e, newModelMainCall_e23, currMatch.main_e20);
	}
}

void CreateCallWithContext_deb::outputAppender( const SFC::Function& modelMain_e26, const SFC::FunctionCall& modelMainCall_e28, const SFC::CompoundStatement& main_e2a)
{
	_modelMain_df5->push_back( modelMain_e26);
	_modelMainCall_df6->push_back( modelMainCall_e28);
	_main_df7->push_back( main_e2a);
}

void CreateLocalsForCall_e2c::operator()( const Packets_t& inits_e2d, const Packets_t& initCalls_e2f, const Packets_t& compoundStmnts_e31, Packets_t& vars_e33, Packets_t& calls_e34)
{
#ifdef PRINT_INFO
	std::cout << "CreateLocalsForCall_e2c" << std::endl;
#endif
	_var_e35= &vars_e33;
	_call_e36= &calls_e34;
	if( ( !inits_e2d.empty())&& ( !initCalls_e2f.empty())&& ( !compoundStmnts_e31.empty()))
		callGetArgs_f28( inits_e2d, initCalls_e2f, compoundStmnts_e31);
}

void CreateLocalsForCall_e2c::callGetArgs_f28( const Packets_t& inits_ef1, const Packets_t& initCalls_ef3, const Packets_t& mains_ef6)
{
	Packets_t args_ef0;
	Packets_t initCalls_ef5;
	Packets_t mains_ef8;
	GetArgs_eef getArgs_eef;
	getArgs_eef( inits_ef1, initCalls_ef3, mains_ef6, args_ef0, initCalls_ef5, mains_ef8);
	if( ( !args_ef0.empty())&& ( !initCalls_ef5.empty())&& ( !mains_ef8.empty()))
		callNeedsVar_f2c( args_ef0, initCalls_ef5, mains_ef8);
}

void CreateLocalsForCall_e2c::callNeedsVar_f2c( const Packets_t& arguments_e38, const Packets_t& initCalls_e3a, const Packets_t& compoundStmnts_e3c)
{
	Packets_t arguments_e3e;
	Packets_t initCalls_e3f;
	Packets_t compoundStmnts_e40;
	NeedsVar_e37 needsVar_e37;
	needsVar_e37( arguments_e38, initCalls_e3a, compoundStmnts_e3c, arguments_e3e, initCalls_e3f, compoundStmnts_e40);
	if( ( !arguments_e3e.empty())&& ( !initCalls_e3f.empty())&& ( !compoundStmnts_e40.empty()))
		callCreateLocalVars_f30( arguments_e3e, initCalls_e3f, compoundStmnts_e40);
}

void CreateLocalsForCall_e2c::callCreateLocalVars_f30( const Packets_t& args_eba, const Packets_t& initCalls_ebd, const Packets_t& mains_ec0)
{
	Packets_t contexts_ebc;
	Packets_t initCalls_ebf;
	CreateLocalVars_eb9 createLocalVars_eb9;
	createLocalVars_eb9( args_eba, initCalls_ebd, mains_ec0, contexts_ebc, initCalls_ebf);
	_var_e35->insert( _var_e35->end(), contexts_ebc.begin(), contexts_ebc.end());
	_call_e36->insert( _call_e36->end(), initCalls_ebf.begin(), initCalls_ebf.end());
}

void NeedsVar_e37::operator()( const Packets_t& arguments_e38, const Packets_t& initCalls_e3a, const Packets_t& compoundStmnts_e3c, Packets_t& arguments_e3e, Packets_t& initCalls_e3f, Packets_t& compoundStmnts_e40)
{
#ifdef PRINT_INFO
	std::cout << "NeedsVar_e37" << std::endl;
#endif
	_argument_e41= &arguments_e3e;
	_initCall_e42= &initCalls_e3f;
	_compoundStmnt_e43= &compoundStmnts_e40;
	for( Packets_t::const_iterator itArgument_e45= arguments_e38.begin(), itInitCall_e4c= initCalls_e3a.begin(), itCompoundStmnt_e53= compoundStmnts_e3c.begin(); itArgument_e45!= arguments_e38.end(), itInitCall_e4c!= initCalls_e3a.end(), itCompoundStmnt_e53!= compoundStmnts_e3c.end(); ++itArgument_e45, ++itInitCall_e4c, ++itCompoundStmnt_e53)
	{
		bool isUnique= isInputUnique( *itArgument_e45, *itInitCall_e4c, *itCompoundStmnt_e53);
		if( !isUnique)
			continue;
		Packets_t oneArgument_e49( 1, *itArgument_e45);
		Packets_t oneInitCall_e50( 1, *itInitCall_e4c);
		Packets_t oneCompoundStmnt_e57( 1, *itCompoundStmnt_e53);
		executeOne( oneArgument_e49, oneInitCall_e50, oneCompoundStmnt_e57);
	}
}

void NeedsVar_e37::executeOne( const Packets_t& arguments_e38, const Packets_t& initCalls_e3a, const Packets_t& compoundStmnts_e3c)
{
	HasLocalVar_e59 hasLocalVar_e59;
	bool isMatchHasLocalVar_e59= hasLocalVar_e59( arguments_e38, initCalls_e3a, compoundStmnts_e3c);
	if( isMatchHasLocalVar_e59)
		return;
	Packets_t args_e87;
	Packets_t calls_e8a;
	Packets_t mains_e8d;
	VarNeeded_e84 varNeeded_e84;
	bool isMatchVarNeeded_e84= varNeeded_e84( arguments_e38, initCalls_e3a, compoundStmnts_e3c, args_e87, calls_e8a, mains_e8d);
	_argument_e41->insert( _argument_e41->end(), args_e87.begin(), args_e87.end());
	_initCall_e42->insert( _initCall_e42->end(), calls_e8a.begin(), calls_e8a.end());
	_compoundStmnt_e43->insert( _compoundStmnt_e43->end(), mains_e8d.begin(), mains_e8d.end());
	if( isMatchVarNeeded_e84)
		return;
}

bool NeedsVar_e37::isInputUnique( const Udm::Object& argument_e46, const Udm::Object& initCall_e4d, const Udm::Object& compoundStmnt_e54)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArgument_e48= _argument_e44.begin(), itInitCall_e4f= _initCall_e4b.begin(), itCompoundStmnt_e56= _compoundStmnt_e52.begin(); itArgument_e48!= _argument_e44.end(), itInitCall_e4f!= _initCall_e4b.end(), itCompoundStmnt_e56!= _compoundStmnt_e52.end(); ++itArgument_e48, ++itInitCall_e4f, ++itCompoundStmnt_e56)
	{
		if( ( *itArgument_e48== argument_e46)&& ( *itInitCall_e4f== initCall_e4d)&& ( *itCompoundStmnt_e56== compoundStmnt_e54))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_argument_e44.push_back( argument_e46);
		_initCall_e4b.push_back( initCall_e4d);
		_compoundStmnt_e52.push_back( compoundStmnt_e54);
	}
	return isUnique;
}

bool HasLocalVar_e59::operator()( const Packets_t& args_e5a, const Packets_t& calls_e5c, const Packets_t& compoundStmnts_e5e)
{
#ifdef PRINT_INFO
	std::cout << "HasLocalVar_e59" << std::endl;
#endif
	processInputPackets( args_e5a, calls_e5c, compoundStmnts_e5e);
	if( false== _matches.empty())
		return true;
	return false;
}

bool HasLocalVar_e59::isInputUnique( const Udm::Object& arg_e64, const Udm::Object& call_e6d, const Udm::Object& compoundStmnt_e76)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArg_e66= _arg_e60.begin(), itCall_e6f= _call_e69.begin(), itCompoundStmnt_e78= _compoundStmnt_e72.begin(); itArg_e66!= _arg_e60.end(), itCall_e6f!= _call_e69.end(), itCompoundStmnt_e78!= _compoundStmnt_e72.end(); ++itArg_e66, ++itCall_e6f, ++itCompoundStmnt_e78)
	{
		if( ( *itArg_e66== arg_e64)&& ( *itCall_e6f== call_e6d)&& ( *itCompoundStmnt_e78== compoundStmnt_e76))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_arg_e60.push_back( arg_e64);
		_call_e69.push_back( call_e6d);
		_compoundStmnt_e72.push_back( compoundStmnt_e76);
	}
	return isUnique;
}

bool HasLocalVar_e59::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void HasLocalVar_e59::processInputPackets( const Packets_t& args_e5a, const Packets_t& calls_e5c, const Packets_t& compoundStmnts_e5e)
{
	for( Packets_t::const_iterator itArg_e61= args_e5a.begin(), itCall_e6a= calls_e5c.begin(), itCompoundStmnt_e73= compoundStmnts_e5e.begin(); itArg_e61!= args_e5a.end(), itCall_e6a!= calls_e5c.end(), itCompoundStmnt_e73!= compoundStmnts_e5e.end(); ++itArg_e61, ++itCall_e6a, ++itCompoundStmnt_e73)
	{
		bool isUnique= isInputUnique( *itArg_e61, *itCall_e6a, *itCompoundStmnt_e73);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArg_e61, *itCall_e6a, *itCompoundStmnt_e73);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( );
	}
}

bool HasLocalVar_e59::patternMatcher( const Udm::Object& arg_e62, const Udm::Object& call_e6b, const Udm::Object& compoundStmnt_e74)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( arg_e62.type(), SFC::Arg::meta))
			continue;
		SFC::Arg arg_e67= SFC::Arg::Cast( arg_e62);
		if( false== Uml::IsDerivedFrom( call_e6b.type(), SFC::FunctionCall::meta))
			continue;
		SFC::FunctionCall call_e70= SFC::FunctionCall::Cast( call_e6b);
		if( false== Uml::IsDerivedFrom( compoundStmnt_e74.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement compoundStmnt_e79= SFC::CompoundStatement::Cast( compoundStmnt_e74);
		SFC::LocalVar var_e7b= arg_e67.actual();
		if( !var_e7b)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_e7f;
		if( !isValidBound(boundObjs_e7f, arg_e67, true))
			continue;
		currMatch.arg_e80= arg_e67;
		if( !isValidBound(boundObjs_e7f, call_e70, true))
			continue;
		currMatch.call_e81= call_e70;
		if( !isValidBound(boundObjs_e7f, compoundStmnt_e79, true))
			continue;
		currMatch.compoundStmnt_e82= compoundStmnt_e79;
		if( !isValidBound(boundObjs_e7f, var_e7b, false))
			continue;
		currMatch.var_e83= var_e7b;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void HasLocalVar_e59::outputAppender()
{
}

bool VarNeeded_e84::operator()( const Packets_t& args_e85, const Packets_t& calls_e88, const Packets_t& mains_e8b, Packets_t& args_e87, Packets_t& calls_e8a, Packets_t& mains_e8d)
{
#ifdef PRINT_INFO
	std::cout << "VarNeeded_e84" << std::endl;
#endif
	_arg_e8e= &args_e87;
	_call_e8f= &calls_e8a;
	_main_e90= &mains_e8d;
	processInputPackets( args_e85, calls_e88, mains_e8b);
	if( false== _matches.empty())
		return true;
	return false;
}

bool VarNeeded_e84::isInputUnique( const Udm::Object& arg_e95, const Udm::Object& call_e9e, const Udm::Object& main_ea7)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArg_e97= _arg_e91.begin(), itCall_ea0= _call_e9a.begin(), itMain_ea9= _main_ea3.begin(); itArg_e97!= _arg_e91.end(), itCall_ea0!= _call_e9a.end(), itMain_ea9!= _main_ea3.end(); ++itArg_e97, ++itCall_ea0, ++itMain_ea9)
	{
		if( ( *itArg_e97== arg_e95)&& ( *itCall_ea0== call_e9e)&& ( *itMain_ea9== main_ea7))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_arg_e91.push_back( arg_e95);
		_call_e9a.push_back( call_e9e);
		_main_ea3.push_back( main_ea7);
	}
	return isUnique;
}

bool VarNeeded_e84::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void VarNeeded_e84::processInputPackets( const Packets_t& args_e85, const Packets_t& calls_e88, const Packets_t& mains_e8b)
{
	for( Packets_t::const_iterator itArg_e92= args_e85.begin(), itCall_e9b= calls_e88.begin(), itMain_ea4= mains_e8b.begin(); itArg_e92!= args_e85.end(), itCall_e9b!= calls_e88.end(), itMain_ea4!= mains_e8b.end(); ++itArg_e92, ++itCall_e9b, ++itMain_ea4)
	{
		bool isUnique= isInputUnique( *itArg_e92, *itCall_e9b, *itMain_ea4);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArg_e92, *itCall_e9b, *itMain_ea4);
	}
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.arg_eb0, currMatch.call_eb1, currMatch.main_eb2);
	}
}

bool VarNeeded_e84::patternMatcher( const Udm::Object& arg_e93, const Udm::Object& call_e9c, const Udm::Object& main_ea5)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( arg_e93.type(), SFC::Arg::meta))
			continue;
		SFC::Arg arg_e98= SFC::Arg::Cast( arg_e93);
		if( false== Uml::IsDerivedFrom( call_e9c.type(), SFC::FunctionCall::meta))
			continue;
		SFC::FunctionCall call_ea1= SFC::FunctionCall::Cast( call_e9c);
		if( false== Uml::IsDerivedFrom( main_ea5.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_eaa= SFC::CompoundStatement::Cast( main_ea5);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_eaf;
		if( !isValidBound(boundObjs_eaf, arg_e98, true))
			continue;
		currMatch.arg_eb0= arg_e98;
		if( !isValidBound(boundObjs_eaf, call_ea1, true))
			continue;
		currMatch.call_eb1= call_ea1;
		if( !isValidBound(boundObjs_eaf, main_eaa, true))
			continue;
		currMatch.main_eb2= main_eaa;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void VarNeeded_e84::outputAppender( const SFC::Arg& arg_eb3, const SFC::FunctionCall& call_eb5, const SFC::CompoundStatement& main_eb7)
{
	_arg_e8e->push_back( arg_eb3);
	_call_e8f->push_back( call_eb5);
	_main_e90->push_back( main_eb7);
}

void CreateLocalVars_eb9::operator()( const Packets_t& args_eba, const Packets_t& initCalls_ebd, const Packets_t& mains_ec0, Packets_t& contexts_ebc, Packets_t& initCalls_ebf)
{
#ifdef PRINT_INFO
	std::cout << "CreateLocalVars_eb9" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(710, "CreateLocalVars");
	_context_ec2= &contexts_ebc;
	_initCall_ec3= &initCalls_ebf;
	processInputPackets( args_eba, initCalls_ebd, mains_ec0);
}

bool CreateLocalVars_eb9::isInputUnique( const Udm::Object& arg_ec8, const Udm::Object& initCall_ed1, const Udm::Object& main_eda)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itArg_eca= _arg_ec4.begin(), itInitCall_ed3= _initCall_ecd.begin(), itMain_edc= _main_ed6.begin(); itArg_eca!= _arg_ec4.end(), itInitCall_ed3!= _initCall_ecd.end(), itMain_edc!= _main_ed6.end(); ++itArg_eca, ++itInitCall_ed3, ++itMain_edc)
	{
		if( ( *itArg_eca== arg_ec8)&& ( *itInitCall_ed3== initCall_ed1)&& ( *itMain_edc== main_eda))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_arg_ec4.push_back( arg_ec8);
		_initCall_ecd.push_back( initCall_ed1);
		_main_ed6.push_back( main_eda);
	}
	return isUnique;
}

bool CreateLocalVars_eb9::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void CreateLocalVars_eb9::processInputPackets( const Packets_t& args_eba, const Packets_t& initCalls_ebd, const Packets_t& mains_ec0)
{
	for( Packets_t::const_iterator itArg_ec5= args_eba.begin(), itInitCall_ece= initCalls_ebd.begin(), itMain_ed7= mains_ec0.begin(); itArg_ec5!= args_eba.end(), itInitCall_ece!= initCalls_ebd.end(), itMain_ed7!= mains_ec0.end(); ++itArg_ec5, ++itInitCall_ece, ++itMain_ed7)
	{
		bool isUnique= isInputUnique( *itArg_ec5, *itInitCall_ece, *itMain_ed7);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itArg_ec5, *itInitCall_ece, *itMain_ed7);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateLocalVars_eb9::patternMatcher( const Udm::Object& arg_ec6, const Udm::Object& initCall_ecf, const Udm::Object& main_ed8)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( arg_ec6.type(), SFC::Arg::meta))
			continue;
		SFC::Arg arg_ecb= SFC::Arg::Cast( arg_ec6);
		if( false== Uml::IsDerivedFrom( initCall_ecf.type(), SFC::FunctionCall::meta))
			continue;
		SFC::FunctionCall initCall_ed4= SFC::FunctionCall::Cast( initCall_ecf);
		if( false== Uml::IsDerivedFrom( main_ed8.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_edd= SFC::CompoundStatement::Cast( main_ed8);
		SFC::DT dataType_edf= arg_ecb.dt();
		if( !dataType_edf)
			continue;
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_ee3;
		if( !isValidBound(boundObjs_ee3, arg_ecb, true))
			continue;
		currMatch.arg_ee4= arg_ecb;
		if( !isValidBound(boundObjs_ee3, initCall_ed4, true))
			continue;
		currMatch.initCall_ee5= initCall_ed4;
		if( !isValidBound(boundObjs_ee3, main_edd, true))
			continue;
		currMatch.main_ee6= main_edd;
		if( !isValidBound(boundObjs_ee3, dataType_edf, false))
			continue;
		currMatch.dataType_ee7= dataType_edf;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void CreateLocalVars_eb9::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::ArgVal newArgumentVal_ee8= SFC::ArgVal::Create( currMatch.initCall_ee5);
		SFC::ArgDeclRef newVarRef_ee9= SFC::ArgDeclRef::Create( newArgumentVal_ee8);
		SFC::LocalVar newContext_eea= SFC::LocalVar::Create( currMatch.main_ee6);
		SFC::Arg& Arg= currMatch.arg_ee4;
		SFC::ArgVal& ArgumentVal= newArgumentVal_ee8;
		SFC::LocalVar& Context= newContext_eea;
		SFC::DT& DataType= currMatch.dataType_ee7;
		SFC::FunctionCall& InitCall= currMatch.initCall_ee5;
		SFC::CompoundStatement& Main= currMatch.main_ee6;
		SFC::ArgDeclRef& VarRef= newVarRef_ee9;
		{
__int64 statementCount = Main.statementCount();
Context.statementIndex() = statementCount++;
Main.statementCount() = statementCount;

Context.name() = Arg.name();
};
		{
ArgumentVal.argIndex() = Arg.argIndex();
};
		newContext_eea.argument()+= currMatch.arg_ee4;
		currMatch.arg_ee4.val()+= newArgumentVal_ee8;
		currMatch.dataType_ee7.te()+= newContext_eea;
		newVarRef_ee9.argdecl()= newContext_eea;
		outputAppender( newContext_eea, currMatch.initCall_ee5);
	}
}

void CreateLocalVars_eb9::outputAppender( const SFC::LocalVar& context_eeb, const SFC::FunctionCall& initCall_eed)
{
	_context_ec2->push_back( context_eeb);
	_initCall_ec3->push_back( initCall_eed);
}

void GetArgs_eef::operator()( const Packets_t& inits_ef1, const Packets_t& initCalls_ef3, const Packets_t& mains_ef6, Packets_t& args_ef0, Packets_t& initCalls_ef5, Packets_t& mains_ef8)
{
#ifdef PRINT_INFO
	std::cout << "GetArgs_eef" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(728, "GetArgs");
	_arg_ef9= &args_ef0;
	_initCall_efa= &initCalls_ef5;
	_main_efb= &mains_ef8;
	processInputPackets( inits_ef1, initCalls_ef3, mains_ef6);
}

bool GetArgs_eef::isInputUnique( const Udm::Object& init_f00, const Udm::Object& initCall_f09, const Udm::Object& main_f12)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itInit_f02= _init_efc.begin(), itInitCall_f0b= _initCall_f05.begin(), itMain_f14= _main_f0e.begin(); itInit_f02!= _init_efc.end(), itInitCall_f0b!= _initCall_f05.end(), itMain_f14!= _main_f0e.end(); ++itInit_f02, ++itInitCall_f0b, ++itMain_f14)
	{
		if( ( *itInit_f02== init_f00)&& ( *itInitCall_f0b== initCall_f09)&& ( *itMain_f14== main_f12))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_init_efc.push_back( init_f00);
		_initCall_f05.push_back( initCall_f09);
		_main_f0e.push_back( main_f12);
	}
	return isUnique;
}

bool GetArgs_eef::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetArgs_eef::processInputPackets( const Packets_t& inits_ef1, const Packets_t& initCalls_ef3, const Packets_t& mains_ef6)
{
	for( Packets_t::const_iterator itInit_efd= inits_ef1.begin(), itInitCall_f06= initCalls_ef3.begin(), itMain_f0f= mains_ef6.begin(); itInit_efd!= inits_ef1.end(), itInitCall_f06!= initCalls_ef3.end(), itMain_f0f!= mains_ef6.end(); ++itInit_efd, ++itInitCall_f06, ++itMain_f0f)
	{
		bool isUnique= isInputUnique( *itInit_efd, *itInitCall_f06, *itMain_f0f);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itInit_efd, *itInitCall_f06, *itMain_f0f);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetArgs_eef::patternMatcher( const Udm::Object& init_efe, const Udm::Object& initCall_f07, const Udm::Object& main_f10)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( init_efe.type(), SFC::Function::meta))
			continue;
		SFC::Function init_f03= SFC::Function::Cast( init_efe);
		if( false== Uml::IsDerivedFrom( initCall_f07.type(), SFC::FunctionCall::meta))
			continue;
		SFC::FunctionCall initCall_f0c= SFC::FunctionCall::Cast( initCall_f07);
		if( false== Uml::IsDerivedFrom( main_f10.type(), SFC::CompoundStatement::meta))
			continue;
		SFC::CompoundStatement main_f15= SFC::CompoundStatement::Cast( main_f10);
		set< SFC::Arg> args_f17= init_f03.Arg_kind_children();
		for( set< SFC::Arg>::const_iterator itArg_f18= args_f17.begin(); itArg_f18!= args_f17.end(); ++itArg_f18)
		{
			SFC::Arg currArg_f19= *itArg_f18;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_f1d;
			if( !isValidBound(boundObjs_f1d, init_f03, true))
				continue;
			currMatch.init_f1e= init_f03;
			if( !isValidBound(boundObjs_f1d, initCall_f0c, true))
				continue;
			currMatch.initCall_f1f= initCall_f0c;
			if( !isValidBound(boundObjs_f1d, main_f15, true))
				continue;
			currMatch.main_f20= main_f15;
			if( !isValidBound(boundObjs_f1d, currArg_f19, false))
				continue;
			currMatch.arg_f21= currArg_f19;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void GetArgs_eef::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		outputAppender( currMatch.arg_f21, currMatch.initCall_f1f, currMatch.main_f20);
	}
}

void GetArgs_eef::outputAppender( const SFC::Arg& arg_f22, const SFC::FunctionCall& initCall_f24, const SFC::CompoundStatement& main_f26)
{
	_arg_ef9->push_back( arg_f22);
	_initCall_efa->push_back( initCall_f24);
	_main_efb->push_back( main_f26);
}

void CallInit_f40::operator()( const Packets_t& classs_f41, const Packets_t& mains_f43, Packets_t& classs_f45, Packets_t& mains_f46)
{
#ifdef PRINT_INFO
	std::cout << "CallInit_f40" << std::endl;
#endif
	_class_f47= &classs_f45;
	_main_f48= &mains_f46;
	_class_f47->insert( _class_f47->end(), classs_f41.begin(), classs_f41.end());
	_main_f48->insert( _main_f48->end(), mains_f43.begin(), mains_f43.end());
	if( ( !classs_f41.empty())&& ( !mains_f43.empty()))
		callCallInits_f9a( classs_f41, mains_f43);
}

void CallInit_f40::callCallInits_f9a( const Packets_t& classs_f6d, const Packets_t& mains_f70)
{
	Packets_t inits_f6c;
	Packets_t initCalls_f6f;
	Packets_t mains_f72;
	CallInits_f6b callInits_f6b;
	callInits_f6b( classs_f6d, mains_f70, inits_f6c, initCalls_f6f, mains_f72);
	if( ( !inits_f6c.empty())&& ( !initCalls_f6f.empty())&& ( !mains_f72.empty()))
		callCreateLocalsForCall_f9d( inits_f6c, initCalls_f6f, mains_f72);
}

void CallInit_f40::callCreateLocalsForCall_f9d( const Packets_t& inits_e2d, const Packets_t& initCalls_e2f, const Packets_t& compoundStmnts_e31)
{
	Packets_t vars_e33;
	Packets_t calls_e34;
	CreateLocalsForCall_e2c createLocalsForCall_e2c;
	createLocalsForCall_e2c( inits_e2d, initCalls_e2f, compoundStmnts_e31, vars_e33, calls_e34);
	if( ( !vars_e33.empty())&& ( !calls_e34.empty()))
		callMarkContext_fa1( vars_e33, calls_e34);
}

void CallInit_f40::callMarkContext_fa1( const Packets_t& vars_f4a, const Packets_t& calls_f4c)
{
	MarkContext_f49 markContext_f49;
	markContext_f49( vars_f4a, calls_f4c);
}

void MarkContext_f49::operator()( const Packets_t& vars_f4a, const Packets_t& calls_f4c)
{
#ifdef PRINT_INFO
	std::cout << "MarkContext_f49" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(669, "MarkContext");
	processInputPackets( vars_f4a, calls_f4c);
}

bool MarkContext_f49::isInputUnique( const Udm::Object& var_f52, const Udm::Object& call_f5b)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itVar_f54= _var_f4e.begin(), itCall_f5d= _call_f57.begin(); itVar_f54!= _var_f4e.end(), itCall_f5d!= _call_f57.end(); ++itVar_f54, ++itCall_f5d)
	{
		if( ( *itVar_f54== var_f52)&& ( *itCall_f5d== call_f5b))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_var_f4e.push_back( var_f52);
		_call_f57.push_back( call_f5b);
	}
	return isUnique;
}

bool MarkContext_f49::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void MarkContext_f49::processInputPackets( const Packets_t& vars_f4a, const Packets_t& calls_f4c)
{
	for( Packets_t::const_iterator itVar_f4f= vars_f4a.begin(), itCall_f58= calls_f4c.begin(); itVar_f4f!= vars_f4a.end(), itCall_f58!= calls_f4c.end(); ++itVar_f4f, ++itCall_f58)
	{
		bool isUnique= isInputUnique( *itVar_f4f, *itCall_f58);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itVar_f4f, *itCall_f58);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool MarkContext_f49::patternMatcher( const Udm::Object& var_f50, const Udm::Object& call_f59)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( var_f50.type(), SFC::LocalVar::meta))
			continue;
		SFC::LocalVar var_f55= SFC::LocalVar::Cast( var_f50);
		if( false== Uml::IsDerivedFrom( call_f59.type(), SFC::FunctionCall::meta))
			continue;
		SFC::FunctionCall call_f5e= SFC::FunctionCall::Cast( call_f59);
		SFC::Function function_f60= call_f5e.callee();
		if( !function_f60)
			continue;
		Udm::Object functionParent_f61= function_f60.container();
		if( false== Uml::IsDerivedFrom( functionParent_f61.type(), SFC::Class::meta))
			continue;
		SFC::Class classFunction_f62= SFC::Class::Cast( functionParent_f61);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_f66;
		if( !isValidBound(boundObjs_f66, var_f55, true))
			continue;
		currMatch.var_f67= var_f55;
		if( !isValidBound(boundObjs_f66, call_f5e, true))
			continue;
		currMatch.call_f68= call_f5e;
		if( !isValidBound(boundObjs_f66, classFunction_f62, false))
			continue;
		currMatch.class_f69= classFunction_f62;
		if( !isValidBound(boundObjs_f66, function_f60, false))
			continue;
		currMatch.function_f6a= function_f60;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void MarkContext_f49::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		currMatch.var_f67.klass()+= currMatch.class_f69;
	}
}

void CallInits_f6b::operator()( const Packets_t& classs_f6d, const Packets_t& mains_f70, Packets_t& inits_f6c, Packets_t& initCalls_f6f, Packets_t& mains_f72)
{
#ifdef PRINT_INFO
	std::cout << "CallInits_f6b" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(677, "CallInits");
	_init_f73= &inits_f6c;
	_initCall_f74= &initCalls_f6f;
	_main_f75= &mains_f72;
	processInputPackets( classs_f6d, mains_f70);
}

bool CallInits_f6b::isInputUnique( const Udm::Object& class_f7a, const Udm::Object& main_f83)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_f7c= _class_f76.begin(), itMain_f85= _main_f7f.begin(); itClass_f7c!= _class_f76.end(), itMain_f85!= _main_f7f.end(); ++itClass_f7c, ++itMain_f85)
	{
		if( ( *itClass_f7c== class_f7a)&& ( *itMain_f85== main_f83))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
	{
		_class_f76.push_back( class_f7a);
		_main_f7f.push_back( main_f83);
	}
	return isUnique;
}

bool CallInits_f6b::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void CallInits_f6b::processInputPackets( const Packets_t& classs_f6d, const Packets_t& mains_f70)
{
	for( Packets_t::const_iterator itClass_f77= classs_f6d.begin(), itMain_f80= mains_f70.begin(); itClass_f77!= classs_f6d.end(), itMain_f80!= mains_f70.end(); ++itClass_f77, ++itMain_f80)
	{
		bool isUnique= isInputUnique( *itClass_f77, *itMain_f80);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itClass_f77, *itMain_f80);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CallInits_f6b::patternMatcher( const Udm::Object& class_f78, const Udm::Object& main_f81)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( class_f78.type(), SFC::Class::meta))
			continue;
		SFC::Class class_f7d= SFC::Class::Cast( class_f78);
		if( false== Uml::IsDerivedFrom( main_f81.type(), SFC::Function::meta))
			continue;
		SFC::Function main_f86= SFC::Function::Cast( main_f81);
		set< SFC::Function> inits_f88= class_f7d.Function_kind_children();
		for( set< SFC::Function>::const_iterator itInit_f89= inits_f88.begin(); itInit_f89!= inits_f88.end(); ++itInit_f89)
		{
			SFC::Function currInit_f8a= *itInit_f89;
			SFC::Function init_f8b= class_f7d.init();
			if( !init_f8b)
				continue;
			if( currInit_f8a!= init_f8b)
				continue;
			Match currMatch;
			set< pair<int, Udm::Object> > boundObjs_f8f;
			if( !isValidBound(boundObjs_f8f, class_f7d, true))
				continue;
			currMatch.class_f90= class_f7d;
			if( !isValidBound(boundObjs_f8f, main_f86, true))
				continue;
			currMatch.main_f91= main_f86;
			if( !isValidBound(boundObjs_f8f, currInit_f8a, false))
				continue;
			currMatch.init_f92= currInit_f8a;
			_matches.push_back( currMatch);
		}
	}
	return !_matches.empty();
}

void CallInits_f6b::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::FunctionCall newInitCall_f93= SFC::FunctionCall::Create( currMatch.main_f91);
		SFC::Class& Class= currMatch.class_f90;
		SFC::Function& Init= currMatch.init_f92;
		SFC::FunctionCall& InitCall= newInitCall_f93;
		SFC::Function& Main= currMatch.main_f91;
		{
__int64 statementCount = Main.statementCount();
InitCall.statementIndex() = statementCount++;
Main.statementCount() = statementCount;
};
		newInitCall_f93.callee()= currMatch.init_f92;
		outputAppender( currMatch.init_f92, newInitCall_f93, currMatch.main_f91);
	}
}

void CallInits_f6b::outputAppender( const SFC::Function& init_f94, const SFC::FunctionCall& initCall_f96, const SFC::Function& main_f98)
{
	_init_f73->push_back( init_f94);
	_initCall_f74->push_back( initCall_f96);
	_main_f75->push_back( main_f98);
}

void CreateMain_fa4::operator()( const Packets_t& classs_fa5, Packets_t& classs_fa7, Packets_t& mainFunctions_fa8)
{
#ifdef PRINT_INFO
	std::cout << "CreateMain_fa4" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(734, "CreateMain");
	_class_fa9= &classs_fa7;
	_mainFunction_faa= &mainFunctions_fa8;
	processInputPackets( classs_fa5);
}

bool CreateMain_fa4::isInputUnique( const Udm::Object& class_faf)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itClass_fb1= _class_fab.begin(); itClass_fb1!= _class_fab.end(); ++itClass_fb1)
	{
		if( ( *itClass_fb1== class_faf))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_class_fab.push_back( class_faf);
	return isUnique;
}

bool CreateMain_fa4::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void CreateMain_fa4::processInputPackets( const Packets_t& classs_fa5)
{
	for( Packets_t::const_iterator itClass_fac= classs_fa5.begin(); itClass_fac!= classs_fa5.end(); ++itClass_fac)
	{
		bool isUnique= isInputUnique( *itClass_fac);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itClass_fac);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool CreateMain_fa4::patternMatcher( const Udm::Object& class_fad)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( class_fad.type(), SFC::Class::meta))
			continue;
		SFC::Class class_fb2= SFC::Class::Cast( class_fad);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_fb7;
		if( !isValidBound(boundObjs_fb7, class_fb2, true))
			continue;
		currMatch.class_fb8= class_fb2;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void CreateMain_fa4::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::Function newMainFunction_fb9= SFC::Function::Create( currMatch.class_fb8);
		SFC::Arg newArgv_fba= SFC::Arg::Create( newMainFunction_fb9);
		SFC::Arg newArgc_fbb= SFC::Arg::Create( newMainFunction_fb9);
		SFC::Arg& Argc= newArgc_fbb;
		SFC::Arg& Argv= newArgv_fba;
		SFC::Class& Class= currMatch.class_fb8;
		SFC::Function& MainFunction= newMainFunction_fb9;
		{
__int64 statementCount = Class.statementCount();
MainFunction.statementIndex() = statementCount++;
Class.statementCount() = statementCount;
};
		{
Argc.name() = "argc";
Argc.type() = "int";
Argc.argIndex() = 0;
};
		{
Argv.name() = "argv[]";
Argv.type() = "char";
Argv.argIndex() = 1;
Argv.ptr() = true;
};
		{
MainFunction.name() = "main";
MainFunction.argCount() = 2;
MainFunction.returnType() = "int";
};
		outputAppender( currMatch.class_fb8, newMainFunction_fb9);
	}
}

void CreateMain_fa4::outputAppender( const SFC::Class& class_fbc, const SFC::Function& mainFunction_fbe)
{
	_class_fa9->push_back( class_fbc);
	_mainFunction_faa->push_back( mainFunction_fbe);
}

void GetProject_fc0::operator()( const Packets_t& projects_fc1, Packets_t& projects_fc3)
{
#ifdef PRINT_INFO
	std::cout << "GetProject_fc0" << std::endl;
#endif
	RTTGenerator::Instance()->generateRule(746, "GetProject");
	_project_fc4= &projects_fc3;
	processInputPackets( projects_fc1);
	forwardInputs( );
}

bool GetProject_fc0::isInputUnique( const Udm::Object& project_fc9)
{
	bool isUnique= true;
	for( Packets_t::const_iterator itProject_fcb= _project_fc5.begin(); itProject_fcb!= _project_fc5.end(); ++itProject_fcb)
	{
		if( ( *itProject_fcb== project_fc9))
		{
			isUnique= false;
			break;
		}
	}
	if( isUnique)
		_project_fc5.push_back( project_fc9);
	return isUnique;
}

bool GetProject_fc0::isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj)
{
	if( boundObjs.find(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj)) != boundObjs.end())
		if( !isInputObj)
			return false;
		else
			return true;
	else
		boundObjs.insert(make_pair(currObj.__impl()->__getdn()->uniqueId(), currObj));
	return true;
}

void GetProject_fc0::processInputPackets( const Packets_t& projects_fc1)
{
	for( Packets_t::const_iterator itProject_fc6= projects_fc1.begin(); itProject_fc6!= projects_fc1.end(); ++itProject_fc6)
	{
		bool isUnique= isInputUnique( *itProject_fc6);
		if( !isUnique)
			continue;
		bool isMatch= patternMatcher( *itProject_fc6);
		if( isMatch)
			effector( );
		_matches.clear();
	}
}

bool GetProject_fc0::patternMatcher( const Udm::Object& project_fc7)
{
	for( int i= 0; i< 1; ++i)
	{
		if( false== Uml::IsDerivedFrom( project_fc7.type(), SFC::Project::meta))
			continue;
		SFC::Project project_fcc= SFC::Project::Cast( project_fc7);
		Match currMatch;
		set< pair<int, Udm::Object> > boundObjs_fd1;
		if( !isValidBound(boundObjs_fd1, project_fcc, true))
			continue;
		currMatch.project_fd2= project_fcc;
		_matches.push_back( currMatch);
	}
	return !_matches.empty();
}

void GetProject_fc0::effector()
{
	for( std::list< Match>::const_iterator itMatch= _matches.begin(); itMatch!= _matches.end(); ++itMatch)
	{
		Match currMatch= *itMatch;
		SFC::Project& Project= currMatch.project_fd2;
		{
SFCTypesManager::initSingleton( Project );
};
	}
}

void GetProject_fc0::forwardInputs()
{
	*_project_fc4= _project_fc5;
}

