#ifndef MOBIES_CTEST_H
#define MOBIES_CTEST_H

// header file ctest.h generated from diagram ctest
// generated with Udm version 3.31 on Mon Jul 23 16:51:14 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace ctest {

	extern ::Uml::Diagram meta;
	class _gen_cont;
	class Arg_cross_ph_SFC;
	class Function_cross_ph_SFC;
	class IterativeBlock_cross_ph_SFC;
	class LocalVar_cross_ph_SFC;
	class StateVar_cross_ph_SFC;
	class StateLabel_cross_ph_SFC;
	class Var_cross_ph_SFC;
	class Declaration_cross_ph_SFC;
	class DT_cross_ph_SFC;
	class Struct_cross_ph_SFC;
	class ArgDeclBase_cross_ph_SFC;
	class Class_cross_ph_SFC;
	class Array_cross_ph_SFC;
	class BasicType_cross_ph_SFC;

	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

	class _gen_cont : public ::Udm::Object {
	public:
		_gen_cont();
		_gen_cont(::Udm::ObjectImpl *impl);
		_gen_cont(const _gen_cont &master);

#ifdef UDM_RVALUE
		_gen_cont(_gen_cont &&master);

		static _gen_cont Cast(::Udm::Object &&a);
		_gen_cont& operator=(_gen_cont &&a);

#endif
		static _gen_cont Cast(const ::Udm::Object &a);
		static _gen_cont Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		_gen_cont CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< _gen_cont> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< _gen_cont, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< _gen_cont, Pred>(impl); };
		_gen_cont CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< _gen_cont> Derived();
		template <class Pred> ::Udm::DerivedAttr< _gen_cont, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< _gen_cont, Pred>(impl); };
		::Udm::ArchetypeAttr< _gen_cont> Archetype() const;
		::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC> Function_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC, Pred> Function_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC, Pred>(impl, meta_Function_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC, Pred> IterativeBlock_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC, Pred>(impl, meta_IterativeBlock_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC, Pred> ArgDeclBase_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC, Pred>(impl, meta_ArgDeclBase_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC> Class_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC, Pred> Class_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC, Pred>(impl, meta_Class_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ctest::Arg_cross_ph_SFC> Arg_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Arg_cross_ph_SFC, Pred> Arg_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Arg_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC> Function_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC, Pred> Function_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC, Pred> IterativeBlock_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::LocalVar_cross_ph_SFC, Pred> LocalVar_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::LocalVar_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::StateVar_cross_ph_SFC> StateVar_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::StateVar_cross_ph_SFC, Pred> StateVar_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::StateVar_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::StateLabel_cross_ph_SFC, Pred> StateLabel_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::StateLabel_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::Var_cross_ph_SFC> Var_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Var_cross_ph_SFC, Pred> Var_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Var_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::Declaration_cross_ph_SFC> Declaration_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Declaration_cross_ph_SFC, Pred> Declaration_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Declaration_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::DT_cross_ph_SFC> DT_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::DT_cross_ph_SFC, Pred> DT_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::DT_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::Struct_cross_ph_SFC> Struct_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Struct_cross_ph_SFC, Pred> Struct_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Struct_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC, Pred> ArgDeclBase_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC> Class_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC, Pred> Class_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::Array_cross_ph_SFC> Array_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::Array_cross_ph_SFC, Pred> Array_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::Array_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ctest::BasicType_cross_ph_SFC> BasicType_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ctest::BasicType_cross_ph_SFC, Pred> BasicType_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ctest::BasicType_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_Function_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_IterativeBlock_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_ArgDeclBase_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_Class_cross_ph_SFC_childrole;

	};

	class Function_cross_ph_SFC : public ::Udm::Object {
	public:
		Function_cross_ph_SFC();
		Function_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Function_cross_ph_SFC(const Function_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Function_cross_ph_SFC(Function_cross_ph_SFC &&master);

		static Function_cross_ph_SFC Cast(::Udm::Object &&a);
		Function_cross_ph_SFC& operator=(Function_cross_ph_SFC &&a);

#endif
		static Function_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Function_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Function_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Function_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Function_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Function_cross_ph_SFC, Pred>(impl); };
		Function_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Function_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Function_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Function_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Function_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< Class_cross_ph_SFC> klassinit() const;
		::Udm::PointerAttr< Class_cross_ph_SFC> klassmain() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> Function_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_klassinit;
		static ::Uml::AssociationRole meta_klassmain;
		static ::Uml::CompositionParentRole meta_Function_cross_ph_SFC_parentrole;

	};

	class IterativeBlock_cross_ph_SFC : public ::Udm::Object {
	public:
		IterativeBlock_cross_ph_SFC();
		IterativeBlock_cross_ph_SFC(::Udm::ObjectImpl *impl);
		IterativeBlock_cross_ph_SFC(const IterativeBlock_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		IterativeBlock_cross_ph_SFC(IterativeBlock_cross_ph_SFC &&master);

		static IterativeBlock_cross_ph_SFC Cast(::Udm::Object &&a);
		IterativeBlock_cross_ph_SFC& operator=(IterativeBlock_cross_ph_SFC &&a);

#endif
		static IterativeBlock_cross_ph_SFC Cast(const ::Udm::Object &a);
		static IterativeBlock_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IterativeBlock_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC, Pred>(impl); };
		IterativeBlock_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< IterativeBlock_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> counter() const;
		::Udm::AssocAttr< Array_cross_ph_SFC> ary() const;
		template <class Pred> ::Udm::AssocAttr< Array_cross_ph_SFC, Pred> ary_sorted(const Pred &) const { return ::Udm::AssocAttr< Array_cross_ph_SFC, Pred>(impl, meta_ary); };
		::Udm::ParentAttr< ::ctest::_gen_cont> IterativeBlock_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_counter;
		static ::Uml::AssociationRole meta_ary;
		static ::Uml::CompositionParentRole meta_IterativeBlock_cross_ph_SFC_parentrole;

	};

	class ArgDeclBase_cross_ph_SFC : public ::Udm::Object {
	public:
		ArgDeclBase_cross_ph_SFC();
		ArgDeclBase_cross_ph_SFC(::Udm::ObjectImpl *impl);
		ArgDeclBase_cross_ph_SFC(const ArgDeclBase_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		ArgDeclBase_cross_ph_SFC(ArgDeclBase_cross_ph_SFC &&master);

		static ArgDeclBase_cross_ph_SFC Cast(::Udm::Object &&a);
		ArgDeclBase_cross_ph_SFC& operator=(ArgDeclBase_cross_ph_SFC &&a);

#endif
		static ArgDeclBase_cross_ph_SFC Cast(const ::Udm::Object &a);
		static ArgDeclBase_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ArgDeclBase_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC, Pred>(impl); };
		ArgDeclBase_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< ArgDeclBase_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< Struct_cross_ph_SFC> strctpath() const;
		template <class Pred> ::Udm::AssocAttr< Struct_cross_ph_SFC, Pred> strctpath_sorted(const Pred &) const { return ::Udm::AssocAttr< Struct_cross_ph_SFC, Pred>(impl, meta_strctpath); };
		::Udm::ParentAttr< ::ctest::_gen_cont> ArgDeclBase_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_strctpath;
		static ::Uml::CompositionParentRole meta_ArgDeclBase_cross_ph_SFC_parentrole;

	};

	class Arg_cross_ph_SFC :  public ArgDeclBase_cross_ph_SFC {
	public:
		Arg_cross_ph_SFC();
		Arg_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Arg_cross_ph_SFC(const Arg_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Arg_cross_ph_SFC(Arg_cross_ph_SFC &&master);

		static Arg_cross_ph_SFC Cast(::Udm::Object &&a);
		Arg_cross_ph_SFC& operator=(Arg_cross_ph_SFC &&a);

#endif
		static Arg_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Arg_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Arg_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Arg_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Arg_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Arg_cross_ph_SFC, Pred>(impl); };
		Arg_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Arg_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Arg_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Arg_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Arg_cross_ph_SFC> Archetype() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> actual() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_actual;

	};

	class Declaration_cross_ph_SFC :  public ArgDeclBase_cross_ph_SFC {
	public:
		Declaration_cross_ph_SFC();
		Declaration_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Declaration_cross_ph_SFC(const Declaration_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Declaration_cross_ph_SFC(Declaration_cross_ph_SFC &&master);

		static Declaration_cross_ph_SFC Cast(::Udm::Object &&a);
		Declaration_cross_ph_SFC& operator=(Declaration_cross_ph_SFC &&a);

#endif
		static Declaration_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Declaration_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Declaration_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Declaration_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Declaration_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Declaration_cross_ph_SFC, Pred>(impl); };
		Declaration_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Declaration_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Declaration_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Declaration_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Declaration_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class StateLabel_cross_ph_SFC :  public Declaration_cross_ph_SFC {
	public:
		StateLabel_cross_ph_SFC();
		StateLabel_cross_ph_SFC(::Udm::ObjectImpl *impl);
		StateLabel_cross_ph_SFC(const StateLabel_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		StateLabel_cross_ph_SFC(StateLabel_cross_ph_SFC &&master);

		static StateLabel_cross_ph_SFC Cast(::Udm::Object &&a);
		StateLabel_cross_ph_SFC& operator=(StateLabel_cross_ph_SFC &&a);

#endif
		static StateLabel_cross_ph_SFC Cast(const ::Udm::Object &a);
		static StateLabel_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateLabel_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC, Pred>(impl); };
		StateLabel_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateLabel_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateLabel_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateLabel_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Var_cross_ph_SFC :  public Declaration_cross_ph_SFC {
	public:
		Var_cross_ph_SFC();
		Var_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Var_cross_ph_SFC(const Var_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Var_cross_ph_SFC(Var_cross_ph_SFC &&master);

		static Var_cross_ph_SFC Cast(::Udm::Object &&a);
		Var_cross_ph_SFC& operator=(Var_cross_ph_SFC &&a);

#endif
		static Var_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Var_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Var_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Var_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Var_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Var_cross_ph_SFC, Pred>(impl); };
		Var_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Var_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Var_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Var_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Var_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class LocalVar_cross_ph_SFC :  public Var_cross_ph_SFC {
	public:
		LocalVar_cross_ph_SFC();
		LocalVar_cross_ph_SFC(::Udm::ObjectImpl *impl);
		LocalVar_cross_ph_SFC(const LocalVar_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		LocalVar_cross_ph_SFC(LocalVar_cross_ph_SFC &&master);

		static LocalVar_cross_ph_SFC Cast(::Udm::Object &&a);
		LocalVar_cross_ph_SFC& operator=(LocalVar_cross_ph_SFC &&a);

#endif
		static LocalVar_cross_ph_SFC Cast(const ::Udm::Object &a);
		static LocalVar_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		LocalVar_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC, Pred>(impl); };
		LocalVar_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< LocalVar_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< LocalVar_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< LocalVar_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC> Archetype() const;
		::Udm::AssocAttr< Arg_cross_ph_SFC> argument() const;
		template <class Pred> ::Udm::AssocAttr< Arg_cross_ph_SFC, Pred> argument_sorted(const Pred &) const { return ::Udm::AssocAttr< Arg_cross_ph_SFC, Pred>(impl, meta_argument); };
		::Udm::PointerAttr< IterativeBlock_cross_ph_SFC> loop() const;
		::Udm::AssocAttr< Class_cross_ph_SFC> klass() const;
		template <class Pred> ::Udm::AssocAttr< Class_cross_ph_SFC, Pred> klass_sorted(const Pred &) const { return ::Udm::AssocAttr< Class_cross_ph_SFC, Pred>(impl, meta_klass); };
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_argument;
		static ::Uml::AssociationRole meta_loop;
		static ::Uml::AssociationRole meta_klass;

	};

	class StateVar_cross_ph_SFC :  public Var_cross_ph_SFC {
	public:
		StateVar_cross_ph_SFC();
		StateVar_cross_ph_SFC(::Udm::ObjectImpl *impl);
		StateVar_cross_ph_SFC(const StateVar_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		StateVar_cross_ph_SFC(StateVar_cross_ph_SFC &&master);

		static StateVar_cross_ph_SFC Cast(::Udm::Object &&a);
		StateVar_cross_ph_SFC& operator=(StateVar_cross_ph_SFC &&a);

#endif
		static StateVar_cross_ph_SFC Cast(const ::Udm::Object &a);
		static StateVar_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateVar_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateVar_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateVar_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateVar_cross_ph_SFC, Pred>(impl); };
		StateVar_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateVar_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateVar_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateVar_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< StateVar_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class DT_cross_ph_SFC :  public Declaration_cross_ph_SFC {
	public:
		DT_cross_ph_SFC();
		DT_cross_ph_SFC(::Udm::ObjectImpl *impl);
		DT_cross_ph_SFC(const DT_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		DT_cross_ph_SFC(DT_cross_ph_SFC &&master);

		static DT_cross_ph_SFC Cast(::Udm::Object &&a);
		DT_cross_ph_SFC& operator=(DT_cross_ph_SFC &&a);

#endif
		static DT_cross_ph_SFC Cast(const ::Udm::Object &a);
		static DT_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DT_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DT_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DT_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DT_cross_ph_SFC, Pred>(impl); };
		DT_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DT_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< DT_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DT_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< DT_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Struct_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		Struct_cross_ph_SFC();
		Struct_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Struct_cross_ph_SFC(const Struct_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Struct_cross_ph_SFC(Struct_cross_ph_SFC &&master);

		static Struct_cross_ph_SFC Cast(::Udm::Object &&a);
		Struct_cross_ph_SFC& operator=(Struct_cross_ph_SFC &&a);

#endif
		static Struct_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Struct_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Struct_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Struct_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Struct_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Struct_cross_ph_SFC, Pred>(impl); };
		Struct_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Struct_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Struct_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Struct_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Struct_cross_ph_SFC> Archetype() const;
		::Udm::PointerAttr< ArgDeclBase_cross_ph_SFC> adbpath() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_adbpath;

	};

	class Class_cross_ph_SFC : public ::Udm::Object {
	public:
		Class_cross_ph_SFC();
		Class_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Class_cross_ph_SFC(const Class_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Class_cross_ph_SFC(Class_cross_ph_SFC &&master);

		static Class_cross_ph_SFC Cast(::Udm::Object &&a);
		Class_cross_ph_SFC& operator=(Class_cross_ph_SFC &&a);

#endif
		static Class_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Class_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Class_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Class_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Class_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Class_cross_ph_SFC, Pred>(impl); };
		Class_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Class_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Class_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Class_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Class_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< Function_cross_ph_SFC> init() const;
		::Udm::AssocAttr< LocalVar_cross_ph_SFC> context() const;
		template <class Pred> ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred> context_sorted(const Pred &) const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred>(impl, meta_context); };
		::Udm::PointerAttr< Function_cross_ph_SFC> main() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> Class_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_init;
		static ::Uml::AssociationRole meta_context;
		static ::Uml::AssociationRole meta_main;
		static ::Uml::CompositionParentRole meta_Class_cross_ph_SFC_parentrole;

	};

	class Array_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		Array_cross_ph_SFC();
		Array_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Array_cross_ph_SFC(const Array_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Array_cross_ph_SFC(Array_cross_ph_SFC &&master);

		static Array_cross_ph_SFC Cast(::Udm::Object &&a);
		Array_cross_ph_SFC& operator=(Array_cross_ph_SFC &&a);

#endif
		static Array_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Array_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Array_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Array_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Array_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Array_cross_ph_SFC, Pred>(impl); };
		Array_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Array_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Array_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Array_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Array_cross_ph_SFC> Archetype() const;
		::Udm::AssocAttr< IterativeBlock_cross_ph_SFC> itb() const;
		template <class Pred> ::Udm::AssocAttr< IterativeBlock_cross_ph_SFC, Pred> itb_sorted(const Pred &) const { return ::Udm::AssocAttr< IterativeBlock_cross_ph_SFC, Pred>(impl, meta_itb); };
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_itb;

	};

	class BasicType_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		BasicType_cross_ph_SFC();
		BasicType_cross_ph_SFC(::Udm::ObjectImpl *impl);
		BasicType_cross_ph_SFC(const BasicType_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		BasicType_cross_ph_SFC(BasicType_cross_ph_SFC &&master);

		static BasicType_cross_ph_SFC Cast(::Udm::Object &&a);
		BasicType_cross_ph_SFC& operator=(BasicType_cross_ph_SFC &&a);

#endif
		static BasicType_cross_ph_SFC Cast(const ::Udm::Object &a);
		static BasicType_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BasicType_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BasicType_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC, Pred>(impl); };
		BasicType_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BasicType_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< BasicType_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BasicType_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< BasicType_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ctest::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

}

#endif // MOBIES_CTEST_H
