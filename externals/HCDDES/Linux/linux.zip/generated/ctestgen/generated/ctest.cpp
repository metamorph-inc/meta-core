// cpp (meta datanetwork format) source file ctest.cpp
// generated from diagram ctest
// generated on Mon Jul 23 16:51:14 2012

#include "ctest.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "ctest_xsd.h"
using namespace std;

namespace ctest {

	_gen_cont::_gen_cont() {}
	_gen_cont::_gen_cont(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	_gen_cont::_gen_cont(const _gen_cont &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	_gen_cont::_gen_cont(_gen_cont &&master) : UDM_OBJECT(master) {};

	_gen_cont _gen_cont::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	_gen_cont& _gen_cont::operator=(_gen_cont &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	_gen_cont _gen_cont::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	_gen_cont _gen_cont::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	_gen_cont _gen_cont::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< _gen_cont> _gen_cont::Instances() { return ::Udm::InstantiatedAttr< _gen_cont>(impl); }
	_gen_cont _gen_cont::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< _gen_cont> _gen_cont::Derived() { return ::Udm::DerivedAttr< _gen_cont>(impl); }
	::Udm::ArchetypeAttr< _gen_cont> _gen_cont::Archetype() const { return ::Udm::ArchetypeAttr< _gen_cont>(impl); }
	::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC> _gen_cont::Function_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC>(impl, meta_Function_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC> _gen_cont::IterativeBlock_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC>(impl, meta_IterativeBlock_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC> _gen_cont::ArgDeclBase_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC>(impl, meta_ArgDeclBase_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC> _gen_cont::Class_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC>(impl, meta_Class_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ctest::Arg_cross_ph_SFC> _gen_cont::Arg_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Arg_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC> _gen_cont::Function_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Function_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC> _gen_cont::IterativeBlock_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::IterativeBlock_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::LocalVar_cross_ph_SFC> _gen_cont::LocalVar_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::LocalVar_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::StateVar_cross_ph_SFC> _gen_cont::StateVar_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::StateVar_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::StateLabel_cross_ph_SFC> _gen_cont::StateLabel_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::StateLabel_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::Var_cross_ph_SFC> _gen_cont::Var_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Var_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::Declaration_cross_ph_SFC> _gen_cont::Declaration_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Declaration_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::DT_cross_ph_SFC> _gen_cont::DT_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::DT_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::Struct_cross_ph_SFC> _gen_cont::Struct_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Struct_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC> _gen_cont::ArgDeclBase_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::ArgDeclBase_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC> _gen_cont::Class_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Class_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::Array_cross_ph_SFC> _gen_cont::Array_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::Array_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ctest::BasicType_cross_ph_SFC> _gen_cont::BasicType_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ctest::BasicType_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::Udm::Object> _gen_cont::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class _gen_cont::meta;
	::Uml::CompositionChildRole _gen_cont::meta_Function_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_IterativeBlock_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Class_cross_ph_SFC_childrole;

	Arg_cross_ph_SFC::Arg_cross_ph_SFC() {}
	Arg_cross_ph_SFC::Arg_cross_ph_SFC(::Udm::ObjectImpl *impl) : ArgDeclBase_cross_ph_SFC(impl) {}
	Arg_cross_ph_SFC::Arg_cross_ph_SFC(const Arg_cross_ph_SFC &master) : ArgDeclBase_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Arg_cross_ph_SFC::Arg_cross_ph_SFC(Arg_cross_ph_SFC &&master) : ArgDeclBase_cross_ph_SFC(master) {};

	Arg_cross_ph_SFC Arg_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Arg_cross_ph_SFC& Arg_cross_ph_SFC::operator=(Arg_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Arg_cross_ph_SFC Arg_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Arg_cross_ph_SFC Arg_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Arg_cross_ph_SFC Arg_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Arg_cross_ph_SFC> Arg_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Arg_cross_ph_SFC>(impl); }
	Arg_cross_ph_SFC Arg_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Arg_cross_ph_SFC> Arg_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Arg_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Arg_cross_ph_SFC> Arg_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Arg_cross_ph_SFC>(impl); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> Arg_cross_ph_SFC::actual() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_actual); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Arg_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Arg_cross_ph_SFC::meta;
	::Uml::AssociationRole Arg_cross_ph_SFC::meta_actual;

	Function_cross_ph_SFC::Function_cross_ph_SFC() {}
	Function_cross_ph_SFC::Function_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Function_cross_ph_SFC::Function_cross_ph_SFC(const Function_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Function_cross_ph_SFC::Function_cross_ph_SFC(Function_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	Function_cross_ph_SFC Function_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Function_cross_ph_SFC& Function_cross_ph_SFC::operator=(Function_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Function_cross_ph_SFC Function_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Function_cross_ph_SFC Function_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Function_cross_ph_SFC Function_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Function_cross_ph_SFC>(impl); }
	Function_cross_ph_SFC Function_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Function_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Function_cross_ph_SFC>(impl); }
	::Udm::StringAttr Function_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Function_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< Class_cross_ph_SFC> Function_cross_ph_SFC::klassinit() const { return ::Udm::PointerAttr< Class_cross_ph_SFC>(impl, meta_klassinit); }
	::Udm::PointerAttr< Class_cross_ph_SFC> Function_cross_ph_SFC::klassmain() const { return ::Udm::PointerAttr< Class_cross_ph_SFC>(impl, meta_klassmain); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Function_cross_ph_SFC::Function_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, meta_Function_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Function_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Function_cross_ph_SFC::meta;
	::Uml::Attribute Function_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute Function_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_klassinit;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_klassmain;
	::Uml::CompositionParentRole Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole;

	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC() {}
	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC(const IterativeBlock_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC(IterativeBlock_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IterativeBlock_cross_ph_SFC& IterativeBlock_cross_ph_SFC::operator=(IterativeBlock_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< IterativeBlock_cross_ph_SFC>(impl); }
	IterativeBlock_cross_ph_SFC IterativeBlock_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< IterativeBlock_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< IterativeBlock_cross_ph_SFC> IterativeBlock_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< IterativeBlock_cross_ph_SFC>(impl); }
	::Udm::StringAttr IterativeBlock_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr IterativeBlock_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> IterativeBlock_cross_ph_SFC::counter() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_counter); }
	::Udm::AssocAttr< Array_cross_ph_SFC> IterativeBlock_cross_ph_SFC::ary() const { return ::Udm::AssocAttr< Array_cross_ph_SFC>(impl, meta_ary); }
	::Udm::ParentAttr< ::ctest::_gen_cont> IterativeBlock_cross_ph_SFC::IterativeBlock_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, meta_IterativeBlock_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ctest::_gen_cont> IterativeBlock_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IterativeBlock_cross_ph_SFC::meta;
	::Uml::Attribute IterativeBlock_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute IterativeBlock_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole IterativeBlock_cross_ph_SFC::meta_counter;
	::Uml::AssociationRole IterativeBlock_cross_ph_SFC::meta_ary;
	::Uml::CompositionParentRole IterativeBlock_cross_ph_SFC::meta_IterativeBlock_cross_ph_SFC_parentrole;

	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC() {}
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(::Udm::ObjectImpl *impl) : Var_cross_ph_SFC(impl) {}
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(const LocalVar_cross_ph_SFC &master) : Var_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(LocalVar_cross_ph_SFC &&master) : Var_cross_ph_SFC(master) {};

	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	LocalVar_cross_ph_SFC& LocalVar_cross_ph_SFC::operator=(LocalVar_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC>(impl); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< LocalVar_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC>(impl); }
	::Udm::AssocAttr< Arg_cross_ph_SFC> LocalVar_cross_ph_SFC::argument() const { return ::Udm::AssocAttr< Arg_cross_ph_SFC>(impl, meta_argument); }
	::Udm::PointerAttr< IterativeBlock_cross_ph_SFC> LocalVar_cross_ph_SFC::loop() const { return ::Udm::PointerAttr< IterativeBlock_cross_ph_SFC>(impl, meta_loop); }
	::Udm::AssocAttr< Class_cross_ph_SFC> LocalVar_cross_ph_SFC::klass() const { return ::Udm::AssocAttr< Class_cross_ph_SFC>(impl, meta_klass); }
	::Udm::ParentAttr< ::ctest::_gen_cont> LocalVar_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class LocalVar_cross_ph_SFC::meta;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_argument;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_loop;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_klass;

	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC() {}
	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC(::Udm::ObjectImpl *impl) : Var_cross_ph_SFC(impl) {}
	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC(const StateVar_cross_ph_SFC &master) : Var_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC(StateVar_cross_ph_SFC &&master) : Var_cross_ph_SFC(master) {};

	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateVar_cross_ph_SFC& StateVar_cross_ph_SFC::operator=(StateVar_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateVar_cross_ph_SFC> StateVar_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< StateVar_cross_ph_SFC>(impl); }
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateVar_cross_ph_SFC> StateVar_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< StateVar_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< StateVar_cross_ph_SFC> StateVar_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< StateVar_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ctest::_gen_cont> StateVar_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateVar_cross_ph_SFC::meta;

	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC() {}
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(::Udm::ObjectImpl *impl) : Declaration_cross_ph_SFC(impl) {}
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(const StateLabel_cross_ph_SFC &master) : Declaration_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(StateLabel_cross_ph_SFC &&master) : Declaration_cross_ph_SFC(master) {};

	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateLabel_cross_ph_SFC& StateLabel_cross_ph_SFC::operator=(StateLabel_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC>(impl); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< StateLabel_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ctest::_gen_cont> StateLabel_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateLabel_cross_ph_SFC::meta;

	Var_cross_ph_SFC::Var_cross_ph_SFC() {}
	Var_cross_ph_SFC::Var_cross_ph_SFC(::Udm::ObjectImpl *impl) : Declaration_cross_ph_SFC(impl) {}
	Var_cross_ph_SFC::Var_cross_ph_SFC(const Var_cross_ph_SFC &master) : Declaration_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Var_cross_ph_SFC::Var_cross_ph_SFC(Var_cross_ph_SFC &&master) : Declaration_cross_ph_SFC(master) {};

	Var_cross_ph_SFC Var_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Var_cross_ph_SFC& Var_cross_ph_SFC::operator=(Var_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Var_cross_ph_SFC Var_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Var_cross_ph_SFC Var_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Var_cross_ph_SFC Var_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Var_cross_ph_SFC> Var_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Var_cross_ph_SFC>(impl); }
	Var_cross_ph_SFC Var_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Var_cross_ph_SFC> Var_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Var_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Var_cross_ph_SFC> Var_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Var_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Var_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Var_cross_ph_SFC::meta;

	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC() {}
	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC(::Udm::ObjectImpl *impl) : ArgDeclBase_cross_ph_SFC(impl) {}
	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC(const Declaration_cross_ph_SFC &master) : ArgDeclBase_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC(Declaration_cross_ph_SFC &&master) : ArgDeclBase_cross_ph_SFC(master) {};

	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Declaration_cross_ph_SFC& Declaration_cross_ph_SFC::operator=(Declaration_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Declaration_cross_ph_SFC> Declaration_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Declaration_cross_ph_SFC>(impl); }
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Declaration_cross_ph_SFC> Declaration_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Declaration_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Declaration_cross_ph_SFC> Declaration_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Declaration_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Declaration_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Declaration_cross_ph_SFC::meta;

	DT_cross_ph_SFC::DT_cross_ph_SFC() {}
	DT_cross_ph_SFC::DT_cross_ph_SFC(::Udm::ObjectImpl *impl) : Declaration_cross_ph_SFC(impl) {}
	DT_cross_ph_SFC::DT_cross_ph_SFC(const DT_cross_ph_SFC &master) : Declaration_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	DT_cross_ph_SFC::DT_cross_ph_SFC(DT_cross_ph_SFC &&master) : Declaration_cross_ph_SFC(master) {};

	DT_cross_ph_SFC DT_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DT_cross_ph_SFC& DT_cross_ph_SFC::operator=(DT_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DT_cross_ph_SFC DT_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DT_cross_ph_SFC DT_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DT_cross_ph_SFC DT_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< DT_cross_ph_SFC>(impl); }
	DT_cross_ph_SFC DT_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< DT_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< DT_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ctest::_gen_cont> DT_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DT_cross_ph_SFC::meta;

	Struct_cross_ph_SFC::Struct_cross_ph_SFC() {}
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(const Struct_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(Struct_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	Struct_cross_ph_SFC Struct_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Struct_cross_ph_SFC& Struct_cross_ph_SFC::operator=(Struct_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Struct_cross_ph_SFC Struct_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Struct_cross_ph_SFC>(impl); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Struct_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Struct_cross_ph_SFC>(impl); }
	::Udm::PointerAttr< ArgDeclBase_cross_ph_SFC> Struct_cross_ph_SFC::adbpath() const { return ::Udm::PointerAttr< ArgDeclBase_cross_ph_SFC>(impl, meta_adbpath); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Struct_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Struct_cross_ph_SFC::meta;
	::Uml::AssociationRole Struct_cross_ph_SFC::meta_adbpath;

	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC() {}
	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC(const ArgDeclBase_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC(ArgDeclBase_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ArgDeclBase_cross_ph_SFC& ArgDeclBase_cross_ph_SFC::operator=(ArgDeclBase_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC>(impl); }
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< ArgDeclBase_cross_ph_SFC>(impl); }
	::Udm::StringAttr ArgDeclBase_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr ArgDeclBase_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< Struct_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::strctpath() const { return ::Udm::AssocAttr< Struct_cross_ph_SFC>(impl, meta_strctpath); }
	::Udm::ParentAttr< ::ctest::_gen_cont> ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, meta_ArgDeclBase_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ctest::_gen_cont> ArgDeclBase_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ArgDeclBase_cross_ph_SFC::meta;
	::Uml::Attribute ArgDeclBase_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute ArgDeclBase_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole ArgDeclBase_cross_ph_SFC::meta_strctpath;
	::Uml::CompositionParentRole ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole;

	Class_cross_ph_SFC::Class_cross_ph_SFC() {}
	Class_cross_ph_SFC::Class_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Class_cross_ph_SFC::Class_cross_ph_SFC(const Class_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Class_cross_ph_SFC::Class_cross_ph_SFC(Class_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	Class_cross_ph_SFC Class_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Class_cross_ph_SFC& Class_cross_ph_SFC::operator=(Class_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Class_cross_ph_SFC Class_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Class_cross_ph_SFC Class_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Class_cross_ph_SFC Class_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Class_cross_ph_SFC>(impl); }
	Class_cross_ph_SFC Class_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Class_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Class_cross_ph_SFC>(impl); }
	::Udm::StringAttr Class_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Class_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< Function_cross_ph_SFC> Class_cross_ph_SFC::init() const { return ::Udm::PointerAttr< Function_cross_ph_SFC>(impl, meta_init); }
	::Udm::AssocAttr< LocalVar_cross_ph_SFC> Class_cross_ph_SFC::context() const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC>(impl, meta_context); }
	::Udm::PointerAttr< Function_cross_ph_SFC> Class_cross_ph_SFC::main() const { return ::Udm::PointerAttr< Function_cross_ph_SFC>(impl, meta_main); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Class_cross_ph_SFC::Class_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, meta_Class_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Class_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Class_cross_ph_SFC::meta;
	::Uml::Attribute Class_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute Class_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole Class_cross_ph_SFC::meta_init;
	::Uml::AssociationRole Class_cross_ph_SFC::meta_context;
	::Uml::AssociationRole Class_cross_ph_SFC::meta_main;
	::Uml::CompositionParentRole Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole;

	Array_cross_ph_SFC::Array_cross_ph_SFC() {}
	Array_cross_ph_SFC::Array_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	Array_cross_ph_SFC::Array_cross_ph_SFC(const Array_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Array_cross_ph_SFC::Array_cross_ph_SFC(Array_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	Array_cross_ph_SFC Array_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Array_cross_ph_SFC& Array_cross_ph_SFC::operator=(Array_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Array_cross_ph_SFC Array_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Array_cross_ph_SFC Array_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Array_cross_ph_SFC Array_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Array_cross_ph_SFC>(impl); }
	Array_cross_ph_SFC Array_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Array_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Array_cross_ph_SFC>(impl); }
	::Udm::AssocAttr< IterativeBlock_cross_ph_SFC> Array_cross_ph_SFC::itb() const { return ::Udm::AssocAttr< IterativeBlock_cross_ph_SFC>(impl, meta_itb); }
	::Udm::ParentAttr< ::ctest::_gen_cont> Array_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Array_cross_ph_SFC::meta;
	::Uml::AssociationRole Array_cross_ph_SFC::meta_itb;

	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC() {}
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(const BasicType_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(BasicType_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BasicType_cross_ph_SFC& BasicType_cross_ph_SFC::operator=(BasicType_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC>(impl); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< BasicType_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< BasicType_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ctest::_gen_cont> BasicType_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ctest::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BasicType_cross_ph_SFC::meta;

	::Uml::Diagram meta;

	void CreateMeta() {
		// classes, with attributes, constraints and constraint definitions
		ArgDeclBase_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		ArgDeclBase_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(ArgDeclBase_cross_ph_SFC::meta);
		ArgDeclBase_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(ArgDeclBase_cross_ph_SFC::meta);

		Arg_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Array_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		BasicType_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Class_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		Class_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(Class_cross_ph_SFC::meta);
		Class_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(Class_cross_ph_SFC::meta);

		DT_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Declaration_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Function_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		Function_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(Function_cross_ph_SFC::meta);
		Function_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(Function_cross_ph_SFC::meta);

		IterativeBlock_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		IterativeBlock_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(IterativeBlock_cross_ph_SFC::meta);
		IterativeBlock_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(IterativeBlock_cross_ph_SFC::meta);

		LocalVar_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		StateLabel_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		StateVar_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Struct_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Var_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		_gen_cont::meta = ::Uml::Class::Create(meta);

	}

	void InitMeta() {
		// classes, with attributes, constraints and constraint definitions
		::Uml::InitClassProps(ArgDeclBase_cross_ph_SFC::meta, "ArgDeclBase_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(ArgDeclBase_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ArgDeclBase_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Arg_cross_ph_SFC::meta, "Arg_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Array_cross_ph_SFC::meta, "Array_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(BasicType_cross_ph_SFC::meta, "BasicType_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Class_cross_ph_SFC::meta, "Class_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(Class_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Class_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(DT_cross_ph_SFC::meta, "DT_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Declaration_cross_ph_SFC::meta, "Declaration_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Function_cross_ph_SFC::meta, "Function_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(Function_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Function_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(IterativeBlock_cross_ph_SFC::meta, "IterativeBlock_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(IterativeBlock_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(IterativeBlock_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(LocalVar_cross_ph_SFC::meta, "LocalVar_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(StateLabel_cross_ph_SFC::meta, "StateLabel_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(StateVar_cross_ph_SFC::meta, "StateVar_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Struct_cross_ph_SFC::meta, "Struct_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Var_cross_ph_SFC::meta, "Var_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(_gen_cont::meta, "_gen_cont", false, NULL, NULL);

		// associations
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Arg_cross_ph_SFC::meta_actual = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Arg_cross_ph_SFC::meta_actual, "actual", true, false, 0, 1);
			LocalVar_cross_ph_SFC::meta_argument = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_argument, "argument", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_klassinit = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_klassinit, "klassinit", true, false, 0, 1);
			Class_cross_ph_SFC::meta_init = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Class_cross_ph_SFC::meta_init, "init", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			IterativeBlock_cross_ph_SFC::meta_counter = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IterativeBlock_cross_ph_SFC::meta_counter, "counter", true, false, 0, 1);
			LocalVar_cross_ph_SFC::meta_loop = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_loop, "loop", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			ArgDeclBase_cross_ph_SFC::meta_strctpath = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ArgDeclBase_cross_ph_SFC::meta_strctpath, "strctpath", true, false, 0, -1);
			Struct_cross_ph_SFC::meta_adbpath = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Struct_cross_ph_SFC::meta_adbpath, "adbpath", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Class_cross_ph_SFC::meta_context = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Class_cross_ph_SFC::meta_context, "context", true, false, 0, -1);
			LocalVar_cross_ph_SFC::meta_klass = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_klass, "klass", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Class_cross_ph_SFC::meta_main = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Class_cross_ph_SFC::meta_main, "main", true, false, 0, 1);
			Function_cross_ph_SFC::meta_klassmain = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_klassmain, "klassmain", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Array_cross_ph_SFC::meta_itb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Array_cross_ph_SFC::meta_itb, "itb", true, false, 0, -1);
			IterativeBlock_cross_ph_SFC::meta_ary = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IterativeBlock_cross_ph_SFC::meta_ary, "ary", true, false, 0, -1);

		}

		// compositions
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole, "Function_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_Function_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Function_cross_ph_SFC_childrole, "Function_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			IterativeBlock_cross_ph_SFC::meta_IterativeBlock_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(IterativeBlock_cross_ph_SFC::meta_IterativeBlock_cross_ph_SFC_parentrole, "IterativeBlock_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_IterativeBlock_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_IterativeBlock_cross_ph_SFC_childrole, "IterativeBlock_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole, "ArgDeclBase_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole, "ArgDeclBase_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole, "Class_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_Class_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Class_cross_ph_SFC_childrole, "Class_cross_ph_SFC_childrole", true, 0, -1);

		}

	}

	void InitMetaLinks() {
		ArgDeclBase_cross_ph_SFC::meta_strctpath.target() = Struct_cross_ph_SFC::meta;
		_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole.target() = ArgDeclBase_cross_ph_SFC::meta;
		ArgDeclBase_cross_ph_SFC::meta.subTypes() += Arg_cross_ph_SFC::meta;
		ArgDeclBase_cross_ph_SFC::meta.subTypes() += Declaration_cross_ph_SFC::meta;

		Arg_cross_ph_SFC::meta_actual.target() = LocalVar_cross_ph_SFC::meta;

		Array_cross_ph_SFC::meta_itb.target() = IterativeBlock_cross_ph_SFC::meta;

		Class_cross_ph_SFC::meta_init.target() = Function_cross_ph_SFC::meta;
		Class_cross_ph_SFC::meta_context.target() = LocalVar_cross_ph_SFC::meta;
		Class_cross_ph_SFC::meta_main.target() = Function_cross_ph_SFC::meta;
		_gen_cont::meta_Class_cross_ph_SFC_childrole.target() = Class_cross_ph_SFC::meta;

		DT_cross_ph_SFC::meta.subTypes() += Struct_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += Array_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += BasicType_cross_ph_SFC::meta;

		Declaration_cross_ph_SFC::meta.subTypes() += StateLabel_cross_ph_SFC::meta;
		Declaration_cross_ph_SFC::meta.subTypes() += Var_cross_ph_SFC::meta;
		Declaration_cross_ph_SFC::meta.subTypes() += DT_cross_ph_SFC::meta;

		Function_cross_ph_SFC::meta_klassinit.target() = Class_cross_ph_SFC::meta;
		Function_cross_ph_SFC::meta_klassmain.target() = Class_cross_ph_SFC::meta;
		_gen_cont::meta_Function_cross_ph_SFC_childrole.target() = Function_cross_ph_SFC::meta;

		IterativeBlock_cross_ph_SFC::meta_counter.target() = LocalVar_cross_ph_SFC::meta;
		IterativeBlock_cross_ph_SFC::meta_ary.target() = Array_cross_ph_SFC::meta;
		_gen_cont::meta_IterativeBlock_cross_ph_SFC_childrole.target() = IterativeBlock_cross_ph_SFC::meta;

		LocalVar_cross_ph_SFC::meta_argument.target() = Arg_cross_ph_SFC::meta;
		LocalVar_cross_ph_SFC::meta_loop.target() = IterativeBlock_cross_ph_SFC::meta;
		LocalVar_cross_ph_SFC::meta_klass.target() = Class_cross_ph_SFC::meta;

		Struct_cross_ph_SFC::meta_adbpath.target() = ArgDeclBase_cross_ph_SFC::meta;

		Var_cross_ph_SFC::meta.subTypes() += LocalVar_cross_ph_SFC::meta;
		Var_cross_ph_SFC::meta.subTypes() += StateVar_cross_ph_SFC::meta;

		Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		IterativeBlock_cross_ph_SFC::meta_IterativeBlock_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole.target() = _gen_cont::meta;

	}

	void InitMeta(const ::Uml::Diagram &parent) {
		// classes, with attributes, constraints and constraint definitions
		::Uml::SetClass(ArgDeclBase_cross_ph_SFC::meta, parent, "ArgDeclBase_cross_ph_SFC");
		::Uml::SetAttribute(ArgDeclBase_cross_ph_SFC::meta_rem_sysname, ArgDeclBase_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(ArgDeclBase_cross_ph_SFC::meta_rem_id, ArgDeclBase_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(Arg_cross_ph_SFC::meta, parent, "Arg_cross_ph_SFC");

		::Uml::SetClass(Array_cross_ph_SFC::meta, parent, "Array_cross_ph_SFC");

		::Uml::SetClass(BasicType_cross_ph_SFC::meta, parent, "BasicType_cross_ph_SFC");

		::Uml::SetClass(Class_cross_ph_SFC::meta, parent, "Class_cross_ph_SFC");
		::Uml::SetAttribute(Class_cross_ph_SFC::meta_rem_sysname, Class_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(Class_cross_ph_SFC::meta_rem_id, Class_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(DT_cross_ph_SFC::meta, parent, "DT_cross_ph_SFC");

		::Uml::SetClass(Declaration_cross_ph_SFC::meta, parent, "Declaration_cross_ph_SFC");

		::Uml::SetClass(Function_cross_ph_SFC::meta, parent, "Function_cross_ph_SFC");
		::Uml::SetAttribute(Function_cross_ph_SFC::meta_rem_sysname, Function_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(Function_cross_ph_SFC::meta_rem_id, Function_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(IterativeBlock_cross_ph_SFC::meta, parent, "IterativeBlock_cross_ph_SFC");
		::Uml::SetAttribute(IterativeBlock_cross_ph_SFC::meta_rem_sysname, IterativeBlock_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(IterativeBlock_cross_ph_SFC::meta_rem_id, IterativeBlock_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(LocalVar_cross_ph_SFC::meta, parent, "LocalVar_cross_ph_SFC");

		::Uml::SetClass(StateLabel_cross_ph_SFC::meta, parent, "StateLabel_cross_ph_SFC");

		::Uml::SetClass(StateVar_cross_ph_SFC::meta, parent, "StateVar_cross_ph_SFC");

		::Uml::SetClass(Struct_cross_ph_SFC::meta, parent, "Struct_cross_ph_SFC");

		::Uml::SetClass(Var_cross_ph_SFC::meta, parent, "Var_cross_ph_SFC");

		::Uml::SetClass(_gen_cont::meta, parent, "_gen_cont");

	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
		// classes
		::Uml::SetAssocRole(ArgDeclBase_cross_ph_SFC::meta_strctpath, ArgDeclBase_cross_ph_SFC::meta, Struct_cross_ph_SFC::meta, "adbpath");
		::Uml::SetParentRole(ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole, ArgDeclBase_cross_ph_SFC::meta, _gen_cont::meta, "ArgDeclBase_cross_ph_SFC_childrole", "ArgDeclBase_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(Arg_cross_ph_SFC::meta_actual, Arg_cross_ph_SFC::meta, LocalVar_cross_ph_SFC::meta, "argument");

		::Uml::SetAssocRole(Array_cross_ph_SFC::meta_itb, Array_cross_ph_SFC::meta, IterativeBlock_cross_ph_SFC::meta, "ary");

		::Uml::SetAssocRole(Class_cross_ph_SFC::meta_init, Class_cross_ph_SFC::meta, Function_cross_ph_SFC::meta, "klassinit");
		::Uml::SetAssocRole(Class_cross_ph_SFC::meta_context, Class_cross_ph_SFC::meta, LocalVar_cross_ph_SFC::meta, "klass");
		::Uml::SetAssocRole(Class_cross_ph_SFC::meta_main, Class_cross_ph_SFC::meta, Function_cross_ph_SFC::meta, "klassmain");
		::Uml::SetParentRole(Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole, Class_cross_ph_SFC::meta, _gen_cont::meta, "Class_cross_ph_SFC_childrole", "Class_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_klassinit, Function_cross_ph_SFC::meta, Class_cross_ph_SFC::meta, "init");
		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_klassmain, Function_cross_ph_SFC::meta, Class_cross_ph_SFC::meta, "main");
		::Uml::SetParentRole(Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole, Function_cross_ph_SFC::meta, _gen_cont::meta, "Function_cross_ph_SFC_childrole", "Function_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(IterativeBlock_cross_ph_SFC::meta_counter, IterativeBlock_cross_ph_SFC::meta, LocalVar_cross_ph_SFC::meta, "loop");
		::Uml::SetAssocRole(IterativeBlock_cross_ph_SFC::meta_ary, IterativeBlock_cross_ph_SFC::meta, Array_cross_ph_SFC::meta, "itb");
		::Uml::SetParentRole(IterativeBlock_cross_ph_SFC::meta_IterativeBlock_cross_ph_SFC_parentrole, IterativeBlock_cross_ph_SFC::meta, _gen_cont::meta, "IterativeBlock_cross_ph_SFC_childrole", "IterativeBlock_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_argument, LocalVar_cross_ph_SFC::meta, Arg_cross_ph_SFC::meta, "actual");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_loop, LocalVar_cross_ph_SFC::meta, IterativeBlock_cross_ph_SFC::meta, "counter");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_klass, LocalVar_cross_ph_SFC::meta, Class_cross_ph_SFC::meta, "context");

		::Uml::SetAssocRole(Struct_cross_ph_SFC::meta_adbpath, Struct_cross_ph_SFC::meta, ArgDeclBase_cross_ph_SFC::meta, "strctpath");

		::Uml::SetChildRole(_gen_cont::meta_Function_cross_ph_SFC_childrole, _gen_cont::meta, Function_cross_ph_SFC::meta, "Function_cross_ph_SFC_parentrole", "Function_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_IterativeBlock_cross_ph_SFC_childrole, _gen_cont::meta, IterativeBlock_cross_ph_SFC::meta, "IterativeBlock_cross_ph_SFC_parentrole", "IterativeBlock_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole, _gen_cont::meta, ArgDeclBase_cross_ph_SFC::meta, "ArgDeclBase_cross_ph_SFC_parentrole", "ArgDeclBase_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Class_cross_ph_SFC_childrole, _gen_cont::meta, Class_cross_ph_SFC::meta, "Class_cross_ph_SFC_parentrole", "Class_cross_ph_SFC_childrole");

	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("ctest.xsd", ctest_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("ctest.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "ctest", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("ctest", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("ctest");
		}
	} __regUnUsed;

}

