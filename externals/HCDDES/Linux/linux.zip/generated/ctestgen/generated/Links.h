#ifndef MOBIES_LINKS_H
#define MOBIES_LINKS_H

// header file Links.h generated from diagram Links
// generated with Udm version 3.31 on Mon Jul 23 16:51:14 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace SFC {
	class Arg;
	class Function;
	class IterativeBlock;
	class LocalVar;
	class StateVar;
	class StateLabel;
	class Var;
	class Declaration;
	class DT;
	class Struct;
	class ArgDeclBase;
	class Class;
	class Array;
	class BasicType;

}

namespace Links {

	extern ::Uml::Diagram meta;
	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

}

#endif // MOBIES_LINKS_H
