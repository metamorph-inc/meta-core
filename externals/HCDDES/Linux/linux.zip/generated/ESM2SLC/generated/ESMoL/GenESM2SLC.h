/* GenESM2SLC.h generated on Mon Jul 23 16:50:55 2012
 */

#include <UdmBase.h>
#include <UdmUtil.h>
#include <cint_string.h>
#include "ESM2SLC.h"
#include "ESMoL.h"
#include "LINKS.h"
#include "SFC.h"

typedef std::list< Udm::Object> Packets_t;

// Forward declarations.
class GetSubsystems_0;
class GetSubSystems_5;
class Test_1e;
class NoRefSubsystem_2c;
class RefSubsystem_42;
class GetRefSubsystems_57;
class GetDataflowSubsystems_5c;
class Test_75;
class RefSubsystem_83;
class NoRefSubsystem_9c;
class Recurse_b1;
class MakeArgDeclRef_d6;
class InpArgVal_dd;
class CheckSigSrc_109;
class IsTrigger_131;
class Otherwise_166;
class InpArgValTrigger_19b;
class GetAllMethodCalls_1d3;
class GetClassFunctions_1dc;
class GetSubCompounds_207;
class GetMethodCalls_240;
class MakeTrigger_283;
class CreateTriggering_290;
class CreateTriggerOr_29d;
class ArgDeclIsCondition_2a4;
class StructTest_2c2;
class IsStruct_2ea;
class Otherwise_31f;
class PlaceMember_354;
class CreateLastBinaryExprs_379;
class CreateNextBinaryExprs_3a5;
class TestMemberPos_3d2;
class NotLastMember_407;
class Otherwise_450;
class CreateOnlyExprs_499;
class CreateFirstBinaryExprs_4c5;
class FirstBinaryExprs_4f2;
class GetLastBinaryExprs_505;
class GetNextBinaryExprs_512;
class HasExpr_53a;
class Otherwise_573;
class GetFirstBinaryExprs_5a8;
class CondHasExprs_5e9;
class HasExpr_611;
class Otherwise_64a;
class GetStructMembers_6a4;
class CreateTriggerCondition_6f1;
class AssignCondVal_734;
class IsTriggered_76c;
class HasTriggers_794;
class Otherwise_7cd;
class GetFunctions_80a;
class GetFunctions_811;
class CreateBlockExecution_82e;
class ChartChildBlock_84e;
class MakeTrigger_855;
class IsTriggered_862;
class HasTriggers_88a;
class Otherwise_8c3;
class CreateTriggering_8f8;
class AssignCondValLocalVar_905;
class GetTriggerPort_946;
class MakeTrigger_97f;
class AddTriggerVars_990;
class AddMatrixTriggerVars_9ad;
class EitherEdge_9c6;
class FallingEdge_a12;
class RisingEdge_a50;
class EdgeTest_a8e;
class RisingEdge_ad4;
class FallingEdge_b2a;
class EitherEdge_b80;
class StartAssignment_bd6;
class AddTriggerVar_c54;
class AddStructTriggerVars_ced;
class EitherEdge_cfa;
class FallingEdge_d56;
class RisingEdge_da4;
class EdgeTest_df2;
class RisingEdge_e47;
class FallingEdge_eae;
class EitherEdge_f15;
class AddTriggerVar_f7c;
class StartAssignment_fe6;
class SaveState_10be;
class SaveStructState_10d7;
class SaveStructState_10e2;
class SaveMatrixState_1137;
class SaveMatrixState_114c;
class AddStateVar_11aa;
class MakeCondition_1218;
class SetStructCondition_1229;
class StartCondition_1230;
class PlaceMember_1266;
class AddTrigger_128b;
class AddLastTrigger_1294;
class AddNextTrigger_12d0;
class TriggerTest_1318;
class HasBinaryExprs_134d;
class Otherwise_1396;
class TraverseBinary_13db;
class GetStructMembers_1437;
class SetMatrixCondition_1481;
class MatrixCondition_148e;
class CreateConditional_14bf;
class OutputEvent_155c;
class CreateOutputEventArgVal_1567;
class UpdateArgCount_15cc;
class InputEvent_1630;
class StructInputEvent_1645;
class UpdateArgCount_164c;
class StructInputEventArgVal_167d;
class MatrixInputEvent_16c7;
class MatrixInputEventArgVal_16d4;
class GetOldVar_1711;
class InputData_1758;
class UpdateArgCount_176d;
class CreateInputDataArgVal_17c1;
class OutputData_1836;
class CreateOutputDataArgVal_184b;
class CreateFunctionCall_18c0;
class GetState_190a;
class PrimitiveChildBlock_1983;
class SetupIfVar_1988;
class AssignIfVar_198d;
class GetIfAndSwitchCaseBlocks_19d0;
class Case_19e7;
class MakeIfVar_1a0e;
class GetIfOutputPorts_1a3d;
class CallCG_1a89;
class CreateCGCall_1aaa;
class GetInputs_1ab3;
class GetInputPorts_1ab6;
class GetSortedInPorts_1ab9;
class ListInPorts_1ad6;
class ProcessMerge_1afa;
class MergeAsSwitch_1aff;
class GetMergeBlocks_1b2e;
class MergeBlocksOnly_1b3a;
class ListOutPorts_1b58;
class MapParams_1b77;
class GetSortedOutPorts_1b8c;
class InitEBCall_1ba9;
class SubsystemChildBlock_1bdd;
class MakeTrigger_1be4;
class CreateAction_1bf1;
class CreateTriggering_1c31;
class MakeTrigger_1c3e;
class MakeCondition_1c4f;
class CreateConditional_1c60;
class SetMatrixCondition_1cc0;
class MatrixCondition_1ccd;
class SetStructCondition_1cfe;
class GetStructMembers_1d05;
class PlaceMember_1d42;
class TraverseBinary_1d67;
class TriggerTest_1db4;
class HasBinaryExprs_1de9;
class Otherwise_1e32;
class AddTrigger_1e77;
class AddNextTrigger_1e80;
class AddLastTrigger_1ebe;
class StartCondition_1f13;
class AddStateVar_1f64;
class SaveState_1fcf;
class SaveMatrixState_1fe8;
class SaveMatrixState_1ffd;
class SaveStructState_204f;
class SaveStructState_205a;
class AddTriggerVars_20bb;
class AddStructTriggerVars_20d8;
class StartAssignment_20e5;
class AddTriggerVar_2160;
class EdgeTest_21ca;
class RisingEdge_221f;
class FallingEdge_2286;
class EitherEdge_22ed;
class RisingEdge_2354;
class FallingEdge_23a2;
class EitherEdge_23f0;
class AddMatrixTriggerVars_2480;
class AddTriggerVar_2499;
class StartAssignment_2505;
class EdgeTest_256a;
class RisingEdge_25b0;
class FallingEdge_2606;
class EitherEdge_265c;
class RisingEdge_26b2;
class FallingEdge_26f0;
class EitherEdge_272e;
class GetTriggerPort_27d1;
class AssignCondVal_280a;
class IsTriggered_2859;
class HasTriggers_2887;
class HasActionPort_28c0;
class Otherwise_28f9;
class CreateFunctionCallArgs_293a;
class CreateMethodCall_2978;
class TestChildBlock_29cf;
class IsChart_29fd;
class IsSubsystem_2a3a;
class Otherwise_2a6f;
class AssignType_2ab3;
class AssignType_2ab8;
class SubsystemFilter_2ae0;
class SubsystemFilter_2ae7;
class IsStateChartInstance_2af9;
class IsStateChart_2b19;
class IsInstance_2b36;
class Otherwise_2b4c;
class GetSubSubsystems_2b63;
class GetSubSubsystems_2b68;
class TL_2b83;
class CheckPorts_2b88;
class CheckPortTypes_2b91;
class CheckAllPorts_2b9a;
class ChartFilter_2b9d;
class Block_2bab;
class IsSubsystem_2bc8;
class CheckPorts_2bdd;
class SetError_2be2;
class GetPorts_2bf5;
class CheckPort_2c12;
class PortHasType_2c2d;
class Otherwise_2c58;
class FilterInstances_2c84;
class NotAnInstanceTest_2c89;
class NotAnInstance_2c95;
class GetSubBlocks_2cad;
class CheckError_2cd2;
class CheckError_2ce9;
class NoError_2d04;
class NoErrorReported_2d2b;
class ReportError_2d52;
class FinishClasses_2d7b;
class AssignToOutArgs_2d84;
class IdenticalOutArgs_2d89;
class FinalizeContext_2dcb;
class GetCalleeObject_2dd0;
class AddMembers_2df7;
class AddContextMember_2e0a;
class ContextTest_2e2e;
class CallerStructHasMember_2e49;
class Otherwise_2e75;
class AddContextArgs_2ea8;
class GetContextArg_2eab;
class AddArgValExprs_2ecc;
class GetClasses_2f01;
class MakeClasses_2f26;
class GetBlocks_2f2f;
class GetRefSubsystemsFull_2f38;
class GetDataflowSubsystems_2f41;
class Test_2f6a;
class IsInstance_2f8d;
class RefSubsystem_2fb4;
class InstanceInRefSubsystem_2fdd;
class Otherwise_3004;
class Recurse_3029;
class GetSubSystems_305b;
class Test_3084;
class NoRefSubsystem_309f;
class RefSubsystem_30c6;
class CreateAllPrograms_30f4;
class CreateSigFlowsR_30f9;
class CreateTSB_30fc;
class CreatePreDelayExec_3103;
class ResetDelayBlockType_310c;
class GetDelayBlocks_3130;
class DoTopologicalSort_316a;
class GetSortedBlocks_318b;
class PassThroughs_31b8;
class PassThroughs_31c1;
class CreateProgramsTopLevel_3210;
class CreateProgramClass_3227;
class HasClassFilter_324f;
class SubsystemHasClass_326a;
class NoClass_3291;
class CreateFunctionLocalVars_32bc;
class CreateOutPortLVs_32c1;
class OutPortFilter_32ca;
class OutPortTest_32d7;
class OutPort2OutPort_32f2;
class Otherwise_331e;
class GetChildOutPorts_3346;
class CreateLocalVars_3373;
class BindToArg_3399;
class OutputArgTest_33ac;
class OutPortArg_33c7;
class Otherwise_33ee;
class BindToArg_3413;
class GetOutArgs_3440;
class CreateInPortLVs_346e;
class GetChildInPorts_3475;
class InPortFilter_34a2;
class InPortTest_34b3;
class InPort2InPort_34d2;
class OutPort2InPort_34fe;
class Otherwise_352a;
class CreateLocalVars_3552;
class GetInArgs_3580;
class GetLocalVars_359c;
class ZeroInitLocalVars_35b6;
class CreateClasses_35ef;
class CopyClass_35f6;
class CopyClass_35ff;
class SubsystemFilter_362e;
class IsInstance_3651;
class HasClass_3678;
class IsStateChart_369f;
class Otherwise_36cc;
class CreateClass_36f1;
class CreateChartClass_3714;
class GetSubSubsystems_3733;
class CreateFunctionsAndArgs_376b;
class CreateFunctions_3770;
class MakeArguments_3791;
class Outputs_3798;
class MainArgCount_37a1;
class CreateOutputPortArgs_37d4;
class Inputs_380c;
class UpdateArgCount_3815;
class CreateInputPortArgs_3848;
class Trigs_3880;
class CreateTriggerPortArgs_3889;
class ZeroUnconOutputs_38b9;
class OutPortConnected_38c0;
class Connected_38db;
class Otherwise_3906;
class GetOutputPorts_392b;
class ZeroOutPort_3954;
class Actions_397e;
class CreateTriggerPortArgs_3987;
class CreateChartFunction_39c6;
class MakeChartArguments_39f2;
class DataInput_39f7;
class UpdateArgCount_3a00;
class DataInput_3a20;
class EventInput_3a5e;
class EventInput_3a67;
class DataOutput_3aa5;
class DataOutput_3aae;
class EventOutput_3aec;
class EventOutput_3af1;
class Constructors_3b5c;
class MakeAllConstructors_3b65;
class MakeConstructors_3b68;
class InitSubSubsystem_3b6d;
class CreateInitFunction_3b9e;
class InitParameters_3bc3;
class InitDirectParameters_3bce;
class InitDirectParameter_3bdb;
class InitTriggerVars_3c13;
class InitMatrixTrigger_3c1a;
class InitMatrixTrigger_3c27;
class InitStructTrigger_3c74;
class InitStructTrigger_3c7b;
class InitPrimitiveParameters_3cd0;
class InitPrimitiveParameter_3cdd;
class Test_3d13;
class MemberHasParameter_3d41;
class StructMember_3d83;
class MemberNoParameter_3dbb;
class GetStructMembers_3df0;
class ZeroPrimitiveParameter_3e29;
class InitPrimPseudoParams_3e62;
class InitPrimPseudoParam_3e6f;
class MakeChartConstructor_3ec7;
class CreateInitFunction_3eca;
class MergeClasses_3efc;
class ElimRedundantClasses_3f05;
class DeleteClass_3f0a;
class RedundancyTest_3f1b;
class NegStatementCount_3f27;
class GetClasses_3f3d;
class MergeClasses_3f60;
class OneClassAtATime_3f65;
class ClassFilter_3f6f;
class SimpleStructFilter_3f74;
class Marked_3f86;
class ComplexStruct1_3f9c;
class ComplexStruct2_3fc3;
class SimpleStruct_3fea;
class GetNextLevelClasses_4001;
class MergeClasses_4024;
class TestEquivalence_4029;
class CheckMethods_4035;
class TestArgs_403a;
class ArgsMatch_4062;
class NoArgMatch_40ab;
class BreakEquivalence_40e3;
class GetMainFunctionArgs_410f;
class TestDataMembers_4146;
class GetMembers_414b;
class TestMembers_4174;
class ParameterMemberMatch_41a2;
class StructMemberMatch_41f5;
class NoMemberMatch_424a;
class BreakEquivalence_4282;
class ElimEquiv_42bc;
class DeleteClass_42c6;
class NoEquivSrc_42c9;
class NoEquivDst_42de;
class MarkClass_42f5;
class TransferMethodCalls_430e;
class TransferMethodCalls_4317;
class TransferMethodCallArgs_431c;
class TransferMethodCallArgs_4325;
class TransferMethodCallTarget_435e;
class GetMethods_4385;
class TransferStruct_43bc;
class TransferStructMembers_43c3;
class TransferParameterMembers_43cc;
class TransferArgDeclRef_43d5;
class TransferParameterMember_43f6;
class TransferStructMembers_4441;
class TransferStructMember_444a;
class TransferTriggerMembers_449b;
class TransferTriggerMember_44a4;
class TransferStruct_44f8;
class TransferSubsystems_4527;
class TransferSubsystem_4530;
class GetEquivalence_4554;
class GetClasses_458a;
class MakeEquivalence_45a7;
class CreateTypes_45de;
class GetTypes_45e7;
class GetTypes_45f0;
class GetContainer_4620;
class NextContainer_464b;
class FindTopContainer_4673;
class ChildOfComponent_468e;
class Otherwise_46b6;
class RegisterStruct_46e7;
class StructMembers_46f8;
class CreateStructMembers_46ff;
class CreateTypesInner_4728;
class CreateArrayOrBasicType_473f;
class RegisterType_4744;
class MakeAssoc_4765;
class ProcessOther_4782;
class ProcessRowVector_478d;
class ProcessArray2_4798;
class GetArray2_47a5;
class Array2Exists_47cd;
class Otherwise_480c;
class UseArray2_4841;
class CreateArray2_4880;
class ProcessScalar_48c2;
class CreateBasicType_48cd;
class UseBasicType_48f7;
class GetBasicType_4927;
class BasicTypeExists_4942;
class Otherwise_496e;
class ProcessArray1_49a3;
class CreateArray1_49b0;
class UseArray1_49e6;
class GetArray1_4a24;
class Array1Exists_4a4c;
class Otherwise_4a8a;
class ProcessColumn_4ad2;
class DimensionTest_4ae4;
class Scalar_4b03;
class ColumnVector_4b2a;
class Other_4b51;
class StructOrMatrix_4b88;
class IsStruct_4ba3;
class IsMatrix_4bc8;
class CreateStructType_4bed;
class HasRefSubsystems_4c27;
class ResetHasRefSubsystems_4c30;
class SetHasRefSubsystems_4c43;
class GetProject_4c5a;

// Class declarations.
class GetSubsystems_0
{
public:
	void operator()( const Packets_t& dataflows_1, Packets_t& subsystems_3);

protected:
	void callTest_d0( const Packets_t& dataflows_1f);
	void callGetSubSystems_d2( const Packets_t& dataflows_6);
	void callGetRefSubsystems_d4( const Packets_t& dataflows_58);

private:
	Packets_t* _subsystem_4;
};

class GetSubSystems_5
{
public:
	void operator()( const Packets_t& dataflows_6, Packets_t& subsystems_8);

protected:
	bool isInputUnique( const Udm::Object& dataflow_e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_6);
	bool patternMatcher( const Udm::Object& dataflow_c);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1c);

private:
	Packets_t* _subsystem_9;
	Packets_t _dataflow_a;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_1a;
		ESMoL::Subsystem subsystem_1b;
	};

	std::list< Match> _matches;
};

class Test_1e
{
public:
	void operator()( const Packets_t& dataflows_1f, Packets_t& dataflows_21, Packets_t& dataflows_22);

protected:
	void executeOne( const Packets_t& dataflows_1f);
	bool isInputUnique( const Udm::Object& dataflow_27);

private:
	Packets_t* _dataflow_23;
	Packets_t* _dataflow_24;
	Packets_t _dataflow_25;
};

class NoRefSubsystem_2c
{
public:
	bool operator()( const Packets_t& dataflows_2d, Packets_t& dataflows_2f);

protected:
	bool isInputUnique( const Udm::Object& dataflow_35);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Dataflow& Dataflow);
	void processInputPackets( const Packets_t& dataflows_2d);
	bool patternMatcher( const Udm::Object& dataflow_33);
	void outputAppender( const ESMoL::Dataflow& dataflow_40);

private:
	Packets_t* _dataflow_30;
	Packets_t _dataflow_31;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_3e;
	};

	std::list< Match> _matches;
};

class RefSubsystem_42
{
public:
	bool operator()( const Packets_t& dataflows_43, Packets_t& dataflows_45);

protected:
	bool isInputUnique( const Udm::Object& dataflow_4b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_43);
	bool patternMatcher( const Udm::Object& dataflow_49);
	void outputAppender( const ESMoL::Dataflow& dataflow_55);

private:
	Packets_t* _dataflow_46;
	Packets_t _dataflow_47;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_54;
	};

	std::list< Match> _matches;
};

class GetRefSubsystems_57
{
public:
	void operator()( const Packets_t& dataflows_58, Packets_t& subsystems_5a);

protected:
	void callGetDataflowSubsystems_ca( const Packets_t& dataflows_5d);
	void callTest_cc( const Packets_t& subsystems_76);
	void callRecurse_ce( const Packets_t& subsystems_b3);

private:
	Packets_t* _subsystem_5b;
};

class GetDataflowSubsystems_5c
{
public:
	void operator()( const Packets_t& dataflows_5d, Packets_t& subsystems_5f);

protected:
	bool isInputUnique( const Udm::Object& dataflow_65);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_5d);
	bool patternMatcher( const Udm::Object& dataflow_63);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_73);

private:
	Packets_t* _subsystem_60;
	Packets_t _dataflow_61;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_71;
		ESMoL::Subsystem subsystem_72;
	};

	std::list< Match> _matches;
};

class Test_75
{
public:
	void operator()( const Packets_t& subsystems_76, Packets_t& subsystems_78, Packets_t& subsystems_79);

protected:
	void executeOne( const Packets_t& subsystems_76);
	bool isInputUnique( const Udm::Object& subsystem_7e);

private:
	Packets_t* _subsystem_7a;
	Packets_t* _subsystem_7b;
	Packets_t _subsystem_7c;
};

class RefSubsystem_83
{
public:
	bool operator()( const Packets_t& subsystems_84, Packets_t& subsystems_86);

protected:
	bool isInputUnique( const Udm::Object& subsystem_8c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_84);
	bool patternMatcher( const Udm::Object& subsystem_8a);
	void outputAppender( const ESMoL::Subsystem& subsystem_9a);

private:
	Packets_t* _subsystem_87;
	Packets_t _subsystem_88;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_98;
		ESMoL::SubsystemRef subsystemRef_99;
	};

	std::list< Match> _matches;
};

class NoRefSubsystem_9c
{
public:
	bool operator()( const Packets_t& subsystems_9d, Packets_t& subsystems_9f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_a5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_9d);
	bool patternMatcher( const Udm::Object& subsystem_a3);
	void outputAppender( const ESMoL::Subsystem& subsystem_af);

private:
	Packets_t* _subsystem_a0;
	Packets_t _subsystem_a1;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_ae;
	};

	std::list< Match> _matches;
};

class Recurse_b1
{
public:
	void operator()( const Packets_t& subsystems_b3, Packets_t& subsystems_b2);

protected:
	bool isInputUnique( const Udm::Object& subsystem_ba);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_b3);
	bool patternMatcher( const Udm::Object& subsystem_b8);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_c8);

private:
	Packets_t* _subsystem_b5;
	Packets_t _subsystem_b6;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_c6;
		ESMoL::Subsystem subsystem_c7;
	};

	std::list< Match> _matches;
};

class MakeArgDeclRef_d6
{
public:
	void operator()( const Packets_t& systems_d7, const Packets_t& argPorts_d9, const Packets_t& argVals_db);

protected:
	void callCheckSigSrc_1c7( const Packets_t& systems_10a, const Packets_t& argPorts_10c, const Packets_t& argVals_10e);
	void callInpArgValTrigger_1cb( const Packets_t& subsystems_19c, const Packets_t& triggerPorts_19e, const Packets_t& argVals_1a0);
	void callInpArgVal_1cf( const Packets_t& subsystems_de, const Packets_t& dstPorts_e0, const Packets_t& argVals_e2);
};

class InpArgVal_dd
{
public:
	void operator()( const Packets_t& subsystems_de, const Packets_t& dstPorts_e0, const Packets_t& argVals_e2);

protected:
	bool isInputUnique( const Udm::Object& subsystem_e8, const Udm::Object& dstPort_f1, const Udm::Object& argVal_fa);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_de, const Packets_t& dstPorts_e0, const Packets_t& argVals_e2);
	bool patternMatcher( const Udm::Object& subsystem_e6, const Udm::Object& dstPort_ef, const Udm::Object& argVal_f8);
	void effector();

private:
	Packets_t _subsystem_e4;
	Packets_t _dstPort_ed;
	Packets_t _argVal_f6;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_104;
		ESMoL::Port dstPort_105;
		SFC::ArgVal argVal_106;
		SFC::ArgDeclBase argDeclBase_107;
	};

	std::list< Match> _matches;
};

class CheckSigSrc_109
{
public:
	void operator()( const Packets_t& systems_10a, const Packets_t& argPorts_10c, const Packets_t& argVals_10e, Packets_t& systems_110, Packets_t& argPorts_111, Packets_t& argVals_112, Packets_t& systems_113, Packets_t& argPorts_114, Packets_t& argVals_115);

protected:
	void executeOne( const Packets_t& systems_10a, const Packets_t& argPorts_10c, const Packets_t& argVals_10e);
	bool isInputUnique( const Udm::Object& system_11e, const Udm::Object& argPort_125, const Udm::Object& argVal_12c);

private:
	Packets_t* _system_116;
	Packets_t* _argPort_117;
	Packets_t* _argVal_118;
	Packets_t* _system_119;
	Packets_t* _argPort_11a;
	Packets_t* _argVal_11b;
	Packets_t _system_11c;
	Packets_t _argPort_123;
	Packets_t _argVal_12a;
};

class IsTrigger_131
{
public:
	bool operator()( const Packets_t& subsystems_132, const Packets_t& triggerPorts_135, const Packets_t& argVals_138, Packets_t& subsystems_134, Packets_t& triggerPorts_137, Packets_t& argVals_13a);

protected:
	bool isInputUnique( const Udm::Object& subsystem_142, const Udm::Object& triggerPort_14b, const Udm::Object& argVal_154);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_132, const Packets_t& triggerPorts_135, const Packets_t& argVals_138);
	bool patternMatcher( const Udm::Object& subsystem_140, const Udm::Object& triggerPort_149, const Udm::Object& argVal_152);
	void outputAppender( const ESMoL::Subsystem& subsystem_160, const ESMoL::TriggerPort& triggerPort_162, const SFC::ArgVal& argVal_164);

private:
	Packets_t* _subsystem_13b;
	Packets_t* _triggerPort_13c;
	Packets_t* _argVal_13d;
	Packets_t _subsystem_13e;
	Packets_t _triggerPort_147;
	Packets_t _argVal_150;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_15d;
		ESMoL::TriggerPort triggerPort_15e;
		SFC::ArgVal argVal_15f;
	};

	std::list< Match> _matches;
};

class Otherwise_166
{
public:
	bool operator()( const Packets_t& subsystems_167, const Packets_t& dstPorts_16a, const Packets_t& argVals_16d, Packets_t& subsystems_169, Packets_t& dstPorts_16c, Packets_t& argVals_16f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_177, const Udm::Object& dstPort_180, const Udm::Object& argVal_189);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_167, const Packets_t& dstPorts_16a, const Packets_t& argVals_16d);
	bool patternMatcher( const Udm::Object& subsystem_175, const Udm::Object& dstPort_17e, const Udm::Object& argVal_187);
	void outputAppender( const ESMoL::Subsystem& subsystem_195, const ESMoL::Port& dstPort_197, const SFC::ArgVal& argVal_199);

private:
	Packets_t* _subsystem_170;
	Packets_t* _dstPort_171;
	Packets_t* _argVal_172;
	Packets_t _subsystem_173;
	Packets_t _dstPort_17c;
	Packets_t _argVal_185;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_192;
		ESMoL::Port dstPort_193;
		SFC::ArgVal argVal_194;
	};

	std::list< Match> _matches;
};

class InpArgValTrigger_19b
{
public:
	void operator()( const Packets_t& subsystems_19c, const Packets_t& triggerPorts_19e, const Packets_t& argVals_1a0);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1a6, const Udm::Object& triggerPort_1af, const Udm::Object& argVal_1b8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_19c, const Packets_t& triggerPorts_19e, const Packets_t& argVals_1a0);
	bool patternMatcher( const Udm::Object& subsystem_1a4, const Udm::Object& triggerPort_1ad, const Udm::Object& argVal_1b6);
	void effector();

private:
	Packets_t _subsystem_1a2;
	Packets_t _triggerPort_1ab;
	Packets_t _argVal_1b4;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1c2;
		ESMoL::TriggerPort triggerPort_1c3;
		SFC::ArgVal argVal_1c4;
		SFC::LocalVar localVar_1c5;
	};

	std::list< Match> _matches;
};

class GetAllMethodCalls_1d3
{
public:
	void operator()( const Packets_t& classs_1d4, Packets_t& methodcalls_1d6, Packets_t& contextargs_1d7, Packets_t& callerstructs_1d8);

protected:
	void callGetClassFunctions_279( const Packets_t& callerClasss_1de);
	void callGetMethodCalls_27b( const Packets_t& compoundStatements_242, const Packets_t& contextargs_244, const Packets_t& callerStructs_247);
	void callGetSubCompounds_27f( const Packets_t& compoundStatements_208, const Packets_t& args_20b, const Packets_t& callerStructs_20e);

private:
	Packets_t* _methodcall_1d9;
	Packets_t* _contextarg_1da;
	Packets_t* _callerstruct_1db;
};

class GetClassFunctions_1dc
{
public:
	void operator()( const Packets_t& callerClasss_1de, Packets_t& callerMethods_1dd, Packets_t& args_1e0, Packets_t& callerStructs_1e1);

protected:
	bool isInputUnique( const Udm::Object& callerClass_1e9);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& callerClasss_1de);
	bool patternMatcher( const Udm::Object& callerClass_1e7);
	void effector();
	void outputAppender( const SFC::Function& callerMethod_201, const SFC::Arg& arg_203, const SFC::Struct& callerStruct_205);

private:
	Packets_t* _callerMethod_1e2;
	Packets_t* _arg_1e3;
	Packets_t* _callerStruct_1e4;
	Packets_t _callerClass_1e5;
	class Match
	{
	public:
		SFC::Class callerClass_1fd;
		SFC::Function callerMethod_1fe;
		SFC::Arg arg_1ff;
		SFC::Struct callerStruct_200;
	};

	std::list< Match> _matches;
};

class GetSubCompounds_207
{
public:
	void operator()( const Packets_t& compoundStatements_208, const Packets_t& args_20b, const Packets_t& callerStructs_20e, Packets_t& subCompounds_20a, Packets_t& args_20d, Packets_t& callerStructs_210);

protected:
	bool isInputUnique( const Udm::Object& compoundStatement_218, const Udm::Object& arg_221, const Udm::Object& callerStruct_22a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& compoundStatements_208, const Packets_t& args_20b, const Packets_t& callerStructs_20e);
	bool patternMatcher( const Udm::Object& compoundStatement_216, const Udm::Object& arg_21f, const Udm::Object& callerStruct_228);
	void effector();
	void outputAppender( const SFC::CompoundStatement& subCompound_23a, const SFC::Arg& arg_23c, const SFC::Struct& callerStruct_23e);

private:
	Packets_t* _subCompound_211;
	Packets_t* _arg_212;
	Packets_t* _callerStruct_213;
	Packets_t _compoundStatement_214;
	Packets_t _arg_21d;
	Packets_t _callerStruct_226;
	class Match
	{
	public:
		SFC::CompoundStatement compoundStatement_236;
		SFC::Arg arg_237;
		SFC::Struct callerStruct_238;
		SFC::CompoundStatement subCompound_239;
	};

	std::list< Match> _matches;
};

class GetMethodCalls_240
{
public:
	void operator()( const Packets_t& compoundStatements_242, const Packets_t& contextargs_244, const Packets_t& callerStructs_247, Packets_t& methodCalls_241, Packets_t& contextargs_246, Packets_t& callerStructs_249);

protected:
	bool isInputUnique( const Udm::Object& compoundStatement_251, const Udm::Object& contextarg_25a, const Udm::Object& callerStruct_263);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& compoundStatements_242, const Packets_t& contextargs_244, const Packets_t& callerStructs_247);
	bool patternMatcher( const Udm::Object& compoundStatement_24f, const Udm::Object& contextarg_258, const Udm::Object& callerStruct_261);
	void effector();
	void outputAppender( const SFC::FunctionCall& methodCall_273, const SFC::Arg& contextarg_275, const SFC::Struct& callerStruct_277);

private:
	Packets_t* _methodCall_24a;
	Packets_t* _contextarg_24b;
	Packets_t* _callerStruct_24c;
	Packets_t _compoundStatement_24d;
	Packets_t _contextarg_256;
	Packets_t _callerStruct_25f;
	class Match
	{
	public:
		SFC::CompoundStatement compoundStatement_26f;
		SFC::Arg contextarg_270;
		SFC::Struct callerStruct_271;
		SFC::FunctionCall methodCall_272;
	};

	std::list< Match> _matches;
};

class MakeTrigger_283
{
public:
	void operator()( const Packets_t& systems_284, const Packets_t& childSubsystems_286, const Packets_t& systemFunctions_288, Packets_t& systems_28a, Packets_t& childSubsystems_28b, Packets_t& compoundStatements_28c);

protected:
	void callIsTriggered_802( const Packets_t& systems_76d, const Packets_t& childSubsystems_76f, const Packets_t& systemFunctions_771);
	void callCreateTriggering_806( const Packets_t& systems_291, const Packets_t& childSubsystems_293, const Packets_t& systemFunctions_295);

private:
	Packets_t* _system_28d;
	Packets_t* _childSubsystem_28e;
	Packets_t* _compoundStatement_28f;
};

class CreateTriggering_290
{
public:
	void operator()( const Packets_t& systems_291, const Packets_t& childSubsystems_293, const Packets_t& systemFunctions_295, Packets_t& systems_297, Packets_t& childSubsystems_298, Packets_t& conditionalBlocks_299);

protected:
	void callCreateTriggerCondition_761( const Packets_t& subsystems_6f2, const Packets_t& blocks_6f5, const Packets_t& mains_6f9);
	void callAssignCondVal_765( const Packets_t& triggerPorts_735, const Packets_t& conditions_739);
	void callcreateTriggerOr_768( const Packets_t& argdecls_29e, const Packets_t& dts_2a0, const Packets_t& conditions_2a2);

private:
	Packets_t* _system_29a;
	Packets_t* _childSubsystem_29b;
	Packets_t* _conditionalBlock_29c;
};

class CreateTriggerOr_29d
{
public:
	void operator()( const Packets_t& argdecls_29e, const Packets_t& dts_2a0, const Packets_t& conditions_2a2);

protected:
	void callStructTest_6e1( const Packets_t& argdecls_2c3, const Packets_t& dts_2c5, const Packets_t& conditions_2c7);
	void callargDeclIsCondition_6e5( const Packets_t& argDeclBases_2a5, const Packets_t& conditions_2a7);
	void callgetStructMembers_6e8( const Packets_t& argDeclBases_6a5, const Packets_t& structs_6a8, const Packets_t& userCodes_6ac);
	void callPlaceMember_6ec( const Packets_t& argdecls_355, const Packets_t& structs_357, const Packets_t& membs_359, const Packets_t& conditions_35b);
};

class ArgDeclIsCondition_2a4
{
public:
	void operator()( const Packets_t& argDeclBases_2a5, const Packets_t& conditions_2a7);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_2ad, const Udm::Object& condition_2b6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_2a5, const Packets_t& conditions_2a7);
	bool patternMatcher( const Udm::Object& argDeclBase_2ab, const Udm::Object& condition_2b4);
	void effector();

private:
	Packets_t _argDeclBase_2a9;
	Packets_t _condition_2b2;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2bf;
		SFC::UserCode condition_2c0;
	};

	std::list< Match> _matches;
};

class StructTest_2c2
{
public:
	void operator()( const Packets_t& argdecls_2c3, const Packets_t& dts_2c5, const Packets_t& conditions_2c7, Packets_t& argdecls_2c9, Packets_t& structs_2ca, Packets_t& conditions_2cb, Packets_t& argdecls_2cc, Packets_t& dts_2cd, Packets_t& conditions_2ce);

protected:
	void executeOne( const Packets_t& argdecls_2c3, const Packets_t& dts_2c5, const Packets_t& conditions_2c7);
	bool isInputUnique( const Udm::Object& argdecl_2d7, const Udm::Object& dt_2de, const Udm::Object& condition_2e5);

private:
	Packets_t* _argdecl_2cf;
	Packets_t* _struct_2d0;
	Packets_t* _condition_2d1;
	Packets_t* _argdecl_2d2;
	Packets_t* _dt_2d3;
	Packets_t* _condition_2d4;
	Packets_t _argdecl_2d5;
	Packets_t _dt_2dc;
	Packets_t _condition_2e3;
};

class IsStruct_2ea
{
public:
	bool operator()( const Packets_t& argVarBases_2eb, const Packets_t& structs_2ee, const Packets_t& conditions_2f1, Packets_t& argVarBases_2ed, Packets_t& structs_2f0, Packets_t& conditions_2f3);

protected:
	bool isInputUnique( const Udm::Object& argVarBase_2fb, const Udm::Object& struct_304, const Udm::Object& condition_30d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argVarBases_2eb, const Packets_t& structs_2ee, const Packets_t& conditions_2f1);
	bool patternMatcher( const Udm::Object& argVarBase_2f9, const Udm::Object& struct_302, const Udm::Object& condition_30b);
	void outputAppender( const SFC::ArgDeclBase& argVarBase_319, const SFC::Struct& struct_31b, const SFC::UserCode& condition_31d);

private:
	Packets_t* _argVarBase_2f4;
	Packets_t* _struct_2f5;
	Packets_t* _condition_2f6;
	Packets_t _argVarBase_2f7;
	Packets_t _struct_300;
	Packets_t _condition_309;
	class Match
	{
	public:
		SFC::ArgDeclBase argVarBase_316;
		SFC::Struct struct_317;
		SFC::UserCode condition_318;
	};

	std::list< Match> _matches;
};

class Otherwise_31f
{
public:
	bool operator()( const Packets_t& argVarBases_320, const Packets_t& dTs_323, const Packets_t& conditions_326, Packets_t& argVarBases_322, Packets_t& dTs_325, Packets_t& conditions_328);

protected:
	bool isInputUnique( const Udm::Object& argVarBase_330, const Udm::Object& dT_339, const Udm::Object& condition_342);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argVarBases_320, const Packets_t& dTs_323, const Packets_t& conditions_326);
	bool patternMatcher( const Udm::Object& argVarBase_32e, const Udm::Object& dT_337, const Udm::Object& condition_340);
	void outputAppender( const SFC::ArgDeclBase& argVarBase_34e, const SFC::DT& dT_350, const SFC::UserCode& condition_352);

private:
	Packets_t* _argVarBase_329;
	Packets_t* _dT_32a;
	Packets_t* _condition_32b;
	Packets_t _argVarBase_32c;
	Packets_t _dT_335;
	Packets_t _condition_33e;
	class Match
	{
	public:
		SFC::ArgDeclBase argVarBase_34b;
		SFC::DT dT_34c;
		SFC::UserCode condition_34d;
	};

	std::list< Match> _matches;
};

class PlaceMember_354
{
public:
	void operator()( const Packets_t& argdecls_355, const Packets_t& structs_357, const Packets_t& membs_359, const Packets_t& conditions_35b);

protected:
	void executeOne( const Packets_t& argdecls_355, const Packets_t& structs_357, const Packets_t& membs_359, const Packets_t& conditions_35b);
	bool isInputUnique( const Udm::Object& argdecl_35f, const Udm::Object& struct_366, const Udm::Object& memb_36d, const Udm::Object& condition_374);
	void calltestMemberPos_687( const Packets_t& argdecls_3d3, const Packets_t& structs_3d5, const Packets_t& membs_3d7, const Packets_t& conditions_3d9);
	void callfirstBinaryExprs_68c( const Packets_t& argdecls_4f3, const Packets_t& membs_4f5, const Packets_t& conditions_4f7);
	void callfirstBinaryExprs_690( const Packets_t& argdecls_4f3, const Packets_t& membs_4f5, const Packets_t& conditions_4f7);
	void callcreateFirstBinaryExprs_694( const Packets_t& argDeclBases_4c6, const Packets_t& localVars_4c8, const Packets_t& userCodes_4ca);
	void callCreateNextBinaryExprs_698( const Packets_t& argDeclBases_3a6, const Packets_t& localVars_3a8, const Packets_t& binaryExprss_3aa);
	void callCreateLastBinaryExprs_69c( const Packets_t& argDeclBases_37a, const Packets_t& localVars_37c, const Packets_t& binaryExprss_37e);
	void callcreateOnlyExprs_6a0( const Packets_t& argDeclBases_49a, const Packets_t& localVars_49c, const Packets_t& userCodes_49e);

private:
	Packets_t _argdecl_35d;
	Packets_t _struct_364;
	Packets_t _memb_36b;
	Packets_t _condition_372;
};

class CreateLastBinaryExprs_379
{
public:
	void operator()( const Packets_t& argDeclBases_37a, const Packets_t& localVars_37c, const Packets_t& binaryExprss_37e);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_384, const Udm::Object& localVar_38d, const Udm::Object& binaryExprs_396);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_37a, const Packets_t& localVars_37c, const Packets_t& binaryExprss_37e);
	bool patternMatcher( const Udm::Object& argDeclBase_382, const Udm::Object& localVar_38b, const Udm::Object& binaryExprs_394);
	void effector();

private:
	Packets_t _argDeclBase_380;
	Packets_t _localVar_389;
	Packets_t _binaryExprs_392;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_39f;
		SFC::LocalVar localVar_3a0;
		SFC::BinaryExprs binaryExprs_3a1;
	};

	std::list< Match> _matches;
};

class CreateNextBinaryExprs_3a5
{
public:
	void operator()( const Packets_t& argDeclBases_3a6, const Packets_t& localVars_3a8, const Packets_t& binaryExprss_3aa);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_3b0, const Udm::Object& localVar_3b9, const Udm::Object& binaryExprs_3c2);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_3a6, const Packets_t& localVars_3a8, const Packets_t& binaryExprss_3aa);
	bool patternMatcher( const Udm::Object& argDeclBase_3ae, const Udm::Object& localVar_3b7, const Udm::Object& binaryExprs_3c0);
	void effector();

private:
	Packets_t _argDeclBase_3ac;
	Packets_t _localVar_3b5;
	Packets_t _binaryExprs_3be;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_3cb;
		SFC::LocalVar localVar_3cc;
		SFC::BinaryExprs binaryExprs_3cd;
	};

	std::list< Match> _matches;
};

class TestMemberPos_3d2
{
public:
	void operator()( const Packets_t& argdecls_3d3, const Packets_t& structs_3d5, const Packets_t& membs_3d7, const Packets_t& conditions_3d9, Packets_t& argdecls_3db, Packets_t& structs_3dc, Packets_t& membs_3dd, Packets_t& conditions_3de, Packets_t& argdecls_3df, Packets_t& structs_3e0, Packets_t& membs_3e1, Packets_t& conditions_3e2);

protected:
	void executeOne( const Packets_t& argdecls_3d3, const Packets_t& structs_3d5, const Packets_t& membs_3d7, const Packets_t& conditions_3d9);
	bool isInputUnique( const Udm::Object& argdecl_3ed, const Udm::Object& struct_3f4, const Udm::Object& memb_3fb, const Udm::Object& condition_402);

private:
	Packets_t* _argdecl_3e3;
	Packets_t* _struct_3e4;
	Packets_t* _memb_3e5;
	Packets_t* _condition_3e6;
	Packets_t* _argdecl_3e7;
	Packets_t* _struct_3e8;
	Packets_t* _memb_3e9;
	Packets_t* _condition_3ea;
	Packets_t _argdecl_3eb;
	Packets_t _struct_3f2;
	Packets_t _memb_3f9;
	Packets_t _condition_400;
};

class NotLastMember_407
{
public:
	bool operator()( const Packets_t& argDeclBases_408, const Packets_t& structs_40b, const Packets_t& localVars_40e, const Packets_t& userCodes_411, Packets_t& argDeclBases_40a, Packets_t& structs_40d, Packets_t& localVars_410, Packets_t& userCodes_413);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_41c, const Udm::Object& struct_425, const Udm::Object& localVar_42e, const Udm::Object& userCode_437);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::LocalVar& LocalVar, SFC::Struct& Struct, SFC::UserCode& UserCode);
	void processInputPackets( const Packets_t& argDeclBases_408, const Packets_t& structs_40b, const Packets_t& localVars_40e, const Packets_t& userCodes_411);
	bool patternMatcher( const Udm::Object& argDeclBase_41a, const Udm::Object& struct_423, const Udm::Object& localVar_42c, const Udm::Object& userCode_435);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_448, const SFC::Struct& struct_44a, const SFC::LocalVar& localVar_44c, const SFC::UserCode& userCode_44e);

private:
	Packets_t* _argDeclBase_414;
	Packets_t* _struct_415;
	Packets_t* _localVar_416;
	Packets_t* _userCode_417;
	Packets_t _argDeclBase_418;
	Packets_t _struct_421;
	Packets_t _localVar_42a;
	Packets_t _userCode_433;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_440;
		SFC::Struct struct_441;
		SFC::LocalVar localVar_442;
		SFC::UserCode userCode_443;
	};

	std::list< Match> _matches;
};

class Otherwise_450
{
public:
	bool operator()( const Packets_t& argDeclBases_451, const Packets_t& structs_454, const Packets_t& localVars_457, const Packets_t& userCodes_45a, Packets_t& argDeclBases_453, Packets_t& structs_456, Packets_t& localVars_459, Packets_t& userCodes_45c);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_465, const Udm::Object& struct_46e, const Udm::Object& localVar_477, const Udm::Object& userCode_480);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::LocalVar& LocalVar, SFC::Struct& Struct, SFC::UserCode& UserCode);
	void processInputPackets( const Packets_t& argDeclBases_451, const Packets_t& structs_454, const Packets_t& localVars_457, const Packets_t& userCodes_45a);
	bool patternMatcher( const Udm::Object& argDeclBase_463, const Udm::Object& struct_46c, const Udm::Object& localVar_475, const Udm::Object& userCode_47e);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_491, const SFC::Struct& struct_493, const SFC::LocalVar& localVar_495, const SFC::UserCode& userCode_497);

private:
	Packets_t* _argDeclBase_45d;
	Packets_t* _struct_45e;
	Packets_t* _localVar_45f;
	Packets_t* _userCode_460;
	Packets_t _argDeclBase_461;
	Packets_t _struct_46a;
	Packets_t _localVar_473;
	Packets_t _userCode_47c;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_489;
		SFC::Struct struct_48a;
		SFC::LocalVar localVar_48b;
		SFC::UserCode userCode_48c;
	};

	std::list< Match> _matches;
};

class CreateOnlyExprs_499
{
public:
	void operator()( const Packets_t& argDeclBases_49a, const Packets_t& localVars_49c, const Packets_t& userCodes_49e);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_4a4, const Udm::Object& localVar_4ad, const Udm::Object& userCode_4b6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_49a, const Packets_t& localVars_49c, const Packets_t& userCodes_49e);
	bool patternMatcher( const Udm::Object& argDeclBase_4a2, const Udm::Object& localVar_4ab, const Udm::Object& userCode_4b4);
	void effector();

private:
	Packets_t _argDeclBase_4a0;
	Packets_t _localVar_4a9;
	Packets_t _userCode_4b2;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_4bf;
		SFC::LocalVar localVar_4c0;
		SFC::UserCode userCode_4c1;
	};

	std::list< Match> _matches;
};

class CreateFirstBinaryExprs_4c5
{
public:
	void operator()( const Packets_t& argDeclBases_4c6, const Packets_t& localVars_4c8, const Packets_t& userCodes_4ca);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_4d0, const Udm::Object& localVar_4d9, const Udm::Object& userCode_4e2);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_4c6, const Packets_t& localVars_4c8, const Packets_t& userCodes_4ca);
	bool patternMatcher( const Udm::Object& argDeclBase_4ce, const Udm::Object& localVar_4d7, const Udm::Object& userCode_4e0);
	void effector();

private:
	Packets_t _argDeclBase_4cc;
	Packets_t _localVar_4d5;
	Packets_t _userCode_4de;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_4eb;
		SFC::LocalVar localVar_4ec;
		SFC::UserCode userCode_4ed;
	};

	std::list< Match> _matches;
};

class FirstBinaryExprs_4f2
{
public:
	void operator()( const Packets_t& argdecls_4f3, const Packets_t& membs_4f5, const Packets_t& conditions_4f7, Packets_t& argdecls_4f9, Packets_t& membs_4fa, Packets_t& binaryexprss_4fb, Packets_t& argdecls_4fc, Packets_t& membs_4fd, Packets_t& conditions_4fe);

protected:
	void callCondHasExprs_67f( const Packets_t& argdecls_5ea, const Packets_t& membs_5ec, const Packets_t& conditions_5ee);
	void callgetLastBinaryExprs_683( const Packets_t& argdecls_506, const Packets_t& membs_508, const Packets_t& conditions_50a);

private:
	Packets_t* _argdecl_4ff;
	Packets_t* _memb_500;
	Packets_t* _binaryexprs_501;
	Packets_t* _argdecl_502;
	Packets_t* _memb_503;
	Packets_t* _condition_504;
};

class GetLastBinaryExprs_505
{
public:
	void operator()( const Packets_t& argdecls_506, const Packets_t& membs_508, const Packets_t& conditions_50a, Packets_t& argdecls_50c, Packets_t& membs_50d, Packets_t& binaryexprss_50e);

protected:
	void callgetFirstBinaryExprs_5e1( const Packets_t& argDeclBases_5a9, const Packets_t& localVars_5ac, const Packets_t& userCodes_5af);
	void callgetNextBinaryExprs_5e5( const Packets_t& argdecls_513, const Packets_t& membs_515, const Packets_t& binaryexprss_517);

private:
	Packets_t* _argdecl_50f;
	Packets_t* _memb_510;
	Packets_t* _binaryexprs_511;
};

class GetNextBinaryExprs_512
{
public:
	void operator()( const Packets_t& argdecls_513, const Packets_t& membs_515, const Packets_t& binaryexprss_517, Packets_t& argdecls_519, Packets_t& membs_51a, Packets_t& binaryexprss_51b, Packets_t& argdecls_51c, Packets_t& membs_51d, Packets_t& binaryexprss_51e);

protected:
	void executeOne( const Packets_t& argdecls_513, const Packets_t& membs_515, const Packets_t& binaryexprss_517);
	bool isInputUnique( const Udm::Object& argdecl_527, const Udm::Object& memb_52e, const Udm::Object& binaryexprs_535);

private:
	Packets_t* _argdecl_51f;
	Packets_t* _memb_520;
	Packets_t* _binaryexprs_521;
	Packets_t* _argdecl_522;
	Packets_t* _memb_523;
	Packets_t* _binaryexprs_524;
	Packets_t _argdecl_525;
	Packets_t _memb_52c;
	Packets_t _binaryexprs_533;
};

class HasExpr_53a
{
public:
	bool operator()( const Packets_t& argDeclBases_53b, const Packets_t& localVars_53e, const Packets_t& binaryExprss_541, Packets_t& argDeclBases_53d, Packets_t& localVars_540, Packets_t& rightBinaryExprss_543);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_54b, const Udm::Object& localVar_554, const Udm::Object& binaryExprs_55d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_53b, const Packets_t& localVars_53e, const Packets_t& binaryExprss_541);
	bool patternMatcher( const Udm::Object& argDeclBase_549, const Udm::Object& localVar_552, const Udm::Object& binaryExprs_55b);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_56d, const SFC::LocalVar& localVar_56f, const SFC::BinaryExprs& rightBinaryExprs_571);

private:
	Packets_t* _argDeclBase_544;
	Packets_t* _localVar_545;
	Packets_t* _rightBinaryExprs_546;
	Packets_t _argDeclBase_547;
	Packets_t _localVar_550;
	Packets_t _binaryExprs_559;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_569;
		SFC::LocalVar localVar_56a;
		SFC::BinaryExprs binaryExprs_56b;
		SFC::BinaryExprs rightBinaryExprs_56c;
	};

	std::list< Match> _matches;
};

class Otherwise_573
{
public:
	bool operator()( const Packets_t& argDeclBases_574, const Packets_t& localVars_577, const Packets_t& binaryExprss_57a, Packets_t& argDeclBases_576, Packets_t& localVars_579, Packets_t& binaryExprss_57c);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_584, const Udm::Object& localVar_58d, const Udm::Object& binaryExprs_596);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_574, const Packets_t& localVars_577, const Packets_t& binaryExprss_57a);
	bool patternMatcher( const Udm::Object& argDeclBase_582, const Udm::Object& localVar_58b, const Udm::Object& binaryExprs_594);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_5a2, const SFC::LocalVar& localVar_5a4, const SFC::BinaryExprs& binaryExprs_5a6);

private:
	Packets_t* _argDeclBase_57d;
	Packets_t* _localVar_57e;
	Packets_t* _binaryExprs_57f;
	Packets_t _argDeclBase_580;
	Packets_t _localVar_589;
	Packets_t _binaryExprs_592;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_59f;
		SFC::LocalVar localVar_5a0;
		SFC::BinaryExprs binaryExprs_5a1;
	};

	std::list< Match> _matches;
};

class GetFirstBinaryExprs_5a8
{
public:
	void operator()( const Packets_t& argDeclBases_5a9, const Packets_t& localVars_5ac, const Packets_t& userCodes_5af, Packets_t& argDeclBases_5ab, Packets_t& localVars_5ae, Packets_t& binaryExprss_5b1);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_5b9, const Udm::Object& localVar_5c2, const Udm::Object& userCode_5cb);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_5a9, const Packets_t& localVars_5ac, const Packets_t& userCodes_5af);
	bool patternMatcher( const Udm::Object& argDeclBase_5b7, const Udm::Object& localVar_5c0, const Udm::Object& userCode_5c9);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_5db, const SFC::LocalVar& localVar_5dd, const SFC::BinaryExprs& binaryExprs_5df);

private:
	Packets_t* _argDeclBase_5b2;
	Packets_t* _localVar_5b3;
	Packets_t* _binaryExprs_5b4;
	Packets_t _argDeclBase_5b5;
	Packets_t _localVar_5be;
	Packets_t _userCode_5c7;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_5d7;
		SFC::LocalVar localVar_5d8;
		SFC::UserCode userCode_5d9;
		SFC::BinaryExprs binaryExprs_5da;
	};

	std::list< Match> _matches;
};

class CondHasExprs_5e9
{
public:
	void operator()( const Packets_t& argdecls_5ea, const Packets_t& membs_5ec, const Packets_t& conditions_5ee, Packets_t& argdecls_5f0, Packets_t& membs_5f1, Packets_t& conditions_5f2, Packets_t& argdecls_5f3, Packets_t& membs_5f4, Packets_t& conditions_5f5);

protected:
	void executeOne( const Packets_t& argdecls_5ea, const Packets_t& membs_5ec, const Packets_t& conditions_5ee);
	bool isInputUnique( const Udm::Object& argdecl_5fe, const Udm::Object& memb_605, const Udm::Object& condition_60c);

private:
	Packets_t* _argdecl_5f6;
	Packets_t* _memb_5f7;
	Packets_t* _condition_5f8;
	Packets_t* _argdecl_5f9;
	Packets_t* _memb_5fa;
	Packets_t* _condition_5fb;
	Packets_t _argdecl_5fc;
	Packets_t _memb_603;
	Packets_t _condition_60a;
};

class HasExpr_611
{
public:
	bool operator()( const Packets_t& argDeclBases_612, const Packets_t& localVars_615, const Packets_t& userCodes_618, Packets_t& argDeclBases_614, Packets_t& localVars_617, Packets_t& userCodes_61a);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_622, const Udm::Object& localVar_62b, const Udm::Object& userCode_634);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_612, const Packets_t& localVars_615, const Packets_t& userCodes_618);
	bool patternMatcher( const Udm::Object& argDeclBase_620, const Udm::Object& localVar_629, const Udm::Object& userCode_632);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_644, const SFC::LocalVar& localVar_646, const SFC::UserCode& userCode_648);

private:
	Packets_t* _argDeclBase_61b;
	Packets_t* _localVar_61c;
	Packets_t* _userCode_61d;
	Packets_t _argDeclBase_61e;
	Packets_t _localVar_627;
	Packets_t _userCode_630;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_640;
		SFC::LocalVar localVar_641;
		SFC::UserCode userCode_642;
		SFC::Exprs exprs_643;
	};

	std::list< Match> _matches;
};

class Otherwise_64a
{
public:
	bool operator()( const Packets_t& argDeclBases_64b, const Packets_t& localVars_64e, const Packets_t& userCodes_651, Packets_t& argDeclBases_64d, Packets_t& localVars_650, Packets_t& userCodes_653);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_65b, const Udm::Object& localVar_664, const Udm::Object& userCode_66d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_64b, const Packets_t& localVars_64e, const Packets_t& userCodes_651);
	bool patternMatcher( const Udm::Object& argDeclBase_659, const Udm::Object& localVar_662, const Udm::Object& userCode_66b);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_679, const SFC::LocalVar& localVar_67b, const SFC::UserCode& userCode_67d);

private:
	Packets_t* _argDeclBase_654;
	Packets_t* _localVar_655;
	Packets_t* _userCode_656;
	Packets_t _argDeclBase_657;
	Packets_t _localVar_660;
	Packets_t _userCode_669;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_676;
		SFC::LocalVar localVar_677;
		SFC::UserCode userCode_678;
	};

	std::list< Match> _matches;
};

class GetStructMembers_6a4
{
public:
	void operator()( const Packets_t& argDeclBases_6a5, const Packets_t& structs_6a8, const Packets_t& userCodes_6ac, Packets_t& argDeclBases_6a7, Packets_t& structs_6aa, Packets_t& localVars_6ab, Packets_t& userCodes_6ae);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_6b7, const Udm::Object& struct_6c0, const Udm::Object& userCode_6c9);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_6a5, const Packets_t& structs_6a8, const Packets_t& userCodes_6ac);
	bool patternMatcher( const Udm::Object& argDeclBase_6b5, const Udm::Object& struct_6be, const Udm::Object& userCode_6c7);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_6d9, const SFC::Struct& struct_6db, const SFC::LocalVar& localVar_6dd, const SFC::UserCode& userCode_6df);
	void sortOutputs();

private:
	Packets_t* _argDeclBase_6af;
	Packets_t* _struct_6b0;
	Packets_t* _localVar_6b1;
	Packets_t* _userCode_6b2;
	Packets_t _argDeclBase_6b3;
	Packets_t _struct_6bc;
	Packets_t _userCode_6c5;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_6d5;
		SFC::Struct struct_6d6;
		SFC::UserCode userCode_6d7;
		SFC::LocalVar localVar_6d8;
	};

	std::list< Match> _matches;
};

class CreateTriggerCondition_6f1
{
public:
	void operator()( const Packets_t& subsystems_6f2, const Packets_t& blocks_6f5, const Packets_t& mains_6f9, Packets_t& subsystems_6f4, Packets_t& blocks_6f7, Packets_t& triggerPorts_6f8, Packets_t& conditionalBlocks_6fb, Packets_t& conditions_6fc);

protected:
	bool isInputUnique( const Udm::Object& subsystem_706, const Udm::Object& block_70f, const Udm::Object& main_718);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_6f2, const Packets_t& blocks_6f5, const Packets_t& mains_6f9);
	bool patternMatcher( const Udm::Object& subsystem_704, const Udm::Object& block_70d, const Udm::Object& main_716);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_72a, const ESMoL::Block& block_72c, const ESMoL::TriggerPort& triggerPort_72e, const SFC::ConditionalBlock& conditionalBlock_730, const SFC::UserCode& condition_732);

private:
	Packets_t* _subsystem_6fd;
	Packets_t* _block_6fe;
	Packets_t* _triggerPort_6ff;
	Packets_t* _conditionalBlock_700;
	Packets_t* _condition_701;
	Packets_t _subsystem_702;
	Packets_t _block_70b;
	Packets_t _main_714;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_724;
		ESMoL::Block block_725;
		SFC::Function main_726;
		ESMoL::TriggerPort triggerPort_727;
	};

	std::list< Match> _matches;
};

class AssignCondVal_734
{
public:
	void operator()( const Packets_t& triggerPorts_735, const Packets_t& conditions_739, Packets_t& argDeclBases_737, Packets_t& dTs_738, Packets_t& conditions_73b);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_743, const Udm::Object& condition_74c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& triggerPorts_735, const Packets_t& conditions_739);
	bool patternMatcher( const Udm::Object& triggerPort_741, const Udm::Object& condition_74a);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_75b, const SFC::DT& dT_75d, const SFC::UserCode& condition_75f);

private:
	Packets_t* _argDeclBase_73c;
	Packets_t* _dT_73d;
	Packets_t* _condition_73e;
	Packets_t _triggerPort_73f;
	Packets_t _condition_748;
	class Match
	{
	public:
		ESMoL::Port triggerPort_757;
		SFC::UserCode condition_758;
		SFC::ArgDeclBase argDeclBase_759;
		SFC::DT dT_75a;
	};

	std::list< Match> _matches;
};

class IsTriggered_76c
{
public:
	void operator()( const Packets_t& systems_76d, const Packets_t& childSubsystems_76f, const Packets_t& systemFunctions_771, Packets_t& systems_773, Packets_t& childSubsystems_774, Packets_t& systemFunctions_775, Packets_t& systems_776, Packets_t& childSubsystems_777, Packets_t& systemFunctions_778);

protected:
	void executeOne( const Packets_t& systems_76d, const Packets_t& childSubsystems_76f, const Packets_t& systemFunctions_771);
	bool isInputUnique( const Udm::Object& system_781, const Udm::Object& childSubsystem_788, const Udm::Object& systemFunction_78f);

private:
	Packets_t* _system_779;
	Packets_t* _childSubsystem_77a;
	Packets_t* _systemFunction_77b;
	Packets_t* _system_77c;
	Packets_t* _childSubsystem_77d;
	Packets_t* _systemFunction_77e;
	Packets_t _system_77f;
	Packets_t _childSubsystem_786;
	Packets_t _systemFunction_78d;
};

class HasTriggers_794
{
public:
	bool operator()( const Packets_t& subsystems_795, const Packets_t& blocks_798, const Packets_t& mains_79b, Packets_t& subsystems_797, Packets_t& blocks_79a, Packets_t& mains_79d);

protected:
	bool isInputUnique( const Udm::Object& subsystem_7a5, const Udm::Object& block_7ae, const Udm::Object& main_7b7);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_795, const Packets_t& blocks_798, const Packets_t& mains_79b);
	bool patternMatcher( const Udm::Object& subsystem_7a3, const Udm::Object& block_7ac, const Udm::Object& main_7b5);
	void outputAppender( const ESMoL::Subsystem& subsystem_7c7, const ESMoL::Subsystem& block_7c9, const SFC::Function& main_7cb);

private:
	Packets_t* _subsystem_79e;
	Packets_t* _block_79f;
	Packets_t* _main_7a0;
	Packets_t _subsystem_7a1;
	Packets_t _block_7aa;
	Packets_t _main_7b3;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_7c3;
		ESMoL::Subsystem block_7c4;
		SFC::Function main_7c5;
		ESMoL::TriggerPort triggerPort_7c6;
	};

	std::list< Match> _matches;
};

class Otherwise_7cd
{
public:
	bool operator()( const Packets_t& subsystems_7ce, const Packets_t& blocks_7d1, const Packets_t& mains_7d4, Packets_t& subsystems_7d0, Packets_t& blocks_7d3, Packets_t& mains_7d6);

protected:
	bool isInputUnique( const Udm::Object& subsystem_7de, const Udm::Object& block_7e7, const Udm::Object& main_7f0);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_7ce, const Packets_t& blocks_7d1, const Packets_t& mains_7d4);
	bool patternMatcher( const Udm::Object& subsystem_7dc, const Udm::Object& block_7e5, const Udm::Object& main_7ee);
	void outputAppender( const ESMoL::Subsystem& subsystem_7fc, const ESMoL::Subsystem& block_7fe, const SFC::Function& main_800);

private:
	Packets_t* _subsystem_7d7;
	Packets_t* _block_7d8;
	Packets_t* _main_7d9;
	Packets_t _subsystem_7da;
	Packets_t _block_7e3;
	Packets_t _main_7ec;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_7f9;
		ESMoL::Subsystem block_7fa;
		SFC::Function main_7fb;
	};

	std::list< Match> _matches;
};

class GetFunctions_80a
{
public:
	void operator()( const Packets_t& systems_80b, Packets_t& systems_80d, Packets_t& systemFunctions_80e);

protected:
	void callGetFunctions_82c( const Packets_t& subsystems_812);

private:
	Packets_t* _system_80f;
	Packets_t* _systemFunction_810;
};

class GetFunctions_811
{
public:
	void operator()( const Packets_t& subsystems_812, Packets_t& subsystems_814, Packets_t& mains_815);

protected:
	bool isInputUnique( const Udm::Object& subsystem_81c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_812);
	bool patternMatcher( const Udm::Object& subsystem_81a);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_828, const SFC::Function& main_82a);

private:
	Packets_t* _subsystem_816;
	Packets_t* _main_817;
	Packets_t _subsystem_818;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_826;
		SFC::Function main_827;
	};

	std::list< Match> _matches;
};

class CreateBlockExecution_82e
{
public:
	void operator()( const Packets_t& systems_82f, const Packets_t& childBlockss_831, const Packets_t& systemFunctions_833, Packets_t& systems_835, Packets_t& systemFunctions_836);

protected:
	void executeOne( const Packets_t& systems_82f, const Packets_t& childBlockss_831, const Packets_t& systemFunctions_833);
	bool isInputUnique( const Udm::Object& system_83b, const Udm::Object& childBlocks_842, const Udm::Object& systemFunction_849);
	void callTestChildBlock_2aa4( const Packets_t& systems_29d0, const Packets_t& childBlocks_29d2, const Packets_t& systemFunctions_29d4);
	void callPrimitiveChildBlock_2aa8( const Packets_t& childPrimitives_1984, const Packets_t& systemFunctions_1986);
	void callSubsystemChildBlock_2aab( const Packets_t& systems_1bde, const Packets_t& childSubsystems_1be0, const Packets_t& systemFunctions_1be2);
	void callChartChildBlock_2aaf( const Packets_t& systems_84f, const Packets_t& childCharts_851, const Packets_t& systemFunctions_853);

private:
	Packets_t* _system_837;
	Packets_t* _systemFunction_838;
	Packets_t _system_839;
	Packets_t _childBlocks_840;
	Packets_t _systemFunction_847;
};

class ChartChildBlock_84e
{
public:
	void operator()( const Packets_t& systems_84f, const Packets_t& childCharts_851, const Packets_t& systemFunctions_853);

protected:
	void callMakeTrigger_195e( const Packets_t& systems_856, const Packets_t& childSubsystems_858, const Packets_t& systemFunctions_85a);
	void callCreateFunctionCall_1962( const Packets_t& subsystems_18c1, const Packets_t& charts_18c4, const Packets_t& compoundStatements_18c9);
	void callGetState_1966( const Packets_t& subsystems_190b, const Packets_t& charts_190e, const Packets_t& mains_1912, const Packets_t& functionCalls_1915);
	void callInputData_196b( const Packets_t& systems_1759, const Packets_t& childCharts_175b, const Packets_t& states_175d, const Packets_t& functions_175f, const Packets_t& functionCalls_1761);
	void callInputEvent_1971( const Packets_t& systems_1631, const Packets_t& childCharts_1633, const Packets_t& states_1635, const Packets_t& functions_1637, const Packets_t& functionCalls_1639);
	void callOutputData_1977( const Packets_t& systems_1837, const Packets_t& childCharts_1839, const Packets_t& states_183b, const Packets_t& functions_183d, const Packets_t& functionCalls_183f);
	void callOutputEvent_197d( const Packets_t& systems_155d, const Packets_t& childCharts_155f, const Packets_t& states_1561, const Packets_t& functions_1563, const Packets_t& functionCalls_1565);
};

class MakeTrigger_855
{
public:
	void operator()( const Packets_t& systems_856, const Packets_t& childSubsystems_858, const Packets_t& systemFunctions_85a, Packets_t& systems_85c, Packets_t& childSubsystems_85d, Packets_t& compoundStatements_85e);

protected:
	void callIsTriggered_1554( const Packets_t& systems_863, const Packets_t& childSubsystems_865, const Packets_t& systemFunctions_867);
	void callCreateTriggering_1558( const Packets_t& systems_8f9, const Packets_t& childSubsystems_8fb, const Packets_t& systemFunctions_8fd);

private:
	Packets_t* _system_85f;
	Packets_t* _childSubsystem_860;
	Packets_t* _compoundStatement_861;
};

class IsTriggered_862
{
public:
	void operator()( const Packets_t& systems_863, const Packets_t& childSubsystems_865, const Packets_t& systemFunctions_867, Packets_t& systems_869, Packets_t& childSubsystems_86a, Packets_t& systemFunctions_86b, Packets_t& systems_86c, Packets_t& childSubsystems_86d, Packets_t& systemFunctions_86e);

protected:
	void executeOne( const Packets_t& systems_863, const Packets_t& childSubsystems_865, const Packets_t& systemFunctions_867);
	bool isInputUnique( const Udm::Object& system_877, const Udm::Object& childSubsystem_87e, const Udm::Object& systemFunction_885);

private:
	Packets_t* _system_86f;
	Packets_t* _childSubsystem_870;
	Packets_t* _systemFunction_871;
	Packets_t* _system_872;
	Packets_t* _childSubsystem_873;
	Packets_t* _systemFunction_874;
	Packets_t _system_875;
	Packets_t _childSubsystem_87c;
	Packets_t _systemFunction_883;
};

class HasTriggers_88a
{
public:
	bool operator()( const Packets_t& subsystems_88b, const Packets_t& blocks_88e, const Packets_t& mains_891, Packets_t& subsystems_88d, Packets_t& blocks_890, Packets_t& mains_893);

protected:
	bool isInputUnique( const Udm::Object& subsystem_89b, const Udm::Object& block_8a4, const Udm::Object& main_8ad);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_88b, const Packets_t& blocks_88e, const Packets_t& mains_891);
	bool patternMatcher( const Udm::Object& subsystem_899, const Udm::Object& block_8a2, const Udm::Object& main_8ab);
	void outputAppender( const ESMoL::Subsystem& subsystem_8bd, const ESMoL::Subsystem& block_8bf, const SFC::Function& main_8c1);

private:
	Packets_t* _subsystem_894;
	Packets_t* _block_895;
	Packets_t* _main_896;
	Packets_t _subsystem_897;
	Packets_t _block_8a0;
	Packets_t _main_8a9;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_8b9;
		ESMoL::Subsystem block_8ba;
		SFC::Function main_8bb;
		ESMoL::TriggerPort triggerPort_8bc;
	};

	std::list< Match> _matches;
};

class Otherwise_8c3
{
public:
	bool operator()( const Packets_t& subsystems_8c4, const Packets_t& blocks_8c7, const Packets_t& mains_8ca, Packets_t& subsystems_8c6, Packets_t& blocks_8c9, Packets_t& mains_8cc);

protected:
	bool isInputUnique( const Udm::Object& subsystem_8d4, const Udm::Object& block_8dd, const Udm::Object& main_8e6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_8c4, const Packets_t& blocks_8c7, const Packets_t& mains_8ca);
	bool patternMatcher( const Udm::Object& subsystem_8d2, const Udm::Object& block_8db, const Udm::Object& main_8e4);
	void outputAppender( const ESMoL::Subsystem& subsystem_8f2, const ESMoL::Subsystem& block_8f4, const SFC::Function& main_8f6);

private:
	Packets_t* _subsystem_8cd;
	Packets_t* _block_8ce;
	Packets_t* _main_8cf;
	Packets_t _subsystem_8d0;
	Packets_t _block_8d9;
	Packets_t _main_8e2;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_8ef;
		ESMoL::Subsystem block_8f0;
		SFC::Function main_8f1;
	};

	std::list< Match> _matches;
};

class CreateTriggering_8f8
{
public:
	void operator()( const Packets_t& systems_8f9, const Packets_t& childSubsystems_8fb, const Packets_t& systemFunctions_8fd, Packets_t& systems_8ff, Packets_t& childSubsystems_900, Packets_t& conditionalBlocks_901);

protected:
	void callGetTriggerPort_1546( const Packets_t& subsystems_947, const Packets_t& blocks_94a, const Packets_t& mains_94d);
	void callAssignCondValLocalVar_154a( const Packets_t& subsystems_906, const Packets_t& triggerPorts_909, const Packets_t& functions_90e);
	void callMakeTrigger_154e( const Packets_t& systems_980, const Packets_t& childSubsystemTriggers_982, const Packets_t& argdecls_984, const Packets_t& dts_986, const Packets_t& functions_988);

private:
	Packets_t* _system_902;
	Packets_t* _childSubsystem_903;
	Packets_t* _conditionalBlock_904;
};

class AssignCondValLocalVar_905
{
public:
	void operator()( const Packets_t& subsystems_906, const Packets_t& triggerPorts_909, const Packets_t& functions_90e, Packets_t& subsystems_908, Packets_t& triggerPorts_90b, Packets_t& argDeclBases_90c, Packets_t& dTs_90d, Packets_t& functions_910);

protected:
	bool isInputUnique( const Udm::Object& subsystem_91a, const Udm::Object& triggerPort_923, const Udm::Object& function_92c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_906, const Packets_t& triggerPorts_909, const Packets_t& functions_90e);
	bool patternMatcher( const Udm::Object& subsystem_918, const Udm::Object& triggerPort_921, const Udm::Object& function_92a);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_93c, const ESMoL::Port& triggerPort_93e, const SFC::ArgDeclBase& argDeclBase_940, const SFC::DT& dT_942, const SFC::Function& function_944);

private:
	Packets_t* _subsystem_911;
	Packets_t* _triggerPort_912;
	Packets_t* _argDeclBase_913;
	Packets_t* _dT_914;
	Packets_t* _function_915;
	Packets_t _subsystem_916;
	Packets_t _triggerPort_91f;
	Packets_t _function_928;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_937;
		ESMoL::Port triggerPort_938;
		SFC::Function function_939;
		SFC::ArgDeclBase argDeclBase_93a;
		SFC::DT dT_93b;
	};

	std::list< Match> _matches;
};

class GetTriggerPort_946
{
public:
	void operator()( const Packets_t& subsystems_947, const Packets_t& blocks_94a, const Packets_t& mains_94d, Packets_t& subsystems_949, Packets_t& triggerPorts_94c, Packets_t& mains_94f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_957, const Udm::Object& block_960, const Udm::Object& main_969);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_947, const Packets_t& blocks_94a, const Packets_t& mains_94d);
	bool patternMatcher( const Udm::Object& subsystem_955, const Udm::Object& block_95e, const Udm::Object& main_967);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_979, const ESMoL::TriggerPort& triggerPort_97b, const SFC::Function& main_97d);

private:
	Packets_t* _subsystem_950;
	Packets_t* _triggerPort_951;
	Packets_t* _main_952;
	Packets_t _subsystem_953;
	Packets_t _block_95c;
	Packets_t _main_965;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_975;
		ESMoL::Block block_976;
		SFC::Function main_977;
		ESMoL::TriggerPort triggerPort_978;
	};

	std::list< Match> _matches;
};

class MakeTrigger_97f
{
public:
	void operator()( const Packets_t& systems_980, const Packets_t& childSubsystemTriggers_982, const Packets_t& argdecls_984, const Packets_t& dts_986, const Packets_t& functions_988, Packets_t& systems_98a, Packets_t& childSubsystems_98b, Packets_t& conditionals_98c);

protected:
	void callAddStateVar_152a( const Packets_t& subsystems_11ab, const Packets_t& triggerPorts_11ae, const Packets_t& argDeclBases_11b1, const Packets_t& dTs_11b5, const Packets_t& functions_11b9);
	void callAddTriggerVars_1530( const Packets_t& systems_991, const Packets_t& childsystems_993, const Packets_t& argdecls_995, const Packets_t& dts_997, const Packets_t& oldvals_999, const Packets_t& contexts_99b, const Packets_t& functions_99d);
	void callSaveState_1538( const Packets_t& systems_10bf, const Packets_t& childsystems_10c1, const Packets_t& argdecls_10c3, const Packets_t& dts_10c5, const Packets_t& oldvals_10c7, const Packets_t& contexts_10c9, const Packets_t& functions_10cb);
	void callMakeCondition_1540( const Packets_t& systems_1219, const Packets_t& childSubsystems_121b, const Packets_t& dts_121d, const Packets_t& oldvals_121f, const Packets_t& functions_1221);

private:
	Packets_t* _system_98d;
	Packets_t* _childSubsystem_98e;
	Packets_t* _conditional_98f;
};

class AddTriggerVars_990
{
public:
	void operator()( const Packets_t& systems_991, const Packets_t& childsystems_993, const Packets_t& argdecls_995, const Packets_t& dts_997, const Packets_t& oldvals_999, const Packets_t& contexts_99b, const Packets_t& functions_99d, Packets_t& systems_99f, Packets_t& childsystems_9a0, Packets_t& argdecls_9a1, Packets_t& dts_9a2, Packets_t& oldvals_9a3, Packets_t& contexts_9a4, Packets_t& functions_9a5);

protected:
	void callAddMatrixTriggerVars_10b0( const Packets_t& childSubsystems_9ae, const Packets_t& argdecls_9b0, const Packets_t& dts_9b2, const Packets_t& oldvals_9b4, const Packets_t& contexts_9b6, const Packets_t& functions_9b8);
	void callAddStructTriggerVars_10b7( const Packets_t& childSubsystems_cee, const Packets_t& argdecls_cf0, const Packets_t& dts_cf2, const Packets_t& oldvals_cf4, const Packets_t& contexts_cf6, const Packets_t& functions_cf8);

private:
	Packets_t* _system_9a6;
	Packets_t* _childsystem_9a7;
	Packets_t* _argdecl_9a8;
	Packets_t* _dt_9a9;
	Packets_t* _oldval_9aa;
	Packets_t* _context_9ab;
	Packets_t* _function_9ac;
};

class AddMatrixTriggerVars_9ad
{
public:
	void operator()( const Packets_t& childSubsystems_9ae, const Packets_t& argdecls_9b0, const Packets_t& dts_9b2, const Packets_t& oldvals_9b4, const Packets_t& contexts_9b6, const Packets_t& functions_9b8, Packets_t& childSubsystems_9ba, Packets_t& argdecls_9bb, Packets_t& dts_9bc, Packets_t& oldvals_9bd, Packets_t& contexts_9be, Packets_t& functions_9bf);

protected:
	void callAddTriggerVar_cc0( const Packets_t& charts_c55, const Packets_t& argDeclBases_c58, const Packets_t& dTs_c5b, const Packets_t& localVars_c5d, const Packets_t& contexts_c60, const Packets_t& functions_c64);
	void callStartAssignment_cc7( const Packets_t& charts_bd8, const Packets_t& argDeclBases_bda, const Packets_t& oldvals_bdd, const Packets_t& contexts_be0, const Packets_t& triggerVars_be3, const Packets_t& functions_be5);
	void callEdgeTest_cce( const Packets_t& events_a8f, const Packets_t& argdecls_a91, const Packets_t& oldvals_a93, const Packets_t& contexts_a95, const Packets_t& initexprs_a97);
	void callEitherEdge_cd4( const Packets_t& argDeclBases_9c7, const Packets_t& localVars_9ca, const Packets_t& contexts_9cd, const Packets_t& unaryExprss_9d0);
	void callFallingEdge_cd9( const Packets_t& argDeclBases_a13, const Packets_t& localVars_a15, const Packets_t& contexts_a17, const Packets_t& unaryExprss_a19);
	void callRisingEdge_cde( const Packets_t& argDeclBases_a51, const Packets_t& localVars_a53, const Packets_t& contexts_a55, const Packets_t& unaryExprss_a57);
	void callFallingEdge_ce3( const Packets_t& argDeclBases_a13, const Packets_t& localVars_a15, const Packets_t& contexts_a17, const Packets_t& unaryExprss_a19);
	void callRisingEdge_ce8( const Packets_t& argDeclBases_a51, const Packets_t& localVars_a53, const Packets_t& contexts_a55, const Packets_t& unaryExprss_a57);

private:
	Packets_t* _childSubsystem_9c0;
	Packets_t* _argdecl_9c1;
	Packets_t* _dt_9c2;
	Packets_t* _oldval_9c3;
	Packets_t* _context_9c4;
	Packets_t* _function_9c5;
};

class EitherEdge_9c6
{
public:
	void operator()( const Packets_t& argDeclBases_9c7, const Packets_t& localVars_9ca, const Packets_t& contexts_9cd, const Packets_t& unaryExprss_9d0, Packets_t& argDeclBases_9c9, Packets_t& localVars_9cc, Packets_t& contexts_9cf, Packets_t& leftUnaryExprss_9d2, Packets_t& rightUnaryExprss_9d3);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_9dd, const Udm::Object& localVar_9e6, const Udm::Object& context_9ef, const Udm::Object& unaryExprs_9f8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_9c7, const Packets_t& localVars_9ca, const Packets_t& contexts_9cd, const Packets_t& unaryExprss_9d0);
	bool patternMatcher( const Udm::Object& argDeclBase_9db, const Udm::Object& localVar_9e4, const Udm::Object& context_9ed, const Udm::Object& unaryExprs_9f6);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_a08, const SFC::LocalVar& localVar_a0a, const SFC::Arg& context_a0c, const SFC::UnaryExprs& leftUnaryExprs_a0e, const SFC::UnaryExprs& rightUnaryExprs_a10);

private:
	Packets_t* _argDeclBase_9d4;
	Packets_t* _localVar_9d5;
	Packets_t* _context_9d6;
	Packets_t* _leftUnaryExprs_9d7;
	Packets_t* _rightUnaryExprs_9d8;
	Packets_t _argDeclBase_9d9;
	Packets_t _localVar_9e2;
	Packets_t _context_9eb;
	Packets_t _unaryExprs_9f4;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_a01;
		SFC::LocalVar localVar_a02;
		SFC::Arg context_a03;
		SFC::UnaryExprs unaryExprs_a04;
	};

	std::list< Match> _matches;
};

class FallingEdge_a12
{
public:
	void operator()( const Packets_t& argDeclBases_a13, const Packets_t& localVars_a15, const Packets_t& contexts_a17, const Packets_t& unaryExprss_a19);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_a1f, const Udm::Object& localVar_a28, const Udm::Object& context_a31, const Udm::Object& unaryExprs_a3a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_a13, const Packets_t& localVars_a15, const Packets_t& contexts_a17, const Packets_t& unaryExprss_a19);
	bool patternMatcher( const Udm::Object& argDeclBase_a1d, const Udm::Object& localVar_a26, const Udm::Object& context_a2f, const Udm::Object& unaryExprs_a38);
	void effector();

private:
	Packets_t _argDeclBase_a1b;
	Packets_t _localVar_a24;
	Packets_t _context_a2d;
	Packets_t _unaryExprs_a36;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_a43;
		SFC::LocalVar localVar_a44;
		SFC::Arg context_a45;
		SFC::UnaryExprs unaryExprs_a46;
	};

	std::list< Match> _matches;
};

class RisingEdge_a50
{
public:
	void operator()( const Packets_t& argDeclBases_a51, const Packets_t& localVars_a53, const Packets_t& contexts_a55, const Packets_t& unaryExprss_a57);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_a5d, const Udm::Object& localVar_a66, const Udm::Object& context_a6f, const Udm::Object& unaryExprs_a78);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_a51, const Packets_t& localVars_a53, const Packets_t& contexts_a55, const Packets_t& unaryExprss_a57);
	bool patternMatcher( const Udm::Object& argDeclBase_a5b, const Udm::Object& localVar_a64, const Udm::Object& context_a6d, const Udm::Object& unaryExprs_a76);
	void effector();

private:
	Packets_t _argDeclBase_a59;
	Packets_t _localVar_a62;
	Packets_t _context_a6b;
	Packets_t _unaryExprs_a74;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_a81;
		SFC::LocalVar localVar_a82;
		SFC::Arg context_a83;
		SFC::UnaryExprs unaryExprs_a84;
	};

	std::list< Match> _matches;
};

class EdgeTest_a8e
{
public:
	void operator()( const Packets_t& events_a8f, const Packets_t& argdecls_a91, const Packets_t& oldvals_a93, const Packets_t& contexts_a95, const Packets_t& initexprs_a97, Packets_t& argdecls_a99, Packets_t& oldvals_a9a, Packets_t& contexts_a9b, Packets_t& initexprs_a9c, Packets_t& argdecls_a9d, Packets_t& oldvals_a9e, Packets_t& contexts_a9f, Packets_t& initexprs_aa0, Packets_t& argdecls_aa1, Packets_t& oldvals_aa2, Packets_t& contexts_aa3, Packets_t& initexprs_aa4);

protected:
	void executeOne( const Packets_t& events_a8f, const Packets_t& argdecls_a91, const Packets_t& oldvals_a93, const Packets_t& contexts_a95, const Packets_t& initexprs_a97);
	bool isInputUnique( const Udm::Object& event_ab3, const Udm::Object& argdecl_aba, const Udm::Object& oldval_ac1, const Udm::Object& context_ac8, const Udm::Object& initexpr_acf);

private:
	Packets_t* _argdecl_aa5;
	Packets_t* _oldval_aa6;
	Packets_t* _context_aa7;
	Packets_t* _initexpr_aa8;
	Packets_t* _argdecl_aa9;
	Packets_t* _oldval_aaa;
	Packets_t* _context_aab;
	Packets_t* _initexpr_aac;
	Packets_t* _argdecl_aad;
	Packets_t* _oldval_aae;
	Packets_t* _context_aaf;
	Packets_t* _initexpr_ab0;
	Packets_t _event_ab1;
	Packets_t _argdecl_ab8;
	Packets_t _oldval_abf;
	Packets_t _context_ac6;
	Packets_t _initexpr_acd;
};

class RisingEdge_ad4
{
public:
	bool operator()( const Packets_t& events_ad5, const Packets_t& argDeclBases_ad7, const Packets_t& localVars_ada, const Packets_t& contexts_add, const Packets_t& unaryExprss_ae0, Packets_t& argDeclBases_ad9, Packets_t& localVars_adc, Packets_t& contexts_adf, Packets_t& unaryExprss_ae2);

protected:
	bool isInputUnique( const Udm::Object& event_aeb, const Udm::Object& argDeclBase_af4, const Udm::Object& localVar_afd, const Udm::Object& context_b06, const Udm::Object& unaryExprs_b0f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, ESMoL::Event& Event, SFC::LocalVar& LocalVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& events_ad5, const Packets_t& argDeclBases_ad7, const Packets_t& localVars_ada, const Packets_t& contexts_add, const Packets_t& unaryExprss_ae0);
	bool patternMatcher( const Udm::Object& event_ae9, const Udm::Object& argDeclBase_af2, const Udm::Object& localVar_afb, const Udm::Object& context_b04, const Udm::Object& unaryExprs_b0d);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_b22, const SFC::LocalVar& localVar_b24, const SFC::Arg& context_b26, const SFC::UnaryExprs& unaryExprs_b28);

private:
	Packets_t* _argDeclBase_ae3;
	Packets_t* _localVar_ae4;
	Packets_t* _context_ae5;
	Packets_t* _unaryExprs_ae6;
	Packets_t _event_ae7;
	Packets_t _argDeclBase_af0;
	Packets_t _localVar_af9;
	Packets_t _context_b02;
	Packets_t _unaryExprs_b0b;
	class Match
	{
	public:
		ESMoL::Event event_b18;
		SFC::ArgDeclBase argDeclBase_b19;
		SFC::LocalVar localVar_b1a;
		SFC::Arg context_b1b;
		SFC::UnaryExprs unaryExprs_b1c;
	};

	std::list< Match> _matches;
};

class FallingEdge_b2a
{
public:
	bool operator()( const Packets_t& events_b2b, const Packets_t& argDeclBases_b2d, const Packets_t& localVars_b30, const Packets_t& contexts_b33, const Packets_t& unaryExprss_b36, Packets_t& argDeclBases_b2f, Packets_t& localVars_b32, Packets_t& contexts_b35, Packets_t& unaryExprss_b38);

protected:
	bool isInputUnique( const Udm::Object& event_b41, const Udm::Object& argDeclBase_b4a, const Udm::Object& localVar_b53, const Udm::Object& context_b5c, const Udm::Object& unaryExprs_b65);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, ESMoL::Event& Event, SFC::LocalVar& LocalVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& events_b2b, const Packets_t& argDeclBases_b2d, const Packets_t& localVars_b30, const Packets_t& contexts_b33, const Packets_t& unaryExprss_b36);
	bool patternMatcher( const Udm::Object& event_b3f, const Udm::Object& argDeclBase_b48, const Udm::Object& localVar_b51, const Udm::Object& context_b5a, const Udm::Object& unaryExprs_b63);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_b78, const SFC::LocalVar& localVar_b7a, const SFC::Arg& context_b7c, const SFC::UnaryExprs& unaryExprs_b7e);

private:
	Packets_t* _argDeclBase_b39;
	Packets_t* _localVar_b3a;
	Packets_t* _context_b3b;
	Packets_t* _unaryExprs_b3c;
	Packets_t _event_b3d;
	Packets_t _argDeclBase_b46;
	Packets_t _localVar_b4f;
	Packets_t _context_b58;
	Packets_t _unaryExprs_b61;
	class Match
	{
	public:
		ESMoL::Event event_b6e;
		SFC::ArgDeclBase argDeclBase_b6f;
		SFC::LocalVar localVar_b70;
		SFC::Arg context_b71;
		SFC::UnaryExprs unaryExprs_b72;
	};

	std::list< Match> _matches;
};

class EitherEdge_b80
{
public:
	bool operator()( const Packets_t& events_b81, const Packets_t& argDeclBases_b83, const Packets_t& localVars_b86, const Packets_t& contexts_b89, const Packets_t& unaryExprss_b8c, Packets_t& argDeclBases_b85, Packets_t& localVars_b88, Packets_t& contexts_b8b, Packets_t& unaryExprss_b8e);

protected:
	bool isInputUnique( const Udm::Object& event_b97, const Udm::Object& argDeclBase_ba0, const Udm::Object& localVar_ba9, const Udm::Object& context_bb2, const Udm::Object& unaryExprs_bbb);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, ESMoL::Event& Event, SFC::LocalVar& LocalVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& events_b81, const Packets_t& argDeclBases_b83, const Packets_t& localVars_b86, const Packets_t& contexts_b89, const Packets_t& unaryExprss_b8c);
	bool patternMatcher( const Udm::Object& event_b95, const Udm::Object& argDeclBase_b9e, const Udm::Object& localVar_ba7, const Udm::Object& context_bb0, const Udm::Object& unaryExprs_bb9);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_bce, const SFC::LocalVar& localVar_bd0, const SFC::Arg& context_bd2, const SFC::UnaryExprs& unaryExprs_bd4);

private:
	Packets_t* _argDeclBase_b8f;
	Packets_t* _localVar_b90;
	Packets_t* _context_b91;
	Packets_t* _unaryExprs_b92;
	Packets_t _event_b93;
	Packets_t _argDeclBase_b9c;
	Packets_t _localVar_ba5;
	Packets_t _context_bae;
	Packets_t _unaryExprs_bb7;
	class Match
	{
	public:
		ESMoL::Event event_bc4;
		SFC::ArgDeclBase argDeclBase_bc5;
		SFC::LocalVar localVar_bc6;
		SFC::Arg context_bc7;
		SFC::UnaryExprs unaryExprs_bc8;
	};

	std::list< Match> _matches;
};

class StartAssignment_bd6
{
public:
	void operator()( const Packets_t& charts_bd8, const Packets_t& argDeclBases_bda, const Packets_t& oldvals_bdd, const Packets_t& contexts_be0, const Packets_t& triggerVars_be3, const Packets_t& functions_be5, Packets_t& events_bd7, Packets_t& argDeclBases_bdc, Packets_t& oldvals_bdf, Packets_t& contexts_be2, Packets_t& unaryExprss_be7);

protected:
	bool isInputUnique( const Udm::Object& chart_bf1, const Udm::Object& argDeclBase_bfa, const Udm::Object& oldval_c03, const Udm::Object& context_c0c, const Udm::Object& triggerVar_c15, const Udm::Object& function_c1e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, ESMoL::Subsystem& Chart, ESMoL::ConnectorRef& ConnectorRef, SFC::Arg& Context, ESMoL::Event& Event, SFC::Function& Function, ESMoL::Primitive& Primitive, ESMoL::State& State, SFC::LocalVar& TriggerVar, SFC::LocalVar& oldval);
	void processInputPackets( const Packets_t& charts_bd8, const Packets_t& argDeclBases_bda, const Packets_t& oldvals_bdd, const Packets_t& contexts_be0, const Packets_t& triggerVars_be3, const Packets_t& functions_be5);
	bool patternMatcher( const Udm::Object& chart_bef, const Udm::Object& argDeclBase_bf8, const Udm::Object& oldval_c01, const Udm::Object& context_c0a, const Udm::Object& triggerVar_c13, const Udm::Object& function_c1c);
	void effector();
	void outputAppender( const ESMoL::Event& event_c4a, const SFC::ArgDeclBase& argDeclBase_c4c, const SFC::LocalVar& oldval_c4e, const SFC::Arg& context_c50, const SFC::UnaryExprs& unaryExprs_c52);

private:
	Packets_t* _event_be8;
	Packets_t* _argDeclBase_be9;
	Packets_t* _oldval_bea;
	Packets_t* _context_beb;
	Packets_t* _unaryExprs_bec;
	Packets_t _chart_bed;
	Packets_t _argDeclBase_bf6;
	Packets_t _oldval_bff;
	Packets_t _context_c08;
	Packets_t _triggerVar_c11;
	Packets_t _function_c1a;
	class Match
	{
	public:
		ESMoL::Subsystem chart_c32;
		SFC::ArgDeclBase argDeclBase_c33;
		SFC::LocalVar oldval_c34;
		SFC::Arg context_c35;
		SFC::LocalVar triggerVar_c36;
		SFC::Function function_c37;
		ESMoL::State state_c38;
		ESMoL::Event event_c39;
		ESMoL::Primitive primitive_c3a;
		ESMoL::ConnectorRef connectorRef_c3b;
	};

	std::list< Match> _matches;
};

class AddTriggerVar_c54
{
public:
	void operator()( const Packets_t& charts_c55, const Packets_t& argDeclBases_c58, const Packets_t& dTs_c5b, const Packets_t& localVars_c5d, const Packets_t& contexts_c60, const Packets_t& functions_c64, Packets_t& charts_c57, Packets_t& argDeclBases_c5a, Packets_t& localVars_c5f, Packets_t& contexts_c62, Packets_t& triggerVars_c63, Packets_t& functions_c66);

protected:
	bool isInputUnique( const Udm::Object& chart_c71, const Udm::Object& argDeclBase_c7a, const Udm::Object& dT_c83, const Udm::Object& localVar_c8c, const Udm::Object& context_c95, const Udm::Object& function_c9e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, ESMoL::Subsystem& Chart, SFC::Arg& Context, SFC::DT& DT, SFC::Function& Function, SFC::LocalVar& LocalVar);
	void processInputPackets( const Packets_t& charts_c55, const Packets_t& argDeclBases_c58, const Packets_t& dTs_c5b, const Packets_t& localVars_c5d, const Packets_t& contexts_c60, const Packets_t& functions_c64);
	bool patternMatcher( const Udm::Object& chart_c6f, const Udm::Object& argDeclBase_c78, const Udm::Object& dT_c81, const Udm::Object& localVar_c8a, const Udm::Object& context_c93, const Udm::Object& function_c9c);
	void effector();
	void outputAppender( const ESMoL::Subsystem& chart_cb4, const SFC::ArgDeclBase& argDeclBase_cb6, const SFC::LocalVar& localVar_cb8, const SFC::Arg& context_cba, const SFC::LocalVar& triggerVar_cbc, const SFC::Function& function_cbe);

private:
	Packets_t* _chart_c67;
	Packets_t* _argDeclBase_c68;
	Packets_t* _localVar_c69;
	Packets_t* _context_c6a;
	Packets_t* _triggerVar_c6b;
	Packets_t* _function_c6c;
	Packets_t _chart_c6d;
	Packets_t _argDeclBase_c76;
	Packets_t _dT_c7f;
	Packets_t _localVar_c88;
	Packets_t _context_c91;
	Packets_t _function_c9a;
	class Match
	{
	public:
		ESMoL::Subsystem chart_ca7;
		SFC::ArgDeclBase argDeclBase_ca8;
		SFC::DT dT_ca9;
		SFC::LocalVar localVar_caa;
		SFC::Arg context_cab;
		SFC::Function function_cac;
	};

	std::list< Match> _matches;
};

class AddStructTriggerVars_ced
{
public:
	void operator()( const Packets_t& childSubsystems_cee, const Packets_t& argdecls_cf0, const Packets_t& dts_cf2, const Packets_t& oldvals_cf4, const Packets_t& contexts_cf6, const Packets_t& functions_cf8);

protected:
	void callAddTriggerVar_107c( const Packets_t& charts_f7d, const Packets_t& argDeclBases_f80, const Packets_t& structs_f83, const Packets_t& localVars_f86, const Packets_t& contexts_f89, const Packets_t& functions_f8d);
	void callStartAssignment_1083( const Packets_t& charts_fe8, const Packets_t& argDeclBases_fea, const Packets_t& structs_fee, const Packets_t& oldvals_ff0, const Packets_t& contexts_ff3, const Packets_t& triggerVars_ff6, const Packets_t& functions_ff8);
	void callEdgeTest_108b( const Packets_t& events_df3, const Packets_t& argdecls_df5, const Packets_t& members_df7, const Packets_t& oldvals_df9, const Packets_t& contexts_dfb, const Packets_t& initexprs_dfd);
	void callEitherEdge_1092( const Packets_t& argDeclBases_cfb, const Packets_t& members_cfe, const Packets_t& localVars_d01, const Packets_t& contexts_d04, const Packets_t& unaryExprss_d07);
	void callFallingEdge_1098( const Packets_t& argDeclBases_d57, const Packets_t& members_d59, const Packets_t& localVars_d5b, const Packets_t& contexts_d5d, const Packets_t& unaryExprss_d5f);
	void callRisingEdge_109e( const Packets_t& argDeclBases_da5, const Packets_t& members_da7, const Packets_t& localVars_da9, const Packets_t& contexts_dab, const Packets_t& unaryExprss_dad);
	void callFallingEdge_10a4( const Packets_t& argDeclBases_d57, const Packets_t& members_d59, const Packets_t& localVars_d5b, const Packets_t& contexts_d5d, const Packets_t& unaryExprss_d5f);
	void callRisingEdge_10aa( const Packets_t& argDeclBases_da5, const Packets_t& members_da7, const Packets_t& localVars_da9, const Packets_t& contexts_dab, const Packets_t& unaryExprss_dad);
};

class EitherEdge_cfa
{
public:
	void operator()( const Packets_t& argDeclBases_cfb, const Packets_t& members_cfe, const Packets_t& localVars_d01, const Packets_t& contexts_d04, const Packets_t& unaryExprss_d07, Packets_t& argDeclBases_cfd, Packets_t& members_d00, Packets_t& localVars_d03, Packets_t& contexts_d06, Packets_t& leftUnaryExprss_d09, Packets_t& rightUnaryExprss_d0a);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_d15, const Udm::Object& member_d1e, const Udm::Object& localVar_d27, const Udm::Object& context_d30, const Udm::Object& unaryExprs_d39);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_cfb, const Packets_t& members_cfe, const Packets_t& localVars_d01, const Packets_t& contexts_d04, const Packets_t& unaryExprss_d07);
	bool patternMatcher( const Udm::Object& argDeclBase_d13, const Udm::Object& member_d1c, const Udm::Object& localVar_d25, const Udm::Object& context_d2e, const Udm::Object& unaryExprs_d37);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_d4a, const SFC::LocalVar& member_d4c, const SFC::LocalVar& localVar_d4e, const SFC::Arg& context_d50, const SFC::UnaryExprs& leftUnaryExprs_d52, const SFC::UnaryExprs& rightUnaryExprs_d54);

private:
	Packets_t* _argDeclBase_d0b;
	Packets_t* _member_d0c;
	Packets_t* _localVar_d0d;
	Packets_t* _context_d0e;
	Packets_t* _leftUnaryExprs_d0f;
	Packets_t* _rightUnaryExprs_d10;
	Packets_t _argDeclBase_d11;
	Packets_t _member_d1a;
	Packets_t _localVar_d23;
	Packets_t _context_d2c;
	Packets_t _unaryExprs_d35;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_d42;
		SFC::LocalVar member_d43;
		SFC::LocalVar localVar_d44;
		SFC::Arg context_d45;
		SFC::UnaryExprs unaryExprs_d46;
	};

	std::list< Match> _matches;
};

class FallingEdge_d56
{
public:
	void operator()( const Packets_t& argDeclBases_d57, const Packets_t& members_d59, const Packets_t& localVars_d5b, const Packets_t& contexts_d5d, const Packets_t& unaryExprss_d5f);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_d65, const Udm::Object& member_d6e, const Udm::Object& localVar_d77, const Udm::Object& context_d80, const Udm::Object& unaryExprs_d89);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_d57, const Packets_t& members_d59, const Packets_t& localVars_d5b, const Packets_t& contexts_d5d, const Packets_t& unaryExprss_d5f);
	bool patternMatcher( const Udm::Object& argDeclBase_d63, const Udm::Object& member_d6c, const Udm::Object& localVar_d75, const Udm::Object& context_d7e, const Udm::Object& unaryExprs_d87);
	void effector();

private:
	Packets_t _argDeclBase_d61;
	Packets_t _member_d6a;
	Packets_t _localVar_d73;
	Packets_t _context_d7c;
	Packets_t _unaryExprs_d85;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_d92;
		SFC::LocalVar member_d93;
		SFC::LocalVar localVar_d94;
		SFC::Arg context_d95;
		SFC::UnaryExprs unaryExprs_d96;
	};

	std::list< Match> _matches;
};

class RisingEdge_da4
{
public:
	void operator()( const Packets_t& argDeclBases_da5, const Packets_t& members_da7, const Packets_t& localVars_da9, const Packets_t& contexts_dab, const Packets_t& unaryExprss_dad);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_db3, const Udm::Object& member_dbc, const Udm::Object& localVar_dc5, const Udm::Object& context_dce, const Udm::Object& unaryExprs_dd7);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_da5, const Packets_t& members_da7, const Packets_t& localVars_da9, const Packets_t& contexts_dab, const Packets_t& unaryExprss_dad);
	bool patternMatcher( const Udm::Object& argDeclBase_db1, const Udm::Object& member_dba, const Udm::Object& localVar_dc3, const Udm::Object& context_dcc, const Udm::Object& unaryExprs_dd5);
	void effector();

private:
	Packets_t _argDeclBase_daf;
	Packets_t _member_db8;
	Packets_t _localVar_dc1;
	Packets_t _context_dca;
	Packets_t _unaryExprs_dd3;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_de0;
		SFC::LocalVar member_de1;
		SFC::LocalVar localVar_de2;
		SFC::Arg context_de3;
		SFC::UnaryExprs unaryExprs_de4;
	};

	std::list< Match> _matches;
};

class EdgeTest_df2
{
public:
	void operator()( const Packets_t& events_df3, const Packets_t& argdecls_df5, const Packets_t& members_df7, const Packets_t& oldvals_df9, const Packets_t& contexts_dfb, const Packets_t& initexprs_dfd, Packets_t& argdecls_dff, Packets_t& members_e00, Packets_t& oldvals_e01, Packets_t& contexts_e02, Packets_t& initexprs_e03, Packets_t& argdecls_e04, Packets_t& members_e05, Packets_t& oldvals_e06, Packets_t& contexts_e07, Packets_t& initexprs_e08, Packets_t& argdecls_e09, Packets_t& members_e0a, Packets_t& oldvals_e0b, Packets_t& contexts_e0c, Packets_t& initexprs_e0d);

protected:
	void executeOne( const Packets_t& events_df3, const Packets_t& argdecls_df5, const Packets_t& members_df7, const Packets_t& oldvals_df9, const Packets_t& contexts_dfb, const Packets_t& initexprs_dfd);
	bool isInputUnique( const Udm::Object& event_e1f, const Udm::Object& argdecl_e26, const Udm::Object& member_e2d, const Udm::Object& oldval_e34, const Udm::Object& context_e3b, const Udm::Object& initexpr_e42);

private:
	Packets_t* _argdecl_e0e;
	Packets_t* _member_e0f;
	Packets_t* _oldval_e10;
	Packets_t* _context_e11;
	Packets_t* _initexpr_e12;
	Packets_t* _argdecl_e13;
	Packets_t* _member_e14;
	Packets_t* _oldval_e15;
	Packets_t* _context_e16;
	Packets_t* _initexpr_e17;
	Packets_t* _argdecl_e18;
	Packets_t* _member_e19;
	Packets_t* _oldval_e1a;
	Packets_t* _context_e1b;
	Packets_t* _initexpr_e1c;
	Packets_t _event_e1d;
	Packets_t _argdecl_e24;
	Packets_t _member_e2b;
	Packets_t _oldval_e32;
	Packets_t _context_e39;
	Packets_t _initexpr_e40;
};

class RisingEdge_e47
{
public:
	bool operator()( const Packets_t& events_e48, const Packets_t& argDeclBases_e4a, const Packets_t& members_e4d, const Packets_t& localVars_e50, const Packets_t& contexts_e53, const Packets_t& unaryExprss_e56, Packets_t& argDeclBases_e4c, Packets_t& members_e4f, Packets_t& localVars_e52, Packets_t& contexts_e55, Packets_t& unaryExprss_e58);

protected:
	bool isInputUnique( const Udm::Object& event_e62, const Udm::Object& argDeclBase_e6b, const Udm::Object& member_e74, const Udm::Object& localVar_e7d, const Udm::Object& context_e86, const Udm::Object& unaryExprs_e8f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, ESMoL::Event& Event, SFC::LocalVar& LocalVar, SFC::LocalVar& Member, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& events_e48, const Packets_t& argDeclBases_e4a, const Packets_t& members_e4d, const Packets_t& localVars_e50, const Packets_t& contexts_e53, const Packets_t& unaryExprss_e56);
	bool patternMatcher( const Udm::Object& event_e60, const Udm::Object& argDeclBase_e69, const Udm::Object& member_e72, const Udm::Object& localVar_e7b, const Udm::Object& context_e84, const Udm::Object& unaryExprs_e8d);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_ea4, const SFC::LocalVar& member_ea6, const SFC::LocalVar& localVar_ea8, const SFC::Arg& context_eaa, const SFC::UnaryExprs& unaryExprs_eac);

private:
	Packets_t* _argDeclBase_e59;
	Packets_t* _member_e5a;
	Packets_t* _localVar_e5b;
	Packets_t* _context_e5c;
	Packets_t* _unaryExprs_e5d;
	Packets_t _event_e5e;
	Packets_t _argDeclBase_e67;
	Packets_t _member_e70;
	Packets_t _localVar_e79;
	Packets_t _context_e82;
	Packets_t _unaryExprs_e8b;
	class Match
	{
	public:
		ESMoL::Event event_e98;
		SFC::ArgDeclBase argDeclBase_e99;
		SFC::LocalVar member_e9a;
		SFC::LocalVar localVar_e9b;
		SFC::Arg context_e9c;
		SFC::UnaryExprs unaryExprs_e9d;
	};

	std::list< Match> _matches;
};

class FallingEdge_eae
{
public:
	bool operator()( const Packets_t& events_eaf, const Packets_t& argDeclBases_eb1, const Packets_t& members_eb4, const Packets_t& localVars_eb7, const Packets_t& contexts_eba, const Packets_t& unaryExprss_ebd, Packets_t& argDeclBases_eb3, Packets_t& members_eb6, Packets_t& localVars_eb9, Packets_t& contexts_ebc, Packets_t& unaryExprss_ebf);

protected:
	bool isInputUnique( const Udm::Object& event_ec9, const Udm::Object& argDeclBase_ed2, const Udm::Object& member_edb, const Udm::Object& localVar_ee4, const Udm::Object& context_eed, const Udm::Object& unaryExprs_ef6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, ESMoL::Event& Event, SFC::LocalVar& LocalVar, SFC::LocalVar& Member, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& events_eaf, const Packets_t& argDeclBases_eb1, const Packets_t& members_eb4, const Packets_t& localVars_eb7, const Packets_t& contexts_eba, const Packets_t& unaryExprss_ebd);
	bool patternMatcher( const Udm::Object& event_ec7, const Udm::Object& argDeclBase_ed0, const Udm::Object& member_ed9, const Udm::Object& localVar_ee2, const Udm::Object& context_eeb, const Udm::Object& unaryExprs_ef4);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_f0b, const SFC::LocalVar& member_f0d, const SFC::LocalVar& localVar_f0f, const SFC::Arg& context_f11, const SFC::UnaryExprs& unaryExprs_f13);

private:
	Packets_t* _argDeclBase_ec0;
	Packets_t* _member_ec1;
	Packets_t* _localVar_ec2;
	Packets_t* _context_ec3;
	Packets_t* _unaryExprs_ec4;
	Packets_t _event_ec5;
	Packets_t _argDeclBase_ece;
	Packets_t _member_ed7;
	Packets_t _localVar_ee0;
	Packets_t _context_ee9;
	Packets_t _unaryExprs_ef2;
	class Match
	{
	public:
		ESMoL::Event event_eff;
		SFC::ArgDeclBase argDeclBase_f00;
		SFC::LocalVar member_f01;
		SFC::LocalVar localVar_f02;
		SFC::Arg context_f03;
		SFC::UnaryExprs unaryExprs_f04;
	};

	std::list< Match> _matches;
};

class EitherEdge_f15
{
public:
	bool operator()( const Packets_t& events_f16, const Packets_t& argDeclBases_f18, const Packets_t& members_f1b, const Packets_t& localVars_f1e, const Packets_t& contexts_f21, const Packets_t& unaryExprss_f24, Packets_t& argDeclBases_f1a, Packets_t& members_f1d, Packets_t& localVars_f20, Packets_t& contexts_f23, Packets_t& unaryExprss_f26);

protected:
	bool isInputUnique( const Udm::Object& event_f30, const Udm::Object& argDeclBase_f39, const Udm::Object& member_f42, const Udm::Object& localVar_f4b, const Udm::Object& context_f54, const Udm::Object& unaryExprs_f5d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, ESMoL::Event& Event, SFC::LocalVar& LocalVar, SFC::LocalVar& Member, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& events_f16, const Packets_t& argDeclBases_f18, const Packets_t& members_f1b, const Packets_t& localVars_f1e, const Packets_t& contexts_f21, const Packets_t& unaryExprss_f24);
	bool patternMatcher( const Udm::Object& event_f2e, const Udm::Object& argDeclBase_f37, const Udm::Object& member_f40, const Udm::Object& localVar_f49, const Udm::Object& context_f52, const Udm::Object& unaryExprs_f5b);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_f72, const SFC::LocalVar& member_f74, const SFC::LocalVar& localVar_f76, const SFC::Arg& context_f78, const SFC::UnaryExprs& unaryExprs_f7a);

private:
	Packets_t* _argDeclBase_f27;
	Packets_t* _member_f28;
	Packets_t* _localVar_f29;
	Packets_t* _context_f2a;
	Packets_t* _unaryExprs_f2b;
	Packets_t _event_f2c;
	Packets_t _argDeclBase_f35;
	Packets_t _member_f3e;
	Packets_t _localVar_f47;
	Packets_t _context_f50;
	Packets_t _unaryExprs_f59;
	class Match
	{
	public:
		ESMoL::Event event_f66;
		SFC::ArgDeclBase argDeclBase_f67;
		SFC::LocalVar member_f68;
		SFC::LocalVar localVar_f69;
		SFC::Arg context_f6a;
		SFC::UnaryExprs unaryExprs_f6b;
	};

	std::list< Match> _matches;
};

class AddTriggerVar_f7c
{
public:
	void operator()( const Packets_t& charts_f7d, const Packets_t& argDeclBases_f80, const Packets_t& structs_f83, const Packets_t& localVars_f86, const Packets_t& contexts_f89, const Packets_t& functions_f8d, Packets_t& charts_f7f, Packets_t& argDeclBases_f82, Packets_t& structs_f85, Packets_t& localVars_f88, Packets_t& contexts_f8b, Packets_t& triggerVars_f8c, Packets_t& functions_f8f);

protected:
	bool isInputUnique( const Udm::Object& chart_f9b, const Udm::Object& argDeclBase_fa4, const Udm::Object& struct_fad, const Udm::Object& localVar_fb6, const Udm::Object& context_fbf, const Udm::Object& function_fc8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& charts_f7d, const Packets_t& argDeclBases_f80, const Packets_t& structs_f83, const Packets_t& localVars_f86, const Packets_t& contexts_f89, const Packets_t& functions_f8d);
	bool patternMatcher( const Udm::Object& chart_f99, const Udm::Object& argDeclBase_fa2, const Udm::Object& struct_fab, const Udm::Object& localVar_fb4, const Udm::Object& context_fbd, const Udm::Object& function_fc6);
	void effector();
	void outputAppender( const ESMoL::Subsystem& chart_fd8, const SFC::ArgDeclBase& argDeclBase_fda, const SFC::Struct& struct_fdc, const SFC::LocalVar& localVar_fde, const SFC::Arg& context_fe0, const SFC::LocalVar& triggerVar_fe2, const SFC::Function& function_fe4);

private:
	Packets_t* _chart_f90;
	Packets_t* _argDeclBase_f91;
	Packets_t* _struct_f92;
	Packets_t* _localVar_f93;
	Packets_t* _context_f94;
	Packets_t* _triggerVar_f95;
	Packets_t* _function_f96;
	Packets_t _chart_f97;
	Packets_t _argDeclBase_fa0;
	Packets_t _struct_fa9;
	Packets_t _localVar_fb2;
	Packets_t _context_fbb;
	Packets_t _function_fc4;
	class Match
	{
	public:
		ESMoL::Subsystem chart_fd1;
		SFC::ArgDeclBase argDeclBase_fd2;
		SFC::Struct struct_fd3;
		SFC::LocalVar localVar_fd4;
		SFC::Arg context_fd5;
		SFC::Function function_fd6;
	};

	std::list< Match> _matches;
};

class StartAssignment_fe6
{
public:
	void operator()( const Packets_t& charts_fe8, const Packets_t& argDeclBases_fea, const Packets_t& structs_fee, const Packets_t& oldvals_ff0, const Packets_t& contexts_ff3, const Packets_t& triggerVars_ff6, const Packets_t& functions_ff8, Packets_t& events_fe7, Packets_t& argDeclBases_fec, Packets_t& localVars_fed, Packets_t& oldvals_ff2, Packets_t& contexts_ff5, Packets_t& unaryExprss_ffa);

protected:
	bool isInputUnique( const Udm::Object& chart_1005, const Udm::Object& argDeclBase_100e, const Udm::Object& struct_1017, const Udm::Object& oldval_1020, const Udm::Object& context_1029, const Udm::Object& triggerVar_1032, const Udm::Object& function_103b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, ESMoL::Subsystem& Chart, ESMoL::ConnectorRef& ConnectorRef, SFC::Arg& Context, ESMoL::Event& Event, SFC::Function& Function, SFC::LocalVar& LocalVar, ESMoL::Primitive& Primitive, ESMoL::State& State, SFC::Struct& Struct, SFC::LocalVar& TriggerVar, SFC::LocalVar& oldval);
	void processInputPackets( const Packets_t& charts_fe8, const Packets_t& argDeclBases_fea, const Packets_t& structs_fee, const Packets_t& oldvals_ff0, const Packets_t& contexts_ff3, const Packets_t& triggerVars_ff6, const Packets_t& functions_ff8);
	bool patternMatcher( const Udm::Object& chart_1003, const Udm::Object& argDeclBase_100c, const Udm::Object& struct_1015, const Udm::Object& oldval_101e, const Udm::Object& context_1027, const Udm::Object& triggerVar_1030, const Udm::Object& function_1039);
	void effector();
	void outputAppender( const ESMoL::Event& event_1070, const SFC::ArgDeclBase& argDeclBase_1072, const SFC::LocalVar& localVar_1074, const SFC::LocalVar& oldval_1076, const SFC::Arg& context_1078, const SFC::UnaryExprs& unaryExprs_107a);

private:
	Packets_t* _event_ffb;
	Packets_t* _argDeclBase_ffc;
	Packets_t* _localVar_ffd;
	Packets_t* _oldval_ffe;
	Packets_t* _context_fff;
	Packets_t* _unaryExprs_1000;
	Packets_t _chart_1001;
	Packets_t _argDeclBase_100a;
	Packets_t _struct_1013;
	Packets_t _oldval_101c;
	Packets_t _context_1025;
	Packets_t _triggerVar_102e;
	Packets_t _function_1037;
	class Match
	{
	public:
		ESMoL::Subsystem chart_1052;
		SFC::ArgDeclBase argDeclBase_1053;
		SFC::Struct struct_1054;
		SFC::LocalVar oldval_1055;
		SFC::Arg context_1056;
		SFC::LocalVar triggerVar_1057;
		SFC::Function function_1058;
		ESMoL::State state_1059;
		ESMoL::Event event_105a;
		ESMoL::Primitive primitive_105b;
		ESMoL::ConnectorRef connectorRef_105c;
		SFC::LocalVar localVar_105d;
	};

	std::list< Match> _matches;
};

class SaveState_10be
{
public:
	void operator()( const Packets_t& systems_10bf, const Packets_t& childsystems_10c1, const Packets_t& argdecls_10c3, const Packets_t& dts_10c5, const Packets_t& oldvals_10c7, const Packets_t& contexts_10c9, const Packets_t& functions_10cb, Packets_t& systems_10cd, Packets_t& childsystems_10ce, Packets_t& dts_10cf, Packets_t& oldvals_10d0, Packets_t& functions_10d1);

protected:
	void callSaveMatrixState_119e( const Packets_t& argdecls_1138, const Packets_t& dts_113a, const Packets_t& oldvals_113c, const Packets_t& contexts_113e, const Packets_t& functions_1140);
	void callSaveStructState_11a4( const Packets_t& argdecls_10d8, const Packets_t& dts_10da, const Packets_t& oldvals_10dc, const Packets_t& contexts_10de, const Packets_t& functions_10e0);

private:
	Packets_t* _system_10d2;
	Packets_t* _childsystem_10d3;
	Packets_t* _dt_10d4;
	Packets_t* _oldval_10d5;
	Packets_t* _function_10d6;
};

class SaveStructState_10d7
{
public:
	void operator()( const Packets_t& argdecls_10d8, const Packets_t& dts_10da, const Packets_t& oldvals_10dc, const Packets_t& contexts_10de, const Packets_t& functions_10e0);

protected:
	void callSaveStructState_1131( const Packets_t& argDeclBases_10e3, const Packets_t& structs_10e5, const Packets_t& localVars_10e7, const Packets_t& contexts_10e9, const Packets_t& functions_10eb);
};

class SaveStructState_10e2
{
public:
	void operator()( const Packets_t& argDeclBases_10e3, const Packets_t& structs_10e5, const Packets_t& localVars_10e7, const Packets_t& contexts_10e9, const Packets_t& functions_10eb);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_10f1, const Udm::Object& struct_10fa, const Udm::Object& localVar_1103, const Udm::Object& context_110c, const Udm::Object& function_1115);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_10e3, const Packets_t& structs_10e5, const Packets_t& localVars_10e7, const Packets_t& contexts_10e9, const Packets_t& functions_10eb);
	bool patternMatcher( const Udm::Object& argDeclBase_10ef, const Udm::Object& struct_10f8, const Udm::Object& localVar_1101, const Udm::Object& context_110a, const Udm::Object& function_1113);
	void effector();

private:
	Packets_t _argDeclBase_10ed;
	Packets_t _struct_10f6;
	Packets_t _localVar_10ff;
	Packets_t _context_1108;
	Packets_t _function_1111;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_1121;
		SFC::Struct struct_1122;
		SFC::LocalVar localVar_1123;
		SFC::Arg context_1124;
		SFC::Function function_1125;
		SFC::LocalVar member_1126;
	};

	std::list< Match> _matches;
};

class SaveMatrixState_1137
{
public:
	void operator()( const Packets_t& argdecls_1138, const Packets_t& dts_113a, const Packets_t& oldvals_113c, const Packets_t& contexts_113e, const Packets_t& functions_1140, Packets_t& argdecls_1142, Packets_t& dts_1143, Packets_t& oldvals_1144, Packets_t& contexts_1145, Packets_t& functions_1146);

protected:
	void callSaveMatrixState_1198( const Packets_t& argDeclBases_114d, const Packets_t& dTs_114f, const Packets_t& localVars_1151, const Packets_t& args_1153, const Packets_t& functions_1155);

private:
	Packets_t* _argdecl_1147;
	Packets_t* _dt_1148;
	Packets_t* _oldval_1149;
	Packets_t* _context_114a;
	Packets_t* _function_114b;
};

class SaveMatrixState_114c
{
public:
	void operator()( const Packets_t& argDeclBases_114d, const Packets_t& dTs_114f, const Packets_t& localVars_1151, const Packets_t& args_1153, const Packets_t& functions_1155);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_115b, const Udm::Object& dT_1164, const Udm::Object& localVar_116d, const Udm::Object& arg_1176, const Udm::Object& function_117f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::ArgDeclBase& ArgDeclBase, SFC::DT& DT, SFC::Function& Function, SFC::LocalVar& LocalVar);
	void processInputPackets( const Packets_t& argDeclBases_114d, const Packets_t& dTs_114f, const Packets_t& localVars_1151, const Packets_t& args_1153, const Packets_t& functions_1155);
	bool patternMatcher( const Udm::Object& argDeclBase_1159, const Udm::Object& dT_1162, const Udm::Object& localVar_116b, const Udm::Object& arg_1174, const Udm::Object& function_117d);
	void effector();

private:
	Packets_t _argDeclBase_1157;
	Packets_t _dT_1160;
	Packets_t _localVar_1169;
	Packets_t _arg_1172;
	Packets_t _function_117b;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_1188;
		SFC::DT dT_1189;
		SFC::LocalVar localVar_118a;
		SFC::Arg arg_118b;
		SFC::Function function_118c;
	};

	std::list< Match> _matches;
};

class AddStateVar_11aa
{
public:
	void operator()( const Packets_t& subsystems_11ab, const Packets_t& triggerPorts_11ae, const Packets_t& argDeclBases_11b1, const Packets_t& dTs_11b5, const Packets_t& functions_11b9, Packets_t& subsystems_11ad, Packets_t& charts_11b0, Packets_t& argDeclBases_11b3, Packets_t& localVars_11b4, Packets_t& dTs_11b7, Packets_t& args_11b8, Packets_t& functions_11bb);

protected:
	bool isInputUnique( const Udm::Object& subsystem_11c7, const Udm::Object& triggerPort_11d0, const Udm::Object& argDeclBase_11d9, const Udm::Object& dT_11e2, const Udm::Object& function_11eb);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_11ab, const Packets_t& triggerPorts_11ae, const Packets_t& argDeclBases_11b1, const Packets_t& dTs_11b5, const Packets_t& functions_11b9);
	bool patternMatcher( const Udm::Object& subsystem_11c5, const Udm::Object& triggerPort_11ce, const Udm::Object& argDeclBase_11d7, const Udm::Object& dT_11e0, const Udm::Object& function_11e9);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_120a, const ESMoL::Subsystem& chart_120c, const SFC::ArgDeclBase& argDeclBase_120e, const SFC::LocalVar& localVar_1210, const SFC::DT& dT_1212, const SFC::Arg& arg_1214, const SFC::Function& function_1216);

private:
	Packets_t* _subsystem_11bc;
	Packets_t* _chart_11bd;
	Packets_t* _argDeclBase_11be;
	Packets_t* _localVar_11bf;
	Packets_t* _dT_11c0;
	Packets_t* _arg_11c1;
	Packets_t* _function_11c2;
	Packets_t _subsystem_11c3;
	Packets_t _triggerPort_11cc;
	Packets_t _argDeclBase_11d5;
	Packets_t _dT_11de;
	Packets_t _function_11e7;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1200;
		ESMoL::TriggerPort triggerPort_1201;
		SFC::ArgDeclBase argDeclBase_1202;
		SFC::DT dT_1203;
		SFC::Function function_1204;
		ESMoL::Subsystem chart_1205;
		SFC::Arg arg_1206;
		SFC::Struct struct_1207;
		SFC::Class class_1208;
	};

	std::list< Match> _matches;
};

class MakeCondition_1218
{
public:
	void operator()( const Packets_t& systems_1219, const Packets_t& childSubsystems_121b, const Packets_t& dts_121d, const Packets_t& oldvals_121f, const Packets_t& functions_1221, Packets_t& systems_1223, Packets_t& childSubsystems_1224, Packets_t& conditionals_1225);

protected:
	void callCreateConditional_151c( const Packets_t& subsystems_14c0, const Packets_t& charts_14c3, const Packets_t& dTs_14c6, const Packets_t& localVars_14c9, const Packets_t& functions_14cd);
	void callSetMatrixCondition_1522( const Packets_t& dts_1482, const Packets_t& triggervars_1484, const Packets_t& conditions_1486);
	void callSetStructCondition_1526( const Packets_t& dts_122a, const Packets_t& oldvals_122c, const Packets_t& conditions_122e);

private:
	Packets_t* _system_1226;
	Packets_t* _childSubsystem_1227;
	Packets_t* _conditional_1228;
};

class SetStructCondition_1229
{
public:
	void operator()( const Packets_t& dts_122a, const Packets_t& oldvals_122c, const Packets_t& conditions_122e);

protected:
	void callStartCondition_1474( const Packets_t& structs_1231, const Packets_t& triggerVars_1234, const Packets_t& userCodes_1237);
	void callgetStructMembers_1478( const Packets_t& structs_1438, const Packets_t& triggerVars_143c, const Packets_t& unaryExprss_143f);
	void callPlaceMember_147c( const Packets_t& structs_1267, const Packets_t& members_1269, const Packets_t& trigvars_126b, const Packets_t& condexprs_126d);
};

class StartCondition_1230
{
public:
	void operator()( const Packets_t& structs_1231, const Packets_t& triggerVars_1234, const Packets_t& userCodes_1237, Packets_t& structs_1233, Packets_t& triggerVars_1236, Packets_t& unaryExprss_1239);

protected:
	bool isInputUnique( const Udm::Object& struct_1241, const Udm::Object& triggerVar_124a, const Udm::Object& userCode_1253);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1231, const Packets_t& triggerVars_1234, const Packets_t& userCodes_1237);
	bool patternMatcher( const Udm::Object& struct_123f, const Udm::Object& triggerVar_1248, const Udm::Object& userCode_1251);
	void effector();
	void outputAppender( const SFC::Struct& struct_1260, const SFC::LocalVar& triggerVar_1262, const SFC::UnaryExprs& unaryExprs_1264);

private:
	Packets_t* _struct_123a;
	Packets_t* _triggerVar_123b;
	Packets_t* _unaryExprs_123c;
	Packets_t _struct_123d;
	Packets_t _triggerVar_1246;
	Packets_t _userCode_124f;
	class Match
	{
	public:
		SFC::Struct struct_125c;
		SFC::LocalVar triggerVar_125d;
		SFC::UserCode userCode_125e;
	};

	std::list< Match> _matches;
};

class PlaceMember_1266
{
public:
	void operator()( const Packets_t& structs_1267, const Packets_t& members_1269, const Packets_t& trigvars_126b, const Packets_t& condexprs_126d);

protected:
	void executeOne( const Packets_t& structs_1267, const Packets_t& members_1269, const Packets_t& trigvars_126b, const Packets_t& condexprs_126d);
	bool isInputUnique( const Udm::Object& struct_1271, const Udm::Object& member_1278, const Udm::Object& trigvar_127f, const Udm::Object& condexpr_1286);
	void callTriggerTest_1428( const Packets_t& structs_1319, const Packets_t& members_131b, const Packets_t& trigvars_131d, const Packets_t& condexprs_131f);
	void callAddTrigger_142d( const Packets_t& structs_128c, const Packets_t& members_128e, const Packets_t& trigvars_1290, const Packets_t& condexprs_1292);
	void callTraverseBinary_1432( const Packets_t& structs_13dc, const Packets_t& members_13df, const Packets_t& triggerVars_13e2, const Packets_t& unaryExprss_13e5);

private:
	Packets_t _struct_126f;
	Packets_t _member_1276;
	Packets_t _trigvar_127d;
	Packets_t _condexpr_1284;
};

class AddTrigger_128b
{
public:
	void operator()( const Packets_t& structs_128c, const Packets_t& members_128e, const Packets_t& trigvars_1290, const Packets_t& condexprs_1292);

protected:
	void callAddLastTrigger_130e( const Packets_t& structs_1295, const Packets_t& members_1297, const Packets_t& triggerVars_1299, const Packets_t& unaryExprss_129b);
	void callAddNextTrigger_1313( const Packets_t& structs_12d1, const Packets_t& members_12d3, const Packets_t& triggerVars_12d5, const Packets_t& unaryExprss_12d7);
};

class AddLastTrigger_1294
{
public:
	void operator()( const Packets_t& structs_1295, const Packets_t& members_1297, const Packets_t& triggerVars_1299, const Packets_t& unaryExprss_129b);

protected:
	bool isInputUnique( const Udm::Object& struct_12a1, const Udm::Object& member_12aa, const Udm::Object& triggerVar_12b3, const Udm::Object& unaryExprs_12bc);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::LocalVar& Member, SFC::Struct& Struct, SFC::LocalVar& TriggerVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& structs_1295, const Packets_t& members_1297, const Packets_t& triggerVars_1299, const Packets_t& unaryExprss_129b);
	bool patternMatcher( const Udm::Object& struct_129f, const Udm::Object& member_12a8, const Udm::Object& triggerVar_12b1, const Udm::Object& unaryExprs_12ba);
	void effector();

private:
	Packets_t _struct_129d;
	Packets_t _member_12a6;
	Packets_t _triggerVar_12af;
	Packets_t _unaryExprs_12b8;
	class Match
	{
	public:
		SFC::Struct struct_12c5;
		SFC::LocalVar member_12c6;
		SFC::LocalVar triggerVar_12c7;
		SFC::UnaryExprs unaryExprs_12c8;
	};

	std::list< Match> _matches;
};

class AddNextTrigger_12d0
{
public:
	void operator()( const Packets_t& structs_12d1, const Packets_t& members_12d3, const Packets_t& triggerVars_12d5, const Packets_t& unaryExprss_12d7);

protected:
	bool isInputUnique( const Udm::Object& struct_12dd, const Udm::Object& member_12e6, const Udm::Object& triggerVar_12ef, const Udm::Object& unaryExprs_12f8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::LocalVar& Member, SFC::Struct& Struct, SFC::LocalVar& TriggerVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& structs_12d1, const Packets_t& members_12d3, const Packets_t& triggerVars_12d5, const Packets_t& unaryExprss_12d7);
	bool patternMatcher( const Udm::Object& struct_12db, const Udm::Object& member_12e4, const Udm::Object& triggerVar_12ed, const Udm::Object& unaryExprs_12f6);
	void effector();

private:
	Packets_t _struct_12d9;
	Packets_t _member_12e2;
	Packets_t _triggerVar_12eb;
	Packets_t _unaryExprs_12f4;
	class Match
	{
	public:
		SFC::Struct struct_1301;
		SFC::LocalVar member_1302;
		SFC::LocalVar triggerVar_1303;
		SFC::UnaryExprs unaryExprs_1304;
	};

	std::list< Match> _matches;
};

class TriggerTest_1318
{
public:
	void operator()( const Packets_t& structs_1319, const Packets_t& members_131b, const Packets_t& trigvars_131d, const Packets_t& condexprs_131f, Packets_t& structs_1321, Packets_t& members_1322, Packets_t& trigvars_1323, Packets_t& condexprs_1324, Packets_t& structs_1325, Packets_t& members_1326, Packets_t& trigvars_1327, Packets_t& condexprs_1328);

protected:
	void executeOne( const Packets_t& structs_1319, const Packets_t& members_131b, const Packets_t& trigvars_131d, const Packets_t& condexprs_131f);
	bool isInputUnique( const Udm::Object& struct_1333, const Udm::Object& member_133a, const Udm::Object& trigvar_1341, const Udm::Object& condexpr_1348);

private:
	Packets_t* _struct_1329;
	Packets_t* _member_132a;
	Packets_t* _trigvar_132b;
	Packets_t* _condexpr_132c;
	Packets_t* _struct_132d;
	Packets_t* _member_132e;
	Packets_t* _trigvar_132f;
	Packets_t* _condexpr_1330;
	Packets_t _struct_1331;
	Packets_t _member_1338;
	Packets_t _trigvar_133f;
	Packets_t _condexpr_1346;
};

class HasBinaryExprs_134d
{
public:
	bool operator()( const Packets_t& structs_134e, const Packets_t& members_1351, const Packets_t& triggerVars_1354, const Packets_t& unaryExprss_1357, Packets_t& structs_1350, Packets_t& members_1353, Packets_t& triggerVars_1356, Packets_t& unaryExprss_1359);

protected:
	bool isInputUnique( const Udm::Object& struct_1362, const Udm::Object& member_136b, const Udm::Object& triggerVar_1374, const Udm::Object& unaryExprs_137d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_134e, const Packets_t& members_1351, const Packets_t& triggerVars_1354, const Packets_t& unaryExprss_1357);
	bool patternMatcher( const Udm::Object& struct_1360, const Udm::Object& member_1369, const Udm::Object& triggerVar_1372, const Udm::Object& unaryExprs_137b);
	void outputAppender( const SFC::Struct& struct_138e, const SFC::LocalVar& member_1390, const SFC::LocalVar& triggerVar_1392, const SFC::UnaryExprs& unaryExprs_1394);

private:
	Packets_t* _struct_135a;
	Packets_t* _member_135b;
	Packets_t* _triggerVar_135c;
	Packets_t* _unaryExprs_135d;
	Packets_t _struct_135e;
	Packets_t _member_1367;
	Packets_t _triggerVar_1370;
	Packets_t _unaryExprs_1379;
	class Match
	{
	public:
		SFC::Struct struct_1389;
		SFC::LocalVar member_138a;
		SFC::LocalVar triggerVar_138b;
		SFC::UnaryExprs unaryExprs_138c;
		SFC::BinaryExprs binaryExprs_138d;
	};

	std::list< Match> _matches;
};

class Otherwise_1396
{
public:
	bool operator()( const Packets_t& structs_1397, const Packets_t& members_139a, const Packets_t& triggerVars_139d, const Packets_t& unaryExprss_13a0, Packets_t& structs_1399, Packets_t& members_139c, Packets_t& triggerVars_139f, Packets_t& unaryExprss_13a2);

protected:
	bool isInputUnique( const Udm::Object& struct_13ab, const Udm::Object& member_13b4, const Udm::Object& triggerVar_13bd, const Udm::Object& unaryExprs_13c6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1397, const Packets_t& members_139a, const Packets_t& triggerVars_139d, const Packets_t& unaryExprss_13a0);
	bool patternMatcher( const Udm::Object& struct_13a9, const Udm::Object& member_13b2, const Udm::Object& triggerVar_13bb, const Udm::Object& unaryExprs_13c4);
	void outputAppender( const SFC::Struct& struct_13d3, const SFC::LocalVar& member_13d5, const SFC::LocalVar& triggerVar_13d7, const SFC::UnaryExprs& unaryExprs_13d9);

private:
	Packets_t* _struct_13a3;
	Packets_t* _member_13a4;
	Packets_t* _triggerVar_13a5;
	Packets_t* _unaryExprs_13a6;
	Packets_t _struct_13a7;
	Packets_t _member_13b0;
	Packets_t _triggerVar_13b9;
	Packets_t _unaryExprs_13c2;
	class Match
	{
	public:
		SFC::Struct struct_13cf;
		SFC::LocalVar member_13d0;
		SFC::LocalVar triggerVar_13d1;
		SFC::UnaryExprs unaryExprs_13d2;
	};

	std::list< Match> _matches;
};

class TraverseBinary_13db
{
public:
	void operator()( const Packets_t& structs_13dc, const Packets_t& members_13df, const Packets_t& triggerVars_13e2, const Packets_t& unaryExprss_13e5, Packets_t& structs_13de, Packets_t& members_13e1, Packets_t& triggerVars_13e4, Packets_t& unaryExprss_13e7);

protected:
	bool isInputUnique( const Udm::Object& struct_13f0, const Udm::Object& member_13f9, const Udm::Object& triggerVar_1402, const Udm::Object& unaryExprs_140b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_13dc, const Packets_t& members_13df, const Packets_t& triggerVars_13e2, const Packets_t& unaryExprss_13e5);
	bool patternMatcher( const Udm::Object& struct_13ee, const Udm::Object& member_13f7, const Udm::Object& triggerVar_1400, const Udm::Object& unaryExprs_1409);
	void effector();
	void outputAppender( const SFC::Struct& struct_1420, const SFC::LocalVar& member_1422, const SFC::LocalVar& triggerVar_1424, const SFC::UnaryExprs& unaryExprs_1426);

private:
	Packets_t* _struct_13e8;
	Packets_t* _member_13e9;
	Packets_t* _triggerVar_13ea;
	Packets_t* _unaryExprs_13eb;
	Packets_t _struct_13ec;
	Packets_t _member_13f5;
	Packets_t _triggerVar_13fe;
	Packets_t _unaryExprs_1407;
	class Match
	{
	public:
		SFC::Struct struct_141a;
		SFC::LocalVar member_141b;
		SFC::LocalVar triggerVar_141c;
		SFC::UnaryExprs unaryExprs_141d;
		SFC::BinaryExprs binaryExprs_141e;
		SFC::UnaryExprs unaryExprs_141f;
	};

	std::list< Match> _matches;
};

class GetStructMembers_1437
{
public:
	void operator()( const Packets_t& structs_1438, const Packets_t& triggerVars_143c, const Packets_t& unaryExprss_143f, Packets_t& structs_143a, Packets_t& members_143b, Packets_t& triggerVars_143e, Packets_t& unaryExprss_1441);

protected:
	bool isInputUnique( const Udm::Object& struct_144a, const Udm::Object& triggerVar_1453, const Udm::Object& unaryExprs_145c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1438, const Packets_t& triggerVars_143c, const Packets_t& unaryExprss_143f);
	bool patternMatcher( const Udm::Object& struct_1448, const Udm::Object& triggerVar_1451, const Udm::Object& unaryExprs_145a);
	void effector();
	void outputAppender( const SFC::Struct& struct_146c, const SFC::LocalVar& member_146e, const SFC::LocalVar& triggerVar_1470, const SFC::UnaryExprs& unaryExprs_1472);
	void sortOutputs();

private:
	Packets_t* _struct_1442;
	Packets_t* _member_1443;
	Packets_t* _triggerVar_1444;
	Packets_t* _unaryExprs_1445;
	Packets_t _struct_1446;
	Packets_t _triggerVar_144f;
	Packets_t _unaryExprs_1458;
	class Match
	{
	public:
		SFC::Struct struct_1468;
		SFC::LocalVar triggerVar_1469;
		SFC::UnaryExprs unaryExprs_146a;
		SFC::LocalVar member_146b;
	};

	std::list< Match> _matches;
};

class SetMatrixCondition_1481
{
public:
	void operator()( const Packets_t& dts_1482, const Packets_t& triggervars_1484, const Packets_t& conditions_1486, Packets_t& dts_1488, Packets_t& triggervars_1489, Packets_t& conditions_148a);

protected:
	void callMatrixCondition_14bb( const Packets_t& dTs_148f, const Packets_t& triggerVars_1491, const Packets_t& conditions_1493);

private:
	Packets_t* _dt_148b;
	Packets_t* _triggervar_148c;
	Packets_t* _condition_148d;
};

class MatrixCondition_148e
{
public:
	void operator()( const Packets_t& dTs_148f, const Packets_t& triggerVars_1491, const Packets_t& conditions_1493);

protected:
	bool isInputUnique( const Udm::Object& dT_1499, const Udm::Object& triggerVar_14a2, const Udm::Object& condition_14ab);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::UserCode& Condition, SFC::DT& DT, SFC::LocalVar& TriggerVar);
	void processInputPackets( const Packets_t& dTs_148f, const Packets_t& triggerVars_1491, const Packets_t& conditions_1493);
	bool patternMatcher( const Udm::Object& dT_1497, const Udm::Object& triggerVar_14a0, const Udm::Object& condition_14a9);
	void effector();

private:
	Packets_t _dT_1495;
	Packets_t _triggerVar_149e;
	Packets_t _condition_14a7;
	class Match
	{
	public:
		SFC::DT dT_14b4;
		SFC::LocalVar triggerVar_14b5;
		SFC::UserCode condition_14b6;
	};

	std::list< Match> _matches;
};

class CreateConditional_14bf
{
public:
	void operator()( const Packets_t& subsystems_14c0, const Packets_t& charts_14c3, const Packets_t& dTs_14c6, const Packets_t& localVars_14c9, const Packets_t& functions_14cd, Packets_t& subsystems_14c2, Packets_t& charts_14c5, Packets_t& dTs_14c8, Packets_t& triggerVars_14cb, Packets_t& userCodes_14cc, Packets_t& conditionalBlocks_14cf);

protected:
	bool isInputUnique( const Udm::Object& subsystem_14da, const Udm::Object& chart_14e3, const Udm::Object& dT_14ec, const Udm::Object& localVar_14f5, const Udm::Object& function_14fe);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_14c0, const Packets_t& charts_14c3, const Packets_t& dTs_14c6, const Packets_t& localVars_14c9, const Packets_t& functions_14cd);
	bool patternMatcher( const Udm::Object& subsystem_14d8, const Udm::Object& chart_14e1, const Udm::Object& dT_14ea, const Udm::Object& localVar_14f3, const Udm::Object& function_14fc);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1510, const ESMoL::Subsystem& chart_1512, const SFC::DT& dT_1514, const SFC::LocalVar& triggerVar_1516, const SFC::UserCode& userCode_1518, const SFC::ConditionalBlock& conditionalBlock_151a);

private:
	Packets_t* _subsystem_14d0;
	Packets_t* _chart_14d1;
	Packets_t* _dT_14d2;
	Packets_t* _triggerVar_14d3;
	Packets_t* _userCode_14d4;
	Packets_t* _conditionalBlock_14d5;
	Packets_t _subsystem_14d6;
	Packets_t _chart_14df;
	Packets_t _dT_14e8;
	Packets_t _localVar_14f1;
	Packets_t _function_14fa;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1508;
		ESMoL::Subsystem chart_1509;
		SFC::DT dT_150a;
		SFC::LocalVar localVar_150b;
		SFC::Function function_150c;
		SFC::LocalVar triggerVar_150d;
	};

	std::list< Match> _matches;
};

class OutputEvent_155c
{
public:
	void operator()( const Packets_t& systems_155d, const Packets_t& childCharts_155f, const Packets_t& states_1561, const Packets_t& functions_1563, const Packets_t& functionCalls_1565);

protected:
	void callCreateOutputEventArgVal_1620( const Packets_t& subsystems_1568, const Packets_t& charts_156c, const Packets_t& states_156e, const Packets_t& mains_1570, const Packets_t& functionCalls_1574);
	void callUpdateArgCount_1626( const Packets_t& subsystems_15cd, const Packets_t& outputPorts_15d0, const Packets_t& functions_15d3, const Packets_t& argVals_15d5, const Packets_t& functionCalls_15d8);
	void callMakeArgDeclRef_162c( const Packets_t& systems_d7, const Packets_t& argPorts_d9, const Packets_t& argVals_db);
};

class CreateOutputEventArgVal_1567
{
public:
	void operator()( const Packets_t& subsystems_1568, const Packets_t& charts_156c, const Packets_t& states_156e, const Packets_t& mains_1570, const Packets_t& functionCalls_1574, Packets_t& subsystems_156a, Packets_t& outputPorts_156b, Packets_t& mains_1572, Packets_t& argVals_1573, Packets_t& functionCalls_1576);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1580, const Udm::Object& chart_1589, const Udm::Object& state_1592, const Udm::Object& main_159b, const Udm::Object& functionCall_15a4);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Subsystem& Chart, ESMoL::Event& Event, SFC::FunctionCall& FunctionCall, SFC::Function& Main, ESMoL::OutputPort& OutputPort, ESMoL::State& State, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_1568, const Packets_t& charts_156c, const Packets_t& states_156e, const Packets_t& mains_1570, const Packets_t& functionCalls_1574);
	bool patternMatcher( const Udm::Object& subsystem_157e, const Udm::Object& chart_1587, const Udm::Object& state_1590, const Udm::Object& main_1599, const Udm::Object& functionCall_15a2);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_15c2, const ESMoL::OutputPort& outputPort_15c4, const SFC::Function& main_15c6, const SFC::ArgVal& argVal_15c8, const SFC::FunctionCall& functionCall_15ca);

private:
	Packets_t* _subsystem_1577;
	Packets_t* _outputPort_1578;
	Packets_t* _main_1579;
	Packets_t* _argVal_157a;
	Packets_t* _functionCall_157b;
	Packets_t _subsystem_157c;
	Packets_t _chart_1585;
	Packets_t _state_158e;
	Packets_t _main_1597;
	Packets_t _functionCall_15a0;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_15b3;
		ESMoL::Subsystem chart_15b4;
		ESMoL::State state_15b5;
		SFC::Function main_15b6;
		SFC::FunctionCall functionCall_15b7;
		ESMoL::OutputPort outputPort_15b8;
		ESMoL::Event event_15b9;
	};

	std::list< Match> _matches;
};

class UpdateArgCount_15cc
{
public:
	void operator()( const Packets_t& subsystems_15cd, const Packets_t& outputPorts_15d0, const Packets_t& functions_15d3, const Packets_t& argVals_15d5, const Packets_t& functionCalls_15d8, Packets_t& subsystems_15cf, Packets_t& outputPorts_15d2, Packets_t& argVals_15d7);

protected:
	bool isInputUnique( const Udm::Object& subsystem_15e1, const Udm::Object& outputPort_15ea, const Udm::Object& function_15f3, const Udm::Object& argVal_15fc, const Udm::Object& functionCall_1605);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::ArgVal& ArgVal, SFC::Function& Function, SFC::FunctionCall& FunctionCall, ESMoL::OutputPort& OutputPort, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_15cd, const Packets_t& outputPorts_15d0, const Packets_t& functions_15d3, const Packets_t& argVals_15d5, const Packets_t& functionCalls_15d8);
	bool patternMatcher( const Udm::Object& subsystem_15df, const Udm::Object& outputPort_15e8, const Udm::Object& function_15f1, const Udm::Object& argVal_15fa, const Udm::Object& functionCall_1603);
	void effector();
	void forwardInputs();

private:
	Packets_t* _subsystem_15da;
	Packets_t* _outputPort_15db;
	Packets_t* _argVal_15dc;
	Packets_t _subsystem_15dd;
	Packets_t _outputPort_15e6;
	Packets_t _function_15ef;
	Packets_t _argVal_15f8;
	Packets_t _functionCall_1601;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1614;
		ESMoL::OutputPort outputPort_1615;
		SFC::Function function_1616;
		SFC::ArgVal argVal_1617;
		SFC::FunctionCall functionCall_1618;
		SFC::Arg arg_1619;
	};

	std::list< Match> _matches;
};

class InputEvent_1630
{
public:
	void operator()( const Packets_t& systems_1631, const Packets_t& childCharts_1633, const Packets_t& states_1635, const Packets_t& functions_1637, const Packets_t& functionCalls_1639, Packets_t& systems_163b, Packets_t& childCharts_163c, Packets_t& states_163d, Packets_t& functions_163e, Packets_t& functionCalls_163f);

protected:
	void callGetOldVar_174c( const Packets_t& blocks_1713, const Packets_t& mains_1715, const Packets_t& functionCalls_1718);
	void callMatrixInputEvent_1750( const Packets_t& oldvars_16c8, const Packets_t& functions_16ca, const Packets_t& functionCalls_16cc);
	void callStructInputEvent_1754( const Packets_t& oldvars_1646, const Packets_t& functions_1648, const Packets_t& functionCalls_164a);

private:
	Packets_t* _system_1640;
	Packets_t* _childChart_1641;
	Packets_t* _state_1642;
	Packets_t* _function_1643;
	Packets_t* _functionCall_1644;
};

class StructInputEvent_1645
{
public:
	void operator()( const Packets_t& oldvars_1646, const Packets_t& functions_1648, const Packets_t& functionCalls_164a);

protected:
	void callStructInputEventArgVal_16bf( const Packets_t& localVars_167e, const Packets_t& mains_1680, const Packets_t& functionCalls_1684);
	void callUpdateArgCount_16c3( const Packets_t& functions_164d, const Packets_t& argVals_164f, const Packets_t& functionCalls_1651);
};

class UpdateArgCount_164c
{
public:
	void operator()( const Packets_t& functions_164d, const Packets_t& argVals_164f, const Packets_t& functionCalls_1651);

protected:
	bool isInputUnique( const Udm::Object& function_1657, const Udm::Object& argVal_1660, const Udm::Object& functionCall_1669);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::ArgVal& ArgVal, SFC::Function& Function, SFC::FunctionCall& FunctionCall);
	void processInputPackets( const Packets_t& functions_164d, const Packets_t& argVals_164f, const Packets_t& functionCalls_1651);
	bool patternMatcher( const Udm::Object& function_1655, const Udm::Object& argVal_165e, const Udm::Object& functionCall_1667);
	void effector();

private:
	Packets_t _function_1653;
	Packets_t _argVal_165c;
	Packets_t _functionCall_1665;
	class Match
	{
	public:
		SFC::Function function_1675;
		SFC::ArgVal argVal_1676;
		SFC::FunctionCall functionCall_1677;
		SFC::Arg arg_1678;
	};

	std::list< Match> _matches;
};

class StructInputEventArgVal_167d
{
public:
	void operator()( const Packets_t& localVars_167e, const Packets_t& mains_1680, const Packets_t& functionCalls_1684, Packets_t& mains_1682, Packets_t& argVals_1683, Packets_t& functionCalls_1686);

protected:
	bool isInputUnique( const Udm::Object& localVar_168e, const Udm::Object& main_1697, const Udm::Object& functionCall_16a0);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& localVars_167e, const Packets_t& mains_1680, const Packets_t& functionCalls_1684);
	bool patternMatcher( const Udm::Object& localVar_168c, const Udm::Object& main_1695, const Udm::Object& functionCall_169e);
	void effector();
	void outputAppender( const SFC::Function& main_16b9, const SFC::ArgVal& argVal_16bb, const SFC::FunctionCall& functionCall_16bd);

private:
	Packets_t* _main_1687;
	Packets_t* _argVal_1688;
	Packets_t* _functionCall_1689;
	Packets_t _localVar_168a;
	Packets_t _main_1693;
	Packets_t _functionCall_169c;
	class Match
	{
	public:
		SFC::LocalVar localVar_16af;
		SFC::Function main_16b0;
		SFC::FunctionCall functionCall_16b1;
		SFC::LocalVar triggerVar_16b2;
		SFC::Struct struct_16b3;
		SFC::LocalVar member_16b4;
	};

	std::list< Match> _matches;
};

class MatrixInputEvent_16c7
{
public:
	void operator()( const Packets_t& oldvars_16c8, const Packets_t& functions_16ca, const Packets_t& functionCalls_16cc, Packets_t& oldvars_16ce, Packets_t& functions_16cf, Packets_t& functionCalls_16d0);

protected:
	void callMatrixInputEventArgVal_170d( const Packets_t& localVars_16d5, const Packets_t& functions_16d7, const Packets_t& functionCalls_16d9);

private:
	Packets_t* _oldvar_16d1;
	Packets_t* _function_16d2;
	Packets_t* _functionCall_16d3;
};

class MatrixInputEventArgVal_16d4
{
public:
	void operator()( const Packets_t& localVars_16d5, const Packets_t& functions_16d7, const Packets_t& functionCalls_16d9);

protected:
	bool isInputUnique( const Udm::Object& localVar_16df, const Udm::Object& function_16e8, const Udm::Object& functionCall_16f1);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::DT& DT, SFC::Function& Function, SFC::FunctionCall& FunctionCall, SFC::LocalVar& LocalVar, SFC::LocalVar& TriggerVar);
	void processInputPackets( const Packets_t& localVars_16d5, const Packets_t& functions_16d7, const Packets_t& functionCalls_16d9);
	bool patternMatcher( const Udm::Object& localVar_16dd, const Udm::Object& function_16e6, const Udm::Object& functionCall_16ef);
	void effector();

private:
	Packets_t _localVar_16db;
	Packets_t _function_16e4;
	Packets_t _functionCall_16ed;
	class Match
	{
	public:
		SFC::LocalVar localVar_16ff;
		SFC::Function function_1700;
		SFC::FunctionCall functionCall_1701;
		SFC::DT dT_1702;
		SFC::LocalVar triggerVar_1703;
		SFC::Arg arg_1704;
	};

	std::list< Match> _matches;
};

class GetOldVar_1711
{
public:
	void operator()( const Packets_t& blocks_1713, const Packets_t& mains_1715, const Packets_t& functionCalls_1718, Packets_t& localVars_1712, Packets_t& mains_1717, Packets_t& functionCalls_171a);

protected:
	bool isInputUnique( const Udm::Object& block_1722, const Udm::Object& main_172b, const Udm::Object& functionCall_1734);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& blocks_1713, const Packets_t& mains_1715, const Packets_t& functionCalls_1718);
	bool patternMatcher( const Udm::Object& block_1720, const Udm::Object& main_1729, const Udm::Object& functionCall_1732);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar_1746, const SFC::Function& main_1748, const SFC::FunctionCall& functionCall_174a);

private:
	Packets_t* _localVar_171b;
	Packets_t* _main_171c;
	Packets_t* _functionCall_171d;
	Packets_t _block_171e;
	Packets_t _main_1727;
	Packets_t _functionCall_1730;
	class Match
	{
	public:
		ESMoL::Subsystem block_1741;
		SFC::Function main_1742;
		SFC::FunctionCall functionCall_1743;
		SFC::LocalVar localVar_1744;
		ESMoL::TriggerPort triggerPort_1745;
	};

	std::list< Match> _matches;
};

class InputData_1758
{
public:
	void operator()( const Packets_t& systems_1759, const Packets_t& childCharts_175b, const Packets_t& states_175d, const Packets_t& functions_175f, const Packets_t& functionCalls_1761, Packets_t& systems_1763, Packets_t& childCharts_1764, Packets_t& states_1765, Packets_t& functions_1766, Packets_t& functionCalls_1767);

protected:
	void callCreateInputDataArgVal_1826( const Packets_t& subsystems_17c2, const Packets_t& charts_17c6, const Packets_t& states_17c8, const Packets_t& mains_17ca, const Packets_t& functionCalls_17ce);
	void callUpdateArgCount_182c( const Packets_t& subsystems_176e, const Packets_t& inputPorts_1771, const Packets_t& functions_1774, const Packets_t& argVals_1776, const Packets_t& functionCalls_1779);
	void callMakeArgDeclRef_1832( const Packets_t& systems_d7, const Packets_t& argPorts_d9, const Packets_t& argVals_db);

private:
	Packets_t* _system_1768;
	Packets_t* _childChart_1769;
	Packets_t* _state_176a;
	Packets_t* _function_176b;
	Packets_t* _functionCall_176c;
};

class UpdateArgCount_176d
{
public:
	void operator()( const Packets_t& subsystems_176e, const Packets_t& inputPorts_1771, const Packets_t& functions_1774, const Packets_t& argVals_1776, const Packets_t& functionCalls_1779, Packets_t& subsystems_1770, Packets_t& inputPorts_1773, Packets_t& argVals_1778);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1782, const Udm::Object& inputPort_178b, const Udm::Object& function_1794, const Udm::Object& argVal_179d, const Udm::Object& functionCall_17a6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::ArgVal& ArgVal, SFC::Function& Function, SFC::FunctionCall& FunctionCall, ESMoL::InputPort& InputPort, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_176e, const Packets_t& inputPorts_1771, const Packets_t& functions_1774, const Packets_t& argVals_1776, const Packets_t& functionCalls_1779);
	bool patternMatcher( const Udm::Object& subsystem_1780, const Udm::Object& inputPort_1789, const Udm::Object& function_1792, const Udm::Object& argVal_179b, const Udm::Object& functionCall_17a4);
	void effector();
	void forwardInputs();

private:
	Packets_t* _subsystem_177b;
	Packets_t* _inputPort_177c;
	Packets_t* _argVal_177d;
	Packets_t _subsystem_177e;
	Packets_t _inputPort_1787;
	Packets_t _function_1790;
	Packets_t _argVal_1799;
	Packets_t _functionCall_17a2;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_17b5;
		ESMoL::InputPort inputPort_17b6;
		SFC::Function function_17b7;
		SFC::ArgVal argVal_17b8;
		SFC::FunctionCall functionCall_17b9;
		SFC::Arg arg_17ba;
	};

	std::list< Match> _matches;
};

class CreateInputDataArgVal_17c1
{
public:
	void operator()( const Packets_t& subsystems_17c2, const Packets_t& charts_17c6, const Packets_t& states_17c8, const Packets_t& mains_17ca, const Packets_t& functionCalls_17ce, Packets_t& subsystems_17c4, Packets_t& inputPorts_17c5, Packets_t& mains_17cc, Packets_t& argVals_17cd, Packets_t& functionCalls_17d0);

protected:
	bool isInputUnique( const Udm::Object& subsystem_17da, const Udm::Object& chart_17e3, const Udm::Object& state_17ec, const Udm::Object& main_17f5, const Udm::Object& functionCall_17fe);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Subsystem& Chart, ESMoL::Data& Data, SFC::FunctionCall& FunctionCall, ESMoL::InputPort& InputPort, SFC::Function& Main, ESMoL::State& State, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_17c2, const Packets_t& charts_17c6, const Packets_t& states_17c8, const Packets_t& mains_17ca, const Packets_t& functionCalls_17ce);
	bool patternMatcher( const Udm::Object& subsystem_17d8, const Udm::Object& chart_17e1, const Udm::Object& state_17ea, const Udm::Object& main_17f3, const Udm::Object& functionCall_17fc);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_181c, const ESMoL::InputPort& inputPort_181e, const SFC::Function& main_1820, const SFC::ArgVal& argVal_1822, const SFC::FunctionCall& functionCall_1824);

private:
	Packets_t* _subsystem_17d1;
	Packets_t* _inputPort_17d2;
	Packets_t* _main_17d3;
	Packets_t* _argVal_17d4;
	Packets_t* _functionCall_17d5;
	Packets_t _subsystem_17d6;
	Packets_t _chart_17df;
	Packets_t _state_17e8;
	Packets_t _main_17f1;
	Packets_t _functionCall_17fa;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_180d;
		ESMoL::Subsystem chart_180e;
		ESMoL::State state_180f;
		SFC::Function main_1810;
		SFC::FunctionCall functionCall_1811;
		ESMoL::InputPort inputPort_1812;
		ESMoL::Data data_1813;
	};

	std::list< Match> _matches;
};

class OutputData_1836
{
public:
	void operator()( const Packets_t& systems_1837, const Packets_t& childCharts_1839, const Packets_t& states_183b, const Packets_t& functions_183d, const Packets_t& functionCalls_183f, Packets_t& systems_1841, Packets_t& childCharts_1842, Packets_t& states_1843, Packets_t& functions_1844, Packets_t& functionCalls_1845);

protected:
	void callCreateOutputDataArgVal_18b0( const Packets_t& subsystems_184c, const Packets_t& charts_1850, const Packets_t& states_1852, const Packets_t& mains_1854, const Packets_t& functionCalls_1858);
	void callUpdateArgCount_18b6( const Packets_t& subsystems_15cd, const Packets_t& outputPorts_15d0, const Packets_t& functions_15d3, const Packets_t& argVals_15d5, const Packets_t& functionCalls_15d8);
	void callMakeArgDeclRef_18bc( const Packets_t& systems_d7, const Packets_t& argPorts_d9, const Packets_t& argVals_db);

private:
	Packets_t* _system_1846;
	Packets_t* _childChart_1847;
	Packets_t* _state_1848;
	Packets_t* _function_1849;
	Packets_t* _functionCall_184a;
};

class CreateOutputDataArgVal_184b
{
public:
	void operator()( const Packets_t& subsystems_184c, const Packets_t& charts_1850, const Packets_t& states_1852, const Packets_t& mains_1854, const Packets_t& functionCalls_1858, Packets_t& subsystems_184e, Packets_t& outputPorts_184f, Packets_t& mains_1856, Packets_t& argVals_1857, Packets_t& functionCalls_185a);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1864, const Udm::Object& chart_186d, const Udm::Object& state_1876, const Udm::Object& main_187f, const Udm::Object& functionCall_1888);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Subsystem& Chart, ESMoL::Data& Data, SFC::FunctionCall& FunctionCall, SFC::Function& Main, ESMoL::OutputPort& OutputPort, ESMoL::State& State, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_184c, const Packets_t& charts_1850, const Packets_t& states_1852, const Packets_t& mains_1854, const Packets_t& functionCalls_1858);
	bool patternMatcher( const Udm::Object& subsystem_1862, const Udm::Object& chart_186b, const Udm::Object& state_1874, const Udm::Object& main_187d, const Udm::Object& functionCall_1886);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_18a6, const ESMoL::OutputPort& outputPort_18a8, const SFC::Function& main_18aa, const SFC::ArgVal& argVal_18ac, const SFC::FunctionCall& functionCall_18ae);

private:
	Packets_t* _subsystem_185b;
	Packets_t* _outputPort_185c;
	Packets_t* _main_185d;
	Packets_t* _argVal_185e;
	Packets_t* _functionCall_185f;
	Packets_t _subsystem_1860;
	Packets_t _chart_1869;
	Packets_t _state_1872;
	Packets_t _main_187b;
	Packets_t _functionCall_1884;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1897;
		ESMoL::Subsystem chart_1898;
		ESMoL::State state_1899;
		SFC::Function main_189a;
		SFC::FunctionCall functionCall_189b;
		ESMoL::OutputPort outputPort_189c;
		ESMoL::Data data_189d;
	};

	std::list< Match> _matches;
};

class CreateFunctionCall_18c0
{
public:
	void operator()( const Packets_t& subsystems_18c1, const Packets_t& charts_18c4, const Packets_t& compoundStatements_18c9, Packets_t& subsystems_18c3, Packets_t& charts_18c6, Packets_t& mains_18c7, Packets_t& functionCalls_18c8);

protected:
	bool isInputUnique( const Udm::Object& subsystem_18d3, const Udm::Object& chart_18dc, const Udm::Object& compoundStatement_18e5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_18c1, const Packets_t& charts_18c4, const Packets_t& compoundStatements_18c9);
	bool patternMatcher( const Udm::Object& subsystem_18d1, const Udm::Object& chart_18da, const Udm::Object& compoundStatement_18e3);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1902, const ESMoL::Subsystem& chart_1904, const SFC::Function& main_1906, const SFC::FunctionCall& functionCall_1908);

private:
	Packets_t* _subsystem_18cb;
	Packets_t* _chart_18cc;
	Packets_t* _main_18cd;
	Packets_t* _functionCall_18ce;
	Packets_t _subsystem_18cf;
	Packets_t _chart_18d8;
	Packets_t _compoundStatement_18e1;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_18f9;
		ESMoL::Subsystem chart_18fa;
		SFC::CompoundStatement compoundStatement_18fb;
		SFC::Class class_18fc;
		SFC::Struct struct_18fd;
		SFC::Arg arg_18fe;
		SFC::Function main_18ff;
	};

	std::list< Match> _matches;
};

class GetState_190a
{
public:
	void operator()( const Packets_t& subsystems_190b, const Packets_t& charts_190e, const Packets_t& mains_1912, const Packets_t& functionCalls_1915, Packets_t& subsystems_190d, Packets_t& charts_1910, Packets_t& states_1911, Packets_t& mains_1914, Packets_t& functionCalls_1917);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1921, const Udm::Object& chart_192a, const Udm::Object& main_1933, const Udm::Object& functionCall_193c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_190b, const Packets_t& charts_190e, const Packets_t& mains_1912, const Packets_t& functionCalls_1915);
	bool patternMatcher( const Udm::Object& subsystem_191f, const Udm::Object& chart_1928, const Udm::Object& main_1931, const Udm::Object& functionCall_193a);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1954, const ESMoL::Subsystem& chart_1956, const ESMoL::State& state_1958, const SFC::Function& main_195a, const SFC::FunctionCall& functionCall_195c);

private:
	Packets_t* _subsystem_1918;
	Packets_t* _chart_1919;
	Packets_t* _state_191a;
	Packets_t* _main_191b;
	Packets_t* _functionCall_191c;
	Packets_t _subsystem_191d;
	Packets_t _chart_1926;
	Packets_t _main_192f;
	Packets_t _functionCall_1938;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_194d;
		ESMoL::Subsystem chart_194e;
		SFC::Function main_194f;
		SFC::FunctionCall functionCall_1950;
		ESMoL::State state_1951;
		ESMoL::Primitive primitive_1952;
		ESMoL::ConnectorRef connectorRef_1953;
	};

	std::list< Match> _matches;
};

class PrimitiveChildBlock_1983
{
public:
	void operator()( const Packets_t& childPrimitives_1984, const Packets_t& systemFunctions_1986);

protected:
	void callCreateCGCall_1bd4( const Packets_t& childPrimitives_1aab, const Packets_t& systemFunctions_1aad);
	void callCallCG_1bd7( const Packets_t& primitives_1a8a, const Packets_t& compoundStatements_1a8d);
	void callSetupIfVar_1bda( const Packets_t& childPrimitives_1989, const Packets_t& systemFunctions_198b);
};

class SetupIfVar_1988
{
public:
	void operator()( const Packets_t& childPrimitives_1989, const Packets_t& systemFunctions_198b);

protected:
	void callGetIfAndSwitchCaseBlocks_1a7a( const Packets_t& childPrimitives_19d1, const Packets_t& systemFunctions_19d3);
	void callMakeIfVar_1a7d( const Packets_t& primitives_1a0f, const Packets_t& compoundStatements_1a13);
	void callGetIfOutputPorts_1a80( const Packets_t& primitives_1a3e, const Packets_t& localVars_1a42, const Packets_t& conditionalGroups_1a45);
	void callAssignIfVar_1a84( const Packets_t& primitives_198e, const Packets_t& outputPorts_1990, const Packets_t& ifVars_1992, const Packets_t& conditionalGroups_1994);
};

class AssignIfVar_198d
{
public:
	void operator()( const Packets_t& primitives_198e, const Packets_t& outputPorts_1990, const Packets_t& ifVars_1992, const Packets_t& conditionalGroups_1994);

protected:
	bool isInputUnique( const Udm::Object& primitive_199a, const Udm::Object& outputPort_19a3, const Udm::Object& ifVar_19ac, const Udm::Object& conditionalGroup_19b5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_198e, const Packets_t& outputPorts_1990, const Packets_t& ifVars_1992, const Packets_t& conditionalGroups_1994);
	bool patternMatcher( const Udm::Object& primitive_1998, const Udm::Object& outputPort_19a1, const Udm::Object& ifVar_19aa, const Udm::Object& conditionalGroup_19b3);
	void effector();

private:
	Packets_t _primitive_1996;
	Packets_t _outputPort_199f;
	Packets_t _ifVar_19a8;
	Packets_t _conditionalGroup_19b1;
	class Match
	{
	public:
		ESMoL::Primitive primitive_19c2;
		ESMoL::OutputPort outputPort_19c3;
		SFC::LocalVar ifVar_19c4;
		SFC::ConditionalGroup conditionalGroup_19c5;
		SFC::ArgDeclBase argDeclBase_19c6;
	};

	std::list< Match> _matches;
};

class GetIfAndSwitchCaseBlocks_19d0
{
public:
	void operator()( const Packets_t& childPrimitives_19d1, const Packets_t& systemFunctions_19d3, Packets_t& childPrimitives_19d5, Packets_t& systemFunctions_19d6);

protected:
	void executeOne( const Packets_t& childPrimitives_19d1, const Packets_t& systemFunctions_19d3);
	bool isInputUnique( const Udm::Object& childPrimitive_19db, const Udm::Object& systemFunction_19e2);

private:
	Packets_t* _childPrimitive_19d7;
	Packets_t* _systemFunction_19d8;
	Packets_t _childPrimitive_19d9;
	Packets_t _systemFunction_19e0;
};

class Case_19e7
{
public:
	bool operator()( const Packets_t& primitives_19e8, const Packets_t& compoundStatements_19eb, Packets_t& primitives_19ea, Packets_t& compoundStatements_19ed);

protected:
	bool isInputUnique( const Udm::Object& primitive_19f4, const Udm::Object& compoundStatement_19fd);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::CompoundStatement& CompoundStatement, ESMoL::Primitive& Primitive);
	void processInputPackets( const Packets_t& primitives_19e8, const Packets_t& compoundStatements_19eb);
	bool patternMatcher( const Udm::Object& primitive_19f2, const Udm::Object& compoundStatement_19fb);
	void outputAppender( const ESMoL::Primitive& primitive_1a0a, const SFC::CompoundStatement& compoundStatement_1a0c);

private:
	Packets_t* _primitive_19ee;
	Packets_t* _compoundStatement_19ef;
	Packets_t _primitive_19f0;
	Packets_t _compoundStatement_19f9;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1a06;
		SFC::CompoundStatement compoundStatement_1a07;
	};

	std::list< Match> _matches;
};

class MakeIfVar_1a0e
{
public:
	void operator()( const Packets_t& primitives_1a0f, const Packets_t& compoundStatements_1a13, Packets_t& primitives_1a11, Packets_t& localVars_1a12, Packets_t& conditionalGroups_1a15);

protected:
	bool isInputUnique( const Udm::Object& primitive_1a1d, const Udm::Object& compoundStatement_1a26);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1a0f, const Packets_t& compoundStatements_1a13);
	bool patternMatcher( const Udm::Object& primitive_1a1b, const Udm::Object& compoundStatement_1a24);
	void effector();
	void outputAppender( const ESMoL::Primitive& primitive_1a37, const SFC::LocalVar& localVar_1a39, const SFC::ConditionalGroup& conditionalGroup_1a3b);

private:
	Packets_t* _primitive_1a16;
	Packets_t* _localVar_1a17;
	Packets_t* _conditionalGroup_1a18;
	Packets_t _primitive_1a19;
	Packets_t _compoundStatement_1a22;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1a2f;
		SFC::CompoundStatement compoundStatement_1a30;
	};

	std::list< Match> _matches;
};

class GetIfOutputPorts_1a3d
{
public:
	void operator()( const Packets_t& primitives_1a3e, const Packets_t& localVars_1a42, const Packets_t& conditionalGroups_1a45, Packets_t& primitives_1a40, Packets_t& outputPorts_1a41, Packets_t& localVars_1a44, Packets_t& conditionalGroups_1a47);

protected:
	bool isInputUnique( const Udm::Object& primitive_1a50, const Udm::Object& localVar_1a59, const Udm::Object& conditionalGroup_1a62);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1a3e, const Packets_t& localVars_1a42, const Packets_t& conditionalGroups_1a45);
	bool patternMatcher( const Udm::Object& primitive_1a4e, const Udm::Object& localVar_1a57, const Udm::Object& conditionalGroup_1a60);
	void effector();
	void outputAppender( const ESMoL::Primitive& primitive_1a72, const ESMoL::OutputPort& outputPort_1a74, const SFC::LocalVar& localVar_1a76, const SFC::ConditionalGroup& conditionalGroup_1a78);
	void sortOutputs();

private:
	Packets_t* _primitive_1a48;
	Packets_t* _outputPort_1a49;
	Packets_t* _localVar_1a4a;
	Packets_t* _conditionalGroup_1a4b;
	Packets_t _primitive_1a4c;
	Packets_t _localVar_1a55;
	Packets_t _conditionalGroup_1a5e;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1a6e;
		SFC::LocalVar localVar_1a6f;
		SFC::ConditionalGroup conditionalGroup_1a70;
		ESMoL::OutputPort outputPort_1a71;
	};

	std::list< Match> _matches;
};

class CallCG_1a89
{
public:
	void operator()( const Packets_t& primitives_1a8a, const Packets_t& compoundStatements_1a8d, Packets_t& primitives_1a8c, Packets_t& compoundStatements_1a8f);

protected:
	bool isInputUnique( const Udm::Object& primitive_1a96, const Udm::Object& compoundStatement_1a9f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1a8a, const Packets_t& compoundStatements_1a8d);
	bool patternMatcher( const Udm::Object& primitive_1a94, const Udm::Object& compoundStatement_1a9d);
	void effector();
	void forwardInputs();

private:
	Packets_t* _primitive_1a90;
	Packets_t* _compoundStatement_1a91;
	Packets_t _primitive_1a92;
	Packets_t _compoundStatement_1a9b;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1aa8;
		SFC::CompoundStatement compoundStatement_1aa9;
	};

	std::list< Match> _matches;
};

class CreateCGCall_1aaa
{
public:
	void operator()( const Packets_t& childPrimitives_1aab, const Packets_t& systemFunctions_1aad, Packets_t& childPrimitives_1aaf, Packets_t& systemFunctions_1ab0);

protected:
	void callInitEBCall_1bc8( const Packets_t& primitives_1baa, const Packets_t& parents_1bad);
	void callGetInputs_1bcb( const Packets_t& childPrimitives_1ab4);
	void callMapParams_1bcd( const Packets_t& primitives_1b78);
	void callGetSortedOutPorts_1bcf( const Packets_t& functions_1b8d);
	void callListOutPorts_1bd1( const Packets_t& primitives_1b59, const Packets_t& outputPorts_1b5b);

private:
	Packets_t* _childPrimitive_1ab1;
	Packets_t* _systemFunction_1ab2;
};

class GetInputs_1ab3
{
public:
	void operator()( const Packets_t& childPrimitives_1ab4);

protected:
	void callProcessMerge_1b54( const Packets_t& childPrimitives_1afb);
	void callGetInputPorts_1b56( const Packets_t& childPrimitives_1ab7);
};

class GetInputPorts_1ab6
{
public:
	void operator()( const Packets_t& childPrimitives_1ab7);

protected:
	void callGetSortedInPorts_1af5( const Packets_t& functions_1aba);
	void callListInPorts_1af7( const Packets_t& primitives_1ad7, const Packets_t& inputPorts_1ad9);
};

class GetSortedInPorts_1ab9
{
public:
	void operator()( const Packets_t& functions_1aba, Packets_t& functions_1abc, Packets_t& inputPorts_1abd);

protected:
	bool isInputUnique( const Udm::Object& function_1ac4);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& functions_1aba);
	bool patternMatcher( const Udm::Object& function_1ac2);
	void effector();
	void outputAppender( const ESMoL::Primitive& function_1ad2, const ESMoL::InputPort& inputPort_1ad4);
	void sortOutputs();

private:
	Packets_t* _function_1abe;
	Packets_t* _inputPort_1abf;
	Packets_t _function_1ac0;
	class Match
	{
	public:
		ESMoL::Primitive function_1ad0;
		ESMoL::InputPort inputPort_1ad1;
	};

	std::list< Match> _matches;
};

class ListInPorts_1ad6
{
public:
	void operator()( const Packets_t& primitives_1ad7, const Packets_t& inputPorts_1ad9);

protected:
	bool isInputUnique( const Udm::Object& primitive_1adf, const Udm::Object& inputPort_1ae8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1ad7, const Packets_t& inputPorts_1ad9);
	bool patternMatcher( const Udm::Object& primitive_1add, const Udm::Object& inputPort_1ae6);
	void effector();

private:
	Packets_t _primitive_1adb;
	Packets_t _inputPort_1ae4;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1af2;
		ESMoL::Port inputPort_1af3;
		SFC::ArgDeclBase argDeclBase_1af4;
	};

	std::list< Match> _matches;
};

class ProcessMerge_1afa
{
public:
	void operator()( const Packets_t& childPrimitives_1afb, Packets_t& childPrimitives_1afd);

protected:
	void callGetMergeBlocks_1b50( const Packets_t& childPrimitives_1b2f);
	void callMergeAsSwitch_1b52( const Packets_t& primitives_1b00);

private:
	Packets_t* _childPrimitive_1afe;
};

class MergeAsSwitch_1aff
{
public:
	void operator()( const Packets_t& primitives_1b00);

protected:
	bool isInputUnique( const Udm::Object& primitive_1b06);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1b00);
	bool patternMatcher( const Udm::Object& primitive_1b04);
	void effector();

private:
	Packets_t _primitive_1b02;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1b24;
		ESMoL::InputPort inputPort_1b25;
		SFC::LocalVar localVar_1b26;
		ESMoL::OutputPort actionOutput_1b27;
		ESMoL::Line line1_1b28;
		ESMoL::Line line2_1b29;
		ESMoL::Subsystem ifAction_1b2a;
		ESMoL::Primitive ifOrSwitchCaseBlock_1b2b;
		ESMoL::OutputPort ifOutput_1b2c;
		ESMoL::ActionPort actionPort_1b2d;
	};

	std::list< Match> _matches;
};

class GetMergeBlocks_1b2e
{
public:
	void operator()( const Packets_t& childPrimitives_1b2f, Packets_t& childPrimitives_1b31);

protected:
	void executeOne( const Packets_t& childPrimitives_1b2f);
	bool isInputUnique( const Udm::Object& childPrimitive_1b35);

private:
	Packets_t* _childPrimitive_1b32;
	Packets_t _childPrimitive_1b33;
};

class MergeBlocksOnly_1b3a
{
public:
	bool operator()( const Packets_t& primitives_1b3b, Packets_t& primitives_1b3d);

protected:
	bool isInputUnique( const Udm::Object& primitive_1b43);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Primitive& Primitive);
	void processInputPackets( const Packets_t& primitives_1b3b);
	bool patternMatcher( const Udm::Object& primitive_1b41);
	void outputAppender( const ESMoL::Primitive& primitive_1b4e);

private:
	Packets_t* _primitive_1b3e;
	Packets_t _primitive_1b3f;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1b4c;
	};

	std::list< Match> _matches;
};

class ListOutPorts_1b58
{
public:
	void operator()( const Packets_t& primitives_1b59, const Packets_t& outputPorts_1b5b);

protected:
	bool isInputUnique( const Udm::Object& primitive_1b61, const Udm::Object& outputPort_1b6a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1b59, const Packets_t& outputPorts_1b5b);
	bool patternMatcher( const Udm::Object& primitive_1b5f, const Udm::Object& outputPort_1b68);
	void effector();

private:
	Packets_t _primitive_1b5d;
	Packets_t _outputPort_1b66;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1b74;
		ESMoL::OutputPort outputPort_1b75;
		SFC::ArgDeclBase argDeclBase_1b76;
	};

	std::list< Match> _matches;
};

class MapParams_1b77
{
public:
	void operator()( const Packets_t& primitives_1b78);

protected:
	bool isInputUnique( const Udm::Object& primitive_1b7e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1b78);
	bool patternMatcher( const Udm::Object& primitive_1b7c);
	void effector();

private:
	Packets_t _primitive_1b7a;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1b8a;
		ESMoL::Parameter parameter_1b8b;
	};

	std::list< Match> _matches;
};

class GetSortedOutPorts_1b8c
{
public:
	void operator()( const Packets_t& functions_1b8d, Packets_t& functions_1b8f, Packets_t& outputPorts_1b90);

protected:
	bool isInputUnique( const Udm::Object& function_1b97);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& functions_1b8d);
	bool patternMatcher( const Udm::Object& function_1b95);
	void effector();
	void outputAppender( const ESMoL::Primitive& function_1ba5, const ESMoL::OutputPort& outputPort_1ba7);
	void sortOutputs();

private:
	Packets_t* _function_1b91;
	Packets_t* _outputPort_1b92;
	Packets_t _function_1b93;
	class Match
	{
	public:
		ESMoL::Primitive function_1ba3;
		ESMoL::OutputPort outputPort_1ba4;
	};

	std::list< Match> _matches;
};

class InitEBCall_1ba9
{
public:
	void operator()( const Packets_t& primitives_1baa, const Packets_t& parents_1bad, Packets_t& primitives_1bac);

protected:
	bool isInputUnique( const Udm::Object& primitive_1bb4, const Udm::Object& parent_1bbd);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& primitives_1baa, const Packets_t& parents_1bad);
	bool patternMatcher( const Udm::Object& primitive_1bb2, const Udm::Object& parent_1bbb);
	void effector();
	void forwardInputs();

private:
	Packets_t* _primitive_1baf;
	Packets_t _primitive_1bb0;
	Packets_t _parent_1bb9;
	class Match
	{
	public:
		ESMoL::Primitive primitive_1bc6;
		SFC::CompoundStatement parent_1bc7;
	};

	std::list< Match> _matches;
};

class SubsystemChildBlock_1bdd
{
public:
	void operator()( const Packets_t& systems_1bde, const Packets_t& childSubsystems_1be0, const Packets_t& systemFunctions_1be2);

protected:
	void callMakeTrigger_29bf( const Packets_t& systems_1be5, const Packets_t& childSubsystems_1be7, const Packets_t& systemFunctions_1be9);
	void callCreateMethodCall_29c3( const Packets_t& subsystems_2979, const Packets_t& blocks_297d, const Packets_t& mains_2980);
	void callCreateFunctionCallArgs_29c7( const Packets_t& subsystems_293b, const Packets_t& functions_293e, const Packets_t& methodCalls_2941);
	void callMakeArgDeclRef_29cb( const Packets_t& systems_d7, const Packets_t& argPorts_d9, const Packets_t& argVals_db);
};

class MakeTrigger_1be4
{
public:
	void operator()( const Packets_t& systems_1be5, const Packets_t& childSubsystems_1be7, const Packets_t& systemFunctions_1be9, Packets_t& systems_1beb, Packets_t& childSubsystems_1bec, Packets_t& compoundStatements_1bed);

protected:
	void callIsTriggered_292e( const Packets_t& systems_285a, const Packets_t& childSubsystems_285c, const Packets_t& systemFunctions_285e);
	void callCreateAction_2932( const Packets_t& subsystems_1bf2, const Packets_t& blocks_1bf5, const Packets_t& functions_1bf8);
	void callCreateTriggering_2936( const Packets_t& systems_1c32, const Packets_t& childSubsystems_1c34, const Packets_t& systemFunctions_1c36);

private:
	Packets_t* _system_1bee;
	Packets_t* _childSubsystem_1bef;
	Packets_t* _compoundStatement_1bf0;
};

class CreateAction_1bf1
{
public:
	void operator()( const Packets_t& subsystems_1bf2, const Packets_t& blocks_1bf5, const Packets_t& functions_1bf8, Packets_t& subsystems_1bf4, Packets_t& blocks_1bf7, Packets_t& conditionalBlocks_1bfa);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1c02, const Udm::Object& block_1c0b, const Udm::Object& function_1c14);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_1bf2, const Packets_t& blocks_1bf5, const Packets_t& functions_1bf8);
	bool patternMatcher( const Udm::Object& subsystem_1c00, const Udm::Object& block_1c09, const Udm::Object& function_1c12);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1c2b, const ESMoL::Block& block_1c2d, const SFC::ConditionalBlock& conditionalBlock_1c2f);

private:
	Packets_t* _subsystem_1bfb;
	Packets_t* _block_1bfc;
	Packets_t* _conditionalBlock_1bfd;
	Packets_t _subsystem_1bfe;
	Packets_t _block_1c07;
	Packets_t _function_1c10;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1c21;
		ESMoL::Block block_1c22;
		SFC::Function function_1c23;
		ESMoL::ActionPort actionPort_1c24;
		SFC::ArgDeclBase argDeclBase_1c25;
	};

	std::list< Match> _matches;
};

class CreateTriggering_1c31
{
public:
	void operator()( const Packets_t& systems_1c32, const Packets_t& childSubsystems_1c34, const Packets_t& systemFunctions_1c36, Packets_t& systems_1c38, Packets_t& childSubsystems_1c39, Packets_t& conditionalBlocks_1c3a);

protected:
	void callGetTriggerPort_284b( const Packets_t& subsystems_27d2, const Packets_t& blocks_27d5, const Packets_t& mains_27d8);
	void callAssignCondVal_284f( const Packets_t& subsystems_280b, const Packets_t& triggerPorts_280e, const Packets_t& functions_2813);
	void callMakeTrigger_2853( const Packets_t& systems_1c3f, const Packets_t& childSubsystemTriggers_1c41, const Packets_t& argdecls_1c43, const Packets_t& dts_1c45, const Packets_t& functions_1c47);

private:
	Packets_t* _system_1c3b;
	Packets_t* _childSubsystem_1c3c;
	Packets_t* _conditionalBlock_1c3d;
};

class MakeTrigger_1c3e
{
public:
	void operator()( const Packets_t& systems_1c3f, const Packets_t& childSubsystemTriggers_1c41, const Packets_t& argdecls_1c43, const Packets_t& dts_1c45, const Packets_t& functions_1c47, Packets_t& systems_1c49, Packets_t& childSubsystems_1c4a, Packets_t& conditionals_1c4b);

protected:
	void callAddStateVar_27b5( const Packets_t& subsystems_1f65, const Packets_t& triggerPorts_1f68, const Packets_t& argDeclBases_1f6b, const Packets_t& dTs_1f6f, const Packets_t& functions_1f73);
	void callAddTriggerVars_27bb( const Packets_t& systems_20bc, const Packets_t& triggers_20be, const Packets_t& argdecls_20c0, const Packets_t& dts_20c2, const Packets_t& oldvals_20c4, const Packets_t& contexts_20c6, const Packets_t& functions_20c8);
	void callSaveState_27c3( const Packets_t& systems_1fd0, const Packets_t& triggers_1fd2, const Packets_t& argdecls_1fd4, const Packets_t& dts_1fd6, const Packets_t& oldvals_1fd8, const Packets_t& contexts_1fda, const Packets_t& functions_1fdc);
	void callMakeCondition_27cb( const Packets_t& systems_1c50, const Packets_t& triggers_1c52, const Packets_t& dts_1c54, const Packets_t& oldvals_1c56, const Packets_t& functions_1c58);

private:
	Packets_t* _system_1c4c;
	Packets_t* _childSubsystem_1c4d;
	Packets_t* _conditional_1c4e;
};

class MakeCondition_1c4f
{
public:
	void operator()( const Packets_t& systems_1c50, const Packets_t& triggers_1c52, const Packets_t& dts_1c54, const Packets_t& oldvals_1c56, const Packets_t& functions_1c58, Packets_t& systems_1c5a, Packets_t& childSubsystems_1c5b, Packets_t& conditionals_1c5c);

protected:
	void callCreateConditional_1f56( const Packets_t& subsystems_1c61, const Packets_t& triggerPorts_1c64, const Packets_t& dTs_1c67, const Packets_t& localVars_1c6a, const Packets_t& functions_1c6e);
	void callSetMatrixCondition_1f5c( const Packets_t& dts_1cc1, const Packets_t& triggervars_1cc3, const Packets_t& conditions_1cc5);
	void callSetStructCondition_1f60( const Packets_t& dts_1cff, const Packets_t& oldvals_1d01, const Packets_t& conditions_1d03);

private:
	Packets_t* _system_1c5d;
	Packets_t* _childSubsystem_1c5e;
	Packets_t* _conditional_1c5f;
};

class CreateConditional_1c60
{
public:
	void operator()( const Packets_t& subsystems_1c61, const Packets_t& triggerPorts_1c64, const Packets_t& dTs_1c67, const Packets_t& localVars_1c6a, const Packets_t& functions_1c6e, Packets_t& subsystems_1c63, Packets_t& charts_1c66, Packets_t& dTs_1c69, Packets_t& triggerVars_1c6c, Packets_t& userCodes_1c6d, Packets_t& conditionalBlocks_1c70);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1c7b, const Udm::Object& triggerPort_1c84, const Udm::Object& dT_1c8d, const Udm::Object& localVar_1c96, const Udm::Object& function_1c9f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_1c61, const Packets_t& triggerPorts_1c64, const Packets_t& dTs_1c67, const Packets_t& localVars_1c6a, const Packets_t& functions_1c6e);
	bool patternMatcher( const Udm::Object& subsystem_1c79, const Udm::Object& triggerPort_1c82, const Udm::Object& dT_1c8b, const Udm::Object& localVar_1c94, const Udm::Object& function_1c9d);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1cb4, const ESMoL::Subsystem& chart_1cb6, const SFC::DT& dT_1cb8, const SFC::LocalVar& triggerVar_1cba, const SFC::UserCode& userCode_1cbc, const SFC::ConditionalBlock& conditionalBlock_1cbe);

private:
	Packets_t* _subsystem_1c71;
	Packets_t* _chart_1c72;
	Packets_t* _dT_1c73;
	Packets_t* _triggerVar_1c74;
	Packets_t* _userCode_1c75;
	Packets_t* _conditionalBlock_1c76;
	Packets_t _subsystem_1c77;
	Packets_t _triggerPort_1c80;
	Packets_t _dT_1c89;
	Packets_t _localVar_1c92;
	Packets_t _function_1c9b;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1cab;
		ESMoL::TriggerPort triggerPort_1cac;
		SFC::DT dT_1cad;
		SFC::LocalVar localVar_1cae;
		SFC::Function function_1caf;
		ESMoL::Subsystem chart_1cb0;
		SFC::LocalVar triggerVar_1cb1;
	};

	std::list< Match> _matches;
};

class SetMatrixCondition_1cc0
{
public:
	void operator()( const Packets_t& dts_1cc1, const Packets_t& triggervars_1cc3, const Packets_t& conditions_1cc5, Packets_t& dts_1cc7, Packets_t& triggervars_1cc8, Packets_t& conditions_1cc9);

protected:
	void callMatrixCondition_1cfa( const Packets_t& dTs_1cce, const Packets_t& triggerVars_1cd0, const Packets_t& conditions_1cd2);

private:
	Packets_t* _dt_1cca;
	Packets_t* _triggervar_1ccb;
	Packets_t* _condition_1ccc;
};

class MatrixCondition_1ccd
{
public:
	void operator()( const Packets_t& dTs_1cce, const Packets_t& triggerVars_1cd0, const Packets_t& conditions_1cd2);

protected:
	bool isInputUnique( const Udm::Object& dT_1cd8, const Udm::Object& triggerVar_1ce1, const Udm::Object& condition_1cea);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::UserCode& Condition, SFC::DT& DT, SFC::LocalVar& TriggerVar);
	void processInputPackets( const Packets_t& dTs_1cce, const Packets_t& triggerVars_1cd0, const Packets_t& conditions_1cd2);
	bool patternMatcher( const Udm::Object& dT_1cd6, const Udm::Object& triggerVar_1cdf, const Udm::Object& condition_1ce8);
	void effector();

private:
	Packets_t _dT_1cd4;
	Packets_t _triggerVar_1cdd;
	Packets_t _condition_1ce6;
	class Match
	{
	public:
		SFC::DT dT_1cf3;
		SFC::LocalVar triggerVar_1cf4;
		SFC::UserCode condition_1cf5;
	};

	std::list< Match> _matches;
};

class SetStructCondition_1cfe
{
public:
	void operator()( const Packets_t& dts_1cff, const Packets_t& oldvals_1d01, const Packets_t& conditions_1d03);

protected:
	void callStartCondition_1f49( const Packets_t& structs_1f14, const Packets_t& triggerVars_1f17, const Packets_t& userCodes_1f1a);
	void callgetStructMembers_1f4d( const Packets_t& structs_1d06, const Packets_t& triggerVars_1d0a, const Packets_t& unaryExprss_1d0d);
	void callPlaceMember_1f51( const Packets_t& structs_1d43, const Packets_t& members_1d45, const Packets_t& trigvars_1d47, const Packets_t& condexprs_1d49);
};

class GetStructMembers_1d05
{
public:
	void operator()( const Packets_t& structs_1d06, const Packets_t& triggerVars_1d0a, const Packets_t& unaryExprss_1d0d, Packets_t& structs_1d08, Packets_t& members_1d09, Packets_t& triggerVars_1d0c, Packets_t& unaryExprss_1d0f);

protected:
	bool isInputUnique( const Udm::Object& struct_1d18, const Udm::Object& triggerVar_1d21, const Udm::Object& unaryExprs_1d2a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1d06, const Packets_t& triggerVars_1d0a, const Packets_t& unaryExprss_1d0d);
	bool patternMatcher( const Udm::Object& struct_1d16, const Udm::Object& triggerVar_1d1f, const Udm::Object& unaryExprs_1d28);
	void effector();
	void outputAppender( const SFC::Struct& struct_1d3a, const SFC::LocalVar& member_1d3c, const SFC::LocalVar& triggerVar_1d3e, const SFC::UnaryExprs& unaryExprs_1d40);
	void sortOutputs();

private:
	Packets_t* _struct_1d10;
	Packets_t* _member_1d11;
	Packets_t* _triggerVar_1d12;
	Packets_t* _unaryExprs_1d13;
	Packets_t _struct_1d14;
	Packets_t _triggerVar_1d1d;
	Packets_t _unaryExprs_1d26;
	class Match
	{
	public:
		SFC::Struct struct_1d36;
		SFC::LocalVar triggerVar_1d37;
		SFC::UnaryExprs unaryExprs_1d38;
		SFC::LocalVar member_1d39;
	};

	std::list< Match> _matches;
};

class PlaceMember_1d42
{
public:
	void operator()( const Packets_t& structs_1d43, const Packets_t& members_1d45, const Packets_t& trigvars_1d47, const Packets_t& condexprs_1d49);

protected:
	void executeOne( const Packets_t& structs_1d43, const Packets_t& members_1d45, const Packets_t& trigvars_1d47, const Packets_t& condexprs_1d49);
	bool isInputUnique( const Udm::Object& struct_1d4d, const Udm::Object& member_1d54, const Udm::Object& trigvar_1d5b, const Udm::Object& condexpr_1d62);
	void callTriggerTest_1f04( const Packets_t& structs_1db5, const Packets_t& members_1db7, const Packets_t& trigvars_1db9, const Packets_t& condexprs_1dbb);
	void callTraverseBinary_1f09( const Packets_t& structs_1d68, const Packets_t& members_1d6b, const Packets_t& triggerVars_1d6e, const Packets_t& unaryExprss_1d71);
	void callAddTrigger_1f0e( const Packets_t& structs_1e78, const Packets_t& members_1e7a, const Packets_t& trigvars_1e7c, const Packets_t& condexprs_1e7e);

private:
	Packets_t _struct_1d4b;
	Packets_t _member_1d52;
	Packets_t _trigvar_1d59;
	Packets_t _condexpr_1d60;
};

class TraverseBinary_1d67
{
public:
	void operator()( const Packets_t& structs_1d68, const Packets_t& members_1d6b, const Packets_t& triggerVars_1d6e, const Packets_t& unaryExprss_1d71, Packets_t& structs_1d6a, Packets_t& members_1d6d, Packets_t& triggerVars_1d70, Packets_t& unaryExprss_1d73);

protected:
	bool isInputUnique( const Udm::Object& struct_1d7c, const Udm::Object& member_1d85, const Udm::Object& triggerVar_1d8e, const Udm::Object& unaryExprs_1d97);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1d68, const Packets_t& members_1d6b, const Packets_t& triggerVars_1d6e, const Packets_t& unaryExprss_1d71);
	bool patternMatcher( const Udm::Object& struct_1d7a, const Udm::Object& member_1d83, const Udm::Object& triggerVar_1d8c, const Udm::Object& unaryExprs_1d95);
	void effector();
	void outputAppender( const SFC::Struct& struct_1dac, const SFC::LocalVar& member_1dae, const SFC::LocalVar& triggerVar_1db0, const SFC::UnaryExprs& unaryExprs_1db2);

private:
	Packets_t* _struct_1d74;
	Packets_t* _member_1d75;
	Packets_t* _triggerVar_1d76;
	Packets_t* _unaryExprs_1d77;
	Packets_t _struct_1d78;
	Packets_t _member_1d81;
	Packets_t _triggerVar_1d8a;
	Packets_t _unaryExprs_1d93;
	class Match
	{
	public:
		SFC::Struct struct_1da6;
		SFC::LocalVar member_1da7;
		SFC::LocalVar triggerVar_1da8;
		SFC::UnaryExprs unaryExprs_1da9;
		SFC::BinaryExprs binaryExprs_1daa;
		SFC::UnaryExprs unaryExprs_1dab;
	};

	std::list< Match> _matches;
};

class TriggerTest_1db4
{
public:
	void operator()( const Packets_t& structs_1db5, const Packets_t& members_1db7, const Packets_t& trigvars_1db9, const Packets_t& condexprs_1dbb, Packets_t& structs_1dbd, Packets_t& members_1dbe, Packets_t& trigvars_1dbf, Packets_t& condexprs_1dc0, Packets_t& structs_1dc1, Packets_t& members_1dc2, Packets_t& trigvars_1dc3, Packets_t& condexprs_1dc4);

protected:
	void executeOne( const Packets_t& structs_1db5, const Packets_t& members_1db7, const Packets_t& trigvars_1db9, const Packets_t& condexprs_1dbb);
	bool isInputUnique( const Udm::Object& struct_1dcf, const Udm::Object& member_1dd6, const Udm::Object& trigvar_1ddd, const Udm::Object& condexpr_1de4);

private:
	Packets_t* _struct_1dc5;
	Packets_t* _member_1dc6;
	Packets_t* _trigvar_1dc7;
	Packets_t* _condexpr_1dc8;
	Packets_t* _struct_1dc9;
	Packets_t* _member_1dca;
	Packets_t* _trigvar_1dcb;
	Packets_t* _condexpr_1dcc;
	Packets_t _struct_1dcd;
	Packets_t _member_1dd4;
	Packets_t _trigvar_1ddb;
	Packets_t _condexpr_1de2;
};

class HasBinaryExprs_1de9
{
public:
	bool operator()( const Packets_t& structs_1dea, const Packets_t& members_1ded, const Packets_t& triggerVars_1df0, const Packets_t& unaryExprss_1df3, Packets_t& structs_1dec, Packets_t& members_1def, Packets_t& triggerVars_1df2, Packets_t& unaryExprss_1df5);

protected:
	bool isInputUnique( const Udm::Object& struct_1dfe, const Udm::Object& member_1e07, const Udm::Object& triggerVar_1e10, const Udm::Object& unaryExprs_1e19);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1dea, const Packets_t& members_1ded, const Packets_t& triggerVars_1df0, const Packets_t& unaryExprss_1df3);
	bool patternMatcher( const Udm::Object& struct_1dfc, const Udm::Object& member_1e05, const Udm::Object& triggerVar_1e0e, const Udm::Object& unaryExprs_1e17);
	void outputAppender( const SFC::Struct& struct_1e2a, const SFC::LocalVar& member_1e2c, const SFC::LocalVar& triggerVar_1e2e, const SFC::UnaryExprs& unaryExprs_1e30);

private:
	Packets_t* _struct_1df6;
	Packets_t* _member_1df7;
	Packets_t* _triggerVar_1df8;
	Packets_t* _unaryExprs_1df9;
	Packets_t _struct_1dfa;
	Packets_t _member_1e03;
	Packets_t _triggerVar_1e0c;
	Packets_t _unaryExprs_1e15;
	class Match
	{
	public:
		SFC::Struct struct_1e25;
		SFC::LocalVar member_1e26;
		SFC::LocalVar triggerVar_1e27;
		SFC::UnaryExprs unaryExprs_1e28;
		SFC::BinaryExprs binaryExprs_1e29;
	};

	std::list< Match> _matches;
};

class Otherwise_1e32
{
public:
	bool operator()( const Packets_t& structs_1e33, const Packets_t& members_1e36, const Packets_t& triggerVars_1e39, const Packets_t& unaryExprss_1e3c, Packets_t& structs_1e35, Packets_t& members_1e38, Packets_t& triggerVars_1e3b, Packets_t& unaryExprss_1e3e);

protected:
	bool isInputUnique( const Udm::Object& struct_1e47, const Udm::Object& member_1e50, const Udm::Object& triggerVar_1e59, const Udm::Object& unaryExprs_1e62);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1e33, const Packets_t& members_1e36, const Packets_t& triggerVars_1e39, const Packets_t& unaryExprss_1e3c);
	bool patternMatcher( const Udm::Object& struct_1e45, const Udm::Object& member_1e4e, const Udm::Object& triggerVar_1e57, const Udm::Object& unaryExprs_1e60);
	void outputAppender( const SFC::Struct& struct_1e6f, const SFC::LocalVar& member_1e71, const SFC::LocalVar& triggerVar_1e73, const SFC::UnaryExprs& unaryExprs_1e75);

private:
	Packets_t* _struct_1e3f;
	Packets_t* _member_1e40;
	Packets_t* _triggerVar_1e41;
	Packets_t* _unaryExprs_1e42;
	Packets_t _struct_1e43;
	Packets_t _member_1e4c;
	Packets_t _triggerVar_1e55;
	Packets_t _unaryExprs_1e5e;
	class Match
	{
	public:
		SFC::Struct struct_1e6b;
		SFC::LocalVar member_1e6c;
		SFC::LocalVar triggerVar_1e6d;
		SFC::UnaryExprs unaryExprs_1e6e;
	};

	std::list< Match> _matches;
};

class AddTrigger_1e77
{
public:
	void operator()( const Packets_t& structs_1e78, const Packets_t& members_1e7a, const Packets_t& trigvars_1e7c, const Packets_t& condexprs_1e7e);

protected:
	void callAddNextTrigger_1efa( const Packets_t& structs_1e81, const Packets_t& members_1e83, const Packets_t& triggerVars_1e85, const Packets_t& unaryExprss_1e87);
	void callAddLastTrigger_1eff( const Packets_t& structs_1ebf, const Packets_t& members_1ec1, const Packets_t& triggerVars_1ec3, const Packets_t& unaryExprss_1ec5);
};

class AddNextTrigger_1e80
{
public:
	void operator()( const Packets_t& structs_1e81, const Packets_t& members_1e83, const Packets_t& triggerVars_1e85, const Packets_t& unaryExprss_1e87);

protected:
	bool isInputUnique( const Udm::Object& struct_1e8d, const Udm::Object& member_1e96, const Udm::Object& triggerVar_1e9f, const Udm::Object& unaryExprs_1ea8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::LocalVar& Member, SFC::Struct& Struct, SFC::LocalVar& TriggerVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& structs_1e81, const Packets_t& members_1e83, const Packets_t& triggerVars_1e85, const Packets_t& unaryExprss_1e87);
	bool patternMatcher( const Udm::Object& struct_1e8b, const Udm::Object& member_1e94, const Udm::Object& triggerVar_1e9d, const Udm::Object& unaryExprs_1ea6);
	void effector();

private:
	Packets_t _struct_1e89;
	Packets_t _member_1e92;
	Packets_t _triggerVar_1e9b;
	Packets_t _unaryExprs_1ea4;
	class Match
	{
	public:
		SFC::Struct struct_1eb1;
		SFC::LocalVar member_1eb2;
		SFC::LocalVar triggerVar_1eb3;
		SFC::UnaryExprs unaryExprs_1eb4;
	};

	std::list< Match> _matches;
};

class AddLastTrigger_1ebe
{
public:
	void operator()( const Packets_t& structs_1ebf, const Packets_t& members_1ec1, const Packets_t& triggerVars_1ec3, const Packets_t& unaryExprss_1ec5);

protected:
	bool isInputUnique( const Udm::Object& struct_1ecb, const Udm::Object& member_1ed4, const Udm::Object& triggerVar_1edd, const Udm::Object& unaryExprs_1ee6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::LocalVar& Member, SFC::Struct& Struct, SFC::LocalVar& TriggerVar, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& structs_1ebf, const Packets_t& members_1ec1, const Packets_t& triggerVars_1ec3, const Packets_t& unaryExprss_1ec5);
	bool patternMatcher( const Udm::Object& struct_1ec9, const Udm::Object& member_1ed2, const Udm::Object& triggerVar_1edb, const Udm::Object& unaryExprs_1ee4);
	void effector();

private:
	Packets_t _struct_1ec7;
	Packets_t _member_1ed0;
	Packets_t _triggerVar_1ed9;
	Packets_t _unaryExprs_1ee2;
	class Match
	{
	public:
		SFC::Struct struct_1eef;
		SFC::LocalVar member_1ef0;
		SFC::LocalVar triggerVar_1ef1;
		SFC::UnaryExprs unaryExprs_1ef2;
	};

	std::list< Match> _matches;
};

class StartCondition_1f13
{
public:
	void operator()( const Packets_t& structs_1f14, const Packets_t& triggerVars_1f17, const Packets_t& userCodes_1f1a, Packets_t& structs_1f16, Packets_t& triggerVars_1f19, Packets_t& unaryExprss_1f1c);

protected:
	bool isInputUnique( const Udm::Object& struct_1f24, const Udm::Object& triggerVar_1f2d, const Udm::Object& userCode_1f36);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& structs_1f14, const Packets_t& triggerVars_1f17, const Packets_t& userCodes_1f1a);
	bool patternMatcher( const Udm::Object& struct_1f22, const Udm::Object& triggerVar_1f2b, const Udm::Object& userCode_1f34);
	void effector();
	void outputAppender( const SFC::Struct& struct_1f43, const SFC::LocalVar& triggerVar_1f45, const SFC::UnaryExprs& unaryExprs_1f47);

private:
	Packets_t* _struct_1f1d;
	Packets_t* _triggerVar_1f1e;
	Packets_t* _unaryExprs_1f1f;
	Packets_t _struct_1f20;
	Packets_t _triggerVar_1f29;
	Packets_t _userCode_1f32;
	class Match
	{
	public:
		SFC::Struct struct_1f3f;
		SFC::LocalVar triggerVar_1f40;
		SFC::UserCode userCode_1f41;
	};

	std::list< Match> _matches;
};

class AddStateVar_1f64
{
public:
	void operator()( const Packets_t& subsystems_1f65, const Packets_t& triggerPorts_1f68, const Packets_t& argDeclBases_1f6b, const Packets_t& dTs_1f6f, const Packets_t& functions_1f73, Packets_t& subsystems_1f67, Packets_t& triggerPorts_1f6a, Packets_t& argDeclBases_1f6d, Packets_t& localVars_1f6e, Packets_t& dTs_1f71, Packets_t& args_1f72, Packets_t& functions_1f75);

protected:
	bool isInputUnique( const Udm::Object& subsystem_1f81, const Udm::Object& triggerPort_1f8a, const Udm::Object& argDeclBase_1f93, const Udm::Object& dT_1f9c, const Udm::Object& function_1fa5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_1f65, const Packets_t& triggerPorts_1f68, const Packets_t& argDeclBases_1f6b, const Packets_t& dTs_1f6f, const Packets_t& functions_1f73);
	bool patternMatcher( const Udm::Object& subsystem_1f7f, const Udm::Object& triggerPort_1f88, const Udm::Object& argDeclBase_1f91, const Udm::Object& dT_1f9a, const Udm::Object& function_1fa3);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_1fc1, const ESMoL::TriggerPort& triggerPort_1fc3, const SFC::ArgDeclBase& argDeclBase_1fc5, const SFC::LocalVar& localVar_1fc7, const SFC::DT& dT_1fc9, const SFC::Arg& arg_1fcb, const SFC::Function& function_1fcd);

private:
	Packets_t* _subsystem_1f76;
	Packets_t* _triggerPort_1f77;
	Packets_t* _argDeclBase_1f78;
	Packets_t* _localVar_1f79;
	Packets_t* _dT_1f7a;
	Packets_t* _arg_1f7b;
	Packets_t* _function_1f7c;
	Packets_t _subsystem_1f7d;
	Packets_t _triggerPort_1f86;
	Packets_t _argDeclBase_1f8f;
	Packets_t _dT_1f98;
	Packets_t _function_1fa1;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_1fb8;
		ESMoL::TriggerPort triggerPort_1fb9;
		SFC::ArgDeclBase argDeclBase_1fba;
		SFC::DT dT_1fbb;
		SFC::Function function_1fbc;
		SFC::Arg arg_1fbd;
		SFC::Struct struct_1fbe;
		SFC::Class class_1fbf;
	};

	std::list< Match> _matches;
};

class SaveState_1fcf
{
public:
	void operator()( const Packets_t& systems_1fd0, const Packets_t& triggers_1fd2, const Packets_t& argdecls_1fd4, const Packets_t& dts_1fd6, const Packets_t& oldvals_1fd8, const Packets_t& contexts_1fda, const Packets_t& functions_1fdc, Packets_t& systems_1fde, Packets_t& triggers_1fdf, Packets_t& dts_1fe0, Packets_t& oldvals_1fe1, Packets_t& functions_1fe2);

protected:
	void callSaveMatrixState_20af( const Packets_t& argdecls_1fe9, const Packets_t& dts_1feb, const Packets_t& oldvals_1fed, const Packets_t& contexts_1fef, const Packets_t& functions_1ff1);
	void callSaveStructState_20b5( const Packets_t& argdecls_2050, const Packets_t& dts_2052, const Packets_t& oldvals_2054, const Packets_t& contexts_2056, const Packets_t& functions_2058);

private:
	Packets_t* _system_1fe3;
	Packets_t* _trigger_1fe4;
	Packets_t* _dt_1fe5;
	Packets_t* _oldval_1fe6;
	Packets_t* _function_1fe7;
};

class SaveMatrixState_1fe8
{
public:
	void operator()( const Packets_t& argdecls_1fe9, const Packets_t& dts_1feb, const Packets_t& oldvals_1fed, const Packets_t& contexts_1fef, const Packets_t& functions_1ff1, Packets_t& argdecls_1ff3, Packets_t& dts_1ff4, Packets_t& oldvals_1ff5, Packets_t& contexts_1ff6, Packets_t& functions_1ff7);

protected:
	void callSaveMatrixState_2049( const Packets_t& argDeclBases_1ffe, const Packets_t& dTs_2000, const Packets_t& localVars_2002, const Packets_t& args_2004, const Packets_t& functions_2006);

private:
	Packets_t* _argdecl_1ff8;
	Packets_t* _dt_1ff9;
	Packets_t* _oldval_1ffa;
	Packets_t* _context_1ffb;
	Packets_t* _function_1ffc;
};

class SaveMatrixState_1ffd
{
public:
	void operator()( const Packets_t& argDeclBases_1ffe, const Packets_t& dTs_2000, const Packets_t& localVars_2002, const Packets_t& args_2004, const Packets_t& functions_2006);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_200c, const Udm::Object& dT_2015, const Udm::Object& localVar_201e, const Udm::Object& arg_2027, const Udm::Object& function_2030);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::ArgDeclBase& ArgDeclBase, SFC::DT& DT, SFC::Function& Function, SFC::LocalVar& LocalVar);
	void processInputPackets( const Packets_t& argDeclBases_1ffe, const Packets_t& dTs_2000, const Packets_t& localVars_2002, const Packets_t& args_2004, const Packets_t& functions_2006);
	bool patternMatcher( const Udm::Object& argDeclBase_200a, const Udm::Object& dT_2013, const Udm::Object& localVar_201c, const Udm::Object& arg_2025, const Udm::Object& function_202e);
	void effector();

private:
	Packets_t _argDeclBase_2008;
	Packets_t _dT_2011;
	Packets_t _localVar_201a;
	Packets_t _arg_2023;
	Packets_t _function_202c;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2039;
		SFC::DT dT_203a;
		SFC::LocalVar localVar_203b;
		SFC::Arg arg_203c;
		SFC::Function function_203d;
	};

	std::list< Match> _matches;
};

class SaveStructState_204f
{
public:
	void operator()( const Packets_t& argdecls_2050, const Packets_t& dts_2052, const Packets_t& oldvals_2054, const Packets_t& contexts_2056, const Packets_t& functions_2058);

protected:
	void callSaveStructState_20a9( const Packets_t& argDeclBases_205b, const Packets_t& structs_205d, const Packets_t& localVars_205f, const Packets_t& contexts_2061, const Packets_t& functions_2063);
};

class SaveStructState_205a
{
public:
	void operator()( const Packets_t& argDeclBases_205b, const Packets_t& structs_205d, const Packets_t& localVars_205f, const Packets_t& contexts_2061, const Packets_t& functions_2063);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_2069, const Udm::Object& struct_2072, const Udm::Object& localVar_207b, const Udm::Object& context_2084, const Udm::Object& function_208d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_205b, const Packets_t& structs_205d, const Packets_t& localVars_205f, const Packets_t& contexts_2061, const Packets_t& functions_2063);
	bool patternMatcher( const Udm::Object& argDeclBase_2067, const Udm::Object& struct_2070, const Udm::Object& localVar_2079, const Udm::Object& context_2082, const Udm::Object& function_208b);
	void effector();

private:
	Packets_t _argDeclBase_2065;
	Packets_t _struct_206e;
	Packets_t _localVar_2077;
	Packets_t _context_2080;
	Packets_t _function_2089;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2099;
		SFC::Struct struct_209a;
		SFC::LocalVar localVar_209b;
		SFC::Arg context_209c;
		SFC::Function function_209d;
		SFC::LocalVar member_209e;
	};

	std::list< Match> _matches;
};

class AddTriggerVars_20bb
{
public:
	void operator()( const Packets_t& systems_20bc, const Packets_t& triggers_20be, const Packets_t& argdecls_20c0, const Packets_t& dts_20c2, const Packets_t& oldvals_20c4, const Packets_t& contexts_20c6, const Packets_t& functions_20c8, Packets_t& systems_20ca, Packets_t& triggers_20cb, Packets_t& argdecls_20cc, Packets_t& dts_20cd, Packets_t& oldvals_20ce, Packets_t& contexts_20cf, Packets_t& functions_20d0);

protected:
	void callAddMatrixTriggerVars_27a7( const Packets_t& triggers_2481, const Packets_t& argdecls_2483, const Packets_t& dts_2485, const Packets_t& oldvals_2487, const Packets_t& contexts_2489, const Packets_t& functions_248b);
	void callAddStructTriggerVars_27ae( const Packets_t& triggers_20d9, const Packets_t& argdecls_20db, const Packets_t& dts_20dd, const Packets_t& oldvals_20df, const Packets_t& contexts_20e1, const Packets_t& functions_20e3);

private:
	Packets_t* _system_20d1;
	Packets_t* _trigger_20d2;
	Packets_t* _argdecl_20d3;
	Packets_t* _dt_20d4;
	Packets_t* _oldval_20d5;
	Packets_t* _context_20d6;
	Packets_t* _function_20d7;
};

class AddStructTriggerVars_20d8
{
public:
	void operator()( const Packets_t& triggers_20d9, const Packets_t& argdecls_20db, const Packets_t& dts_20dd, const Packets_t& oldvals_20df, const Packets_t& contexts_20e1, const Packets_t& functions_20e3);

protected:
	void callAddTriggerVar_244c( const Packets_t& triggerPorts_2161, const Packets_t& argDeclBases_2164, const Packets_t& structs_2167, const Packets_t& localVars_216a, const Packets_t& contexts_216d, const Packets_t& functions_2171);
	void callStartAssignment_2453( const Packets_t& triggerPorts_20e6, const Packets_t& argDeclBases_20e9, const Packets_t& structs_20ed, const Packets_t& oldvals_20ef, const Packets_t& contexts_20f2, const Packets_t& triggerVars_20f5, const Packets_t& functions_20f7);
	void callEdgeTest_245b( const Packets_t& triggers_21cb, const Packets_t& argdecls_21cd, const Packets_t& members_21cf, const Packets_t& oldvals_21d1, const Packets_t& contexts_21d3, const Packets_t& initexprs_21d5);
	void callRisingEdge_2462( const Packets_t& argDeclBases_2355, const Packets_t& members_2357, const Packets_t& localVars_2359, const Packets_t& contexts_235b, const Packets_t& unaryExprss_235d);
	void callFallingEdge_2468( const Packets_t& argDeclBases_23a3, const Packets_t& members_23a5, const Packets_t& localVars_23a7, const Packets_t& contexts_23a9, const Packets_t& unaryExprss_23ab);
	void callEitherEdge_246e( const Packets_t& argDeclBases_23f1, const Packets_t& members_23f4, const Packets_t& localVars_23f7, const Packets_t& contexts_23fa, const Packets_t& unaryExprss_23fd);
	void callRisingEdge_2474( const Packets_t& argDeclBases_2355, const Packets_t& members_2357, const Packets_t& localVars_2359, const Packets_t& contexts_235b, const Packets_t& unaryExprss_235d);
	void callFallingEdge_247a( const Packets_t& argDeclBases_23a3, const Packets_t& members_23a5, const Packets_t& localVars_23a7, const Packets_t& contexts_23a9, const Packets_t& unaryExprss_23ab);
};

class StartAssignment_20e5
{
public:
	void operator()( const Packets_t& triggerPorts_20e6, const Packets_t& argDeclBases_20e9, const Packets_t& structs_20ed, const Packets_t& oldvals_20ef, const Packets_t& contexts_20f2, const Packets_t& triggerVars_20f5, const Packets_t& functions_20f7, Packets_t& triggerPorts_20e8, Packets_t& argDeclBases_20eb, Packets_t& localVars_20ec, Packets_t& oldvals_20f1, Packets_t& contexts_20f4, Packets_t& unaryExprss_20f9);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_2104, const Udm::Object& argDeclBase_210d, const Udm::Object& struct_2116, const Udm::Object& oldval_211f, const Udm::Object& context_2128, const Udm::Object& triggerVar_2131, const Udm::Object& function_213a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& triggerPorts_20e6, const Packets_t& argDeclBases_20e9, const Packets_t& structs_20ed, const Packets_t& oldvals_20ef, const Packets_t& contexts_20f2, const Packets_t& triggerVars_20f5, const Packets_t& functions_20f7);
	bool patternMatcher( const Udm::Object& triggerPort_2102, const Udm::Object& argDeclBase_210b, const Udm::Object& struct_2114, const Udm::Object& oldval_211d, const Udm::Object& context_2126, const Udm::Object& triggerVar_212f, const Udm::Object& function_2138);
	void effector();
	void outputAppender( const ESMoL::TriggerPort& triggerPort_2154, const SFC::ArgDeclBase& argDeclBase_2156, const SFC::LocalVar& localVar_2158, const SFC::LocalVar& oldval_215a, const SFC::Arg& context_215c, const SFC::UnaryExprs& unaryExprs_215e);

private:
	Packets_t* _triggerPort_20fa;
	Packets_t* _argDeclBase_20fb;
	Packets_t* _localVar_20fc;
	Packets_t* _oldval_20fd;
	Packets_t* _context_20fe;
	Packets_t* _unaryExprs_20ff;
	Packets_t _triggerPort_2100;
	Packets_t _argDeclBase_2109;
	Packets_t _struct_2112;
	Packets_t _oldval_211b;
	Packets_t _context_2124;
	Packets_t _triggerVar_212d;
	Packets_t _function_2136;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_2146;
		SFC::ArgDeclBase argDeclBase_2147;
		SFC::Struct struct_2148;
		SFC::LocalVar oldval_2149;
		SFC::Arg context_214a;
		SFC::LocalVar triggerVar_214b;
		SFC::Function function_214c;
		SFC::LocalVar localVar_214d;
	};

	std::list< Match> _matches;
};

class AddTriggerVar_2160
{
public:
	void operator()( const Packets_t& triggerPorts_2161, const Packets_t& argDeclBases_2164, const Packets_t& structs_2167, const Packets_t& localVars_216a, const Packets_t& contexts_216d, const Packets_t& functions_2171, Packets_t& triggerPorts_2163, Packets_t& argDeclBases_2166, Packets_t& structs_2169, Packets_t& localVars_216c, Packets_t& contexts_216f, Packets_t& triggerVars_2170, Packets_t& functions_2173);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_217f, const Udm::Object& argDeclBase_2188, const Udm::Object& struct_2191, const Udm::Object& localVar_219a, const Udm::Object& context_21a3, const Udm::Object& function_21ac);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& triggerPorts_2161, const Packets_t& argDeclBases_2164, const Packets_t& structs_2167, const Packets_t& localVars_216a, const Packets_t& contexts_216d, const Packets_t& functions_2171);
	bool patternMatcher( const Udm::Object& triggerPort_217d, const Udm::Object& argDeclBase_2186, const Udm::Object& struct_218f, const Udm::Object& localVar_2198, const Udm::Object& context_21a1, const Udm::Object& function_21aa);
	void effector();
	void outputAppender( const ESMoL::TriggerPort& triggerPort_21bc, const SFC::ArgDeclBase& argDeclBase_21be, const SFC::Struct& struct_21c0, const SFC::LocalVar& localVar_21c2, const SFC::Arg& context_21c4, const SFC::LocalVar& triggerVar_21c6, const SFC::Function& function_21c8);

private:
	Packets_t* _triggerPort_2174;
	Packets_t* _argDeclBase_2175;
	Packets_t* _struct_2176;
	Packets_t* _localVar_2177;
	Packets_t* _context_2178;
	Packets_t* _triggerVar_2179;
	Packets_t* _function_217a;
	Packets_t _triggerPort_217b;
	Packets_t _argDeclBase_2184;
	Packets_t _struct_218d;
	Packets_t _localVar_2196;
	Packets_t _context_219f;
	Packets_t _function_21a8;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_21b5;
		SFC::ArgDeclBase argDeclBase_21b6;
		SFC::Struct struct_21b7;
		SFC::LocalVar localVar_21b8;
		SFC::Arg context_21b9;
		SFC::Function function_21ba;
	};

	std::list< Match> _matches;
};

class EdgeTest_21ca
{
public:
	void operator()( const Packets_t& triggers_21cb, const Packets_t& argdecls_21cd, const Packets_t& members_21cf, const Packets_t& oldvals_21d1, const Packets_t& contexts_21d3, const Packets_t& initexprs_21d5, Packets_t& argdecls_21d7, Packets_t& members_21d8, Packets_t& oldvals_21d9, Packets_t& contexts_21da, Packets_t& initexprs_21db, Packets_t& argdecls_21dc, Packets_t& members_21dd, Packets_t& oldvals_21de, Packets_t& contexts_21df, Packets_t& initexprs_21e0, Packets_t& argdecls_21e1, Packets_t& members_21e2, Packets_t& oldvals_21e3, Packets_t& contexts_21e4, Packets_t& initexprs_21e5);

protected:
	void executeOne( const Packets_t& triggers_21cb, const Packets_t& argdecls_21cd, const Packets_t& members_21cf, const Packets_t& oldvals_21d1, const Packets_t& contexts_21d3, const Packets_t& initexprs_21d5);
	bool isInputUnique( const Udm::Object& trigger_21f7, const Udm::Object& argdecl_21fe, const Udm::Object& member_2205, const Udm::Object& oldval_220c, const Udm::Object& context_2213, const Udm::Object& initexpr_221a);

private:
	Packets_t* _argdecl_21e6;
	Packets_t* _member_21e7;
	Packets_t* _oldval_21e8;
	Packets_t* _context_21e9;
	Packets_t* _initexpr_21ea;
	Packets_t* _argdecl_21eb;
	Packets_t* _member_21ec;
	Packets_t* _oldval_21ed;
	Packets_t* _context_21ee;
	Packets_t* _initexpr_21ef;
	Packets_t* _argdecl_21f0;
	Packets_t* _member_21f1;
	Packets_t* _oldval_21f2;
	Packets_t* _context_21f3;
	Packets_t* _initexpr_21f4;
	Packets_t _trigger_21f5;
	Packets_t _argdecl_21fc;
	Packets_t _member_2203;
	Packets_t _oldval_220a;
	Packets_t _context_2211;
	Packets_t _initexpr_2218;
};

class RisingEdge_221f
{
public:
	bool operator()( const Packets_t& triggerPorts_2220, const Packets_t& argDeclBases_2222, const Packets_t& members_2225, const Packets_t& localVars_2228, const Packets_t& contexts_222b, const Packets_t& unaryExprss_222e, Packets_t& argDeclBases_2224, Packets_t& members_2227, Packets_t& localVars_222a, Packets_t& contexts_222d, Packets_t& unaryExprss_2230);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_223a, const Udm::Object& argDeclBase_2243, const Udm::Object& member_224c, const Udm::Object& localVar_2255, const Udm::Object& context_225e, const Udm::Object& unaryExprs_2267);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::LocalVar& LocalVar, SFC::LocalVar& Member, ESMoL::TriggerPort& TriggerPort, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& triggerPorts_2220, const Packets_t& argDeclBases_2222, const Packets_t& members_2225, const Packets_t& localVars_2228, const Packets_t& contexts_222b, const Packets_t& unaryExprss_222e);
	bool patternMatcher( const Udm::Object& triggerPort_2238, const Udm::Object& argDeclBase_2241, const Udm::Object& member_224a, const Udm::Object& localVar_2253, const Udm::Object& context_225c, const Udm::Object& unaryExprs_2265);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_227c, const SFC::LocalVar& member_227e, const SFC::LocalVar& localVar_2280, const SFC::Arg& context_2282, const SFC::UnaryExprs& unaryExprs_2284);

private:
	Packets_t* _argDeclBase_2231;
	Packets_t* _member_2232;
	Packets_t* _localVar_2233;
	Packets_t* _context_2234;
	Packets_t* _unaryExprs_2235;
	Packets_t _triggerPort_2236;
	Packets_t _argDeclBase_223f;
	Packets_t _member_2248;
	Packets_t _localVar_2251;
	Packets_t _context_225a;
	Packets_t _unaryExprs_2263;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_2270;
		SFC::ArgDeclBase argDeclBase_2271;
		SFC::LocalVar member_2272;
		SFC::LocalVar localVar_2273;
		SFC::Arg context_2274;
		SFC::UnaryExprs unaryExprs_2275;
	};

	std::list< Match> _matches;
};

class FallingEdge_2286
{
public:
	bool operator()( const Packets_t& triggerPorts_2287, const Packets_t& argDeclBases_2289, const Packets_t& members_228c, const Packets_t& localVars_228f, const Packets_t& contexts_2292, const Packets_t& unaryExprss_2295, Packets_t& argDeclBases_228b, Packets_t& members_228e, Packets_t& localVars_2291, Packets_t& contexts_2294, Packets_t& unaryExprss_2297);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_22a1, const Udm::Object& argDeclBase_22aa, const Udm::Object& member_22b3, const Udm::Object& localVar_22bc, const Udm::Object& context_22c5, const Udm::Object& unaryExprs_22ce);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::LocalVar& LocalVar, SFC::LocalVar& Member, ESMoL::TriggerPort& TriggerPort, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& triggerPorts_2287, const Packets_t& argDeclBases_2289, const Packets_t& members_228c, const Packets_t& localVars_228f, const Packets_t& contexts_2292, const Packets_t& unaryExprss_2295);
	bool patternMatcher( const Udm::Object& triggerPort_229f, const Udm::Object& argDeclBase_22a8, const Udm::Object& member_22b1, const Udm::Object& localVar_22ba, const Udm::Object& context_22c3, const Udm::Object& unaryExprs_22cc);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_22e3, const SFC::LocalVar& member_22e5, const SFC::LocalVar& localVar_22e7, const SFC::Arg& context_22e9, const SFC::UnaryExprs& unaryExprs_22eb);

private:
	Packets_t* _argDeclBase_2298;
	Packets_t* _member_2299;
	Packets_t* _localVar_229a;
	Packets_t* _context_229b;
	Packets_t* _unaryExprs_229c;
	Packets_t _triggerPort_229d;
	Packets_t _argDeclBase_22a6;
	Packets_t _member_22af;
	Packets_t _localVar_22b8;
	Packets_t _context_22c1;
	Packets_t _unaryExprs_22ca;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_22d7;
		SFC::ArgDeclBase argDeclBase_22d8;
		SFC::LocalVar member_22d9;
		SFC::LocalVar localVar_22da;
		SFC::Arg context_22db;
		SFC::UnaryExprs unaryExprs_22dc;
	};

	std::list< Match> _matches;
};

class EitherEdge_22ed
{
public:
	bool operator()( const Packets_t& triggerPorts_22ee, const Packets_t& argDeclBases_22f0, const Packets_t& members_22f3, const Packets_t& localVars_22f6, const Packets_t& contexts_22f9, const Packets_t& unaryExprss_22fc, Packets_t& argDeclBases_22f2, Packets_t& members_22f5, Packets_t& localVars_22f8, Packets_t& contexts_22fb, Packets_t& unaryExprss_22fe);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_2308, const Udm::Object& argDeclBase_2311, const Udm::Object& member_231a, const Udm::Object& localVar_2323, const Udm::Object& context_232c, const Udm::Object& unaryExprs_2335);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::LocalVar& LocalVar, SFC::LocalVar& Member, ESMoL::TriggerPort& TriggerPort, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& triggerPorts_22ee, const Packets_t& argDeclBases_22f0, const Packets_t& members_22f3, const Packets_t& localVars_22f6, const Packets_t& contexts_22f9, const Packets_t& unaryExprss_22fc);
	bool patternMatcher( const Udm::Object& triggerPort_2306, const Udm::Object& argDeclBase_230f, const Udm::Object& member_2318, const Udm::Object& localVar_2321, const Udm::Object& context_232a, const Udm::Object& unaryExprs_2333);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_234a, const SFC::LocalVar& member_234c, const SFC::LocalVar& localVar_234e, const SFC::Arg& context_2350, const SFC::UnaryExprs& unaryExprs_2352);

private:
	Packets_t* _argDeclBase_22ff;
	Packets_t* _member_2300;
	Packets_t* _localVar_2301;
	Packets_t* _context_2302;
	Packets_t* _unaryExprs_2303;
	Packets_t _triggerPort_2304;
	Packets_t _argDeclBase_230d;
	Packets_t _member_2316;
	Packets_t _localVar_231f;
	Packets_t _context_2328;
	Packets_t _unaryExprs_2331;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_233e;
		SFC::ArgDeclBase argDeclBase_233f;
		SFC::LocalVar member_2340;
		SFC::LocalVar localVar_2341;
		SFC::Arg context_2342;
		SFC::UnaryExprs unaryExprs_2343;
	};

	std::list< Match> _matches;
};

class RisingEdge_2354
{
public:
	void operator()( const Packets_t& argDeclBases_2355, const Packets_t& members_2357, const Packets_t& localVars_2359, const Packets_t& contexts_235b, const Packets_t& unaryExprss_235d);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_2363, const Udm::Object& member_236c, const Udm::Object& localVar_2375, const Udm::Object& context_237e, const Udm::Object& unaryExprs_2387);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_2355, const Packets_t& members_2357, const Packets_t& localVars_2359, const Packets_t& contexts_235b, const Packets_t& unaryExprss_235d);
	bool patternMatcher( const Udm::Object& argDeclBase_2361, const Udm::Object& member_236a, const Udm::Object& localVar_2373, const Udm::Object& context_237c, const Udm::Object& unaryExprs_2385);
	void effector();

private:
	Packets_t _argDeclBase_235f;
	Packets_t _member_2368;
	Packets_t _localVar_2371;
	Packets_t _context_237a;
	Packets_t _unaryExprs_2383;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2390;
		SFC::LocalVar member_2391;
		SFC::LocalVar localVar_2392;
		SFC::Arg context_2393;
		SFC::UnaryExprs unaryExprs_2394;
	};

	std::list< Match> _matches;
};

class FallingEdge_23a2
{
public:
	void operator()( const Packets_t& argDeclBases_23a3, const Packets_t& members_23a5, const Packets_t& localVars_23a7, const Packets_t& contexts_23a9, const Packets_t& unaryExprss_23ab);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_23b1, const Udm::Object& member_23ba, const Udm::Object& localVar_23c3, const Udm::Object& context_23cc, const Udm::Object& unaryExprs_23d5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_23a3, const Packets_t& members_23a5, const Packets_t& localVars_23a7, const Packets_t& contexts_23a9, const Packets_t& unaryExprss_23ab);
	bool patternMatcher( const Udm::Object& argDeclBase_23af, const Udm::Object& member_23b8, const Udm::Object& localVar_23c1, const Udm::Object& context_23ca, const Udm::Object& unaryExprs_23d3);
	void effector();

private:
	Packets_t _argDeclBase_23ad;
	Packets_t _member_23b6;
	Packets_t _localVar_23bf;
	Packets_t _context_23c8;
	Packets_t _unaryExprs_23d1;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_23de;
		SFC::LocalVar member_23df;
		SFC::LocalVar localVar_23e0;
		SFC::Arg context_23e1;
		SFC::UnaryExprs unaryExprs_23e2;
	};

	std::list< Match> _matches;
};

class EitherEdge_23f0
{
public:
	void operator()( const Packets_t& argDeclBases_23f1, const Packets_t& members_23f4, const Packets_t& localVars_23f7, const Packets_t& contexts_23fa, const Packets_t& unaryExprss_23fd, Packets_t& argDeclBases_23f3, Packets_t& members_23f6, Packets_t& localVars_23f9, Packets_t& contexts_23fc, Packets_t& leftUnaryExprss_23ff, Packets_t& rightUnaryExprss_2400);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_240b, const Udm::Object& member_2414, const Udm::Object& localVar_241d, const Udm::Object& context_2426, const Udm::Object& unaryExprs_242f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_23f1, const Packets_t& members_23f4, const Packets_t& localVars_23f7, const Packets_t& contexts_23fa, const Packets_t& unaryExprss_23fd);
	bool patternMatcher( const Udm::Object& argDeclBase_2409, const Udm::Object& member_2412, const Udm::Object& localVar_241b, const Udm::Object& context_2424, const Udm::Object& unaryExprs_242d);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_2440, const SFC::LocalVar& member_2442, const SFC::LocalVar& localVar_2444, const SFC::Arg& context_2446, const SFC::UnaryExprs& leftUnaryExprs_2448, const SFC::UnaryExprs& rightUnaryExprs_244a);

private:
	Packets_t* _argDeclBase_2401;
	Packets_t* _member_2402;
	Packets_t* _localVar_2403;
	Packets_t* _context_2404;
	Packets_t* _leftUnaryExprs_2405;
	Packets_t* _rightUnaryExprs_2406;
	Packets_t _argDeclBase_2407;
	Packets_t _member_2410;
	Packets_t _localVar_2419;
	Packets_t _context_2422;
	Packets_t _unaryExprs_242b;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2438;
		SFC::LocalVar member_2439;
		SFC::LocalVar localVar_243a;
		SFC::Arg context_243b;
		SFC::UnaryExprs unaryExprs_243c;
	};

	std::list< Match> _matches;
};

class AddMatrixTriggerVars_2480
{
public:
	void operator()( const Packets_t& triggers_2481, const Packets_t& argdecls_2483, const Packets_t& dts_2485, const Packets_t& oldvals_2487, const Packets_t& contexts_2489, const Packets_t& functions_248b, Packets_t& triggers_248d, Packets_t& argdecls_248e, Packets_t& dts_248f, Packets_t& oldvals_2490, Packets_t& contexts_2491, Packets_t& functions_2492);

protected:
	void callAddTriggerVar_277a( const Packets_t& triggerPorts_249a, const Packets_t& argDeclBases_249d, const Packets_t& dTs_24a0, const Packets_t& localVars_24a2, const Packets_t& contexts_24a5, const Packets_t& functions_24a9);
	void callStartAssignment_2781( const Packets_t& triggerPorts_2506, const Packets_t& argDeclBases_2509, const Packets_t& oldvals_250c, const Packets_t& contexts_250f, const Packets_t& triggerVars_2512, const Packets_t& functions_2514);
	void callEdgeTest_2788( const Packets_t& triggers_256b, const Packets_t& argdecls_256d, const Packets_t& oldvals_256f, const Packets_t& contexts_2571, const Packets_t& initexprs_2573);
	void callRisingEdge_278e( const Packets_t& argDeclBases_26b3, const Packets_t& localVars_26b5, const Packets_t& contexts_26b7, const Packets_t& unaryExprss_26b9);
	void callFallingEdge_2793( const Packets_t& argDeclBases_26f1, const Packets_t& localVars_26f3, const Packets_t& contexts_26f5, const Packets_t& unaryExprss_26f7);
	void callEitherEdge_2798( const Packets_t& argDeclBases_272f, const Packets_t& localVars_2732, const Packets_t& contexts_2735, const Packets_t& unaryExprss_2738);
	void callRisingEdge_279d( const Packets_t& argDeclBases_26b3, const Packets_t& localVars_26b5, const Packets_t& contexts_26b7, const Packets_t& unaryExprss_26b9);
	void callFallingEdge_27a2( const Packets_t& argDeclBases_26f1, const Packets_t& localVars_26f3, const Packets_t& contexts_26f5, const Packets_t& unaryExprss_26f7);

private:
	Packets_t* _trigger_2493;
	Packets_t* _argdecl_2494;
	Packets_t* _dt_2495;
	Packets_t* _oldval_2496;
	Packets_t* _context_2497;
	Packets_t* _function_2498;
};

class AddTriggerVar_2499
{
public:
	void operator()( const Packets_t& triggerPorts_249a, const Packets_t& argDeclBases_249d, const Packets_t& dTs_24a0, const Packets_t& localVars_24a2, const Packets_t& contexts_24a5, const Packets_t& functions_24a9, Packets_t& triggerPorts_249c, Packets_t& argDeclBases_249f, Packets_t& localVars_24a4, Packets_t& contexts_24a7, Packets_t& triggerVars_24a8, Packets_t& functions_24ab);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_24b6, const Udm::Object& argDeclBase_24bf, const Udm::Object& dT_24c8, const Udm::Object& localVar_24d1, const Udm::Object& context_24da, const Udm::Object& function_24e3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::DT& DT, SFC::Function& Function, SFC::LocalVar& LocalVar, ESMoL::TriggerPort& TriggerPort);
	void processInputPackets( const Packets_t& triggerPorts_249a, const Packets_t& argDeclBases_249d, const Packets_t& dTs_24a0, const Packets_t& localVars_24a2, const Packets_t& contexts_24a5, const Packets_t& functions_24a9);
	bool patternMatcher( const Udm::Object& triggerPort_24b4, const Udm::Object& argDeclBase_24bd, const Udm::Object& dT_24c6, const Udm::Object& localVar_24cf, const Udm::Object& context_24d8, const Udm::Object& function_24e1);
	void effector();
	void outputAppender( const ESMoL::TriggerPort& triggerPort_24f9, const SFC::ArgDeclBase& argDeclBase_24fb, const SFC::LocalVar& localVar_24fd, const SFC::Arg& context_24ff, const SFC::LocalVar& triggerVar_2501, const SFC::Function& function_2503);

private:
	Packets_t* _triggerPort_24ac;
	Packets_t* _argDeclBase_24ad;
	Packets_t* _localVar_24ae;
	Packets_t* _context_24af;
	Packets_t* _triggerVar_24b0;
	Packets_t* _function_24b1;
	Packets_t _triggerPort_24b2;
	Packets_t _argDeclBase_24bb;
	Packets_t _dT_24c4;
	Packets_t _localVar_24cd;
	Packets_t _context_24d6;
	Packets_t _function_24df;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_24ec;
		SFC::ArgDeclBase argDeclBase_24ed;
		SFC::DT dT_24ee;
		SFC::LocalVar localVar_24ef;
		SFC::Arg context_24f0;
		SFC::Function function_24f1;
	};

	std::list< Match> _matches;
};

class StartAssignment_2505
{
public:
	void operator()( const Packets_t& triggerPorts_2506, const Packets_t& argDeclBases_2509, const Packets_t& oldvals_250c, const Packets_t& contexts_250f, const Packets_t& triggerVars_2512, const Packets_t& functions_2514, Packets_t& triggerPorts_2508, Packets_t& argDeclBases_250b, Packets_t& oldvals_250e, Packets_t& contexts_2511, Packets_t& unaryExprss_2516);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_2520, const Udm::Object& argDeclBase_2529, const Udm::Object& oldval_2532, const Udm::Object& context_253b, const Udm::Object& triggerVar_2544, const Udm::Object& function_254d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& triggerPorts_2506, const Packets_t& argDeclBases_2509, const Packets_t& oldvals_250c, const Packets_t& contexts_250f, const Packets_t& triggerVars_2512, const Packets_t& functions_2514);
	bool patternMatcher( const Udm::Object& triggerPort_251e, const Udm::Object& argDeclBase_2527, const Udm::Object& oldval_2530, const Udm::Object& context_2539, const Udm::Object& triggerVar_2542, const Udm::Object& function_254b);
	void effector();
	void outputAppender( const ESMoL::TriggerPort& triggerPort_2560, const SFC::ArgDeclBase& argDeclBase_2562, const SFC::LocalVar& oldval_2564, const SFC::Arg& context_2566, const SFC::UnaryExprs& unaryExprs_2568);

private:
	Packets_t* _triggerPort_2517;
	Packets_t* _argDeclBase_2518;
	Packets_t* _oldval_2519;
	Packets_t* _context_251a;
	Packets_t* _unaryExprs_251b;
	Packets_t _triggerPort_251c;
	Packets_t _argDeclBase_2525;
	Packets_t _oldval_252e;
	Packets_t _context_2537;
	Packets_t _triggerVar_2540;
	Packets_t _function_2549;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_2556;
		SFC::ArgDeclBase argDeclBase_2557;
		SFC::LocalVar oldval_2558;
		SFC::Arg context_2559;
		SFC::LocalVar triggerVar_255a;
		SFC::Function function_255b;
	};

	std::list< Match> _matches;
};

class EdgeTest_256a
{
public:
	void operator()( const Packets_t& triggers_256b, const Packets_t& argdecls_256d, const Packets_t& oldvals_256f, const Packets_t& contexts_2571, const Packets_t& initexprs_2573, Packets_t& argdecls_2575, Packets_t& oldvals_2576, Packets_t& contexts_2577, Packets_t& initexprs_2578, Packets_t& argdecls_2579, Packets_t& oldvals_257a, Packets_t& contexts_257b, Packets_t& initexprs_257c, Packets_t& argdecls_257d, Packets_t& oldvals_257e, Packets_t& contexts_257f, Packets_t& initexprs_2580);

protected:
	void executeOne( const Packets_t& triggers_256b, const Packets_t& argdecls_256d, const Packets_t& oldvals_256f, const Packets_t& contexts_2571, const Packets_t& initexprs_2573);
	bool isInputUnique( const Udm::Object& trigger_258f, const Udm::Object& argdecl_2596, const Udm::Object& oldval_259d, const Udm::Object& context_25a4, const Udm::Object& initexpr_25ab);

private:
	Packets_t* _argdecl_2581;
	Packets_t* _oldval_2582;
	Packets_t* _context_2583;
	Packets_t* _initexpr_2584;
	Packets_t* _argdecl_2585;
	Packets_t* _oldval_2586;
	Packets_t* _context_2587;
	Packets_t* _initexpr_2588;
	Packets_t* _argdecl_2589;
	Packets_t* _oldval_258a;
	Packets_t* _context_258b;
	Packets_t* _initexpr_258c;
	Packets_t _trigger_258d;
	Packets_t _argdecl_2594;
	Packets_t _oldval_259b;
	Packets_t _context_25a2;
	Packets_t _initexpr_25a9;
};

class RisingEdge_25b0
{
public:
	bool operator()( const Packets_t& triggerPorts_25b1, const Packets_t& argDeclBases_25b3, const Packets_t& localVars_25b6, const Packets_t& contexts_25b9, const Packets_t& unaryExprss_25bc, Packets_t& argDeclBases_25b5, Packets_t& localVars_25b8, Packets_t& contexts_25bb, Packets_t& unaryExprss_25be);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_25c7, const Udm::Object& argDeclBase_25d0, const Udm::Object& localVar_25d9, const Udm::Object& context_25e2, const Udm::Object& unaryExprs_25eb);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::LocalVar& LocalVar, ESMoL::TriggerPort& TriggerPort, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& triggerPorts_25b1, const Packets_t& argDeclBases_25b3, const Packets_t& localVars_25b6, const Packets_t& contexts_25b9, const Packets_t& unaryExprss_25bc);
	bool patternMatcher( const Udm::Object& triggerPort_25c5, const Udm::Object& argDeclBase_25ce, const Udm::Object& localVar_25d7, const Udm::Object& context_25e0, const Udm::Object& unaryExprs_25e9);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_25fe, const SFC::LocalVar& localVar_2600, const SFC::Arg& context_2602, const SFC::UnaryExprs& unaryExprs_2604);

private:
	Packets_t* _argDeclBase_25bf;
	Packets_t* _localVar_25c0;
	Packets_t* _context_25c1;
	Packets_t* _unaryExprs_25c2;
	Packets_t _triggerPort_25c3;
	Packets_t _argDeclBase_25cc;
	Packets_t _localVar_25d5;
	Packets_t _context_25de;
	Packets_t _unaryExprs_25e7;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_25f4;
		SFC::ArgDeclBase argDeclBase_25f5;
		SFC::LocalVar localVar_25f6;
		SFC::Arg context_25f7;
		SFC::UnaryExprs unaryExprs_25f8;
	};

	std::list< Match> _matches;
};

class FallingEdge_2606
{
public:
	bool operator()( const Packets_t& triggerPorts_2607, const Packets_t& argDeclBases_2609, const Packets_t& localVars_260c, const Packets_t& contexts_260f, const Packets_t& unaryExprss_2612, Packets_t& argDeclBases_260b, Packets_t& localVars_260e, Packets_t& contexts_2611, Packets_t& unaryExprss_2614);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_261d, const Udm::Object& argDeclBase_2626, const Udm::Object& localVar_262f, const Udm::Object& context_2638, const Udm::Object& unaryExprs_2641);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::LocalVar& LocalVar, ESMoL::TriggerPort& TriggerPort, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& triggerPorts_2607, const Packets_t& argDeclBases_2609, const Packets_t& localVars_260c, const Packets_t& contexts_260f, const Packets_t& unaryExprss_2612);
	bool patternMatcher( const Udm::Object& triggerPort_261b, const Udm::Object& argDeclBase_2624, const Udm::Object& localVar_262d, const Udm::Object& context_2636, const Udm::Object& unaryExprs_263f);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_2654, const SFC::LocalVar& localVar_2656, const SFC::Arg& context_2658, const SFC::UnaryExprs& unaryExprs_265a);

private:
	Packets_t* _argDeclBase_2615;
	Packets_t* _localVar_2616;
	Packets_t* _context_2617;
	Packets_t* _unaryExprs_2618;
	Packets_t _triggerPort_2619;
	Packets_t _argDeclBase_2622;
	Packets_t _localVar_262b;
	Packets_t _context_2634;
	Packets_t _unaryExprs_263d;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_264a;
		SFC::ArgDeclBase argDeclBase_264b;
		SFC::LocalVar localVar_264c;
		SFC::Arg context_264d;
		SFC::UnaryExprs unaryExprs_264e;
	};

	std::list< Match> _matches;
};

class EitherEdge_265c
{
public:
	bool operator()( const Packets_t& triggerPorts_265d, const Packets_t& argDeclBases_265f, const Packets_t& localVars_2662, const Packets_t& contexts_2665, const Packets_t& unaryExprss_2668, Packets_t& argDeclBases_2661, Packets_t& localVars_2664, Packets_t& contexts_2667, Packets_t& unaryExprss_266a);

protected:
	bool isInputUnique( const Udm::Object& triggerPort_2673, const Udm::Object& argDeclBase_267c, const Udm::Object& localVar_2685, const Udm::Object& context_268e, const Udm::Object& unaryExprs_2697);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgDeclBase& ArgDeclBase, SFC::Arg& Context, SFC::LocalVar& LocalVar, ESMoL::TriggerPort& TriggerPort, SFC::UnaryExprs& UnaryExprs);
	void processInputPackets( const Packets_t& triggerPorts_265d, const Packets_t& argDeclBases_265f, const Packets_t& localVars_2662, const Packets_t& contexts_2665, const Packets_t& unaryExprss_2668);
	bool patternMatcher( const Udm::Object& triggerPort_2671, const Udm::Object& argDeclBase_267a, const Udm::Object& localVar_2683, const Udm::Object& context_268c, const Udm::Object& unaryExprs_2695);
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_26aa, const SFC::LocalVar& localVar_26ac, const SFC::Arg& context_26ae, const SFC::UnaryExprs& unaryExprs_26b0);

private:
	Packets_t* _argDeclBase_266b;
	Packets_t* _localVar_266c;
	Packets_t* _context_266d;
	Packets_t* _unaryExprs_266e;
	Packets_t _triggerPort_266f;
	Packets_t _argDeclBase_2678;
	Packets_t _localVar_2681;
	Packets_t _context_268a;
	Packets_t _unaryExprs_2693;
	class Match
	{
	public:
		ESMoL::TriggerPort triggerPort_26a0;
		SFC::ArgDeclBase argDeclBase_26a1;
		SFC::LocalVar localVar_26a2;
		SFC::Arg context_26a3;
		SFC::UnaryExprs unaryExprs_26a4;
	};

	std::list< Match> _matches;
};

class RisingEdge_26b2
{
public:
	void operator()( const Packets_t& argDeclBases_26b3, const Packets_t& localVars_26b5, const Packets_t& contexts_26b7, const Packets_t& unaryExprss_26b9);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_26bf, const Udm::Object& localVar_26c8, const Udm::Object& context_26d1, const Udm::Object& unaryExprs_26da);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_26b3, const Packets_t& localVars_26b5, const Packets_t& contexts_26b7, const Packets_t& unaryExprss_26b9);
	bool patternMatcher( const Udm::Object& argDeclBase_26bd, const Udm::Object& localVar_26c6, const Udm::Object& context_26cf, const Udm::Object& unaryExprs_26d8);
	void effector();

private:
	Packets_t _argDeclBase_26bb;
	Packets_t _localVar_26c4;
	Packets_t _context_26cd;
	Packets_t _unaryExprs_26d6;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_26e3;
		SFC::LocalVar localVar_26e4;
		SFC::Arg context_26e5;
		SFC::UnaryExprs unaryExprs_26e6;
	};

	std::list< Match> _matches;
};

class FallingEdge_26f0
{
public:
	void operator()( const Packets_t& argDeclBases_26f1, const Packets_t& localVars_26f3, const Packets_t& contexts_26f5, const Packets_t& unaryExprss_26f7);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_26fd, const Udm::Object& localVar_2706, const Udm::Object& context_270f, const Udm::Object& unaryExprs_2718);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_26f1, const Packets_t& localVars_26f3, const Packets_t& contexts_26f5, const Packets_t& unaryExprss_26f7);
	bool patternMatcher( const Udm::Object& argDeclBase_26fb, const Udm::Object& localVar_2704, const Udm::Object& context_270d, const Udm::Object& unaryExprs_2716);
	void effector();

private:
	Packets_t _argDeclBase_26f9;
	Packets_t _localVar_2702;
	Packets_t _context_270b;
	Packets_t _unaryExprs_2714;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2721;
		SFC::LocalVar localVar_2722;
		SFC::Arg context_2723;
		SFC::UnaryExprs unaryExprs_2724;
	};

	std::list< Match> _matches;
};

class EitherEdge_272e
{
public:
	void operator()( const Packets_t& argDeclBases_272f, const Packets_t& localVars_2732, const Packets_t& contexts_2735, const Packets_t& unaryExprss_2738, Packets_t& argDeclBases_2731, Packets_t& localVars_2734, Packets_t& contexts_2737, Packets_t& leftUnaryExprss_273a, Packets_t& rightUnaryExprss_273b);

protected:
	bool isInputUnique( const Udm::Object& argDeclBase_2745, const Udm::Object& localVar_274e, const Udm::Object& context_2757, const Udm::Object& unaryExprs_2760);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& argDeclBases_272f, const Packets_t& localVars_2732, const Packets_t& contexts_2735, const Packets_t& unaryExprss_2738);
	bool patternMatcher( const Udm::Object& argDeclBase_2743, const Udm::Object& localVar_274c, const Udm::Object& context_2755, const Udm::Object& unaryExprs_275e);
	void effector();
	void outputAppender( const SFC::ArgDeclBase& argDeclBase_2770, const SFC::LocalVar& localVar_2772, const SFC::Arg& context_2774, const SFC::UnaryExprs& leftUnaryExprs_2776, const SFC::UnaryExprs& rightUnaryExprs_2778);

private:
	Packets_t* _argDeclBase_273c;
	Packets_t* _localVar_273d;
	Packets_t* _context_273e;
	Packets_t* _leftUnaryExprs_273f;
	Packets_t* _rightUnaryExprs_2740;
	Packets_t _argDeclBase_2741;
	Packets_t _localVar_274a;
	Packets_t _context_2753;
	Packets_t _unaryExprs_275c;
	class Match
	{
	public:
		SFC::ArgDeclBase argDeclBase_2769;
		SFC::LocalVar localVar_276a;
		SFC::Arg context_276b;
		SFC::UnaryExprs unaryExprs_276c;
	};

	std::list< Match> _matches;
};

class GetTriggerPort_27d1
{
public:
	void operator()( const Packets_t& subsystems_27d2, const Packets_t& blocks_27d5, const Packets_t& mains_27d8, Packets_t& subsystems_27d4, Packets_t& triggerPorts_27d7, Packets_t& mains_27da);

protected:
	bool isInputUnique( const Udm::Object& subsystem_27e2, const Udm::Object& block_27eb, const Udm::Object& main_27f4);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_27d2, const Packets_t& blocks_27d5, const Packets_t& mains_27d8);
	bool patternMatcher( const Udm::Object& subsystem_27e0, const Udm::Object& block_27e9, const Udm::Object& main_27f2);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_2804, const ESMoL::TriggerPort& triggerPort_2806, const SFC::Function& main_2808);

private:
	Packets_t* _subsystem_27db;
	Packets_t* _triggerPort_27dc;
	Packets_t* _main_27dd;
	Packets_t _subsystem_27de;
	Packets_t _block_27e7;
	Packets_t _main_27f0;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2800;
		ESMoL::Block block_2801;
		SFC::Function main_2802;
		ESMoL::TriggerPort triggerPort_2803;
	};

	std::list< Match> _matches;
};

class AssignCondVal_280a
{
public:
	void operator()( const Packets_t& subsystems_280b, const Packets_t& triggerPorts_280e, const Packets_t& functions_2813, Packets_t& subsystems_280d, Packets_t& triggerPorts_2810, Packets_t& argDeclBases_2811, Packets_t& dTs_2812, Packets_t& functions_2815);

protected:
	bool isInputUnique( const Udm::Object& subsystem_281f, const Udm::Object& triggerPort_2828, const Udm::Object& function_2831);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_280b, const Packets_t& triggerPorts_280e, const Packets_t& functions_2813);
	bool patternMatcher( const Udm::Object& subsystem_281d, const Udm::Object& triggerPort_2826, const Udm::Object& function_282f);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_2841, const ESMoL::Port& triggerPort_2843, const SFC::ArgDeclBase& argDeclBase_2845, const SFC::DT& dT_2847, const SFC::Function& function_2849);

private:
	Packets_t* _subsystem_2816;
	Packets_t* _triggerPort_2817;
	Packets_t* _argDeclBase_2818;
	Packets_t* _dT_2819;
	Packets_t* _function_281a;
	Packets_t _subsystem_281b;
	Packets_t _triggerPort_2824;
	Packets_t _function_282d;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_283c;
		ESMoL::Port triggerPort_283d;
		SFC::Function function_283e;
		SFC::ArgDeclBase argDeclBase_283f;
		SFC::DT dT_2840;
	};

	std::list< Match> _matches;
};

class IsTriggered_2859
{
public:
	void operator()( const Packets_t& systems_285a, const Packets_t& childSubsystems_285c, const Packets_t& systemFunctions_285e, Packets_t& systems_2860, Packets_t& childSubsystems_2861, Packets_t& systemFunctions_2862, Packets_t& systems_2863, Packets_t& childSubsystems_2864, Packets_t& systemFunctions_2865, Packets_t& systems_2866, Packets_t& childSubsystems_2867, Packets_t& systemFunctions_2868);

protected:
	void executeOne( const Packets_t& systems_285a, const Packets_t& childSubsystems_285c, const Packets_t& systemFunctions_285e);
	bool isInputUnique( const Udm::Object& system_2874, const Udm::Object& childSubsystem_287b, const Udm::Object& systemFunction_2882);

private:
	Packets_t* _system_2869;
	Packets_t* _childSubsystem_286a;
	Packets_t* _systemFunction_286b;
	Packets_t* _system_286c;
	Packets_t* _childSubsystem_286d;
	Packets_t* _systemFunction_286e;
	Packets_t* _system_286f;
	Packets_t* _childSubsystem_2870;
	Packets_t* _systemFunction_2871;
	Packets_t _system_2872;
	Packets_t _childSubsystem_2879;
	Packets_t _systemFunction_2880;
};

class HasTriggers_2887
{
public:
	bool operator()( const Packets_t& subsystems_2888, const Packets_t& blocks_288b, const Packets_t& mains_288e, Packets_t& subsystems_288a, Packets_t& blocks_288d, Packets_t& mains_2890);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2898, const Udm::Object& block_28a1, const Udm::Object& main_28aa);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2888, const Packets_t& blocks_288b, const Packets_t& mains_288e);
	bool patternMatcher( const Udm::Object& subsystem_2896, const Udm::Object& block_289f, const Udm::Object& main_28a8);
	void outputAppender( const ESMoL::Subsystem& subsystem_28ba, const ESMoL::Subsystem& block_28bc, const SFC::Function& main_28be);

private:
	Packets_t* _subsystem_2891;
	Packets_t* _block_2892;
	Packets_t* _main_2893;
	Packets_t _subsystem_2894;
	Packets_t _block_289d;
	Packets_t _main_28a6;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_28b6;
		ESMoL::Subsystem block_28b7;
		SFC::Function main_28b8;
		ESMoL::TriggerPort triggerPort_28b9;
	};

	std::list< Match> _matches;
};

class HasActionPort_28c0
{
public:
	bool operator()( const Packets_t& subsystems_28c1, const Packets_t& blocks_28c4, const Packets_t& mains_28c7, Packets_t& subsystems_28c3, Packets_t& blocks_28c6, Packets_t& mains_28c9);

protected:
	bool isInputUnique( const Udm::Object& subsystem_28d1, const Udm::Object& block_28da, const Udm::Object& main_28e3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_28c1, const Packets_t& blocks_28c4, const Packets_t& mains_28c7);
	bool patternMatcher( const Udm::Object& subsystem_28cf, const Udm::Object& block_28d8, const Udm::Object& main_28e1);
	void outputAppender( const ESMoL::Subsystem& subsystem_28f3, const ESMoL::Subsystem& block_28f5, const SFC::Function& main_28f7);

private:
	Packets_t* _subsystem_28ca;
	Packets_t* _block_28cb;
	Packets_t* _main_28cc;
	Packets_t _subsystem_28cd;
	Packets_t _block_28d6;
	Packets_t _main_28df;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_28ef;
		ESMoL::Subsystem block_28f0;
		SFC::Function main_28f1;
		ESMoL::ActionPort actionPort_28f2;
	};

	std::list< Match> _matches;
};

class Otherwise_28f9
{
public:
	bool operator()( const Packets_t& subsystems_28fa, const Packets_t& blocks_28fd, const Packets_t& mains_2900, Packets_t& subsystems_28fc, Packets_t& blocks_28ff, Packets_t& mains_2902);

protected:
	bool isInputUnique( const Udm::Object& subsystem_290a, const Udm::Object& block_2913, const Udm::Object& main_291c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_28fa, const Packets_t& blocks_28fd, const Packets_t& mains_2900);
	bool patternMatcher( const Udm::Object& subsystem_2908, const Udm::Object& block_2911, const Udm::Object& main_291a);
	void outputAppender( const ESMoL::Subsystem& subsystem_2928, const ESMoL::Subsystem& block_292a, const SFC::Function& main_292c);

private:
	Packets_t* _subsystem_2903;
	Packets_t* _block_2904;
	Packets_t* _main_2905;
	Packets_t _subsystem_2906;
	Packets_t _block_290f;
	Packets_t _main_2918;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2925;
		ESMoL::Subsystem block_2926;
		SFC::Function main_2927;
	};

	std::list< Match> _matches;
};

class CreateFunctionCallArgs_293a
{
public:
	void operator()( const Packets_t& subsystems_293b, const Packets_t& functions_293e, const Packets_t& methodCalls_2941, Packets_t& subsystems_293d, Packets_t& ports_2940, Packets_t& argVals_2943);

protected:
	bool isInputUnique( const Udm::Object& subsystem_294b, const Udm::Object& function_2954, const Udm::Object& methodCall_295d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_293b, const Packets_t& functions_293e, const Packets_t& methodCalls_2941);
	bool patternMatcher( const Udm::Object& subsystem_2949, const Udm::Object& function_2952, const Udm::Object& methodCall_295b);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_2972, const ESMoL::Port& port_2974, const SFC::ArgVal& argVal_2976);

private:
	Packets_t* _subsystem_2944;
	Packets_t* _port_2945;
	Packets_t* _argVal_2946;
	Packets_t _subsystem_2947;
	Packets_t _function_2950;
	Packets_t _methodCall_2959;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_296c;
		SFC::Function function_296d;
		SFC::FunctionCall methodCall_296e;
		SFC::Arg arg_296f;
		ESMoL::Port port_2970;
	};

	std::list< Match> _matches;
};

class CreateMethodCall_2978
{
public:
	void operator()( const Packets_t& subsystems_2979, const Packets_t& blocks_297d, const Packets_t& mains_2980, Packets_t& subsystems_297b, Packets_t& functions_297c, Packets_t& methodCalls_297f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2989, const Udm::Object& block_2992, const Udm::Object& main_299b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2979, const Packets_t& blocks_297d, const Packets_t& mains_2980);
	bool patternMatcher( const Udm::Object& subsystem_2987, const Udm::Object& block_2990, const Udm::Object& main_2999);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_29b9, const SFC::Function& function_29bb, const SFC::FunctionCall& methodCall_29bd);

private:
	Packets_t* _subsystem_2982;
	Packets_t* _function_2983;
	Packets_t* _methodCall_2984;
	Packets_t _subsystem_2985;
	Packets_t _block_298e;
	Packets_t _main_2997;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_29b0;
		ESMoL::Subsystem block_29b1;
		SFC::CompoundStatement main_29b2;
		SFC::Function function_29b3;
		SFC::Class class_29b4;
		SFC::Arg arg_29b5;
		SFC::Struct struct_29b6;
	};

	std::list< Match> _matches;
};

class TestChildBlock_29cf
{
public:
	void operator()( const Packets_t& systems_29d0, const Packets_t& childBlocks_29d2, const Packets_t& systemFunctions_29d4, Packets_t& systems_29d6, Packets_t& childCharts_29d7, Packets_t& systemFunctions_29d8, Packets_t& systems_29d9, Packets_t& childSubsystems_29da, Packets_t& systemFunctions_29db, Packets_t& systems_29dc, Packets_t& childBlocks_29dd, Packets_t& systemFunctions_29de);

protected:
	void executeOne( const Packets_t& systems_29d0, const Packets_t& childBlocks_29d2, const Packets_t& systemFunctions_29d4);
	bool isInputUnique( const Udm::Object& system_29ea, const Udm::Object& childBlock_29f1, const Udm::Object& systemFunction_29f8);

private:
	Packets_t* _system_29df;
	Packets_t* _childChart_29e0;
	Packets_t* _systemFunction_29e1;
	Packets_t* _system_29e2;
	Packets_t* _childSubsystem_29e3;
	Packets_t* _systemFunction_29e4;
	Packets_t* _system_29e5;
	Packets_t* _childBlock_29e6;
	Packets_t* _systemFunction_29e7;
	Packets_t _system_29e8;
	Packets_t _childBlock_29ef;
	Packets_t _systemFunction_29f6;
};

class IsChart_29fd
{
public:
	bool operator()( const Packets_t& subsystems_29fe, const Packets_t& blocks_2a01, const Packets_t& mains_2a04, Packets_t& subsystems_2a00, Packets_t& blocks_2a03, Packets_t& mains_2a06);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2a0e, const Udm::Object& block_2a17, const Udm::Object& main_2a20);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_29fe, const Packets_t& blocks_2a01, const Packets_t& mains_2a04);
	bool patternMatcher( const Udm::Object& subsystem_2a0c, const Udm::Object& block_2a15, const Udm::Object& main_2a1e);
	void outputAppender( const ESMoL::Subsystem& subsystem_2a34, const ESMoL::Subsystem& block_2a36, const SFC::Function& main_2a38);

private:
	Packets_t* _subsystem_2a07;
	Packets_t* _block_2a08;
	Packets_t* _main_2a09;
	Packets_t _subsystem_2a0a;
	Packets_t _block_2a13;
	Packets_t _main_2a1c;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2a2f;
		ESMoL::Subsystem block_2a30;
		SFC::Function main_2a31;
		ESMoL::Primitive primitive_2a32;
		ESMoL::ConnectorRef connectorRef_2a33;
	};

	std::list< Match> _matches;
};

class IsSubsystem_2a3a
{
public:
	bool operator()( const Packets_t& subsystems_2a3b, const Packets_t& blocks_2a3e, const Packets_t& mains_2a41, Packets_t& subsystems_2a3d, Packets_t& blocks_2a40, Packets_t& mains_2a43);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2a4b, const Udm::Object& block_2a54, const Udm::Object& main_2a5d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2a3b, const Packets_t& blocks_2a3e, const Packets_t& mains_2a41);
	bool patternMatcher( const Udm::Object& subsystem_2a49, const Udm::Object& block_2a52, const Udm::Object& main_2a5b);
	void outputAppender( const ESMoL::Subsystem& subsystem_2a69, const ESMoL::Subsystem& block_2a6b, const SFC::Function& main_2a6d);

private:
	Packets_t* _subsystem_2a44;
	Packets_t* _block_2a45;
	Packets_t* _main_2a46;
	Packets_t _subsystem_2a47;
	Packets_t _block_2a50;
	Packets_t _main_2a59;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2a66;
		ESMoL::Subsystem block_2a67;
		SFC::Function main_2a68;
	};

	std::list< Match> _matches;
};

class Otherwise_2a6f
{
public:
	bool operator()( const Packets_t& subsystems_2a70, const Packets_t& blocks_2a73, const Packets_t& mains_2a76, Packets_t& subsystems_2a72, Packets_t& blocks_2a75, Packets_t& mains_2a78);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2a80, const Udm::Object& block_2a89, const Udm::Object& main_2a92);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2a70, const Packets_t& blocks_2a73, const Packets_t& mains_2a76);
	bool patternMatcher( const Udm::Object& subsystem_2a7e, const Udm::Object& block_2a87, const Udm::Object& main_2a90);
	void outputAppender( const ESMoL::Subsystem& subsystem_2a9e, const ESMoL::Block& block_2aa0, const SFC::Function& main_2aa2);

private:
	Packets_t* _subsystem_2a79;
	Packets_t* _block_2a7a;
	Packets_t* _main_2a7b;
	Packets_t _subsystem_2a7c;
	Packets_t _block_2a85;
	Packets_t _main_2a8e;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2a9b;
		ESMoL::Block block_2a9c;
		SFC::Function main_2a9d;
	};

	std::list< Match> _matches;
};

class AssignType_2ab3
{
public:
	void operator()( const Packets_t& ports_2ab4, const Packets_t& argvars_2ab6);

protected:
	void callAssignType_2add( const Packets_t& ports_2ab9, const Packets_t& argvars_2abb);
};

class AssignType_2ab8
{
public:
	void operator()( const Packets_t& ports_2ab9, const Packets_t& argvars_2abb);

protected:
	bool isInputUnique( const Udm::Object& port_2ac1, const Udm::Object& argvar_2aca);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& ports_2ab9, const Packets_t& argvars_2abb);
	bool patternMatcher( const Udm::Object& port_2abf, const Udm::Object& argvar_2ac8);
	void effector();

private:
	Packets_t _port_2abd;
	Packets_t _argvar_2ac6;
	class Match
	{
	public:
		ESMoL::Port port_2ad8;
		SFC::ArgDeclBase argvar_2ad9;
		ESMoL::TypeBaseRef typeBaseRef_2ada;
		ESMoL::TypeBase typeBase_2adb;
		SFC::DT dT_2adc;
	};

	std::list< Match> _matches;
};

class SubsystemFilter_2ae0
{
public:
	void operator()( const Packets_t& systems_2ae1, Packets_t& chartsystems_2ae3, Packets_t& systems_2ae4);

protected:
	void callSubsystemFilter_2b61( const Packets_t& systems_2ae8);

private:
	Packets_t* _chartsystem_2ae5;
	Packets_t* _system_2ae6;
};

class SubsystemFilter_2ae7
{
public:
	void operator()( const Packets_t& systems_2ae8, Packets_t& systems_2aea, Packets_t& systems_2aeb, Packets_t& systems_2aec, Packets_t& systems_2aed);

protected:
	void executeOne( const Packets_t& systems_2ae8);
	bool isInputUnique( const Udm::Object& system_2af4);

private:
	Packets_t* _system_2aee;
	Packets_t* _system_2aef;
	Packets_t* _system_2af0;
	Packets_t* _system_2af1;
	Packets_t _system_2af2;
};

class IsStateChartInstance_2af9
{
public:
	bool operator()( const Packets_t& subsystems_2afa, Packets_t& subsystems_2afc);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2b02);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::ConnectorRef& ConnectorRef, ESMoL::Primitive& Primitive, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_2afa);
	bool patternMatcher( const Udm::Object& subsystem_2b00);
	void outputAppender( const ESMoL::Subsystem& subsystem_2b17);

private:
	Packets_t* _subsystem_2afd;
	Packets_t _subsystem_2afe;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2b11;
		ESMoL::Primitive primitive_2b12;
		ESMoL::ConnectorRef connectorRef_2b13;
	};

	std::list< Match> _matches;
};

class IsStateChart_2b19
{
public:
	bool operator()( const Packets_t& subsystems_2b1a, Packets_t& subsystems_2b1c);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2b22);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2b1a);
	bool patternMatcher( const Udm::Object& subsystem_2b20);
	void outputAppender( const ESMoL::Subsystem& subsystem_2b34);

private:
	Packets_t* _subsystem_2b1d;
	Packets_t _subsystem_2b1e;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2b31;
		ESMoL::Primitive primitive_2b32;
		ESMoL::ConnectorRef connectorRef_2b33;
	};

	std::list< Match> _matches;
};

class IsInstance_2b36
{
public:
	bool operator()( const Packets_t& subsystems_2b37, Packets_t& subsystems_2b39);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2b3f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_2b37);
	bool patternMatcher( const Udm::Object& subsystem_2b3d);
	void outputAppender( const ESMoL::Subsystem& subsystem_2b4a);

private:
	Packets_t* _subsystem_2b3a;
	Packets_t _subsystem_2b3b;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2b48;
	};

	std::list< Match> _matches;
};

class Otherwise_2b4c
{
public:
	bool operator()( const Packets_t& subsystems_2b4d, Packets_t& subsystems_2b4f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2b55);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2b4d);
	bool patternMatcher( const Udm::Object& subsystem_2b53);
	void outputAppender( const ESMoL::Subsystem& subsystem_2b5f);

private:
	Packets_t* _subsystem_2b50;
	Packets_t _subsystem_2b51;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2b5e;
	};

	std::list< Match> _matches;
};

class GetSubSubsystems_2b63
{
public:
	void operator()( const Packets_t& systems_2b64, Packets_t& subsystems_2b66);

protected:
	void callGetSubSubsystems_2b81( const Packets_t& subsystems_2b69);

private:
	Packets_t* _subsystem_2b67;
};

class GetSubSubsystems_2b68
{
public:
	void operator()( const Packets_t& subsystems_2b69, Packets_t& subSubsystems_2b6b);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2b71);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2b69);
	bool patternMatcher( const Udm::Object& subsystem_2b6f);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subSubsystem_2b7f);

private:
	Packets_t* _subSubsystem_2b6c;
	Packets_t _subsystem_2b6d;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2b7d;
		ESMoL::Subsystem subSubsystem_2b7e;
	};

	std::list< Match> _matches;
};

class TL_2b83
{
public:
	void operator()( const Packets_t& dataflows_2b84, const Packets_t& projects_2b86);

protected:
	void callGetProject_4c7b( const Packets_t& dataflows_4c5b, const Packets_t& projects_4c5e);
	void callHasRefSubsystems_4c7e( const Packets_t& dataflows_4c28, const Packets_t& projects_4c2a);
	void callCheckPorts_4c81( const Packets_t& dataflows_2b89, const Packets_t& projects_2b8b);
	void callCreateTypes_4c84( const Packets_t& dataflows_45df, const Packets_t& projects_45e1);
	void callMakeClasses_4c87( const Packets_t& dataflows_2f27, const Packets_t& projects_2f29);
	void callFinishClasses_4c8a( const Packets_t& dataflows_2d7c, const Packets_t& projects_2d7e);
	void callMergeClasses_4c8d( const Packets_t& dataflows_3efd, const Packets_t& projects_3eff);
	void callConstructors_4c90( const Packets_t& dataflows_3b5d, const Packets_t& projects_3b5f);
};

class CheckPorts_2b88
{
public:
	void operator()( const Packets_t& dataflows_2b89, const Packets_t& projects_2b8b, Packets_t& dataflows_2b8d, Packets_t& projects_2b8e);

protected:
	void callCheckPortTypes_2d75( const Packets_t& dataflows_2b92, const Packets_t& projects_2b94);
	void callCheckError_2d78( const Packets_t& dataflows_2cd3, const Packets_t& projects_2cd5);

private:
	Packets_t* _dataflow_2b8f;
	Packets_t* _project_2b90;
};

class CheckPortTypes_2b91
{
public:
	void operator()( const Packets_t& dataflows_2b92, const Packets_t& projects_2b94, Packets_t& dataflows_2b96, Packets_t& projects_2b97);

protected:
	void callGetSubsystems_2cce( const Packets_t& dataflows_1);
	void callCheckAllPorts_2cd0( const Packets_t& blocks_2b9b);

private:
	Packets_t* _dataflow_2b98;
	Packets_t* _project_2b99;
};

class CheckAllPorts_2b9a
{
public:
	void operator()( const Packets_t& blocks_2b9b);

protected:
	void callFilterInstances_2cc6( const Packets_t& blocks_2c85);
	void callCheckPorts_2cc8( const Packets_t& blocks_2bde);
	void callChartFilter_2cca( const Packets_t& blocks_2b9e);
	void callGetSubBlocks_2ccc( const Packets_t& subsystems_2caf);
};

class ChartFilter_2b9d
{
public:
	void operator()( const Packets_t& blocks_2b9e, Packets_t& systems_2ba0, Packets_t& systems_2ba1);

protected:
	void executeOne( const Packets_t& blocks_2b9e);
	bool isInputUnique( const Udm::Object& block_2ba6);

private:
	Packets_t* _system_2ba2;
	Packets_t* _system_2ba3;
	Packets_t _block_2ba4;
};

class Block_2bab
{
public:
	bool operator()( const Packets_t& subsystems_2bac, Packets_t& subsystems_2bae);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2bb4);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2bac);
	bool patternMatcher( const Udm::Object& subsystem_2bb2);
	void outputAppender( const ESMoL::Subsystem& subsystem_2bc6);

private:
	Packets_t* _subsystem_2baf;
	Packets_t _subsystem_2bb0;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2bc3;
		ESMoL::Primitive primitive_2bc4;
		ESMoL::ConnectorRef connectorRef_2bc5;
	};

	std::list< Match> _matches;
};

class IsSubsystem_2bc8
{
public:
	bool operator()( const Packets_t& subsystems_2bc9, Packets_t& subsystems_2bcb);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2bd1);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2bc9);
	bool patternMatcher( const Udm::Object& subsystem_2bcf);
	void outputAppender( const ESMoL::Subsystem& subsystem_2bdb);

private:
	Packets_t* _subsystem_2bcc;
	Packets_t _subsystem_2bcd;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2bda;
	};

	std::list< Match> _matches;
};

class CheckPorts_2bdd
{
public:
	void operator()( const Packets_t& blocks_2bde, Packets_t& blocks_2be0);

protected:
	void callGetPorts_2c7d( const Packets_t& blocks_2bf6);
	void callCheckPort_2c7f( const Packets_t& blocks_2c13, const Packets_t& ports_2c15);
	void callSetError_2c82( const Packets_t& blocks_2be3);

private:
	Packets_t* _block_2be1;
};

class SetError_2be2
{
public:
	void operator()( const Packets_t& blocks_2be3, Packets_t& blocks_2be5);

protected:
	bool isInputUnique( const Udm::Object& block_2beb);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& blocks_2be3);
	bool patternMatcher( const Udm::Object& block_2be9);
	void effector();
	void forwardInputs();

private:
	Packets_t* _block_2be6;
	Packets_t _block_2be7;
	class Match
	{
	public:
		ESMoL::Block block_2bf4;
	};

	std::list< Match> _matches;
};

class GetPorts_2bf5
{
public:
	void operator()( const Packets_t& blocks_2bf6, Packets_t& blocks_2bf8, Packets_t& ports_2bf9);

protected:
	bool isInputUnique( const Udm::Object& block_2c00);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& blocks_2bf6);
	bool patternMatcher( const Udm::Object& block_2bfe);
	void effector();
	void outputAppender( const ESMoL::Block& block_2c0e, const ESMoL::Port& port_2c10);

private:
	Packets_t* _block_2bfa;
	Packets_t* _port_2bfb;
	Packets_t _block_2bfc;
	class Match
	{
	public:
		ESMoL::Block block_2c0c;
		ESMoL::Port port_2c0d;
	};

	std::list< Match> _matches;
};

class CheckPort_2c12
{
public:
	void operator()( const Packets_t& blocks_2c13, const Packets_t& ports_2c15, Packets_t& blocks_2c17, Packets_t& ports_2c18, Packets_t& blocks_2c19, Packets_t& ports_2c1a);

protected:
	void executeOne( const Packets_t& blocks_2c13, const Packets_t& ports_2c15);
	bool isInputUnique( const Udm::Object& block_2c21, const Udm::Object& port_2c28);

private:
	Packets_t* _block_2c1b;
	Packets_t* _port_2c1c;
	Packets_t* _block_2c1d;
	Packets_t* _port_2c1e;
	Packets_t _block_2c1f;
	Packets_t _port_2c26;
};

class PortHasType_2c2d
{
public:
	bool operator()( const Packets_t& blocks_2c2e, const Packets_t& ports_2c31, Packets_t& blocks_2c30, Packets_t& ports_2c33);

protected:
	bool isInputUnique( const Udm::Object& block_2c3a, const Udm::Object& port_2c43);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& blocks_2c2e, const Packets_t& ports_2c31);
	bool patternMatcher( const Udm::Object& block_2c38, const Udm::Object& port_2c41);
	void outputAppender( const ESMoL::Block& block_2c54, const ESMoL::Port& port_2c56);

private:
	Packets_t* _block_2c34;
	Packets_t* _port_2c35;
	Packets_t _block_2c36;
	Packets_t _port_2c3f;
	class Match
	{
	public:
		ESMoL::Block block_2c50;
		ESMoL::Port port_2c51;
		ESMoL::TypeBaseRef typeBaseRef_2c52;
		ESMoL::TypeBase typeBase_2c53;
	};

	std::list< Match> _matches;
};

class Otherwise_2c58
{
public:
	bool operator()( const Packets_t& blocks_2c59, const Packets_t& ports_2c5c, Packets_t& blocks_2c5b, Packets_t& ports_2c5e);

protected:
	bool isInputUnique( const Udm::Object& block_2c65, const Udm::Object& port_2c6e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& blocks_2c59, const Packets_t& ports_2c5c);
	bool patternMatcher( const Udm::Object& block_2c63, const Udm::Object& port_2c6c);
	void outputAppender( const ESMoL::Block& block_2c79, const ESMoL::Port& port_2c7b);

private:
	Packets_t* _block_2c5f;
	Packets_t* _port_2c60;
	Packets_t _block_2c61;
	Packets_t _port_2c6a;
	class Match
	{
	public:
		ESMoL::Block block_2c77;
		ESMoL::Port port_2c78;
	};

	std::list< Match> _matches;
};

class FilterInstances_2c84
{
public:
	void operator()( const Packets_t& blocks_2c85, Packets_t& blocks_2c87);

protected:
	void callNotAnInstanceTest_2cab( const Packets_t& blocks_2c8a);

private:
	Packets_t* _block_2c88;
};

class NotAnInstanceTest_2c89
{
public:
	void operator()( const Packets_t& blocks_2c8a, Packets_t& blocks_2c8c);

protected:
	void executeOne( const Packets_t& blocks_2c8a);
	bool isInputUnique( const Udm::Object& block_2c90);

private:
	Packets_t* _block_2c8d;
	Packets_t _block_2c8e;
};

class NotAnInstance_2c95
{
public:
	bool operator()( const Packets_t& blocks_2c96, Packets_t& blocks_2c98);

protected:
	bool isInputUnique( const Udm::Object& block_2c9e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Block& Block);
	void processInputPackets( const Packets_t& blocks_2c96);
	bool patternMatcher( const Udm::Object& block_2c9c);
	void outputAppender( const ESMoL::Block& block_2ca9);

private:
	Packets_t* _block_2c99;
	Packets_t _block_2c9a;
	class Match
	{
	public:
		ESMoL::Block block_2ca7;
	};

	std::list< Match> _matches;
};

class GetSubBlocks_2cad
{
public:
	void operator()( const Packets_t& subsystems_2caf, Packets_t& blocks_2cae);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2cb6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2caf);
	bool patternMatcher( const Udm::Object& subsystem_2cb4);
	void effector();
	void outputAppender( const ESMoL::Block& block_2cc4);

private:
	Packets_t* _block_2cb1;
	Packets_t _subsystem_2cb2;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2cc2;
		ESMoL::Block block_2cc3;
	};

	std::list< Match> _matches;
};

class CheckError_2cd2
{
public:
	void operator()( const Packets_t& dataflows_2cd3, const Packets_t& projects_2cd5, Packets_t& dataflows_2cd7, Packets_t& projects_2cd8);

protected:
	void executeOne( const Packets_t& dataflows_2cd3, const Packets_t& projects_2cd5);
	bool isInputUnique( const Udm::Object& dataflow_2cdd, const Udm::Object& project_2ce4);
	void callCheckError_2d6f( const Packets_t& dataflows_2cea, const Packets_t& projects_2cec);
	void callReportError_2d72( const Packets_t& dataflows_2d53, const Packets_t& projects_2d55);

private:
	Packets_t* _dataflow_2cd9;
	Packets_t* _project_2cda;
	Packets_t _dataflow_2cdb;
	Packets_t _project_2ce2;
};

class CheckError_2ce9
{
public:
	void operator()( const Packets_t& dataflows_2cea, const Packets_t& projects_2cec, Packets_t& dataflows_2cee, Packets_t& projects_2cef, Packets_t& dataflows_2cf0, Packets_t& projects_2cf1);

protected:
	void executeOne( const Packets_t& dataflows_2cea, const Packets_t& projects_2cec);
	bool isInputUnique( const Udm::Object& dataflow_2cf8, const Udm::Object& project_2cff);

private:
	Packets_t* _dataflow_2cf2;
	Packets_t* _project_2cf3;
	Packets_t* _dataflow_2cf4;
	Packets_t* _project_2cf5;
	Packets_t _dataflow_2cf6;
	Packets_t _project_2cfd;
};

class NoError_2d04
{
public:
	bool operator()( const Packets_t& dataflows_2d05, const Packets_t& projects_2d08, Packets_t& dataflows_2d07, Packets_t& projects_2d0a);

protected:
	bool isInputUnique( const Udm::Object& dataflow_2d11, const Udm::Object& project_2d1a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Dataflow& Dataflow, SFC::Project& Project);
	void processInputPackets( const Packets_t& dataflows_2d05, const Packets_t& projects_2d08);
	bool patternMatcher( const Udm::Object& dataflow_2d0f, const Udm::Object& project_2d18);
	void outputAppender( const ESMoL::Dataflow& dataflow_2d27, const SFC::Project& project_2d29);

private:
	Packets_t* _dataflow_2d0b;
	Packets_t* _project_2d0c;
	Packets_t _dataflow_2d0d;
	Packets_t _project_2d16;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_2d23;
		SFC::Project project_2d24;
	};

	std::list< Match> _matches;
};

class NoErrorReported_2d2b
{
public:
	bool operator()( const Packets_t& dataflows_2d2c, const Packets_t& projects_2d2f, Packets_t& dataflows_2d2e, Packets_t& projects_2d31);

protected:
	bool isInputUnique( const Udm::Object& dataflow_2d38, const Udm::Object& project_2d41);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Dataflow& Dataflow, SFC::Project& Project);
	void processInputPackets( const Packets_t& dataflows_2d2c, const Packets_t& projects_2d2f);
	bool patternMatcher( const Udm::Object& dataflow_2d36, const Udm::Object& project_2d3f);
	void outputAppender( const ESMoL::Dataflow& dataflow_2d4e, const SFC::Project& project_2d50);

private:
	Packets_t* _dataflow_2d32;
	Packets_t* _project_2d33;
	Packets_t _dataflow_2d34;
	Packets_t _project_2d3d;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_2d4a;
		SFC::Project project_2d4b;
	};

	std::list< Match> _matches;
};

class ReportError_2d52
{
public:
	void operator()( const Packets_t& dataflows_2d53, const Packets_t& projects_2d55);

protected:
	bool isInputUnique( const Udm::Object& dataflow_2d5b, const Udm::Object& project_2d64);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_2d53, const Packets_t& projects_2d55);
	bool patternMatcher( const Udm::Object& dataflow_2d59, const Udm::Object& project_2d62);
	void effector();

private:
	Packets_t _dataflow_2d57;
	Packets_t _project_2d60;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_2d6d;
		SFC::Project project_2d6e;
	};

	std::list< Match> _matches;
};

class FinishClasses_2d7b
{
public:
	void operator()( const Packets_t& dataflows_2d7c, const Packets_t& projects_2d7e, Packets_t& dataflows_2d80, Packets_t& projects_2d81);

protected:
	void callGetClasses_2f1e( const Packets_t& projects_2f02);
	void callAssignToOutArgs_2f20( const Packets_t& classs_2d85);
	void callFinalizeContext_2f22( const Packets_t& classs_2dcc);
	void callAddContextArgs_2f24( const Packets_t& classs_2ea9);

private:
	Packets_t* _dataflow_2d82;
	Packets_t* _project_2d83;
};

class AssignToOutArgs_2d84
{
public:
	void operator()( const Packets_t& classs_2d85, Packets_t& classs_2d87);

protected:
	void callIdenticalOutArgs_2dc9( const Packets_t& classs_2d8a);

private:
	Packets_t* _class_2d88;
};

class IdenticalOutArgs_2d89
{
public:
	void operator()( const Packets_t& classs_2d8a);

protected:
	bool isInputUnique( const Udm::Object& class_2d90);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Block& Block, SFC::Class& Class, SFC::Function& Function, SFC::Arg& LeftArg, ESMoL::OutPort& LeftSubsystemOutPort, ESMoL::Line& Line, ESMoL::OutPort& OutPort, SFC::Arg& RightArg, ESMoL::OutPort& RightSubsystemOutPort, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& classs_2d8a);
	bool patternMatcher( const Udm::Object& class_2d8e);
	void effector();

private:
	Packets_t _class_2d8c;
	class Match
	{
	public:
		SFC::Class class_2db5;
		ESMoL::Block block_2db6;
		ESMoL::Subsystem subsystem_2db7;
		ESMoL::OutPort rightSubsystemOutPort_2db8;
		SFC::Arg rightArg_2db9;
		ESMoL::OutPort outPort_2dba;
		ESMoL::Line line_2dbb;
		ESMoL::OutPort leftSubsystemOutPort_2dbc;
		SFC::Arg leftArg_2dbd;
		SFC::Function function_2dbe;
	};

	std::list< Match> _matches;
};

class FinalizeContext_2dcb
{
public:
	void operator()( const Packets_t& classs_2dcc, Packets_t& classs_2dce);

protected:
	void callGetAllMethodCalls_2ea0( const Packets_t& classs_1d4);
	void callGetCalleeObject_2ea2( const Packets_t& methodCalls_2dd1, const Packets_t& callerStructs_2dd4);
	void callAddMembers_2ea5( const Packets_t& calleeObjects_2df8, const Packets_t& callerStructs_2dfa);

private:
	Packets_t* _class_2dcf;
};

class GetCalleeObject_2dd0
{
public:
	void operator()( const Packets_t& methodCalls_2dd1, const Packets_t& callerStructs_2dd4, Packets_t& calleeSubsystems_2dd3, Packets_t& callerStructs_2dd6);

protected:
	bool isInputUnique( const Udm::Object& methodCall_2ddd, const Udm::Object& callerStruct_2de6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& methodCalls_2dd1, const Packets_t& callerStructs_2dd4);
	bool patternMatcher( const Udm::Object& methodCall_2ddb, const Udm::Object& callerStruct_2de4);
	void effector();
	void outputAppender( const ESMoL::Subsystem& calleeSubsystem_2df3, const SFC::Struct& callerStruct_2df5);

private:
	Packets_t* _calleeSubsystem_2dd7;
	Packets_t* _callerStruct_2dd8;
	Packets_t _methodCall_2dd9;
	Packets_t _callerStruct_2de2;
	class Match
	{
	public:
		SFC::FunctionCall methodCall_2df0;
		SFC::Struct callerStruct_2df1;
		ESMoL::Subsystem calleeSubsystem_2df2;
	};

	std::list< Match> _matches;
};

class AddMembers_2df7
{
public:
	void operator()( const Packets_t& calleeObjects_2df8, const Packets_t& callerStructs_2dfa);

protected:
	void executeOne( const Packets_t& calleeObjects_2df8, const Packets_t& callerStructs_2dfa);
	bool isInputUnique( const Udm::Object& calleeObject_2dfe, const Udm::Object& callerStruct_2e05);
	void callContextTest_2e9a( const Packets_t& calleeObjects_2e2f, const Packets_t& callerStructs_2e31);
	void callAddContextMember_2e9d( const Packets_t& calleeSubsystems_2e0b, const Packets_t& callerStructs_2e0d);

private:
	Packets_t _calleeObject_2dfc;
	Packets_t _callerStruct_2e03;
};

class AddContextMember_2e0a
{
public:
	void operator()( const Packets_t& calleeSubsystems_2e0b, const Packets_t& callerStructs_2e0d);

protected:
	bool isInputUnique( const Udm::Object& calleeSubsystem_2e13, const Udm::Object& callerStruct_2e1c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& calleeSubsystems_2e0b, const Packets_t& callerStructs_2e0d);
	bool patternMatcher( const Udm::Object& calleeSubsystem_2e11, const Udm::Object& callerStruct_2e1a);
	void effector();

private:
	Packets_t _calleeSubsystem_2e0f;
	Packets_t _callerStruct_2e18;
	class Match
	{
	public:
		ESMoL::Subsystem calleeSubsystem_2e29;
		SFC::Struct callerStruct_2e2a;
		SFC::Class calleeClass_2e2b;
		SFC::Struct calleeStruct_2e2c;
	};

	std::list< Match> _matches;
};

class ContextTest_2e2e
{
public:
	void operator()( const Packets_t& calleeObjects_2e2f, const Packets_t& callerStructs_2e31, Packets_t& calleeObjects_2e33, Packets_t& callerStructs_2e34, Packets_t& calleeObjects_2e35, Packets_t& callerStructs_2e36);

protected:
	void executeOne( const Packets_t& calleeObjects_2e2f, const Packets_t& callerStructs_2e31);
	bool isInputUnique( const Udm::Object& calleeObject_2e3d, const Udm::Object& callerStruct_2e44);

private:
	Packets_t* _calleeObject_2e37;
	Packets_t* _callerStruct_2e38;
	Packets_t* _calleeObject_2e39;
	Packets_t* _callerStruct_2e3a;
	Packets_t _calleeObject_2e3b;
	Packets_t _callerStruct_2e42;
};

class CallerStructHasMember_2e49
{
public:
	bool operator()( const Packets_t& calleeSubsystems_2e4a, const Packets_t& callerStructs_2e4d, Packets_t& calleeSubsystems_2e4c, Packets_t& callerStructs_2e4f);

protected:
	bool isInputUnique( const Udm::Object& calleeSubsystem_2e56, const Udm::Object& callerStruct_2e5f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& calleeSubsystems_2e4a, const Packets_t& callerStructs_2e4d);
	bool patternMatcher( const Udm::Object& calleeSubsystem_2e54, const Udm::Object& callerStruct_2e5d);
	void outputAppender( const ESMoL::Subsystem& calleeSubsystem_2e71, const SFC::Struct& callerStruct_2e73);

private:
	Packets_t* _calleeSubsystem_2e50;
	Packets_t* _callerStruct_2e51;
	Packets_t _calleeSubsystem_2e52;
	Packets_t _callerStruct_2e5b;
	class Match
	{
	public:
		ESMoL::Subsystem calleeSubsystem_2e6e;
		SFC::Struct callerStruct_2e6f;
		SFC::LocalVar localVar_2e70;
	};

	std::list< Match> _matches;
};

class Otherwise_2e75
{
public:
	bool operator()( const Packets_t& calleeSubsystems_2e76, const Packets_t& callerStructs_2e79, Packets_t& calleeSubsystems_2e78, Packets_t& callerStructs_2e7b);

protected:
	bool isInputUnique( const Udm::Object& calleeSubsystem_2e82, const Udm::Object& callerStruct_2e8b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& calleeSubsystems_2e76, const Packets_t& callerStructs_2e79);
	bool patternMatcher( const Udm::Object& calleeSubsystem_2e80, const Udm::Object& callerStruct_2e89);
	void outputAppender( const ESMoL::Subsystem& calleeSubsystem_2e96, const SFC::Struct& callerStruct_2e98);

private:
	Packets_t* _calleeSubsystem_2e7c;
	Packets_t* _callerStruct_2e7d;
	Packets_t _calleeSubsystem_2e7e;
	Packets_t _callerStruct_2e87;
	class Match
	{
	public:
		ESMoL::Subsystem calleeSubsystem_2e94;
		SFC::Struct callerStruct_2e95;
	};

	std::list< Match> _matches;
};

class AddContextArgs_2ea8
{
public:
	void operator()( const Packets_t& classs_2ea9);

protected:
	void callGetAllMethodCalls_2ef9( const Packets_t& classs_1d4);
	void callGetContextArg_2efb( const Packets_t& methodCalls_2eac, const Packets_t& callerContextArgs_2eaf);
	void calladdArgValExprs_2efe( const Packets_t& methodCalls_2ecd, const Packets_t& callerContextArgs_2ecf);
};

class GetContextArg_2eab
{
public:
	void operator()( const Packets_t& methodCalls_2eac, const Packets_t& callerContextArgs_2eaf, Packets_t& methodCalls_2eae, Packets_t& callerContextArgs_2eb1);

protected:
	bool isInputUnique( const Udm::Object& methodCall_2eb8, const Udm::Object& callerContextArg_2ec1);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& methodCalls_2eac, const Packets_t& callerContextArgs_2eaf);
	bool patternMatcher( const Udm::Object& methodCall_2eb6, const Udm::Object& callerContextArg_2ebf);
	void effector();
	void forwardInputs();

private:
	Packets_t* _methodCall_2eb2;
	Packets_t* _callerContextArg_2eb3;
	Packets_t _methodCall_2eb4;
	Packets_t _callerContextArg_2ebd;
	class Match
	{
	public:
		SFC::FunctionCall methodCall_2eca;
		SFC::Arg callerContextArg_2ecb;
	};

	std::list< Match> _matches;
};

class AddArgValExprs_2ecc
{
public:
	void operator()( const Packets_t& methodCalls_2ecd, const Packets_t& callerContextArgs_2ecf);

protected:
	bool isInputUnique( const Udm::Object& methodCall_2ed5, const Udm::Object& callerContextArg_2ede);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::ArgVal& ArgVal, SFC::Arg& CallerContextArg, SFC::LocalVar& LocalVar, SFC::FunctionCall& MethodCall, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& methodCalls_2ecd, const Packets_t& callerContextArgs_2ecf);
	bool patternMatcher( const Udm::Object& methodCall_2ed3, const Udm::Object& callerContextArg_2edc);
	void effector();

private:
	Packets_t _methodCall_2ed1;
	Packets_t _callerContextArg_2eda;
	class Match
	{
	public:
		SFC::FunctionCall methodCall_2eec;
		SFC::Arg callerContextArg_2eed;
		ESMoL::Subsystem subsystem_2eee;
		SFC::LocalVar localVar_2eef;
		SFC::ArgVal argVal_2ef0;
	};

	std::list< Match> _matches;
};

class GetClasses_2f01
{
public:
	void operator()( const Packets_t& projects_2f02, Packets_t& classs_2f04);

protected:
	bool isInputUnique( const Udm::Object& project_2f0a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& projects_2f02);
	bool patternMatcher( const Udm::Object& project_2f08);
	void effector();
	void outputAppender( const SFC::Class& class_2f1c);

private:
	Packets_t* _class_2f05;
	Packets_t _project_2f06;
	class Match
	{
	public:
		SFC::Project project_2f19;
		SFC::Program program_2f1a;
		SFC::Class class_2f1b;
	};

	std::list< Match> _matches;
};

class MakeClasses_2f26
{
public:
	void operator()( const Packets_t& dataflows_2f27, const Packets_t& projects_2f29, Packets_t& dataflows_2f2b, Packets_t& projects_2f2c);

protected:
	void callGetBlocks_3b56( const Packets_t& dataflows_2f30, const Packets_t& projects_2f32);
	void callCreateAllPrograms_3b59( const Packets_t& subsystems_30f5, const Packets_t& projects_30f7);

private:
	Packets_t* _dataflow_2f2d;
	Packets_t* _project_2f2e;
};

class GetBlocks_2f2f
{
public:
	void operator()( const Packets_t& dataflows_2f30, const Packets_t& projects_2f32, Packets_t& subsystems_2f34, Packets_t& projects_2f35);

protected:
	void callTest_30eb( const Packets_t& dataflows_3085, const Packets_t& projects_3087);
	void callGetRefSubsystemsFull_30ee( const Packets_t& dataflows_2f39, const Packets_t& projects_2f3b);
	void callGetSubSystems_30f1( const Packets_t& dataflows_305c, const Packets_t& projects_305f);

private:
	Packets_t* _subsystem_2f36;
	Packets_t* _project_2f37;
};

class GetRefSubsystemsFull_2f38
{
public:
	void operator()( const Packets_t& dataflows_2f39, const Packets_t& projects_2f3b, Packets_t& subsystems_2f3d, Packets_t& projects_2f3e);

protected:
	void callGetDataflowSubsystems_3052( const Packets_t& dataflows_2f42, const Packets_t& projects_2f45);
	void callTest_3055( const Packets_t& subsystems_2f6b, const Packets_t& projects_2f6d);
	void callRecurse_3058( const Packets_t& subsystems_302b, const Packets_t& projects_302d);

private:
	Packets_t* _subsystem_2f3f;
	Packets_t* _project_2f40;
};

class GetDataflowSubsystems_2f41
{
public:
	void operator()( const Packets_t& dataflows_2f42, const Packets_t& projects_2f45, Packets_t& subsystems_2f44, Packets_t& projects_2f47);

protected:
	bool isInputUnique( const Udm::Object& dataflow_2f4e, const Udm::Object& project_2f57);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_2f42, const Packets_t& projects_2f45);
	bool patternMatcher( const Udm::Object& dataflow_2f4c, const Udm::Object& project_2f55);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_2f66, const SFC::Project& project_2f68);

private:
	Packets_t* _subsystem_2f48;
	Packets_t* _project_2f49;
	Packets_t _dataflow_2f4a;
	Packets_t _project_2f53;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_2f63;
		SFC::Project project_2f64;
		ESMoL::Subsystem subsystem_2f65;
	};

	std::list< Match> _matches;
};

class Test_2f6a
{
public:
	void operator()( const Packets_t& subsystems_2f6b, const Packets_t& projects_2f6d, Packets_t& subsystems_2f6f, Packets_t& projects_2f70, Packets_t& subsystems_2f71, Packets_t& projects_2f72, Packets_t& subsystems_2f73, Packets_t& projects_2f74, Packets_t& subsystems_2f75, Packets_t& projects_2f76);

protected:
	void executeOne( const Packets_t& subsystems_2f6b, const Packets_t& projects_2f6d);
	bool isInputUnique( const Udm::Object& subsystem_2f81, const Udm::Object& project_2f88);

private:
	Packets_t* _subsystem_2f77;
	Packets_t* _project_2f78;
	Packets_t* _subsystem_2f79;
	Packets_t* _project_2f7a;
	Packets_t* _subsystem_2f7b;
	Packets_t* _project_2f7c;
	Packets_t* _subsystem_2f7d;
	Packets_t* _project_2f7e;
	Packets_t _subsystem_2f7f;
	Packets_t _project_2f86;
};

class IsInstance_2f8d
{
public:
	bool operator()( const Packets_t& subsystems_2f8e, const Packets_t& projects_2f91, Packets_t& subsystems_2f90, Packets_t& projects_2f93);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2f9a, const Udm::Object& project_2fa3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Project& Project, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_2f8e, const Packets_t& projects_2f91);
	bool patternMatcher( const Udm::Object& subsystem_2f98, const Udm::Object& project_2fa1);
	void outputAppender( const ESMoL::Subsystem& subsystem_2fb0, const SFC::Project& project_2fb2);

private:
	Packets_t* _subsystem_2f94;
	Packets_t* _project_2f95;
	Packets_t _subsystem_2f96;
	Packets_t _project_2f9f;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2fac;
		SFC::Project project_2fad;
	};

	std::list< Match> _matches;
};

class RefSubsystem_2fb4
{
public:
	bool operator()( const Packets_t& subsystems_2fb5, const Packets_t& projects_2fb8, Packets_t& subsystems_2fb7, Packets_t& projects_2fba);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2fc1, const Udm::Object& project_2fca);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_2fb5, const Packets_t& projects_2fb8);
	bool patternMatcher( const Udm::Object& subsystem_2fbf, const Udm::Object& project_2fc8);
	void outputAppender( const ESMoL::Subsystem& subsystem_2fd9, const SFC::Project& project_2fdb);

private:
	Packets_t* _subsystem_2fbb;
	Packets_t* _project_2fbc;
	Packets_t _subsystem_2fbd;
	Packets_t _project_2fc6;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2fd6;
		SFC::Project project_2fd7;
		ESMoL::SubsystemRef subsystemRef_2fd8;
	};

	std::list< Match> _matches;
};

class InstanceInRefSubsystem_2fdd
{
public:
	bool operator()( const Packets_t& subsystems_2fde, const Packets_t& projects_2fe1, Packets_t& subsystems_2fe0, Packets_t& projects_2fe3);

protected:
	bool isInputUnique( const Udm::Object& subsystem_2fea, const Udm::Object& project_2ff3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Project& Project, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_2fde, const Packets_t& projects_2fe1);
	bool patternMatcher( const Udm::Object& subsystem_2fe8, const Udm::Object& project_2ff1);
	void outputAppender( const ESMoL::Subsystem& subsystem_3000, const SFC::Project& project_3002);

private:
	Packets_t* _subsystem_2fe4;
	Packets_t* _project_2fe5;
	Packets_t _subsystem_2fe6;
	Packets_t _project_2fef;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_2ffc;
		SFC::Project project_2ffd;
	};

	std::list< Match> _matches;
};

class Otherwise_3004
{
public:
	bool operator()( const Packets_t& subsystems_3005, const Packets_t& projects_3008, Packets_t& subsystems_3007, Packets_t& projects_300a);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3011, const Udm::Object& project_301a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3005, const Packets_t& projects_3008);
	bool patternMatcher( const Udm::Object& subsystem_300f, const Udm::Object& project_3018);
	void outputAppender( const ESMoL::Subsystem& subsystem_3025, const SFC::Project& project_3027);

private:
	Packets_t* _subsystem_300b;
	Packets_t* _project_300c;
	Packets_t _subsystem_300d;
	Packets_t _project_3016;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3023;
		SFC::Project project_3024;
	};

	std::list< Match> _matches;
};

class Recurse_3029
{
public:
	void operator()( const Packets_t& subsystems_302b, const Packets_t& projects_302d, Packets_t& subsystems_302a, Packets_t& projects_302f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3036, const Udm::Object& project_303f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_302b, const Packets_t& projects_302d);
	bool patternMatcher( const Udm::Object& subsystem_3034, const Udm::Object& project_303d);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_304e, const SFC::Project& project_3050);

private:
	Packets_t* _subsystem_3030;
	Packets_t* _project_3031;
	Packets_t _subsystem_3032;
	Packets_t _project_303b;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_304b;
		SFC::Project project_304c;
		ESMoL::Subsystem subsystem_304d;
	};

	std::list< Match> _matches;
};

class GetSubSystems_305b
{
public:
	void operator()( const Packets_t& dataflows_305c, const Packets_t& projects_305f, Packets_t& subsystems_305e, Packets_t& projects_3061);

protected:
	bool isInputUnique( const Udm::Object& dataflow_3068, const Udm::Object& project_3071);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_305c, const Packets_t& projects_305f);
	bool patternMatcher( const Udm::Object& dataflow_3066, const Udm::Object& project_306f);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_3080, const SFC::Project& project_3082);

private:
	Packets_t* _subsystem_3062;
	Packets_t* _project_3063;
	Packets_t _dataflow_3064;
	Packets_t _project_306d;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_307d;
		SFC::Project project_307e;
		ESMoL::Subsystem subsystem_307f;
	};

	std::list< Match> _matches;
};

class Test_3084
{
public:
	void operator()( const Packets_t& dataflows_3085, const Packets_t& projects_3087, Packets_t& dataflows_3089, Packets_t& projects_308a, Packets_t& dataflows_308b, Packets_t& projects_308c);

protected:
	void executeOne( const Packets_t& dataflows_3085, const Packets_t& projects_3087);
	bool isInputUnique( const Udm::Object& dataflow_3093, const Udm::Object& project_309a);

private:
	Packets_t* _dataflow_308d;
	Packets_t* _project_308e;
	Packets_t* _dataflow_308f;
	Packets_t* _project_3090;
	Packets_t _dataflow_3091;
	Packets_t _project_3098;
};

class NoRefSubsystem_309f
{
public:
	bool operator()( const Packets_t& dataflows_30a0, const Packets_t& projects_30a3, Packets_t& dataflows_30a2, Packets_t& projects_30a5);

protected:
	bool isInputUnique( const Udm::Object& dataflow_30ac, const Udm::Object& project_30b5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Dataflow& Dataflow, SFC::Project& Project);
	void processInputPackets( const Packets_t& dataflows_30a0, const Packets_t& projects_30a3);
	bool patternMatcher( const Udm::Object& dataflow_30aa, const Udm::Object& project_30b3);
	void outputAppender( const ESMoL::Dataflow& dataflow_30c2, const SFC::Project& project_30c4);

private:
	Packets_t* _dataflow_30a6;
	Packets_t* _project_30a7;
	Packets_t _dataflow_30a8;
	Packets_t _project_30b1;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_30be;
		SFC::Project project_30bf;
	};

	std::list< Match> _matches;
};

class RefSubsystem_30c6
{
public:
	bool operator()( const Packets_t& dataflows_30c7, const Packets_t& projects_30ca, Packets_t& dataflows_30c9, Packets_t& projects_30cc);

protected:
	bool isInputUnique( const Udm::Object& dataflow_30d3, const Udm::Object& project_30dc);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_30c7, const Packets_t& projects_30ca);
	bool patternMatcher( const Udm::Object& dataflow_30d1, const Udm::Object& project_30da);
	void outputAppender( const ESMoL::Dataflow& dataflow_30e7, const SFC::Project& project_30e9);

private:
	Packets_t* _dataflow_30cd;
	Packets_t* _project_30ce;
	Packets_t _dataflow_30cf;
	Packets_t _project_30d8;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_30e5;
		SFC::Project project_30e6;
	};

	std::list< Match> _matches;
};

class CreateAllPrograms_30f4
{
public:
	void operator()( const Packets_t& subsystems_30f5, const Packets_t& projects_30f7);

protected:
	void callCreateProgramsTopLevel_3b4a( const Packets_t& systems_3211, const Packets_t& projects_3213);
	void callCreateClasses_3b4d( const Packets_t& systems_35f0, const Packets_t& programs_35f2);
	void callCreateFunctionsAndArgs_3b50( const Packets_t& systems_376c);
	void callCreateFunctionLocalVars_3b52( const Packets_t& systems_32bd);
	void callCreateSigFlowsR_3b54( const Packets_t& systems_30fa);
};

class CreateSigFlowsR_30f9
{
public:
	void operator()( const Packets_t& systems_30fa);

protected:
	void callSubsystemFilter_3207( const Packets_t& systems_2ae1);
	void callGetFunctions_3209( const Packets_t& systems_80b);
	void callCreateTSB_320b( const Packets_t& systems_30fd, const Packets_t& systemFunctions_30ff);
	void callGetSubSubsystems_320e( const Packets_t& systems_2b64);
};

class CreateTSB_30fc
{
public:
	void operator()( const Packets_t& systems_30fd, const Packets_t& systemFunctions_30ff, Packets_t& systems_3101);

protected:
	void callPassThroughs_31f7( const Packets_t& systems_31b9, const Packets_t& systemFunctions_31bb);
	void callDoTopologicalSort_31fa( const Packets_t& subsystems_316b, const Packets_t& mains_316e);
	void callCreatePreDelayExec_31fd( const Packets_t& systems_3104, const Packets_t& systemFunctions_3106);
	void callGetSortedBlocks_3200( const Packets_t& subsystems_318c, const Packets_t& mains_3190);
	void callCreateBlockExecution_3203( const Packets_t& systems_82f, const Packets_t& childBlockss_831, const Packets_t& systemFunctions_833);

private:
	Packets_t* _system_3102;
};

class CreatePreDelayExec_3103
{
public:
	void operator()( const Packets_t& systems_3104, const Packets_t& systemFunctions_3106, Packets_t& systems_3108, Packets_t& systemFunctions_3109);

protected:
	void callGetDelayBlocks_3160( const Packets_t& subsystems_3131, const Packets_t& mains_3135);
	void callCreateBlockExecution_3163( const Packets_t& systems_82f, const Packets_t& childBlockss_831, const Packets_t& systemFunctions_833);
	void callResetDelayBlockType_3167( const Packets_t& subsystems_310d, const Packets_t& mains_310f);

private:
	Packets_t* _system_310a;
	Packets_t* _systemFunction_310b;
};

class ResetDelayBlockType_310c
{
public:
	void operator()( const Packets_t& subsystems_310d, const Packets_t& mains_310f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3115, const Udm::Object& main_311e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Primitive& ChildBlocks, SFC::Function& Main, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_310d, const Packets_t& mains_310f);
	bool patternMatcher( const Udm::Object& subsystem_3113, const Udm::Object& main_311c);
	void effector();

private:
	Packets_t _subsystem_3111;
	Packets_t _main_311a;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_312a;
		SFC::Function main_312b;
		ESMoL::Primitive childBlocks_312c;
	};

	std::list< Match> _matches;
};

class GetDelayBlocks_3130
{
public:
	void operator()( const Packets_t& subsystems_3131, const Packets_t& mains_3135, Packets_t& subsystems_3133, Packets_t& childBlockss_3134, Packets_t& mains_3137);

protected:
	bool isInputUnique( const Udm::Object& subsystem_313f, const Udm::Object& main_3148);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Primitive& ChildBlocks, SFC::Function& Main, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_3131, const Packets_t& mains_3135);
	bool patternMatcher( const Udm::Object& subsystem_313d, const Udm::Object& main_3146);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_315a, const ESMoL::Primitive& childBlocks_315c, const SFC::Function& main_315e);

private:
	Packets_t* _subsystem_3138;
	Packets_t* _childBlocks_3139;
	Packets_t* _main_313a;
	Packets_t _subsystem_313b;
	Packets_t _main_3144;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3154;
		SFC::Function main_3155;
		ESMoL::Primitive childBlocks_3156;
	};

	std::list< Match> _matches;
};

class DoTopologicalSort_316a
{
public:
	void operator()( const Packets_t& subsystems_316b, const Packets_t& mains_316e, Packets_t& subsystems_316d, Packets_t& mains_3170);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3177, const Udm::Object& main_3180);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_316b, const Packets_t& mains_316e);
	bool patternMatcher( const Udm::Object& subsystem_3175, const Udm::Object& main_317e);
	void effector();
	void forwardInputs();

private:
	Packets_t* _subsystem_3171;
	Packets_t* _main_3172;
	Packets_t _subsystem_3173;
	Packets_t _main_317c;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3189;
		SFC::Function main_318a;
	};

	std::list< Match> _matches;
};

class GetSortedBlocks_318b
{
public:
	void operator()( const Packets_t& subsystems_318c, const Packets_t& mains_3190, Packets_t& subsystems_318e, Packets_t& childBlockss_318f, Packets_t& mains_3192);

protected:
	bool isInputUnique( const Udm::Object& subsystem_319a, const Udm::Object& main_31a3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_318c, const Packets_t& mains_3190);
	bool patternMatcher( const Udm::Object& subsystem_3198, const Udm::Object& main_31a1);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_31b2, const ESMoL::Block& childBlocks_31b4, const SFC::Function& main_31b6);
	void sortOutputs();

private:
	Packets_t* _subsystem_3193;
	Packets_t* _childBlocks_3194;
	Packets_t* _main_3195;
	Packets_t _subsystem_3196;
	Packets_t _main_319f;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_31af;
		SFC::Function main_31b0;
		ESMoL::Block childBlocks_31b1;
	};

	std::list< Match> _matches;
};

class PassThroughs_31b8
{
public:
	void operator()( const Packets_t& systems_31b9, const Packets_t& systemFunctions_31bb, Packets_t& systems_31bd, Packets_t& systemFunctions_31be);

protected:
	void callPassThroughs_31f4( const Packets_t& subsystems_31c2, const Packets_t& mains_31c4);

private:
	Packets_t* _system_31bf;
	Packets_t* _systemFunction_31c0;
};

class PassThroughs_31c1
{
public:
	void operator()( const Packets_t& subsystems_31c2, const Packets_t& mains_31c4);

protected:
	bool isInputUnique( const Udm::Object& subsystem_31ca, const Udm::Object& main_31d3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_31c2, const Packets_t& mains_31c4);
	bool patternMatcher( const Udm::Object& subsystem_31c8, const Udm::Object& main_31d1);
	void effector();

private:
	Packets_t _subsystem_31c6;
	Packets_t _main_31cf;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_31ed;
		SFC::Function main_31ee;
		ESMoL::Line line_31ef;
		ESMoL::InPort inPort_31f0;
		ESMoL::OutPort outPort_31f1;
		SFC::Arg outArg_31f2;
		SFC::Arg inArg_31f3;
	};

	std::list< Match> _matches;
};

class CreateProgramsTopLevel_3210
{
public:
	void operator()( const Packets_t& systems_3211, const Packets_t& projects_3213, Packets_t& systems_3215, Packets_t& programs_3216);

protected:
	void executeOne( const Packets_t& systems_3211, const Packets_t& projects_3213);
	bool isInputUnique( const Udm::Object& system_321b, const Udm::Object& project_3222);
	void callHasClassFilter_32b6( const Packets_t& systems_3250, const Packets_t& projects_3252);
	void callCreateProgramClass_32b9( const Packets_t& subsystems_3228, const Packets_t& projects_322c);

private:
	Packets_t* _system_3217;
	Packets_t* _program_3218;
	Packets_t _system_3219;
	Packets_t _project_3220;
};

class CreateProgramClass_3227
{
public:
	void operator()( const Packets_t& subsystems_3228, const Packets_t& projects_322c, Packets_t& subsystems_322a, Packets_t& programs_322b);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3234, const Udm::Object& project_323d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3228, const Packets_t& projects_322c);
	bool patternMatcher( const Udm::Object& subsystem_3232, const Udm::Object& project_323b);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_324b, const SFC::Program& program_324d);

private:
	Packets_t* _subsystem_322e;
	Packets_t* _program_322f;
	Packets_t _subsystem_3230;
	Packets_t _project_3239;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3246;
		SFC::Project project_3247;
	};

	std::list< Match> _matches;
};

class HasClassFilter_324f
{
public:
	void operator()( const Packets_t& systems_3250, const Packets_t& projects_3252, Packets_t& systems_3254, Packets_t& projects_3255, Packets_t& systems_3256, Packets_t& projects_3257);

protected:
	void executeOne( const Packets_t& systems_3250, const Packets_t& projects_3252);
	bool isInputUnique( const Udm::Object& system_325e, const Udm::Object& project_3265);

private:
	Packets_t* _system_3258;
	Packets_t* _project_3259;
	Packets_t* _system_325a;
	Packets_t* _project_325b;
	Packets_t _system_325c;
	Packets_t _project_3263;
};

class SubsystemHasClass_326a
{
public:
	bool operator()( const Packets_t& subsystems_326b, const Packets_t& projects_326e, Packets_t& subsystems_326d, Packets_t& projects_3270);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3277, const Udm::Object& project_3280);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_326b, const Packets_t& projects_326e);
	bool patternMatcher( const Udm::Object& subsystem_3275, const Udm::Object& project_327e);
	void outputAppender( const ESMoL::Subsystem& subsystem_328d, const SFC::Project& project_328f);

private:
	Packets_t* _subsystem_3271;
	Packets_t* _project_3272;
	Packets_t _subsystem_3273;
	Packets_t _project_327c;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_328a;
		SFC::Project project_328b;
		SFC::Class class_328c;
	};

	std::list< Match> _matches;
};

class NoClass_3291
{
public:
	bool operator()( const Packets_t& subsystems_3292, const Packets_t& projects_3295, Packets_t& subsystems_3294, Packets_t& projects_3297);

protected:
	bool isInputUnique( const Udm::Object& subsystem_329e, const Udm::Object& project_32a7);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3292, const Packets_t& projects_3295);
	bool patternMatcher( const Udm::Object& subsystem_329c, const Udm::Object& project_32a5);
	void outputAppender( const ESMoL::Subsystem& subsystem_32b2, const SFC::Project& project_32b4);

private:
	Packets_t* _subsystem_3298;
	Packets_t* _project_3299;
	Packets_t _subsystem_329a;
	Packets_t _project_32a3;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_32b0;
		SFC::Project project_32b1;
	};

	std::list< Match> _matches;
};

class CreateFunctionLocalVars_32bc
{
public:
	void operator()( const Packets_t& systems_32bd, Packets_t& systems_32bf);

protected:
	void callSubsystemFilter_35e3( const Packets_t& systems_2ae1);
	void callGetFunctions_35e5( const Packets_t& systems_80b);
	void callCreateOutPortLVs_35e7( const Packets_t& systems_32c2, const Packets_t& systemFunctions_32c4);
	void callCreateInPortLVs_35ea( const Packets_t& systems_346f, const Packets_t& systemFunctions_3471);
	void callGetSubSubsystems_35ed( const Packets_t& systems_2b64);

private:
	Packets_t* _system_32c0;
};

class CreateOutPortLVs_32c1
{
public:
	void operator()( const Packets_t& systems_32c2, const Packets_t& systemFunctions_32c4, Packets_t& systems_32c6, Packets_t& systemFunctions_32c7);

protected:
	void callGetChildOutPorts_3460( const Packets_t& subsystems_3347, const Packets_t& mains_334a);
	void callOutPortFilter_3463( const Packets_t& outPorts_32cb, const Packets_t& systemFunctions_32cd);
	void callCreateLocalVars_3466( const Packets_t& outPorts_3374, const Packets_t& mains_3376);
	void callGetOutArgs_3469( const Packets_t& outPorts_3442);
	void callBindToArg_346b( const Packets_t& systemOutPorts_339a, const Packets_t& outPorts_339c);

private:
	Packets_t* _system_32c8;
	Packets_t* _systemFunction_32c9;
};

class OutPortFilter_32ca
{
public:
	void operator()( const Packets_t& outPorts_32cb, const Packets_t& systemFunctions_32cd, Packets_t& outPorts_32cf, Packets_t& systemFunctions_32d0, Packets_t& outPorts_32d1, Packets_t& systemFunctions_32d2);

protected:
	void callOutPortTest_3343( const Packets_t& outPorts_32d8, const Packets_t& systemFunctions_32da);

private:
	Packets_t* _outPort_32d3;
	Packets_t* _systemFunction_32d4;
	Packets_t* _outPort_32d5;
	Packets_t* _systemFunction_32d6;
};

class OutPortTest_32d7
{
public:
	void operator()( const Packets_t& outPorts_32d8, const Packets_t& systemFunctions_32da, Packets_t& outPorts_32dc, Packets_t& systemFunctions_32dd, Packets_t& outPorts_32de, Packets_t& systemFunctions_32df);

protected:
	void executeOne( const Packets_t& outPorts_32d8, const Packets_t& systemFunctions_32da);
	bool isInputUnique( const Udm::Object& outPort_32e6, const Udm::Object& systemFunction_32ed);

private:
	Packets_t* _outPort_32e0;
	Packets_t* _systemFunction_32e1;
	Packets_t* _outPort_32e2;
	Packets_t* _systemFunction_32e3;
	Packets_t _outPort_32e4;
	Packets_t _systemFunction_32eb;
};

class OutPort2OutPort_32f2
{
public:
	bool operator()( const Packets_t& outPorts_32f3, const Packets_t& mains_32f6, Packets_t& outPorts_32f5, Packets_t& mains_32f8);

protected:
	bool isInputUnique( const Udm::Object& outPort_32ff, const Udm::Object& main_3308);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_32f3, const Packets_t& mains_32f6);
	bool patternMatcher( const Udm::Object& outPort_32fd, const Udm::Object& main_3306);
	void outputAppender( const ESMoL::OutPort& outPort_331a, const SFC::Function& main_331c);

private:
	Packets_t* _outPort_32f9;
	Packets_t* _main_32fa;
	Packets_t _outPort_32fb;
	Packets_t _main_3304;
	class Match
	{
	public:
		ESMoL::OutPort outPort_3316;
		SFC::Function main_3317;
		ESMoL::OutPort subsystemOutPort_3318;
		ESMoL::Line line_3319;
	};

	std::list< Match> _matches;
};

class Otherwise_331e
{
public:
	bool operator()( const Packets_t& outPorts_331f, const Packets_t& mains_3322, Packets_t& outPorts_3321, Packets_t& mains_3324);

protected:
	bool isInputUnique( const Udm::Object& outPort_332b, const Udm::Object& main_3334);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_331f, const Packets_t& mains_3322);
	bool patternMatcher( const Udm::Object& outPort_3329, const Udm::Object& main_3332);
	void outputAppender( const ESMoL::OutPort& outPort_333f, const SFC::Function& main_3341);

private:
	Packets_t* _outPort_3325;
	Packets_t* _main_3326;
	Packets_t _outPort_3327;
	Packets_t _main_3330;
	class Match
	{
	public:
		ESMoL::OutPort outPort_333d;
		SFC::Function main_333e;
	};

	std::list< Match> _matches;
};

class GetChildOutPorts_3346
{
public:
	void operator()( const Packets_t& subsystems_3347, const Packets_t& mains_334a, Packets_t& outPorts_3349, Packets_t& mains_334c);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3353, const Udm::Object& main_335c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3347, const Packets_t& mains_334a);
	bool patternMatcher( const Udm::Object& subsystem_3351, const Udm::Object& main_335a);
	void effector();
	void outputAppender( const ESMoL::OutPort& outPort_336f, const SFC::Function& main_3371);

private:
	Packets_t* _outPort_334d;
	Packets_t* _main_334e;
	Packets_t _subsystem_334f;
	Packets_t _main_3358;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_336b;
		SFC::Function main_336c;
		ESMoL::Block block_336d;
		ESMoL::OutPort outPort_336e;
	};

	std::list< Match> _matches;
};

class CreateLocalVars_3373
{
public:
	void operator()( const Packets_t& outPorts_3374, const Packets_t& mains_3376);

protected:
	bool isInputUnique( const Udm::Object& outPort_337c, const Udm::Object& main_3385);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_3374, const Packets_t& mains_3376);
	bool patternMatcher( const Udm::Object& outPort_337a, const Udm::Object& main_3383);
	void effector();

private:
	Packets_t _outPort_3378;
	Packets_t _main_3381;
	class Match
	{
	public:
		ESMoL::OutPort outPort_3393;
		SFC::Function main_3394;
		ESMoL::TypeBaseRef typeBaseRef_3395;
		ESMoL::TypeBase typeBase_3396;
		SFC::DT dT_3397;
	};

	std::list< Match> _matches;
};

class BindToArg_3399
{
public:
	void operator()( const Packets_t& systemOutPorts_339a, const Packets_t& outPorts_339c);

protected:
	void executeOne( const Packets_t& systemOutPorts_339a, const Packets_t& outPorts_339c);
	bool isInputUnique( const Udm::Object& systemOutPort_33a0, const Udm::Object& outPort_33a7);
	void callOutputArgTest_343a( const Packets_t& systemOutPorts_33ad, const Packets_t& outPorts_33af);
	void callBindToArg_343d( const Packets_t& subsystemOutPorts_3414, const Packets_t& outPorts_3416);

private:
	Packets_t _systemOutPort_339e;
	Packets_t _outPort_33a5;
};

class OutputArgTest_33ac
{
public:
	void operator()( const Packets_t& systemOutPorts_33ad, const Packets_t& outPorts_33af, Packets_t& systemOutPorts_33b1, Packets_t& outPorts_33b2, Packets_t& systemOutPorts_33b3, Packets_t& outPorts_33b4);

protected:
	void executeOne( const Packets_t& systemOutPorts_33ad, const Packets_t& outPorts_33af);
	bool isInputUnique( const Udm::Object& systemOutPort_33bb, const Udm::Object& outPort_33c2);

private:
	Packets_t* _systemOutPort_33b5;
	Packets_t* _outPort_33b6;
	Packets_t* _systemOutPort_33b7;
	Packets_t* _outPort_33b8;
	Packets_t _systemOutPort_33b9;
	Packets_t _outPort_33c0;
};

class OutPortArg_33c7
{
public:
	bool operator()( const Packets_t& subsystemOutPorts_33c8, const Packets_t& outPorts_33cb, Packets_t& subsystemOutPorts_33ca, Packets_t& outPorts_33cd);

protected:
	bool isInputUnique( const Udm::Object& subsystemOutPort_33d4, const Udm::Object& outPort_33dd);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystemOutPorts_33c8, const Packets_t& outPorts_33cb);
	bool patternMatcher( const Udm::Object& subsystemOutPort_33d2, const Udm::Object& outPort_33db);
	void outputAppender( const ESMoL::OutPort& subsystemOutPort_33ea, const ESMoL::OutPort& outPort_33ec);

private:
	Packets_t* _subsystemOutPort_33ce;
	Packets_t* _outPort_33cf;
	Packets_t _subsystemOutPort_33d0;
	Packets_t _outPort_33d9;
	class Match
	{
	public:
		ESMoL::OutPort subsystemOutPort_33e7;
		ESMoL::OutPort outPort_33e8;
		SFC::ArgDeclBase argDeclBase_33e9;
	};

	std::list< Match> _matches;
};

class Otherwise_33ee
{
public:
	bool operator()( const Packets_t& subsystemOutPorts_33ef, const Packets_t& outPorts_33f2, Packets_t& subsystemOutPorts_33f1, Packets_t& outPorts_33f4);

protected:
	bool isInputUnique( const Udm::Object& subsystemOutPort_33fb, const Udm::Object& outPort_3404);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystemOutPorts_33ef, const Packets_t& outPorts_33f2);
	bool patternMatcher( const Udm::Object& subsystemOutPort_33f9, const Udm::Object& outPort_3402);
	void outputAppender( const ESMoL::OutPort& subsystemOutPort_340f, const ESMoL::OutPort& outPort_3411);

private:
	Packets_t* _subsystemOutPort_33f5;
	Packets_t* _outPort_33f6;
	Packets_t _subsystemOutPort_33f7;
	Packets_t _outPort_3400;
	class Match
	{
	public:
		ESMoL::OutPort subsystemOutPort_340d;
		ESMoL::OutPort outPort_340e;
	};

	std::list< Match> _matches;
};

class BindToArg_3413
{
public:
	void operator()( const Packets_t& subsystemOutPorts_3414, const Packets_t& outPorts_3416);

protected:
	bool isInputUnique( const Udm::Object& subsystemOutPort_341c, const Udm::Object& outPort_3425);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystemOutPorts_3414, const Packets_t& outPorts_3416);
	bool patternMatcher( const Udm::Object& subsystemOutPort_341a, const Udm::Object& outPort_3423);
	void effector();

private:
	Packets_t _subsystemOutPort_3418;
	Packets_t _outPort_3421;
	class Match
	{
	public:
		ESMoL::OutPort subsystemOutPort_3436;
		ESMoL::OutPort outPort_3437;
		SFC::Arg arg_3438;
		ESMoL::Line line_3439;
	};

	std::list< Match> _matches;
};

class GetOutArgs_3440
{
public:
	void operator()( const Packets_t& outPorts_3442, Packets_t& subsystemOutPorts_3441, Packets_t& outPorts_3444);

protected:
	bool isInputUnique( const Udm::Object& outPort_344b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_3442);
	bool patternMatcher( const Udm::Object& outPort_3449);
	void effector();
	void outputAppender( const ESMoL::OutPort& subsystemOutPort_345c, const ESMoL::OutPort& outPort_345e);
	void sortOutputs();

private:
	Packets_t* _subsystemOutPort_3445;
	Packets_t* _outPort_3446;
	Packets_t _outPort_3447;
	class Match
	{
	public:
		ESMoL::OutPort outPort_3459;
		ESMoL::OutPort subsystemOutPort_345a;
		ESMoL::Line line_345b;
	};

	std::list< Match> _matches;
};

class CreateInPortLVs_346e
{
public:
	void operator()( const Packets_t& systems_346f, const Packets_t& systemFunctions_3471, Packets_t& systems_3473);

protected:
	void callGetChildInPorts_35d3( const Packets_t& subsystems_3476, const Packets_t& mains_3479);
	void callInPortFilter_35d6( const Packets_t& inPorts_34a3, const Packets_t& systemFunctions_34a5);
	void callCreateLocalVars_35d9( const Packets_t& inPorts_3554, const Packets_t& mains_3556);
	void callGetInArgs_35dc( const Packets_t& inPorts_3581);
	void callGetLocalVars_35de( const Packets_t& inPorts_359d);
	void callZeroInitLocalVars_35e0( const Packets_t& localVars_35b7, const Packets_t& mains_35b9);

private:
	Packets_t* _system_3474;
};

class GetChildInPorts_3475
{
public:
	void operator()( const Packets_t& subsystems_3476, const Packets_t& mains_3479, Packets_t& inPorts_3478, Packets_t& mains_347b);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3482, const Udm::Object& main_348b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3476, const Packets_t& mains_3479);
	bool patternMatcher( const Udm::Object& subsystem_3480, const Udm::Object& main_3489);
	void effector();
	void outputAppender( const ESMoL::InPort& inPort_349e, const SFC::Function& main_34a0);

private:
	Packets_t* _inPort_347c;
	Packets_t* _main_347d;
	Packets_t _subsystem_347e;
	Packets_t _main_3487;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_349a;
		SFC::Function main_349b;
		ESMoL::Block block_349c;
		ESMoL::InPort inPort_349d;
	};

	std::list< Match> _matches;
};

class InPortFilter_34a2
{
public:
	void operator()( const Packets_t& inPorts_34a3, const Packets_t& systemFunctions_34a5, Packets_t& inPorts_34a7, Packets_t& systemFunctions_34a8, Packets_t& inPorts_34a9, Packets_t& systemFunctions_34aa, Packets_t& inPorts_34ab, Packets_t& systemFunctions_34ac);

protected:
	void callInPortTest_354f( const Packets_t& inPorts_34b4, const Packets_t& systemFunctions_34b6);

private:
	Packets_t* _inPort_34ad;
	Packets_t* _systemFunction_34ae;
	Packets_t* _inPort_34af;
	Packets_t* _systemFunction_34b0;
	Packets_t* _inPort_34b1;
	Packets_t* _systemFunction_34b2;
};

class InPortTest_34b3
{
public:
	void operator()( const Packets_t& inPorts_34b4, const Packets_t& systemFunctions_34b6, Packets_t& inPorts_34b8, Packets_t& systemFunctions_34b9, Packets_t& inPorts_34ba, Packets_t& systemFunctions_34bb, Packets_t& inPorts_34bc, Packets_t& systemFunctions_34bd);

protected:
	void executeOne( const Packets_t& inPorts_34b4, const Packets_t& systemFunctions_34b6);
	bool isInputUnique( const Udm::Object& inPort_34c6, const Udm::Object& systemFunction_34cd);

private:
	Packets_t* _inPort_34be;
	Packets_t* _systemFunction_34bf;
	Packets_t* _inPort_34c0;
	Packets_t* _systemFunction_34c1;
	Packets_t* _inPort_34c2;
	Packets_t* _systemFunction_34c3;
	Packets_t _inPort_34c4;
	Packets_t _systemFunction_34cb;
};

class InPort2InPort_34d2
{
public:
	bool operator()( const Packets_t& inPorts_34d3, const Packets_t& mains_34d6, Packets_t& inPorts_34d5, Packets_t& mains_34d8);

protected:
	bool isInputUnique( const Udm::Object& inPort_34df, const Udm::Object& main_34e8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inPorts_34d3, const Packets_t& mains_34d6);
	bool patternMatcher( const Udm::Object& inPort_34dd, const Udm::Object& main_34e6);
	void outputAppender( const ESMoL::InPort& inPort_34fa, const SFC::Function& main_34fc);

private:
	Packets_t* _inPort_34d9;
	Packets_t* _main_34da;
	Packets_t _inPort_34db;
	Packets_t _main_34e4;
	class Match
	{
	public:
		ESMoL::InPort inPort_34f6;
		SFC::Function main_34f7;
		ESMoL::InPort subsystemInPort_34f8;
		ESMoL::Line line_34f9;
	};

	std::list< Match> _matches;
};

class OutPort2InPort_34fe
{
public:
	bool operator()( const Packets_t& inPorts_34ff, const Packets_t& mains_3502, Packets_t& inPorts_3501, Packets_t& mains_3504);

protected:
	bool isInputUnique( const Udm::Object& inPort_350b, const Udm::Object& main_3514);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inPorts_34ff, const Packets_t& mains_3502);
	bool patternMatcher( const Udm::Object& inPort_3509, const Udm::Object& main_3512);
	void outputAppender( const ESMoL::InPort& inPort_3526, const SFC::Function& main_3528);

private:
	Packets_t* _inPort_3505;
	Packets_t* _main_3506;
	Packets_t _inPort_3507;
	Packets_t _main_3510;
	class Match
	{
	public:
		ESMoL::InPort inPort_3522;
		SFC::Function main_3523;
		ESMoL::OutPort outPort_3524;
		ESMoL::Line line_3525;
	};

	std::list< Match> _matches;
};

class Otherwise_352a
{
public:
	bool operator()( const Packets_t& inPorts_352b, const Packets_t& mains_352e, Packets_t& inPorts_352d, Packets_t& mains_3530);

protected:
	bool isInputUnique( const Udm::Object& inPort_3537, const Udm::Object& main_3540);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inPorts_352b, const Packets_t& mains_352e);
	bool patternMatcher( const Udm::Object& inPort_3535, const Udm::Object& main_353e);
	void outputAppender( const ESMoL::InPort& inPort_354b, const SFC::Function& main_354d);

private:
	Packets_t* _inPort_3531;
	Packets_t* _main_3532;
	Packets_t _inPort_3533;
	Packets_t _main_353c;
	class Match
	{
	public:
		ESMoL::InPort inPort_3549;
		SFC::Function main_354a;
	};

	std::list< Match> _matches;
};

class CreateLocalVars_3552
{
public:
	void operator()( const Packets_t& inPorts_3554, const Packets_t& mains_3556, Packets_t& localVars_3553, Packets_t& mains_3558);

protected:
	bool isInputUnique( const Udm::Object& inPort_355f, const Udm::Object& main_3568);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inPorts_3554, const Packets_t& mains_3556);
	bool patternMatcher( const Udm::Object& inPort_355d, const Udm::Object& main_3566);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar_357c, const SFC::Function& main_357e);

private:
	Packets_t* _localVar_3559;
	Packets_t* _main_355a;
	Packets_t _inPort_355b;
	Packets_t _main_3564;
	class Match
	{
	public:
		ESMoL::InPort inPort_3576;
		SFC::Function main_3577;
		ESMoL::TypeBaseRef typeBaseRef_3578;
		SFC::DT dT_3579;
		ESMoL::TypeBase typeBase_357a;
	};

	std::list< Match> _matches;
};

class GetInArgs_3580
{
public:
	void operator()( const Packets_t& inPorts_3581);

protected:
	bool isInputUnique( const Udm::Object& inPort_3587);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inPorts_3581);
	bool patternMatcher( const Udm::Object& inPort_3585);
	void effector();

private:
	Packets_t _inPort_3583;
	class Match
	{
	public:
		ESMoL::InPort inPort_3598;
		SFC::Arg arg_3599;
		ESMoL::InPort subsystemInPort_359a;
		ESMoL::Line line_359b;
	};

	std::list< Match> _matches;
};

class GetLocalVars_359c
{
public:
	void operator()( const Packets_t& inPorts_359d);

protected:
	bool isInputUnique( const Udm::Object& inPort_35a3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inPorts_359d);
	bool patternMatcher( const Udm::Object& inPort_35a1);
	void effector();

private:
	Packets_t _inPort_359f;
	class Match
	{
	public:
		ESMoL::InPort inPort_35b2;
		SFC::ArgDeclBase argDeclBase_35b3;
		ESMoL::OutPort outPort_35b4;
		ESMoL::Line line_35b5;
	};

	std::list< Match> _matches;
};

class ZeroInitLocalVars_35b6
{
public:
	void operator()( const Packets_t& localVars_35b7, const Packets_t& mains_35b9);

protected:
	bool isInputUnique( const Udm::Object& localVar_35bf, const Udm::Object& main_35c8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& localVars_35b7, const Packets_t& mains_35b9);
	bool patternMatcher( const Udm::Object& localVar_35bd, const Udm::Object& main_35c6);
	void effector();

private:
	Packets_t _localVar_35bb;
	Packets_t _main_35c4;
	class Match
	{
	public:
		SFC::LocalVar localVar_35d1;
		SFC::Function main_35d2;
	};

	std::list< Match> _matches;
};

class CreateClasses_35ef
{
public:
	void operator()( const Packets_t& systems_35f0, const Packets_t& programs_35f2, Packets_t& systems_35f4);

protected:
	void callCopyClass_375c( const Packets_t& systems_35f7, const Packets_t& programs_35f9);
	void callGetSubSubsystems_375f( const Packets_t& subsystems_3734, const Packets_t& programs_3737);
	void callSubsystemFilter_3762( const Packets_t& systems_362f, const Packets_t& programs_3631);
	void callCreateChartClass_3765( const Packets_t& subsystems_3715, const Packets_t& programs_3717);
	void callCreateClass_3768( const Packets_t& subsystems_36f2, const Packets_t& programs_36f5);

private:
	Packets_t* _system_35f5;
};

class CopyClass_35f6
{
public:
	void operator()( const Packets_t& systems_35f7, const Packets_t& programs_35f9, Packets_t& systems_35fb, Packets_t& programs_35fc);

protected:
	void callCopyClass_362b( const Packets_t& subsystems_3600, const Packets_t& programs_3602);

private:
	Packets_t* _system_35fd;
	Packets_t* _program_35fe;
};

class CopyClass_35ff
{
public:
	void operator()( const Packets_t& subsystems_3600, const Packets_t& programs_3602);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3608, const Udm::Object& program_3611);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class, ESMoL::Subsystem& InstanceSubsystem, SFC::Program& Program, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_3600, const Packets_t& programs_3602);
	bool patternMatcher( const Udm::Object& subsystem_3606, const Udm::Object& program_360f);
	void effector();

private:
	Packets_t _subsystem_3604;
	Packets_t _program_360d;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3621;
		SFC::Program program_3622;
		SFC::Class class_3623;
		ESMoL::Subsystem instanceSubsystem_3624;
	};

	std::list< Match> _matches;
};

class SubsystemFilter_362e
{
public:
	void operator()( const Packets_t& systems_362f, const Packets_t& programs_3631, Packets_t& systems_3633, Packets_t& programs_3634, Packets_t& systems_3635, Packets_t& programs_3636, Packets_t& systems_3637, Packets_t& programs_3638, Packets_t& systems_3639, Packets_t& programs_363a);

protected:
	void executeOne( const Packets_t& systems_362f, const Packets_t& programs_3631);
	bool isInputUnique( const Udm::Object& system_3645, const Udm::Object& program_364c);

private:
	Packets_t* _system_363b;
	Packets_t* _program_363c;
	Packets_t* _system_363d;
	Packets_t* _program_363e;
	Packets_t* _system_363f;
	Packets_t* _program_3640;
	Packets_t* _system_3641;
	Packets_t* _program_3642;
	Packets_t _system_3643;
	Packets_t _program_364a;
};

class IsInstance_3651
{
public:
	bool operator()( const Packets_t& subsystems_3652, const Packets_t& programs_3655, Packets_t& subsystems_3654, Packets_t& programs_3657);

protected:
	bool isInputUnique( const Udm::Object& subsystem_365e, const Udm::Object& program_3667);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Program& Program, ESMoL::Subsystem& Subsystem);
	void processInputPackets( const Packets_t& subsystems_3652, const Packets_t& programs_3655);
	bool patternMatcher( const Udm::Object& subsystem_365c, const Udm::Object& program_3665);
	void outputAppender( const ESMoL::Subsystem& subsystem_3674, const SFC::Program& program_3676);

private:
	Packets_t* _subsystem_3658;
	Packets_t* _program_3659;
	Packets_t _subsystem_365a;
	Packets_t _program_3663;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3670;
		SFC::Program program_3671;
	};

	std::list< Match> _matches;
};

class HasClass_3678
{
public:
	bool operator()( const Packets_t& subsystems_3679, const Packets_t& programs_367c, Packets_t& subsystems_367b, Packets_t& programs_367e);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3685, const Udm::Object& program_368e);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3679, const Packets_t& programs_367c);
	bool patternMatcher( const Udm::Object& subsystem_3683, const Udm::Object& program_368c);
	void outputAppender( const ESMoL::Subsystem& subsystem_369b, const SFC::Program& program_369d);

private:
	Packets_t* _subsystem_367f;
	Packets_t* _program_3680;
	Packets_t _subsystem_3681;
	Packets_t _program_368a;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3698;
		SFC::Program program_3699;
		SFC::Class class_369a;
	};

	std::list< Match> _matches;
};

class IsStateChart_369f
{
public:
	bool operator()( const Packets_t& subsystems_36a0, const Packets_t& programs_36a3, Packets_t& subsystems_36a2, Packets_t& programs_36a5);

protected:
	bool isInputUnique( const Udm::Object& subsystem_36ac, const Udm::Object& program_36b5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_36a0, const Packets_t& programs_36a3);
	bool patternMatcher( const Udm::Object& subsystem_36aa, const Udm::Object& program_36b3);
	void outputAppender( const ESMoL::Subsystem& subsystem_36c8, const SFC::Program& program_36ca);

private:
	Packets_t* _subsystem_36a6;
	Packets_t* _program_36a7;
	Packets_t _subsystem_36a8;
	Packets_t _program_36b1;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_36c4;
		SFC::Program program_36c5;
		ESMoL::Primitive primitive_36c6;
		ESMoL::ConnectorRef connectorRef_36c7;
	};

	std::list< Match> _matches;
};

class Otherwise_36cc
{
public:
	bool operator()( const Packets_t& subsystems_36cd, const Packets_t& programs_36d0, Packets_t& subsystems_36cf, Packets_t& programs_36d2);

protected:
	bool isInputUnique( const Udm::Object& subsystem_36d9, const Udm::Object& program_36e2);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_36cd, const Packets_t& programs_36d0);
	bool patternMatcher( const Udm::Object& subsystem_36d7, const Udm::Object& program_36e0);
	void outputAppender( const ESMoL::Subsystem& subsystem_36ed, const SFC::Program& program_36ef);

private:
	Packets_t* _subsystem_36d3;
	Packets_t* _program_36d4;
	Packets_t _subsystem_36d5;
	Packets_t _program_36de;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_36eb;
		SFC::Program program_36ec;
	};

	std::list< Match> _matches;
};

class CreateClass_36f1
{
public:
	void operator()( const Packets_t& subsystems_36f2, const Packets_t& programs_36f5, Packets_t& subsystems_36f4, Packets_t& programs_36f7);

protected:
	bool isInputUnique( const Udm::Object& subsystem_36fe, const Udm::Object& program_3707);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_36f2, const Packets_t& programs_36f5);
	bool patternMatcher( const Udm::Object& subsystem_36fc, const Udm::Object& program_3705);
	void effector();
	void forwardInputs();

private:
	Packets_t* _subsystem_36f8;
	Packets_t* _program_36f9;
	Packets_t _subsystem_36fa;
	Packets_t _program_3703;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3710;
		SFC::Program program_3711;
	};

	std::list< Match> _matches;
};

class CreateChartClass_3714
{
public:
	void operator()( const Packets_t& subsystems_3715, const Packets_t& programs_3717);

protected:
	bool isInputUnique( const Udm::Object& subsystem_371d, const Udm::Object& program_3726);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3715, const Packets_t& programs_3717);
	bool patternMatcher( const Udm::Object& subsystem_371b, const Udm::Object& program_3724);
	void effector();

private:
	Packets_t _subsystem_3719;
	Packets_t _program_3722;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_372f;
		SFC::Program program_3730;
	};

	std::list< Match> _matches;
};

class GetSubSubsystems_3733
{
public:
	void operator()( const Packets_t& subsystems_3734, const Packets_t& programs_3737, Packets_t& subSubsystems_3736, Packets_t& programs_3739);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3740, const Udm::Object& program_3749);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3734, const Packets_t& programs_3737);
	bool patternMatcher( const Udm::Object& subsystem_373e, const Udm::Object& program_3747);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subSubsystem_3758, const SFC::Program& program_375a);

private:
	Packets_t* _subSubsystem_373a;
	Packets_t* _program_373b;
	Packets_t _subsystem_373c;
	Packets_t _program_3745;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3755;
		SFC::Program program_3756;
		ESMoL::Subsystem subSubsystem_3757;
	};

	std::list< Match> _matches;
};

class CreateFunctionsAndArgs_376b
{
public:
	void operator()( const Packets_t& systems_376c, Packets_t& systems_376e);

protected:
	void callSubsystemFilter_3b3c( const Packets_t& systems_2ae1);
	void callCreateFunctions_3b3e( const Packets_t& subsystems_3771);
	void callCreateChartFunction_3b40( const Packets_t& subsystems_39c8);
	void callMakeArguments_3b42( const Packets_t& systems_3792, const Packets_t& functions_3794);
	void callMakeChartArguments_3b45( const Packets_t& states_39f3, const Packets_t& functions_39f5);
	void callGetSubSubsystems_3b48( const Packets_t& systems_2b64);

private:
	Packets_t* _system_376f;
};

class CreateFunctions_3770
{
public:
	void operator()( const Packets_t& subsystems_3771, Packets_t& subsystems_3773, Packets_t& mains_3774);

protected:
	bool isInputUnique( const Udm::Object& subsystem_377b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3771);
	bool patternMatcher( const Udm::Object& subsystem_3779);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_378d, const SFC::Function& main_378f);

private:
	Packets_t* _subsystem_3775;
	Packets_t* _main_3776;
	Packets_t _subsystem_3777;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3788;
		SFC::Class class_3789;
		SFC::Struct struct_378a;
	};

	std::list< Match> _matches;
};

class MakeArguments_3791
{
public:
	void operator()( const Packets_t& systems_3792, const Packets_t& functions_3794, Packets_t& systems_3796);

protected:
	void callTrigs_39b7( const Packets_t& systems_3881, const Packets_t& functions_3883);
	void callActions_39ba( const Packets_t& systems_397f, const Packets_t& functions_3981);
	void callInputs_39bd( const Packets_t& systems_380d, const Packets_t& functions_380f);
	void callOutputs_39c0( const Packets_t& systems_3799, const Packets_t& functions_379b);
	void callZeroUnconOutputs_39c3( const Packets_t& systems_38ba, const Packets_t& functions_38bc);

private:
	Packets_t* _system_3797;
};

class Outputs_3798
{
public:
	void operator()( const Packets_t& systems_3799, const Packets_t& functions_379b, Packets_t& systems_379d, Packets_t& functions_379e);

protected:
	void callCreateOutputPortArgs_3802( const Packets_t& subsystems_37d6, const Packets_t& mains_37d9);
	void callMainArgCount_3805( const Packets_t& outputPorts_37a2, const Packets_t& args_37a5, const Packets_t& mains_37a8);
	void callAssignType_3809( const Packets_t& ports_2ab4, const Packets_t& argvars_2ab6);

private:
	Packets_t* _system_379f;
	Packets_t* _function_37a0;
};

class MainArgCount_37a1
{
public:
	void operator()( const Packets_t& outputPorts_37a2, const Packets_t& args_37a5, const Packets_t& mains_37a8, Packets_t& outputPorts_37a4, Packets_t& args_37a7);

protected:
	bool isInputUnique( const Udm::Object& outputPort_37b0, const Udm::Object& arg_37b9, const Udm::Object& main_37c2);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outputPorts_37a2, const Packets_t& args_37a5, const Packets_t& mains_37a8);
	bool patternMatcher( const Udm::Object& outputPort_37ae, const Udm::Object& arg_37b7, const Udm::Object& main_37c0);
	void effector();
	void forwardInputs();

private:
	Packets_t* _outputPort_37aa;
	Packets_t* _arg_37ab;
	Packets_t _outputPort_37ac;
	Packets_t _arg_37b5;
	Packets_t _main_37be;
	class Match
	{
	public:
		ESMoL::OutputPort outputPort_37d1;
		SFC::Arg arg_37d2;
		SFC::Function main_37d3;
	};

	std::list< Match> _matches;
};

class CreateOutputPortArgs_37d4
{
public:
	void operator()( const Packets_t& subsystems_37d6, const Packets_t& mains_37d9, Packets_t& outputPorts_37d5, Packets_t& args_37d8, Packets_t& mains_37db);

protected:
	bool isInputUnique( const Udm::Object& subsystem_37e3, const Udm::Object& main_37ec);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_37d6, const Packets_t& mains_37d9);
	bool patternMatcher( const Udm::Object& subsystem_37e1, const Udm::Object& main_37ea);
	void effector();
	void outputAppender( const ESMoL::OutputPort& outputPort_37fc, const SFC::Arg& arg_37fe, const SFC::Function& main_3800);

private:
	Packets_t* _outputPort_37dc;
	Packets_t* _arg_37dd;
	Packets_t* _main_37de;
	Packets_t _subsystem_37df;
	Packets_t _main_37e8;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_37f8;
		SFC::Function main_37f9;
		ESMoL::OutputPort outputPort_37fa;
	};

	std::list< Match> _matches;
};

class Inputs_380c
{
public:
	void operator()( const Packets_t& systems_380d, const Packets_t& functions_380f, Packets_t& systems_3811, Packets_t& functions_3812);

protected:
	void callCreateInputPortArgs_3876( const Packets_t& subsystems_384a, const Packets_t& mains_384d);
	void callUpdateArgCount_3879( const Packets_t& inputPorts_3816, const Packets_t& args_3819, const Packets_t& mains_381c);
	void callAssignType_387d( const Packets_t& ports_2ab4, const Packets_t& argvars_2ab6);

private:
	Packets_t* _system_3813;
	Packets_t* _function_3814;
};

class UpdateArgCount_3815
{
public:
	void operator()( const Packets_t& inputPorts_3816, const Packets_t& args_3819, const Packets_t& mains_381c, Packets_t& inputPorts_3818, Packets_t& args_381b);

protected:
	bool isInputUnique( const Udm::Object& inputPort_3824, const Udm::Object& arg_382d, const Udm::Object& main_3836);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& inputPorts_3816, const Packets_t& args_3819, const Packets_t& mains_381c);
	bool patternMatcher( const Udm::Object& inputPort_3822, const Udm::Object& arg_382b, const Udm::Object& main_3834);
	void effector();
	void forwardInputs();

private:
	Packets_t* _inputPort_381e;
	Packets_t* _arg_381f;
	Packets_t _inputPort_3820;
	Packets_t _arg_3829;
	Packets_t _main_3832;
	class Match
	{
	public:
		ESMoL::InputPort inputPort_3845;
		SFC::Arg arg_3846;
		SFC::Function main_3847;
	};

	std::list< Match> _matches;
};

class CreateInputPortArgs_3848
{
public:
	void operator()( const Packets_t& subsystems_384a, const Packets_t& mains_384d, Packets_t& inputPorts_3849, Packets_t& args_384c, Packets_t& mains_384f);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3857, const Udm::Object& main_3860);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_384a, const Packets_t& mains_384d);
	bool patternMatcher( const Udm::Object& subsystem_3855, const Udm::Object& main_385e);
	void effector();
	void outputAppender( const ESMoL::InputPort& inputPort_3870, const SFC::Arg& arg_3872, const SFC::Function& main_3874);

private:
	Packets_t* _inputPort_3850;
	Packets_t* _arg_3851;
	Packets_t* _main_3852;
	Packets_t _subsystem_3853;
	Packets_t _main_385c;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_386c;
		SFC::Function main_386d;
		ESMoL::InputPort inputPort_386e;
	};

	std::list< Match> _matches;
};

class Trigs_3880
{
public:
	void operator()( const Packets_t& systems_3881, const Packets_t& functions_3883, Packets_t& systems_3885, Packets_t& functions_3886);

protected:
	void callCreateTriggerPortArgs_38b3( const Packets_t& subsystems_388a, const Packets_t& mains_388e);
	void callAssignType_38b6( const Packets_t& ports_2ab4, const Packets_t& argvars_2ab6);

private:
	Packets_t* _system_3887;
	Packets_t* _function_3888;
};

class CreateTriggerPortArgs_3889
{
public:
	void operator()( const Packets_t& subsystems_388a, const Packets_t& mains_388e, Packets_t& triggerPorts_388c, Packets_t& args_388d);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3896, const Udm::Object& main_389f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_388a, const Packets_t& mains_388e);
	bool patternMatcher( const Udm::Object& subsystem_3894, const Udm::Object& main_389d);
	void effector();
	void outputAppender( const ESMoL::TriggerPort& triggerPort_38af, const SFC::Arg& arg_38b1);

private:
	Packets_t* _triggerPort_3890;
	Packets_t* _arg_3891;
	Packets_t _subsystem_3892;
	Packets_t _main_389b;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_38ab;
		SFC::Function main_38ac;
		ESMoL::TriggerPort triggerPort_38ad;
	};

	std::list< Match> _matches;
};

class ZeroUnconOutputs_38b9
{
public:
	void operator()( const Packets_t& systems_38ba, const Packets_t& functions_38bc, Packets_t& systems_38be);

protected:
	void callGetOutputPorts_3975( const Packets_t& subsystems_392c, const Packets_t& mains_392f);
	void callOutPortConnected_3978( const Packets_t& outps_38c1, const Packets_t& functions_38c3);
	void callZeroOutPort_397b( const Packets_t& outPorts_3955, const Packets_t& mains_3957);

private:
	Packets_t* _system_38bf;
};

class OutPortConnected_38c0
{
public:
	void operator()( const Packets_t& outps_38c1, const Packets_t& functions_38c3, Packets_t& outps_38c5, Packets_t& functions_38c6, Packets_t& outps_38c7, Packets_t& functions_38c8);

protected:
	void executeOne( const Packets_t& outps_38c1, const Packets_t& functions_38c3);
	bool isInputUnique( const Udm::Object& outp_38cf, const Udm::Object& function_38d6);

private:
	Packets_t* _outp_38c9;
	Packets_t* _function_38ca;
	Packets_t* _outp_38cb;
	Packets_t* _function_38cc;
	Packets_t _outp_38cd;
	Packets_t _function_38d4;
};

class Connected_38db
{
public:
	bool operator()( const Packets_t& outPorts_38dc, const Packets_t& mains_38df, Packets_t& outPorts_38de, Packets_t& mains_38e1);

protected:
	bool isInputUnique( const Udm::Object& outPort_38e8, const Udm::Object& main_38f1);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_38dc, const Packets_t& mains_38df);
	bool patternMatcher( const Udm::Object& outPort_38e6, const Udm::Object& main_38ef);
	void outputAppender( const ESMoL::OutPort& outPort_3902, const SFC::Function& main_3904);

private:
	Packets_t* _outPort_38e2;
	Packets_t* _main_38e3;
	Packets_t _outPort_38e4;
	Packets_t _main_38ed;
	class Match
	{
	public:
		ESMoL::OutPort outPort_38fe;
		SFC::Function main_38ff;
		ESMoL::Line line_3900;
		ESMoL::Port port_3901;
	};

	std::list< Match> _matches;
};

class Otherwise_3906
{
public:
	bool operator()( const Packets_t& outPorts_3907, const Packets_t& mains_390a, Packets_t& outPorts_3909, Packets_t& mains_390c);

protected:
	bool isInputUnique( const Udm::Object& outPort_3913, const Udm::Object& main_391c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_3907, const Packets_t& mains_390a);
	bool patternMatcher( const Udm::Object& outPort_3911, const Udm::Object& main_391a);
	void outputAppender( const ESMoL::OutPort& outPort_3927, const SFC::Function& main_3929);

private:
	Packets_t* _outPort_390d;
	Packets_t* _main_390e;
	Packets_t _outPort_390f;
	Packets_t _main_3918;
	class Match
	{
	public:
		ESMoL::OutPort outPort_3925;
		SFC::Function main_3926;
	};

	std::list< Match> _matches;
};

class GetOutputPorts_392b
{
public:
	void operator()( const Packets_t& subsystems_392c, const Packets_t& mains_392f, Packets_t& outPorts_392e, Packets_t& mains_3931);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3938, const Udm::Object& main_3941);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_392c, const Packets_t& mains_392f);
	bool patternMatcher( const Udm::Object& subsystem_3936, const Udm::Object& main_393f);
	void effector();
	void outputAppender( const ESMoL::OutPort& outPort_3950, const SFC::Function& main_3952);

private:
	Packets_t* _outPort_3932;
	Packets_t* _main_3933;
	Packets_t _subsystem_3934;
	Packets_t _main_393d;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_394d;
		SFC::Function main_394e;
		ESMoL::OutPort outPort_394f;
	};

	std::list< Match> _matches;
};

class ZeroOutPort_3954
{
public:
	void operator()( const Packets_t& outPorts_3955, const Packets_t& mains_3957);

protected:
	bool isInputUnique( const Udm::Object& outPort_395d, const Udm::Object& main_3966);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& outPorts_3955, const Packets_t& mains_3957);
	bool patternMatcher( const Udm::Object& outPort_395b, const Udm::Object& main_3964);
	void effector();

private:
	Packets_t _outPort_3959;
	Packets_t _main_3962;
	class Match
	{
	public:
		ESMoL::OutPort outPort_3972;
		SFC::Function main_3973;
		SFC::Arg arg_3974;
	};

	std::list< Match> _matches;
};

class Actions_397e
{
public:
	void operator()( const Packets_t& systems_397f, const Packets_t& functions_3981, Packets_t& systems_3983, Packets_t& functions_3984);

protected:
	void callCreateTriggerPortArgs_39b1( const Packets_t& subsystems_3988, const Packets_t& mains_398c);
	void callAssignType_39b4( const Packets_t& ports_2ab4, const Packets_t& argvars_2ab6);

private:
	Packets_t* _system_3985;
	Packets_t* _function_3986;
};

class CreateTriggerPortArgs_3987
{
public:
	void operator()( const Packets_t& subsystems_3988, const Packets_t& mains_398c, Packets_t& actionPorts_398a, Packets_t& args_398b);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3994, const Udm::Object& main_399d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3988, const Packets_t& mains_398c);
	bool patternMatcher( const Udm::Object& subsystem_3992, const Udm::Object& main_399b);
	void effector();
	void outputAppender( const ESMoL::ActionPort& actionPort_39ad, const SFC::Arg& arg_39af);

private:
	Packets_t* _actionPort_398e;
	Packets_t* _arg_398f;
	Packets_t _subsystem_3990;
	Packets_t _main_3999;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_39a9;
		SFC::Function main_39aa;
		ESMoL::ActionPort actionPort_39ab;
	};

	std::list< Match> _matches;
};

class CreateChartFunction_39c6
{
public:
	void operator()( const Packets_t& subsystems_39c8, Packets_t& states_39c7, Packets_t& mains_39ca);

protected:
	bool isInputUnique( const Udm::Object& subsystem_39d1);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_39c8);
	bool patternMatcher( const Udm::Object& subsystem_39cf);
	void effector();
	void outputAppender( const ESMoL::State& state_39ee, const SFC::Function& main_39f0);

private:
	Packets_t* _state_39cb;
	Packets_t* _main_39cc;
	Packets_t _subsystem_39cd;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_39e6;
		ESMoL::Primitive primitive_39e7;
		ESMoL::ConnectorRef connectorRef_39e8;
		ESMoL::State state_39e9;
		SFC::Class class_39ea;
		SFC::Struct struct_39eb;
	};

	std::list< Match> _matches;
};

class MakeChartArguments_39f2
{
public:
	void operator()( const Packets_t& states_39f3, const Packets_t& functions_39f5);

protected:
	void callDataInput_3b30( const Packets_t& states_39f8, const Packets_t& functions_39fa);
	void callEventInput_3b33( const Packets_t& states_3a5f, const Packets_t& functions_3a61);
	void callDataOutput_3b36( const Packets_t& states_3aa6, const Packets_t& functions_3aa8);
	void callEventOutput_3b39( const Packets_t& states_3aed, const Packets_t& functions_3aef);
};

class DataInput_39f7
{
public:
	void operator()( const Packets_t& states_39f8, const Packets_t& functions_39fa, Packets_t& states_39fc, Packets_t& functions_39fd);

protected:
	void callDataInput_3a58( const Packets_t& states_3a21, const Packets_t& mains_3a24);
	void callUpdateArgCount_3a5b( const Packets_t& args_3a01, const Packets_t& mains_3a03);

private:
	Packets_t* _state_39fe;
	Packets_t* _function_39ff;
};

class UpdateArgCount_3a00
{
public:
	void operator()( const Packets_t& args_3a01, const Packets_t& mains_3a03);

protected:
	bool isInputUnique( const Udm::Object& arg_3a09, const Udm::Object& main_3a12);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& args_3a01, const Packets_t& mains_3a03);
	bool patternMatcher( const Udm::Object& arg_3a07, const Udm::Object& main_3a10);
	void effector();

private:
	Packets_t _arg_3a05;
	Packets_t _main_3a0e;
	class Match
	{
	public:
		SFC::Arg arg_3a1e;
		SFC::Function main_3a1f;
	};

	std::list< Match> _matches;
};

class DataInput_3a20
{
public:
	void operator()( const Packets_t& states_3a21, const Packets_t& mains_3a24, Packets_t& args_3a23, Packets_t& mains_3a26);

protected:
	bool isInputUnique( const Udm::Object& state_3a2d, const Udm::Object& main_3a36);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::DT& DT, ESMoL::Data& Data, SFC::Function& Main, ESMoL::State& State, ESMoL::TypeBase& TypeBase, ESMoL::TypeBaseRef& TypeBaseRef);
	void processInputPackets( const Packets_t& states_3a21, const Packets_t& mains_3a24);
	bool patternMatcher( const Udm::Object& state_3a2b, const Udm::Object& main_3a34);
	void effector();
	void outputAppender( const SFC::Arg& arg_3a54, const SFC::Function& main_3a56);

private:
	Packets_t* _arg_3a27;
	Packets_t* _main_3a28;
	Packets_t _state_3a29;
	Packets_t _main_3a32;
	class Match
	{
	public:
		ESMoL::State state_3a47;
		SFC::Function main_3a48;
		ESMoL::TypeBase typeBase_3a49;
		SFC::DT dT_3a4a;
		ESMoL::Data data_3a4b;
		ESMoL::TypeBaseRef typeBaseRef_3a4c;
	};

	std::list< Match> _matches;
};

class EventInput_3a5e
{
public:
	void operator()( const Packets_t& states_3a5f, const Packets_t& functions_3a61, Packets_t& states_3a63, Packets_t& functions_3a64);

protected:
	void callEventInput_3a9f( const Packets_t& states_3a68, const Packets_t& mains_3a6b);
	void callUpdateArgCount_3aa2( const Packets_t& args_3a01, const Packets_t& mains_3a03);

private:
	Packets_t* _state_3a65;
	Packets_t* _function_3a66;
};

class EventInput_3a67
{
public:
	void operator()( const Packets_t& states_3a68, const Packets_t& mains_3a6b, Packets_t& args_3a6a, Packets_t& mains_3a6d);

protected:
	bool isInputUnique( const Udm::Object& state_3a74, const Udm::Object& main_3a7d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::DT& DT, ESMoL::Event& Event, SFC::Function& Main, ESMoL::State& State, ESMoL::TypeBase& TypeBase, ESMoL::TypeBaseRef& TypeBaseRef);
	void processInputPackets( const Packets_t& states_3a68, const Packets_t& mains_3a6b);
	bool patternMatcher( const Udm::Object& state_3a72, const Udm::Object& main_3a7b);
	void effector();
	void outputAppender( const SFC::Arg& arg_3a9b, const SFC::Function& main_3a9d);

private:
	Packets_t* _arg_3a6e;
	Packets_t* _main_3a6f;
	Packets_t _state_3a70;
	Packets_t _main_3a79;
	class Match
	{
	public:
		ESMoL::State state_3a8e;
		SFC::Function main_3a8f;
		ESMoL::TypeBase typeBase_3a90;
		SFC::DT dT_3a91;
		ESMoL::Event event_3a92;
		ESMoL::TypeBaseRef typeBaseRef_3a93;
	};

	std::list< Match> _matches;
};

class DataOutput_3aa5
{
public:
	void operator()( const Packets_t& states_3aa6, const Packets_t& functions_3aa8, Packets_t& states_3aaa, Packets_t& functions_3aab);

protected:
	void callDataOutput_3ae6( const Packets_t& states_3aaf, const Packets_t& mains_3ab2);
	void callUpdateArgCount_3ae9( const Packets_t& args_3a01, const Packets_t& mains_3a03);

private:
	Packets_t* _state_3aac;
	Packets_t* _function_3aad;
};

class DataOutput_3aae
{
public:
	void operator()( const Packets_t& states_3aaf, const Packets_t& mains_3ab2, Packets_t& args_3ab1, Packets_t& mains_3ab4);

protected:
	bool isInputUnique( const Udm::Object& state_3abb, const Udm::Object& main_3ac4);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::DT& DT, ESMoL::Data& Data, SFC::Function& Main, ESMoL::State& State, ESMoL::TypeBase& TypeBase, ESMoL::TypeBaseRef& TypeBaseRef);
	void processInputPackets( const Packets_t& states_3aaf, const Packets_t& mains_3ab2);
	bool patternMatcher( const Udm::Object& state_3ab9, const Udm::Object& main_3ac2);
	void effector();
	void outputAppender( const SFC::Arg& arg_3ae2, const SFC::Function& main_3ae4);

private:
	Packets_t* _arg_3ab5;
	Packets_t* _main_3ab6;
	Packets_t _state_3ab7;
	Packets_t _main_3ac0;
	class Match
	{
	public:
		ESMoL::State state_3ad5;
		SFC::Function main_3ad6;
		ESMoL::TypeBase typeBase_3ad7;
		SFC::DT dT_3ad8;
		ESMoL::Data data_3ad9;
		ESMoL::TypeBaseRef typeBaseRef_3ada;
	};

	std::list< Match> _matches;
};

class EventOutput_3aec
{
public:
	void operator()( const Packets_t& states_3aed, const Packets_t& functions_3aef);

protected:
	void callEventOutput_3b2a( const Packets_t& states_3af2, const Packets_t& mains_3af5);
	void callUpdateArgCount_3b2d( const Packets_t& args_3a01, const Packets_t& mains_3a03);
};

class EventOutput_3af1
{
public:
	void operator()( const Packets_t& states_3af2, const Packets_t& mains_3af5, Packets_t& args_3af4, Packets_t& mains_3af7);

protected:
	bool isInputUnique( const Udm::Object& state_3afe, const Udm::Object& main_3b07);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::DT& DT, ESMoL::Event& Event, SFC::Function& Main, ESMoL::State& State, ESMoL::TypeBaseRef& TypeBaseRef, ESMoL::TypeStruct& TypeStruct);
	void processInputPackets( const Packets_t& states_3af2, const Packets_t& mains_3af5);
	bool patternMatcher( const Udm::Object& state_3afc, const Udm::Object& main_3b05);
	void effector();
	void outputAppender( const SFC::Arg& arg_3b26, const SFC::Function& main_3b28);

private:
	Packets_t* _arg_3af8;
	Packets_t* _main_3af9;
	Packets_t _state_3afa;
	Packets_t _main_3b03;
	class Match
	{
	public:
		ESMoL::State state_3b19;
		SFC::Function main_3b1a;
		ESMoL::TypeStruct typeStruct_3b1b;
		SFC::DT dT_3b1c;
		ESMoL::Event event_3b1d;
		ESMoL::TypeBaseRef typeBaseRef_3b1e;
	};

	std::list< Match> _matches;
};

class Constructors_3b5c
{
public:
	void operator()( const Packets_t& dataflows_3b5d, const Packets_t& projects_3b5f, Packets_t& dataflows_3b61, Packets_t& projects_3b62);

protected:
	void callGetSubsystems_3ef8( const Packets_t& dataflows_1);
	void callMakeAllConstructors_3efa( const Packets_t& subsystems_3b66);

private:
	Packets_t* _dataflow_3b63;
	Packets_t* _project_3b64;
};

class MakeAllConstructors_3b65
{
public:
	void operator()( const Packets_t& subsystems_3b66);

protected:
	void callSubsystemFilter_3ef0( const Packets_t& systems_2ae1);
	void callMakeConstructors_3ef2( const Packets_t& systems_3b69);
	void callMakeChartConstructor_3ef4( const Packets_t& systems_3ec8);
	void callGetSubSubsystems_3ef6( const Packets_t& systems_2b64);
};

class MakeConstructors_3b68
{
public:
	void operator()( const Packets_t& systems_3b69, Packets_t& systems_3b6b);

protected:
	void callCreateInitFunction_3ebe( const Packets_t& subsystems_3b9f);
	void callinitParameters_3ec0( const Packets_t& systems_3bc4, const Packets_t& initFunctions_3bc6, const Packets_t& classStructs_3bc8);
	void callinitSubSubsystem_3ec4( const Packets_t& subsystems_3b6e, const Packets_t& initFunctions_3b70);

private:
	Packets_t* _system_3b6c;
};

class InitSubSubsystem_3b6d
{
public:
	void operator()( const Packets_t& subsystems_3b6e, const Packets_t& initFunctions_3b70);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3b76, const Udm::Object& initFunction_3b7f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3b6e, const Packets_t& initFunctions_3b70);
	bool patternMatcher( const Udm::Object& subsystem_3b74, const Udm::Object& initFunction_3b7d);
	void effector();

private:
	Packets_t _subsystem_3b72;
	Packets_t _initFunction_3b7b;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3b92;
		SFC::Function initFunction_3b93;
		SFC::LocalVar localVar_3b94;
		SFC::Arg superArg_3b95;
		SFC::Function superInitFunction_3b96;
		ESMoL::Subsystem superSubsystem_3b97;
		SFC::Arg arg_3b98;
	};

	std::list< Match> _matches;
};

class CreateInitFunction_3b9e
{
public:
	void operator()( const Packets_t& subsystems_3b9f, Packets_t& subsystems_3ba1, Packets_t& initFunctions_3ba2, Packets_t& structs_3ba3);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3bab);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3b9f);
	bool patternMatcher( const Udm::Object& subsystem_3ba9);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_3bbd, const SFC::Function& initFunction_3bbf, const SFC::Struct& struct_3bc1);

private:
	Packets_t* _subsystem_3ba4;
	Packets_t* _initFunction_3ba5;
	Packets_t* _struct_3ba6;
	Packets_t _subsystem_3ba7;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3bb8;
		SFC::Class class_3bb9;
		SFC::Struct struct_3bba;
	};

	std::list< Match> _matches;
};

class InitParameters_3bc3
{
public:
	void operator()( const Packets_t& systems_3bc4, const Packets_t& initFunctions_3bc6, const Packets_t& classStructs_3bc8, Packets_t& systems_3bca, Packets_t& initFunctions_3bcb);

protected:
	void callinitDirectParameters_3eae( const Packets_t& systems_3bcf, const Packets_t& initFunctions_3bd1, const Packets_t& classStructs_3bd3);
	void callinitPrimitiveParameters_3eb2( const Packets_t& systems_3cd1, const Packets_t& initFunctions_3cd3, const Packets_t& classStructs_3cd5);
	void callinitPrimPseudoParams_3eb6( const Packets_t& systems_3e63, const Packets_t& initFunctions_3e65, const Packets_t& classStructs_3e67);
	void callInitTriggerVars_3eba( const Packets_t& systems_3c14, const Packets_t& initFunctions_3c16, const Packets_t& classStructs_3c18);

private:
	Packets_t* _system_3bcc;
	Packets_t* _initFunction_3bcd;
};

class InitDirectParameters_3bce
{
public:
	void operator()( const Packets_t& systems_3bcf, const Packets_t& initFunctions_3bd1, const Packets_t& classStructs_3bd3, Packets_t& systems_3bd5, Packets_t& initFunctions_3bd6, Packets_t& classStructs_3bd7);

protected:
	void callinitDirectParameter_3c0f( const Packets_t& subsystems_3bdc, const Packets_t& initFunctions_3bde, const Packets_t& classStructs_3be0);

private:
	Packets_t* _system_3bd8;
	Packets_t* _initFunction_3bd9;
	Packets_t* _classStruct_3bda;
};

class InitDirectParameter_3bdb
{
public:
	void operator()( const Packets_t& subsystems_3bdc, const Packets_t& initFunctions_3bde, const Packets_t& classStructs_3be0);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3be6, const Udm::Object& initFunction_3bef, const Udm::Object& classStruct_3bf8);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3bdc, const Packets_t& initFunctions_3bde, const Packets_t& classStructs_3be0);
	bool patternMatcher( const Udm::Object& subsystem_3be4, const Udm::Object& initFunction_3bed, const Udm::Object& classStruct_3bf6);
	void effector();

private:
	Packets_t _subsystem_3be2;
	Packets_t _initFunction_3beb;
	Packets_t _classStruct_3bf4;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3c0a;
		SFC::Function initFunction_3c0b;
		SFC::Struct classStruct_3c0c;
		ESMoL::Parameter parameter_3c0d;
		SFC::LocalVar localVar_3c0e;
	};

	std::list< Match> _matches;
};

class InitTriggerVars_3c13
{
public:
	void operator()( const Packets_t& systems_3c14, const Packets_t& initFunctions_3c16, const Packets_t& classStructs_3c18);

protected:
	void callInitMatrixTrigger_3cc8( const Packets_t& systems_3c1b, const Packets_t& initFunctions_3c1d, const Packets_t& classStructs_3c1f);
	void callInitStructTrigger_3ccc( const Packets_t& systems_3c75, const Packets_t& initFunctions_3c77, const Packets_t& classStructs_3c79);
};

class InitMatrixTrigger_3c1a
{
public:
	void operator()( const Packets_t& systems_3c1b, const Packets_t& initFunctions_3c1d, const Packets_t& classStructs_3c1f, Packets_t& outs_3c21, Packets_t& initFunctions_3c22, Packets_t& classStructs_3c23);

protected:
	void callInitMatrixTrigger_3c70( const Packets_t& subsystems_3c28, const Packets_t& initFunctions_3c2a, const Packets_t& classStructs_3c2c);

private:
	Packets_t* _out_3c24;
	Packets_t* _initFunction_3c25;
	Packets_t* _classStruct_3c26;
};

class InitMatrixTrigger_3c27
{
public:
	void operator()( const Packets_t& subsystems_3c28, const Packets_t& initFunctions_3c2a, const Packets_t& classStructs_3c2c);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3c32, const Udm::Object& initFunction_3c3b, const Udm::Object& classStruct_3c44);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::Struct& ClassStruct, SFC::DT& DT, SFC::Function& InitFunction, SFC::LocalVar& LocalVar, ESMoL::Subsystem& Subsystem, ESMoL::TriggerPort& TriggerPort);
	void processInputPackets( const Packets_t& subsystems_3c28, const Packets_t& initFunctions_3c2a, const Packets_t& classStructs_3c2c);
	bool patternMatcher( const Udm::Object& subsystem_3c30, const Udm::Object& initFunction_3c39, const Udm::Object& classStruct_3c42);
	void effector();

private:
	Packets_t _subsystem_3c2e;
	Packets_t _initFunction_3c37;
	Packets_t _classStruct_3c40;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3c5c;
		SFC::Function initFunction_3c5d;
		SFC::Struct classStruct_3c5e;
		ESMoL::TriggerPort triggerPort_3c5f;
		SFC::Arg arg_3c60;
		SFC::LocalVar localVar_3c61;
		SFC::DT dT_3c62;
	};

	std::list< Match> _matches;
};

class InitStructTrigger_3c74
{
public:
	void operator()( const Packets_t& systems_3c75, const Packets_t& initFunctions_3c77, const Packets_t& classStructs_3c79);

protected:
	void callInitStructTrigger_3cc4( const Packets_t& subsystems_3c7c, const Packets_t& initFunctions_3c7e, const Packets_t& classStructs_3c80);
};

class InitStructTrigger_3c7b
{
public:
	void operator()( const Packets_t& subsystems_3c7c, const Packets_t& initFunctions_3c7e, const Packets_t& classStructs_3c80);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3c86, const Udm::Object& initFunction_3c8f, const Udm::Object& classStruct_3c98);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3c7c, const Packets_t& initFunctions_3c7e, const Packets_t& classStructs_3c80);
	bool patternMatcher( const Udm::Object& subsystem_3c84, const Udm::Object& initFunction_3c8d, const Udm::Object& classStruct_3c96);
	void effector();

private:
	Packets_t _subsystem_3c82;
	Packets_t _initFunction_3c8b;
	Packets_t _classStruct_3c94;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3cb4;
		SFC::Function initFunction_3cb5;
		SFC::Struct classStruct_3cb6;
		ESMoL::TriggerPort triggerPort_3cb7;
		SFC::Arg arg_3cb8;
		SFC::LocalVar member_3cb9;
		SFC::LocalVar localVar_3cba;
		SFC::Struct struct_3cbb;
	};

	std::list< Match> _matches;
};

class InitPrimitiveParameters_3cd0
{
public:
	void operator()( const Packets_t& systems_3cd1, const Packets_t& initFunctions_3cd3, const Packets_t& classStructs_3cd5, Packets_t& systems_3cd7, Packets_t& initFunctions_3cd8, Packets_t& classStructs_3cd9);

protected:
	void callGetStructMembers_3e52( const Packets_t& subsystems_3df1, const Packets_t& initFunctions_3df4, const Packets_t& classStructs_3df7);
	void callTest_3e56( const Packets_t& systems_3d14, const Packets_t& initFunctions_3d16, const Packets_t& members_3d18);
	void callinitPrimitiveParameter_3e5a( const Packets_t& subsystem1s_3cde, const Packets_t& initFunctions_3ce0, const Packets_t& localVars_3ce2);
	void callzeroPrimitiveParameter_3e5e( const Packets_t& subsystems_3e2a, const Packets_t& initFunctions_3e2c, const Packets_t& localVars_3e2e);

private:
	Packets_t* _system_3cda;
	Packets_t* _initFunction_3cdb;
	Packets_t* _classStruct_3cdc;
};

class InitPrimitiveParameter_3cdd
{
public:
	void operator()( const Packets_t& subsystem1s_3cde, const Packets_t& initFunctions_3ce0, const Packets_t& localVars_3ce2);

protected:
	bool isInputUnique( const Udm::Object& subsystem1_3ce8, const Udm::Object& initFunction_3cf1, const Udm::Object& localVar_3cfa);
	bool isGuardTrue( SFC::Function& InitFunction, SFC::LocalVar& LocalVar, ESMoL::Parameter& Parameter, ESMoL::Primitive& Primitive, ESMoL::Subsystem& Subsystem1, ESMoL::Subsystem& Subsystem2);
	void processInputPackets( const Packets_t& subsystem1s_3cde, const Packets_t& initFunctions_3ce0, const Packets_t& localVars_3ce2);
	bool patternMatcher( const Udm::Object& subsystem1_3ce6, const Udm::Object& initFunction_3cef, const Udm::Object& localVar_3cf8);
	void effector();

private:
	Packets_t _subsystem1_3ce4;
	Packets_t _initFunction_3ced;
	Packets_t _localVar_3cf6;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem1_3d07;
		SFC::Function initFunction_3d08;
		SFC::LocalVar localVar_3d09;
		ESMoL::Subsystem subsystem2_3d0a;
		ESMoL::Primitive primitive_3d0b;
		ESMoL::Parameter parameter_3d0c;
	};

	std::list< Match> _matches;
};

class Test_3d13
{
public:
	void operator()( const Packets_t& systems_3d14, const Packets_t& initFunctions_3d16, const Packets_t& members_3d18, Packets_t& systems_3d1a, Packets_t& initFunctions_3d1b, Packets_t& classStructs_3d1c, Packets_t& systems_3d1d, Packets_t& initFunctions_3d1e, Packets_t& classStructs_3d1f, Packets_t& systems_3d20, Packets_t& initFunctions_3d21, Packets_t& classStructs_3d22);

protected:
	void executeOne( const Packets_t& systems_3d14, const Packets_t& initFunctions_3d16, const Packets_t& members_3d18);
	bool isInputUnique( const Udm::Object& system_3d2e, const Udm::Object& initFunction_3d35, const Udm::Object& member_3d3c);

private:
	Packets_t* _system_3d23;
	Packets_t* _initFunction_3d24;
	Packets_t* _classStruct_3d25;
	Packets_t* _system_3d26;
	Packets_t* _initFunction_3d27;
	Packets_t* _classStruct_3d28;
	Packets_t* _system_3d29;
	Packets_t* _initFunction_3d2a;
	Packets_t* _classStruct_3d2b;
	Packets_t _system_3d2c;
	Packets_t _initFunction_3d33;
	Packets_t _member_3d3a;
};

class MemberHasParameter_3d41
{
public:
	bool operator()( const Packets_t& subsystem1s_3d42, const Packets_t& initFunctions_3d45, const Packets_t& localVars_3d48, Packets_t& subsystem1s_3d44, Packets_t& initFunctions_3d47, Packets_t& localVars_3d4a);

protected:
	bool isInputUnique( const Udm::Object& subsystem1_3d52, const Udm::Object& initFunction_3d5b, const Udm::Object& localVar_3d64);
	bool isGuardTrue( SFC::Function& InitFunction, SFC::LocalVar& LocalVar, ESMoL::Parameter& Parameter, ESMoL::Primitive& Primitive, ESMoL::Subsystem& Subsystem1, ESMoL::Subsystem& Subsystem2);
	void processInputPackets( const Packets_t& subsystem1s_3d42, const Packets_t& initFunctions_3d45, const Packets_t& localVars_3d48);
	bool patternMatcher( const Udm::Object& subsystem1_3d50, const Udm::Object& initFunction_3d59, const Udm::Object& localVar_3d62);
	void outputAppender( const ESMoL::Subsystem& subsystem1_3d7d, const SFC::Function& initFunction_3d7f, const SFC::LocalVar& localVar_3d81);

private:
	Packets_t* _subsystem1_3d4b;
	Packets_t* _initFunction_3d4c;
	Packets_t* _localVar_3d4d;
	Packets_t _subsystem1_3d4e;
	Packets_t _initFunction_3d57;
	Packets_t _localVar_3d60;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem1_3d71;
		SFC::Function initFunction_3d72;
		SFC::LocalVar localVar_3d73;
		ESMoL::Subsystem subsystem2_3d74;
		ESMoL::Primitive primitive_3d75;
		ESMoL::Parameter parameter_3d76;
	};

	std::list< Match> _matches;
};

class StructMember_3d83
{
public:
	bool operator()( const Packets_t& subsystems_3d84, const Packets_t& initFunctions_3d87, const Packets_t& localVars_3d8a, Packets_t& subsystems_3d86, Packets_t& initFunctions_3d89, Packets_t& localVars_3d8c);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3d94, const Udm::Object& initFunction_3d9d, const Udm::Object& localVar_3da6);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3d84, const Packets_t& initFunctions_3d87, const Packets_t& localVars_3d8a);
	bool patternMatcher( const Udm::Object& subsystem_3d92, const Udm::Object& initFunction_3d9b, const Udm::Object& localVar_3da4);
	void outputAppender( const ESMoL::Subsystem& subsystem_3db5, const SFC::Function& initFunction_3db7, const SFC::LocalVar& localVar_3db9);

private:
	Packets_t* _subsystem_3d8d;
	Packets_t* _initFunction_3d8e;
	Packets_t* _localVar_3d8f;
	Packets_t _subsystem_3d90;
	Packets_t _initFunction_3d99;
	Packets_t _localVar_3da2;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3db1;
		SFC::Function initFunction_3db2;
		SFC::LocalVar localVar_3db3;
		SFC::Struct struct_3db4;
	};

	std::list< Match> _matches;
};

class MemberNoParameter_3dbb
{
public:
	bool operator()( const Packets_t& subsystems_3dbc, const Packets_t& initFunctions_3dbf, const Packets_t& localVars_3dc2, Packets_t& subsystems_3dbe, Packets_t& initFunctions_3dc1, Packets_t& localVars_3dc4);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3dcc, const Udm::Object& initFunction_3dd5, const Udm::Object& localVar_3dde);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3dbc, const Packets_t& initFunctions_3dbf, const Packets_t& localVars_3dc2);
	bool patternMatcher( const Udm::Object& subsystem_3dca, const Udm::Object& initFunction_3dd3, const Udm::Object& localVar_3ddc);
	void outputAppender( const ESMoL::Subsystem& subsystem_3dea, const SFC::Function& initFunction_3dec, const SFC::LocalVar& localVar_3dee);

private:
	Packets_t* _subsystem_3dc5;
	Packets_t* _initFunction_3dc6;
	Packets_t* _localVar_3dc7;
	Packets_t _subsystem_3dc8;
	Packets_t _initFunction_3dd1;
	Packets_t _localVar_3dda;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3de7;
		SFC::Function initFunction_3de8;
		SFC::LocalVar localVar_3de9;
	};

	std::list< Match> _matches;
};

class GetStructMembers_3df0
{
public:
	void operator()( const Packets_t& subsystems_3df1, const Packets_t& initFunctions_3df4, const Packets_t& classStructs_3df7, Packets_t& subsystems_3df3, Packets_t& initFunctions_3df6, Packets_t& localVars_3df9);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3e01, const Udm::Object& initFunction_3e0a, const Udm::Object& classStruct_3e13);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3df1, const Packets_t& initFunctions_3df4, const Packets_t& classStructs_3df7);
	bool patternMatcher( const Udm::Object& subsystem_3dff, const Udm::Object& initFunction_3e08, const Udm::Object& classStruct_3e11);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_3e23, const SFC::Function& initFunction_3e25, const SFC::LocalVar& localVar_3e27);

private:
	Packets_t* _subsystem_3dfa;
	Packets_t* _initFunction_3dfb;
	Packets_t* _localVar_3dfc;
	Packets_t _subsystem_3dfd;
	Packets_t _initFunction_3e06;
	Packets_t _classStruct_3e0f;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3e1f;
		SFC::Function initFunction_3e20;
		SFC::Struct classStruct_3e21;
		SFC::LocalVar localVar_3e22;
	};

	std::list< Match> _matches;
};

class ZeroPrimitiveParameter_3e29
{
public:
	void operator()( const Packets_t& subsystems_3e2a, const Packets_t& initFunctions_3e2c, const Packets_t& localVars_3e2e);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3e34, const Udm::Object& initFunction_3e3d, const Udm::Object& localVar_3e46);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3e2a, const Packets_t& initFunctions_3e2c, const Packets_t& localVars_3e2e);
	bool patternMatcher( const Udm::Object& subsystem_3e32, const Udm::Object& initFunction_3e3b, const Udm::Object& localVar_3e44);
	void effector();

private:
	Packets_t _subsystem_3e30;
	Packets_t _initFunction_3e39;
	Packets_t _localVar_3e42;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3e4f;
		SFC::Function initFunction_3e50;
		SFC::LocalVar localVar_3e51;
	};

	std::list< Match> _matches;
};

class InitPrimPseudoParams_3e62
{
public:
	void operator()( const Packets_t& systems_3e63, const Packets_t& initFunctions_3e65, const Packets_t& classStructs_3e67, Packets_t& systems_3e69, Packets_t& initFunctions_3e6a, Packets_t& classStructs_3e6b);

protected:
	void callinitPrimPseudoParam_3eaa( const Packets_t& subsystem1s_3e70, const Packets_t& initFunctions_3e72, const Packets_t& classStructs_3e74);

private:
	Packets_t* _system_3e6c;
	Packets_t* _initFunction_3e6d;
	Packets_t* _classStruct_3e6e;
};

class InitPrimPseudoParam_3e6f
{
public:
	void operator()( const Packets_t& subsystem1s_3e70, const Packets_t& initFunctions_3e72, const Packets_t& classStructs_3e74);

protected:
	bool isInputUnique( const Udm::Object& subsystem1_3e7a, const Udm::Object& initFunction_3e83, const Udm::Object& classStruct_3e8c);
	bool isGuardTrue( SFC::Struct& ClassStruct, SFC::Function& InitFunction, SFC::LocalVar& LocalVar, ESMoL::Parameter& Parameter, ESMoL::Primitive& Primitive, ESMoL::Subsystem& Subsystem1, ESMoL::Subsystem& Subsystem2);
	void processInputPackets( const Packets_t& subsystem1s_3e70, const Packets_t& initFunctions_3e72, const Packets_t& classStructs_3e74);
	bool patternMatcher( const Udm::Object& subsystem1_3e78, const Udm::Object& initFunction_3e81, const Udm::Object& classStruct_3e8a);
	void effector();

private:
	Packets_t _subsystem1_3e76;
	Packets_t _initFunction_3e7f;
	Packets_t _classStruct_3e88;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem1_3e9c;
		SFC::Function initFunction_3e9d;
		SFC::Struct classStruct_3e9e;
		ESMoL::Subsystem subsystem2_3e9f;
		ESMoL::Primitive primitive_3ea0;
		ESMoL::Parameter parameter_3ea1;
		SFC::LocalVar localVar_3ea2;
	};

	std::list< Match> _matches;
};

class MakeChartConstructor_3ec7
{
public:
	void operator()( const Packets_t& systems_3ec8);

protected:
	void callCreateInitFunction_3eeb( const Packets_t& subsystems_3ecb);
	void callinitSubSubsystem_3eed( const Packets_t& subsystems_3b6e, const Packets_t& initFunctions_3b70);
};

class CreateInitFunction_3eca
{
public:
	void operator()( const Packets_t& subsystems_3ecb, Packets_t& subsystems_3ecd, Packets_t& initFunctions_3ece);

protected:
	bool isInputUnique( const Udm::Object& subsystem_3ed5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_3ecb);
	bool patternMatcher( const Udm::Object& subsystem_3ed3);
	void effector();
	void outputAppender( const ESMoL::Subsystem& subsystem_3ee7, const SFC::Function& initFunction_3ee9);

private:
	Packets_t* _subsystem_3ecf;
	Packets_t* _initFunction_3ed0;
	Packets_t _subsystem_3ed1;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_3ee2;
		SFC::Class class_3ee3;
		SFC::Struct struct_3ee4;
	};

	std::list< Match> _matches;
};

class MergeClasses_3efc
{
public:
	void operator()( const Packets_t& dataflows_3efd, const Packets_t& projects_3eff, Packets_t& dataflows_3f01, Packets_t& projects_3f02);

protected:
	void callMergeClasses_45da( const Packets_t& projects_3f61);
	void callElimRedundantClasses_45dc( const Packets_t& projects_3f06);

private:
	Packets_t* _dataflow_3f03;
	Packets_t* _project_3f04;
};

class ElimRedundantClasses_3f05
{
public:
	void operator()( const Packets_t& projects_3f06, Packets_t& projects_3f08);

protected:
	void callGetClasses_3f5a( const Packets_t& projects_3f3f);
	void callRedundancyTest_3f5c( const Packets_t& classs_3f1c);
	void callDeleteClass_3f5e( const Packets_t& classs_3f0b);

private:
	Packets_t* _project_3f09;
};

class DeleteClass_3f0a
{
public:
	void operator()( const Packets_t& classs_3f0b);

protected:
	bool isInputUnique( const Udm::Object& class_3f11);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_3f0b);
	bool patternMatcher( const Udm::Object& class_3f0f);
	void effector();

private:
	Packets_t _class_3f0d;
	class Match
	{
	public:
		SFC::Class class_3f1a;
	};

	std::list< Match> _matches;
};

class RedundancyTest_3f1b
{
public:
	void operator()( const Packets_t& classs_3f1c, Packets_t& classs_3f1e);

protected:
	void executeOne( const Packets_t& classs_3f1c);
	bool isInputUnique( const Udm::Object& class_3f22);

private:
	Packets_t* _class_3f1f;
	Packets_t _class_3f20;
};

class NegStatementCount_3f27
{
public:
	bool operator()( const Packets_t& classs_3f28, Packets_t& classs_3f2a);

protected:
	bool isInputUnique( const Udm::Object& class_3f30);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class);
	void processInputPackets( const Packets_t& classs_3f28);
	bool patternMatcher( const Udm::Object& class_3f2e);
	void outputAppender( const SFC::Class& class_3f3b);

private:
	Packets_t* _class_3f2b;
	Packets_t _class_3f2c;
	class Match
	{
	public:
		SFC::Class class_3f39;
	};

	std::list< Match> _matches;
};

class GetClasses_3f3d
{
public:
	void operator()( const Packets_t& projects_3f3f, Packets_t& classs_3f3e);

protected:
	bool isInputUnique( const Udm::Object& project_3f46);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& projects_3f3f);
	bool patternMatcher( const Udm::Object& project_3f44);
	void effector();
	void outputAppender( const SFC::Class& class_3f58);

private:
	Packets_t* _class_3f41;
	Packets_t _project_3f42;
	class Match
	{
	public:
		SFC::Project project_3f55;
		SFC::Program program_3f56;
		SFC::Class class_3f57;
	};

	std::list< Match> _matches;
};

class MergeClasses_3f60
{
public:
	void operator()( const Packets_t& projects_3f61, Packets_t& projects_3f63);

protected:
	void callMakeEquivalence_45d4( const Packets_t& projects_45a8);
	void callGetClasses_45d6( const Packets_t& projects_458c);
	void callOneClassAtATime_45d8( const Packets_t& classs_3f66);

private:
	Packets_t* _project_3f64;
};

class OneClassAtATime_3f65
{
public:
	void operator()( const Packets_t& classs_3f66);

protected:
	void executeOne( const Packets_t& classs_3f66);
	bool isInputUnique( const Udm::Object& class_3f6a);
	void callClassFilter_4582( const Packets_t& classs_3f70);
	void callMergeClasses_4584( const Packets_t& classs_4025);
	void callGetNextLevelClasses_4586( const Packets_t& childClasss_4002);
	void callOneClassAtATime_4588( const Packets_t& classs_3f66);

private:
	Packets_t _class_3f68;
};

class ClassFilter_3f6f
{
public:
	void operator()( const Packets_t& classs_3f70, Packets_t& classs_3f72);

protected:
	void callSimpleStructFilter_3fff( const Packets_t& classs_3f75);

private:
	Packets_t* _class_3f73;
};

class SimpleStructFilter_3f74
{
public:
	void operator()( const Packets_t& classs_3f75, Packets_t& classs_3f77, Packets_t& classs_3f78, Packets_t& classs_3f79, Packets_t& classs_3f7a);

protected:
	void executeOne( const Packets_t& classs_3f75);
	bool isInputUnique( const Udm::Object& class_3f81);

private:
	Packets_t* _class_3f7b;
	Packets_t* _class_3f7c;
	Packets_t* _class_3f7d;
	Packets_t* _class_3f7e;
	Packets_t _class_3f7f;
};

class Marked_3f86
{
public:
	bool operator()( const Packets_t& classs_3f87, Packets_t& classs_3f89);

protected:
	bool isInputUnique( const Udm::Object& class_3f8f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class);
	void processInputPackets( const Packets_t& classs_3f87);
	bool patternMatcher( const Udm::Object& class_3f8d);
	void outputAppender( const SFC::Class& class_3f9a);

private:
	Packets_t* _class_3f8a;
	Packets_t _class_3f8b;
	class Match
	{
	public:
		SFC::Class class_3f98;
	};

	std::list< Match> _matches;
};

class ComplexStruct1_3f9c
{
public:
	bool operator()( const Packets_t& classs_3f9d, Packets_t& classs_3f9f);

protected:
	bool isInputUnique( const Udm::Object& class_3fa5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_3f9d);
	bool patternMatcher( const Udm::Object& class_3fa3);
	void outputAppender( const SFC::Class& class_3fc1);

private:
	Packets_t* _class_3fa0;
	Packets_t _class_3fa1;
	class Match
	{
	public:
		SFC::Class class_3fbb;
		SFC::Class childClass_3fbc;
		SFC::Class equivClass_3fbd;
		SFC::Struct parentStruct_3fbe;
		SFC::LocalVar localVar_3fbf;
		SFC::Struct childStruct_3fc0;
	};

	std::list< Match> _matches;
};

class ComplexStruct2_3fc3
{
public:
	bool operator()( const Packets_t& classs_3fc4, Packets_t& classs_3fc6);

protected:
	bool isInputUnique( const Udm::Object& class_3fcc);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_3fc4);
	bool patternMatcher( const Udm::Object& class_3fca);
	void outputAppender( const SFC::Class& class_3fe8);

private:
	Packets_t* _class_3fc7;
	Packets_t _class_3fc8;
	class Match
	{
	public:
		SFC::Class class_3fe2;
		SFC::Struct parentStruct_3fe3;
		SFC::Class childClass_3fe4;
		SFC::Class equivClass_3fe5;
		SFC::LocalVar localVar_3fe6;
		SFC::Struct childStruct_3fe7;
	};

	std::list< Match> _matches;
};

class SimpleStruct_3fea
{
public:
	bool operator()( const Packets_t& classs_3feb, Packets_t& classs_3fed);

protected:
	bool isInputUnique( const Udm::Object& class_3ff3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_3feb);
	bool patternMatcher( const Udm::Object& class_3ff1);
	void outputAppender( const SFC::Class& class_3ffd);

private:
	Packets_t* _class_3fee;
	Packets_t _class_3fef;
	class Match
	{
	public:
		SFC::Class class_3ffc;
	};

	std::list< Match> _matches;
};

class GetNextLevelClasses_4001
{
public:
	void operator()( const Packets_t& childClasss_4002, Packets_t& parentClasss_4004);

protected:
	bool isInputUnique( const Udm::Object& childClass_400a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& childClasss_4002);
	bool patternMatcher( const Udm::Object& childClass_4008);
	void effector();
	void outputAppender( const SFC::Class& parentClass_4022);

private:
	Packets_t* _parentClass_4005;
	Packets_t _childClass_4006;
	class Match
	{
	public:
		SFC::Class childClass_401d;
		SFC::Class parentClass_401e;
		SFC::LocalVar member_401f;
		SFC::Struct childStruct_4020;
		SFC::Struct parentStruct_4021;
	};

	std::list< Match> _matches;
};

class MergeClasses_4024
{
public:
	void operator()( const Packets_t& classs_4025, Packets_t& classs_4027);

protected:
	void callTestEquivalence_457e( const Packets_t& classs_402a);
	void callElimEquiv_4580( const Packets_t& classs_42bd);

private:
	Packets_t* _class_4028;
};

class TestEquivalence_4029
{
public:
	void operator()( const Packets_t& classs_402a, Packets_t& classs_402c);

protected:
	void executeOne( const Packets_t& classs_402a);
	bool isInputUnique( const Udm::Object& class_4030);
	void callTestDataMembers_42b8( const Packets_t& classs_4147);
	void callCheckMethods_42ba( const Packets_t& classs_4036);

private:
	Packets_t* _class_402d;
	Packets_t _class_402e;
};

class CheckMethods_4035
{
public:
	void operator()( const Packets_t& classs_4036, Packets_t& classs_4038);

protected:
	void callGetMainFunctionArgs_413c( const Packets_t& class1s_4110);
	void callTestArgs_413e( const Packets_t& class1s_403b, const Packets_t& class2s_403d, const Packets_t& args_403f);
	void callBreakEquivalence_4142( const Packets_t& class1s_40e4, const Packets_t& class2s_40e6, const Packets_t& args_40e8);

private:
	Packets_t* _class_4039;
};

class TestArgs_403a
{
public:
	void operator()( const Packets_t& class1s_403b, const Packets_t& class2s_403d, const Packets_t& args_403f, Packets_t& class1s_4041, Packets_t& class2s_4042, Packets_t& args_4043, Packets_t& class1s_4044, Packets_t& class2s_4045, Packets_t& args_4046);

protected:
	void executeOne( const Packets_t& class1s_403b, const Packets_t& class2s_403d, const Packets_t& args_403f);
	bool isInputUnique( const Udm::Object& class1_404f, const Udm::Object& class2_4056, const Udm::Object& arg_405d);

private:
	Packets_t* _class1_4047;
	Packets_t* _class2_4048;
	Packets_t* _arg_4049;
	Packets_t* _class1_404a;
	Packets_t* _class2_404b;
	Packets_t* _arg_404c;
	Packets_t _class1_404d;
	Packets_t _class2_4054;
	Packets_t _arg_405b;
};

class ArgsMatch_4062
{
public:
	bool operator()( const Packets_t& class1s_4063, const Packets_t& class2s_4066, const Packets_t& arg1s_4069, Packets_t& class1s_4065, Packets_t& class2s_4068, Packets_t& arg1s_406b);

protected:
	bool isInputUnique( const Udm::Object& class1_4073, const Udm::Object& class2_407c, const Udm::Object& arg1_4085);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg1, SFC::Arg& Arg2, SFC::Class& Class1, SFC::Class& Class2, SFC::DT& DT, SFC::Function& MainFunction2);
	void processInputPackets( const Packets_t& class1s_4063, const Packets_t& class2s_4066, const Packets_t& arg1s_4069);
	bool patternMatcher( const Udm::Object& class1_4071, const Udm::Object& class2_407a, const Udm::Object& arg1_4083);
	void outputAppender( const SFC::Class& class1_40a5, const SFC::Class& class2_40a7, const SFC::Arg& arg1_40a9);

private:
	Packets_t* _class1_406c;
	Packets_t* _class2_406d;
	Packets_t* _arg1_406e;
	Packets_t _class1_406f;
	Packets_t _class2_4078;
	Packets_t _arg1_4081;
	class Match
	{
	public:
		SFC::Class class1_4099;
		SFC::Class class2_409a;
		SFC::Arg arg1_409b;
		SFC::Arg arg2_409c;
		SFC::Function mainFunction2_409d;
		SFC::DT dT_409e;
	};

	std::list< Match> _matches;
};

class NoArgMatch_40ab
{
public:
	bool operator()( const Packets_t& class1s_40ac, const Packets_t& class2s_40af, const Packets_t& arg1s_40b2, Packets_t& class1s_40ae, Packets_t& class2s_40b1, Packets_t& arg1s_40b4);

protected:
	bool isInputUnique( const Udm::Object& class1_40bc, const Udm::Object& class2_40c5, const Udm::Object& arg1_40ce);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_40ac, const Packets_t& class2s_40af, const Packets_t& arg1s_40b2);
	bool patternMatcher( const Udm::Object& class1_40ba, const Udm::Object& class2_40c3, const Udm::Object& arg1_40cc);
	void outputAppender( const SFC::Class& class1_40dd, const SFC::Class& class2_40df, const SFC::Arg& arg1_40e1);

private:
	Packets_t* _class1_40b5;
	Packets_t* _class2_40b6;
	Packets_t* _arg1_40b7;
	Packets_t _class1_40b8;
	Packets_t _class2_40c1;
	Packets_t _arg1_40ca;
	class Match
	{
	public:
		SFC::Class class1_40da;
		SFC::Class class2_40db;
		SFC::Arg arg1_40dc;
	};

	std::list< Match> _matches;
};

class BreakEquivalence_40e3
{
public:
	void operator()( const Packets_t& class1s_40e4, const Packets_t& class2s_40e6, const Packets_t& args_40e8);

protected:
	bool isInputUnique( const Udm::Object& class1_40ee, const Udm::Object& class2_40f7, const Udm::Object& arg_4100);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_40e4, const Packets_t& class2s_40e6, const Packets_t& args_40e8);
	bool patternMatcher( const Udm::Object& class1_40ec, const Udm::Object& class2_40f5, const Udm::Object& arg_40fe);
	void effector();

private:
	Packets_t _class1_40ea;
	Packets_t _class2_40f3;
	Packets_t _arg_40fc;
	class Match
	{
	public:
		SFC::Class class1_410c;
		SFC::Class class2_410d;
		SFC::Arg arg_410e;
	};

	std::list< Match> _matches;
};

class GetMainFunctionArgs_410f
{
public:
	void operator()( const Packets_t& class1s_4110, Packets_t& class1s_4112, Packets_t& class2s_4113, Packets_t& args_4114);

protected:
	bool isInputUnique( const Udm::Object& class1_411c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg, SFC::Class& Class1, SFC::Class& Class2, SFC::Function& MainFunction1);
	void processInputPackets( const Packets_t& class1s_4110);
	bool patternMatcher( const Udm::Object& class1_411a);
	void effector();
	void outputAppender( const SFC::Class& class1_4136, const SFC::Class& class2_4138, const SFC::Arg& arg_413a);

private:
	Packets_t* _class1_4115;
	Packets_t* _class2_4116;
	Packets_t* _arg_4117;
	Packets_t _class1_4118;
	class Match
	{
	public:
		SFC::Class class1_412e;
		SFC::Class class2_412f;
		SFC::Arg arg_4130;
		SFC::Function mainFunction1_4131;
	};

	std::list< Match> _matches;
};

class TestDataMembers_4146
{
public:
	void operator()( const Packets_t& classs_4147, Packets_t& classs_4149);

protected:
	void callGetMembers_42ae( const Packets_t& class1s_414c);
	void callTestMembers_42b0( const Packets_t& class1s_4175, const Packets_t& class2s_4177, const Packets_t& members_4179);
	void callBreakEquivalence_42b4( const Packets_t& class1s_4283, const Packets_t& class2s_4285, const Packets_t& localVar1s_4287);

private:
	Packets_t* _class_414a;
};

class GetMembers_414b
{
public:
	void operator()( const Packets_t& class1s_414c, Packets_t& class1s_414e, Packets_t& class2s_414f, Packets_t& localVar1s_4150);

protected:
	bool isInputUnique( const Udm::Object& class1_4158);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_414c);
	bool patternMatcher( const Udm::Object& class1_4156);
	void effector();
	void outputAppender( const SFC::Class& class1_416e, const SFC::Class& class2_4170, const SFC::LocalVar& localVar1_4172);

private:
	Packets_t* _class1_4151;
	Packets_t* _class2_4152;
	Packets_t* _localVar1_4153;
	Packets_t _class1_4154;
	class Match
	{
	public:
		SFC::Class class1_416a;
		SFC::Class class2_416b;
		SFC::LocalVar localVar1_416c;
		SFC::Struct classStruct1_416d;
	};

	std::list< Match> _matches;
};

class TestMembers_4174
{
public:
	void operator()( const Packets_t& class1s_4175, const Packets_t& class2s_4177, const Packets_t& members_4179, Packets_t& class1s_417b, Packets_t& class2s_417c, Packets_t& members_417d, Packets_t& class1s_417e, Packets_t& class2s_417f, Packets_t& members_4180, Packets_t& class1s_4181, Packets_t& class2s_4182, Packets_t& members_4183);

protected:
	void executeOne( const Packets_t& class1s_4175, const Packets_t& class2s_4177, const Packets_t& members_4179);
	bool isInputUnique( const Udm::Object& class1_418f, const Udm::Object& class2_4196, const Udm::Object& member_419d);

private:
	Packets_t* _class1_4184;
	Packets_t* _class2_4185;
	Packets_t* _member_4186;
	Packets_t* _class1_4187;
	Packets_t* _class2_4188;
	Packets_t* _member_4189;
	Packets_t* _class1_418a;
	Packets_t* _class2_418b;
	Packets_t* _member_418c;
	Packets_t _class1_418d;
	Packets_t _class2_4194;
	Packets_t _member_419b;
};

class ParameterMemberMatch_41a2
{
public:
	bool operator()( const Packets_t& class1s_41a3, const Packets_t& class2s_41a6, const Packets_t& localVar1s_41a9, Packets_t& class1s_41a5, Packets_t& class2s_41a8, Packets_t& localVar1s_41ab);

protected:
	bool isInputUnique( const Udm::Object& class1_41b3, const Udm::Object& class2_41bc, const Udm::Object& localVar1_41c5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class1, SFC::Class& Class2, SFC::DT& DT, SFC::LocalVar& LocalVar1, SFC::LocalVar& LocalVar2, ESMoL::Parameter& Parameter1, ESMoL::Parameter& Parameter2, SFC::Struct& Struct2);
	void processInputPackets( const Packets_t& class1s_41a3, const Packets_t& class2s_41a6, const Packets_t& localVar1s_41a9);
	bool patternMatcher( const Udm::Object& class1_41b1, const Udm::Object& class2_41ba, const Udm::Object& localVar1_41c3);
	void outputAppender( const SFC::Class& class1_41ef, const SFC::Class& class2_41f1, const SFC::LocalVar& localVar1_41f3);

private:
	Packets_t* _class1_41ac;
	Packets_t* _class2_41ad;
	Packets_t* _localVar1_41ae;
	Packets_t _class1_41af;
	Packets_t _class2_41b8;
	Packets_t _localVar1_41c1;
	class Match
	{
	public:
		SFC::Class class1_41df;
		SFC::Class class2_41e0;
		SFC::LocalVar localVar1_41e1;
		ESMoL::Parameter parameter2_41e2;
		SFC::Struct struct2_41e3;
		SFC::LocalVar localVar2_41e4;
		SFC::DT dT_41e5;
		ESMoL::Parameter parameter1_41e6;
	};

	std::list< Match> _matches;
};

class StructMemberMatch_41f5
{
public:
	bool operator()( const Packets_t& class1s_41f6, const Packets_t& class2s_41f9, const Packets_t& localVar1s_41fc, Packets_t& class1s_41f8, Packets_t& class2s_41fb, Packets_t& localVar1s_41fe);

protected:
	bool isInputUnique( const Udm::Object& class1_4206, const Udm::Object& class2_420f, const Udm::Object& localVar1_4218);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class, SFC::Class& Class1, SFC::Class& Class2, SFC::LocalVar& LocalVar1, SFC::LocalVar& LocalVar2, SFC::Struct& Struct2, ESMoL::Subsystem& Subsystem1, ESMoL::Subsystem& Subsystem2);
	void processInputPackets( const Packets_t& class1s_41f6, const Packets_t& class2s_41f9, const Packets_t& localVar1s_41fc);
	bool patternMatcher( const Udm::Object& class1_4204, const Udm::Object& class2_420d, const Udm::Object& localVar1_4216);
	void outputAppender( const SFC::Class& class1_4244, const SFC::Class& class2_4246, const SFC::LocalVar& localVar1_4248);

private:
	Packets_t* _class1_41ff;
	Packets_t* _class2_4200;
	Packets_t* _localVar1_4201;
	Packets_t _class1_4202;
	Packets_t _class2_420b;
	Packets_t _localVar1_4214;
	class Match
	{
	public:
		SFC::Class class1_4234;
		SFC::Class class2_4235;
		SFC::LocalVar localVar1_4236;
		SFC::Struct struct2_4237;
		SFC::LocalVar localVar2_4238;
		SFC::Class class_4239;
		ESMoL::Subsystem subsystem1_423a;
		ESMoL::Subsystem subsystem2_423b;
	};

	std::list< Match> _matches;
};

class NoMemberMatch_424a
{
public:
	bool operator()( const Packets_t& class1s_424b, const Packets_t& class2s_424e, const Packets_t& localVar1s_4251, Packets_t& class1s_424d, Packets_t& class2s_4250, Packets_t& localVar1s_4253);

protected:
	bool isInputUnique( const Udm::Object& class1_425b, const Udm::Object& class2_4264, const Udm::Object& localVar1_426d);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_424b, const Packets_t& class2s_424e, const Packets_t& localVar1s_4251);
	bool patternMatcher( const Udm::Object& class1_4259, const Udm::Object& class2_4262, const Udm::Object& localVar1_426b);
	void outputAppender( const SFC::Class& class1_427c, const SFC::Class& class2_427e, const SFC::LocalVar& localVar1_4280);

private:
	Packets_t* _class1_4254;
	Packets_t* _class2_4255;
	Packets_t* _localVar1_4256;
	Packets_t _class1_4257;
	Packets_t _class2_4260;
	Packets_t _localVar1_4269;
	class Match
	{
	public:
		SFC::Class class1_4279;
		SFC::Class class2_427a;
		SFC::LocalVar localVar1_427b;
	};

	std::list< Match> _matches;
};

class BreakEquivalence_4282
{
public:
	void operator()( const Packets_t& class1s_4283, const Packets_t& class2s_4285, const Packets_t& localVar1s_4287);

protected:
	bool isInputUnique( const Udm::Object& class1_428d, const Udm::Object& class2_4296, const Udm::Object& localVar1_429f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_4283, const Packets_t& class2s_4285, const Packets_t& localVar1s_4287);
	bool patternMatcher( const Udm::Object& class1_428b, const Udm::Object& class2_4294, const Udm::Object& localVar1_429d);
	void effector();

private:
	Packets_t _class1_4289;
	Packets_t _class2_4292;
	Packets_t _localVar1_429b;
	class Match
	{
	public:
		SFC::Class class1_42ab;
		SFC::Class class2_42ac;
		SFC::LocalVar localVar1_42ad;
	};

	std::list< Match> _matches;
};

class ElimEquiv_42bc
{
public:
	void operator()( const Packets_t& classs_42bd);

protected:
	void executeOne( const Packets_t& classs_42bd);
	bool isInputUnique( const Udm::Object& class_42c1);
	void callGetEquivalence_4571( const Packets_t& class1s_4555);
	void callTransferSubsystems_4573( const Packets_t& class1s_4528, const Packets_t& class2s_452a);
	void callTransferMethodCalls_4576( const Packets_t& class1s_430f, const Packets_t& class2s_4311);
	void callTransferStruct_4579( const Packets_t& class1s_43bd, const Packets_t& class2s_43bf);
	void callDeleteClass_457c( const Packets_t& deleteClasss_42c7);

private:
	Packets_t _class_42bf;
};

class DeleteClass_42c6
{
public:
	void operator()( const Packets_t& deleteClasss_42c7);

protected:
	void callmarkClass_4308( const Packets_t& classs_42f6);
	void callnoEquivDst_430a( const Packets_t& class2s_42df);
	void callnoEquivSrc_430c( const Packets_t& class1s_42ca);
};

class NoEquivSrc_42c9
{
public:
	void operator()( const Packets_t& class1s_42ca);

protected:
	bool isInputUnique( const Udm::Object& class1_42d0);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_42ca);
	bool patternMatcher( const Udm::Object& class1_42ce);
	void effector();

private:
	Packets_t _class1_42cc;
	class Match
	{
	public:
		SFC::Class class1_42dc;
		SFC::Class class2_42dd;
	};

	std::list< Match> _matches;
};

class NoEquivDst_42de
{
public:
	void operator()( const Packets_t& class2s_42df, Packets_t& class2s_42e1);

protected:
	bool isInputUnique( const Udm::Object& class2_42e7);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class2s_42df);
	bool patternMatcher( const Udm::Object& class2_42e5);
	void effector();
	void forwardInputs();

private:
	Packets_t* _class2_42e2;
	Packets_t _class2_42e3;
	class Match
	{
	public:
		SFC::Class class2_42f3;
		SFC::Class class1_42f4;
	};

	std::list< Match> _matches;
};

class MarkClass_42f5
{
public:
	void operator()( const Packets_t& classs_42f6, Packets_t& classs_42f8);

protected:
	bool isInputUnique( const Udm::Object& class_42fe);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& classs_42f6);
	bool patternMatcher( const Udm::Object& class_42fc);
	void effector();
	void forwardInputs();

private:
	Packets_t* _class_42f9;
	Packets_t _class_42fa;
	class Match
	{
	public:
		SFC::Class class_4307;
	};

	std::list< Match> _matches;
};

class TransferMethodCalls_430e
{
public:
	void operator()( const Packets_t& class1s_430f, const Packets_t& class2s_4311, Packets_t& class1s_4313, Packets_t& class2s_4314);

protected:
	void callGetMethods_43b6( const Packets_t& class1s_4387, const Packets_t& class2s_438a);
	void callTransferMethodCalls_43b9( const Packets_t& method1s_4318, const Packets_t& method2s_431a);

private:
	Packets_t* _class1_4315;
	Packets_t* _class2_4316;
};

class TransferMethodCalls_4317
{
public:
	void operator()( const Packets_t& method1s_4318, const Packets_t& method2s_431a);

protected:
	void callTransferMethodCallArgs_437f( const Packets_t& method1s_431d, const Packets_t& method2s_431f);
	void callTransferMethodCallTarget_4382( const Packets_t& method1s_435f, const Packets_t& method2s_4361);
};

class TransferMethodCallArgs_431c
{
public:
	void operator()( const Packets_t& method1s_431d, const Packets_t& method2s_431f, Packets_t& method1s_4321, Packets_t& method2s_4322);

protected:
	void callTransferMethodCallArgs_435b( const Packets_t& method1s_4326, const Packets_t& method2s_4328);

private:
	Packets_t* _method1_4323;
	Packets_t* _method2_4324;
};

class TransferMethodCallArgs_4325
{
public:
	void operator()( const Packets_t& method1s_4326, const Packets_t& method2s_4328);

protected:
	bool isInputUnique( const Udm::Object& method1_432e, const Udm::Object& method2_4337);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Arg& Arg1, SFC::Arg& Arg2, SFC::ArgVal& ArgVal, SFC::Function& Method1, SFC::Function& Method2, SFC::FunctionCall& MethodCall2);
	void processInputPackets( const Packets_t& method1s_4326, const Packets_t& method2s_4328);
	bool patternMatcher( const Udm::Object& method1_432c, const Udm::Object& method2_4335);
	void effector();

private:
	Packets_t _method1_432a;
	Packets_t _method2_4333;
	class Match
	{
	public:
		SFC::Function method1_434f;
		SFC::Function method2_4350;
		SFC::Arg arg1_4351;
		SFC::FunctionCall methodCall2_4352;
		SFC::ArgVal argVal_4353;
		SFC::Arg arg2_4354;
	};

	std::list< Match> _matches;
};

class TransferMethodCallTarget_435e
{
public:
	void operator()( const Packets_t& method1s_435f, const Packets_t& method2s_4361);

protected:
	bool isInputUnique( const Udm::Object& method1_4367, const Udm::Object& method2_4370);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& method1s_435f, const Packets_t& method2s_4361);
	bool patternMatcher( const Udm::Object& method1_4365, const Udm::Object& method2_436e);
	void effector();

private:
	Packets_t _method1_4363;
	Packets_t _method2_436c;
	class Match
	{
	public:
		SFC::Function method1_437c;
		SFC::Function method2_437d;
		SFC::FunctionCall methodCall2_437e;
	};

	std::list< Match> _matches;
};

class GetMethods_4385
{
public:
	void operator()( const Packets_t& class1s_4387, const Packets_t& class2s_438a, Packets_t& method1s_4386, Packets_t& method2s_4389);

protected:
	bool isInputUnique( const Udm::Object& class1_4392, const Udm::Object& class2_439b);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class1, SFC::Class& Class2, SFC::Function& Method1, SFC::Function& Method2);
	void processInputPackets( const Packets_t& class1s_4387, const Packets_t& class2s_438a);
	bool patternMatcher( const Udm::Object& class1_4390, const Udm::Object& class2_4399);
	void effector();
	void outputAppender( const SFC::Function& method1_43b2, const SFC::Function& method2_43b4);

private:
	Packets_t* _method1_438c;
	Packets_t* _method2_438d;
	Packets_t _class1_438e;
	Packets_t _class2_4397;
	class Match
	{
	public:
		SFC::Class class1_43aa;
		SFC::Class class2_43ab;
		SFC::Function method1_43ac;
		SFC::Function method2_43ad;
	};

	std::list< Match> _matches;
};

class TransferStruct_43bc
{
public:
	void operator()( const Packets_t& class1s_43bd, const Packets_t& class2s_43bf, Packets_t& deleteclasss_43c1);

protected:
	void callTransferStructMembers_4521( const Packets_t& class1s_43c4, const Packets_t& class2s_43c6);
	void callTransferStruct_4524( const Packets_t& class1s_44f9, const Packets_t& class2s_44fb);

private:
	Packets_t* _deleteclass_43c2;
};

class TransferStructMembers_43c3
{
public:
	void operator()( const Packets_t& class1s_43c4, const Packets_t& class2s_43c6, Packets_t& class1s_43c8, Packets_t& class2s_43c9);

protected:
	void callTransferParameterMembers_44ef( const Packets_t& class1s_43cd, const Packets_t& class2s_43cf);
	void callTransferTriggerMembers_44f2( const Packets_t& class1s_449c, const Packets_t& class2s_449e);
	void callTransferStructMembers_44f5( const Packets_t& class1s_4442, const Packets_t& class2s_4444);

private:
	Packets_t* _class1_43ca;
	Packets_t* _class2_43cb;
};

class TransferParameterMembers_43cc
{
public:
	void operator()( const Packets_t& class1s_43cd, const Packets_t& class2s_43cf, Packets_t& class1s_43d1, Packets_t& class2s_43d2);

protected:
	void callTransferParameterMember_443b( const Packets_t& class1s_43f7, const Packets_t& class2s_43fa);
	void callTransferArgDeclRef_443e( const Packets_t& localVar1s_43d6, const Packets_t& localVar2s_43d8);

private:
	Packets_t* _class1_43d3;
	Packets_t* _class2_43d4;
};

class TransferArgDeclRef_43d5
{
public:
	void operator()( const Packets_t& localVar1s_43d6, const Packets_t& localVar2s_43d8);

protected:
	bool isInputUnique( const Udm::Object& localVar1_43de, const Udm::Object& localVar2_43e7);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& localVar1s_43d6, const Packets_t& localVar2s_43d8);
	bool patternMatcher( const Udm::Object& localVar1_43dc, const Udm::Object& localVar2_43e5);
	void effector();

private:
	Packets_t _localVar1_43da;
	Packets_t _localVar2_43e3;
	class Match
	{
	public:
		SFC::LocalVar localVar1_43f3;
		SFC::LocalVar localVar2_43f4;
		SFC::ArgDeclRef argDeclRef_43f5;
	};

	std::list< Match> _matches;
};

class TransferParameterMember_43f6
{
public:
	void operator()( const Packets_t& class1s_43f7, const Packets_t& class2s_43fa, Packets_t& localVar1s_43f9, Packets_t& localVar2s_43fc);

protected:
	bool isInputUnique( const Udm::Object& class1_4403, const Udm::Object& class2_440c);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class1, SFC::Class& Class2, SFC::LocalVar& LocalVar1, SFC::LocalVar& LocalVar2, ESMoL::Parameter& Parameter1, ESMoL::Parameter& Parameter2, SFC::Struct& Struct1, SFC::Struct& Struct2);
	void processInputPackets( const Packets_t& class1s_43f7, const Packets_t& class2s_43fa);
	bool patternMatcher( const Udm::Object& class1_4401, const Udm::Object& class2_440a);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar1_4437, const SFC::LocalVar& localVar2_4439);

private:
	Packets_t* _localVar1_43fd;
	Packets_t* _localVar2_43fe;
	Packets_t _class1_43ff;
	Packets_t _class2_4408;
	class Match
	{
	public:
		SFC::Class class1_4427;
		SFC::Class class2_4428;
		SFC::Struct struct1_4429;
		SFC::LocalVar localVar1_442a;
		ESMoL::Parameter parameter1_442b;
		ESMoL::Parameter parameter2_442c;
		SFC::Struct struct2_442d;
		SFC::LocalVar localVar2_442e;
	};

	std::list< Match> _matches;
};

class TransferStructMembers_4441
{
public:
	void operator()( const Packets_t& class1s_4442, const Packets_t& class2s_4444, Packets_t& class1s_4446, Packets_t& class2s_4447);

protected:
	void callTransferStructMember_4495( const Packets_t& class1s_444b, const Packets_t& class2s_444e);
	void callTransferArgDeclRef_4498( const Packets_t& localVar1s_43d6, const Packets_t& localVar2s_43d8);

private:
	Packets_t* _class1_4448;
	Packets_t* _class2_4449;
};

class TransferStructMember_444a
{
public:
	void operator()( const Packets_t& class1s_444b, const Packets_t& class2s_444e, Packets_t& localVar1s_444d, Packets_t& localVar2s_4450);

protected:
	bool isInputUnique( const Udm::Object& class1_4457, const Udm::Object& class2_4460);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class, SFC::Class& Class1, SFC::Class& Class2, SFC::LocalVar& LocalVar1, SFC::LocalVar& LocalVar2, SFC::Struct& Struct1, SFC::Struct& Struct2, ESMoL::Subsystem& SubSubsystem1, ESMoL::Subsystem& SubSubsystem2);
	void processInputPackets( const Packets_t& class1s_444b, const Packets_t& class2s_444e);
	bool patternMatcher( const Udm::Object& class1_4455, const Udm::Object& class2_445e);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar1_4491, const SFC::LocalVar& localVar2_4493);

private:
	Packets_t* _localVar1_4451;
	Packets_t* _localVar2_4452;
	Packets_t _class1_4453;
	Packets_t _class2_445c;
	class Match
	{
	public:
		SFC::Class class1_447f;
		SFC::Class class2_4480;
		SFC::Struct struct1_4481;
		SFC::LocalVar localVar1_4482;
		ESMoL::Subsystem subSubsystem1_4483;
		SFC::Class class_4484;
		ESMoL::Subsystem subSubsystem2_4485;
		SFC::Struct struct2_4486;
		SFC::LocalVar localVar2_4487;
	};

	std::list< Match> _matches;
};

class TransferTriggerMembers_449b
{
public:
	void operator()( const Packets_t& class1s_449c, const Packets_t& class2s_449e, Packets_t& class1s_44a0, Packets_t& class2s_44a1);

protected:
	void callTransferTriggerMember_44e9( const Packets_t& class1s_44a5, const Packets_t& class2s_44a8);
	void callTransferArgDeclRef_44ec( const Packets_t& localVar1s_43d6, const Packets_t& localVar2s_43d8);

private:
	Packets_t* _class1_44a2;
	Packets_t* _class2_44a3;
};

class TransferTriggerMember_44a4
{
public:
	void operator()( const Packets_t& class1s_44a5, const Packets_t& class2s_44a8, Packets_t& localVar1s_44a7, Packets_t& localVar2s_44aa);

protected:
	bool isInputUnique( const Udm::Object& class1_44b1, const Udm::Object& class2_44ba);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class1, SFC::Class& Class2, SFC::LocalVar& LocalVar1, SFC::LocalVar& LocalVar2, SFC::Struct& Struct1, SFC::Struct& Struct2, ESMoL::TriggerPort& TriggerPort1, ESMoL::TriggerPort& TriggerPort2);
	void processInputPackets( const Packets_t& class1s_44a5, const Packets_t& class2s_44a8);
	bool patternMatcher( const Udm::Object& class1_44af, const Udm::Object& class2_44b8);
	void effector();
	void outputAppender( const SFC::LocalVar& localVar1_44e5, const SFC::LocalVar& localVar2_44e7);

private:
	Packets_t* _localVar1_44ab;
	Packets_t* _localVar2_44ac;
	Packets_t _class1_44ad;
	Packets_t _class2_44b6;
	class Match
	{
	public:
		SFC::Class class1_44d5;
		SFC::Class class2_44d6;
		SFC::Struct struct1_44d7;
		SFC::LocalVar localVar1_44d8;
		ESMoL::TriggerPort triggerPort2_44d9;
		ESMoL::TriggerPort triggerPort1_44da;
		SFC::Struct struct2_44db;
		SFC::LocalVar localVar2_44dc;
	};

	std::list< Match> _matches;
};

class TransferStruct_44f8
{
public:
	void operator()( const Packets_t& class1s_44f9, const Packets_t& class2s_44fb);

protected:
	bool isInputUnique( const Udm::Object& class1_4501, const Udm::Object& class2_450a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_44f9, const Packets_t& class2s_44fb);
	bool patternMatcher( const Udm::Object& class1_44ff, const Udm::Object& class2_4508);
	void effector();

private:
	Packets_t _class1_44fd;
	Packets_t _class2_4506;
	class Match
	{
	public:
		SFC::Class class1_451c;
		SFC::Class class2_451d;
		SFC::Struct struct1_451e;
		SFC::ArgDeclBase argDeclBase_451f;
		SFC::Struct struct2_4520;
	};

	std::list< Match> _matches;
};

class TransferSubsystems_4527
{
public:
	void operator()( const Packets_t& class1s_4528, const Packets_t& class2s_452a, Packets_t& class1s_452c, Packets_t& class2s_452d);

protected:
	void callTransferSubsystem_4551( const Packets_t& class1s_4531, const Packets_t& class2s_4533);

private:
	Packets_t* _class1_452e;
	Packets_t* _class2_452f;
};

class TransferSubsystem_4530
{
public:
	void operator()( const Packets_t& class1s_4531, const Packets_t& class2s_4533);

protected:
	bool isInputUnique( const Udm::Object& class1_4539, const Udm::Object& class2_4542);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_4531, const Packets_t& class2s_4533);
	bool patternMatcher( const Udm::Object& class1_4537, const Udm::Object& class2_4540);
	void effector();

private:
	Packets_t _class1_4535;
	Packets_t _class2_453e;
	class Match
	{
	public:
		SFC::Class class1_454e;
		SFC::Class class2_454f;
		ESMoL::Subsystem subsystem_4550;
	};

	std::list< Match> _matches;
};

class GetEquivalence_4554
{
public:
	void operator()( const Packets_t& class1s_4555, Packets_t& class1s_4557, Packets_t& class2s_4558);

protected:
	bool isInputUnique( const Udm::Object& class1_455f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& class1s_4555);
	bool patternMatcher( const Udm::Object& class1_455d);
	void effector();
	void outputAppender( const SFC::Class& class1_456d, const SFC::Class& class2_456f);

private:
	Packets_t* _class1_4559;
	Packets_t* _class2_455a;
	Packets_t _class1_455b;
	class Match
	{
	public:
		SFC::Class class1_456b;
		SFC::Class class2_456c;
	};

	std::list< Match> _matches;
};

class GetClasses_458a
{
public:
	void operator()( const Packets_t& projects_458c, Packets_t& classs_458b);

protected:
	bool isInputUnique( const Udm::Object& project_4593);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& projects_458c);
	bool patternMatcher( const Udm::Object& project_4591);
	void effector();
	void outputAppender( const SFC::Class& class_45a5);

private:
	Packets_t* _class_458e;
	Packets_t _project_458f;
	class Match
	{
	public:
		SFC::Project project_45a2;
		SFC::Program program_45a3;
		SFC::Class class_45a4;
	};

	std::list< Match> _matches;
};

class MakeEquivalence_45a7
{
public:
	void operator()( const Packets_t& projects_45a8, Packets_t& projects_45aa);

protected:
	bool isInputUnique( const Udm::Object& project_45b0);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Class& Class1, SFC::Class& Class2, SFC::Program& Program, SFC::Project& Project, ESMoL::Subsystem& Subsystem1, ESMoL::Subsystem& Subsystem2);
	void processInputPackets( const Packets_t& projects_45a8);
	bool patternMatcher( const Udm::Object& project_45ae);
	void effector();
	void forwardInputs();

private:
	Packets_t* _project_45ab;
	Packets_t _project_45ac;
	class Match
	{
	public:
		SFC::Project project_45c8;
		SFC::Program program_45c9;
		SFC::Class class1_45ca;
		SFC::Class class2_45cb;
		ESMoL::Subsystem subsystem1_45cc;
		ESMoL::Subsystem subsystem2_45cd;
	};

	std::list< Match> _matches;
};

class CreateTypes_45de
{
public:
	void operator()( const Packets_t& dataflows_45df, const Packets_t& projects_45e1, Packets_t& dataflows_45e3, Packets_t& projects_45e4);

protected:
	void callGetTypes_4c1c( const Packets_t& states_45e8, const Packets_t& projects_45ea);
	void callCreateTypesInner_4c1f( const Packets_t& typess_4729, const Packets_t& projects_472b);
	void callStructMembers_4c22( const Packets_t& typess_46f9, const Packets_t& newStructs_46fb);
	void callRegisterStruct_4c25( const Packets_t& sfcStructs_46e8);

private:
	Packets_t* _dataflow_45e5;
	Packets_t* _project_45e6;
};

class GetTypes_45e7
{
public:
	void operator()( const Packets_t& states_45e8, const Packets_t& projects_45ea, Packets_t& typess_45ec, Packets_t& projects_45ed);

protected:
	void callGetContainer_46db( const Packets_t& dataflows_4621, const Packets_t& projects_4624);
	void callFindTopContainer_46de( const Packets_t& containers_4674, const Packets_t& projects_4676);
	void callGetTypes_46e1( const Packets_t& designFolders_45f1, const Packets_t& projects_45f4);
	void callNextContainer_46e4( const Packets_t& designFolders_464d, const Packets_t& projects_464f);

private:
	Packets_t* _types_45ee;
	Packets_t* _project_45ef;
};

class GetTypes_45f0
{
public:
	void operator()( const Packets_t& designFolders_45f1, const Packets_t& projects_45f4, Packets_t& typeBases_45f3, Packets_t& projects_45f6);

protected:
	bool isInputUnique( const Udm::Object& designFolder_45fd, const Udm::Object& project_4606);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& designFolders_45f1, const Packets_t& projects_45f4);
	bool patternMatcher( const Udm::Object& designFolder_45fb, const Udm::Object& project_4604);
	void effector();
	void outputAppender( const ESMoL::TypeBase& typeBase_461c, const SFC::Project& project_461e);

private:
	Packets_t* _typeBase_45f7;
	Packets_t* _project_45f8;
	Packets_t _designFolder_45f9;
	Packets_t _project_4602;
	class Match
	{
	public:
		ESMoL::DesignFolder designFolder_4617;
		SFC::Project project_4618;
		ESMoL::RootFolder rootFolder_4619;
		ESMoL::Types types_461a;
		ESMoL::TypeBase typeBase_461b;
	};

	std::list< Match> _matches;
};

class GetContainer_4620
{
public:
	void operator()( const Packets_t& dataflows_4621, const Packets_t& projects_4624, Packets_t& designFolders_4623, Packets_t& projects_4626);

protected:
	bool isInputUnique( const Udm::Object& dataflow_462d, const Udm::Object& project_4636);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_4621, const Packets_t& projects_4624);
	bool patternMatcher( const Udm::Object& dataflow_462b, const Udm::Object& project_4634);
	void effector();
	void outputAppender( const ESMoL::DesignFolder& designFolder_4647, const SFC::Project& project_4649);

private:
	Packets_t* _designFolder_4627;
	Packets_t* _project_4628;
	Packets_t _dataflow_4629;
	Packets_t _project_4632;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_4643;
		SFC::Project project_4644;
		ESMoL::ModelsFolder modelsFolder_4645;
		ESMoL::DesignFolder designFolder_4646;
	};

	std::list< Match> _matches;
};

class NextContainer_464b
{
public:
	void operator()( const Packets_t& designFolders_464d, const Packets_t& projects_464f, Packets_t& designFolders_464c, Packets_t& projects_4651);

protected:
	bool isInputUnique( const Udm::Object& designFolder_4658, const Udm::Object& project_4661);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& designFolders_464d, const Packets_t& projects_464f);
	bool patternMatcher( const Udm::Object& designFolder_4656, const Udm::Object& project_465f);
	void effector();
	void outputAppender( const ESMoL::DesignFolder& designFolder_466f, const SFC::Project& project_4671);

private:
	Packets_t* _designFolder_4652;
	Packets_t* _project_4653;
	Packets_t _designFolder_4654;
	Packets_t _project_465d;
	class Match
	{
	public:
		ESMoL::DesignFolder designFolder_466c;
		SFC::Project project_466d;
		ESMoL::DesignFolder designFolder_466e;
	};

	std::list< Match> _matches;
};

class FindTopContainer_4673
{
public:
	void operator()( const Packets_t& containers_4674, const Packets_t& projects_4676, Packets_t& containers_4678, Packets_t& projects_4679, Packets_t& containers_467a, Packets_t& projects_467b);

protected:
	void executeOne( const Packets_t& containers_4674, const Packets_t& projects_4676);
	bool isInputUnique( const Udm::Object& container_4682, const Udm::Object& project_4689);

private:
	Packets_t* _container_467c;
	Packets_t* _project_467d;
	Packets_t* _container_467e;
	Packets_t* _project_467f;
	Packets_t _container_4680;
	Packets_t _project_4687;
};

class ChildOfComponent_468e
{
public:
	bool operator()( const Packets_t& designFolders_468f, const Packets_t& projects_4692, Packets_t& designFolders_4691, Packets_t& projects_4694);

protected:
	bool isInputUnique( const Udm::Object& designFolder_469b, const Udm::Object& project_46a4);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& designFolders_468f, const Packets_t& projects_4692);
	bool patternMatcher( const Udm::Object& designFolder_4699, const Udm::Object& project_46a2);
	void outputAppender( const ESMoL::DesignFolder& designFolder_46b2, const SFC::Project& project_46b4);

private:
	Packets_t* _designFolder_4695;
	Packets_t* _project_4696;
	Packets_t _designFolder_4697;
	Packets_t _project_46a0;
	class Match
	{
	public:
		ESMoL::DesignFolder designFolder_46af;
		SFC::Project project_46b0;
		ESMoL::RootFolder rootFolder_46b1;
	};

	std::list< Match> _matches;
};

class Otherwise_46b6
{
public:
	bool operator()( const Packets_t& designFolders_46b7, const Packets_t& projects_46ba, Packets_t& designFolders_46b9, Packets_t& projects_46bc);

protected:
	bool isInputUnique( const Udm::Object& designFolder_46c3, const Udm::Object& project_46cc);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& designFolders_46b7, const Packets_t& projects_46ba);
	bool patternMatcher( const Udm::Object& designFolder_46c1, const Udm::Object& project_46ca);
	void outputAppender( const ESMoL::DesignFolder& designFolder_46d7, const SFC::Project& project_46d9);

private:
	Packets_t* _designFolder_46bd;
	Packets_t* _project_46be;
	Packets_t _designFolder_46bf;
	Packets_t _project_46c8;
	class Match
	{
	public:
		ESMoL::DesignFolder designFolder_46d5;
		SFC::Project project_46d6;
	};

	std::list< Match> _matches;
};

class RegisterStruct_46e7
{
public:
	void operator()( const Packets_t& sfcStructs_46e8);

protected:
	bool isInputUnique( const Udm::Object& sfcStruct_46ee);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& sfcStructs_46e8);
	bool patternMatcher( const Udm::Object& sfcStruct_46ec);
	void effector();

private:
	Packets_t _sfcStruct_46ea;
	class Match
	{
	public:
		SFC::Struct sfcStruct_46f7;
	};

	std::list< Match> _matches;
};

class StructMembers_46f8
{
public:
	void operator()( const Packets_t& typess_46f9, const Packets_t& newStructs_46fb, Packets_t& newStructs_46fd);

protected:
	void callCreateStructMembers_4725( const Packets_t& eSMoL_Structs_4700, const Packets_t& sfc_Structs_4702);

private:
	Packets_t* _newStruct_46fe;
};

class CreateStructMembers_46ff
{
public:
	void operator()( const Packets_t& eSMoL_Structs_4700, const Packets_t& sfc_Structs_4702);

protected:
	bool isInputUnique( const Udm::Object& eSMoL_Struct_4708, const Udm::Object& sfc_Struct_4711);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& eSMoL_Structs_4700, const Packets_t& sfc_Structs_4702);
	bool patternMatcher( const Udm::Object& eSMoL_Struct_4706, const Udm::Object& sfc_Struct_470f);
	void effector();

private:
	Packets_t _eSMoL_Struct_4704;
	Packets_t _sfc_Struct_470d;
	class Match
	{
	public:
		ESMoL::TypeStruct eSMoL_Struct_471f;
		SFC::Struct sfc_Struct_4720;
		ESMoL::TypeBaseRef eSMoL_StructRef_4721;
		ESMoL::TypeBase eSMoL_TypeBase_4722;
		SFC::DT sfc_DT_4723;
	};

	std::list< Match> _matches;
};

class CreateTypesInner_4728
{
public:
	void operator()( const Packets_t& typess_4729, const Packets_t& projects_472b, Packets_t& typess_472d, Packets_t& newStructs_472e);

protected:
	void executeOne( const Packets_t& typess_4729, const Packets_t& projects_472b);
	bool isInputUnique( const Udm::Object& types_4733, const Udm::Object& project_473a);
	void callStructOrMatrix_4c13( const Packets_t& typess_4b89, const Packets_t& projects_4b8b);
	void callCreateStructType_4c16( const Packets_t& eSMoL_Structs_4bee, const Packets_t& projects_4bf2);
	void callCreateArrayOrBasicType_4c19( const Packets_t& typess_4740, const Packets_t& projects_4742);

private:
	Packets_t* _types_472f;
	Packets_t* _newStruct_4730;
	Packets_t _types_4731;
	Packets_t _project_4738;
};

class CreateArrayOrBasicType_473f
{
public:
	void operator()( const Packets_t& typess_4740, const Packets_t& projects_4742);

protected:
	void callDimensionTest_4b76( const Packets_t& typess_4ae5, const Packets_t& projects_4ae7);
	void callProcessOther_4b79( const Packets_t& typess_4783, const Packets_t& projects_4785);
	void callProcessColumn_4b7c( const Packets_t& typess_4ad3, const Packets_t& projects_4ad5);
	void callProcessScalar_4b7f( const Packets_t& typess_48c3, const Packets_t& projects_48c5);
	void callRegisterType_4b82( const Packets_t& matrixs_4745, const Packets_t& dTs_4748);
	void callMakeAssoc_4b85( const Packets_t& matrixs_4766, const Packets_t& dTs_4768);
};

class RegisterType_4744
{
public:
	void operator()( const Packets_t& matrixs_4745, const Packets_t& dTs_4748, Packets_t& matrixs_4747, Packets_t& dTs_474a);

protected:
	bool isInputUnique( const Udm::Object& matrix_4751, const Udm::Object& dT_475a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_4745, const Packets_t& dTs_4748);
	bool patternMatcher( const Udm::Object& matrix_474f, const Udm::Object& dT_4758);
	void effector();
	void forwardInputs();

private:
	Packets_t* _matrix_474b;
	Packets_t* _dT_474c;
	Packets_t _matrix_474d;
	Packets_t _dT_4756;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4763;
		SFC::DT dT_4764;
	};

	std::list< Match> _matches;
};

class MakeAssoc_4765
{
public:
	void operator()( const Packets_t& matrixs_4766, const Packets_t& dTs_4768);

protected:
	bool isInputUnique( const Udm::Object& matrix_476e, const Udm::Object& dT_4777);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_4766, const Packets_t& dTs_4768);
	bool patternMatcher( const Udm::Object& matrix_476c, const Udm::Object& dT_4775);
	void effector();

private:
	Packets_t _matrix_476a;
	Packets_t _dT_4773;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4780;
		SFC::DT dT_4781;
	};

	std::list< Match> _matches;
};

class ProcessOther_4782
{
public:
	void operator()( const Packets_t& typess_4783, const Packets_t& projects_4785, Packets_t& typess_4787, Packets_t& array1s_4788, Packets_t& projects_4789);

protected:
	void callProcessRowVector_4acb( const Packets_t& typess_478e, const Packets_t& projects_4790);
	void callProcessArray1_4ace( const Packets_t& typess_49a4, const Packets_t& basictypes_49a6, const Packets_t& projects_49a8);

private:
	Packets_t* _types_478a;
	Packets_t* _array1_478b;
	Packets_t* _project_478c;
};

class ProcessRowVector_478d
{
public:
	void operator()( const Packets_t& typess_478e, const Packets_t& projects_4790, Packets_t& typess_4792, Packets_t& array2s_4793, Packets_t& projectss_4794);

protected:
	void callProcessScalar_499c( const Packets_t& typess_48c3, const Packets_t& projects_48c5);
	void callProcessArray2_499f( const Packets_t& typess_4799, const Packets_t& basictypes_479b, const Packets_t& projects_479d);

private:
	Packets_t* _types_4795;
	Packets_t* _array2_4796;
	Packets_t* _projects_4797;
};

class ProcessArray2_4798
{
public:
	void operator()( const Packets_t& typess_4799, const Packets_t& basictypes_479b, const Packets_t& projects_479d, Packets_t& typess_479f, Packets_t& array2s_47a0, Packets_t& projectss_47a1);

protected:
	void callGetArray2_48b6( const Packets_t& typess_47a6, const Packets_t& basictypes_47a8, const Packets_t& projects_47aa);
	void callUseArray2_48ba( const Packets_t& matrixs_4842, const Packets_t& basicTypes_4846, const Packets_t& projects_4848);
	void callCreateArray2_48be( const Packets_t& matrixs_4881, const Packets_t& basicTypes_4885, const Packets_t& projects_4887);

private:
	Packets_t* _types_47a2;
	Packets_t* _array2_47a3;
	Packets_t* _projects_47a4;
};

class GetArray2_47a5
{
public:
	void operator()( const Packets_t& typess_47a6, const Packets_t& basictypes_47a8, const Packets_t& projects_47aa, Packets_t& typess_47ac, Packets_t& basictypes_47ad, Packets_t& projectss_47ae, Packets_t& typess_47af, Packets_t& basictypes_47b0, Packets_t& projectss_47b1);

protected:
	void executeOne( const Packets_t& typess_47a6, const Packets_t& basictypes_47a8, const Packets_t& projects_47aa);
	bool isInputUnique( const Udm::Object& types_47ba, const Udm::Object& basictype_47c1, const Udm::Object& project_47c8);

private:
	Packets_t* _types_47b2;
	Packets_t* _basictype_47b3;
	Packets_t* _projects_47b4;
	Packets_t* _types_47b5;
	Packets_t* _basictype_47b6;
	Packets_t* _projects_47b7;
	Packets_t _types_47b8;
	Packets_t _basictype_47bf;
	Packets_t _project_47c6;
};

class Array2Exists_47cd
{
public:
	bool operator()( const Packets_t& matrixs_47ce, const Packets_t& basicTypes_47d1, const Packets_t& projects_47d4, Packets_t& matrixs_47d0, Packets_t& basicTypes_47d3, Packets_t& projects_47d6);

protected:
	bool isInputUnique( const Udm::Object& matrix_47de, const Udm::Object& basicType_47e7, const Udm::Object& project_47f0);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Array& Array, SFC::BasicType& BasicType, ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_47ce, const Packets_t& basicTypes_47d1, const Packets_t& projects_47d4);
	bool patternMatcher( const Udm::Object& matrix_47dc, const Udm::Object& basicType_47e5, const Udm::Object& project_47ee);
	void outputAppender( const ESMoL::Matrix& matrix_4806, const SFC::BasicType& basicType_4808, const SFC::Project& project_480a);

private:
	Packets_t* _matrix_47d7;
	Packets_t* _basicType_47d8;
	Packets_t* _project_47d9;
	Packets_t _matrix_47da;
	Packets_t _basicType_47e3;
	Packets_t _project_47ec;
	class Match
	{
	public:
		ESMoL::Matrix matrix_47fe;
		SFC::BasicType basicType_47ff;
		SFC::Project project_4800;
		SFC::Array array_4801;
	};

	std::list< Match> _matches;
};

class Otherwise_480c
{
public:
	bool operator()( const Packets_t& matrixs_480d, const Packets_t& basicTypes_4810, const Packets_t& projects_4813, Packets_t& matrixs_480f, Packets_t& basicTypes_4812, Packets_t& projects_4815);

protected:
	bool isInputUnique( const Udm::Object& matrix_481d, const Udm::Object& basicType_4826, const Udm::Object& project_482f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_480d, const Packets_t& basicTypes_4810, const Packets_t& projects_4813);
	bool patternMatcher( const Udm::Object& matrix_481b, const Udm::Object& basicType_4824, const Udm::Object& project_482d);
	void outputAppender( const ESMoL::Matrix& matrix_483b, const SFC::BasicType& basicType_483d, const SFC::Project& project_483f);

private:
	Packets_t* _matrix_4816;
	Packets_t* _basicType_4817;
	Packets_t* _project_4818;
	Packets_t _matrix_4819;
	Packets_t _basicType_4822;
	Packets_t _project_482b;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4838;
		SFC::BasicType basicType_4839;
		SFC::Project project_483a;
	};

	std::list< Match> _matches;
};

class UseArray2_4841
{
public:
	void operator()( const Packets_t& matrixs_4842, const Packets_t& basicTypes_4846, const Packets_t& projects_4848, Packets_t& matrixs_4844, Packets_t& arrays_4845, Packets_t& projects_484a);

protected:
	bool isInputUnique( const Udm::Object& matrix_4852, const Udm::Object& basicType_485b, const Udm::Object& project_4864);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Array& Array, SFC::BasicType& BasicType, ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_4842, const Packets_t& basicTypes_4846, const Packets_t& projects_4848);
	bool patternMatcher( const Udm::Object& matrix_4850, const Udm::Object& basicType_4859, const Udm::Object& project_4862);
	void effector();
	void outputAppender( const ESMoL::Matrix& matrix_487a, const SFC::Array& array_487c, const SFC::Project& project_487e);

private:
	Packets_t* _matrix_484b;
	Packets_t* _array_484c;
	Packets_t* _project_484d;
	Packets_t _matrix_484e;
	Packets_t _basicType_4857;
	Packets_t _project_4860;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4872;
		SFC::BasicType basicType_4873;
		SFC::Project project_4874;
		SFC::Array array_4875;
	};

	std::list< Match> _matches;
};

class CreateArray2_4880
{
public:
	void operator()( const Packets_t& matrixs_4881, const Packets_t& basicTypes_4885, const Packets_t& projects_4887, Packets_t& matrixs_4883, Packets_t& arrays_4884, Packets_t& projects_4889);

protected:
	bool isInputUnique( const Udm::Object& matrix_4891, const Udm::Object& basicType_489a, const Udm::Object& project_48a3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_4881, const Packets_t& basicTypes_4885, const Packets_t& projects_4887);
	bool patternMatcher( const Udm::Object& matrix_488f, const Udm::Object& basicType_4898, const Udm::Object& project_48a1);
	void effector();
	void outputAppender( const ESMoL::Matrix& matrix_48b0, const SFC::Array& array_48b2, const SFC::Project& project_48b4);

private:
	Packets_t* _matrix_488a;
	Packets_t* _array_488b;
	Packets_t* _project_488c;
	Packets_t _matrix_488d;
	Packets_t _basicType_4896;
	Packets_t _project_489f;
	class Match
	{
	public:
		ESMoL::Matrix matrix_48ac;
		SFC::BasicType basicType_48ad;
		SFC::Project project_48ae;
	};

	std::list< Match> _matches;
};

class ProcessScalar_48c2
{
public:
	void operator()( const Packets_t& typess_48c3, const Packets_t& projects_48c5, Packets_t& typess_48c7, Packets_t& basictypes_48c8, Packets_t& projects_48c9);

protected:
	void callGetBasicType_4993( const Packets_t& typess_4928, const Packets_t& projects_492a);
	void callCreateBasicType_4996( const Packets_t& matrixs_48ce, const Packets_t& projects_48d2);
	void callUseBasicType_4999( const Packets_t& matrixs_48f8, const Packets_t& projects_48fc);

private:
	Packets_t* _types_48ca;
	Packets_t* _basictype_48cb;
	Packets_t* _project_48cc;
};

class CreateBasicType_48cd
{
public:
	void operator()( const Packets_t& matrixs_48ce, const Packets_t& projects_48d2, Packets_t& matrixs_48d0, Packets_t& basicTypes_48d1, Packets_t& projects_48d4);

protected:
	bool isInputUnique( const Udm::Object& matrix_48dc, const Udm::Object& project_48e5);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_48ce, const Packets_t& projects_48d2);
	bool patternMatcher( const Udm::Object& matrix_48da, const Udm::Object& project_48e3);
	void effector();
	void outputAppender( const ESMoL::Matrix& matrix_48f1, const SFC::BasicType& basicType_48f3, const SFC::Project& project_48f5);

private:
	Packets_t* _matrix_48d5;
	Packets_t* _basicType_48d6;
	Packets_t* _project_48d7;
	Packets_t _matrix_48d8;
	Packets_t _project_48e1;
	class Match
	{
	public:
		ESMoL::Matrix matrix_48ee;
		SFC::Project project_48ef;
	};

	std::list< Match> _matches;
};

class UseBasicType_48f7
{
public:
	void operator()( const Packets_t& matrixs_48f8, const Packets_t& projects_48fc, Packets_t& matrixs_48fa, Packets_t& basicTypes_48fb, Packets_t& projects_48fe);

protected:
	bool isInputUnique( const Udm::Object& matrix_4906, const Udm::Object& project_490f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::BasicType& BasicType, ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_48f8, const Packets_t& projects_48fc);
	bool patternMatcher( const Udm::Object& matrix_4904, const Udm::Object& project_490d);
	void effector();
	void outputAppender( const ESMoL::Matrix& matrix_4921, const SFC::BasicType& basicType_4923, const SFC::Project& project_4925);

private:
	Packets_t* _matrix_48ff;
	Packets_t* _basicType_4900;
	Packets_t* _project_4901;
	Packets_t _matrix_4902;
	Packets_t _project_490b;
	class Match
	{
	public:
		ESMoL::Matrix matrix_491b;
		SFC::Project project_491c;
		SFC::BasicType basicType_491d;
	};

	std::list< Match> _matches;
};

class GetBasicType_4927
{
public:
	void operator()( const Packets_t& typess_4928, const Packets_t& projects_492a, Packets_t& typess_492c, Packets_t& projectss_492d, Packets_t& typess_492e, Packets_t& projectss_492f);

protected:
	void executeOne( const Packets_t& typess_4928, const Packets_t& projects_492a);
	bool isInputUnique( const Udm::Object& types_4936, const Udm::Object& project_493d);

private:
	Packets_t* _types_4930;
	Packets_t* _projects_4931;
	Packets_t* _types_4932;
	Packets_t* _projects_4933;
	Packets_t _types_4934;
	Packets_t _project_493b;
};

class BasicTypeExists_4942
{
public:
	bool operator()( const Packets_t& matrixs_4943, const Packets_t& projects_4946, Packets_t& matrixs_4945, Packets_t& projects_4948);

protected:
	bool isInputUnique( const Udm::Object& matrix_494f, const Udm::Object& project_4958);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::BasicType& BasicType, ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_4943, const Packets_t& projects_4946);
	bool patternMatcher( const Udm::Object& matrix_494d, const Udm::Object& project_4956);
	void outputAppender( const ESMoL::Matrix& matrix_496a, const SFC::Project& project_496c);

private:
	Packets_t* _matrix_4949;
	Packets_t* _project_494a;
	Packets_t _matrix_494b;
	Packets_t _project_4954;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4964;
		SFC::Project project_4965;
		SFC::BasicType basicType_4966;
	};

	std::list< Match> _matches;
};

class Otherwise_496e
{
public:
	bool operator()( const Packets_t& matrixs_496f, const Packets_t& projects_4972, Packets_t& matrixs_4971, Packets_t& projects_4974);

protected:
	bool isInputUnique( const Udm::Object& matrix_497b, const Udm::Object& project_4984);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_496f, const Packets_t& projects_4972);
	bool patternMatcher( const Udm::Object& matrix_4979, const Udm::Object& project_4982);
	void outputAppender( const ESMoL::Matrix& matrix_498f, const SFC::Project& project_4991);

private:
	Packets_t* _matrix_4975;
	Packets_t* _project_4976;
	Packets_t _matrix_4977;
	Packets_t _project_4980;
	class Match
	{
	public:
		ESMoL::Matrix matrix_498d;
		SFC::Project project_498e;
	};

	std::list< Match> _matches;
};

class ProcessArray1_49a3
{
public:
	void operator()( const Packets_t& typess_49a4, const Packets_t& basictypes_49a6, const Packets_t& projects_49a8, Packets_t& typess_49aa, Packets_t& array1s_49ab, Packets_t& projects_49ac);

protected:
	void callGetArray1_4abf( const Packets_t& typess_4a25, const Packets_t& dts_4a27, const Packets_t& projects_4a29);
	void callCreateArray1_4ac3( const Packets_t& matrixs_49b1, const Packets_t& dTs_49b4, const Packets_t& projects_49b7);
	void callUseArray1_4ac7( const Packets_t& matrixs_49e7, const Packets_t& dTs_49ea, const Packets_t& projects_49ed);

private:
	Packets_t* _types_49ad;
	Packets_t* _array1_49ae;
	Packets_t* _project_49af;
};

class CreateArray1_49b0
{
public:
	void operator()( const Packets_t& matrixs_49b1, const Packets_t& dTs_49b4, const Packets_t& projects_49b7, Packets_t& matrixs_49b3, Packets_t& arrays_49b6, Packets_t& projects_49b9);

protected:
	bool isInputUnique( const Udm::Object& matrix_49c1, const Udm::Object& dT_49ca, const Udm::Object& project_49d3);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_49b1, const Packets_t& dTs_49b4, const Packets_t& projects_49b7);
	bool patternMatcher( const Udm::Object& matrix_49bf, const Udm::Object& dT_49c8, const Udm::Object& project_49d1);
	void effector();
	void outputAppender( const ESMoL::Matrix& matrix_49e0, const SFC::Array& array_49e2, const SFC::Project& project_49e4);

private:
	Packets_t* _matrix_49ba;
	Packets_t* _array_49bb;
	Packets_t* _project_49bc;
	Packets_t _matrix_49bd;
	Packets_t _dT_49c6;
	Packets_t _project_49cf;
	class Match
	{
	public:
		ESMoL::Matrix matrix_49dc;
		SFC::DT dT_49dd;
		SFC::Project project_49de;
	};

	std::list< Match> _matches;
};

class UseArray1_49e6
{
public:
	void operator()( const Packets_t& matrixs_49e7, const Packets_t& dTs_49ea, const Packets_t& projects_49ed, Packets_t& matrixs_49e9, Packets_t& arrays_49ec, Packets_t& projects_49ef);

protected:
	bool isInputUnique( const Udm::Object& matrix_49f7, const Udm::Object& dT_4a00, const Udm::Object& project_4a09);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Array& Array, SFC::DT& DT, ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_49e7, const Packets_t& dTs_49ea, const Packets_t& projects_49ed);
	bool patternMatcher( const Udm::Object& matrix_49f5, const Udm::Object& dT_49fe, const Udm::Object& project_4a07);
	void effector();
	void outputAppender( const ESMoL::Matrix& matrix_4a1e, const SFC::Array& array_4a20, const SFC::Project& project_4a22);

private:
	Packets_t* _matrix_49f0;
	Packets_t* _array_49f1;
	Packets_t* _project_49f2;
	Packets_t _matrix_49f3;
	Packets_t _dT_49fc;
	Packets_t _project_4a05;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4a16;
		SFC::DT dT_4a17;
		SFC::Project project_4a18;
		SFC::Array array_4a19;
	};

	std::list< Match> _matches;
};

class GetArray1_4a24
{
public:
	void operator()( const Packets_t& typess_4a25, const Packets_t& dts_4a27, const Packets_t& projects_4a29, Packets_t& typess_4a2b, Packets_t& dts_4a2c, Packets_t& projectss_4a2d, Packets_t& typess_4a2e, Packets_t& dts_4a2f, Packets_t& projectss_4a30);

protected:
	void executeOne( const Packets_t& typess_4a25, const Packets_t& dts_4a27, const Packets_t& projects_4a29);
	bool isInputUnique( const Udm::Object& types_4a39, const Udm::Object& dt_4a40, const Udm::Object& project_4a47);

private:
	Packets_t* _types_4a31;
	Packets_t* _dt_4a32;
	Packets_t* _projects_4a33;
	Packets_t* _types_4a34;
	Packets_t* _dt_4a35;
	Packets_t* _projects_4a36;
	Packets_t _types_4a37;
	Packets_t _dt_4a3e;
	Packets_t _project_4a45;
};

class Array1Exists_4a4c
{
public:
	bool operator()( const Packets_t& matrixs_4a4d, const Packets_t& dTs_4a50, const Packets_t& projects_4a53, Packets_t& matrixs_4a4f, Packets_t& dTs_4a52, Packets_t& projects_4a55);

protected:
	bool isInputUnique( const Udm::Object& matrix_4a5d, const Udm::Object& dT_4a66, const Udm::Object& project_4a6f);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( SFC::Array& Array, SFC::DT& DT, ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_4a4d, const Packets_t& dTs_4a50, const Packets_t& projects_4a53);
	bool patternMatcher( const Udm::Object& matrix_4a5b, const Udm::Object& dT_4a64, const Udm::Object& project_4a6d);
	void outputAppender( const ESMoL::Matrix& matrix_4a84, const SFC::DT& dT_4a86, const SFC::Project& project_4a88);

private:
	Packets_t* _matrix_4a56;
	Packets_t* _dT_4a57;
	Packets_t* _project_4a58;
	Packets_t _matrix_4a59;
	Packets_t _dT_4a62;
	Packets_t _project_4a6b;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4a7c;
		SFC::DT dT_4a7d;
		SFC::Project project_4a7e;
		SFC::Array array_4a7f;
	};

	std::list< Match> _matches;
};

class Otherwise_4a8a
{
public:
	bool operator()( const Packets_t& matrixs_4a8b, const Packets_t& dTs_4a8e, const Packets_t& projects_4a91, Packets_t& matrixs_4a8d, Packets_t& dTs_4a90, Packets_t& projects_4a93);

protected:
	bool isInputUnique( const Udm::Object& matrix_4a9b, const Udm::Object& dT_4aa4, const Udm::Object& project_4aad);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_4a8b, const Packets_t& dTs_4a8e, const Packets_t& projects_4a91);
	bool patternMatcher( const Udm::Object& matrix_4a99, const Udm::Object& dT_4aa2, const Udm::Object& project_4aab);
	void outputAppender( const ESMoL::Matrix& matrix_4ab9, const SFC::DT& dT_4abb, const SFC::Project& project_4abd);

private:
	Packets_t* _matrix_4a94;
	Packets_t* _dT_4a95;
	Packets_t* _project_4a96;
	Packets_t _matrix_4a97;
	Packets_t _dT_4aa0;
	Packets_t _project_4aa9;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4ab6;
		SFC::DT dT_4ab7;
		SFC::Project project_4ab8;
	};

	std::list< Match> _matches;
};

class ProcessColumn_4ad2
{
public:
	void operator()( const Packets_t& typess_4ad3, const Packets_t& projects_4ad5, Packets_t& typess_4ad7, Packets_t& array1s_4ad8, Packets_t& projects_4ad9);

protected:
	void callProcessScalar_4add( const Packets_t& typess_48c3, const Packets_t& projects_48c5);
	void callProcessArray1_4ae0( const Packets_t& typess_49a4, const Packets_t& basictypes_49a6, const Packets_t& projects_49a8);

private:
	Packets_t* _types_4ada;
	Packets_t* _array1_4adb;
	Packets_t* _project_4adc;
};

class DimensionTest_4ae4
{
public:
	void operator()( const Packets_t& typess_4ae5, const Packets_t& projects_4ae7, Packets_t& typess_4ae9, Packets_t& projects_4aea, Packets_t& typess_4aeb, Packets_t& projects_4aec, Packets_t& typess_4aed, Packets_t& projects_4aee);

protected:
	void executeOne( const Packets_t& typess_4ae5, const Packets_t& projects_4ae7);
	bool isInputUnique( const Udm::Object& types_4af7, const Udm::Object& project_4afe);

private:
	Packets_t* _types_4aef;
	Packets_t* _project_4af0;
	Packets_t* _types_4af1;
	Packets_t* _project_4af2;
	Packets_t* _types_4af3;
	Packets_t* _project_4af4;
	Packets_t _types_4af5;
	Packets_t _project_4afc;
};

class Scalar_4b03
{
public:
	bool operator()( const Packets_t& matrixs_4b04, const Packets_t& projects_4b07, Packets_t& matrixs_4b06, Packets_t& projects_4b09);

protected:
	bool isInputUnique( const Udm::Object& matrix_4b10, const Udm::Object& project_4b19);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_4b04, const Packets_t& projects_4b07);
	bool patternMatcher( const Udm::Object& matrix_4b0e, const Udm::Object& project_4b17);
	void outputAppender( const ESMoL::Matrix& matrix_4b26, const SFC::Project& project_4b28);

private:
	Packets_t* _matrix_4b0a;
	Packets_t* _project_4b0b;
	Packets_t _matrix_4b0c;
	Packets_t _project_4b15;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4b22;
		SFC::Project project_4b23;
	};

	std::list< Match> _matches;
};

class ColumnVector_4b2a
{
public:
	bool operator()( const Packets_t& matrixs_4b2b, const Packets_t& projects_4b2e, Packets_t& matrixs_4b2d, Packets_t& projects_4b30);

protected:
	bool isInputUnique( const Udm::Object& matrix_4b37, const Udm::Object& project_4b40);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	bool isGuardTrue( ESMoL::Matrix& Matrix, SFC::Project& Project);
	void processInputPackets( const Packets_t& matrixs_4b2b, const Packets_t& projects_4b2e);
	bool patternMatcher( const Udm::Object& matrix_4b35, const Udm::Object& project_4b3e);
	void outputAppender( const ESMoL::Matrix& matrix_4b4d, const SFC::Project& project_4b4f);

private:
	Packets_t* _matrix_4b31;
	Packets_t* _project_4b32;
	Packets_t _matrix_4b33;
	Packets_t _project_4b3c;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4b49;
		SFC::Project project_4b4a;
	};

	std::list< Match> _matches;
};

class Other_4b51
{
public:
	bool operator()( const Packets_t& matrixs_4b52, const Packets_t& projects_4b55, Packets_t& matrixs_4b54, Packets_t& projects_4b57);

protected:
	bool isInputUnique( const Udm::Object& matrix_4b5e, const Udm::Object& project_4b67);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_4b52, const Packets_t& projects_4b55);
	bool patternMatcher( const Udm::Object& matrix_4b5c, const Udm::Object& project_4b65);
	void outputAppender( const ESMoL::Matrix& matrix_4b72, const SFC::Project& project_4b74);

private:
	Packets_t* _matrix_4b58;
	Packets_t* _project_4b59;
	Packets_t _matrix_4b5a;
	Packets_t _project_4b63;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4b70;
		SFC::Project project_4b71;
	};

	std::list< Match> _matches;
};

class StructOrMatrix_4b88
{
public:
	void operator()( const Packets_t& typess_4b89, const Packets_t& projects_4b8b, Packets_t& typess_4b8d, Packets_t& projects_4b8e, Packets_t& typess_4b8f, Packets_t& projects_4b90);

protected:
	void executeOne( const Packets_t& typess_4b89, const Packets_t& projects_4b8b);
	bool isInputUnique( const Udm::Object& types_4b97, const Udm::Object& project_4b9e);

private:
	Packets_t* _types_4b91;
	Packets_t* _project_4b92;
	Packets_t* _types_4b93;
	Packets_t* _project_4b94;
	Packets_t _types_4b95;
	Packets_t _project_4b9c;
};

class IsStruct_4ba3
{
public:
	bool operator()( const Packets_t& typeStructs_4ba4, const Packets_t& projects_4ba7, Packets_t& typeStructs_4ba6, Packets_t& projects_4ba9);

protected:
	bool isInputUnique( const Udm::Object& typeStruct_4bb0, const Udm::Object& project_4bb9);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& typeStructs_4ba4, const Packets_t& projects_4ba7);
	bool patternMatcher( const Udm::Object& typeStruct_4bae, const Udm::Object& project_4bb7);
	void outputAppender( const ESMoL::TypeStruct& typeStruct_4bc4, const SFC::Project& project_4bc6);

private:
	Packets_t* _typeStruct_4baa;
	Packets_t* _project_4bab;
	Packets_t _typeStruct_4bac;
	Packets_t _project_4bb5;
	class Match
	{
	public:
		ESMoL::TypeStruct typeStruct_4bc2;
		SFC::Project project_4bc3;
	};

	std::list< Match> _matches;
};

class IsMatrix_4bc8
{
public:
	bool operator()( const Packets_t& matrixs_4bc9, const Packets_t& projects_4bcc, Packets_t& matrixs_4bcb, Packets_t& projects_4bce);

protected:
	bool isInputUnique( const Udm::Object& matrix_4bd5, const Udm::Object& project_4bde);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& matrixs_4bc9, const Packets_t& projects_4bcc);
	bool patternMatcher( const Udm::Object& matrix_4bd3, const Udm::Object& project_4bdc);
	void outputAppender( const ESMoL::Matrix& matrix_4be9, const SFC::Project& project_4beb);

private:
	Packets_t* _matrix_4bcf;
	Packets_t* _project_4bd0;
	Packets_t _matrix_4bd1;
	Packets_t _project_4bda;
	class Match
	{
	public:
		ESMoL::Matrix matrix_4be7;
		SFC::Project project_4be8;
	};

	std::list< Match> _matches;
};

class CreateStructType_4bed
{
public:
	void operator()( const Packets_t& eSMoL_Structs_4bee, const Packets_t& projects_4bf2, Packets_t& eSMoL_Structs_4bf0, Packets_t& sfc_Structs_4bf1);

protected:
	bool isInputUnique( const Udm::Object& eSMoL_Struct_4bfa, const Udm::Object& project_4c03);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& eSMoL_Structs_4bee, const Packets_t& projects_4bf2);
	bool patternMatcher( const Udm::Object& eSMoL_Struct_4bf8, const Udm::Object& project_4c01);
	void effector();
	void outputAppender( const ESMoL::TypeStruct& eSMoL_Struct_4c0f, const SFC::Struct& sfc_Struct_4c11);

private:
	Packets_t* _eSMoL_Struct_4bf4;
	Packets_t* _sfc_Struct_4bf5;
	Packets_t _eSMoL_Struct_4bf6;
	Packets_t _project_4bff;
	class Match
	{
	public:
		ESMoL::TypeStruct eSMoL_Struct_4c0c;
		SFC::Project project_4c0d;
	};

	std::list< Match> _matches;
};

class HasRefSubsystems_4c27
{
public:
	void operator()( const Packets_t& dataflows_4c28, const Packets_t& projects_4c2a, Packets_t& dataflows_4c2c, Packets_t& projects_4c2d);

protected:
	void callresetHasRefSubsystems_4c54( const Packets_t& dataflows_4c31);
	void callGetRefSubsystems_4c56( const Packets_t& dataflows_58);
	void callsetHasRefSubsystems_4c58( const Packets_t& subsystems_4c44);

private:
	Packets_t* _dataflow_4c2e;
	Packets_t* _project_4c2f;
};

class ResetHasRefSubsystems_4c30
{
public:
	void operator()( const Packets_t& dataflows_4c31, Packets_t& dataflows_4c33);

protected:
	bool isInputUnique( const Udm::Object& dataflow_4c39);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_4c31);
	bool patternMatcher( const Udm::Object& dataflow_4c37);
	void effector();
	void forwardInputs();

private:
	Packets_t* _dataflow_4c34;
	Packets_t _dataflow_4c35;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_4c42;
	};

	std::list< Match> _matches;
};

class SetHasRefSubsystems_4c43
{
public:
	void operator()( const Packets_t& subsystems_4c44);

protected:
	bool isInputUnique( const Udm::Object& subsystem_4c4a);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& subsystems_4c44);
	bool patternMatcher( const Udm::Object& subsystem_4c48);
	void effector();

private:
	Packets_t _subsystem_4c46;
	class Match
	{
	public:
		ESMoL::Subsystem subsystem_4c53;
	};

	std::list< Match> _matches;
};

class GetProject_4c5a
{
public:
	void operator()( const Packets_t& dataflows_4c5b, const Packets_t& projects_4c5e, Packets_t& dataflows_4c5d, Packets_t& projects_4c60);

protected:
	bool isInputUnique( const Udm::Object& dataflow_4c67, const Udm::Object& project_4c70);
	bool isValidBound( set< pair<int, Udm::Object> >& boundObjs, Udm::Object& currObj, bool isInputObj);
	void processInputPackets( const Packets_t& dataflows_4c5b, const Packets_t& projects_4c5e);
	bool patternMatcher( const Udm::Object& dataflow_4c65, const Udm::Object& project_4c6e);
	void effector();
	void forwardInputs();

private:
	Packets_t* _dataflow_4c61;
	Packets_t* _project_4c62;
	Packets_t _dataflow_4c63;
	Packets_t _project_4c6c;
	class Match
	{
	public:
		ESMoL::Dataflow dataflow_4c79;
		SFC::Project project_4c7a;
	};

	std::list< Match> _matches;
};

