// cpp (meta datanetwork format) source file ESM2SLC.cpp
// generated from diagram ESM2SLC
// generated on Mon Jul 23 16:50:56 2012

#include "ESM2SLC.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "ESM2SLC_xsd.h"
using namespace std;

namespace ESM2SLC {

	_gen_cont::_gen_cont() {}
	_gen_cont::_gen_cont(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	_gen_cont::_gen_cont(const _gen_cont &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	_gen_cont::_gen_cont(_gen_cont &&master) : UDM_OBJECT(master) {};

	_gen_cont _gen_cont::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	_gen_cont& _gen_cont::operator=(_gen_cont &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	_gen_cont _gen_cont::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	_gen_cont _gen_cont::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	_gen_cont _gen_cont::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< _gen_cont> _gen_cont::Instances() { return ::Udm::InstantiatedAttr< _gen_cont>(impl); }
	_gen_cont _gen_cont::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< _gen_cont> _gen_cont::Derived() { return ::Udm::DerivedAttr< _gen_cont>(impl); }
	::Udm::ArchetypeAttr< _gen_cont> _gen_cont::Archetype() const { return ::Udm::ArchetypeAttr< _gen_cont>(impl); }
	::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC> _gen_cont::Function_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC>(impl, meta_Function_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC> _gen_cont::FunctionCall_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC>(impl, meta_FunctionCall_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC> _gen_cont::ArgDeclBase_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC>(impl, meta_ArgDeclBase_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC> _gen_cont::Class_cross_ph_SFC_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC>(impl, meta_Class_cross_ph_SFC_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL> _gen_cont::TypeBase_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL>(impl, meta_TypeBase_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL> _gen_cont::TypeBaseRef_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL>(impl, meta_TypeBaseRef_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL> _gen_cont::Primitive_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL>(impl, meta_Primitive_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL> _gen_cont::Parameter_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL>(impl, meta_Parameter_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL> _gen_cont::Subsystem_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL>(impl, meta_Subsystem_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL> _gen_cont::Port_cross_ph_ESMoL_childrole() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL>(impl, meta_Port_cross_ph_ESMoL_childrole); }
	::Udm::ChildrenAttr< ::ESM2SLC::Arg_cross_ph_SFC> _gen_cont::Arg_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Arg_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC> _gen_cont::Function_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::LocalVar_cross_ph_SFC> _gen_cont::LocalVar_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::LocalVar_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::StateVar_cross_ph_SFC> _gen_cont::StateVar_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::StateVar_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::StateLabel_cross_ph_SFC> _gen_cont::StateLabel_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::StateLabel_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC> _gen_cont::FunctionCall_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Var_cross_ph_SFC> _gen_cont::Var_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Var_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Declaration_cross_ph_SFC> _gen_cont::Declaration_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Declaration_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::DT_cross_ph_SFC> _gen_cont::DT_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::DT_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Struct_cross_ph_SFC> _gen_cont::Struct_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Struct_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC> _gen_cont::ArgDeclBase_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC> _gen_cont::Class_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Array_cross_ph_SFC> _gen_cont::Array_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Array_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::BasicType_cross_ph_SFC> _gen_cont::BasicType_cross_ph_SFC_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::BasicType_cross_ph_SFC>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::TypeStruct_cross_ph_ESMoL> _gen_cont::TypeStruct_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeStruct_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Matrix_cross_ph_ESMoL> _gen_cont::Matrix_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Matrix_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL> _gen_cont::TypeBase_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL> _gen_cont::TypeBaseRef_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL> _gen_cont::Primitive_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL> _gen_cont::Parameter_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL> _gen_cont::Subsystem_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::OutputPort_cross_ph_ESMoL> _gen_cont::OutputPort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::OutputPort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::OutPort_cross_ph_ESMoL> _gen_cont::OutPort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::OutPort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::StatePort_cross_ph_ESMoL> _gen_cont::StatePort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::StatePort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL> _gen_cont::Port_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::EnablePort_cross_ph_ESMoL> _gen_cont::EnablePort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::EnablePort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::TriggerPort_cross_ph_ESMoL> _gen_cont::TriggerPort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::TriggerPort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::InputPort_cross_ph_ESMoL> _gen_cont::InputPort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::InputPort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::InPort_cross_ph_ESMoL> _gen_cont::InPort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::InPort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESM2SLC::ActionPort_cross_ph_ESMoL> _gen_cont::ActionPort_cross_ph_ESMoL_kind_children() const { return ::Udm::ChildrenAttr< ::ESM2SLC::ActionPort_cross_ph_ESMoL>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::Udm::Object> _gen_cont::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class _gen_cont::meta;
	::Uml::CompositionChildRole _gen_cont::meta_Function_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_FunctionCall_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Class_cross_ph_SFC_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Primitive_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Parameter_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Subsystem_cross_ph_ESMoL_childrole;
	::Uml::CompositionChildRole _gen_cont::meta_Port_cross_ph_ESMoL_childrole;

	Arg_cross_ph_SFC::Arg_cross_ph_SFC() {}
	Arg_cross_ph_SFC::Arg_cross_ph_SFC(::Udm::ObjectImpl *impl) : ArgDeclBase_cross_ph_SFC(impl) {}
	Arg_cross_ph_SFC::Arg_cross_ph_SFC(const Arg_cross_ph_SFC &master) : ArgDeclBase_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Arg_cross_ph_SFC::Arg_cross_ph_SFC(Arg_cross_ph_SFC &&master) : ArgDeclBase_cross_ph_SFC(master) {};

	Arg_cross_ph_SFC Arg_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Arg_cross_ph_SFC& Arg_cross_ph_SFC::operator=(Arg_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Arg_cross_ph_SFC Arg_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Arg_cross_ph_SFC Arg_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Arg_cross_ph_SFC Arg_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Arg_cross_ph_SFC> Arg_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Arg_cross_ph_SFC>(impl); }
	Arg_cross_ph_SFC Arg_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Arg_cross_ph_SFC> Arg_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Arg_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Arg_cross_ph_SFC> Arg_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Arg_cross_ph_SFC>(impl); }
	::Udm::PointerAttr< Parameter_cross_ph_ESMoL> Arg_cross_ph_SFC::initparam() const { return ::Udm::PointerAttr< Parameter_cross_ph_ESMoL>(impl, meta_initparam); }
	::Udm::AssocAttr< Port_cross_ph_ESMoL> Arg_cross_ph_SFC::port() const { return ::Udm::AssocAttr< Port_cross_ph_ESMoL>(impl, meta_port); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Arg_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Arg_cross_ph_SFC::meta;
	::Uml::AssociationRole Arg_cross_ph_SFC::meta_initparam;
	::Uml::AssociationRole Arg_cross_ph_SFC::meta_port;

	Function_cross_ph_SFC::Function_cross_ph_SFC() {}
	Function_cross_ph_SFC::Function_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Function_cross_ph_SFC::Function_cross_ph_SFC(const Function_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Function_cross_ph_SFC::Function_cross_ph_SFC(Function_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	Function_cross_ph_SFC Function_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Function_cross_ph_SFC& Function_cross_ph_SFC::operator=(Function_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Function_cross_ph_SFC Function_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Function_cross_ph_SFC Function_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Function_cross_ph_SFC Function_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Function_cross_ph_SFC>(impl); }
	Function_cross_ph_SFC Function_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Function_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Function_cross_ph_SFC> Function_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Function_cross_ph_SFC>(impl); }
	::Udm::StringAttr Function_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Function_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< Subsystem_cross_ph_ESMoL> Function_cross_ph_SFC::sysinit() const { return ::Udm::PointerAttr< Subsystem_cross_ph_ESMoL>(impl, meta_sysinit); }
	::Udm::AssocAttr< Subsystem_cross_ph_ESMoL> Function_cross_ph_SFC::sysmain() const { return ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL>(impl, meta_sysmain); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Function_cross_ph_SFC::Function_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_Function_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Function_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Function_cross_ph_SFC::meta;
	::Uml::Attribute Function_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute Function_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_sysinit;
	::Uml::AssociationRole Function_cross_ph_SFC::meta_sysmain;
	::Uml::CompositionParentRole Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole;

	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC() {}
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(::Udm::ObjectImpl *impl) : Var_cross_ph_SFC(impl) {}
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(const LocalVar_cross_ph_SFC &master) : Var_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	LocalVar_cross_ph_SFC::LocalVar_cross_ph_SFC(LocalVar_cross_ph_SFC &&master) : Var_cross_ph_SFC(master) {};

	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	LocalVar_cross_ph_SFC& LocalVar_cross_ph_SFC::operator=(LocalVar_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC>(impl); }
	LocalVar_cross_ph_SFC LocalVar_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< LocalVar_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC>(impl); }
	::Udm::PointerAttr< Struct_cross_ph_SFC> LocalVar_cross_ph_SFC::pstrct() const { return ::Udm::PointerAttr< Struct_cross_ph_SFC>(impl, meta_pstrct); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::trigvar() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_trigvar); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC::oldvar() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_oldvar); }
	::Udm::AssocAttr< TriggerPort_cross_ph_ESMoL> LocalVar_cross_ph_SFC::trig() const { return ::Udm::AssocAttr< TriggerPort_cross_ph_ESMoL>(impl, meta_trig); }
	::Udm::AssocAttr< Subsystem_cross_ph_ESMoL> LocalVar_cross_ph_SFC::sys() const { return ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL>(impl, meta_sys); }
	::Udm::AssocAttr< Parameter_cross_ph_ESMoL> LocalVar_cross_ph_SFC::param() const { return ::Udm::AssocAttr< Parameter_cross_ph_ESMoL>(impl, meta_param); }
	::Udm::PointerAttr< TypeBaseRef_cross_ph_ESMoL> LocalVar_cross_ph_SFC::tbr() const { return ::Udm::PointerAttr< TypeBaseRef_cross_ph_ESMoL>(impl, meta_tbr); }
	::Udm::PointerAttr< Primitive_cross_ph_ESMoL> LocalVar_cross_ph_SFC::ifblock() const { return ::Udm::PointerAttr< Primitive_cross_ph_ESMoL>(impl, meta_ifblock); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> LocalVar_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class LocalVar_cross_ph_SFC::meta;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_pstrct;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_trigvar;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_oldvar;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_trig;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_sys;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_param;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_tbr;
	::Uml::AssociationRole LocalVar_cross_ph_SFC::meta_ifblock;

	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC() {}
	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC(::Udm::ObjectImpl *impl) : Var_cross_ph_SFC(impl) {}
	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC(const StateVar_cross_ph_SFC &master) : Var_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	StateVar_cross_ph_SFC::StateVar_cross_ph_SFC(StateVar_cross_ph_SFC &&master) : Var_cross_ph_SFC(master) {};

	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateVar_cross_ph_SFC& StateVar_cross_ph_SFC::operator=(StateVar_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateVar_cross_ph_SFC> StateVar_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< StateVar_cross_ph_SFC>(impl); }
	StateVar_cross_ph_SFC StateVar_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateVar_cross_ph_SFC> StateVar_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< StateVar_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< StateVar_cross_ph_SFC> StateVar_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< StateVar_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> StateVar_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateVar_cross_ph_SFC::meta;

	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC() {}
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(::Udm::ObjectImpl *impl) : Declaration_cross_ph_SFC(impl) {}
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(const StateLabel_cross_ph_SFC &master) : Declaration_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	StateLabel_cross_ph_SFC::StateLabel_cross_ph_SFC(StateLabel_cross_ph_SFC &&master) : Declaration_cross_ph_SFC(master) {};

	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateLabel_cross_ph_SFC& StateLabel_cross_ph_SFC::operator=(StateLabel_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC>(impl); }
	StateLabel_cross_ph_SFC StateLabel_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< StateLabel_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> StateLabel_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateLabel_cross_ph_SFC::meta;

	FunctionCall_cross_ph_SFC::FunctionCall_cross_ph_SFC() {}
	FunctionCall_cross_ph_SFC::FunctionCall_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	FunctionCall_cross_ph_SFC::FunctionCall_cross_ph_SFC(const FunctionCall_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FunctionCall_cross_ph_SFC::FunctionCall_cross_ph_SFC(FunctionCall_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	FunctionCall_cross_ph_SFC FunctionCall_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FunctionCall_cross_ph_SFC& FunctionCall_cross_ph_SFC::operator=(FunctionCall_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FunctionCall_cross_ph_SFC FunctionCall_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FunctionCall_cross_ph_SFC FunctionCall_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FunctionCall_cross_ph_SFC FunctionCall_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FunctionCall_cross_ph_SFC> FunctionCall_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< FunctionCall_cross_ph_SFC>(impl); }
	FunctionCall_cross_ph_SFC FunctionCall_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FunctionCall_cross_ph_SFC> FunctionCall_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< FunctionCall_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< FunctionCall_cross_ph_SFC> FunctionCall_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< FunctionCall_cross_ph_SFC>(impl); }
	::Udm::StringAttr FunctionCall_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr FunctionCall_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< Subsystem_cross_ph_ESMoL> FunctionCall_cross_ph_SFC::obj() const { return ::Udm::PointerAttr< Subsystem_cross_ph_ESMoL>(impl, meta_obj); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> FunctionCall_cross_ph_SFC::FunctionCall_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_FunctionCall_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> FunctionCall_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FunctionCall_cross_ph_SFC::meta;
	::Uml::Attribute FunctionCall_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute FunctionCall_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole FunctionCall_cross_ph_SFC::meta_obj;
	::Uml::CompositionParentRole FunctionCall_cross_ph_SFC::meta_FunctionCall_cross_ph_SFC_parentrole;

	Var_cross_ph_SFC::Var_cross_ph_SFC() {}
	Var_cross_ph_SFC::Var_cross_ph_SFC(::Udm::ObjectImpl *impl) : Declaration_cross_ph_SFC(impl) {}
	Var_cross_ph_SFC::Var_cross_ph_SFC(const Var_cross_ph_SFC &master) : Declaration_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Var_cross_ph_SFC::Var_cross_ph_SFC(Var_cross_ph_SFC &&master) : Declaration_cross_ph_SFC(master) {};

	Var_cross_ph_SFC Var_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Var_cross_ph_SFC& Var_cross_ph_SFC::operator=(Var_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Var_cross_ph_SFC Var_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Var_cross_ph_SFC Var_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Var_cross_ph_SFC Var_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Var_cross_ph_SFC> Var_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Var_cross_ph_SFC>(impl); }
	Var_cross_ph_SFC Var_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Var_cross_ph_SFC> Var_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Var_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Var_cross_ph_SFC> Var_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Var_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Var_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Var_cross_ph_SFC::meta;

	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC() {}
	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC(::Udm::ObjectImpl *impl) : ArgDeclBase_cross_ph_SFC(impl) {}
	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC(const Declaration_cross_ph_SFC &master) : ArgDeclBase_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Declaration_cross_ph_SFC::Declaration_cross_ph_SFC(Declaration_cross_ph_SFC &&master) : ArgDeclBase_cross_ph_SFC(master) {};

	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Declaration_cross_ph_SFC& Declaration_cross_ph_SFC::operator=(Declaration_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Declaration_cross_ph_SFC> Declaration_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Declaration_cross_ph_SFC>(impl); }
	Declaration_cross_ph_SFC Declaration_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Declaration_cross_ph_SFC> Declaration_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Declaration_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Declaration_cross_ph_SFC> Declaration_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Declaration_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Declaration_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Declaration_cross_ph_SFC::meta;

	DT_cross_ph_SFC::DT_cross_ph_SFC() {}
	DT_cross_ph_SFC::DT_cross_ph_SFC(::Udm::ObjectImpl *impl) : Declaration_cross_ph_SFC(impl) {}
	DT_cross_ph_SFC::DT_cross_ph_SFC(const DT_cross_ph_SFC &master) : Declaration_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	DT_cross_ph_SFC::DT_cross_ph_SFC(DT_cross_ph_SFC &&master) : Declaration_cross_ph_SFC(master) {};

	DT_cross_ph_SFC DT_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DT_cross_ph_SFC& DT_cross_ph_SFC::operator=(DT_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DT_cross_ph_SFC DT_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DT_cross_ph_SFC DT_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DT_cross_ph_SFC DT_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< DT_cross_ph_SFC>(impl); }
	DT_cross_ph_SFC DT_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< DT_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< DT_cross_ph_SFC> DT_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< DT_cross_ph_SFC>(impl); }
	::Udm::PointerAttr< TypeBase_cross_ph_ESMoL> DT_cross_ph_SFC::tb() const { return ::Udm::PointerAttr< TypeBase_cross_ph_ESMoL>(impl, meta_tb); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> DT_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DT_cross_ph_SFC::meta;
	::Uml::AssociationRole DT_cross_ph_SFC::meta_tb;

	Struct_cross_ph_SFC::Struct_cross_ph_SFC() {}
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(const Struct_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Struct_cross_ph_SFC::Struct_cross_ph_SFC(Struct_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	Struct_cross_ph_SFC Struct_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Struct_cross_ph_SFC& Struct_cross_ph_SFC::operator=(Struct_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Struct_cross_ph_SFC Struct_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Struct_cross_ph_SFC>(impl); }
	Struct_cross_ph_SFC Struct_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Struct_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Struct_cross_ph_SFC> Struct_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Struct_cross_ph_SFC>(impl); }
	::Udm::AssocAttr< LocalVar_cross_ph_SFC> Struct_cross_ph_SFC::pmemb() const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC>(impl, meta_pmemb); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Struct_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Struct_cross_ph_SFC::meta;
	::Uml::AssociationRole Struct_cross_ph_SFC::meta_pmemb;

	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC() {}
	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC(const ArgDeclBase_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC(ArgDeclBase_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ArgDeclBase_cross_ph_SFC& ArgDeclBase_cross_ph_SFC::operator=(ArgDeclBase_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC>(impl); }
	ArgDeclBase_cross_ph_SFC ArgDeclBase_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< ArgDeclBase_cross_ph_SFC>(impl); }
	::Udm::StringAttr ArgDeclBase_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr ArgDeclBase_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< Port_cross_ph_ESMoL> ArgDeclBase_cross_ph_SFC::port() const { return ::Udm::AssocAttr< Port_cross_ph_ESMoL>(impl, meta_port); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> ArgDeclBase_cross_ph_SFC::ArgDeclBase_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_ArgDeclBase_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> ArgDeclBase_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ArgDeclBase_cross_ph_SFC::meta;
	::Uml::Attribute ArgDeclBase_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute ArgDeclBase_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole ArgDeclBase_cross_ph_SFC::meta_port;
	::Uml::CompositionParentRole ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole;

	Class_cross_ph_SFC::Class_cross_ph_SFC() {}
	Class_cross_ph_SFC::Class_cross_ph_SFC(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Class_cross_ph_SFC::Class_cross_ph_SFC(const Class_cross_ph_SFC &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Class_cross_ph_SFC::Class_cross_ph_SFC(Class_cross_ph_SFC &&master) : UDM_OBJECT(master) {};

	Class_cross_ph_SFC Class_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Class_cross_ph_SFC& Class_cross_ph_SFC::operator=(Class_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Class_cross_ph_SFC Class_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Class_cross_ph_SFC Class_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Class_cross_ph_SFC Class_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Class_cross_ph_SFC>(impl); }
	Class_cross_ph_SFC Class_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Class_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Class_cross_ph_SFC>(impl); }
	::Udm::StringAttr Class_cross_ph_SFC::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Class_cross_ph_SFC::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::equivdst() const { return ::Udm::AssocAttr< Class_cross_ph_SFC>(impl, meta_equivdst); }
	::Udm::AssocAttr< Class_cross_ph_SFC> Class_cross_ph_SFC::equivsrc() const { return ::Udm::AssocAttr< Class_cross_ph_SFC>(impl, meta_equivsrc); }
	::Udm::AssocAttr< Subsystem_cross_ph_ESMoL> Class_cross_ph_SFC::obj() const { return ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL>(impl, meta_obj); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Class_cross_ph_SFC::Class_cross_ph_SFC_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_Class_cross_ph_SFC_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Class_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Class_cross_ph_SFC::meta;
	::Uml::Attribute Class_cross_ph_SFC::meta_rem_sysname;
	::Uml::Attribute Class_cross_ph_SFC::meta_rem_id;
	::Uml::AssociationRole Class_cross_ph_SFC::meta_equivdst;
	::Uml::AssociationRole Class_cross_ph_SFC::meta_equivsrc;
	::Uml::AssociationRole Class_cross_ph_SFC::meta_obj;
	::Uml::CompositionParentRole Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole;

	Array_cross_ph_SFC::Array_cross_ph_SFC() {}
	Array_cross_ph_SFC::Array_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	Array_cross_ph_SFC::Array_cross_ph_SFC(const Array_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	Array_cross_ph_SFC::Array_cross_ph_SFC(Array_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	Array_cross_ph_SFC Array_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Array_cross_ph_SFC& Array_cross_ph_SFC::operator=(Array_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Array_cross_ph_SFC Array_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Array_cross_ph_SFC Array_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Array_cross_ph_SFC Array_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< Array_cross_ph_SFC>(impl); }
	Array_cross_ph_SFC Array_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< Array_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< Array_cross_ph_SFC> Array_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< Array_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Array_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Array_cross_ph_SFC::meta;

	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC() {}
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(::Udm::ObjectImpl *impl) : DT_cross_ph_SFC(impl) {}
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(const BasicType_cross_ph_SFC &master) : DT_cross_ph_SFC(master) {}

#ifdef UDM_RVALUE
	BasicType_cross_ph_SFC::BasicType_cross_ph_SFC(BasicType_cross_ph_SFC &&master) : DT_cross_ph_SFC(master) {};

	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BasicType_cross_ph_SFC& BasicType_cross_ph_SFC::operator=(BasicType_cross_ph_SFC &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Instances() { return ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC>(impl); }
	BasicType_cross_ph_SFC BasicType_cross_ph_SFC::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Derived() { return ::Udm::DerivedAttr< BasicType_cross_ph_SFC>(impl); }
	::Udm::ArchetypeAttr< BasicType_cross_ph_SFC> BasicType_cross_ph_SFC::Archetype() const { return ::Udm::ArchetypeAttr< BasicType_cross_ph_SFC>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> BasicType_cross_ph_SFC::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BasicType_cross_ph_SFC::meta;

	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL() {}
	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : TypeBase_cross_ph_ESMoL(impl) {}
	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL(const TypeStruct_cross_ph_ESMoL &master) : TypeBase_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	TypeStruct_cross_ph_ESMoL::TypeStruct_cross_ph_ESMoL(TypeStruct_cross_ph_ESMoL &&master) : TypeBase_cross_ph_ESMoL(master) {};

	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeStruct_cross_ph_ESMoL& TypeStruct_cross_ph_ESMoL::operator=(TypeStruct_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL>(impl); }
	TypeStruct_cross_ph_ESMoL TypeStruct_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TypeStruct_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeStruct_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeStruct_cross_ph_ESMoL::meta;

	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL() {}
	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : TypeBase_cross_ph_ESMoL(impl) {}
	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL(const Matrix_cross_ph_ESMoL &master) : TypeBase_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	Matrix_cross_ph_ESMoL::Matrix_cross_ph_ESMoL(Matrix_cross_ph_ESMoL &&master) : TypeBase_cross_ph_ESMoL(master) {};

	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Matrix_cross_ph_ESMoL& Matrix_cross_ph_ESMoL::operator=(Matrix_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL>(impl); }
	Matrix_cross_ph_ESMoL Matrix_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Matrix_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Matrix_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Matrix_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Matrix_cross_ph_ESMoL::meta;

	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL() {}
	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL(const TypeBase_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL(TypeBase_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeBase_cross_ph_ESMoL& TypeBase_cross_ph_ESMoL::operator=(TypeBase_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL>(impl); }
	TypeBase_cross_ph_ESMoL TypeBase_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TypeBase_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr TypeBase_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr TypeBase_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< DT_cross_ph_SFC> TypeBase_cross_ph_ESMoL::dt() const { return ::Udm::PointerAttr< DT_cross_ph_SFC>(impl, meta_dt); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeBase_cross_ph_ESMoL::TypeBase_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_TypeBase_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeBase_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeBase_cross_ph_ESMoL::meta;
	::Uml::Attribute TypeBase_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute TypeBase_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole TypeBase_cross_ph_ESMoL::meta_dt;
	::Uml::CompositionParentRole TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole;

	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL() {}
	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL(const TypeBaseRef_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL(TypeBaseRef_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeBaseRef_cross_ph_ESMoL& TypeBaseRef_cross_ph_ESMoL::operator=(TypeBaseRef_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL>(impl); }
	TypeBaseRef_cross_ph_ESMoL TypeBaseRef_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TypeBaseRef_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr TypeBaseRef_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr TypeBaseRef_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> TypeBaseRef_cross_ph_ESMoL::lvar() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_lvar); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeBaseRef_cross_ph_ESMoL::TypeBaseRef_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_TypeBaseRef_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeBaseRef_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeBaseRef_cross_ph_ESMoL::meta;
	::Uml::Attribute TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute TypeBaseRef_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole TypeBaseRef_cross_ph_ESMoL::meta_lvar;
	::Uml::CompositionParentRole TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole;

	Primitive_cross_ph_ESMoL::Primitive_cross_ph_ESMoL() {}
	Primitive_cross_ph_ESMoL::Primitive_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Primitive_cross_ph_ESMoL::Primitive_cross_ph_ESMoL(const Primitive_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Primitive_cross_ph_ESMoL::Primitive_cross_ph_ESMoL(Primitive_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	Primitive_cross_ph_ESMoL Primitive_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Primitive_cross_ph_ESMoL& Primitive_cross_ph_ESMoL::operator=(Primitive_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Primitive_cross_ph_ESMoL Primitive_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Primitive_cross_ph_ESMoL Primitive_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Primitive_cross_ph_ESMoL Primitive_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Primitive_cross_ph_ESMoL> Primitive_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Primitive_cross_ph_ESMoL>(impl); }
	Primitive_cross_ph_ESMoL Primitive_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Primitive_cross_ph_ESMoL> Primitive_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Primitive_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Primitive_cross_ph_ESMoL> Primitive_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Primitive_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr Primitive_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Primitive_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> Primitive_cross_ph_ESMoL::ifval() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_ifval); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Primitive_cross_ph_ESMoL::Primitive_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_Primitive_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Primitive_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Primitive_cross_ph_ESMoL::meta;
	::Uml::Attribute Primitive_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute Primitive_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole Primitive_cross_ph_ESMoL::meta_ifval;
	::Uml::CompositionParentRole Primitive_cross_ph_ESMoL::meta_Primitive_cross_ph_ESMoL_parentrole;

	Parameter_cross_ph_ESMoL::Parameter_cross_ph_ESMoL() {}
	Parameter_cross_ph_ESMoL::Parameter_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Parameter_cross_ph_ESMoL::Parameter_cross_ph_ESMoL(const Parameter_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Parameter_cross_ph_ESMoL::Parameter_cross_ph_ESMoL(Parameter_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	Parameter_cross_ph_ESMoL Parameter_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Parameter_cross_ph_ESMoL& Parameter_cross_ph_ESMoL::operator=(Parameter_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Parameter_cross_ph_ESMoL Parameter_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Parameter_cross_ph_ESMoL Parameter_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Parameter_cross_ph_ESMoL Parameter_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Parameter_cross_ph_ESMoL> Parameter_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Parameter_cross_ph_ESMoL>(impl); }
	Parameter_cross_ph_ESMoL Parameter_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Parameter_cross_ph_ESMoL> Parameter_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Parameter_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Parameter_cross_ph_ESMoL> Parameter_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Parameter_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr Parameter_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Parameter_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< Arg_cross_ph_SFC> Parameter_cross_ph_ESMoL::arg() const { return ::Udm::PointerAttr< Arg_cross_ph_SFC>(impl, meta_arg); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> Parameter_cross_ph_ESMoL::memb() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_memb); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Parameter_cross_ph_ESMoL::Parameter_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_Parameter_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Parameter_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Parameter_cross_ph_ESMoL::meta;
	::Uml::Attribute Parameter_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute Parameter_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole Parameter_cross_ph_ESMoL::meta_arg;
	::Uml::AssociationRole Parameter_cross_ph_ESMoL::meta_memb;
	::Uml::CompositionParentRole Parameter_cross_ph_ESMoL::meta_Parameter_cross_ph_ESMoL_parentrole;

	Subsystem_cross_ph_ESMoL::Subsystem_cross_ph_ESMoL() {}
	Subsystem_cross_ph_ESMoL::Subsystem_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Subsystem_cross_ph_ESMoL::Subsystem_cross_ph_ESMoL(const Subsystem_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Subsystem_cross_ph_ESMoL::Subsystem_cross_ph_ESMoL(Subsystem_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	Subsystem_cross_ph_ESMoL Subsystem_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Subsystem_cross_ph_ESMoL& Subsystem_cross_ph_ESMoL::operator=(Subsystem_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Subsystem_cross_ph_ESMoL Subsystem_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Subsystem_cross_ph_ESMoL Subsystem_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Subsystem_cross_ph_ESMoL Subsystem_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Subsystem_cross_ph_ESMoL> Subsystem_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Subsystem_cross_ph_ESMoL>(impl); }
	Subsystem_cross_ph_ESMoL Subsystem_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Subsystem_cross_ph_ESMoL> Subsystem_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Subsystem_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Subsystem_cross_ph_ESMoL> Subsystem_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Subsystem_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr Subsystem_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Subsystem_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::PointerAttr< Function_cross_ph_SFC> Subsystem_cross_ph_ESMoL::init() const { return ::Udm::PointerAttr< Function_cross_ph_SFC>(impl, meta_init); }
	::Udm::PointerAttr< Function_cross_ph_SFC> Subsystem_cross_ph_ESMoL::main() const { return ::Udm::PointerAttr< Function_cross_ph_SFC>(impl, meta_main); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> Subsystem_cross_ph_ESMoL::memb() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_memb); }
	::Udm::AssocAttr< FunctionCall_cross_ph_SFC> Subsystem_cross_ph_ESMoL::mcall() const { return ::Udm::AssocAttr< FunctionCall_cross_ph_SFC>(impl, meta_mcall); }
	::Udm::PointerAttr< Class_cross_ph_SFC> Subsystem_cross_ph_ESMoL::cls() const { return ::Udm::PointerAttr< Class_cross_ph_SFC>(impl, meta_cls); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Subsystem_cross_ph_ESMoL::Subsystem_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_Subsystem_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Subsystem_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Subsystem_cross_ph_ESMoL::meta;
	::Uml::Attribute Subsystem_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute Subsystem_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole Subsystem_cross_ph_ESMoL::meta_init;
	::Uml::AssociationRole Subsystem_cross_ph_ESMoL::meta_main;
	::Uml::AssociationRole Subsystem_cross_ph_ESMoL::meta_memb;
	::Uml::AssociationRole Subsystem_cross_ph_ESMoL::meta_mcall;
	::Uml::AssociationRole Subsystem_cross_ph_ESMoL::meta_cls;
	::Uml::CompositionParentRole Subsystem_cross_ph_ESMoL::meta_Subsystem_cross_ph_ESMoL_parentrole;

	OutputPort_cross_ph_ESMoL::OutputPort_cross_ph_ESMoL() {}
	OutputPort_cross_ph_ESMoL::OutputPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : OutPort_cross_ph_ESMoL(impl) {}
	OutputPort_cross_ph_ESMoL::OutputPort_cross_ph_ESMoL(const OutputPort_cross_ph_ESMoL &master) : OutPort_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	OutputPort_cross_ph_ESMoL::OutputPort_cross_ph_ESMoL(OutputPort_cross_ph_ESMoL &&master) : OutPort_cross_ph_ESMoL(master) {};

	OutputPort_cross_ph_ESMoL OutputPort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutputPort_cross_ph_ESMoL& OutputPort_cross_ph_ESMoL::operator=(OutputPort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutputPort_cross_ph_ESMoL OutputPort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutputPort_cross_ph_ESMoL OutputPort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutputPort_cross_ph_ESMoL OutputPort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutputPort_cross_ph_ESMoL> OutputPort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< OutputPort_cross_ph_ESMoL>(impl); }
	OutputPort_cross_ph_ESMoL OutputPort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutputPort_cross_ph_ESMoL> OutputPort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< OutputPort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< OutputPort_cross_ph_ESMoL> OutputPort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< OutputPort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> OutputPort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OutputPort_cross_ph_ESMoL::meta;

	OutPort_cross_ph_ESMoL::OutPort_cross_ph_ESMoL() {}
	OutPort_cross_ph_ESMoL::OutPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : Port_cross_ph_ESMoL(impl) {}
	OutPort_cross_ph_ESMoL::OutPort_cross_ph_ESMoL(const OutPort_cross_ph_ESMoL &master) : Port_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	OutPort_cross_ph_ESMoL::OutPort_cross_ph_ESMoL(OutPort_cross_ph_ESMoL &&master) : Port_cross_ph_ESMoL(master) {};

	OutPort_cross_ph_ESMoL OutPort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutPort_cross_ph_ESMoL& OutPort_cross_ph_ESMoL::operator=(OutPort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutPort_cross_ph_ESMoL OutPort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutPort_cross_ph_ESMoL OutPort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutPort_cross_ph_ESMoL OutPort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutPort_cross_ph_ESMoL> OutPort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< OutPort_cross_ph_ESMoL>(impl); }
	OutPort_cross_ph_ESMoL OutPort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutPort_cross_ph_ESMoL> OutPort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< OutPort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< OutPort_cross_ph_ESMoL> OutPort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< OutPort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> OutPort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OutPort_cross_ph_ESMoL::meta;

	StatePort_cross_ph_ESMoL::StatePort_cross_ph_ESMoL() {}
	StatePort_cross_ph_ESMoL::StatePort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : OutPort_cross_ph_ESMoL(impl) {}
	StatePort_cross_ph_ESMoL::StatePort_cross_ph_ESMoL(const StatePort_cross_ph_ESMoL &master) : OutPort_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	StatePort_cross_ph_ESMoL::StatePort_cross_ph_ESMoL(StatePort_cross_ph_ESMoL &&master) : OutPort_cross_ph_ESMoL(master) {};

	StatePort_cross_ph_ESMoL StatePort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StatePort_cross_ph_ESMoL& StatePort_cross_ph_ESMoL::operator=(StatePort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StatePort_cross_ph_ESMoL StatePort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StatePort_cross_ph_ESMoL StatePort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StatePort_cross_ph_ESMoL StatePort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StatePort_cross_ph_ESMoL> StatePort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< StatePort_cross_ph_ESMoL>(impl); }
	StatePort_cross_ph_ESMoL StatePort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StatePort_cross_ph_ESMoL> StatePort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< StatePort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< StatePort_cross_ph_ESMoL> StatePort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< StatePort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> StatePort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StatePort_cross_ph_ESMoL::meta;

	Port_cross_ph_ESMoL::Port_cross_ph_ESMoL() {}
	Port_cross_ph_ESMoL::Port_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Port_cross_ph_ESMoL::Port_cross_ph_ESMoL(const Port_cross_ph_ESMoL &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Port_cross_ph_ESMoL::Port_cross_ph_ESMoL(Port_cross_ph_ESMoL &&master) : UDM_OBJECT(master) {};

	Port_cross_ph_ESMoL Port_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Port_cross_ph_ESMoL& Port_cross_ph_ESMoL::operator=(Port_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Port_cross_ph_ESMoL Port_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Port_cross_ph_ESMoL Port_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Port_cross_ph_ESMoL Port_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Port_cross_ph_ESMoL> Port_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< Port_cross_ph_ESMoL>(impl); }
	Port_cross_ph_ESMoL Port_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Port_cross_ph_ESMoL> Port_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< Port_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< Port_cross_ph_ESMoL> Port_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< Port_cross_ph_ESMoL>(impl); }
	::Udm::StringAttr Port_cross_ph_ESMoL::rem_sysname() const { return ::Udm::StringAttr(impl, meta_rem_sysname); }
	::Udm::IntegerAttr Port_cross_ph_ESMoL::rem_id() const { return ::Udm::IntegerAttr(impl, meta_rem_id); }
	::Udm::AssocAttr< Arg_cross_ph_SFC> Port_cross_ph_ESMoL::arg() const { return ::Udm::AssocAttr< Arg_cross_ph_SFC>(impl, meta_arg); }
	::Udm::PointerAttr< ArgDeclBase_cross_ph_SFC> Port_cross_ph_ESMoL::argdecl() const { return ::Udm::PointerAttr< ArgDeclBase_cross_ph_SFC>(impl, meta_argdecl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Port_cross_ph_ESMoL::Port_cross_ph_ESMoL_parentrole() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, meta_Port_cross_ph_ESMoL_parentrole); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Port_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Port_cross_ph_ESMoL::meta;
	::Uml::Attribute Port_cross_ph_ESMoL::meta_rem_sysname;
	::Uml::Attribute Port_cross_ph_ESMoL::meta_rem_id;
	::Uml::AssociationRole Port_cross_ph_ESMoL::meta_arg;
	::Uml::AssociationRole Port_cross_ph_ESMoL::meta_argdecl;
	::Uml::CompositionParentRole Port_cross_ph_ESMoL::meta_Port_cross_ph_ESMoL_parentrole;

	EnablePort_cross_ph_ESMoL::EnablePort_cross_ph_ESMoL() {}
	EnablePort_cross_ph_ESMoL::EnablePort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : InPort_cross_ph_ESMoL(impl) {}
	EnablePort_cross_ph_ESMoL::EnablePort_cross_ph_ESMoL(const EnablePort_cross_ph_ESMoL &master) : InPort_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	EnablePort_cross_ph_ESMoL::EnablePort_cross_ph_ESMoL(EnablePort_cross_ph_ESMoL &&master) : InPort_cross_ph_ESMoL(master) {};

	EnablePort_cross_ph_ESMoL EnablePort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	EnablePort_cross_ph_ESMoL& EnablePort_cross_ph_ESMoL::operator=(EnablePort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	EnablePort_cross_ph_ESMoL EnablePort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	EnablePort_cross_ph_ESMoL EnablePort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	EnablePort_cross_ph_ESMoL EnablePort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< EnablePort_cross_ph_ESMoL> EnablePort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< EnablePort_cross_ph_ESMoL>(impl); }
	EnablePort_cross_ph_ESMoL EnablePort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< EnablePort_cross_ph_ESMoL> EnablePort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< EnablePort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< EnablePort_cross_ph_ESMoL> EnablePort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< EnablePort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> EnablePort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class EnablePort_cross_ph_ESMoL::meta;

	TriggerPort_cross_ph_ESMoL::TriggerPort_cross_ph_ESMoL() {}
	TriggerPort_cross_ph_ESMoL::TriggerPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : InPort_cross_ph_ESMoL(impl) {}
	TriggerPort_cross_ph_ESMoL::TriggerPort_cross_ph_ESMoL(const TriggerPort_cross_ph_ESMoL &master) : InPort_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	TriggerPort_cross_ph_ESMoL::TriggerPort_cross_ph_ESMoL(TriggerPort_cross_ph_ESMoL &&master) : InPort_cross_ph_ESMoL(master) {};

	TriggerPort_cross_ph_ESMoL TriggerPort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TriggerPort_cross_ph_ESMoL& TriggerPort_cross_ph_ESMoL::operator=(TriggerPort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TriggerPort_cross_ph_ESMoL TriggerPort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TriggerPort_cross_ph_ESMoL TriggerPort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TriggerPort_cross_ph_ESMoL TriggerPort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TriggerPort_cross_ph_ESMoL> TriggerPort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< TriggerPort_cross_ph_ESMoL>(impl); }
	TriggerPort_cross_ph_ESMoL TriggerPort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TriggerPort_cross_ph_ESMoL> TriggerPort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< TriggerPort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< TriggerPort_cross_ph_ESMoL> TriggerPort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< TriggerPort_cross_ph_ESMoL>(impl); }
	::Udm::PointerAttr< LocalVar_cross_ph_SFC> TriggerPort_cross_ph_ESMoL::memb() const { return ::Udm::PointerAttr< LocalVar_cross_ph_SFC>(impl, meta_memb); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TriggerPort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TriggerPort_cross_ph_ESMoL::meta;
	::Uml::AssociationRole TriggerPort_cross_ph_ESMoL::meta_memb;

	InputPort_cross_ph_ESMoL::InputPort_cross_ph_ESMoL() {}
	InputPort_cross_ph_ESMoL::InputPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : InPort_cross_ph_ESMoL(impl) {}
	InputPort_cross_ph_ESMoL::InputPort_cross_ph_ESMoL(const InputPort_cross_ph_ESMoL &master) : InPort_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	InputPort_cross_ph_ESMoL::InputPort_cross_ph_ESMoL(InputPort_cross_ph_ESMoL &&master) : InPort_cross_ph_ESMoL(master) {};

	InputPort_cross_ph_ESMoL InputPort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	InputPort_cross_ph_ESMoL& InputPort_cross_ph_ESMoL::operator=(InputPort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	InputPort_cross_ph_ESMoL InputPort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	InputPort_cross_ph_ESMoL InputPort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	InputPort_cross_ph_ESMoL InputPort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< InputPort_cross_ph_ESMoL> InputPort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< InputPort_cross_ph_ESMoL>(impl); }
	InputPort_cross_ph_ESMoL InputPort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< InputPort_cross_ph_ESMoL> InputPort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< InputPort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< InputPort_cross_ph_ESMoL> InputPort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< InputPort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> InputPort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class InputPort_cross_ph_ESMoL::meta;

	InPort_cross_ph_ESMoL::InPort_cross_ph_ESMoL() {}
	InPort_cross_ph_ESMoL::InPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : Port_cross_ph_ESMoL(impl) {}
	InPort_cross_ph_ESMoL::InPort_cross_ph_ESMoL(const InPort_cross_ph_ESMoL &master) : Port_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	InPort_cross_ph_ESMoL::InPort_cross_ph_ESMoL(InPort_cross_ph_ESMoL &&master) : Port_cross_ph_ESMoL(master) {};

	InPort_cross_ph_ESMoL InPort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	InPort_cross_ph_ESMoL& InPort_cross_ph_ESMoL::operator=(InPort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	InPort_cross_ph_ESMoL InPort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	InPort_cross_ph_ESMoL InPort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	InPort_cross_ph_ESMoL InPort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< InPort_cross_ph_ESMoL> InPort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< InPort_cross_ph_ESMoL>(impl); }
	InPort_cross_ph_ESMoL InPort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< InPort_cross_ph_ESMoL> InPort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< InPort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< InPort_cross_ph_ESMoL> InPort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< InPort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> InPort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class InPort_cross_ph_ESMoL::meta;

	ActionPort_cross_ph_ESMoL::ActionPort_cross_ph_ESMoL() {}
	ActionPort_cross_ph_ESMoL::ActionPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl) : InPort_cross_ph_ESMoL(impl) {}
	ActionPort_cross_ph_ESMoL::ActionPort_cross_ph_ESMoL(const ActionPort_cross_ph_ESMoL &master) : InPort_cross_ph_ESMoL(master) {}

#ifdef UDM_RVALUE
	ActionPort_cross_ph_ESMoL::ActionPort_cross_ph_ESMoL(ActionPort_cross_ph_ESMoL &&master) : InPort_cross_ph_ESMoL(master) {};

	ActionPort_cross_ph_ESMoL ActionPort_cross_ph_ESMoL::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ActionPort_cross_ph_ESMoL& ActionPort_cross_ph_ESMoL::operator=(ActionPort_cross_ph_ESMoL &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ActionPort_cross_ph_ESMoL ActionPort_cross_ph_ESMoL::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ActionPort_cross_ph_ESMoL ActionPort_cross_ph_ESMoL::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ActionPort_cross_ph_ESMoL ActionPort_cross_ph_ESMoL::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ActionPort_cross_ph_ESMoL> ActionPort_cross_ph_ESMoL::Instances() { return ::Udm::InstantiatedAttr< ActionPort_cross_ph_ESMoL>(impl); }
	ActionPort_cross_ph_ESMoL ActionPort_cross_ph_ESMoL::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ActionPort_cross_ph_ESMoL> ActionPort_cross_ph_ESMoL::Derived() { return ::Udm::DerivedAttr< ActionPort_cross_ph_ESMoL>(impl); }
	::Udm::ArchetypeAttr< ActionPort_cross_ph_ESMoL> ActionPort_cross_ph_ESMoL::Archetype() const { return ::Udm::ArchetypeAttr< ActionPort_cross_ph_ESMoL>(impl); }
	::Udm::ParentAttr< ::ESM2SLC::_gen_cont> ActionPort_cross_ph_ESMoL::parent() const { return ::Udm::ParentAttr< ::ESM2SLC::_gen_cont>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ActionPort_cross_ph_ESMoL::meta;

	::Uml::Diagram meta;

	void CreateMeta() {
		// classes, with attributes, constraints and constraint definitions
		ActionPort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		ArgDeclBase_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		ArgDeclBase_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(ArgDeclBase_cross_ph_SFC::meta);
		ArgDeclBase_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(ArgDeclBase_cross_ph_SFC::meta);

		Arg_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Array_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		BasicType_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Class_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		Class_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(Class_cross_ph_SFC::meta);
		Class_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(Class_cross_ph_SFC::meta);

		DT_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Declaration_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		EnablePort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		FunctionCall_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		FunctionCall_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(FunctionCall_cross_ph_SFC::meta);
		FunctionCall_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(FunctionCall_cross_ph_SFC::meta);

		Function_cross_ph_SFC::meta = ::Uml::Class::Create(meta);
		Function_cross_ph_SFC::meta_rem_sysname = ::Uml::Attribute::Create(Function_cross_ph_SFC::meta);
		Function_cross_ph_SFC::meta_rem_id = ::Uml::Attribute::Create(Function_cross_ph_SFC::meta);

		InPort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		InputPort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		LocalVar_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Matrix_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		OutPort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		OutputPort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		Parameter_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		Parameter_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(Parameter_cross_ph_ESMoL::meta);
		Parameter_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(Parameter_cross_ph_ESMoL::meta);

		Port_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		Port_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(Port_cross_ph_ESMoL::meta);
		Port_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(Port_cross_ph_ESMoL::meta);

		Primitive_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		Primitive_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(Primitive_cross_ph_ESMoL::meta);
		Primitive_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(Primitive_cross_ph_ESMoL::meta);

		StateLabel_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		StatePort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		StateVar_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Struct_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		Subsystem_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		Subsystem_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(Subsystem_cross_ph_ESMoL::meta);
		Subsystem_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(Subsystem_cross_ph_ESMoL::meta);

		TriggerPort_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		TypeBaseRef_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(TypeBaseRef_cross_ph_ESMoL::meta);
		TypeBaseRef_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(TypeBaseRef_cross_ph_ESMoL::meta);

		TypeBase_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);
		TypeBase_cross_ph_ESMoL::meta_rem_sysname = ::Uml::Attribute::Create(TypeBase_cross_ph_ESMoL::meta);
		TypeBase_cross_ph_ESMoL::meta_rem_id = ::Uml::Attribute::Create(TypeBase_cross_ph_ESMoL::meta);

		TypeStruct_cross_ph_ESMoL::meta = ::Uml::Class::Create(meta);

		Var_cross_ph_SFC::meta = ::Uml::Class::Create(meta);

		_gen_cont::meta = ::Uml::Class::Create(meta);

	}

	void InitMeta() {
		// classes, with attributes, constraints and constraint definitions
		::Uml::InitClassProps(ActionPort_cross_ph_ESMoL::meta, "ActionPort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(ArgDeclBase_cross_ph_SFC::meta, "ArgDeclBase_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(ArgDeclBase_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ArgDeclBase_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Arg_cross_ph_SFC::meta, "Arg_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Array_cross_ph_SFC::meta, "Array_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(BasicType_cross_ph_SFC::meta, "BasicType_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Class_cross_ph_SFC::meta, "Class_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(Class_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Class_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(DT_cross_ph_SFC::meta, "DT_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Declaration_cross_ph_SFC::meta, "Declaration_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(EnablePort_cross_ph_ESMoL::meta, "EnablePort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(FunctionCall_cross_ph_SFC::meta, "FunctionCall_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(FunctionCall_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(FunctionCall_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Function_cross_ph_SFC::meta, "Function_cross_ph_SFC", false, NULL, "SFC");
		::Uml::InitAttributeProps(Function_cross_ph_SFC::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Function_cross_ph_SFC::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(InPort_cross_ph_ESMoL::meta, "InPort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(InputPort_cross_ph_ESMoL::meta, "InputPort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(LocalVar_cross_ph_SFC::meta, "LocalVar_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Matrix_cross_ph_ESMoL::meta, "Matrix_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(OutPort_cross_ph_ESMoL::meta, "OutPort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(OutputPort_cross_ph_ESMoL::meta, "OutputPort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(Parameter_cross_ph_ESMoL::meta, "Parameter_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(Parameter_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Parameter_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Port_cross_ph_ESMoL::meta, "Port_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(Port_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Port_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Primitive_cross_ph_ESMoL::meta, "Primitive_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(Primitive_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Primitive_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(StateLabel_cross_ph_SFC::meta, "StateLabel_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(StatePort_cross_ph_ESMoL::meta, "StatePort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(StateVar_cross_ph_SFC::meta, "StateVar_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Struct_cross_ph_SFC::meta, "Struct_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(Subsystem_cross_ph_ESMoL::meta, "Subsystem_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(Subsystem_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Subsystem_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TriggerPort_cross_ph_ESMoL::meta, "TriggerPort_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(TypeBaseRef_cross_ph_ESMoL::meta, "TypeBaseRef_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(TypeBaseRef_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TypeBase_cross_ph_ESMoL::meta, "TypeBase_cross_ph_ESMoL", false, NULL, "ESMoL");
		::Uml::InitAttributeProps(TypeBase_cross_ph_ESMoL::meta_rem_sysname, "rem_sysname", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(TypeBase_cross_ph_ESMoL::meta_rem_id, "rem_id", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TypeStruct_cross_ph_ESMoL::meta, "TypeStruct_cross_ph_ESMoL", false, NULL, "ESMoL");

		::Uml::InitClassProps(Var_cross_ph_SFC::meta, "Var_cross_ph_SFC", false, NULL, "SFC");

		::Uml::InitClassProps(_gen_cont::meta, "_gen_cont", false, NULL, NULL);

		// associations
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Arg_cross_ph_SFC::meta_initparam = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Arg_cross_ph_SFC::meta_initparam, "initparam", true, false, 0, 1);
			Parameter_cross_ph_ESMoL::meta_arg = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Parameter_cross_ph_ESMoL::meta_arg, "arg", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Arg_cross_ph_SFC::meta_port = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Arg_cross_ph_SFC::meta_port, "port", true, false, 0, -1);
			Port_cross_ph_ESMoL::meta_arg = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Port_cross_ph_ESMoL::meta_arg, "arg", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_sysinit = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_sysinit, "sysinit", true, false, 0, 1);
			Subsystem_cross_ph_ESMoL::meta_init = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Subsystem_cross_ph_ESMoL::meta_init, "init", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Function_cross_ph_SFC::meta_sysmain = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Function_cross_ph_SFC::meta_sysmain, "sysmain", true, false, 0, -1);
			Subsystem_cross_ph_ESMoL::meta_main = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Subsystem_cross_ph_ESMoL::meta_main, "main", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_pstrct = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_pstrct, "pstrct", true, false, 0, 1);
			Struct_cross_ph_SFC::meta_pmemb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Struct_cross_ph_SFC::meta_pmemb, "pmemb", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_trigvar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_trigvar, "trigvar", true, false, 0, 1);
			LocalVar_cross_ph_SFC::meta_oldvar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_oldvar, "oldvar", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_trig = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_trig, "trig", true, false, 0, -1);
			TriggerPort_cross_ph_ESMoL::meta_memb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TriggerPort_cross_ph_ESMoL::meta_memb, "memb", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_sys = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_sys, "sys", true, false, 0, -1);
			Subsystem_cross_ph_ESMoL::meta_memb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Subsystem_cross_ph_ESMoL::meta_memb, "memb", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_param = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_param, "param", true, false, 0, -1);
			Parameter_cross_ph_ESMoL::meta_memb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Parameter_cross_ph_ESMoL::meta_memb, "memb", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			LocalVar_cross_ph_SFC::meta_tbr = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_tbr, "tbr", true, false, 0, 1);
			TypeBaseRef_cross_ph_ESMoL::meta_lvar = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypeBaseRef_cross_ph_ESMoL::meta_lvar, "lvar", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			FunctionCall_cross_ph_SFC::meta_obj = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FunctionCall_cross_ph_SFC::meta_obj, "obj", true, false, 0, 1);
			Subsystem_cross_ph_ESMoL::meta_mcall = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Subsystem_cross_ph_ESMoL::meta_mcall, "mcall", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			DT_cross_ph_SFC::meta_tb = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(DT_cross_ph_SFC::meta_tb, "tb", true, false, 0, 1);
			TypeBase_cross_ph_ESMoL::meta_dt = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypeBase_cross_ph_ESMoL::meta_dt, "dt", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Class_cross_ph_SFC::meta_equivdst = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Class_cross_ph_SFC::meta_equivdst, "equivdst", true, false, 0, -1);
			Class_cross_ph_SFC::meta_equivsrc = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Class_cross_ph_SFC::meta_equivsrc, "equivsrc", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Primitive_cross_ph_ESMoL::meta_ifval = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Primitive_cross_ph_ESMoL::meta_ifval, "ifval", true, false, 0, 1);
			LocalVar_cross_ph_SFC::meta_ifblock = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(LocalVar_cross_ph_SFC::meta_ifblock, "ifblock", true, false, 0, 1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Subsystem_cross_ph_ESMoL::meta_cls = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Subsystem_cross_ph_ESMoL::meta_cls, "cls", true, false, 0, 1);
			Class_cross_ph_SFC::meta_obj = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Class_cross_ph_SFC::meta_obj, "obj", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Association");
			Port_cross_ph_ESMoL::meta_argdecl = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Port_cross_ph_ESMoL::meta_argdecl, "argdecl", true, false, 0, 1);
			ArgDeclBase_cross_ph_SFC::meta_port = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ArgDeclBase_cross_ph_SFC::meta_port, "port", true, false, 0, -1);

		}

		// compositions
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole, "Function_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_Function_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Function_cross_ph_SFC_childrole, "Function_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FunctionCall_cross_ph_SFC::meta_FunctionCall_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FunctionCall_cross_ph_SFC::meta_FunctionCall_cross_ph_SFC_parentrole, "FunctionCall_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_FunctionCall_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_FunctionCall_cross_ph_SFC_childrole, "FunctionCall_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole, "ArgDeclBase_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole, "ArgDeclBase_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole, "Class_cross_ph_SFC_parentrole", true);
			_gen_cont::meta_Class_cross_ph_SFC_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Class_cross_ph_SFC_childrole, "Class_cross_ph_SFC_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole, "TypeBase_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole, "TypeBase_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole, "TypeBaseRef_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole, "TypeBaseRef_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Primitive_cross_ph_ESMoL::meta_Primitive_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Primitive_cross_ph_ESMoL::meta_Primitive_cross_ph_ESMoL_parentrole, "Primitive_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_Primitive_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Primitive_cross_ph_ESMoL_childrole, "Primitive_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Parameter_cross_ph_ESMoL::meta_Parameter_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Parameter_cross_ph_ESMoL::meta_Parameter_cross_ph_ESMoL_parentrole, "Parameter_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_Parameter_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Parameter_cross_ph_ESMoL_childrole, "Parameter_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Subsystem_cross_ph_ESMoL::meta_Subsystem_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Subsystem_cross_ph_ESMoL::meta_Subsystem_cross_ph_ESMoL_parentrole, "Subsystem_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_Subsystem_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Subsystem_cross_ph_ESMoL_childrole, "Subsystem_cross_ph_ESMoL_childrole", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Port_cross_ph_ESMoL::meta_Port_cross_ph_ESMoL_parentrole = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Port_cross_ph_ESMoL::meta_Port_cross_ph_ESMoL_parentrole, "Port_cross_ph_ESMoL_parentrole", true);
			_gen_cont::meta_Port_cross_ph_ESMoL_childrole = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(_gen_cont::meta_Port_cross_ph_ESMoL_childrole, "Port_cross_ph_ESMoL_childrole", true, 0, -1);

		}

	}

	void InitMetaLinks() {
		ArgDeclBase_cross_ph_SFC::meta_port.target() = Port_cross_ph_ESMoL::meta;
		_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole.target() = ArgDeclBase_cross_ph_SFC::meta;
		ArgDeclBase_cross_ph_SFC::meta.subTypes() += Arg_cross_ph_SFC::meta;
		ArgDeclBase_cross_ph_SFC::meta.subTypes() += Declaration_cross_ph_SFC::meta;

		Arg_cross_ph_SFC::meta_initparam.target() = Parameter_cross_ph_ESMoL::meta;
		Arg_cross_ph_SFC::meta_port.target() = Port_cross_ph_ESMoL::meta;

		Class_cross_ph_SFC::meta_equivdst.target() = Class_cross_ph_SFC::meta;
		Class_cross_ph_SFC::meta_equivsrc.target() = Class_cross_ph_SFC::meta;
		Class_cross_ph_SFC::meta_obj.target() = Subsystem_cross_ph_ESMoL::meta;
		_gen_cont::meta_Class_cross_ph_SFC_childrole.target() = Class_cross_ph_SFC::meta;

		DT_cross_ph_SFC::meta_tb.target() = TypeBase_cross_ph_ESMoL::meta;
		DT_cross_ph_SFC::meta.subTypes() += Struct_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += Array_cross_ph_SFC::meta;
		DT_cross_ph_SFC::meta.subTypes() += BasicType_cross_ph_SFC::meta;

		Declaration_cross_ph_SFC::meta.subTypes() += StateLabel_cross_ph_SFC::meta;
		Declaration_cross_ph_SFC::meta.subTypes() += Var_cross_ph_SFC::meta;
		Declaration_cross_ph_SFC::meta.subTypes() += DT_cross_ph_SFC::meta;

		FunctionCall_cross_ph_SFC::meta_obj.target() = Subsystem_cross_ph_ESMoL::meta;
		_gen_cont::meta_FunctionCall_cross_ph_SFC_childrole.target() = FunctionCall_cross_ph_SFC::meta;

		Function_cross_ph_SFC::meta_sysinit.target() = Subsystem_cross_ph_ESMoL::meta;
		Function_cross_ph_SFC::meta_sysmain.target() = Subsystem_cross_ph_ESMoL::meta;
		_gen_cont::meta_Function_cross_ph_SFC_childrole.target() = Function_cross_ph_SFC::meta;

		InPort_cross_ph_ESMoL::meta.subTypes() += EnablePort_cross_ph_ESMoL::meta;
		InPort_cross_ph_ESMoL::meta.subTypes() += TriggerPort_cross_ph_ESMoL::meta;
		InPort_cross_ph_ESMoL::meta.subTypes() += InputPort_cross_ph_ESMoL::meta;
		InPort_cross_ph_ESMoL::meta.subTypes() += ActionPort_cross_ph_ESMoL::meta;

		LocalVar_cross_ph_SFC::meta_pstrct.target() = Struct_cross_ph_SFC::meta;
		LocalVar_cross_ph_SFC::meta_trigvar.target() = LocalVar_cross_ph_SFC::meta;
		LocalVar_cross_ph_SFC::meta_oldvar.target() = LocalVar_cross_ph_SFC::meta;
		LocalVar_cross_ph_SFC::meta_trig.target() = TriggerPort_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_sys.target() = Subsystem_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_param.target() = Parameter_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_tbr.target() = TypeBaseRef_cross_ph_ESMoL::meta;
		LocalVar_cross_ph_SFC::meta_ifblock.target() = Primitive_cross_ph_ESMoL::meta;

		OutPort_cross_ph_ESMoL::meta.subTypes() += OutputPort_cross_ph_ESMoL::meta;
		OutPort_cross_ph_ESMoL::meta.subTypes() += StatePort_cross_ph_ESMoL::meta;

		Parameter_cross_ph_ESMoL::meta_arg.target() = Arg_cross_ph_SFC::meta;
		Parameter_cross_ph_ESMoL::meta_memb.target() = LocalVar_cross_ph_SFC::meta;
		_gen_cont::meta_Parameter_cross_ph_ESMoL_childrole.target() = Parameter_cross_ph_ESMoL::meta;

		Port_cross_ph_ESMoL::meta_arg.target() = Arg_cross_ph_SFC::meta;
		Port_cross_ph_ESMoL::meta_argdecl.target() = ArgDeclBase_cross_ph_SFC::meta;
		_gen_cont::meta_Port_cross_ph_ESMoL_childrole.target() = Port_cross_ph_ESMoL::meta;
		Port_cross_ph_ESMoL::meta.subTypes() += OutPort_cross_ph_ESMoL::meta;
		Port_cross_ph_ESMoL::meta.subTypes() += InPort_cross_ph_ESMoL::meta;

		Primitive_cross_ph_ESMoL::meta_ifval.target() = LocalVar_cross_ph_SFC::meta;
		_gen_cont::meta_Primitive_cross_ph_ESMoL_childrole.target() = Primitive_cross_ph_ESMoL::meta;

		Struct_cross_ph_SFC::meta_pmemb.target() = LocalVar_cross_ph_SFC::meta;

		Subsystem_cross_ph_ESMoL::meta_init.target() = Function_cross_ph_SFC::meta;
		Subsystem_cross_ph_ESMoL::meta_main.target() = Function_cross_ph_SFC::meta;
		Subsystem_cross_ph_ESMoL::meta_memb.target() = LocalVar_cross_ph_SFC::meta;
		Subsystem_cross_ph_ESMoL::meta_mcall.target() = FunctionCall_cross_ph_SFC::meta;
		Subsystem_cross_ph_ESMoL::meta_cls.target() = Class_cross_ph_SFC::meta;
		_gen_cont::meta_Subsystem_cross_ph_ESMoL_childrole.target() = Subsystem_cross_ph_ESMoL::meta;

		TriggerPort_cross_ph_ESMoL::meta_memb.target() = LocalVar_cross_ph_SFC::meta;

		TypeBaseRef_cross_ph_ESMoL::meta_lvar.target() = LocalVar_cross_ph_SFC::meta;
		_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole.target() = TypeBaseRef_cross_ph_ESMoL::meta;

		TypeBase_cross_ph_ESMoL::meta_dt.target() = DT_cross_ph_SFC::meta;
		_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole.target() = TypeBase_cross_ph_ESMoL::meta;
		TypeBase_cross_ph_ESMoL::meta.subTypes() += TypeStruct_cross_ph_ESMoL::meta;
		TypeBase_cross_ph_ESMoL::meta.subTypes() += Matrix_cross_ph_ESMoL::meta;

		Var_cross_ph_SFC::meta.subTypes() += LocalVar_cross_ph_SFC::meta;
		Var_cross_ph_SFC::meta.subTypes() += StateVar_cross_ph_SFC::meta;

		Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		FunctionCall_cross_ph_SFC::meta_FunctionCall_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole.target() = _gen_cont::meta;
		TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		Primitive_cross_ph_ESMoL::meta_Primitive_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		Parameter_cross_ph_ESMoL::meta_Parameter_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		Subsystem_cross_ph_ESMoL::meta_Subsystem_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;
		Port_cross_ph_ESMoL::meta_Port_cross_ph_ESMoL_parentrole.target() = _gen_cont::meta;

	}

	void InitMeta(const ::Uml::Diagram &parent) {
		// classes, with attributes, constraints and constraint definitions
		::Uml::SetClass(ActionPort_cross_ph_ESMoL::meta, parent, "ActionPort_cross_ph_ESMoL");

		::Uml::SetClass(ArgDeclBase_cross_ph_SFC::meta, parent, "ArgDeclBase_cross_ph_SFC");
		::Uml::SetAttribute(ArgDeclBase_cross_ph_SFC::meta_rem_sysname, ArgDeclBase_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(ArgDeclBase_cross_ph_SFC::meta_rem_id, ArgDeclBase_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(Arg_cross_ph_SFC::meta, parent, "Arg_cross_ph_SFC");

		::Uml::SetClass(Array_cross_ph_SFC::meta, parent, "Array_cross_ph_SFC");

		::Uml::SetClass(BasicType_cross_ph_SFC::meta, parent, "BasicType_cross_ph_SFC");

		::Uml::SetClass(Class_cross_ph_SFC::meta, parent, "Class_cross_ph_SFC");
		::Uml::SetAttribute(Class_cross_ph_SFC::meta_rem_sysname, Class_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(Class_cross_ph_SFC::meta_rem_id, Class_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(DT_cross_ph_SFC::meta, parent, "DT_cross_ph_SFC");

		::Uml::SetClass(Declaration_cross_ph_SFC::meta, parent, "Declaration_cross_ph_SFC");

		::Uml::SetClass(EnablePort_cross_ph_ESMoL::meta, parent, "EnablePort_cross_ph_ESMoL");

		::Uml::SetClass(FunctionCall_cross_ph_SFC::meta, parent, "FunctionCall_cross_ph_SFC");
		::Uml::SetAttribute(FunctionCall_cross_ph_SFC::meta_rem_sysname, FunctionCall_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(FunctionCall_cross_ph_SFC::meta_rem_id, FunctionCall_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(Function_cross_ph_SFC::meta, parent, "Function_cross_ph_SFC");
		::Uml::SetAttribute(Function_cross_ph_SFC::meta_rem_sysname, Function_cross_ph_SFC::meta, "rem_sysname");
		::Uml::SetAttribute(Function_cross_ph_SFC::meta_rem_id, Function_cross_ph_SFC::meta, "rem_id");

		::Uml::SetClass(InPort_cross_ph_ESMoL::meta, parent, "InPort_cross_ph_ESMoL");

		::Uml::SetClass(InputPort_cross_ph_ESMoL::meta, parent, "InputPort_cross_ph_ESMoL");

		::Uml::SetClass(LocalVar_cross_ph_SFC::meta, parent, "LocalVar_cross_ph_SFC");

		::Uml::SetClass(Matrix_cross_ph_ESMoL::meta, parent, "Matrix_cross_ph_ESMoL");

		::Uml::SetClass(OutPort_cross_ph_ESMoL::meta, parent, "OutPort_cross_ph_ESMoL");

		::Uml::SetClass(OutputPort_cross_ph_ESMoL::meta, parent, "OutputPort_cross_ph_ESMoL");

		::Uml::SetClass(Parameter_cross_ph_ESMoL::meta, parent, "Parameter_cross_ph_ESMoL");
		::Uml::SetAttribute(Parameter_cross_ph_ESMoL::meta_rem_sysname, Parameter_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(Parameter_cross_ph_ESMoL::meta_rem_id, Parameter_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(Port_cross_ph_ESMoL::meta, parent, "Port_cross_ph_ESMoL");
		::Uml::SetAttribute(Port_cross_ph_ESMoL::meta_rem_sysname, Port_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(Port_cross_ph_ESMoL::meta_rem_id, Port_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(Primitive_cross_ph_ESMoL::meta, parent, "Primitive_cross_ph_ESMoL");
		::Uml::SetAttribute(Primitive_cross_ph_ESMoL::meta_rem_sysname, Primitive_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(Primitive_cross_ph_ESMoL::meta_rem_id, Primitive_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(StateLabel_cross_ph_SFC::meta, parent, "StateLabel_cross_ph_SFC");

		::Uml::SetClass(StatePort_cross_ph_ESMoL::meta, parent, "StatePort_cross_ph_ESMoL");

		::Uml::SetClass(StateVar_cross_ph_SFC::meta, parent, "StateVar_cross_ph_SFC");

		::Uml::SetClass(Struct_cross_ph_SFC::meta, parent, "Struct_cross_ph_SFC");

		::Uml::SetClass(Subsystem_cross_ph_ESMoL::meta, parent, "Subsystem_cross_ph_ESMoL");
		::Uml::SetAttribute(Subsystem_cross_ph_ESMoL::meta_rem_sysname, Subsystem_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(Subsystem_cross_ph_ESMoL::meta_rem_id, Subsystem_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(TriggerPort_cross_ph_ESMoL::meta, parent, "TriggerPort_cross_ph_ESMoL");

		::Uml::SetClass(TypeBaseRef_cross_ph_ESMoL::meta, parent, "TypeBaseRef_cross_ph_ESMoL");
		::Uml::SetAttribute(TypeBaseRef_cross_ph_ESMoL::meta_rem_sysname, TypeBaseRef_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(TypeBaseRef_cross_ph_ESMoL::meta_rem_id, TypeBaseRef_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(TypeBase_cross_ph_ESMoL::meta, parent, "TypeBase_cross_ph_ESMoL");
		::Uml::SetAttribute(TypeBase_cross_ph_ESMoL::meta_rem_sysname, TypeBase_cross_ph_ESMoL::meta, "rem_sysname");
		::Uml::SetAttribute(TypeBase_cross_ph_ESMoL::meta_rem_id, TypeBase_cross_ph_ESMoL::meta, "rem_id");

		::Uml::SetClass(TypeStruct_cross_ph_ESMoL::meta, parent, "TypeStruct_cross_ph_ESMoL");

		::Uml::SetClass(Var_cross_ph_SFC::meta, parent, "Var_cross_ph_SFC");

		::Uml::SetClass(_gen_cont::meta, parent, "_gen_cont");

	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
		// classes
		::Uml::SetAssocRole(ArgDeclBase_cross_ph_SFC::meta_port, ArgDeclBase_cross_ph_SFC::meta, Port_cross_ph_ESMoL::meta, "argdecl");
		::Uml::SetParentRole(ArgDeclBase_cross_ph_SFC::meta_ArgDeclBase_cross_ph_SFC_parentrole, ArgDeclBase_cross_ph_SFC::meta, _gen_cont::meta, "ArgDeclBase_cross_ph_SFC_childrole", "ArgDeclBase_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(Arg_cross_ph_SFC::meta_initparam, Arg_cross_ph_SFC::meta, Parameter_cross_ph_ESMoL::meta, "arg");
		::Uml::SetAssocRole(Arg_cross_ph_SFC::meta_port, Arg_cross_ph_SFC::meta, Port_cross_ph_ESMoL::meta, "arg");

		::Uml::SetAssocRole(Class_cross_ph_SFC::meta_equivdst, Class_cross_ph_SFC::meta, Class_cross_ph_SFC::meta, "equivsrc");
		::Uml::SetAssocRole(Class_cross_ph_SFC::meta_equivsrc, Class_cross_ph_SFC::meta, Class_cross_ph_SFC::meta, "equivdst");
		::Uml::SetAssocRole(Class_cross_ph_SFC::meta_obj, Class_cross_ph_SFC::meta, Subsystem_cross_ph_ESMoL::meta, "cls");
		::Uml::SetParentRole(Class_cross_ph_SFC::meta_Class_cross_ph_SFC_parentrole, Class_cross_ph_SFC::meta, _gen_cont::meta, "Class_cross_ph_SFC_childrole", "Class_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(DT_cross_ph_SFC::meta_tb, DT_cross_ph_SFC::meta, TypeBase_cross_ph_ESMoL::meta, "dt");

		::Uml::SetAssocRole(FunctionCall_cross_ph_SFC::meta_obj, FunctionCall_cross_ph_SFC::meta, Subsystem_cross_ph_ESMoL::meta, "mcall");
		::Uml::SetParentRole(FunctionCall_cross_ph_SFC::meta_FunctionCall_cross_ph_SFC_parentrole, FunctionCall_cross_ph_SFC::meta, _gen_cont::meta, "FunctionCall_cross_ph_SFC_childrole", "FunctionCall_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_sysinit, Function_cross_ph_SFC::meta, Subsystem_cross_ph_ESMoL::meta, "init");
		::Uml::SetAssocRole(Function_cross_ph_SFC::meta_sysmain, Function_cross_ph_SFC::meta, Subsystem_cross_ph_ESMoL::meta, "main");
		::Uml::SetParentRole(Function_cross_ph_SFC::meta_Function_cross_ph_SFC_parentrole, Function_cross_ph_SFC::meta, _gen_cont::meta, "Function_cross_ph_SFC_childrole", "Function_cross_ph_SFC_parentrole");

		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_pstrct, LocalVar_cross_ph_SFC::meta, Struct_cross_ph_SFC::meta, "pmemb");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_trigvar, LocalVar_cross_ph_SFC::meta, LocalVar_cross_ph_SFC::meta, "oldvar");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_oldvar, LocalVar_cross_ph_SFC::meta, LocalVar_cross_ph_SFC::meta, "trigvar");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_trig, LocalVar_cross_ph_SFC::meta, TriggerPort_cross_ph_ESMoL::meta, "memb");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_sys, LocalVar_cross_ph_SFC::meta, Subsystem_cross_ph_ESMoL::meta, "memb");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_param, LocalVar_cross_ph_SFC::meta, Parameter_cross_ph_ESMoL::meta, "memb");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_tbr, LocalVar_cross_ph_SFC::meta, TypeBaseRef_cross_ph_ESMoL::meta, "lvar");
		::Uml::SetAssocRole(LocalVar_cross_ph_SFC::meta_ifblock, LocalVar_cross_ph_SFC::meta, Primitive_cross_ph_ESMoL::meta, "ifval");

		::Uml::SetAssocRole(Parameter_cross_ph_ESMoL::meta_arg, Parameter_cross_ph_ESMoL::meta, Arg_cross_ph_SFC::meta, "initparam");
		::Uml::SetAssocRole(Parameter_cross_ph_ESMoL::meta_memb, Parameter_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "param");
		::Uml::SetParentRole(Parameter_cross_ph_ESMoL::meta_Parameter_cross_ph_ESMoL_parentrole, Parameter_cross_ph_ESMoL::meta, _gen_cont::meta, "Parameter_cross_ph_ESMoL_childrole", "Parameter_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(Port_cross_ph_ESMoL::meta_arg, Port_cross_ph_ESMoL::meta, Arg_cross_ph_SFC::meta, "port");
		::Uml::SetAssocRole(Port_cross_ph_ESMoL::meta_argdecl, Port_cross_ph_ESMoL::meta, ArgDeclBase_cross_ph_SFC::meta, "port");
		::Uml::SetParentRole(Port_cross_ph_ESMoL::meta_Port_cross_ph_ESMoL_parentrole, Port_cross_ph_ESMoL::meta, _gen_cont::meta, "Port_cross_ph_ESMoL_childrole", "Port_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(Primitive_cross_ph_ESMoL::meta_ifval, Primitive_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "ifblock");
		::Uml::SetParentRole(Primitive_cross_ph_ESMoL::meta_Primitive_cross_ph_ESMoL_parentrole, Primitive_cross_ph_ESMoL::meta, _gen_cont::meta, "Primitive_cross_ph_ESMoL_childrole", "Primitive_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(Struct_cross_ph_SFC::meta_pmemb, Struct_cross_ph_SFC::meta, LocalVar_cross_ph_SFC::meta, "pstrct");

		::Uml::SetAssocRole(Subsystem_cross_ph_ESMoL::meta_init, Subsystem_cross_ph_ESMoL::meta, Function_cross_ph_SFC::meta, "sysinit");
		::Uml::SetAssocRole(Subsystem_cross_ph_ESMoL::meta_main, Subsystem_cross_ph_ESMoL::meta, Function_cross_ph_SFC::meta, "sysmain");
		::Uml::SetAssocRole(Subsystem_cross_ph_ESMoL::meta_memb, Subsystem_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "sys");
		::Uml::SetAssocRole(Subsystem_cross_ph_ESMoL::meta_mcall, Subsystem_cross_ph_ESMoL::meta, FunctionCall_cross_ph_SFC::meta, "obj");
		::Uml::SetAssocRole(Subsystem_cross_ph_ESMoL::meta_cls, Subsystem_cross_ph_ESMoL::meta, Class_cross_ph_SFC::meta, "obj");
		::Uml::SetParentRole(Subsystem_cross_ph_ESMoL::meta_Subsystem_cross_ph_ESMoL_parentrole, Subsystem_cross_ph_ESMoL::meta, _gen_cont::meta, "Subsystem_cross_ph_ESMoL_childrole", "Subsystem_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(TriggerPort_cross_ph_ESMoL::meta_memb, TriggerPort_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "trig");

		::Uml::SetAssocRole(TypeBaseRef_cross_ph_ESMoL::meta_lvar, TypeBaseRef_cross_ph_ESMoL::meta, LocalVar_cross_ph_SFC::meta, "tbr");
		::Uml::SetParentRole(TypeBaseRef_cross_ph_ESMoL::meta_TypeBaseRef_cross_ph_ESMoL_parentrole, TypeBaseRef_cross_ph_ESMoL::meta, _gen_cont::meta, "TypeBaseRef_cross_ph_ESMoL_childrole", "TypeBaseRef_cross_ph_ESMoL_parentrole");

		::Uml::SetAssocRole(TypeBase_cross_ph_ESMoL::meta_dt, TypeBase_cross_ph_ESMoL::meta, DT_cross_ph_SFC::meta, "tb");
		::Uml::SetParentRole(TypeBase_cross_ph_ESMoL::meta_TypeBase_cross_ph_ESMoL_parentrole, TypeBase_cross_ph_ESMoL::meta, _gen_cont::meta, "TypeBase_cross_ph_ESMoL_childrole", "TypeBase_cross_ph_ESMoL_parentrole");

		::Uml::SetChildRole(_gen_cont::meta_Function_cross_ph_SFC_childrole, _gen_cont::meta, Function_cross_ph_SFC::meta, "Function_cross_ph_SFC_parentrole", "Function_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_FunctionCall_cross_ph_SFC_childrole, _gen_cont::meta, FunctionCall_cross_ph_SFC::meta, "FunctionCall_cross_ph_SFC_parentrole", "FunctionCall_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_ArgDeclBase_cross_ph_SFC_childrole, _gen_cont::meta, ArgDeclBase_cross_ph_SFC::meta, "ArgDeclBase_cross_ph_SFC_parentrole", "ArgDeclBase_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Class_cross_ph_SFC_childrole, _gen_cont::meta, Class_cross_ph_SFC::meta, "Class_cross_ph_SFC_parentrole", "Class_cross_ph_SFC_childrole");
		::Uml::SetChildRole(_gen_cont::meta_TypeBase_cross_ph_ESMoL_childrole, _gen_cont::meta, TypeBase_cross_ph_ESMoL::meta, "TypeBase_cross_ph_ESMoL_parentrole", "TypeBase_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_TypeBaseRef_cross_ph_ESMoL_childrole, _gen_cont::meta, TypeBaseRef_cross_ph_ESMoL::meta, "TypeBaseRef_cross_ph_ESMoL_parentrole", "TypeBaseRef_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Primitive_cross_ph_ESMoL_childrole, _gen_cont::meta, Primitive_cross_ph_ESMoL::meta, "Primitive_cross_ph_ESMoL_parentrole", "Primitive_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Parameter_cross_ph_ESMoL_childrole, _gen_cont::meta, Parameter_cross_ph_ESMoL::meta, "Parameter_cross_ph_ESMoL_parentrole", "Parameter_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Subsystem_cross_ph_ESMoL_childrole, _gen_cont::meta, Subsystem_cross_ph_ESMoL::meta, "Subsystem_cross_ph_ESMoL_parentrole", "Subsystem_cross_ph_ESMoL_childrole");
		::Uml::SetChildRole(_gen_cont::meta_Port_cross_ph_ESMoL_childrole, _gen_cont::meta, Port_cross_ph_ESMoL::meta, "Port_cross_ph_ESMoL_parentrole", "Port_cross_ph_ESMoL_childrole");

	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("ESM2SLC.xsd", ESM2SLC_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("ESM2SLC.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "ESM2SLC", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("ESM2SLC", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("ESM2SLC");
		}
	} __regUnUsed;

}

