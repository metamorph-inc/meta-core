#ifndef MOBIES_ESM2SLC_H
#define MOBIES_ESM2SLC_H

// header file ESM2SLC.h generated from diagram ESM2SLC
// generated with Udm version 3.31 on Mon Jul 23 16:50:56 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace ESM2SLC {

	extern ::Uml::Diagram meta;
	class _gen_cont;
	class Arg_cross_ph_SFC;
	class Function_cross_ph_SFC;
	class LocalVar_cross_ph_SFC;
	class StateVar_cross_ph_SFC;
	class StateLabel_cross_ph_SFC;
	class FunctionCall_cross_ph_SFC;
	class Var_cross_ph_SFC;
	class Declaration_cross_ph_SFC;
	class DT_cross_ph_SFC;
	class Struct_cross_ph_SFC;
	class ArgDeclBase_cross_ph_SFC;
	class Class_cross_ph_SFC;
	class Array_cross_ph_SFC;
	class BasicType_cross_ph_SFC;
	class TypeStruct_cross_ph_ESMoL;
	class Matrix_cross_ph_ESMoL;
	class TypeBase_cross_ph_ESMoL;
	class TypeBaseRef_cross_ph_ESMoL;
	class Primitive_cross_ph_ESMoL;
	class Parameter_cross_ph_ESMoL;
	class Subsystem_cross_ph_ESMoL;
	class OutputPort_cross_ph_ESMoL;
	class OutPort_cross_ph_ESMoL;
	class StatePort_cross_ph_ESMoL;
	class Port_cross_ph_ESMoL;
	class EnablePort_cross_ph_ESMoL;
	class TriggerPort_cross_ph_ESMoL;
	class InputPort_cross_ph_ESMoL;
	class InPort_cross_ph_ESMoL;
	class ActionPort_cross_ph_ESMoL;

	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

	class _gen_cont : public ::Udm::Object {
	public:
		_gen_cont();
		_gen_cont(::Udm::ObjectImpl *impl);
		_gen_cont(const _gen_cont &master);

#ifdef UDM_RVALUE
		_gen_cont(_gen_cont &&master);

		static _gen_cont Cast(::Udm::Object &&a);
		_gen_cont& operator=(_gen_cont &&a);

#endif
		static _gen_cont Cast(const ::Udm::Object &a);
		static _gen_cont Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		_gen_cont CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< _gen_cont> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< _gen_cont, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< _gen_cont, Pred>(impl); };
		_gen_cont CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< _gen_cont> Derived();
		template <class Pred> ::Udm::DerivedAttr< _gen_cont, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< _gen_cont, Pred>(impl); };
		::Udm::ArchetypeAttr< _gen_cont> Archetype() const;
		::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC> Function_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC, Pred> Function_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC, Pred>(impl, meta_Function_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC> FunctionCall_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC, Pred> FunctionCall_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC, Pred>(impl, meta_FunctionCall_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC, Pred> ArgDeclBase_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC, Pred>(impl, meta_ArgDeclBase_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC> Class_cross_ph_SFC_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC, Pred> Class_cross_ph_SFC_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC, Pred>(impl, meta_Class_cross_ph_SFC_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL, Pred> TypeBase_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL, Pred>(impl, meta_TypeBase_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL, Pred> TypeBaseRef_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL, Pred>(impl, meta_TypeBaseRef_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL> Primitive_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL, Pred> Primitive_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL, Pred>(impl, meta_Primitive_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL> Parameter_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL, Pred> Parameter_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL, Pred>(impl, meta_Parameter_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL> Subsystem_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL, Pred> Subsystem_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL, Pred>(impl, meta_Subsystem_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL> Port_cross_ph_ESMoL_childrole() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL, Pred> Port_cross_ph_ESMoL_childrole_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL, Pred>(impl, meta_Port_cross_ph_ESMoL_childrole); };
		::Udm::ChildrenAttr< ::ESM2SLC::Arg_cross_ph_SFC> Arg_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Arg_cross_ph_SFC, Pred> Arg_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Arg_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC> Function_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC, Pred> Function_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Function_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::LocalVar_cross_ph_SFC> LocalVar_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::LocalVar_cross_ph_SFC, Pred> LocalVar_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::LocalVar_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::StateVar_cross_ph_SFC> StateVar_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::StateVar_cross_ph_SFC, Pred> StateVar_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::StateVar_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::StateLabel_cross_ph_SFC> StateLabel_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::StateLabel_cross_ph_SFC, Pred> StateLabel_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::StateLabel_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC> FunctionCall_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC, Pred> FunctionCall_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::FunctionCall_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Var_cross_ph_SFC> Var_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Var_cross_ph_SFC, Pred> Var_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Var_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Declaration_cross_ph_SFC> Declaration_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Declaration_cross_ph_SFC, Pred> Declaration_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Declaration_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::DT_cross_ph_SFC> DT_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::DT_cross_ph_SFC, Pred> DT_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::DT_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Struct_cross_ph_SFC> Struct_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Struct_cross_ph_SFC, Pred> Struct_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Struct_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC> ArgDeclBase_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC, Pred> ArgDeclBase_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::ArgDeclBase_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC> Class_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC, Pred> Class_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Class_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Array_cross_ph_SFC> Array_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Array_cross_ph_SFC, Pred> Array_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Array_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::BasicType_cross_ph_SFC> BasicType_cross_ph_SFC_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::BasicType_cross_ph_SFC, Pred> BasicType_cross_ph_SFC_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::BasicType_cross_ph_SFC, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::TypeStruct_cross_ph_ESMoL> TypeStruct_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::TypeStruct_cross_ph_ESMoL, Pred> TypeStruct_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeStruct_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Matrix_cross_ph_ESMoL> Matrix_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Matrix_cross_ph_ESMoL, Pred> Matrix_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Matrix_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL> TypeBase_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL, Pred> TypeBase_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBase_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL> TypeBaseRef_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL, Pred> TypeBaseRef_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL> Primitive_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL, Pred> Primitive_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Primitive_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL> Parameter_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL, Pred> Parameter_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Parameter_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL> Subsystem_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL, Pred> Subsystem_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Subsystem_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::OutputPort_cross_ph_ESMoL> OutputPort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::OutputPort_cross_ph_ESMoL, Pred> OutputPort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::OutputPort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::OutPort_cross_ph_ESMoL> OutPort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::OutPort_cross_ph_ESMoL, Pred> OutPort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::OutPort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::StatePort_cross_ph_ESMoL> StatePort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::StatePort_cross_ph_ESMoL, Pred> StatePort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::StatePort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL> Port_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL, Pred> Port_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::Port_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::EnablePort_cross_ph_ESMoL> EnablePort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::EnablePort_cross_ph_ESMoL, Pred> EnablePort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::EnablePort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::TriggerPort_cross_ph_ESMoL> TriggerPort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::TriggerPort_cross_ph_ESMoL, Pred> TriggerPort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::TriggerPort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::InputPort_cross_ph_ESMoL> InputPort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::InputPort_cross_ph_ESMoL, Pred> InputPort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::InputPort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::InPort_cross_ph_ESMoL> InPort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::InPort_cross_ph_ESMoL, Pred> InPort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::InPort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESM2SLC::ActionPort_cross_ph_ESMoL> ActionPort_cross_ph_ESMoL_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESM2SLC::ActionPort_cross_ph_ESMoL, Pred> ActionPort_cross_ph_ESMoL_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESM2SLC::ActionPort_cross_ph_ESMoL, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_Function_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_FunctionCall_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_ArgDeclBase_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_Class_cross_ph_SFC_childrole;
		static ::Uml::CompositionChildRole meta_TypeBase_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_TypeBaseRef_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_Primitive_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_Parameter_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_Subsystem_cross_ph_ESMoL_childrole;
		static ::Uml::CompositionChildRole meta_Port_cross_ph_ESMoL_childrole;

	};

	class Function_cross_ph_SFC : public ::Udm::Object {
	public:
		Function_cross_ph_SFC();
		Function_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Function_cross_ph_SFC(const Function_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Function_cross_ph_SFC(Function_cross_ph_SFC &&master);

		static Function_cross_ph_SFC Cast(::Udm::Object &&a);
		Function_cross_ph_SFC& operator=(Function_cross_ph_SFC &&a);

#endif
		static Function_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Function_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Function_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Function_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Function_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Function_cross_ph_SFC, Pred>(impl); };
		Function_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Function_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Function_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Function_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Function_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< Subsystem_cross_ph_ESMoL> sysinit() const;
		::Udm::AssocAttr< Subsystem_cross_ph_ESMoL> sysmain() const;
		template <class Pred> ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL, Pred> sysmain_sorted(const Pred &) const { return ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL, Pred>(impl, meta_sysmain); };
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Function_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_sysinit;
		static ::Uml::AssociationRole meta_sysmain;
		static ::Uml::CompositionParentRole meta_Function_cross_ph_SFC_parentrole;

	};

	class FunctionCall_cross_ph_SFC : public ::Udm::Object {
	public:
		FunctionCall_cross_ph_SFC();
		FunctionCall_cross_ph_SFC(::Udm::ObjectImpl *impl);
		FunctionCall_cross_ph_SFC(const FunctionCall_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		FunctionCall_cross_ph_SFC(FunctionCall_cross_ph_SFC &&master);

		static FunctionCall_cross_ph_SFC Cast(::Udm::Object &&a);
		FunctionCall_cross_ph_SFC& operator=(FunctionCall_cross_ph_SFC &&a);

#endif
		static FunctionCall_cross_ph_SFC Cast(const ::Udm::Object &a);
		static FunctionCall_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FunctionCall_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FunctionCall_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FunctionCall_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FunctionCall_cross_ph_SFC, Pred>(impl); };
		FunctionCall_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FunctionCall_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< FunctionCall_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FunctionCall_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< FunctionCall_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< Subsystem_cross_ph_ESMoL> obj() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> FunctionCall_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_obj;
		static ::Uml::CompositionParentRole meta_FunctionCall_cross_ph_SFC_parentrole;

	};

	class ArgDeclBase_cross_ph_SFC : public ::Udm::Object {
	public:
		ArgDeclBase_cross_ph_SFC();
		ArgDeclBase_cross_ph_SFC(::Udm::ObjectImpl *impl);
		ArgDeclBase_cross_ph_SFC(const ArgDeclBase_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		ArgDeclBase_cross_ph_SFC(ArgDeclBase_cross_ph_SFC &&master);

		static ArgDeclBase_cross_ph_SFC Cast(::Udm::Object &&a);
		ArgDeclBase_cross_ph_SFC& operator=(ArgDeclBase_cross_ph_SFC &&a);

#endif
		static ArgDeclBase_cross_ph_SFC Cast(const ::Udm::Object &a);
		static ArgDeclBase_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ArgDeclBase_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ArgDeclBase_cross_ph_SFC, Pred>(impl); };
		ArgDeclBase_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ArgDeclBase_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< ArgDeclBase_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< Port_cross_ph_ESMoL> port() const;
		template <class Pred> ::Udm::AssocAttr< Port_cross_ph_ESMoL, Pred> port_sorted(const Pred &) const { return ::Udm::AssocAttr< Port_cross_ph_ESMoL, Pred>(impl, meta_port); };
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> ArgDeclBase_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_port;
		static ::Uml::CompositionParentRole meta_ArgDeclBase_cross_ph_SFC_parentrole;

	};

	class Arg_cross_ph_SFC :  public ArgDeclBase_cross_ph_SFC {
	public:
		Arg_cross_ph_SFC();
		Arg_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Arg_cross_ph_SFC(const Arg_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Arg_cross_ph_SFC(Arg_cross_ph_SFC &&master);

		static Arg_cross_ph_SFC Cast(::Udm::Object &&a);
		Arg_cross_ph_SFC& operator=(Arg_cross_ph_SFC &&a);

#endif
		static Arg_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Arg_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Arg_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Arg_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Arg_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Arg_cross_ph_SFC, Pred>(impl); };
		Arg_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Arg_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Arg_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Arg_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Arg_cross_ph_SFC> Archetype() const;
		::Udm::PointerAttr< Parameter_cross_ph_ESMoL> initparam() const;
		::Udm::AssocAttr< Port_cross_ph_ESMoL> port() const;
		template <class Pred> ::Udm::AssocAttr< Port_cross_ph_ESMoL, Pred> port_sorted(const Pred &) const { return ::Udm::AssocAttr< Port_cross_ph_ESMoL, Pred>(impl, meta_port); };
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_initparam;
		static ::Uml::AssociationRole meta_port;

	};

	class Declaration_cross_ph_SFC :  public ArgDeclBase_cross_ph_SFC {
	public:
		Declaration_cross_ph_SFC();
		Declaration_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Declaration_cross_ph_SFC(const Declaration_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Declaration_cross_ph_SFC(Declaration_cross_ph_SFC &&master);

		static Declaration_cross_ph_SFC Cast(::Udm::Object &&a);
		Declaration_cross_ph_SFC& operator=(Declaration_cross_ph_SFC &&a);

#endif
		static Declaration_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Declaration_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Declaration_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Declaration_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Declaration_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Declaration_cross_ph_SFC, Pred>(impl); };
		Declaration_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Declaration_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Declaration_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Declaration_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Declaration_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class StateLabel_cross_ph_SFC :  public Declaration_cross_ph_SFC {
	public:
		StateLabel_cross_ph_SFC();
		StateLabel_cross_ph_SFC(::Udm::ObjectImpl *impl);
		StateLabel_cross_ph_SFC(const StateLabel_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		StateLabel_cross_ph_SFC(StateLabel_cross_ph_SFC &&master);

		static StateLabel_cross_ph_SFC Cast(::Udm::Object &&a);
		StateLabel_cross_ph_SFC& operator=(StateLabel_cross_ph_SFC &&a);

#endif
		static StateLabel_cross_ph_SFC Cast(const ::Udm::Object &a);
		static StateLabel_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateLabel_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateLabel_cross_ph_SFC, Pred>(impl); };
		StateLabel_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateLabel_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateLabel_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateLabel_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< StateLabel_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Var_cross_ph_SFC :  public Declaration_cross_ph_SFC {
	public:
		Var_cross_ph_SFC();
		Var_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Var_cross_ph_SFC(const Var_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Var_cross_ph_SFC(Var_cross_ph_SFC &&master);

		static Var_cross_ph_SFC Cast(::Udm::Object &&a);
		Var_cross_ph_SFC& operator=(Var_cross_ph_SFC &&a);

#endif
		static Var_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Var_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Var_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Var_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Var_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Var_cross_ph_SFC, Pred>(impl); };
		Var_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Var_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Var_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Var_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Var_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class LocalVar_cross_ph_SFC :  public Var_cross_ph_SFC {
	public:
		LocalVar_cross_ph_SFC();
		LocalVar_cross_ph_SFC(::Udm::ObjectImpl *impl);
		LocalVar_cross_ph_SFC(const LocalVar_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		LocalVar_cross_ph_SFC(LocalVar_cross_ph_SFC &&master);

		static LocalVar_cross_ph_SFC Cast(::Udm::Object &&a);
		LocalVar_cross_ph_SFC& operator=(LocalVar_cross_ph_SFC &&a);

#endif
		static LocalVar_cross_ph_SFC Cast(const ::Udm::Object &a);
		static LocalVar_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		LocalVar_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< LocalVar_cross_ph_SFC, Pred>(impl); };
		LocalVar_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< LocalVar_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< LocalVar_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< LocalVar_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< LocalVar_cross_ph_SFC> Archetype() const;
		::Udm::PointerAttr< Struct_cross_ph_SFC> pstrct() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> trigvar() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> oldvar() const;
		::Udm::AssocAttr< TriggerPort_cross_ph_ESMoL> trig() const;
		template <class Pred> ::Udm::AssocAttr< TriggerPort_cross_ph_ESMoL, Pred> trig_sorted(const Pred &) const { return ::Udm::AssocAttr< TriggerPort_cross_ph_ESMoL, Pred>(impl, meta_trig); };
		::Udm::AssocAttr< Subsystem_cross_ph_ESMoL> sys() const;
		template <class Pred> ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL, Pred> sys_sorted(const Pred &) const { return ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL, Pred>(impl, meta_sys); };
		::Udm::AssocAttr< Parameter_cross_ph_ESMoL> param() const;
		template <class Pred> ::Udm::AssocAttr< Parameter_cross_ph_ESMoL, Pred> param_sorted(const Pred &) const { return ::Udm::AssocAttr< Parameter_cross_ph_ESMoL, Pred>(impl, meta_param); };
		::Udm::PointerAttr< TypeBaseRef_cross_ph_ESMoL> tbr() const;
		::Udm::PointerAttr< Primitive_cross_ph_ESMoL> ifblock() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_pstrct;
		static ::Uml::AssociationRole meta_trigvar;
		static ::Uml::AssociationRole meta_oldvar;
		static ::Uml::AssociationRole meta_trig;
		static ::Uml::AssociationRole meta_sys;
		static ::Uml::AssociationRole meta_param;
		static ::Uml::AssociationRole meta_tbr;
		static ::Uml::AssociationRole meta_ifblock;

	};

	class StateVar_cross_ph_SFC :  public Var_cross_ph_SFC {
	public:
		StateVar_cross_ph_SFC();
		StateVar_cross_ph_SFC(::Udm::ObjectImpl *impl);
		StateVar_cross_ph_SFC(const StateVar_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		StateVar_cross_ph_SFC(StateVar_cross_ph_SFC &&master);

		static StateVar_cross_ph_SFC Cast(::Udm::Object &&a);
		StateVar_cross_ph_SFC& operator=(StateVar_cross_ph_SFC &&a);

#endif
		static StateVar_cross_ph_SFC Cast(const ::Udm::Object &a);
		static StateVar_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateVar_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateVar_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateVar_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateVar_cross_ph_SFC, Pred>(impl); };
		StateVar_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateVar_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateVar_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateVar_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< StateVar_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class DT_cross_ph_SFC :  public Declaration_cross_ph_SFC {
	public:
		DT_cross_ph_SFC();
		DT_cross_ph_SFC(::Udm::ObjectImpl *impl);
		DT_cross_ph_SFC(const DT_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		DT_cross_ph_SFC(DT_cross_ph_SFC &&master);

		static DT_cross_ph_SFC Cast(::Udm::Object &&a);
		DT_cross_ph_SFC& operator=(DT_cross_ph_SFC &&a);

#endif
		static DT_cross_ph_SFC Cast(const ::Udm::Object &a);
		static DT_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DT_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DT_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DT_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DT_cross_ph_SFC, Pred>(impl); };
		DT_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DT_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< DT_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DT_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< DT_cross_ph_SFC> Archetype() const;
		::Udm::PointerAttr< TypeBase_cross_ph_ESMoL> tb() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_tb;

	};

	class Struct_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		Struct_cross_ph_SFC();
		Struct_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Struct_cross_ph_SFC(const Struct_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Struct_cross_ph_SFC(Struct_cross_ph_SFC &&master);

		static Struct_cross_ph_SFC Cast(::Udm::Object &&a);
		Struct_cross_ph_SFC& operator=(Struct_cross_ph_SFC &&a);

#endif
		static Struct_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Struct_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Struct_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Struct_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Struct_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Struct_cross_ph_SFC, Pred>(impl); };
		Struct_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Struct_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Struct_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Struct_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Struct_cross_ph_SFC> Archetype() const;
		::Udm::AssocAttr< LocalVar_cross_ph_SFC> pmemb() const;
		template <class Pred> ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred> pmemb_sorted(const Pred &) const { return ::Udm::AssocAttr< LocalVar_cross_ph_SFC, Pred>(impl, meta_pmemb); };
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_pmemb;

	};

	class Class_cross_ph_SFC : public ::Udm::Object {
	public:
		Class_cross_ph_SFC();
		Class_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Class_cross_ph_SFC(const Class_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Class_cross_ph_SFC(Class_cross_ph_SFC &&master);

		static Class_cross_ph_SFC Cast(::Udm::Object &&a);
		Class_cross_ph_SFC& operator=(Class_cross_ph_SFC &&a);

#endif
		static Class_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Class_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Class_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Class_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Class_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Class_cross_ph_SFC, Pred>(impl); };
		Class_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Class_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Class_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Class_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Class_cross_ph_SFC> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< Class_cross_ph_SFC> equivdst() const;
		template <class Pred> ::Udm::AssocAttr< Class_cross_ph_SFC, Pred> equivdst_sorted(const Pred &) const { return ::Udm::AssocAttr< Class_cross_ph_SFC, Pred>(impl, meta_equivdst); };
		::Udm::AssocAttr< Class_cross_ph_SFC> equivsrc() const;
		template <class Pred> ::Udm::AssocAttr< Class_cross_ph_SFC, Pred> equivsrc_sorted(const Pred &) const { return ::Udm::AssocAttr< Class_cross_ph_SFC, Pred>(impl, meta_equivsrc); };
		::Udm::AssocAttr< Subsystem_cross_ph_ESMoL> obj() const;
		template <class Pred> ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL, Pred> obj_sorted(const Pred &) const { return ::Udm::AssocAttr< Subsystem_cross_ph_ESMoL, Pred>(impl, meta_obj); };
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Class_cross_ph_SFC_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_equivdst;
		static ::Uml::AssociationRole meta_equivsrc;
		static ::Uml::AssociationRole meta_obj;
		static ::Uml::CompositionParentRole meta_Class_cross_ph_SFC_parentrole;

	};

	class Array_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		Array_cross_ph_SFC();
		Array_cross_ph_SFC(::Udm::ObjectImpl *impl);
		Array_cross_ph_SFC(const Array_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		Array_cross_ph_SFC(Array_cross_ph_SFC &&master);

		static Array_cross_ph_SFC Cast(::Udm::Object &&a);
		Array_cross_ph_SFC& operator=(Array_cross_ph_SFC &&a);

#endif
		static Array_cross_ph_SFC Cast(const ::Udm::Object &a);
		static Array_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Array_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Array_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Array_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Array_cross_ph_SFC, Pred>(impl); };
		Array_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Array_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< Array_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Array_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< Array_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class BasicType_cross_ph_SFC :  public DT_cross_ph_SFC {
	public:
		BasicType_cross_ph_SFC();
		BasicType_cross_ph_SFC(::Udm::ObjectImpl *impl);
		BasicType_cross_ph_SFC(const BasicType_cross_ph_SFC &master);

#ifdef UDM_RVALUE
		BasicType_cross_ph_SFC(BasicType_cross_ph_SFC &&master);

		static BasicType_cross_ph_SFC Cast(::Udm::Object &&a);
		BasicType_cross_ph_SFC& operator=(BasicType_cross_ph_SFC &&a);

#endif
		static BasicType_cross_ph_SFC Cast(const ::Udm::Object &a);
		static BasicType_cross_ph_SFC Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BasicType_cross_ph_SFC CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BasicType_cross_ph_SFC> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BasicType_cross_ph_SFC, Pred>(impl); };
		BasicType_cross_ph_SFC CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BasicType_cross_ph_SFC> Derived();
		template <class Pred> ::Udm::DerivedAttr< BasicType_cross_ph_SFC, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BasicType_cross_ph_SFC, Pred>(impl); };
		::Udm::ArchetypeAttr< BasicType_cross_ph_SFC> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class TypeBase_cross_ph_ESMoL : public ::Udm::Object {
	public:
		TypeBase_cross_ph_ESMoL();
		TypeBase_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TypeBase_cross_ph_ESMoL(const TypeBase_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TypeBase_cross_ph_ESMoL(TypeBase_cross_ph_ESMoL &&master);

		static TypeBase_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TypeBase_cross_ph_ESMoL& operator=(TypeBase_cross_ph_ESMoL &&a);

#endif
		static TypeBase_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TypeBase_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeBase_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeBase_cross_ph_ESMoL, Pred>(impl); };
		TypeBase_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeBase_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeBase_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< DT_cross_ph_SFC> dt() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeBase_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_dt;
		static ::Uml::CompositionParentRole meta_TypeBase_cross_ph_ESMoL_parentrole;

	};

	class TypeStruct_cross_ph_ESMoL :  public TypeBase_cross_ph_ESMoL {
	public:
		TypeStruct_cross_ph_ESMoL();
		TypeStruct_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TypeStruct_cross_ph_ESMoL(const TypeStruct_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TypeStruct_cross_ph_ESMoL(TypeStruct_cross_ph_ESMoL &&master);

		static TypeStruct_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TypeStruct_cross_ph_ESMoL& operator=(TypeStruct_cross_ph_ESMoL &&a);

#endif
		static TypeStruct_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TypeStruct_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeStruct_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeStruct_cross_ph_ESMoL, Pred>(impl); };
		TypeStruct_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeStruct_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeStruct_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class Matrix_cross_ph_ESMoL :  public TypeBase_cross_ph_ESMoL {
	public:
		Matrix_cross_ph_ESMoL();
		Matrix_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Matrix_cross_ph_ESMoL(const Matrix_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Matrix_cross_ph_ESMoL(Matrix_cross_ph_ESMoL &&master);

		static Matrix_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Matrix_cross_ph_ESMoL& operator=(Matrix_cross_ph_ESMoL &&a);

#endif
		static Matrix_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Matrix_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Matrix_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Matrix_cross_ph_ESMoL, Pred>(impl); };
		Matrix_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Matrix_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Matrix_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Matrix_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Matrix_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class TypeBaseRef_cross_ph_ESMoL : public ::Udm::Object {
	public:
		TypeBaseRef_cross_ph_ESMoL();
		TypeBaseRef_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TypeBaseRef_cross_ph_ESMoL(const TypeBaseRef_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TypeBaseRef_cross_ph_ESMoL(TypeBaseRef_cross_ph_ESMoL &&master);

		static TypeBaseRef_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TypeBaseRef_cross_ph_ESMoL& operator=(TypeBaseRef_cross_ph_ESMoL &&a);

#endif
		static TypeBaseRef_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TypeBaseRef_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeBaseRef_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeBaseRef_cross_ph_ESMoL, Pred>(impl); };
		TypeBaseRef_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeBaseRef_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeBaseRef_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> lvar() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> TypeBaseRef_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_lvar;
		static ::Uml::CompositionParentRole meta_TypeBaseRef_cross_ph_ESMoL_parentrole;

	};

	class Primitive_cross_ph_ESMoL : public ::Udm::Object {
	public:
		Primitive_cross_ph_ESMoL();
		Primitive_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Primitive_cross_ph_ESMoL(const Primitive_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Primitive_cross_ph_ESMoL(Primitive_cross_ph_ESMoL &&master);

		static Primitive_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Primitive_cross_ph_ESMoL& operator=(Primitive_cross_ph_ESMoL &&a);

#endif
		static Primitive_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Primitive_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Primitive_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Primitive_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Primitive_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Primitive_cross_ph_ESMoL, Pred>(impl); };
		Primitive_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Primitive_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Primitive_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Primitive_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Primitive_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> ifval() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Primitive_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_ifval;
		static ::Uml::CompositionParentRole meta_Primitive_cross_ph_ESMoL_parentrole;

	};

	class Parameter_cross_ph_ESMoL : public ::Udm::Object {
	public:
		Parameter_cross_ph_ESMoL();
		Parameter_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Parameter_cross_ph_ESMoL(const Parameter_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Parameter_cross_ph_ESMoL(Parameter_cross_ph_ESMoL &&master);

		static Parameter_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Parameter_cross_ph_ESMoL& operator=(Parameter_cross_ph_ESMoL &&a);

#endif
		static Parameter_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Parameter_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Parameter_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Parameter_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Parameter_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Parameter_cross_ph_ESMoL, Pred>(impl); };
		Parameter_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Parameter_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Parameter_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Parameter_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Parameter_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< Arg_cross_ph_SFC> arg() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> memb() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Parameter_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::AssociationRole meta_memb;
		static ::Uml::CompositionParentRole meta_Parameter_cross_ph_ESMoL_parentrole;

	};

	class Subsystem_cross_ph_ESMoL : public ::Udm::Object {
	public:
		Subsystem_cross_ph_ESMoL();
		Subsystem_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Subsystem_cross_ph_ESMoL(const Subsystem_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Subsystem_cross_ph_ESMoL(Subsystem_cross_ph_ESMoL &&master);

		static Subsystem_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Subsystem_cross_ph_ESMoL& operator=(Subsystem_cross_ph_ESMoL &&a);

#endif
		static Subsystem_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Subsystem_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Subsystem_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Subsystem_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Subsystem_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Subsystem_cross_ph_ESMoL, Pred>(impl); };
		Subsystem_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Subsystem_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Subsystem_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Subsystem_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Subsystem_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::PointerAttr< Function_cross_ph_SFC> init() const;
		::Udm::PointerAttr< Function_cross_ph_SFC> main() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> memb() const;
		::Udm::AssocAttr< FunctionCall_cross_ph_SFC> mcall() const;
		template <class Pred> ::Udm::AssocAttr< FunctionCall_cross_ph_SFC, Pred> mcall_sorted(const Pred &) const { return ::Udm::AssocAttr< FunctionCall_cross_ph_SFC, Pred>(impl, meta_mcall); };
		::Udm::PointerAttr< Class_cross_ph_SFC> cls() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Subsystem_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_init;
		static ::Uml::AssociationRole meta_main;
		static ::Uml::AssociationRole meta_memb;
		static ::Uml::AssociationRole meta_mcall;
		static ::Uml::AssociationRole meta_cls;
		static ::Uml::CompositionParentRole meta_Subsystem_cross_ph_ESMoL_parentrole;

	};

	class Port_cross_ph_ESMoL : public ::Udm::Object {
	public:
		Port_cross_ph_ESMoL();
		Port_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		Port_cross_ph_ESMoL(const Port_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		Port_cross_ph_ESMoL(Port_cross_ph_ESMoL &&master);

		static Port_cross_ph_ESMoL Cast(::Udm::Object &&a);
		Port_cross_ph_ESMoL& operator=(Port_cross_ph_ESMoL &&a);

#endif
		static Port_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static Port_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Port_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Port_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Port_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Port_cross_ph_ESMoL, Pred>(impl); };
		Port_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Port_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< Port_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Port_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< Port_cross_ph_ESMoL> Archetype() const;
		::Udm::StringAttr rem_sysname() const;
		::Udm::IntegerAttr rem_id() const;
		::Udm::AssocAttr< Arg_cross_ph_SFC> arg() const;
		template <class Pred> ::Udm::AssocAttr< Arg_cross_ph_SFC, Pred> arg_sorted(const Pred &) const { return ::Udm::AssocAttr< Arg_cross_ph_SFC, Pred>(impl, meta_arg); };
		::Udm::PointerAttr< ArgDeclBase_cross_ph_SFC> argdecl() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> Port_cross_ph_ESMoL_parentrole() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_rem_sysname;
		static ::Uml::Attribute meta_rem_id;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::AssociationRole meta_argdecl;
		static ::Uml::CompositionParentRole meta_Port_cross_ph_ESMoL_parentrole;

	};

	class OutPort_cross_ph_ESMoL :  public Port_cross_ph_ESMoL {
	public:
		OutPort_cross_ph_ESMoL();
		OutPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		OutPort_cross_ph_ESMoL(const OutPort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		OutPort_cross_ph_ESMoL(OutPort_cross_ph_ESMoL &&master);

		static OutPort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		OutPort_cross_ph_ESMoL& operator=(OutPort_cross_ph_ESMoL &&a);

#endif
		static OutPort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static OutPort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutPort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutPort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutPort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutPort_cross_ph_ESMoL, Pred>(impl); };
		OutPort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutPort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutPort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutPort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< OutPort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class OutputPort_cross_ph_ESMoL :  public OutPort_cross_ph_ESMoL {
	public:
		OutputPort_cross_ph_ESMoL();
		OutputPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		OutputPort_cross_ph_ESMoL(const OutputPort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		OutputPort_cross_ph_ESMoL(OutputPort_cross_ph_ESMoL &&master);

		static OutputPort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		OutputPort_cross_ph_ESMoL& operator=(OutputPort_cross_ph_ESMoL &&a);

#endif
		static OutputPort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static OutputPort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutputPort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutputPort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutputPort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutputPort_cross_ph_ESMoL, Pred>(impl); };
		OutputPort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutputPort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutputPort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutputPort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< OutputPort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class StatePort_cross_ph_ESMoL :  public OutPort_cross_ph_ESMoL {
	public:
		StatePort_cross_ph_ESMoL();
		StatePort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		StatePort_cross_ph_ESMoL(const StatePort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		StatePort_cross_ph_ESMoL(StatePort_cross_ph_ESMoL &&master);

		static StatePort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		StatePort_cross_ph_ESMoL& operator=(StatePort_cross_ph_ESMoL &&a);

#endif
		static StatePort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static StatePort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StatePort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StatePort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StatePort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StatePort_cross_ph_ESMoL, Pred>(impl); };
		StatePort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StatePort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< StatePort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StatePort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< StatePort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class InPort_cross_ph_ESMoL :  public Port_cross_ph_ESMoL {
	public:
		InPort_cross_ph_ESMoL();
		InPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		InPort_cross_ph_ESMoL(const InPort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		InPort_cross_ph_ESMoL(InPort_cross_ph_ESMoL &&master);

		static InPort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		InPort_cross_ph_ESMoL& operator=(InPort_cross_ph_ESMoL &&a);

#endif
		static InPort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static InPort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		InPort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< InPort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< InPort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< InPort_cross_ph_ESMoL, Pred>(impl); };
		InPort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< InPort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< InPort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< InPort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< InPort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class EnablePort_cross_ph_ESMoL :  public InPort_cross_ph_ESMoL {
	public:
		EnablePort_cross_ph_ESMoL();
		EnablePort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		EnablePort_cross_ph_ESMoL(const EnablePort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		EnablePort_cross_ph_ESMoL(EnablePort_cross_ph_ESMoL &&master);

		static EnablePort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		EnablePort_cross_ph_ESMoL& operator=(EnablePort_cross_ph_ESMoL &&a);

#endif
		static EnablePort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static EnablePort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		EnablePort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< EnablePort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< EnablePort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< EnablePort_cross_ph_ESMoL, Pred>(impl); };
		EnablePort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< EnablePort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< EnablePort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< EnablePort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< EnablePort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class TriggerPort_cross_ph_ESMoL :  public InPort_cross_ph_ESMoL {
	public:
		TriggerPort_cross_ph_ESMoL();
		TriggerPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		TriggerPort_cross_ph_ESMoL(const TriggerPort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		TriggerPort_cross_ph_ESMoL(TriggerPort_cross_ph_ESMoL &&master);

		static TriggerPort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		TriggerPort_cross_ph_ESMoL& operator=(TriggerPort_cross_ph_ESMoL &&a);

#endif
		static TriggerPort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static TriggerPort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TriggerPort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TriggerPort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TriggerPort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TriggerPort_cross_ph_ESMoL, Pred>(impl); };
		TriggerPort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TriggerPort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< TriggerPort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TriggerPort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< TriggerPort_cross_ph_ESMoL> Archetype() const;
		::Udm::PointerAttr< LocalVar_cross_ph_SFC> memb() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_memb;

	};

	class InputPort_cross_ph_ESMoL :  public InPort_cross_ph_ESMoL {
	public:
		InputPort_cross_ph_ESMoL();
		InputPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		InputPort_cross_ph_ESMoL(const InputPort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		InputPort_cross_ph_ESMoL(InputPort_cross_ph_ESMoL &&master);

		static InputPort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		InputPort_cross_ph_ESMoL& operator=(InputPort_cross_ph_ESMoL &&a);

#endif
		static InputPort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static InputPort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		InputPort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< InputPort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< InputPort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< InputPort_cross_ph_ESMoL, Pred>(impl); };
		InputPort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< InputPort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< InputPort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< InputPort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< InputPort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

	class ActionPort_cross_ph_ESMoL :  public InPort_cross_ph_ESMoL {
	public:
		ActionPort_cross_ph_ESMoL();
		ActionPort_cross_ph_ESMoL(::Udm::ObjectImpl *impl);
		ActionPort_cross_ph_ESMoL(const ActionPort_cross_ph_ESMoL &master);

#ifdef UDM_RVALUE
		ActionPort_cross_ph_ESMoL(ActionPort_cross_ph_ESMoL &&master);

		static ActionPort_cross_ph_ESMoL Cast(::Udm::Object &&a);
		ActionPort_cross_ph_ESMoL& operator=(ActionPort_cross_ph_ESMoL &&a);

#endif
		static ActionPort_cross_ph_ESMoL Cast(const ::Udm::Object &a);
		static ActionPort_cross_ph_ESMoL Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ActionPort_cross_ph_ESMoL CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ActionPort_cross_ph_ESMoL> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ActionPort_cross_ph_ESMoL, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ActionPort_cross_ph_ESMoL, Pred>(impl); };
		ActionPort_cross_ph_ESMoL CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ActionPort_cross_ph_ESMoL> Derived();
		template <class Pred> ::Udm::DerivedAttr< ActionPort_cross_ph_ESMoL, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ActionPort_cross_ph_ESMoL, Pred>(impl); };
		::Udm::ArchetypeAttr< ActionPort_cross_ph_ESMoL> Archetype() const;
		::Udm::ParentAttr< ::ESM2SLC::_gen_cont> parent() const;

		static ::Uml::Class meta;

	};

}

#endif // MOBIES_ESM2SLC_H
