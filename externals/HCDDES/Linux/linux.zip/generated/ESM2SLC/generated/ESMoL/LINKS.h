#ifndef MOBIES_LINKS_H
#define MOBIES_LINKS_H

// header file LINKS.h generated from diagram LINKS
// generated with Udm version 3.31 on Mon Jul 23 16:50:57 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace ESMoL {
	class TypeStruct;
	class Matrix;
	class TypeBase;
	class TypeBaseRef;
	class Primitive;
	class Parameter;
	class Subsystem;
	class OutputPort;
	class OutPort;
	class StatePort;
	class Port;
	class EnablePort;
	class TriggerPort;
	class InputPort;
	class InPort;
	class ActionPort;

}

namespace SFC {
	class Arg;
	class Function;
	class LocalVar;
	class StateVar;
	class StateLabel;
	class FunctionCall;
	class Var;
	class Declaration;
	class DT;
	class Struct;
	class ArgDeclBase;
	class Class;
	class Array;
	class BasicType;

}

namespace LINKS {

	extern ::Uml::Diagram meta;
	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

}

#endif // MOBIES_LINKS_H
