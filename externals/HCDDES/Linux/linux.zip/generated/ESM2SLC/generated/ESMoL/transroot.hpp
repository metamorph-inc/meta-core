typedef TL_2b83 TransClass;
