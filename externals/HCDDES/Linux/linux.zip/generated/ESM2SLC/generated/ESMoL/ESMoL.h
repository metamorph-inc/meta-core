#ifndef MOBIES_ESMOL_H
#define MOBIES_ESMOL_H

// header file ESMoL.h generated from diagram ESMoL
// generated with Udm version 3.31 on Mon Jul 23 16:50:57 2012

#include <UdmBase.h>

#if !defined(UDM_VERSION_MAJOR) || !defined(UDM_VERSION_MINOR)
#    error "Udm headers too old, they do not define UDM_VERSION"
#elif UDM_VERSION_MAJOR < 3
#    error "Udm headers too old, minimum version required 3.31"
#elif UDM_VERSION_MAJOR == 3 && UDM_VERSION_MINOR < 31
#    error "Udm headers too old, minimum version required 3.31"
#endif

#include <Uml.h>


#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif

namespace SFC {
	class Arg;
	class Function;
	class LocalVar;
	class StateVar;
	class StateLabel;
	class FunctionCall;
	class Var;
	class Declaration;
	class DT;
	class Struct;
	class ArgDeclBase;
	class Class;
	class Array;
	class BasicType;

}

namespace ESMoL {

	extern ::Uml::Diagram meta;
	class FaultToInput_Members_Base;
	class OutputToFault_Members_Base;
	class ExecutionAssignment_dstExecutionAssignment_RPContainer_Base;
	class Connector_srcConnector_RPContainer_Base;
	class Connector_dstConnector_RPContainer_Base;
	class MessageRef_RefersTo_Base;
	class CommMapping_srcCommMapping_RPContainer_Base;
	class CommMapping_dstCommMapping_RPContainer_Base;
	class CommMapping_Members_Base;
	class ComponentRef_RefersTo_Base;
	class FaultScenario;
	class ScenarioInfo;
	class FaultEvent;
	class FaultTrigger;
	class FaultCondition;
	class ConditionEvent;
	class Precondition;
	class Postcondition;
	class DetectionCondition;
	class MitigationCondition;
	class TaskInst;
	class Action;
	class DetectionAction;
	class MitigationAction;
	class FaultMgrTask;
	class CompBreakout;
	class DesignReference;
	class FaultToInput;
	class OutputToFault;
	class FaultModelRef;
	class FaultModel;
	class Additive;
	class Substitutive;
	class Incorporation;
	class Occurrence;
	class Continuous;
	class Periodic;
	class Intermittent;
	class Multiplicative;
	class Variable;
	class FaultModelFolder;
	class RandomDistribution;
	class Constant;
	class Interval;
	class Uniform;
	class Normal;
	class Exponential;
	class Step;
	class Pulse;
	class ValueObject;
	class Functions;
	class Sinusoid;
	class TransitionToState;
	class StateToTransition;
	class PNTransition;
	class PNState;
	class BIPConnector;
	class PNVarRef;
	class Module;
	class PetriNet;
	class PNPort;
	class PNVariable;
	class ModelsFolder;
	class ModelInfo;
	class ExecutionInfo;
	class TTExecInfo;
	class AsyncPeriodicExecInfo;
	class ExecutionContext;
	class TTExecContext;
	class PeriodicExecInfo;
	class ExecutionAssignment;
	class Executable;
	class AperiodicExecInfo;
	class SporadicExecInfo;
	class CCode;
	class SubsystemRef;
	class COutputPort;
	class CInputPort;
	class PetriNetRef;
	class CANMessage;
	class AutoCANParam;
	class AutoCANMessage;
	class FieldDataType;
	class BitField;
	class ValueType;
	class TTBus;
	class OldBus;
	class CANBus;
	class Link;
	class SerialLink;
	class IOPortExp;
	class IOPortInfo;
	class IOPortInfoRef;
	class IOPortAssignment;
	class IOPortInfoBase;
	class OldTask;
	class ArchitectureLibrary;
	class SystemTypes;
	class Connector;
	class ComponentBase;
	class Message;
	class MsgPort;
	class Output;
	class Input;
	class OutputEvent;
	class InputEvent;
	class Trigger;
	class PlantComponent;
	class DesignFolder;
	class Component;
	class MessageRef;
	class TimingConstraint;
	class RequirementsLibrary;
	class TimingSheet;
	class TaskRef;
	class Types;
	class TypeStruct;
	class Matrix;
	class TypeBase;
	class TypeBaseRef;
	class Primitive;
	class Block;
	class Parameter;
	class Reference;
	class Annotation;
	class Line;
	class Dataflow;
	class Subsystem;
	class OutputPort;
	class OutPort;
	class StatePort;
	class Port;
	class EnablePort;
	class TriggerPort;
	class InputPort;
	class InPort;
	class ActionPort;
	class HasRefId;
	class State;
	class Transition;
	class History;
	class TransStart;
	class Junction;
	class ConnectorRef;
	class Stateflow;
	class TransConnector;
	class Data;
	class Event;
	class StateDE;
	class Conditional;
	class ShallowHistory;
	class DeepHistory;
	class Join;
	class Fork;
	class Choice;
	class Entry;
	class Exit;
	class Terminate;
	class OS;
	class Wire;
	class HardwareUnit;
	class PlatformLibrary;
	class Network;
	class Connectable;
	class HWElement;
	class IChan;
	class OChan;
	class BChan;
	class Bus;
	class Plant;
	class IODevice;
	class PhysConnection;
	class AcquisitionConnection;
	class ActuationConnection;
	class PhysInterface;
	class Node;
	class Channel;
	class DeploymentLibrary;
	class System;
	class NodeRef;
	class ComponentRef;
	class CommMapping;
	class Dependency;
	class ComponentAssignment;
	class PlantComponentRef;
	class RootFolder;
	class MgaObject;

	void Initialize();
	void Initialize(const ::Uml::Diagram &dgr);

	extern  ::Udm::UdmDiagram diagram;

	class FaultToInput_Members_Base :  virtual public ::Udm::Object {
	public:
		FaultToInput_Members_Base();
		FaultToInput_Members_Base(::Udm::ObjectImpl *impl);
		FaultToInput_Members_Base(const FaultToInput_Members_Base &master);

#ifdef UDM_RVALUE
		FaultToInput_Members_Base(FaultToInput_Members_Base &&master);

		static FaultToInput_Members_Base Cast(::Udm::Object &&a);
		FaultToInput_Members_Base& operator=(FaultToInput_Members_Base &&a);

#endif
		static FaultToInput_Members_Base Cast(const ::Udm::Object &a);
		static FaultToInput_Members_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultToInput_Members_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultToInput_Members_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultToInput_Members_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultToInput_Members_Base, Pred>(impl); };
		FaultToInput_Members_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultToInput_Members_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultToInput_Members_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultToInput_Members_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultToInput_Members_Base> Archetype() const;
		::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base> dstFaultToInput() const;
		template <class Pred> ::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base, Pred> dstFaultToInput_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base, Pred>(impl, meta_dstFaultToInput, meta_dstFaultToInput_rev); };
		::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base> srcFaultToInput() const;
		template <class Pred> ::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base, Pred> srcFaultToInput_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base, Pred>(impl, meta_srcFaultToInput, meta_srcFaultToInput_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstFaultToInput;
		static ::Uml::AssociationRole meta_dstFaultToInput_rev;
		static ::Uml::AssociationRole meta_srcFaultToInput;
		static ::Uml::AssociationRole meta_srcFaultToInput_rev;

	};

	class OutputToFault_Members_Base :  virtual public ::Udm::Object {
	public:
		OutputToFault_Members_Base();
		OutputToFault_Members_Base(::Udm::ObjectImpl *impl);
		OutputToFault_Members_Base(const OutputToFault_Members_Base &master);

#ifdef UDM_RVALUE
		OutputToFault_Members_Base(OutputToFault_Members_Base &&master);

		static OutputToFault_Members_Base Cast(::Udm::Object &&a);
		OutputToFault_Members_Base& operator=(OutputToFault_Members_Base &&a);

#endif
		static OutputToFault_Members_Base Cast(const ::Udm::Object &a);
		static OutputToFault_Members_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutputToFault_Members_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutputToFault_Members_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutputToFault_Members_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutputToFault_Members_Base, Pred>(impl); };
		OutputToFault_Members_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutputToFault_Members_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutputToFault_Members_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutputToFault_Members_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< OutputToFault_Members_Base> Archetype() const;
		::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base> dstOutputToFault() const;
		template <class Pred> ::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base, Pred> dstOutputToFault_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base, Pred>(impl, meta_dstOutputToFault, meta_dstOutputToFault_rev); };
		::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base> srcOutputToFault() const;
		template <class Pred> ::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base, Pred> srcOutputToFault_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base, Pred>(impl, meta_srcOutputToFault, meta_srcOutputToFault_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstOutputToFault;
		static ::Uml::AssociationRole meta_dstOutputToFault_rev;
		static ::Uml::AssociationRole meta_srcOutputToFault;
		static ::Uml::AssociationRole meta_srcOutputToFault_rev;

	};

	class ExecutionAssignment_dstExecutionAssignment_RPContainer_Base :  virtual public ::Udm::Object {
	public:
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base();
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(::Udm::ObjectImpl *impl);
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(const ExecutionAssignment_dstExecutionAssignment_RPContainer_Base &master);

#ifdef UDM_RVALUE
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base &&master);

		static ExecutionAssignment_dstExecutionAssignment_RPContainer_Base Cast(::Udm::Object &&a);
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base& operator=(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base &&a);

#endif
		static ExecutionAssignment_dstExecutionAssignment_RPContainer_Base Cast(const ::Udm::Object &a);
		static ExecutionAssignment_dstExecutionAssignment_RPContainer_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base, Pred>(impl); };
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> Archetype() const;
		::Udm::AssocAttr< ExecutionAssignment> dstExecutionAssignment__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< ExecutionAssignment, Pred> dstExecutionAssignment__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< ExecutionAssignment, Pred>(impl, meta_dstExecutionAssignment__rp_helper_rev); };
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstExecutionAssignment__rp_helper_rev;

	};

	class Connector_srcConnector_RPContainer_Base :  virtual public ::Udm::Object {
	public:
		Connector_srcConnector_RPContainer_Base();
		Connector_srcConnector_RPContainer_Base(::Udm::ObjectImpl *impl);
		Connector_srcConnector_RPContainer_Base(const Connector_srcConnector_RPContainer_Base &master);

#ifdef UDM_RVALUE
		Connector_srcConnector_RPContainer_Base(Connector_srcConnector_RPContainer_Base &&master);

		static Connector_srcConnector_RPContainer_Base Cast(::Udm::Object &&a);
		Connector_srcConnector_RPContainer_Base& operator=(Connector_srcConnector_RPContainer_Base &&a);

#endif
		static Connector_srcConnector_RPContainer_Base Cast(const ::Udm::Object &a);
		static Connector_srcConnector_RPContainer_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Connector_srcConnector_RPContainer_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Connector_srcConnector_RPContainer_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Connector_srcConnector_RPContainer_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Connector_srcConnector_RPContainer_Base, Pred>(impl); };
		Connector_srcConnector_RPContainer_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Connector_srcConnector_RPContainer_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< Connector_srcConnector_RPContainer_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Connector_srcConnector_RPContainer_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< Connector_srcConnector_RPContainer_Base> Archetype() const;
		::Udm::AssocAttr< Connector> srcConnector__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< Connector, Pred> srcConnector__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< Connector, Pred>(impl, meta_srcConnector__rp_helper_rev); };
		::Udm::ParentAttr< ::ESMoL::Component> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcConnector__rp_helper_rev;

	};

	class Connector_dstConnector_RPContainer_Base :  virtual public ::Udm::Object {
	public:
		Connector_dstConnector_RPContainer_Base();
		Connector_dstConnector_RPContainer_Base(::Udm::ObjectImpl *impl);
		Connector_dstConnector_RPContainer_Base(const Connector_dstConnector_RPContainer_Base &master);

#ifdef UDM_RVALUE
		Connector_dstConnector_RPContainer_Base(Connector_dstConnector_RPContainer_Base &&master);

		static Connector_dstConnector_RPContainer_Base Cast(::Udm::Object &&a);
		Connector_dstConnector_RPContainer_Base& operator=(Connector_dstConnector_RPContainer_Base &&a);

#endif
		static Connector_dstConnector_RPContainer_Base Cast(const ::Udm::Object &a);
		static Connector_dstConnector_RPContainer_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Connector_dstConnector_RPContainer_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Connector_dstConnector_RPContainer_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Connector_dstConnector_RPContainer_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Connector_dstConnector_RPContainer_Base, Pred>(impl); };
		Connector_dstConnector_RPContainer_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Connector_dstConnector_RPContainer_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< Connector_dstConnector_RPContainer_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Connector_dstConnector_RPContainer_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< Connector_dstConnector_RPContainer_Base> Archetype() const;
		::Udm::AssocAttr< Connector> dstConnector__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< Connector, Pred> dstConnector__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< Connector, Pred>(impl, meta_dstConnector__rp_helper_rev); };
		::Udm::ParentAttr< ::ESMoL::Component> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstConnector__rp_helper_rev;

	};

	class MessageRef_RefersTo_Base :  virtual public ::Udm::Object {
	public:
		MessageRef_RefersTo_Base();
		MessageRef_RefersTo_Base(::Udm::ObjectImpl *impl);
		MessageRef_RefersTo_Base(const MessageRef_RefersTo_Base &master);

#ifdef UDM_RVALUE
		MessageRef_RefersTo_Base(MessageRef_RefersTo_Base &&master);

		static MessageRef_RefersTo_Base Cast(::Udm::Object &&a);
		MessageRef_RefersTo_Base& operator=(MessageRef_RefersTo_Base &&a);

#endif
		static MessageRef_RefersTo_Base Cast(const ::Udm::Object &a);
		static MessageRef_RefersTo_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		MessageRef_RefersTo_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< MessageRef_RefersTo_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< MessageRef_RefersTo_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< MessageRef_RefersTo_Base, Pred>(impl); };
		MessageRef_RefersTo_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< MessageRef_RefersTo_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< MessageRef_RefersTo_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< MessageRef_RefersTo_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< MessageRef_RefersTo_Base> Archetype() const;
		::Udm::AssocAttr< MessageRef> referedbyBusMessageRef() const;
		template <class Pred> ::Udm::AssocAttr< MessageRef, Pred> referedbyBusMessageRef_sorted(const Pred &) const { return ::Udm::AssocAttr< MessageRef, Pred>(impl, meta_referedbyBusMessageRef); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyBusMessageRef;

	};

	class CommMapping_srcCommMapping_RPContainer_Base :  virtual public ::Udm::Object {
	public:
		CommMapping_srcCommMapping_RPContainer_Base();
		CommMapping_srcCommMapping_RPContainer_Base(::Udm::ObjectImpl *impl);
		CommMapping_srcCommMapping_RPContainer_Base(const CommMapping_srcCommMapping_RPContainer_Base &master);

#ifdef UDM_RVALUE
		CommMapping_srcCommMapping_RPContainer_Base(CommMapping_srcCommMapping_RPContainer_Base &&master);

		static CommMapping_srcCommMapping_RPContainer_Base Cast(::Udm::Object &&a);
		CommMapping_srcCommMapping_RPContainer_Base& operator=(CommMapping_srcCommMapping_RPContainer_Base &&a);

#endif
		static CommMapping_srcCommMapping_RPContainer_Base Cast(const ::Udm::Object &a);
		static CommMapping_srcCommMapping_RPContainer_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CommMapping_srcCommMapping_RPContainer_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CommMapping_srcCommMapping_RPContainer_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CommMapping_srcCommMapping_RPContainer_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CommMapping_srcCommMapping_RPContainer_Base, Pred>(impl); };
		CommMapping_srcCommMapping_RPContainer_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CommMapping_srcCommMapping_RPContainer_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< CommMapping_srcCommMapping_RPContainer_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CommMapping_srcCommMapping_RPContainer_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< CommMapping_srcCommMapping_RPContainer_Base> Archetype() const;
		::Udm::AssocAttr< CommMapping> srcCommMapping__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< CommMapping, Pred> srcCommMapping__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< CommMapping, Pred>(impl, meta_srcCommMapping__rp_helper_rev); };
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcCommMapping__rp_helper_rev;

	};

	class CommMapping_dstCommMapping_RPContainer_Base :  virtual public ::Udm::Object {
	public:
		CommMapping_dstCommMapping_RPContainer_Base();
		CommMapping_dstCommMapping_RPContainer_Base(::Udm::ObjectImpl *impl);
		CommMapping_dstCommMapping_RPContainer_Base(const CommMapping_dstCommMapping_RPContainer_Base &master);

#ifdef UDM_RVALUE
		CommMapping_dstCommMapping_RPContainer_Base(CommMapping_dstCommMapping_RPContainer_Base &&master);

		static CommMapping_dstCommMapping_RPContainer_Base Cast(::Udm::Object &&a);
		CommMapping_dstCommMapping_RPContainer_Base& operator=(CommMapping_dstCommMapping_RPContainer_Base &&a);

#endif
		static CommMapping_dstCommMapping_RPContainer_Base Cast(const ::Udm::Object &a);
		static CommMapping_dstCommMapping_RPContainer_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CommMapping_dstCommMapping_RPContainer_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CommMapping_dstCommMapping_RPContainer_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CommMapping_dstCommMapping_RPContainer_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CommMapping_dstCommMapping_RPContainer_Base, Pred>(impl); };
		CommMapping_dstCommMapping_RPContainer_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CommMapping_dstCommMapping_RPContainer_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< CommMapping_dstCommMapping_RPContainer_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CommMapping_dstCommMapping_RPContainer_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< CommMapping_dstCommMapping_RPContainer_Base> Archetype() const;
		::Udm::AssocAttr< CommMapping> dstCommMapping__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< CommMapping, Pred> dstCommMapping__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< CommMapping, Pred>(impl, meta_dstCommMapping__rp_helper_rev); };
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstCommMapping__rp_helper_rev;

	};

	class CommMapping_Members_Base :  virtual public ::Udm::Object {
	public:
		CommMapping_Members_Base();
		CommMapping_Members_Base(::Udm::ObjectImpl *impl);
		CommMapping_Members_Base(const CommMapping_Members_Base &master);

#ifdef UDM_RVALUE
		CommMapping_Members_Base(CommMapping_Members_Base &&master);

		static CommMapping_Members_Base Cast(::Udm::Object &&a);
		CommMapping_Members_Base& operator=(CommMapping_Members_Base &&a);

#endif
		static CommMapping_Members_Base Cast(const ::Udm::Object &a);
		static CommMapping_Members_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CommMapping_Members_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CommMapping_Members_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CommMapping_Members_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CommMapping_Members_Base, Pred>(impl); };
		CommMapping_Members_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CommMapping_Members_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< CommMapping_Members_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CommMapping_Members_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< CommMapping_Members_Base> Archetype() const;
		::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base> dstCommMapping() const;
		template <class Pred> ::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base, Pred> dstCommMapping_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base, Pred>(impl, meta_dstCommMapping, meta_dstCommMapping_rev); };
		::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base> srcCommMapping() const;
		template <class Pred> ::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base, Pred> srcCommMapping_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base, Pred>(impl, meta_srcCommMapping, meta_srcCommMapping_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstCommMapping;
		static ::Uml::AssociationRole meta_dstCommMapping_rev;
		static ::Uml::AssociationRole meta_srcCommMapping;
		static ::Uml::AssociationRole meta_srcCommMapping_rev;

	};

	class ComponentRef_RefersTo_Base :  virtual public ::Udm::Object {
	public:
		ComponentRef_RefersTo_Base();
		ComponentRef_RefersTo_Base(::Udm::ObjectImpl *impl);
		ComponentRef_RefersTo_Base(const ComponentRef_RefersTo_Base &master);

#ifdef UDM_RVALUE
		ComponentRef_RefersTo_Base(ComponentRef_RefersTo_Base &&master);

		static ComponentRef_RefersTo_Base Cast(::Udm::Object &&a);
		ComponentRef_RefersTo_Base& operator=(ComponentRef_RefersTo_Base &&a);

#endif
		static ComponentRef_RefersTo_Base Cast(const ::Udm::Object &a);
		static ComponentRef_RefersTo_Base Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ComponentRef_RefersTo_Base CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ComponentRef_RefersTo_Base> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ComponentRef_RefersTo_Base, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ComponentRef_RefersTo_Base, Pred>(impl); };
		ComponentRef_RefersTo_Base CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ComponentRef_RefersTo_Base> Derived();
		template <class Pred> ::Udm::DerivedAttr< ComponentRef_RefersTo_Base, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ComponentRef_RefersTo_Base, Pred>(impl); };
		::Udm::ArchetypeAttr< ComponentRef_RefersTo_Base> Archetype() const;
		::Udm::AssocAttr< ComponentRef> referedbyComponentRef() const;
		template <class Pred> ::Udm::AssocAttr< ComponentRef, Pred> referedbyComponentRef_sorted(const Pred &) const { return ::Udm::AssocAttr< ComponentRef, Pred>(impl, meta_referedbyComponentRef); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyComponentRef;

	};

	class FaultModelFolder : public ::Udm::Object {
	public:
		FaultModelFolder();
		FaultModelFolder(::Udm::ObjectImpl *impl);
		FaultModelFolder(const FaultModelFolder &master);

#ifdef UDM_RVALUE
		FaultModelFolder(FaultModelFolder &&master);

		static FaultModelFolder Cast(::Udm::Object &&a);
		FaultModelFolder& operator=(FaultModelFolder &&a);

#endif
		static FaultModelFolder Cast(const ::Udm::Object &a);
		static FaultModelFolder Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultModelFolder CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultModelFolder> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultModelFolder, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultModelFolder, Pred>(impl); };
		FaultModelFolder CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultModelFolder> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultModelFolder, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultModelFolder, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultModelFolder> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModel_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred> FaultModel_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred>(impl, meta_FaultModel_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred> FaultModel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::DesignFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_FaultModel_children;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;

	};

	class ModelsFolder : public ::Udm::Object {
	public:
		ModelsFolder();
		ModelsFolder(::Udm::ObjectImpl *impl);
		ModelsFolder(const ModelsFolder &master);

#ifdef UDM_RVALUE
		ModelsFolder(ModelsFolder &&master);

		static ModelsFolder Cast(::Udm::Object &&a);
		ModelsFolder& operator=(ModelsFolder &&a);

#endif
		static ModelsFolder Cast(const ::Udm::Object &a);
		static ModelsFolder Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ModelsFolder CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ModelsFolder> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ModelsFolder, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ModelsFolder, Pred>(impl); };
		ModelsFolder CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ModelsFolder> Derived();
		template <class Pred> ::Udm::DerivedAttr< ModelsFolder, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ModelsFolder, Pred>(impl); };
		::Udm::ArchetypeAttr< ModelsFolder> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::Dataflow> Dataflow_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Dataflow, Pred> Dataflow_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Dataflow, Pred>(impl, meta_Dataflow_children); };
		::Udm::ChildrenAttr< ::ESMoL::Stateflow> Stateflow_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Stateflow, Pred> Stateflow_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Stateflow, Pred>(impl, meta_Stateflow_children); };
		::Udm::ChildrenAttr< ::ESMoL::ModelInfo> ModelInfo_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ModelInfo, Pred> ModelInfo_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ModelInfo, Pred>(impl, meta_ModelInfo_children); };
		::Udm::ChildrenAttr< ::ESMoL::Module> Module_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Module, Pred> Module_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Module, Pred>(impl, meta_Module_children); };
		::Udm::ChildrenAttr< ::ESMoL::Module> Module_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Module, Pred> Module_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Module, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ModelInfo> ModelInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ModelInfo, Pred> ModelInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ModelInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Dataflow> Dataflow_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Dataflow, Pred> Dataflow_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Dataflow, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Stateflow> Stateflow_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Stateflow, Pred> Stateflow_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Stateflow, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::DesignFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_Dataflow_children;
		static ::Uml::CompositionChildRole meta_Stateflow_children;
		static ::Uml::CompositionChildRole meta_ModelInfo_children;
		static ::Uml::CompositionChildRole meta_Module_children;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;

	};

	class ArchitectureLibrary : public ::Udm::Object {
	public:
		ArchitectureLibrary();
		ArchitectureLibrary(::Udm::ObjectImpl *impl);
		ArchitectureLibrary(const ArchitectureLibrary &master);

#ifdef UDM_RVALUE
		ArchitectureLibrary(ArchitectureLibrary &&master);

		static ArchitectureLibrary Cast(::Udm::Object &&a);
		ArchitectureLibrary& operator=(ArchitectureLibrary &&a);

#endif
		static ArchitectureLibrary Cast(const ::Udm::Object &a);
		static ArchitectureLibrary Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ArchitectureLibrary CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ArchitectureLibrary> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ArchitectureLibrary, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ArchitectureLibrary, Pred>(impl); };
		ArchitectureLibrary CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ArchitectureLibrary> Derived();
		template <class Pred> ::Udm::DerivedAttr< ArchitectureLibrary, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ArchitectureLibrary, Pred>(impl); };
		::Udm::ArchetypeAttr< ArchitectureLibrary> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::SystemTypes> SystemTypes_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred> SystemTypes_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred>(impl, meta_SystemTypes_children); };
		::Udm::ChildrenAttr< ::ESMoL::SystemTypes> SystemTypes_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred> SystemTypes_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_SystemTypes_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class DesignFolder : public ::Udm::Object {
	public:
		DesignFolder();
		DesignFolder(::Udm::ObjectImpl *impl);
		DesignFolder(const DesignFolder &master);

#ifdef UDM_RVALUE
		DesignFolder(DesignFolder &&master);

		static DesignFolder Cast(::Udm::Object &&a);
		DesignFolder& operator=(DesignFolder &&a);

#endif
		static DesignFolder Cast(const ::Udm::Object &a);
		static DesignFolder Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DesignFolder CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DesignFolder> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DesignFolder, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DesignFolder, Pred>(impl); };
		DesignFolder CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DesignFolder> Derived();
		template <class Pred> ::Udm::DerivedAttr< DesignFolder, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DesignFolder, Pred>(impl); };
		::Udm::ArchetypeAttr< DesignFolder> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::SystemTypes> SystemTypes_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred> SystemTypes_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred>(impl, meta_SystemTypes_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModel_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred> FaultModel_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred>(impl, meta_FaultModel_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder> FaultModelFolder_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder, Pred> FaultModelFolder_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder, Pred>(impl, meta_FaultModelFolder_children); };
		::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> HardwareUnit_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred> HardwareUnit_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred>(impl, meta_HardwareUnit_children); };
		::Udm::ChildrenAttr< ::ESMoL::TimingSheet> TimingSheet_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred> TimingSheet_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred>(impl, meta_TimingSheet_children); };
		::Udm::ChildrenAttr< ::ESMoL::System> System_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::System, Pred> System_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::System, Pred>(impl, meta_System_children); };
		::Udm::ChildrenAttr< ::ESMoL::ModelsFolder> ModelsFolder_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ModelsFolder, Pred> ModelsFolder_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ModelsFolder, Pred>(impl, meta_ModelsFolder_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultScenario> FaultScenario_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultScenario, Pred> FaultScenario_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultScenario, Pred>(impl, meta_FaultScenario_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultScenario> FaultScenario_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultScenario, Pred> FaultScenario_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultScenario, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred> FaultModel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder> FaultModelFolder_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder, Pred> FaultModelFolder_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ModelsFolder> ModelsFolder_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ModelsFolder, Pred> ModelsFolder_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ModelsFolder, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::SystemTypes> SystemTypes_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred> SystemTypes_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TimingSheet> TimingSheet_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred> TimingSheet_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> HardwareUnit_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred> HardwareUnit_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HWElement> HWElement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred> HWElement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::System> System_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::System, Pred> System_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::System, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_SystemTypes_children;
		static ::Uml::CompositionChildRole meta_FaultModel_children;
		static ::Uml::CompositionChildRole meta_FaultModelFolder_children;
		static ::Uml::CompositionChildRole meta_HardwareUnit_children;
		static ::Uml::CompositionChildRole meta_TimingSheet_children;
		static ::Uml::CompositionChildRole meta_System_children;
		static ::Uml::CompositionChildRole meta_ModelsFolder_children;
		static ::Uml::CompositionChildRole meta_FaultScenario_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class RequirementsLibrary : public ::Udm::Object {
	public:
		RequirementsLibrary();
		RequirementsLibrary(::Udm::ObjectImpl *impl);
		RequirementsLibrary(const RequirementsLibrary &master);

#ifdef UDM_RVALUE
		RequirementsLibrary(RequirementsLibrary &&master);

		static RequirementsLibrary Cast(::Udm::Object &&a);
		RequirementsLibrary& operator=(RequirementsLibrary &&a);

#endif
		static RequirementsLibrary Cast(const ::Udm::Object &a);
		static RequirementsLibrary Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		RequirementsLibrary CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< RequirementsLibrary> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< RequirementsLibrary, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< RequirementsLibrary, Pred>(impl); };
		RequirementsLibrary CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< RequirementsLibrary> Derived();
		template <class Pred> ::Udm::DerivedAttr< RequirementsLibrary, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< RequirementsLibrary, Pred>(impl); };
		::Udm::ArchetypeAttr< RequirementsLibrary> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::TimingSheet> TimingSheet_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred> TimingSheet_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred>(impl, meta_TimingSheet_children); };
		::Udm::ChildrenAttr< ::ESMoL::TimingSheet> TimingSheet_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred> TimingSheet_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_TimingSheet_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class Types : public ::Udm::Object {
	public:
		Types();
		Types(::Udm::ObjectImpl *impl);
		Types(const Types &master);

#ifdef UDM_RVALUE
		Types(Types &&master);

		static Types Cast(::Udm::Object &&a);
		Types& operator=(Types &&a);

#endif
		static Types Cast(const ::Udm::Object &a);
		static Types Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Types CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Types> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Types, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Types, Pred>(impl); };
		Types CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Types> Derived();
		template <class Pred> ::Udm::DerivedAttr< Types, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Types, Pred>(impl); };
		::Udm::ArchetypeAttr< Types> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::TypeBase> TypeBase_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeBase, Pred> TypeBase_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBase, Pred>(impl, meta_TypeBase_children); };
		::Udm::ChildrenAttr< ::ESMoL::TypeStruct> TypeStruct_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeStruct, Pred> TypeStruct_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeStruct, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Matrix> Matrix_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Matrix, Pred> Matrix_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Matrix, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TypeBase> TypeBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeBase, Pred> TypeBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_TypeBase_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class Dataflow : public ::Udm::Object {
	public:
		Dataflow();
		Dataflow(::Udm::ObjectImpl *impl);
		Dataflow(const Dataflow &master);

#ifdef UDM_RVALUE
		Dataflow(Dataflow &&master);

		static Dataflow Cast(::Udm::Object &&a);
		Dataflow& operator=(Dataflow &&a);

#endif
		static Dataflow Cast(const ::Udm::Object &a);
		static Dataflow Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Dataflow CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Dataflow> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Dataflow, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Dataflow, Pred>(impl); };
		Dataflow CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Dataflow> Derived();
		template <class Pred> ::Udm::DerivedAttr< Dataflow, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Dataflow, Pred>(impl); };
		::Udm::ArchetypeAttr< Dataflow> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::Subsystem> Subsystem_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred> Subsystem_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred>(impl, meta_Subsystem_children); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentBase> ComponentBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred> ComponentBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Block> Block_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Block, Pred> Block_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Block, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Subsystem> Subsystem_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred> Subsystem_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HasRefId> HasRefId_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred> HasRefId_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> ModelsFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_Subsystem_children;
		static ::Uml::CompositionParentRole meta_ModelsFolder_parent;

	};

	class Stateflow : public ::Udm::Object {
	public:
		Stateflow();
		Stateflow(::Udm::ObjectImpl *impl);
		Stateflow(const Stateflow &master);

#ifdef UDM_RVALUE
		Stateflow(Stateflow &&master);

		static Stateflow Cast(::Udm::Object &&a);
		Stateflow& operator=(Stateflow &&a);

#endif
		static Stateflow Cast(const ::Udm::Object &a);
		static Stateflow Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Stateflow CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Stateflow> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Stateflow, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Stateflow, Pred>(impl); };
		Stateflow CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Stateflow> Derived();
		template <class Pred> ::Udm::DerivedAttr< Stateflow, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Stateflow, Pred>(impl); };
		::Udm::ArchetypeAttr< Stateflow> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::State> State_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::State, Pred> State_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::State, Pred>(impl, meta_State_children); };
		::Udm::ChildrenAttr< ::ESMoL::HasRefId> HasRefId_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred> HasRefId_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::State> State_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::State, Pred> State_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::State, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TransConnector> TransConnector_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred> TransConnector_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> ModelsFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_State_children;
		static ::Uml::CompositionParentRole meta_ModelsFolder_parent;

	};

	class PlatformLibrary : public ::Udm::Object {
	public:
		PlatformLibrary();
		PlatformLibrary(::Udm::ObjectImpl *impl);
		PlatformLibrary(const PlatformLibrary &master);

#ifdef UDM_RVALUE
		PlatformLibrary(PlatformLibrary &&master);

		static PlatformLibrary Cast(::Udm::Object &&a);
		PlatformLibrary& operator=(PlatformLibrary &&a);

#endif
		static PlatformLibrary Cast(const ::Udm::Object &a);
		static PlatformLibrary Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PlatformLibrary CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PlatformLibrary> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PlatformLibrary, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PlatformLibrary, Pred>(impl); };
		PlatformLibrary CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PlatformLibrary> Derived();
		template <class Pred> ::Udm::DerivedAttr< PlatformLibrary, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PlatformLibrary, Pred>(impl); };
		::Udm::ArchetypeAttr< PlatformLibrary> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> HardwareUnit_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred> HardwareUnit_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred>(impl, meta_HardwareUnit_children); };
		::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> HardwareUnit_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred> HardwareUnit_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HWElement> HWElement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred> HWElement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_HardwareUnit_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class DeploymentLibrary : public ::Udm::Object {
	public:
		DeploymentLibrary();
		DeploymentLibrary(::Udm::ObjectImpl *impl);
		DeploymentLibrary(const DeploymentLibrary &master);

#ifdef UDM_RVALUE
		DeploymentLibrary(DeploymentLibrary &&master);

		static DeploymentLibrary Cast(::Udm::Object &&a);
		DeploymentLibrary& operator=(DeploymentLibrary &&a);

#endif
		static DeploymentLibrary Cast(const ::Udm::Object &a);
		static DeploymentLibrary Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DeploymentLibrary CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DeploymentLibrary> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DeploymentLibrary, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DeploymentLibrary, Pred>(impl); };
		DeploymentLibrary CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DeploymentLibrary> Derived();
		template <class Pred> ::Udm::DerivedAttr< DeploymentLibrary, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DeploymentLibrary, Pred>(impl); };
		::Udm::ArchetypeAttr< DeploymentLibrary> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::System> System_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::System, Pred> System_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::System, Pred>(impl, meta_System_children); };
		::Udm::ChildrenAttr< ::ESMoL::System> System_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::System, Pred> System_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::System, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_System_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class RootFolder : public ::Udm::Object {
	public:
		RootFolder();
		RootFolder(::Udm::ObjectImpl *impl);
		RootFolder(const RootFolder &master);

#ifdef UDM_RVALUE
		RootFolder(RootFolder &&master);

		static RootFolder Cast(::Udm::Object &&a);
		RootFolder& operator=(RootFolder &&a);

#endif
		static RootFolder Cast(const ::Udm::Object &a);
		static RootFolder Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		RootFolder CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< RootFolder> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< RootFolder, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< RootFolder, Pred>(impl); };
		RootFolder CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< RootFolder> Derived();
		template <class Pred> ::Udm::DerivedAttr< RootFolder, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< RootFolder, Pred>(impl); };
		::Udm::ArchetypeAttr< RootFolder> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary> ArchitectureLibrary_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary, Pred> ArchitectureLibrary_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary, Pred>(impl, meta_ArchitectureLibrary_children); };
		::Udm::ChildrenAttr< ::ESMoL::DesignFolder> DesignFolder_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DesignFolder, Pred> DesignFolder_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DesignFolder, Pred>(impl, meta_DesignFolder_children); };
		::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary> RequirementsLibrary_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary, Pred> RequirementsLibrary_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary, Pred>(impl, meta_RequirementsLibrary_children); };
		::Udm::ChildrenAttr< ::ESMoL::Types> Types_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Types, Pred> Types_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Types, Pred>(impl, meta_Types_children); };
		::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary> PlatformLibrary_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary, Pred> PlatformLibrary_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary, Pred>(impl, meta_PlatformLibrary_children); };
		::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary> DeploymentLibrary_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary, Pred> DeploymentLibrary_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary, Pred>(impl, meta_DeploymentLibrary_children); };
		::Udm::ChildrenAttr< ::ESMoL::RootFolder> RootFolder_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::RootFolder, Pred> RootFolder_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::RootFolder, Pred>(impl, meta_RootFolder_children); };
		::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary> ArchitectureLibrary_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary, Pred> ArchitectureLibrary_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::DesignFolder> DesignFolder_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DesignFolder, Pred> DesignFolder_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DesignFolder, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary> RequirementsLibrary_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary, Pred> RequirementsLibrary_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Types> Types_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Types, Pred> Types_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Types, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary> PlatformLibrary_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary, Pred> PlatformLibrary_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary> DeploymentLibrary_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary, Pred> DeploymentLibrary_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::RootFolder> RootFolder_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::RootFolder, Pred> RootFolder_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::RootFolder, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RootFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::CompositionChildRole meta_ArchitectureLibrary_children;
		static ::Uml::CompositionChildRole meta_DesignFolder_children;
		static ::Uml::CompositionChildRole meta_RequirementsLibrary_children;
		static ::Uml::CompositionChildRole meta_Types_children;
		static ::Uml::CompositionChildRole meta_PlatformLibrary_children;
		static ::Uml::CompositionChildRole meta_DeploymentLibrary_children;
		static ::Uml::CompositionChildRole meta_RootFolder_children;
		static ::Uml::CompositionParentRole meta_RootFolder_parent;

	};

	class MgaObject :  virtual public ::Udm::Object {
	public:
		MgaObject();
		MgaObject(::Udm::ObjectImpl *impl);
		MgaObject(const MgaObject &master);

#ifdef UDM_RVALUE
		MgaObject(MgaObject &&master);

		static MgaObject Cast(::Udm::Object &&a);
		MgaObject& operator=(MgaObject &&a);

#endif
		static MgaObject Cast(const ::Udm::Object &a);
		static MgaObject Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		MgaObject CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< MgaObject> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< MgaObject, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< MgaObject, Pred>(impl); };
		MgaObject CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< MgaObject> Derived();
		template <class Pred> ::Udm::DerivedAttr< MgaObject, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< MgaObject, Pred>(impl); };
		::Udm::ArchetypeAttr< MgaObject> Archetype() const;
		::Udm::StringAttr name() const;
		::Udm::StringAttr position() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_name;
		static ::Uml::Attribute meta_position;

	};

	class FaultScenario :  public MgaObject {
	public:
		FaultScenario();
		FaultScenario(::Udm::ObjectImpl *impl);
		FaultScenario(const FaultScenario &master);

#ifdef UDM_RVALUE
		FaultScenario(FaultScenario &&master);

		static FaultScenario Cast(::Udm::Object &&a);
		FaultScenario& operator=(FaultScenario &&a);

#endif
		static FaultScenario Cast(const ::Udm::Object &a);
		static FaultScenario Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultScenario CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultScenario> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultScenario, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultScenario, Pred>(impl); };
		FaultScenario CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultScenario> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultScenario, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultScenario, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultScenario> Archetype() const;
		::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo> ScenarioInfo_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo, Pred> ScenarioInfo_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo, Pred>(impl, meta_ScenarioInfo_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultTrigger> FaultTrigger_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultTrigger, Pred> FaultTrigger_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultTrigger, Pred>(impl, meta_FaultTrigger_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultCondition> FaultCondition_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultCondition, Pred> FaultCondition_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultCondition, Pred>(impl, meta_FaultCondition_children); };
		::Udm::ChildrenAttr< ::ESMoL::TaskInst> TaskInst_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TaskInst, Pred> TaskInst_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TaskInst, Pred>(impl, meta_TaskInst_children); };
		::Udm::ChildrenAttr< ::ESMoL::Action> Action_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Action, Pred> Action_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Action, Pred>(impl, meta_Action_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask> FaultMgrTask_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask, Pred> FaultMgrTask_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask, Pred>(impl, meta_FaultMgrTask_children); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentBase> ComponentBase_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred> ComponentBase_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred>(impl, meta_ComponentBase_children); };
		::Udm::ChildrenAttr< ::ESMoL::CompBreakout> CompBreakout_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CompBreakout, Pred> CompBreakout_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CompBreakout, Pred>(impl, meta_CompBreakout_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModel_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred> FaultModel_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred>(impl, meta_FaultModel_children); };
		::Udm::ChildrenAttr< ::ESMoL::DesignReference> DesignReference_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DesignReference, Pred> DesignReference_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DesignReference, Pred>(impl, meta_DesignReference_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput> FaultToInput_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput, Pred> FaultToInput_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput, Pred>(impl, meta_FaultToInput_children); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault> OutputToFault_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault, Pred> OutputToFault_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault, Pred>(impl, meta_OutputToFault_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModelRef> FaultModelRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModelRef, Pred> FaultModelRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelRef, Pred>(impl, meta_FaultModelRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo> ScenarioInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo, Pred> ScenarioInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultTrigger> FaultTrigger_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultTrigger, Pred> FaultTrigger_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultTrigger, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultCondition> FaultCondition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultCondition, Pred> FaultCondition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultCondition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ConditionEvent> ConditionEvent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ConditionEvent, Pred> ConditionEvent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ConditionEvent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Precondition> Precondition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Precondition, Pred> Precondition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Precondition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Postcondition> Postcondition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Postcondition, Pred> Postcondition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Postcondition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::DetectionCondition> DetectionCondition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DetectionCondition, Pred> DetectionCondition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DetectionCondition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MitigationCondition> MitigationCondition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MitigationCondition, Pred> MitigationCondition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MitigationCondition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TaskInst> TaskInst_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TaskInst, Pred> TaskInst_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TaskInst, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Action> Action_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Action, Pred> Action_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Action, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::DetectionAction> DetectionAction_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DetectionAction, Pred> DetectionAction_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DetectionAction, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MitigationAction> MitigationAction_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MitigationAction, Pred> MitigationAction_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MitigationAction, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask> FaultMgrTask_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask, Pred> FaultMgrTask_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CompBreakout> CompBreakout_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CompBreakout, Pred> CompBreakout_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CompBreakout, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::DesignReference> DesignReference_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DesignReference, Pred> DesignReference_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DesignReference, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput> FaultToInput_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput, Pred> FaultToInput_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault> OutputToFault_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault, Pred> OutputToFault_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModelRef> FaultModelRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModelRef, Pred> FaultModelRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred> FaultModel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PetriNet> PetriNet_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred> PetriNet_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CCode> CCode_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CCode, Pred> CCode_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CCode, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::SubsystemRef> SubsystemRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SubsystemRef, Pred> SubsystemRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SubsystemRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PetriNetRef> PetriNetRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PetriNetRef, Pred> PetriNetRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNetRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentBase> ComponentBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred> ComponentBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Subsystem> Subsystem_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred> Subsystem_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::DesignFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_ScenarioInfo_children;
		static ::Uml::CompositionChildRole meta_FaultTrigger_children;
		static ::Uml::CompositionChildRole meta_FaultCondition_children;
		static ::Uml::CompositionChildRole meta_TaskInst_children;
		static ::Uml::CompositionChildRole meta_Action_children;
		static ::Uml::CompositionChildRole meta_FaultMgrTask_children;
		static ::Uml::CompositionChildRole meta_ComponentBase_children;
		static ::Uml::CompositionChildRole meta_CompBreakout_children;
		static ::Uml::CompositionChildRole meta_FaultModel_children;
		static ::Uml::CompositionChildRole meta_DesignReference_children;
		static ::Uml::CompositionChildRole meta_FaultToInput_children;
		static ::Uml::CompositionChildRole meta_OutputToFault_children;
		static ::Uml::CompositionChildRole meta_FaultModelRef_children;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;

	};

	class ScenarioInfo :  public MgaObject {
	public:
		ScenarioInfo();
		ScenarioInfo(::Udm::ObjectImpl *impl);
		ScenarioInfo(const ScenarioInfo &master);

#ifdef UDM_RVALUE
		ScenarioInfo(ScenarioInfo &&master);

		static ScenarioInfo Cast(::Udm::Object &&a);
		ScenarioInfo& operator=(ScenarioInfo &&a);

#endif
		static ScenarioInfo Cast(const ::Udm::Object &a);
		static ScenarioInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ScenarioInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ScenarioInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ScenarioInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ScenarioInfo, Pred>(impl); };
		ScenarioInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ScenarioInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< ScenarioInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ScenarioInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< ScenarioInfo> Archetype() const;
		::Udm::StringAttr Requirements() const;
		::Udm::StringAttr ScenarioDescription() const;
		::Udm::StringAttr Criticality() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Requirements;
		static ::Uml::Attribute meta_ScenarioDescription;
		static ::Uml::Attribute meta_Criticality;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class FaultEvent :  virtual  public MgaObject {
	public:
		FaultEvent();
		FaultEvent(::Udm::ObjectImpl *impl);
		FaultEvent(const FaultEvent &master);

#ifdef UDM_RVALUE
		FaultEvent(FaultEvent &&master);

		static FaultEvent Cast(::Udm::Object &&a);
		FaultEvent& operator=(FaultEvent &&a);

#endif
		static FaultEvent Cast(const ::Udm::Object &a);
		static FaultEvent Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultEvent CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultEvent> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultEvent, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultEvent, Pred>(impl); };
		FaultEvent CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultEvent> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultEvent, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultEvent, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultEvent> Archetype() const;
		::Udm::AssocAttr< FaultTrigger> referedbyFaultTrigger() const;
		template <class Pred> ::Udm::AssocAttr< FaultTrigger, Pred> referedbyFaultTrigger_sorted(const Pred &) const { return ::Udm::AssocAttr< FaultTrigger, Pred>(impl, meta_referedbyFaultTrigger); };
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyFaultTrigger;

	};

	class FaultTrigger :  public MgaObject {
	public:
		FaultTrigger();
		FaultTrigger(::Udm::ObjectImpl *impl);
		FaultTrigger(const FaultTrigger &master);

#ifdef UDM_RVALUE
		FaultTrigger(FaultTrigger &&master);

		static FaultTrigger Cast(::Udm::Object &&a);
		FaultTrigger& operator=(FaultTrigger &&a);

#endif
		static FaultTrigger Cast(const ::Udm::Object &a);
		static FaultTrigger Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultTrigger CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultTrigger> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultTrigger, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultTrigger, Pred>(impl); };
		FaultTrigger CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultTrigger> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultTrigger, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultTrigger, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultTrigger> Archetype() const;
		::Udm::PointerAttr< FaultEvent> ref() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class FaultCondition :  virtual  public MgaObject {
	public:
		FaultCondition();
		FaultCondition(::Udm::ObjectImpl *impl);
		FaultCondition(const FaultCondition &master);

#ifdef UDM_RVALUE
		FaultCondition(FaultCondition &&master);

		static FaultCondition Cast(::Udm::Object &&a);
		FaultCondition& operator=(FaultCondition &&a);

#endif
		static FaultCondition Cast(const ::Udm::Object &a);
		static FaultCondition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultCondition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultCondition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultCondition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultCondition, Pred>(impl); };
		FaultCondition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultCondition> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultCondition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultCondition, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultCondition> Archetype() const;
		::Udm::StringAttr Expression() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Expression;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class ConditionEvent :  public FaultCondition,  public FaultEvent {
	public:
		ConditionEvent();
		ConditionEvent(::Udm::ObjectImpl *impl);
		ConditionEvent(const ConditionEvent &master);

#ifdef UDM_RVALUE
		ConditionEvent(ConditionEvent &&master);

		static ConditionEvent Cast(::Udm::Object &&a);
		ConditionEvent& operator=(ConditionEvent &&a);

#endif
		static ConditionEvent Cast(const ::Udm::Object &a);
		static ConditionEvent Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ConditionEvent CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ConditionEvent> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ConditionEvent, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ConditionEvent, Pred>(impl); };
		ConditionEvent CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ConditionEvent> Derived();
		template <class Pred> ::Udm::DerivedAttr< ConditionEvent, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ConditionEvent, Pred>(impl); };
		::Udm::ArchetypeAttr< ConditionEvent> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class Precondition :  public FaultCondition {
	public:
		Precondition();
		Precondition(::Udm::ObjectImpl *impl);
		Precondition(const Precondition &master);

#ifdef UDM_RVALUE
		Precondition(Precondition &&master);

		static Precondition Cast(::Udm::Object &&a);
		Precondition& operator=(Precondition &&a);

#endif
		static Precondition Cast(const ::Udm::Object &a);
		static Precondition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Precondition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Precondition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Precondition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Precondition, Pred>(impl); };
		Precondition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Precondition> Derived();
		template <class Pred> ::Udm::DerivedAttr< Precondition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Precondition, Pred>(impl); };
		::Udm::ArchetypeAttr< Precondition> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class Postcondition :  public FaultCondition {
	public:
		Postcondition();
		Postcondition(::Udm::ObjectImpl *impl);
		Postcondition(const Postcondition &master);

#ifdef UDM_RVALUE
		Postcondition(Postcondition &&master);

		static Postcondition Cast(::Udm::Object &&a);
		Postcondition& operator=(Postcondition &&a);

#endif
		static Postcondition Cast(const ::Udm::Object &a);
		static Postcondition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Postcondition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Postcondition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Postcondition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Postcondition, Pred>(impl); };
		Postcondition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Postcondition> Derived();
		template <class Pred> ::Udm::DerivedAttr< Postcondition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Postcondition, Pred>(impl); };
		::Udm::ArchetypeAttr< Postcondition> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class DetectionCondition :  public FaultCondition {
	public:
		DetectionCondition();
		DetectionCondition(::Udm::ObjectImpl *impl);
		DetectionCondition(const DetectionCondition &master);

#ifdef UDM_RVALUE
		DetectionCondition(DetectionCondition &&master);

		static DetectionCondition Cast(::Udm::Object &&a);
		DetectionCondition& operator=(DetectionCondition &&a);

#endif
		static DetectionCondition Cast(const ::Udm::Object &a);
		static DetectionCondition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DetectionCondition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DetectionCondition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DetectionCondition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DetectionCondition, Pred>(impl); };
		DetectionCondition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DetectionCondition> Derived();
		template <class Pred> ::Udm::DerivedAttr< DetectionCondition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DetectionCondition, Pred>(impl); };
		::Udm::ArchetypeAttr< DetectionCondition> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class MitigationCondition :  public FaultCondition {
	public:
		MitigationCondition();
		MitigationCondition(::Udm::ObjectImpl *impl);
		MitigationCondition(const MitigationCondition &master);

#ifdef UDM_RVALUE
		MitigationCondition(MitigationCondition &&master);

		static MitigationCondition Cast(::Udm::Object &&a);
		MitigationCondition& operator=(MitigationCondition &&a);

#endif
		static MitigationCondition Cast(const ::Udm::Object &a);
		static MitigationCondition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		MitigationCondition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< MitigationCondition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< MitigationCondition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< MitigationCondition, Pred>(impl); };
		MitigationCondition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< MitigationCondition> Derived();
		template <class Pred> ::Udm::DerivedAttr< MitigationCondition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< MitigationCondition, Pred>(impl); };
		::Udm::ArchetypeAttr< MitigationCondition> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class TaskInst :  public MgaObject {
	public:
		TaskInst();
		TaskInst(::Udm::ObjectImpl *impl);
		TaskInst(const TaskInst &master);

#ifdef UDM_RVALUE
		TaskInst(TaskInst &&master);

		static TaskInst Cast(::Udm::Object &&a);
		TaskInst& operator=(TaskInst &&a);

#endif
		static TaskInst Cast(const ::Udm::Object &a);
		static TaskInst Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TaskInst CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TaskInst> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TaskInst, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TaskInst, Pred>(impl); };
		TaskInst CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TaskInst> Derived();
		template <class Pred> ::Udm::DerivedAttr< TaskInst, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TaskInst, Pred>(impl); };
		::Udm::ArchetypeAttr< TaskInst> Archetype() const;
		::Udm::PointerAttr< ComponentRef> ref() const;
		::Udm::AClassAssocAttr< CompBreakout, ComponentBase> srcCompBreakout() const;
		template <class Pred> ::Udm::AClassAssocAttr< CompBreakout, ComponentBase, Pred> srcCompBreakout_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< CompBreakout, ComponentBase, Pred>(impl, meta_srcCompBreakout, meta_srcCompBreakout_rev); };
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::AssociationRole meta_srcCompBreakout;
		static ::Uml::AssociationRole meta_srcCompBreakout_rev;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class Action :  public MgaObject {
	public:
		Action();
		Action(::Udm::ObjectImpl *impl);
		Action(const Action &master);

#ifdef UDM_RVALUE
		Action(Action &&master);

		static Action Cast(::Udm::Object &&a);
		Action& operator=(Action &&a);

#endif
		static Action Cast(const ::Udm::Object &a);
		static Action Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Action CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Action> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Action, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Action, Pred>(impl); };
		Action CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Action> Derived();
		template <class Pred> ::Udm::DerivedAttr< Action, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Action, Pred>(impl); };
		::Udm::ArchetypeAttr< Action> Archetype() const;
		::Udm::PointerAttr< ComponentRef> ref() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class DetectionAction :  public Action {
	public:
		DetectionAction();
		DetectionAction(::Udm::ObjectImpl *impl);
		DetectionAction(const DetectionAction &master);

#ifdef UDM_RVALUE
		DetectionAction(DetectionAction &&master);

		static DetectionAction Cast(::Udm::Object &&a);
		DetectionAction& operator=(DetectionAction &&a);

#endif
		static DetectionAction Cast(const ::Udm::Object &a);
		static DetectionAction Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DetectionAction CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DetectionAction> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DetectionAction, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DetectionAction, Pred>(impl); };
		DetectionAction CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DetectionAction> Derived();
		template <class Pred> ::Udm::DerivedAttr< DetectionAction, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DetectionAction, Pred>(impl); };
		::Udm::ArchetypeAttr< DetectionAction> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class MitigationAction :  public Action {
	public:
		MitigationAction();
		MitigationAction(::Udm::ObjectImpl *impl);
		MitigationAction(const MitigationAction &master);

#ifdef UDM_RVALUE
		MitigationAction(MitigationAction &&master);

		static MitigationAction Cast(::Udm::Object &&a);
		MitigationAction& operator=(MitigationAction &&a);

#endif
		static MitigationAction Cast(const ::Udm::Object &a);
		static MitigationAction Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		MitigationAction CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< MitigationAction> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< MitigationAction, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< MitigationAction, Pred>(impl); };
		MitigationAction CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< MitigationAction> Derived();
		template <class Pred> ::Udm::DerivedAttr< MitigationAction, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< MitigationAction, Pred>(impl); };
		::Udm::ArchetypeAttr< MitigationAction> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;

	};

	class FaultMgrTask :  public MgaObject {
	public:
		FaultMgrTask();
		FaultMgrTask(::Udm::ObjectImpl *impl);
		FaultMgrTask(const FaultMgrTask &master);

#ifdef UDM_RVALUE
		FaultMgrTask(FaultMgrTask &&master);

		static FaultMgrTask Cast(::Udm::Object &&a);
		FaultMgrTask& operator=(FaultMgrTask &&a);

#endif
		static FaultMgrTask Cast(const ::Udm::Object &a);
		static FaultMgrTask Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultMgrTask CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultMgrTask> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultMgrTask, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultMgrTask, Pred>(impl); };
		FaultMgrTask CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultMgrTask> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultMgrTask, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultMgrTask, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultMgrTask> Archetype() const;
		::Udm::PointerAttr< ComponentRef> ref() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class CompBreakout :  public MgaObject {
	public:
		CompBreakout();
		CompBreakout(::Udm::ObjectImpl *impl);
		CompBreakout(const CompBreakout &master);

#ifdef UDM_RVALUE
		CompBreakout(CompBreakout &&master);

		static CompBreakout Cast(::Udm::Object &&a);
		CompBreakout& operator=(CompBreakout &&a);

#endif
		static CompBreakout Cast(const ::Udm::Object &a);
		static CompBreakout Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CompBreakout CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CompBreakout> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CompBreakout, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CompBreakout, Pred>(impl); };
		CompBreakout CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CompBreakout> Derived();
		template <class Pred> ::Udm::DerivedAttr< CompBreakout, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CompBreakout, Pred>(impl); };
		::Udm::ArchetypeAttr< CompBreakout> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::ComponentBase> srcCompBreakout_end() const;
		::Udm::AssocEndAttr< ::ESMoL::TaskInst> dstCompBreakout_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;
		static ::Uml::AssociationRole meta_srcCompBreakout_end_;
		static ::Uml::AssociationRole meta_dstCompBreakout_end_;

	};

	class DesignReference :  public MgaObject {
	public:
		DesignReference();
		DesignReference(::Udm::ObjectImpl *impl);
		DesignReference(const DesignReference &master);

#ifdef UDM_RVALUE
		DesignReference(DesignReference &&master);

		static DesignReference Cast(::Udm::Object &&a);
		DesignReference& operator=(DesignReference &&a);

#endif
		static DesignReference Cast(const ::Udm::Object &a);
		static DesignReference Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DesignReference CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DesignReference> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DesignReference, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DesignReference, Pred>(impl); };
		DesignReference CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DesignReference> Derived();
		template <class Pred> ::Udm::DerivedAttr< DesignReference, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DesignReference, Pred>(impl); };
		::Udm::ArchetypeAttr< DesignReference> Archetype() const;
		::Udm::PointerAttr< System> ref() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class FaultToInput :  public MgaObject {
	public:
		FaultToInput();
		FaultToInput(::Udm::ObjectImpl *impl);
		FaultToInput(const FaultToInput &master);

#ifdef UDM_RVALUE
		FaultToInput(FaultToInput &&master);

		static FaultToInput Cast(::Udm::Object &&a);
		FaultToInput& operator=(FaultToInput &&a);

#endif
		static FaultToInput Cast(const ::Udm::Object &a);
		static FaultToInput Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultToInput CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultToInput> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultToInput, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultToInput, Pred>(impl); };
		FaultToInput CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultToInput> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultToInput, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultToInput, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultToInput> Archetype() const;
		::Udm::StringAttr VectorIndex() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::FaultToInput_Members_Base> srcFaultToInput_end() const;
		::Udm::AssocEndAttr< ::ESMoL::FaultToInput_Members_Base> dstFaultToInput_end() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_VectorIndex;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;
		static ::Uml::AssociationRole meta_srcFaultToInput_end_;
		static ::Uml::AssociationRole meta_dstFaultToInput_end_;

	};

	class OutputToFault :  public MgaObject {
	public:
		OutputToFault();
		OutputToFault(::Udm::ObjectImpl *impl);
		OutputToFault(const OutputToFault &master);

#ifdef UDM_RVALUE
		OutputToFault(OutputToFault &&master);

		static OutputToFault Cast(::Udm::Object &&a);
		OutputToFault& operator=(OutputToFault &&a);

#endif
		static OutputToFault Cast(const ::Udm::Object &a);
		static OutputToFault Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutputToFault CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutputToFault> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutputToFault, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutputToFault, Pred>(impl); };
		OutputToFault CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutputToFault> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutputToFault, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutputToFault, Pred>(impl); };
		::Udm::ArchetypeAttr< OutputToFault> Archetype() const;
		::Udm::StringAttr VectorIndex() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::OutputToFault_Members_Base> srcOutputToFault_end() const;
		::Udm::AssocEndAttr< ::ESMoL::OutputToFault_Members_Base> dstOutputToFault_end() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_VectorIndex;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;
		static ::Uml::AssociationRole meta_srcOutputToFault_end_;
		static ::Uml::AssociationRole meta_dstOutputToFault_end_;

	};

	class FaultModelRef :  public MgaObject {
	public:
		FaultModelRef();
		FaultModelRef(::Udm::ObjectImpl *impl);
		FaultModelRef(const FaultModelRef &master);

#ifdef UDM_RVALUE
		FaultModelRef(FaultModelRef &&master);

		static FaultModelRef Cast(::Udm::Object &&a);
		FaultModelRef& operator=(FaultModelRef &&a);

#endif
		static FaultModelRef Cast(const ::Udm::Object &a);
		static FaultModelRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultModelRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultModelRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultModelRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultModelRef, Pred>(impl); };
		FaultModelRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultModelRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultModelRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultModelRef, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultModelRef> Archetype() const;
		::Udm::PointerAttr< FaultModel> ref() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultScenario> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;

	};

	class FaultModel :  public MgaObject {
	public:
		FaultModel();
		FaultModel(::Udm::ObjectImpl *impl);
		FaultModel(const FaultModel &master);

#ifdef UDM_RVALUE
		FaultModel(FaultModel &&master);

		static FaultModel Cast(::Udm::Object &&a);
		FaultModel& operator=(FaultModel &&a);

#endif
		static FaultModel Cast(const ::Udm::Object &a);
		static FaultModel Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FaultModel CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FaultModel> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FaultModel, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FaultModel, Pred>(impl); };
		FaultModel CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FaultModel> Derived();
		template <class Pred> ::Udm::DerivedAttr< FaultModel, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FaultModel, Pred>(impl); };
		::Udm::ArchetypeAttr< FaultModel> Archetype() const;
		::Udm::AssocAttr< FaultModelRef> referedbyFaultModelRef() const;
		template <class Pred> ::Udm::AssocAttr< FaultModelRef, Pred> referedbyFaultModelRef_sorted(const Pred &) const { return ::Udm::AssocAttr< FaultModelRef, Pred>(impl, meta_referedbyFaultModelRef); };
		::Udm::ChildrenAttr< ::ESMoL::Variable> Variable_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Variable, Pred> Variable_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Variable, Pred>(impl, meta_Variable_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred> FaultToInput_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred> OutputToFault_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Variable> Variable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Variable, Pred> Variable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Variable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultModelFolder> FaultModelFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyFaultModelRef;
		static ::Uml::CompositionChildRole meta_Variable_children;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;
		static ::Uml::CompositionParentRole meta_FaultModelFolder_parent;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;

	};

	class Incorporation :  public MgaObject {
	public:
		Incorporation();
		Incorporation(::Udm::ObjectImpl *impl);
		Incorporation(const Incorporation &master);

#ifdef UDM_RVALUE
		Incorporation(Incorporation &&master);

		static Incorporation Cast(::Udm::Object &&a);
		Incorporation& operator=(Incorporation &&a);

#endif
		static Incorporation Cast(const ::Udm::Object &a);
		static Incorporation Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Incorporation CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Incorporation> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Incorporation, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Incorporation, Pred>(impl); };
		Incorporation CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Incorporation> Derived();
		template <class Pred> ::Udm::DerivedAttr< Incorporation, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Incorporation, Pred>(impl); };
		::Udm::ArchetypeAttr< Incorporation> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> Variable_parent() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_Variable_parent;

	};

	class Additive :  public Incorporation {
	public:
		Additive();
		Additive(::Udm::ObjectImpl *impl);
		Additive(const Additive &master);

#ifdef UDM_RVALUE
		Additive(Additive &&master);

		static Additive Cast(::Udm::Object &&a);
		Additive& operator=(Additive &&a);

#endif
		static Additive Cast(const ::Udm::Object &a);
		static Additive Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Additive CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Additive> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Additive, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Additive, Pred>(impl); };
		Additive CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Additive> Derived();
		template <class Pred> ::Udm::DerivedAttr< Additive, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Additive, Pred>(impl); };
		::Udm::ArchetypeAttr< Additive> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Substitutive :  public Incorporation {
	public:
		Substitutive();
		Substitutive(::Udm::ObjectImpl *impl);
		Substitutive(const Substitutive &master);

#ifdef UDM_RVALUE
		Substitutive(Substitutive &&master);

		static Substitutive Cast(::Udm::Object &&a);
		Substitutive& operator=(Substitutive &&a);

#endif
		static Substitutive Cast(const ::Udm::Object &a);
		static Substitutive Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Substitutive CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Substitutive> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Substitutive, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Substitutive, Pred>(impl); };
		Substitutive CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Substitutive> Derived();
		template <class Pred> ::Udm::DerivedAttr< Substitutive, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Substitutive, Pred>(impl); };
		::Udm::ArchetypeAttr< Substitutive> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Occurrence :  public MgaObject {
	public:
		Occurrence();
		Occurrence(::Udm::ObjectImpl *impl);
		Occurrence(const Occurrence &master);

#ifdef UDM_RVALUE
		Occurrence(Occurrence &&master);

		static Occurrence Cast(::Udm::Object &&a);
		Occurrence& operator=(Occurrence &&a);

#endif
		static Occurrence Cast(const ::Udm::Object &a);
		static Occurrence Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Occurrence CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Occurrence> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Occurrence, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Occurrence, Pred>(impl); };
		Occurrence CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Occurrence> Derived();
		template <class Pred> ::Udm::DerivedAttr< Occurrence, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Occurrence, Pred>(impl); };
		::Udm::ArchetypeAttr< Occurrence> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> Variable_parent() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_Variable_parent;

	};

	class Continuous :  public Occurrence {
	public:
		Continuous();
		Continuous(::Udm::ObjectImpl *impl);
		Continuous(const Continuous &master);

#ifdef UDM_RVALUE
		Continuous(Continuous &&master);

		static Continuous Cast(::Udm::Object &&a);
		Continuous& operator=(Continuous &&a);

#endif
		static Continuous Cast(const ::Udm::Object &a);
		static Continuous Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Continuous CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Continuous> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Continuous, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Continuous, Pred>(impl); };
		Continuous CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Continuous> Derived();
		template <class Pred> ::Udm::DerivedAttr< Continuous, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Continuous, Pred>(impl); };
		::Udm::ArchetypeAttr< Continuous> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Periodic :  public Occurrence {
	public:
		Periodic();
		Periodic(::Udm::ObjectImpl *impl);
		Periodic(const Periodic &master);

#ifdef UDM_RVALUE
		Periodic(Periodic &&master);

		static Periodic Cast(::Udm::Object &&a);
		Periodic& operator=(Periodic &&a);

#endif
		static Periodic Cast(const ::Udm::Object &a);
		static Periodic Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Periodic CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Periodic> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Periodic, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Periodic, Pred>(impl); };
		Periodic CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Periodic> Derived();
		template <class Pred> ::Udm::DerivedAttr< Periodic, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Periodic, Pred>(impl); };
		::Udm::ArchetypeAttr< Periodic> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Intermittent :  public Occurrence {
	public:
		Intermittent();
		Intermittent(::Udm::ObjectImpl *impl);
		Intermittent(const Intermittent &master);

#ifdef UDM_RVALUE
		Intermittent(Intermittent &&master);

		static Intermittent Cast(::Udm::Object &&a);
		Intermittent& operator=(Intermittent &&a);

#endif
		static Intermittent Cast(const ::Udm::Object &a);
		static Intermittent Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Intermittent CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Intermittent> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Intermittent, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Intermittent, Pred>(impl); };
		Intermittent CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Intermittent> Derived();
		template <class Pred> ::Udm::DerivedAttr< Intermittent, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Intermittent, Pred>(impl); };
		::Udm::ArchetypeAttr< Intermittent> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Multiplicative :  public Incorporation {
	public:
		Multiplicative();
		Multiplicative(::Udm::ObjectImpl *impl);
		Multiplicative(const Multiplicative &master);

#ifdef UDM_RVALUE
		Multiplicative(Multiplicative &&master);

		static Multiplicative Cast(::Udm::Object &&a);
		Multiplicative& operator=(Multiplicative &&a);

#endif
		static Multiplicative Cast(const ::Udm::Object &a);
		static Multiplicative Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Multiplicative CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Multiplicative> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Multiplicative, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Multiplicative, Pred>(impl); };
		Multiplicative CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Multiplicative> Derived();
		template <class Pred> ::Udm::DerivedAttr< Multiplicative, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Multiplicative, Pred>(impl); };
		::Udm::ArchetypeAttr< Multiplicative> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Variable :  public FaultToInput_Members_Base,  public MgaObject,  public OutputToFault_Members_Base {
	public:
		Variable();
		Variable(::Udm::ObjectImpl *impl);
		Variable(const Variable &master);

#ifdef UDM_RVALUE
		Variable(Variable &&master);

		static Variable Cast(::Udm::Object &&a);
		Variable& operator=(Variable &&a);

#endif
		static Variable Cast(const ::Udm::Object &a);
		static Variable Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Variable CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Variable> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Variable, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Variable, Pred>(impl); };
		Variable CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Variable> Derived();
		template <class Pred> ::Udm::DerivedAttr< Variable, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Variable, Pred>(impl); };
		::Udm::ArchetypeAttr< Variable> Archetype() const;
		::Udm::ChildrenAttr< ::ESMoL::Occurrence> Occurrence_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Occurrence, Pred> Occurrence_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Occurrence, Pred>(impl, meta_Occurrence_children); };
		::Udm::ChildrenAttr< ::ESMoL::Incorporation> Incorporation_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Incorporation, Pred> Incorporation_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Incorporation, Pred>(impl, meta_Incorporation_children); };
		::Udm::ChildrenAttr< ::ESMoL::ValueObject> ValueObject_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ValueObject, Pred> ValueObject_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ValueObject, Pred>(impl, meta_ValueObject_children); };
		::Udm::ChildrenAttr< ::ESMoL::Additive> Additive_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Additive, Pred> Additive_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Additive, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Substitutive> Substitutive_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Substitutive, Pred> Substitutive_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Substitutive, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Incorporation> Incorporation_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Incorporation, Pred> Incorporation_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Incorporation, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Occurrence> Occurrence_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Occurrence, Pred> Occurrence_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Occurrence, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Continuous> Continuous_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Continuous, Pred> Continuous_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Continuous, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Periodic> Periodic_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Periodic, Pred> Periodic_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Periodic, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Intermittent> Intermittent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Intermittent, Pred> Intermittent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Intermittent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Multiplicative> Multiplicative_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Multiplicative, Pred> Multiplicative_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Multiplicative, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::RandomDistribution> RandomDistribution_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::RandomDistribution, Pred> RandomDistribution_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::RandomDistribution, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Constant> Constant_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Constant, Pred> Constant_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Constant, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Uniform> Uniform_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Uniform, Pred> Uniform_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Uniform, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Normal> Normal_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Normal, Pred> Normal_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Normal, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Exponential> Exponential_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Exponential, Pred> Exponential_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Exponential, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Step> Step_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Step, Pred> Step_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Step, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Pulse> Pulse_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Pulse, Pred> Pulse_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Pulse, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ValueObject> ValueObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ValueObject, Pred> ValueObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ValueObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Functions> Functions_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Functions, Pred> Functions_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Functions, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Sinusoid> Sinusoid_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Sinusoid, Pred> Sinusoid_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Sinusoid, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::FaultModel> FaultModel_parent() const;
		::Udm::ParentAttr< ::ESMoL::FaultModel> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_Occurrence_children;
		static ::Uml::CompositionChildRole meta_Incorporation_children;
		static ::Uml::CompositionChildRole meta_ValueObject_children;
		static ::Uml::CompositionParentRole meta_FaultModel_parent;

	};

	class Interval :  public MgaObject {
	public:
		Interval();
		Interval(::Udm::ObjectImpl *impl);
		Interval(const Interval &master);

#ifdef UDM_RVALUE
		Interval(Interval &&master);

		static Interval Cast(::Udm::Object &&a);
		Interval& operator=(Interval &&a);

#endif
		static Interval Cast(const ::Udm::Object &a);
		static Interval Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Interval CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Interval> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Interval, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Interval, Pred>(impl); };
		Interval CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Interval> Derived();
		template <class Pred> ::Udm::DerivedAttr< Interval, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Interval, Pred>(impl); };
		::Udm::ArchetypeAttr< Interval> Archetype() const;
		::Udm::StringAttr Range() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Range;

	};

	class ValueObject :  public MgaObject {
	public:
		ValueObject();
		ValueObject(::Udm::ObjectImpl *impl);
		ValueObject(const ValueObject &master);

#ifdef UDM_RVALUE
		ValueObject(ValueObject &&master);

		static ValueObject Cast(::Udm::Object &&a);
		ValueObject& operator=(ValueObject &&a);

#endif
		static ValueObject Cast(const ::Udm::Object &a);
		static ValueObject Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ValueObject CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ValueObject> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ValueObject, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ValueObject, Pred>(impl); };
		ValueObject CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ValueObject> Derived();
		template <class Pred> ::Udm::DerivedAttr< ValueObject, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ValueObject, Pred>(impl); };
		::Udm::ArchetypeAttr< ValueObject> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> Variable_parent() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_Variable_parent;

	};

	class RandomDistribution :  public ValueObject {
	public:
		RandomDistribution();
		RandomDistribution(::Udm::ObjectImpl *impl);
		RandomDistribution(const RandomDistribution &master);

#ifdef UDM_RVALUE
		RandomDistribution(RandomDistribution &&master);

		static RandomDistribution Cast(::Udm::Object &&a);
		RandomDistribution& operator=(RandomDistribution &&a);

#endif
		static RandomDistribution Cast(const ::Udm::Object &a);
		static RandomDistribution Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		RandomDistribution CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< RandomDistribution> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< RandomDistribution, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< RandomDistribution, Pred>(impl); };
		RandomDistribution CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< RandomDistribution> Derived();
		template <class Pred> ::Udm::DerivedAttr< RandomDistribution, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< RandomDistribution, Pred>(impl); };
		::Udm::ArchetypeAttr< RandomDistribution> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Constant :  public ValueObject {
	public:
		Constant();
		Constant(::Udm::ObjectImpl *impl);
		Constant(const Constant &master);

#ifdef UDM_RVALUE
		Constant(Constant &&master);

		static Constant Cast(::Udm::Object &&a);
		Constant& operator=(Constant &&a);

#endif
		static Constant Cast(const ::Udm::Object &a);
		static Constant Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Constant CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Constant> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Constant, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Constant, Pred>(impl); };
		Constant CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Constant> Derived();
		template <class Pred> ::Udm::DerivedAttr< Constant, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Constant, Pred>(impl); };
		::Udm::ArchetypeAttr< Constant> Archetype() const;
		::Udm::StringAttr Value() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Value;

	};

	class Uniform :  public RandomDistribution {
	public:
		Uniform();
		Uniform(::Udm::ObjectImpl *impl);
		Uniform(const Uniform &master);

#ifdef UDM_RVALUE
		Uniform(Uniform &&master);

		static Uniform Cast(::Udm::Object &&a);
		Uniform& operator=(Uniform &&a);

#endif
		static Uniform Cast(const ::Udm::Object &a);
		static Uniform Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Uniform CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Uniform> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Uniform, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Uniform, Pred>(impl); };
		Uniform CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Uniform> Derived();
		template <class Pred> ::Udm::DerivedAttr< Uniform, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Uniform, Pred>(impl); };
		::Udm::ArchetypeAttr< Uniform> Archetype() const;
		::Udm::StringAttr LowerBound() const;
		::Udm::StringAttr UpperBound() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_LowerBound;
		static ::Uml::Attribute meta_UpperBound;

	};

	class Normal :  public RandomDistribution {
	public:
		Normal();
		Normal(::Udm::ObjectImpl *impl);
		Normal(const Normal &master);

#ifdef UDM_RVALUE
		Normal(Normal &&master);

		static Normal Cast(::Udm::Object &&a);
		Normal& operator=(Normal &&a);

#endif
		static Normal Cast(const ::Udm::Object &a);
		static Normal Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Normal CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Normal> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Normal, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Normal, Pred>(impl); };
		Normal CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Normal> Derived();
		template <class Pred> ::Udm::DerivedAttr< Normal, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Normal, Pred>(impl); };
		::Udm::ArchetypeAttr< Normal> Archetype() const;
		::Udm::StringAttr Mean() const;
		::Udm::StringAttr StdDev() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Mean;
		static ::Uml::Attribute meta_StdDev;

	};

	class Exponential :  public RandomDistribution {
	public:
		Exponential();
		Exponential(::Udm::ObjectImpl *impl);
		Exponential(const Exponential &master);

#ifdef UDM_RVALUE
		Exponential(Exponential &&master);

		static Exponential Cast(::Udm::Object &&a);
		Exponential& operator=(Exponential &&a);

#endif
		static Exponential Cast(const ::Udm::Object &a);
		static Exponential Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Exponential CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Exponential> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Exponential, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Exponential, Pred>(impl); };
		Exponential CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Exponential> Derived();
		template <class Pred> ::Udm::DerivedAttr< Exponential, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Exponential, Pred>(impl); };
		::Udm::ArchetypeAttr< Exponential> Archetype() const;
		::Udm::StringAttr Rate() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Rate;

	};

	class Functions :  public ValueObject {
	public:
		Functions();
		Functions(::Udm::ObjectImpl *impl);
		Functions(const Functions &master);

#ifdef UDM_RVALUE
		Functions(Functions &&master);

		static Functions Cast(::Udm::Object &&a);
		Functions& operator=(Functions &&a);

#endif
		static Functions Cast(const ::Udm::Object &a);
		static Functions Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Functions CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Functions> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Functions, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Functions, Pred>(impl); };
		Functions CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Functions> Derived();
		template <class Pred> ::Udm::DerivedAttr< Functions, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Functions, Pred>(impl); };
		::Udm::ArchetypeAttr< Functions> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;

	};

	class Step :  public Functions {
	public:
		Step();
		Step(::Udm::ObjectImpl *impl);
		Step(const Step &master);

#ifdef UDM_RVALUE
		Step(Step &&master);

		static Step Cast(::Udm::Object &&a);
		Step& operator=(Step &&a);

#endif
		static Step Cast(const ::Udm::Object &a);
		static Step Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Step CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Step> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Step, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Step, Pred>(impl); };
		Step CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Step> Derived();
		template <class Pred> ::Udm::DerivedAttr< Step, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Step, Pred>(impl); };
		::Udm::ArchetypeAttr< Step> Archetype() const;
		::Udm::StringAttr Shift() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Shift;

	};

	class Pulse :  public Functions {
	public:
		Pulse();
		Pulse(::Udm::ObjectImpl *impl);
		Pulse(const Pulse &master);

#ifdef UDM_RVALUE
		Pulse(Pulse &&master);

		static Pulse Cast(::Udm::Object &&a);
		Pulse& operator=(Pulse &&a);

#endif
		static Pulse Cast(const ::Udm::Object &a);
		static Pulse Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Pulse CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Pulse> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Pulse, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Pulse, Pred>(impl); };
		Pulse CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Pulse> Derived();
		template <class Pred> ::Udm::DerivedAttr< Pulse, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Pulse, Pred>(impl); };
		::Udm::ArchetypeAttr< Pulse> Archetype() const;
		::Udm::StringAttr Shift() const;
		::Udm::StringAttr Duration() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Shift;
		static ::Uml::Attribute meta_Duration;

	};

	class Sinusoid :  public Functions {
	public:
		Sinusoid();
		Sinusoid(::Udm::ObjectImpl *impl);
		Sinusoid(const Sinusoid &master);

#ifdef UDM_RVALUE
		Sinusoid(Sinusoid &&master);

		static Sinusoid Cast(::Udm::Object &&a);
		Sinusoid& operator=(Sinusoid &&a);

#endif
		static Sinusoid Cast(const ::Udm::Object &a);
		static Sinusoid Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Sinusoid CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Sinusoid> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Sinusoid, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Sinusoid, Pred>(impl); };
		Sinusoid CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Sinusoid> Derived();
		template <class Pred> ::Udm::DerivedAttr< Sinusoid, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Sinusoid, Pred>(impl); };
		::Udm::ArchetypeAttr< Sinusoid> Archetype() const;
		::Udm::StringAttr Frequency() const;
		::Udm::StringAttr Phase() const;
		::Udm::ParentAttr< ::ESMoL::Variable> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Frequency;
		static ::Uml::Attribute meta_Phase;

	};

	class TransitionToState :  public MgaObject {
	public:
		TransitionToState();
		TransitionToState(::Udm::ObjectImpl *impl);
		TransitionToState(const TransitionToState &master);

#ifdef UDM_RVALUE
		TransitionToState(TransitionToState &&master);

		static TransitionToState Cast(::Udm::Object &&a);
		TransitionToState& operator=(TransitionToState &&a);

#endif
		static TransitionToState Cast(const ::Udm::Object &a);
		static TransitionToState Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TransitionToState CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TransitionToState> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TransitionToState, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TransitionToState, Pred>(impl); };
		TransitionToState CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TransitionToState> Derived();
		template <class Pred> ::Udm::DerivedAttr< TransitionToState, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TransitionToState, Pred>(impl); };
		::Udm::ArchetypeAttr< TransitionToState> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> PetriNet_parent() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::PNTransition> srcTransitionToState_end() const;
		::Udm::AssocEndAttr< ::ESMoL::PNState> dstTransitionToState_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_PetriNet_parent;
		static ::Uml::AssociationRole meta_srcTransitionToState_end_;
		static ::Uml::AssociationRole meta_dstTransitionToState_end_;

	};

	class StateToTransition :  public MgaObject {
	public:
		StateToTransition();
		StateToTransition(::Udm::ObjectImpl *impl);
		StateToTransition(const StateToTransition &master);

#ifdef UDM_RVALUE
		StateToTransition(StateToTransition &&master);

		static StateToTransition Cast(::Udm::Object &&a);
		StateToTransition& operator=(StateToTransition &&a);

#endif
		static StateToTransition Cast(const ::Udm::Object &a);
		static StateToTransition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateToTransition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateToTransition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateToTransition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateToTransition, Pred>(impl); };
		StateToTransition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateToTransition> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateToTransition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateToTransition, Pred>(impl); };
		::Udm::ArchetypeAttr< StateToTransition> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> PetriNet_parent() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::PNState> srcStateToTransition_end() const;
		::Udm::AssocEndAttr< ::ESMoL::PNTransition> dstStateToTransition_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_PetriNet_parent;
		static ::Uml::AssociationRole meta_srcStateToTransition_end_;
		static ::Uml::AssociationRole meta_dstStateToTransition_end_;

	};

	class PNTransition :  public MgaObject {
	public:
		PNTransition();
		PNTransition(::Udm::ObjectImpl *impl);
		PNTransition(const PNTransition &master);

#ifdef UDM_RVALUE
		PNTransition(PNTransition &&master);

		static PNTransition Cast(::Udm::Object &&a);
		PNTransition& operator=(PNTransition &&a);

#endif
		static PNTransition Cast(const ::Udm::Object &a);
		static PNTransition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PNTransition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PNTransition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PNTransition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PNTransition, Pred>(impl); };
		PNTransition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PNTransition> Derived();
		template <class Pred> ::Udm::DerivedAttr< PNTransition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PNTransition, Pred>(impl); };
		::Udm::ArchetypeAttr< PNTransition> Archetype() const;
		::Udm::StringAttr guard() const;
		::Udm::StringAttr action() const;
		::Udm::AClassAssocAttr< TransitionToState, PNState> dstTransitionToState() const;
		template <class Pred> ::Udm::AClassAssocAttr< TransitionToState, PNState, Pred> dstTransitionToState_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< TransitionToState, PNState, Pred>(impl, meta_dstTransitionToState, meta_dstTransitionToState_rev); };
		::Udm::AClassAssocAttr< StateToTransition, PNState> srcStateToTransition() const;
		template <class Pred> ::Udm::AClassAssocAttr< StateToTransition, PNState, Pred> srcStateToTransition_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< StateToTransition, PNState, Pred>(impl, meta_srcStateToTransition, meta_srcStateToTransition_rev); };
		::Udm::ParentAttr< ::ESMoL::PetriNet> PetriNet_parent() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_guard;
		static ::Uml::Attribute meta_action;
		static ::Uml::AssociationRole meta_dstTransitionToState;
		static ::Uml::AssociationRole meta_dstTransitionToState_rev;
		static ::Uml::AssociationRole meta_srcStateToTransition;
		static ::Uml::AssociationRole meta_srcStateToTransition_rev;
		static ::Uml::CompositionParentRole meta_PetriNet_parent;

	};

	class PNState :  public MgaObject {
	public:
		PNState();
		PNState(::Udm::ObjectImpl *impl);
		PNState(const PNState &master);

#ifdef UDM_RVALUE
		PNState(PNState &&master);

		static PNState Cast(::Udm::Object &&a);
		PNState& operator=(PNState &&a);

#endif
		static PNState Cast(const ::Udm::Object &a);
		static PNState Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PNState CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PNState> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PNState, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PNState, Pred>(impl); };
		PNState CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PNState> Derived();
		template <class Pred> ::Udm::DerivedAttr< PNState, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PNState, Pred>(impl); };
		::Udm::ArchetypeAttr< PNState> Archetype() const;
		::Udm::BooleanAttr initial() const;
		::Udm::AClassAssocAttr< TransitionToState, PNTransition> srcTransitionToState() const;
		template <class Pred> ::Udm::AClassAssocAttr< TransitionToState, PNTransition, Pred> srcTransitionToState_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< TransitionToState, PNTransition, Pred>(impl, meta_srcTransitionToState, meta_srcTransitionToState_rev); };
		::Udm::AClassAssocAttr< StateToTransition, PNTransition> dstStateToTransition() const;
		template <class Pred> ::Udm::AClassAssocAttr< StateToTransition, PNTransition, Pred> dstStateToTransition_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< StateToTransition, PNTransition, Pred>(impl, meta_dstStateToTransition, meta_dstStateToTransition_rev); };
		::Udm::ParentAttr< ::ESMoL::PetriNet> PetriNet_parent() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_initial;
		static ::Uml::AssociationRole meta_srcTransitionToState;
		static ::Uml::AssociationRole meta_srcTransitionToState_rev;
		static ::Uml::AssociationRole meta_dstStateToTransition;
		static ::Uml::AssociationRole meta_dstStateToTransition_rev;
		static ::Uml::CompositionParentRole meta_PetriNet_parent;

	};

	class BIPConnector :  public MgaObject {
	public:
		BIPConnector();
		BIPConnector(::Udm::ObjectImpl *impl);
		BIPConnector(const BIPConnector &master);

#ifdef UDM_RVALUE
		BIPConnector(BIPConnector &&master);

		static BIPConnector Cast(::Udm::Object &&a);
		BIPConnector& operator=(BIPConnector &&a);

#endif
		static BIPConnector Cast(const ::Udm::Object &a);
		static BIPConnector Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BIPConnector CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BIPConnector> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BIPConnector, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BIPConnector, Pred>(impl); };
		BIPConnector CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BIPConnector> Derived();
		template <class Pred> ::Udm::DerivedAttr< BIPConnector, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BIPConnector, Pred>(impl); };
		::Udm::ArchetypeAttr< BIPConnector> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Module> Module_parent() const;
		::Udm::ParentAttr< ::ESMoL::Module> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::PNPort> srcPortToPort_end() const;
		::Udm::AssocEndAttr< ::ESMoL::PNPort> dstPortToPort_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_Module_parent;
		static ::Uml::AssociationRole meta_srcPortToPort_end_;
		static ::Uml::AssociationRole meta_dstPortToPort_end_;

	};

	class PNVarRef :  public MgaObject {
	public:
		PNVarRef();
		PNVarRef(::Udm::ObjectImpl *impl);
		PNVarRef(const PNVarRef &master);

#ifdef UDM_RVALUE
		PNVarRef(PNVarRef &&master);

		static PNVarRef Cast(::Udm::Object &&a);
		PNVarRef& operator=(PNVarRef &&a);

#endif
		static PNVarRef Cast(const ::Udm::Object &a);
		static PNVarRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PNVarRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PNVarRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PNVarRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PNVarRef, Pred>(impl); };
		PNVarRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PNVarRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< PNVarRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PNVarRef, Pred>(impl); };
		::Udm::ArchetypeAttr< PNVarRef> Archetype() const;
		::Udm::PointerAttr< PNVariable> ref() const;
		::Udm::ParentAttr< ::ESMoL::PNPort> PNPort_parent() const;
		::Udm::ParentAttr< ::ESMoL::PNPort> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_PNPort_parent;

	};

	class Module :  public MgaObject {
	public:
		Module();
		Module(::Udm::ObjectImpl *impl);
		Module(const Module &master);

#ifdef UDM_RVALUE
		Module(Module &&master);

		static Module Cast(::Udm::Object &&a);
		Module& operator=(Module &&a);

#endif
		static Module Cast(const ::Udm::Object &a);
		static Module Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Module CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Module> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Module, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Module, Pred>(impl); };
		Module CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Module> Derived();
		template <class Pred> ::Udm::DerivedAttr< Module, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Module, Pred>(impl); };
		::Udm::ArchetypeAttr< Module> Archetype() const;
		::Udm::ChildrenAttr< ::ESMoL::BIPConnector> BIPConnector_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BIPConnector, Pred> BIPConnector_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BIPConnector, Pred>(impl, meta_BIPConnector_children); };
		::Udm::ChildrenAttr< ::ESMoL::PetriNet> PetriNet_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred> PetriNet_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred>(impl, meta_PetriNet_children); };
		::Udm::ChildrenAttr< ::ESMoL::BIPConnector> BIPConnector_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BIPConnector, Pred> BIPConnector_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BIPConnector, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PetriNet> PetriNet_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred> PetriNet_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentBase> ComponentBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred> ComponentBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> ModelsFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_BIPConnector_children;
		static ::Uml::CompositionChildRole meta_PetriNet_children;
		static ::Uml::CompositionParentRole meta_ModelsFolder_parent;

	};

	class ModelInfo :  public MgaObject {
	public:
		ModelInfo();
		ModelInfo(::Udm::ObjectImpl *impl);
		ModelInfo(const ModelInfo &master);

#ifdef UDM_RVALUE
		ModelInfo(ModelInfo &&master);

		static ModelInfo Cast(::Udm::Object &&a);
		ModelInfo& operator=(ModelInfo &&a);

#endif
		static ModelInfo Cast(const ::Udm::Object &a);
		static ModelInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ModelInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ModelInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ModelInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ModelInfo, Pred>(impl); };
		ModelInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ModelInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< ModelInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ModelInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< ModelInfo> Archetype() const;
		::Udm::StringAttr ModelPath() const;
		::Udm::StringAttr DateTimeStamp() const;
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> ModelsFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::ModelsFolder> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_ModelPath;
		static ::Uml::Attribute meta_DateTimeStamp;
		static ::Uml::CompositionParentRole meta_ModelsFolder_parent;

	};

	class ExecutionInfo :  public MgaObject {
	public:
		ExecutionInfo();
		ExecutionInfo(::Udm::ObjectImpl *impl);
		ExecutionInfo(const ExecutionInfo &master);

#ifdef UDM_RVALUE
		ExecutionInfo(ExecutionInfo &&master);

		static ExecutionInfo Cast(::Udm::Object &&a);
		ExecutionInfo& operator=(ExecutionInfo &&a);

#endif
		static ExecutionInfo Cast(const ::Udm::Object &a);
		static ExecutionInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ExecutionInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ExecutionInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ExecutionInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ExecutionInfo, Pred>(impl); };
		ExecutionInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ExecutionInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< ExecutionInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ExecutionInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< ExecutionInfo> Archetype() const;
		::Udm::StringAttr WCDuration() const;
		::Udm::StringAttr RelDeadline() const;
		::Udm::AClassAssocAttr< ExecutionAssignment, Executable> dstExecutionAssignment() const;
		template <class Pred> ::Udm::AClassAssocAttr< ExecutionAssignment, Executable, Pred> dstExecutionAssignment_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< ExecutionAssignment, Executable, Pred>(impl, meta_dstExecutionAssignment, meta_dstExecutionAssignment_rev); };
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_WCDuration;
		static ::Uml::Attribute meta_RelDeadline;
		static ::Uml::AssociationRole meta_dstExecutionAssignment;
		static ::Uml::AssociationRole meta_dstExecutionAssignment_rev;
		static ::Uml::CompositionParentRole meta_System_parent;

	};

	class ExecutionContext :  public MgaObject {
	public:
		ExecutionContext();
		ExecutionContext(::Udm::ObjectImpl *impl);
		ExecutionContext(const ExecutionContext &master);

#ifdef UDM_RVALUE
		ExecutionContext(ExecutionContext &&master);

		static ExecutionContext Cast(::Udm::Object &&a);
		ExecutionContext& operator=(ExecutionContext &&a);

#endif
		static ExecutionContext Cast(const ::Udm::Object &a);
		static ExecutionContext Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ExecutionContext CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ExecutionContext> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ExecutionContext, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ExecutionContext, Pred>(impl); };
		ExecutionContext CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ExecutionContext> Derived();
		template <class Pred> ::Udm::DerivedAttr< ExecutionContext, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ExecutionContext, Pred>(impl); };
		::Udm::ArchetypeAttr< ExecutionContext> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HWElement> HWElement_parent() const;
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_HWElement_parent;

	};

	class TTExecContext :  public ExecutionContext {
	public:
		TTExecContext();
		TTExecContext(::Udm::ObjectImpl *impl);
		TTExecContext(const TTExecContext &master);

#ifdef UDM_RVALUE
		TTExecContext(TTExecContext &&master);

		static TTExecContext Cast(::Udm::Object &&a);
		TTExecContext& operator=(TTExecContext &&a);

#endif
		static TTExecContext Cast(const ::Udm::Object &a);
		static TTExecContext Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TTExecContext CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TTExecContext> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TTExecContext, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TTExecContext, Pred>(impl); };
		TTExecContext CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TTExecContext> Derived();
		template <class Pred> ::Udm::DerivedAttr< TTExecContext, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TTExecContext, Pred>(impl); };
		::Udm::ArchetypeAttr< TTExecContext> Archetype() const;
		::Udm::StringAttr Hyperperiod() const;
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Hyperperiod;

	};

	class PeriodicExecInfo :  public ExecutionInfo {
	public:
		PeriodicExecInfo();
		PeriodicExecInfo(::Udm::ObjectImpl *impl);
		PeriodicExecInfo(const PeriodicExecInfo &master);

#ifdef UDM_RVALUE
		PeriodicExecInfo(PeriodicExecInfo &&master);

		static PeriodicExecInfo Cast(::Udm::Object &&a);
		PeriodicExecInfo& operator=(PeriodicExecInfo &&a);

#endif
		static PeriodicExecInfo Cast(const ::Udm::Object &a);
		static PeriodicExecInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PeriodicExecInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PeriodicExecInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PeriodicExecInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PeriodicExecInfo, Pred>(impl); };
		PeriodicExecInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PeriodicExecInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< PeriodicExecInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PeriodicExecInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< PeriodicExecInfo> Archetype() const;
		::Udm::StringAttr ExecPeriod() const;
		::Udm::StringAttr DesiredOffset() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_ExecPeriod;
		static ::Uml::Attribute meta_DesiredOffset;

	};

	class TTExecInfo :  public PeriodicExecInfo {
	public:
		TTExecInfo();
		TTExecInfo(::Udm::ObjectImpl *impl);
		TTExecInfo(const TTExecInfo &master);

#ifdef UDM_RVALUE
		TTExecInfo(TTExecInfo &&master);

		static TTExecInfo Cast(::Udm::Object &&a);
		TTExecInfo& operator=(TTExecInfo &&a);

#endif
		static TTExecInfo Cast(const ::Udm::Object &a);
		static TTExecInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TTExecInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TTExecInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TTExecInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TTExecInfo, Pred>(impl); };
		TTExecInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TTExecInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< TTExecInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TTExecInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< TTExecInfo> Archetype() const;
		::Udm::StringAttr TTSchedule() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_TTSchedule;

	};

	class AsyncPeriodicExecInfo :  public PeriodicExecInfo {
	public:
		AsyncPeriodicExecInfo();
		AsyncPeriodicExecInfo(::Udm::ObjectImpl *impl);
		AsyncPeriodicExecInfo(const AsyncPeriodicExecInfo &master);

#ifdef UDM_RVALUE
		AsyncPeriodicExecInfo(AsyncPeriodicExecInfo &&master);

		static AsyncPeriodicExecInfo Cast(::Udm::Object &&a);
		AsyncPeriodicExecInfo& operator=(AsyncPeriodicExecInfo &&a);

#endif
		static AsyncPeriodicExecInfo Cast(const ::Udm::Object &a);
		static AsyncPeriodicExecInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		AsyncPeriodicExecInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< AsyncPeriodicExecInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< AsyncPeriodicExecInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< AsyncPeriodicExecInfo, Pred>(impl); };
		AsyncPeriodicExecInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< AsyncPeriodicExecInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< AsyncPeriodicExecInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< AsyncPeriodicExecInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< AsyncPeriodicExecInfo> Archetype() const;
		::Udm::StringAttr TerminationTime() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_TerminationTime;

	};

	class ExecutionAssignment :  public MgaObject {
	public:
		typedef std::pair< ::ESMoL::ExecutionInfo, std::vector< ::Udm::Object> > srcExecutionAssignment_chain_t;

		ExecutionAssignment();
		ExecutionAssignment(::Udm::ObjectImpl *impl);
		ExecutionAssignment(const ExecutionAssignment &master);

#ifdef UDM_RVALUE
		ExecutionAssignment(ExecutionAssignment &&master);

		static ExecutionAssignment Cast(::Udm::Object &&a);
		ExecutionAssignment& operator=(ExecutionAssignment &&a);

#endif
		static ExecutionAssignment Cast(const ::Udm::Object &a);
		static ExecutionAssignment Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ExecutionAssignment CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ExecutionAssignment> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ExecutionAssignment, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ExecutionAssignment, Pred>(impl); };
		ExecutionAssignment CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ExecutionAssignment> Derived();
		template <class Pred> ::Udm::DerivedAttr< ExecutionAssignment, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ExecutionAssignment, Pred>(impl); };
		::Udm::ArchetypeAttr< ExecutionAssignment> Archetype() const;
		::Udm::PointerAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> dstExecutionAssignment__rp_helper() const;
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::ExecutionInfo> srcExecutionAssignment_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::ExecutionInfo, srcExecutionAssignment_chain_t > srcExecutionAssignment_chain() const;
		::Udm::AssocEndAttr< ::ESMoL::Executable> dstExecutionAssignment_end() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstExecutionAssignment__rp_helper;
		static ::Uml::CompositionParentRole meta_System_parent;
		static ::Uml::AssociationRole meta_srcExecutionAssignment_end_;
		static ::Uml::AssociationRole meta_dstExecutionAssignment_end_;

	};

	class Executable :  virtual  public MgaObject {
	public:
		Executable();
		Executable(::Udm::ObjectImpl *impl);
		Executable(const Executable &master);

#ifdef UDM_RVALUE
		Executable(Executable &&master);

		static Executable Cast(::Udm::Object &&a);
		Executable& operator=(Executable &&a);

#endif
		static Executable Cast(const ::Udm::Object &a);
		static Executable Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Executable CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Executable> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Executable, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Executable, Pred>(impl); };
		Executable CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Executable> Derived();
		template <class Pred> ::Udm::DerivedAttr< Executable, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Executable, Pred>(impl); };
		::Udm::ArchetypeAttr< Executable> Archetype() const;
		::Udm::AClassAssocAttr< ExecutionAssignment, ExecutionInfo> srcExecutionAssignment() const;
		template <class Pred> ::Udm::AClassAssocAttr< ExecutionAssignment, ExecutionInfo, Pred> srcExecutionAssignment_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< ExecutionAssignment, ExecutionInfo, Pred>(impl, meta_srcExecutionAssignment, meta_srcExecutionAssignment_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcExecutionAssignment;
		static ::Uml::AssociationRole meta_srcExecutionAssignment_rev;

	};

	class AperiodicExecInfo :  public ExecutionInfo {
	public:
		AperiodicExecInfo();
		AperiodicExecInfo(::Udm::ObjectImpl *impl);
		AperiodicExecInfo(const AperiodicExecInfo &master);

#ifdef UDM_RVALUE
		AperiodicExecInfo(AperiodicExecInfo &&master);

		static AperiodicExecInfo Cast(::Udm::Object &&a);
		AperiodicExecInfo& operator=(AperiodicExecInfo &&a);

#endif
		static AperiodicExecInfo Cast(const ::Udm::Object &a);
		static AperiodicExecInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		AperiodicExecInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< AperiodicExecInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< AperiodicExecInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< AperiodicExecInfo, Pred>(impl); };
		AperiodicExecInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< AperiodicExecInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< AperiodicExecInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< AperiodicExecInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< AperiodicExecInfo> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;

	};

	class SporadicExecInfo :  public AperiodicExecInfo {
	public:
		SporadicExecInfo();
		SporadicExecInfo(::Udm::ObjectImpl *impl);
		SporadicExecInfo(const SporadicExecInfo &master);

#ifdef UDM_RVALUE
		SporadicExecInfo(SporadicExecInfo &&master);

		static SporadicExecInfo Cast(::Udm::Object &&a);
		SporadicExecInfo& operator=(SporadicExecInfo &&a);

#endif
		static SporadicExecInfo Cast(const ::Udm::Object &a);
		static SporadicExecInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SporadicExecInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SporadicExecInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SporadicExecInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SporadicExecInfo, Pred>(impl); };
		SporadicExecInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SporadicExecInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< SporadicExecInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SporadicExecInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< SporadicExecInfo> Archetype() const;
		::Udm::StringAttr MinimumPeriod() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_MinimumPeriod;

	};

	class FieldDataType :  public MgaObject {
	public:
		FieldDataType();
		FieldDataType(::Udm::ObjectImpl *impl);
		FieldDataType(const FieldDataType &master);

#ifdef UDM_RVALUE
		FieldDataType(FieldDataType &&master);

		static FieldDataType Cast(::Udm::Object &&a);
		FieldDataType& operator=(FieldDataType &&a);

#endif
		static FieldDataType Cast(const ::Udm::Object &a);
		static FieldDataType Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		FieldDataType CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< FieldDataType> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< FieldDataType, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< FieldDataType, Pred>(impl); };
		FieldDataType CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< FieldDataType> Derived();
		template <class Pred> ::Udm::DerivedAttr< FieldDataType, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< FieldDataType, Pred>(impl); };
		::Udm::ArchetypeAttr< FieldDataType> Archetype() const;
		::Udm::IntegerAttr NumBits() const;
		::Udm::StringAttr InitialValue() const;
		::Udm::ParentAttr< ::ESMoL::MsgPort> MsgPort_parent() const;
		::Udm::ParentAttr< ::ESMoL::MsgPort> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_NumBits;
		static ::Uml::Attribute meta_InitialValue;
		static ::Uml::CompositionParentRole meta_MsgPort_parent;

	};

	class BitField :  public FieldDataType {
	public:
		BitField();
		BitField(::Udm::ObjectImpl *impl);
		BitField(const BitField &master);

#ifdef UDM_RVALUE
		BitField(BitField &&master);

		static BitField Cast(::Udm::Object &&a);
		BitField& operator=(BitField &&a);

#endif
		static BitField Cast(const ::Udm::Object &a);
		static BitField Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BitField CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BitField> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BitField, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BitField, Pred>(impl); };
		BitField CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BitField> Derived();
		template <class Pred> ::Udm::DerivedAttr< BitField, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BitField, Pred>(impl); };
		::Udm::ArchetypeAttr< BitField> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::MsgPort> parent() const;

		static ::Uml::Class meta;

	};

	class ValueType :  public FieldDataType {
	public:
		ValueType();
		ValueType(::Udm::ObjectImpl *impl);
		ValueType(const ValueType &master);

#ifdef UDM_RVALUE
		ValueType(ValueType &&master);

		static ValueType Cast(::Udm::Object &&a);
		ValueType& operator=(ValueType &&a);

#endif
		static ValueType Cast(const ::Udm::Object &a);
		static ValueType Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ValueType CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ValueType> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ValueType, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ValueType, Pred>(impl); };
		ValueType CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ValueType> Derived();
		template <class Pred> ::Udm::DerivedAttr< ValueType, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ValueType, Pred>(impl); };
		::Udm::ArchetypeAttr< ValueType> Archetype() const;
		::Udm::StringAttr Scale() const;
		::Udm::BooleanAttr Signed() const;
		::Udm::StringAttr DataType() const;
		::Udm::StringAttr MinValue() const;
		::Udm::StringAttr MaxValue() const;
		::Udm::StringAttr Units() const;
		::Udm::StringAttr Offset() const;
		::Udm::ParentAttr< ::ESMoL::MsgPort> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Scale;
		static ::Uml::Attribute meta_Signed;
		static ::Uml::Attribute meta_DataType;
		static ::Uml::Attribute meta_MinValue;
		static ::Uml::Attribute meta_MaxValue;
		static ::Uml::Attribute meta_Units;
		static ::Uml::Attribute meta_Offset;

	};

	class IOPortExp :  virtual  public MgaObject {
	public:
		IOPortExp();
		IOPortExp(::Udm::ObjectImpl *impl);
		IOPortExp(const IOPortExp &master);

#ifdef UDM_RVALUE
		IOPortExp(IOPortExp &&master);

		static IOPortExp Cast(::Udm::Object &&a);
		IOPortExp& operator=(IOPortExp &&a);

#endif
		static IOPortExp Cast(const ::Udm::Object &a);
		static IOPortExp Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IOPortExp CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IOPortExp> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IOPortExp, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IOPortExp, Pred>(impl); };
		IOPortExp CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IOPortExp> Derived();
		template <class Pred> ::Udm::DerivedAttr< IOPortExp, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IOPortExp, Pred>(impl); };
		::Udm::ArchetypeAttr< IOPortExp> Archetype() const;
		::Udm::AClassAssocAttr< IOPortAssignment, IOPortInfoBase> srcIOPortAssignment() const;
		template <class Pred> ::Udm::AClassAssocAttr< IOPortAssignment, IOPortInfoBase, Pred> srcIOPortAssignment_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< IOPortAssignment, IOPortInfoBase, Pred>(impl, meta_srcIOPortAssignment, meta_srcIOPortAssignment_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcIOPortAssignment;
		static ::Uml::AssociationRole meta_srcIOPortAssignment_rev;

	};

	class IOPortAssignment :  public MgaObject {
	public:
		IOPortAssignment();
		IOPortAssignment(::Udm::ObjectImpl *impl);
		IOPortAssignment(const IOPortAssignment &master);

#ifdef UDM_RVALUE
		IOPortAssignment(IOPortAssignment &&master);

		static IOPortAssignment Cast(::Udm::Object &&a);
		IOPortAssignment& operator=(IOPortAssignment &&a);

#endif
		static IOPortAssignment Cast(const ::Udm::Object &a);
		static IOPortAssignment Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IOPortAssignment CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IOPortAssignment> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IOPortAssignment, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IOPortAssignment, Pred>(impl); };
		IOPortAssignment CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IOPortAssignment> Derived();
		template <class Pred> ::Udm::DerivedAttr< IOPortAssignment, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IOPortAssignment, Pred>(impl); };
		::Udm::ArchetypeAttr< IOPortAssignment> Archetype() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::IOPortInfoBase> srcIOPortAssignment_end() const;
		::Udm::AssocEndAttr< ::ESMoL::IOPortExp> dstIOPortAssignment_end() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcIOPortAssignment_end_;
		static ::Uml::AssociationRole meta_dstIOPortAssignment_end_;

	};

	class IOPortInfoBase :  public MgaObject {
	public:
		IOPortInfoBase();
		IOPortInfoBase(::Udm::ObjectImpl *impl);
		IOPortInfoBase(const IOPortInfoBase &master);

#ifdef UDM_RVALUE
		IOPortInfoBase(IOPortInfoBase &&master);

		static IOPortInfoBase Cast(::Udm::Object &&a);
		IOPortInfoBase& operator=(IOPortInfoBase &&a);

#endif
		static IOPortInfoBase Cast(const ::Udm::Object &a);
		static IOPortInfoBase Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IOPortInfoBase CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IOPortInfoBase> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IOPortInfoBase, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IOPortInfoBase, Pred>(impl); };
		IOPortInfoBase CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IOPortInfoBase> Derived();
		template <class Pred> ::Udm::DerivedAttr< IOPortInfoBase, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IOPortInfoBase, Pred>(impl); };
		::Udm::ArchetypeAttr< IOPortInfoBase> Archetype() const;
		::Udm::AClassAssocAttr< IOPortAssignment, IOPortExp> dstIOPortAssignment() const;
		template <class Pred> ::Udm::AClassAssocAttr< IOPortAssignment, IOPortExp, Pred> dstIOPortAssignment_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< IOPortAssignment, IOPortExp, Pred>(impl, meta_dstIOPortAssignment, meta_dstIOPortAssignment_rev); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstIOPortAssignment;
		static ::Uml::AssociationRole meta_dstIOPortAssignment_rev;

	};

	class IOPortInfo :  public IOPortInfoBase {
	public:
		IOPortInfo();
		IOPortInfo(::Udm::ObjectImpl *impl);
		IOPortInfo(const IOPortInfo &master);

#ifdef UDM_RVALUE
		IOPortInfo(IOPortInfo &&master);

		static IOPortInfo Cast(::Udm::Object &&a);
		IOPortInfo& operator=(IOPortInfo &&a);

#endif
		static IOPortInfo Cast(const ::Udm::Object &a);
		static IOPortInfo Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IOPortInfo CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IOPortInfo> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IOPortInfo, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IOPortInfo, Pred>(impl); };
		IOPortInfo CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IOPortInfo> Derived();
		template <class Pred> ::Udm::DerivedAttr< IOPortInfo, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IOPortInfo, Pred>(impl); };
		::Udm::ArchetypeAttr< IOPortInfo> Archetype() const;
		::Udm::StringAttr DataSize() const;
		::Udm::StringAttr DataInit() const;
		::Udm::StringAttr DataMin() const;
		::Udm::StringAttr DataMax() const;
		::Udm::StringAttr Scale() const;
		::Udm::StringAttr Offset() const;
		::Udm::AssocAttr< IOPortInfoRef> referedbyIOPortInfoRef() const;
		template <class Pred> ::Udm::AssocAttr< IOPortInfoRef, Pred> referedbyIOPortInfoRef_sorted(const Pred &) const { return ::Udm::AssocAttr< IOPortInfoRef, Pred>(impl, meta_referedbyIOPortInfoRef); };
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_DataSize;
		static ::Uml::Attribute meta_DataInit;
		static ::Uml::Attribute meta_DataMin;
		static ::Uml::Attribute meta_DataMax;
		static ::Uml::Attribute meta_Scale;
		static ::Uml::Attribute meta_Offset;
		static ::Uml::AssociationRole meta_referedbyIOPortInfoRef;

	};

	class IOPortInfoRef :  public IOPortInfoBase {
	public:
		IOPortInfoRef();
		IOPortInfoRef(::Udm::ObjectImpl *impl);
		IOPortInfoRef(const IOPortInfoRef &master);

#ifdef UDM_RVALUE
		IOPortInfoRef(IOPortInfoRef &&master);

		static IOPortInfoRef Cast(::Udm::Object &&a);
		IOPortInfoRef& operator=(IOPortInfoRef &&a);

#endif
		static IOPortInfoRef Cast(const ::Udm::Object &a);
		static IOPortInfoRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IOPortInfoRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IOPortInfoRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IOPortInfoRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IOPortInfoRef, Pred>(impl); };
		IOPortInfoRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IOPortInfoRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< IOPortInfoRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IOPortInfoRef, Pred>(impl); };
		::Udm::ArchetypeAttr< IOPortInfoRef> Archetype() const;
		::Udm::PointerAttr< IOPortInfo> ref() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;

	};

	class OldTask :  public MgaObject {
	public:
		OldTask();
		OldTask(::Udm::ObjectImpl *impl);
		OldTask(const OldTask &master);

#ifdef UDM_RVALUE
		OldTask(OldTask &&master);

		static OldTask Cast(::Udm::Object &&a);
		OldTask& operator=(OldTask &&a);

#endif
		static OldTask Cast(const ::Udm::Object &a);
		static OldTask Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OldTask CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OldTask> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OldTask, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OldTask, Pred>(impl); };
		OldTask CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OldTask> Derived();
		template <class Pred> ::Udm::DerivedAttr< OldTask, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OldTask, Pred>(impl); };
		::Udm::ArchetypeAttr< OldTask> Archetype() const;
		::Udm::IntegerAttr Priority() const;
		::Udm::StringAttr TaskType() const;
		::Udm::IntegerAttr Activation() const;
		::Udm::BooleanAttr AutoStart() const;
		::Udm::StringAttr Preemption() const;
		::Udm::BooleanAttr Cyclic() const;
		::Udm::IntegerAttr CycleTime() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Priority;
		static ::Uml::Attribute meta_TaskType;
		static ::Uml::Attribute meta_Activation;
		static ::Uml::Attribute meta_AutoStart;
		static ::Uml::Attribute meta_Preemption;
		static ::Uml::Attribute meta_Cyclic;
		static ::Uml::Attribute meta_CycleTime;

	};

	class SystemTypes :  public MgaObject {
	public:
		SystemTypes();
		SystemTypes(::Udm::ObjectImpl *impl);
		SystemTypes(const SystemTypes &master);

#ifdef UDM_RVALUE
		SystemTypes(SystemTypes &&master);

		static SystemTypes Cast(::Udm::Object &&a);
		SystemTypes& operator=(SystemTypes &&a);

#endif
		static SystemTypes Cast(const ::Udm::Object &a);
		static SystemTypes Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SystemTypes CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SystemTypes> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SystemTypes, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SystemTypes, Pred>(impl); };
		SystemTypes CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SystemTypes> Derived();
		template <class Pred> ::Udm::DerivedAttr< SystemTypes, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SystemTypes, Pred>(impl); };
		::Udm::ArchetypeAttr< SystemTypes> Archetype() const;
		::Udm::ChildrenAttr< ::ESMoL::Message> Message_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Message, Pred> Message_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Message, Pred>(impl, meta_Message_children); };
		::Udm::ChildrenAttr< ::ESMoL::Component> Component_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Component, Pred> Component_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Component, Pred>(impl, meta_Component_children); };
		::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base> MessageRef_RefersTo_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base, Pred> MessageRef_RefersTo_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base> ComponentRef_RefersTo_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base, Pred> ComponentRef_RefersTo_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CANMessage> CANMessage_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CANMessage, Pred> CANMessage_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CANMessage, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::AutoCANMessage> AutoCANMessage_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::AutoCANMessage, Pred> AutoCANMessage_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::AutoCANMessage, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Message> Message_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Message, Pred> Message_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Message, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PlantComponent> PlantComponent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PlantComponent, Pred> PlantComponent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PlantComponent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Component> Component_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Component, Pred> Component_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Component, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::ArchitectureLibrary> ArchitectureLibrary_parent() const;
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_Message_children;
		static ::Uml::CompositionChildRole meta_Component_children;
		static ::Uml::CompositionParentRole meta_ArchitectureLibrary_parent;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;

	};

	class Connector :  public MgaObject {
	public:
		typedef std::pair< ::ESMoL::Output, std::vector< ::Udm::Object> > srcConnector_chain_t;
		typedef std::pair< ::ESMoL::Input, std::vector< ::Udm::Object> > dstConnector_chain_t;

		Connector();
		Connector(::Udm::ObjectImpl *impl);
		Connector(const Connector &master);

#ifdef UDM_RVALUE
		Connector(Connector &&master);

		static Connector Cast(::Udm::Object &&a);
		Connector& operator=(Connector &&a);

#endif
		static Connector Cast(const ::Udm::Object &a);
		static Connector Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Connector CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Connector> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Connector, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Connector, Pred>(impl); };
		Connector CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Connector> Derived();
		template <class Pred> ::Udm::DerivedAttr< Connector, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Connector, Pred>(impl); };
		::Udm::ArchetypeAttr< Connector> Archetype() const;
		::Udm::StringAttr ConnectionType() const;
		::Udm::PointerAttr< Connector_dstConnector_RPContainer_Base> dstConnector__rp_helper() const;
		::Udm::PointerAttr< Connector_srcConnector_RPContainer_Base> srcConnector__rp_helper() const;
		::Udm::ParentAttr< ::ESMoL::Component> Component_parent() const;
		::Udm::ParentAttr< ::ESMoL::Component> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::Output> srcConnector_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::Output, srcConnector_chain_t > srcConnector_chain() const;
		::Udm::AssocEndAttr< ::ESMoL::Input> dstConnector_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::Input, dstConnector_chain_t > dstConnector_chain() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_ConnectionType;
		static ::Uml::AssociationRole meta_dstConnector__rp_helper;
		static ::Uml::AssociationRole meta_srcConnector__rp_helper;
		static ::Uml::CompositionParentRole meta_Component_parent;
		static ::Uml::AssociationRole meta_srcConnector_end_;
		static ::Uml::AssociationRole meta_dstConnector_end_;

	};

	class ComponentBase :  virtual  public MgaObject {
	public:
		ComponentBase();
		ComponentBase(::Udm::ObjectImpl *impl);
		ComponentBase(const ComponentBase &master);

#ifdef UDM_RVALUE
		ComponentBase(ComponentBase &&master);

		static ComponentBase Cast(::Udm::Object &&a);
		ComponentBase& operator=(ComponentBase &&a);

#endif
		static ComponentBase Cast(const ::Udm::Object &a);
		static ComponentBase Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ComponentBase CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ComponentBase> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ComponentBase, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ComponentBase, Pred>(impl); };
		ComponentBase CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ComponentBase> Derived();
		template <class Pred> ::Udm::DerivedAttr< ComponentBase, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ComponentBase, Pred>(impl); };
		::Udm::ArchetypeAttr< ComponentBase> Archetype() const;
		::Udm::IntegerAttr Period() const;
		::Udm::IntegerAttr Deadline() const;
		::Udm::AClassAssocAttr< CompBreakout, TaskInst> dstCompBreakout() const;
		template <class Pred> ::Udm::AClassAssocAttr< CompBreakout, TaskInst, Pred> dstCompBreakout_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< CompBreakout, TaskInst, Pred>(impl, meta_dstCompBreakout, meta_dstCompBreakout_rev); };
		::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultScenario_parent() const;
		::Udm::ParentAttr< ::ESMoL::Component> Component_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Period;
		static ::Uml::Attribute meta_Deadline;
		static ::Uml::AssociationRole meta_dstCompBreakout;
		static ::Uml::AssociationRole meta_dstCompBreakout_rev;
		static ::Uml::CompositionParentRole meta_FaultScenario_parent;
		static ::Uml::CompositionParentRole meta_Component_parent;

	};

	class PetriNet :  public ComponentBase {
	public:
		PetriNet();
		PetriNet(::Udm::ObjectImpl *impl);
		PetriNet(const PetriNet &master);

#ifdef UDM_RVALUE
		PetriNet(PetriNet &&master);

		static PetriNet Cast(::Udm::Object &&a);
		PetriNet& operator=(PetriNet &&a);

#endif
		static PetriNet Cast(const ::Udm::Object &a);
		static PetriNet Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PetriNet CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PetriNet> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PetriNet, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PetriNet, Pred>(impl); };
		PetriNet CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PetriNet> Derived();
		template <class Pred> ::Udm::DerivedAttr< PetriNet, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PetriNet, Pred>(impl); };
		::Udm::ArchetypeAttr< PetriNet> Archetype() const;
		::Udm::StringAttr action() const;
		::Udm::AssocAttr< PetriNetRef> referedbyPetriNetRef() const;
		template <class Pred> ::Udm::AssocAttr< PetriNetRef, Pred> referedbyPetriNetRef_sorted(const Pred &) const { return ::Udm::AssocAttr< PetriNetRef, Pred>(impl, meta_referedbyPetriNetRef); };
		::Udm::ChildrenAttr< ::ESMoL::StateToTransition> StateToTransition_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::StateToTransition, Pred> StateToTransition_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::StateToTransition, Pred>(impl, meta_StateToTransition_children); };
		::Udm::ChildrenAttr< ::ESMoL::PNTransition> PNTransition_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNTransition, Pred> PNTransition_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNTransition, Pred>(impl, meta_PNTransition_children); };
		::Udm::ChildrenAttr< ::ESMoL::TransitionToState> TransitionToState_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransitionToState, Pred> TransitionToState_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransitionToState, Pred>(impl, meta_TransitionToState_children); };
		::Udm::ChildrenAttr< ::ESMoL::PNState> PNState_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNState, Pred> PNState_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNState, Pred>(impl, meta_PNState_children); };
		::Udm::ChildrenAttr< ::ESMoL::PNVariable> PNVariable_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNVariable, Pred> PNVariable_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNVariable, Pred>(impl, meta_PNVariable_children); };
		::Udm::ChildrenAttr< ::ESMoL::PNPort> PNPort_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNPort, Pred> PNPort_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNPort, Pred>(impl, meta_PNPort_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred> FaultToInput_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred> OutputToFault_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::FaultEvent> FaultEvent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultEvent, Pred> FaultEvent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultEvent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TransitionToState> TransitionToState_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransitionToState, Pred> TransitionToState_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransitionToState, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::StateToTransition> StateToTransition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::StateToTransition, Pred> StateToTransition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::StateToTransition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PNTransition> PNTransition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNTransition, Pred> PNTransition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNTransition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PNState> PNState_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNState, Pred> PNState_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNState, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PNPort> PNPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNPort, Pred> PNPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PNVariable> PNVariable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNVariable, Pred> PNVariable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNVariable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IOPortExp> IOPortExp_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred> IOPortExp_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Output> Output_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Output, Pred> Output_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Output, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Input> Input_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Input, Pred> Input_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Input, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputEvent> OutputEvent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputEvent, Pred> OutputEvent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputEvent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::InputEvent> InputEvent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::InputEvent, Pred> InputEvent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::InputEvent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Module> Module_parent() const;
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_action;
		static ::Uml::AssociationRole meta_referedbyPetriNetRef;
		static ::Uml::CompositionChildRole meta_StateToTransition_children;
		static ::Uml::CompositionChildRole meta_PNTransition_children;
		static ::Uml::CompositionChildRole meta_TransitionToState_children;
		static ::Uml::CompositionChildRole meta_PNState_children;
		static ::Uml::CompositionChildRole meta_PNVariable_children;
		static ::Uml::CompositionChildRole meta_PNPort_children;
		static ::Uml::CompositionParentRole meta_Module_parent;

	};

	class CCode :  public ComponentBase {
	public:
		CCode();
		CCode(::Udm::ObjectImpl *impl);
		CCode(const CCode &master);

#ifdef UDM_RVALUE
		CCode(CCode &&master);

		static CCode Cast(::Udm::Object &&a);
		CCode& operator=(CCode &&a);

#endif
		static CCode Cast(const ::Udm::Object &a);
		static CCode Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CCode CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CCode> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CCode, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CCode, Pred>(impl); };
		CCode CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CCode> Derived();
		template <class Pred> ::Udm::DerivedAttr< CCode, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CCode, Pred>(impl); };
		::Udm::ArchetypeAttr< CCode> Archetype() const;
		::Udm::StringAttr CodeInfo() const;
		::Udm::ChildrenAttr< ::ESMoL::COutputPort> COutputPort_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::COutputPort, Pred> COutputPort_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::COutputPort, Pred>(impl, meta_COutputPort_children); };
		::Udm::ChildrenAttr< ::ESMoL::CInputPort> CInputPort_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CInputPort, Pred> CInputPort_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CInputPort, Pred>(impl, meta_CInputPort_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred> FaultToInput_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred> OutputToFault_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::COutputPort> COutputPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::COutputPort, Pred> COutputPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::COutputPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CInputPort> CInputPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CInputPort, Pred> CInputPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CInputPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IOPortExp> IOPortExp_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred> IOPortExp_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Output> Output_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Output, Pred> Output_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Output, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Input> Input_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Input, Pred> Input_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Input, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_CodeInfo;
		static ::Uml::CompositionChildRole meta_COutputPort_children;
		static ::Uml::CompositionChildRole meta_CInputPort_children;

	};

	class SubsystemRef :  public ComponentBase,  public Connector_dstConnector_RPContainer_Base,  public Connector_srcConnector_RPContainer_Base {
	public:
		SubsystemRef();
		SubsystemRef(::Udm::ObjectImpl *impl);
		SubsystemRef(const SubsystemRef &master);

#ifdef UDM_RVALUE
		SubsystemRef(SubsystemRef &&master);

		static SubsystemRef Cast(::Udm::Object &&a);
		SubsystemRef& operator=(SubsystemRef &&a);

#endif
		static SubsystemRef Cast(const ::Udm::Object &a);
		static SubsystemRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SubsystemRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SubsystemRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SubsystemRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SubsystemRef, Pred>(impl); };
		SubsystemRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SubsystemRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< SubsystemRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SubsystemRef, Pred>(impl); };
		::Udm::ArchetypeAttr< SubsystemRef> Archetype() const;
		::Udm::PointerAttr< Subsystem> ref() const;
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;

	};

	class PetriNetRef :  public ComponentBase,  public Connector_dstConnector_RPContainer_Base,  public Connector_srcConnector_RPContainer_Base {
	public:
		PetriNetRef();
		PetriNetRef(::Udm::ObjectImpl *impl);
		PetriNetRef(const PetriNetRef &master);

#ifdef UDM_RVALUE
		PetriNetRef(PetriNetRef &&master);

		static PetriNetRef Cast(::Udm::Object &&a);
		PetriNetRef& operator=(PetriNetRef &&a);

#endif
		static PetriNetRef Cast(const ::Udm::Object &a);
		static PetriNetRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PetriNetRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PetriNetRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PetriNetRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PetriNetRef, Pred>(impl); };
		PetriNetRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PetriNetRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< PetriNetRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PetriNetRef, Pred>(impl); };
		::Udm::ArchetypeAttr< PetriNetRef> Archetype() const;
		::Udm::PointerAttr< PetriNet> ref() const;
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;

	};

	class Message :  public MessageRef_RefersTo_Base,  public MgaObject {
	public:
		Message();
		Message(::Udm::ObjectImpl *impl);
		Message(const Message &master);

#ifdef UDM_RVALUE
		Message(Message &&master);

		static Message Cast(::Udm::Object &&a);
		Message& operator=(Message &&a);

#endif
		static Message Cast(const ::Udm::Object &a);
		static Message Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Message CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Message> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Message, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Message, Pred>(impl); };
		Message CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Message> Derived();
		template <class Pred> ::Udm::DerivedAttr< Message, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Message, Pred>(impl); };
		::Udm::ArchetypeAttr< Message> Archetype() const;
		::Udm::StringAttr MsgSize() const;
		::Udm::StringAttr MsgMetaData() const;
		::Udm::ChildrenAttr< ::ESMoL::MsgPort> MsgPort_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MsgPort, Pred> MsgPort_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MsgPort, Pred>(impl, meta_MsgPort_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred> FaultToInput_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred> OutputToFault_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::AutoCANParam> AutoCANParam_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::AutoCANParam, Pred> AutoCANParam_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::AutoCANParam, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IOPortExp> IOPortExp_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred> IOPortExp_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MsgPort> MsgPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MsgPort, Pred> MsgPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MsgPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Output> Output_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Output, Pred> Output_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Output, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Input> Input_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Input, Pred> Input_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Input, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::SystemTypes> SystemTypes_parent() const;
		::Udm::ParentAttr< ::ESMoL::SystemTypes> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_MsgSize;
		static ::Uml::Attribute meta_MsgMetaData;
		static ::Uml::CompositionChildRole meta_MsgPort_children;
		static ::Uml::CompositionParentRole meta_SystemTypes_parent;

	};

	class CANMessage :  public Message {
	public:
		CANMessage();
		CANMessage(::Udm::ObjectImpl *impl);
		CANMessage(const CANMessage &master);

#ifdef UDM_RVALUE
		CANMessage(CANMessage &&master);

		static CANMessage Cast(::Udm::Object &&a);
		CANMessage& operator=(CANMessage &&a);

#endif
		static CANMessage Cast(const ::Udm::Object &a);
		static CANMessage Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CANMessage CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CANMessage> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CANMessage, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CANMessage, Pred>(impl); };
		CANMessage CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CANMessage> Derived();
		template <class Pred> ::Udm::DerivedAttr< CANMessage, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CANMessage, Pred>(impl); };
		::Udm::ArchetypeAttr< CANMessage> Archetype() const;
		::Udm::IntegerAttr Priority() const;
		::Udm::StringAttr Period() const;
		::Udm::ParentAttr< ::ESMoL::SystemTypes> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Priority;
		static ::Uml::Attribute meta_Period;

	};

	class AutoCANMessage :  public CANMessage {
	public:
		AutoCANMessage();
		AutoCANMessage(::Udm::ObjectImpl *impl);
		AutoCANMessage(const AutoCANMessage &master);

#ifdef UDM_RVALUE
		AutoCANMessage(AutoCANMessage &&master);

		static AutoCANMessage Cast(::Udm::Object &&a);
		AutoCANMessage& operator=(AutoCANMessage &&a);

#endif
		static AutoCANMessage Cast(const ::Udm::Object &a);
		static AutoCANMessage Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		AutoCANMessage CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< AutoCANMessage> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< AutoCANMessage, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< AutoCANMessage, Pred>(impl); };
		AutoCANMessage CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< AutoCANMessage> Derived();
		template <class Pred> ::Udm::DerivedAttr< AutoCANMessage, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< AutoCANMessage, Pred>(impl); };
		::Udm::ArchetypeAttr< AutoCANMessage> Archetype() const;
		::Udm::IntegerAttr PGN() const;
		::Udm::ParentAttr< ::ESMoL::SystemTypes> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_PGN;

	};

	class Output :  virtual  public IOPortExp,  public OutputToFault_Members_Base {
	public:
		Output();
		Output(::Udm::ObjectImpl *impl);
		Output(const Output &master);

#ifdef UDM_RVALUE
		Output(Output &&master);

		static Output Cast(::Udm::Object &&a);
		Output& operator=(Output &&a);

#endif
		static Output Cast(const ::Udm::Object &a);
		static Output Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Output CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Output> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Output, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Output, Pred>(impl); };
		Output CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Output> Derived();
		template <class Pred> ::Udm::DerivedAttr< Output, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Output, Pred>(impl); };
		::Udm::ArchetypeAttr< Output> Archetype() const;
		::Udm::AClassAssocAttr< Connector, Input> dstConnector() const;
		template <class Pred> ::Udm::AClassAssocAttr< Connector, Input, Pred> dstConnector_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Connector, Input, Pred>(impl, meta_dstConnector, meta_dstConnector_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstConnector;
		static ::Uml::AssociationRole meta_dstConnector_rev;

	};

	class COutputPort :  public Output {
	public:
		COutputPort();
		COutputPort(::Udm::ObjectImpl *impl);
		COutputPort(const COutputPort &master);

#ifdef UDM_RVALUE
		COutputPort(COutputPort &&master);

		static COutputPort Cast(::Udm::Object &&a);
		COutputPort& operator=(COutputPort &&a);

#endif
		static COutputPort Cast(const ::Udm::Object &a);
		static COutputPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		COutputPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< COutputPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< COutputPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< COutputPort, Pred>(impl); };
		COutputPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< COutputPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< COutputPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< COutputPort, Pred>(impl); };
		::Udm::ArchetypeAttr< COutputPort> Archetype() const;
		::Udm::StringAttr CPortType() const;
		::Udm::ParentAttr< ::ESMoL::CCode> CCode_parent() const;
		::Udm::ParentAttr< ::ESMoL::CCode> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_CPortType;
		static ::Uml::CompositionParentRole meta_CCode_parent;

	};

	class Input :  public FaultToInput_Members_Base,  virtual  public IOPortExp {
	public:
		Input();
		Input(::Udm::ObjectImpl *impl);
		Input(const Input &master);

#ifdef UDM_RVALUE
		Input(Input &&master);

		static Input Cast(::Udm::Object &&a);
		Input& operator=(Input &&a);

#endif
		static Input Cast(const ::Udm::Object &a);
		static Input Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Input CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Input> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Input, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Input, Pred>(impl); };
		Input CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Input> Derived();
		template <class Pred> ::Udm::DerivedAttr< Input, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Input, Pred>(impl); };
		::Udm::ArchetypeAttr< Input> Archetype() const;
		::Udm::AClassAssocAttr< Connector, Output> srcConnector() const;
		template <class Pred> ::Udm::AClassAssocAttr< Connector, Output, Pred> srcConnector_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Connector, Output, Pred>(impl, meta_srcConnector, meta_srcConnector_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcConnector;
		static ::Uml::AssociationRole meta_srcConnector_rev;

	};

	class PNVariable :  public Input,  public Output {
	public:
		PNVariable();
		PNVariable(::Udm::ObjectImpl *impl);
		PNVariable(const PNVariable &master);

#ifdef UDM_RVALUE
		PNVariable(PNVariable &&master);

		static PNVariable Cast(::Udm::Object &&a);
		PNVariable& operator=(PNVariable &&a);

#endif
		static PNVariable Cast(const ::Udm::Object &a);
		static PNVariable Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PNVariable CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PNVariable> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PNVariable, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PNVariable, Pred>(impl); };
		PNVariable CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PNVariable> Derived();
		template <class Pred> ::Udm::DerivedAttr< PNVariable, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PNVariable, Pred>(impl); };
		::Udm::ArchetypeAttr< PNVariable> Archetype() const;
		::Udm::StringAttr datatype() const;
		::Udm::AssocAttr< PNVarRef> referedbyPNVarRef() const;
		template <class Pred> ::Udm::AssocAttr< PNVarRef, Pred> referedbyPNVarRef_sorted(const Pred &) const { return ::Udm::AssocAttr< PNVarRef, Pred>(impl, meta_referedbyPNVarRef); };
		::Udm::ParentAttr< ::ESMoL::PetriNet> PetriNet_parent() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_datatype;
		static ::Uml::AssociationRole meta_referedbyPNVarRef;
		static ::Uml::CompositionParentRole meta_PetriNet_parent;

	};

	class CInputPort :  public Input {
	public:
		CInputPort();
		CInputPort(::Udm::ObjectImpl *impl);
		CInputPort(const CInputPort &master);

#ifdef UDM_RVALUE
		CInputPort(CInputPort &&master);

		static CInputPort Cast(::Udm::Object &&a);
		CInputPort& operator=(CInputPort &&a);

#endif
		static CInputPort Cast(const ::Udm::Object &a);
		static CInputPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CInputPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CInputPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CInputPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CInputPort, Pred>(impl); };
		CInputPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CInputPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< CInputPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CInputPort, Pred>(impl); };
		::Udm::ArchetypeAttr< CInputPort> Archetype() const;
		::Udm::StringAttr CPortType() const;
		::Udm::ParentAttr< ::ESMoL::CCode> CCode_parent() const;
		::Udm::ParentAttr< ::ESMoL::CCode> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_CPortType;
		static ::Uml::CompositionParentRole meta_CCode_parent;

	};

	class MsgPort :  public Input,  public Output {
	public:
		MsgPort();
		MsgPort(::Udm::ObjectImpl *impl);
		MsgPort(const MsgPort &master);

#ifdef UDM_RVALUE
		MsgPort(MsgPort &&master);

		static MsgPort Cast(::Udm::Object &&a);
		MsgPort& operator=(MsgPort &&a);

#endif
		static MsgPort Cast(const ::Udm::Object &a);
		static MsgPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		MsgPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< MsgPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< MsgPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< MsgPort, Pred>(impl); };
		MsgPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< MsgPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< MsgPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< MsgPort, Pred>(impl); };
		::Udm::ArchetypeAttr< MsgPort> Archetype() const;
		::Udm::IntegerAttr MsgPortNum() const;
		::Udm::StringAttr FieldMetaData() const;
		::Udm::ChildrenAttr< ::ESMoL::FieldDataType> FieldDataType_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FieldDataType, Pred> FieldDataType_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FieldDataType, Pred>(impl, meta_FieldDataType_children); };
		::Udm::ChildrenAttr< ::ESMoL::FieldDataType> FieldDataType_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FieldDataType, Pred> FieldDataType_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FieldDataType, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::BitField> BitField_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BitField, Pred> BitField_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BitField, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ValueType> ValueType_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ValueType, Pred> ValueType_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ValueType, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Message> Message_parent() const;
		::Udm::ParentAttr< ::ESMoL::Message> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_MsgPortNum;
		static ::Uml::Attribute meta_FieldMetaData;
		static ::Uml::CompositionChildRole meta_FieldDataType_children;
		static ::Uml::CompositionParentRole meta_Message_parent;

	};

	class AutoCANParam :  public MsgPort {
	public:
		AutoCANParam();
		AutoCANParam(::Udm::ObjectImpl *impl);
		AutoCANParam(const AutoCANParam &master);

#ifdef UDM_RVALUE
		AutoCANParam(AutoCANParam &&master);

		static AutoCANParam Cast(::Udm::Object &&a);
		AutoCANParam& operator=(AutoCANParam &&a);

#endif
		static AutoCANParam Cast(const ::Udm::Object &a);
		static AutoCANParam Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		AutoCANParam CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< AutoCANParam> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< AutoCANParam, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< AutoCANParam, Pred>(impl); };
		AutoCANParam CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< AutoCANParam> Derived();
		template <class Pred> ::Udm::DerivedAttr< AutoCANParam, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< AutoCANParam, Pred>(impl); };
		::Udm::ArchetypeAttr< AutoCANParam> Archetype() const;
		::Udm::IntegerAttr SPN() const;
		::Udm::ParentAttr< ::ESMoL::Message> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_SPN;

	};

	class OutputEvent :  virtual  public MgaObject {
	public:
		OutputEvent();
		OutputEvent(::Udm::ObjectImpl *impl);
		OutputEvent(const OutputEvent &master);

#ifdef UDM_RVALUE
		OutputEvent(OutputEvent &&master);

		static OutputEvent Cast(::Udm::Object &&a);
		OutputEvent& operator=(OutputEvent &&a);

#endif
		static OutputEvent Cast(const ::Udm::Object &a);
		static OutputEvent Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutputEvent CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutputEvent> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutputEvent, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutputEvent, Pred>(impl); };
		OutputEvent CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutputEvent> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutputEvent, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutputEvent, Pred>(impl); };
		::Udm::ArchetypeAttr< OutputEvent> Archetype() const;
		::Udm::AClassAssocAttr< Trigger, InputEvent> dstTrigger() const;
		template <class Pred> ::Udm::AClassAssocAttr< Trigger, InputEvent, Pred> dstTrigger_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Trigger, InputEvent, Pred>(impl, meta_dstTrigger, meta_dstTrigger_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstTrigger;
		static ::Uml::AssociationRole meta_dstTrigger_rev;

	};

	class InputEvent :  virtual  public MgaObject {
	public:
		InputEvent();
		InputEvent(::Udm::ObjectImpl *impl);
		InputEvent(const InputEvent &master);

#ifdef UDM_RVALUE
		InputEvent(InputEvent &&master);

		static InputEvent Cast(::Udm::Object &&a);
		InputEvent& operator=(InputEvent &&a);

#endif
		static InputEvent Cast(const ::Udm::Object &a);
		static InputEvent Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		InputEvent CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< InputEvent> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< InputEvent, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< InputEvent, Pred>(impl); };
		InputEvent CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< InputEvent> Derived();
		template <class Pred> ::Udm::DerivedAttr< InputEvent, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< InputEvent, Pred>(impl); };
		::Udm::ArchetypeAttr< InputEvent> Archetype() const;
		::Udm::AClassAssocAttr< Trigger, OutputEvent> srcTrigger() const;
		template <class Pred> ::Udm::AClassAssocAttr< Trigger, OutputEvent, Pred> srcTrigger_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Trigger, OutputEvent, Pred>(impl, meta_srcTrigger, meta_srcTrigger_rev); };
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcTrigger;
		static ::Uml::AssociationRole meta_srcTrigger_rev;

	};

	class PNPort :  public FaultEvent,  public InputEvent,  public OutputEvent {
	public:
		PNPort();
		PNPort(::Udm::ObjectImpl *impl);
		PNPort(const PNPort &master);

#ifdef UDM_RVALUE
		PNPort(PNPort &&master);

		static PNPort Cast(::Udm::Object &&a);
		PNPort& operator=(PNPort &&a);

#endif
		static PNPort Cast(const ::Udm::Object &a);
		static PNPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PNPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PNPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PNPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PNPort, Pred>(impl); };
		PNPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PNPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< PNPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PNPort, Pred>(impl); };
		::Udm::ArchetypeAttr< PNPort> Archetype() const;
		::Udm::BooleanAttr visible() const;
		::Udm::AClassAssocAttr< BIPConnector, PNPort> dstPortToPort() const;
		template <class Pred> ::Udm::AClassAssocAttr< BIPConnector, PNPort, Pred> dstPortToPort_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< BIPConnector, PNPort, Pred>(impl, meta_dstPortToPort, meta_dstPortToPort_rev); };
		::Udm::AClassAssocAttr< BIPConnector, PNPort> srcPortToPort() const;
		template <class Pred> ::Udm::AClassAssocAttr< BIPConnector, PNPort, Pred> srcPortToPort_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< BIPConnector, PNPort, Pred>(impl, meta_srcPortToPort, meta_srcPortToPort_rev); };
		::Udm::ChildrenAttr< ::ESMoL::PNVarRef> PNVarRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNVarRef, Pred> PNVarRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNVarRef, Pred>(impl, meta_PNVarRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::PNVarRef> PNVarRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PNVarRef, Pred> PNVarRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PNVarRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::PetriNet> PetriNet_parent() const;
		::Udm::ParentAttr< ::ESMoL::PetriNet> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_visible;
		static ::Uml::AssociationRole meta_dstPortToPort;
		static ::Uml::AssociationRole meta_dstPortToPort_rev;
		static ::Uml::AssociationRole meta_srcPortToPort;
		static ::Uml::AssociationRole meta_srcPortToPort_rev;
		static ::Uml::CompositionChildRole meta_PNVarRef_children;
		static ::Uml::CompositionParentRole meta_PetriNet_parent;

	};

	class Trigger :  public MgaObject {
	public:
		Trigger();
		Trigger(::Udm::ObjectImpl *impl);
		Trigger(const Trigger &master);

#ifdef UDM_RVALUE
		Trigger(Trigger &&master);

		static Trigger Cast(::Udm::Object &&a);
		Trigger& operator=(Trigger &&a);

#endif
		static Trigger Cast(const ::Udm::Object &a);
		static Trigger Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Trigger CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Trigger> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Trigger, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Trigger, Pred>(impl); };
		Trigger CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Trigger> Derived();
		template <class Pred> ::Udm::DerivedAttr< Trigger, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Trigger, Pred>(impl); };
		::Udm::ArchetypeAttr< Trigger> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Component> Component_parent() const;
		::Udm::ParentAttr< ::ESMoL::Component> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::OutputEvent> srcTrigger_end() const;
		::Udm::AssocEndAttr< ::ESMoL::InputEvent> dstTrigger_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_Component_parent;
		static ::Uml::AssociationRole meta_srcTrigger_end_;
		static ::Uml::AssociationRole meta_dstTrigger_end_;

	};

	class Component :  public ComponentRef_RefersTo_Base,  public MgaObject {
	public:
		Component();
		Component(::Udm::ObjectImpl *impl);
		Component(const Component &master);

#ifdef UDM_RVALUE
		Component(Component &&master);

		static Component Cast(::Udm::Object &&a);
		Component& operator=(Component &&a);

#endif
		static Component Cast(const ::Udm::Object &a);
		static Component Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Component CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Component> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Component, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Component, Pred>(impl); };
		Component CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Component> Derived();
		template <class Pred> ::Udm::DerivedAttr< Component, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Component, Pred>(impl); };
		::Udm::ArchetypeAttr< Component> Archetype() const;
		::Udm::StringAttr HeaderFiles() const;
		::Udm::StringAttr SourceFiles() const;
		::Udm::AssocAttr< TaskRef> referedbyTaskRef() const;
		template <class Pred> ::Udm::AssocAttr< TaskRef, Pred> referedbyTaskRef_sorted(const Pred &) const { return ::Udm::AssocAttr< TaskRef, Pred>(impl, meta_referedbyTaskRef); };
		::Udm::ChildrenAttr< ::ESMoL::Trigger> Trigger_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Trigger, Pred> Trigger_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Trigger, Pred>(impl, meta_Trigger_children); };
		::Udm::ChildrenAttr< ::ESMoL::MessageRef> MessageRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MessageRef, Pred> MessageRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef, Pred>(impl, meta_MessageRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentBase> ComponentBase_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred> ComponentBase_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred>(impl, meta_ComponentBase_children); };
		::Udm::ChildrenAttr< ::ESMoL::Connector> Connector_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connector, Pred> Connector_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connector, Pred>(impl, meta_Connector_children); };
		::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred> FaultToInput_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred> OutputToFault_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connector_srcConnector_RPContainer_Base> Connector_srcConnector_RPContainer_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connector_srcConnector_RPContainer_Base, Pred> Connector_srcConnector_RPContainer_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connector_srcConnector_RPContainer_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connector_dstConnector_RPContainer_Base> Connector_dstConnector_RPContainer_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connector_dstConnector_RPContainer_Base, Pred> Connector_dstConnector_RPContainer_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connector_dstConnector_RPContainer_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base> MessageRef_RefersTo_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base, Pred> MessageRef_RefersTo_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> CommMapping_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred> CommMapping_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PetriNet> PetriNet_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred> PetriNet_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Executable> Executable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred> Executable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CCode> CCode_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CCode, Pred> CCode_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CCode, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::SubsystemRef> SubsystemRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SubsystemRef, Pred> SubsystemRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SubsystemRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PetriNetRef> PetriNetRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PetriNetRef, Pred> PetriNetRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNetRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IOPortExp> IOPortExp_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred> IOPortExp_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connector> Connector_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connector, Pred> Connector_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connector, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentBase> ComponentBase_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred> ComponentBase_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Output> Output_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Output, Pred> Output_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Output, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Input> Input_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Input, Pred> Input_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Input, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputEvent> OutputEvent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputEvent, Pred> OutputEvent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputEvent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::InputEvent> InputEvent_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::InputEvent, Pred> InputEvent_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::InputEvent, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Trigger> Trigger_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Trigger, Pred> Trigger_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Trigger, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MessageRef> MessageRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MessageRef, Pred> MessageRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Subsystem> Subsystem_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred> Subsystem_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::SystemTypes> SystemTypes_parent() const;
		::Udm::ParentAttr< ::ESMoL::SystemTypes> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_HeaderFiles;
		static ::Uml::Attribute meta_SourceFiles;
		static ::Uml::AssociationRole meta_referedbyTaskRef;
		static ::Uml::CompositionChildRole meta_Trigger_children;
		static ::Uml::CompositionChildRole meta_MessageRef_children;
		static ::Uml::CompositionChildRole meta_ComponentBase_children;
		static ::Uml::CompositionChildRole meta_Connector_children;
		static ::Uml::CompositionParentRole meta_SystemTypes_parent;

	};

	class PlantComponent :  public Component {
	public:
		PlantComponent();
		PlantComponent(::Udm::ObjectImpl *impl);
		PlantComponent(const PlantComponent &master);

#ifdef UDM_RVALUE
		PlantComponent(PlantComponent &&master);

		static PlantComponent Cast(::Udm::Object &&a);
		PlantComponent& operator=(PlantComponent &&a);

#endif
		static PlantComponent Cast(const ::Udm::Object &a);
		static PlantComponent Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PlantComponent CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PlantComponent> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PlantComponent, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PlantComponent, Pred>(impl); };
		PlantComponent CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PlantComponent> Derived();
		template <class Pred> ::Udm::DerivedAttr< PlantComponent, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PlantComponent, Pred>(impl); };
		::Udm::ArchetypeAttr< PlantComponent> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::SystemTypes> parent() const;

		static ::Uml::Class meta;

	};

	class MessageRef :  public CommMapping_Members_Base,  public Connector_dstConnector_RPContainer_Base,  public Connector_srcConnector_RPContainer_Base,  public Executable,  public Input,  public InputEvent,  public MessageRef_RefersTo_Base,  public Output,  public OutputEvent {
	public:
		MessageRef();
		MessageRef(::Udm::ObjectImpl *impl);
		MessageRef(const MessageRef &master);

#ifdef UDM_RVALUE
		MessageRef(MessageRef &&master);

		static MessageRef Cast(::Udm::Object &&a);
		MessageRef& operator=(MessageRef &&a);

#endif
		static MessageRef Cast(const ::Udm::Object &a);
		static MessageRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		MessageRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< MessageRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< MessageRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< MessageRef, Pred>(impl); };
		MessageRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< MessageRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< MessageRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< MessageRef, Pred>(impl); };
		::Udm::ArchetypeAttr< MessageRef> Archetype() const;
		::Udm::PointerAttr< MessageRef_RefersTo_Base> ref() const;
		::Udm::AClassAssocAttr< Dependency, MessageRef> dstDependency() const;
		template <class Pred> ::Udm::AClassAssocAttr< Dependency, MessageRef, Pred> dstDependency_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Dependency, MessageRef, Pred>(impl, meta_dstDependency, meta_dstDependency_rev); };
		::Udm::AClassAssocAttr< Dependency, MessageRef> srcDependency() const;
		template <class Pred> ::Udm::AClassAssocAttr< Dependency, MessageRef, Pred> srcDependency_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Dependency, MessageRef, Pred>(impl, meta_srcDependency, meta_srcDependency_rev); };
		::Udm::ParentAttr< ::ESMoL::Component> Component_parent() const;
		::Udm::ParentAttr< ::ESMoL::Component> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::AssociationRole meta_dstDependency;
		static ::Uml::AssociationRole meta_dstDependency_rev;
		static ::Uml::AssociationRole meta_srcDependency;
		static ::Uml::AssociationRole meta_srcDependency_rev;
		static ::Uml::CompositionParentRole meta_Component_parent;

	};

	class TimingConstraint :  public MgaObject {
	public:
		TimingConstraint();
		TimingConstraint(::Udm::ObjectImpl *impl);
		TimingConstraint(const TimingConstraint &master);

#ifdef UDM_RVALUE
		TimingConstraint(TimingConstraint &&master);

		static TimingConstraint Cast(::Udm::Object &&a);
		TimingConstraint& operator=(TimingConstraint &&a);

#endif
		static TimingConstraint Cast(const ::Udm::Object &a);
		static TimingConstraint Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TimingConstraint CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TimingConstraint> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TimingConstraint, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TimingConstraint, Pred>(impl); };
		TimingConstraint CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TimingConstraint> Derived();
		template <class Pred> ::Udm::DerivedAttr< TimingConstraint, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TimingConstraint, Pred>(impl); };
		::Udm::ArchetypeAttr< TimingConstraint> Archetype() const;
		::Udm::StringAttr Latency() const;
		::Udm::ParentAttr< ::ESMoL::TimingSheet> TimingSheet_parent() const;
		::Udm::ParentAttr< ::ESMoL::TimingSheet> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::TaskRef> srcTimingConstraint_end() const;
		::Udm::AssocEndAttr< ::ESMoL::TaskRef> dstTimingConstraint_end() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Latency;
		static ::Uml::CompositionParentRole meta_TimingSheet_parent;
		static ::Uml::AssociationRole meta_srcTimingConstraint_end_;
		static ::Uml::AssociationRole meta_dstTimingConstraint_end_;

	};

	class TimingSheet :  public MgaObject {
	public:
		TimingSheet();
		TimingSheet(::Udm::ObjectImpl *impl);
		TimingSheet(const TimingSheet &master);

#ifdef UDM_RVALUE
		TimingSheet(TimingSheet &&master);

		static TimingSheet Cast(::Udm::Object &&a);
		TimingSheet& operator=(TimingSheet &&a);

#endif
		static TimingSheet Cast(const ::Udm::Object &a);
		static TimingSheet Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TimingSheet CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TimingSheet> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TimingSheet, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TimingSheet, Pred>(impl); };
		TimingSheet CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TimingSheet> Derived();
		template <class Pred> ::Udm::DerivedAttr< TimingSheet, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TimingSheet, Pred>(impl); };
		::Udm::ArchetypeAttr< TimingSheet> Archetype() const;
		::Udm::ChildrenAttr< ::ESMoL::TaskRef> TaskRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TaskRef, Pred> TaskRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TaskRef, Pred>(impl, meta_TaskRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::TimingConstraint> TimingConstraint_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TimingConstraint, Pred> TimingConstraint_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TimingConstraint, Pred>(impl, meta_TimingConstraint_children); };
		::Udm::ChildrenAttr< ::ESMoL::TimingConstraint> TimingConstraint_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TimingConstraint, Pred> TimingConstraint_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TimingConstraint, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TaskRef> TaskRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TaskRef, Pred> TaskRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TaskRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::RequirementsLibrary> RequirementsLibrary_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_TaskRef_children;
		static ::Uml::CompositionChildRole meta_TimingConstraint_children;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;
		static ::Uml::CompositionParentRole meta_RequirementsLibrary_parent;

	};

	class TaskRef :  public MgaObject {
	public:
		TaskRef();
		TaskRef(::Udm::ObjectImpl *impl);
		TaskRef(const TaskRef &master);

#ifdef UDM_RVALUE
		TaskRef(TaskRef &&master);

		static TaskRef Cast(::Udm::Object &&a);
		TaskRef& operator=(TaskRef &&a);

#endif
		static TaskRef Cast(const ::Udm::Object &a);
		static TaskRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TaskRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TaskRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TaskRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TaskRef, Pred>(impl); };
		TaskRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TaskRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< TaskRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TaskRef, Pred>(impl); };
		::Udm::ArchetypeAttr< TaskRef> Archetype() const;
		::Udm::AClassAssocAttr< TimingConstraint, TaskRef> dstTimingConstraint() const;
		template <class Pred> ::Udm::AClassAssocAttr< TimingConstraint, TaskRef, Pred> dstTimingConstraint_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< TimingConstraint, TaskRef, Pred>(impl, meta_dstTimingConstraint, meta_dstTimingConstraint_rev); };
		::Udm::AClassAssocAttr< TimingConstraint, TaskRef> srcTimingConstraint() const;
		template <class Pred> ::Udm::AClassAssocAttr< TimingConstraint, TaskRef, Pred> srcTimingConstraint_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< TimingConstraint, TaskRef, Pred>(impl, meta_srcTimingConstraint, meta_srcTimingConstraint_rev); };
		::Udm::PointerAttr< Component> ref() const;
		::Udm::ParentAttr< ::ESMoL::TimingSheet> TimingSheet_parent() const;
		::Udm::ParentAttr< ::ESMoL::TimingSheet> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstTimingConstraint;
		static ::Uml::AssociationRole meta_dstTimingConstraint_rev;
		static ::Uml::AssociationRole meta_srcTimingConstraint;
		static ::Uml::AssociationRole meta_srcTimingConstraint_rev;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_TimingSheet_parent;

	};

	class TypeBase :  public MgaObject {
	public:
		TypeBase();
		TypeBase(::Udm::ObjectImpl *impl);
		TypeBase(const TypeBase &master);

#ifdef UDM_RVALUE
		TypeBase(TypeBase &&master);

		static TypeBase Cast(::Udm::Object &&a);
		TypeBase& operator=(TypeBase &&a);

#endif
		static TypeBase Cast(const ::Udm::Object &a);
		static TypeBase Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeBase CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeBase> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeBase, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeBase, Pred>(impl); };
		TypeBase CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeBase> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeBase, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeBase, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeBase> Archetype() const;
		::Udm::AssocAttr< TypeBaseRef> referedbyTypeStructRef() const;
		template <class Pred> ::Udm::AssocAttr< TypeBaseRef, Pred> referedbyTypeStructRef_sorted(const Pred &) const { return ::Udm::AssocAttr< TypeBaseRef, Pred>(impl, meta_referedbyTypeStructRef); };
		::Udm::CrossPointerAttr< ::SFC::DT> dt() const;
		::Udm::ParentAttr< ::ESMoL::Types> Types_parent() const;
		::Udm::ParentAttr< ::ESMoL::Types> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyTypeStructRef;
		static ::Uml::AssociationRole meta_dt;
		static ::Uml::CompositionParentRole meta_Types_parent;

	};

	class TypeStruct :  public TypeBase {
	public:
		TypeStruct();
		TypeStruct(::Udm::ObjectImpl *impl);
		TypeStruct(const TypeStruct &master);

#ifdef UDM_RVALUE
		TypeStruct(TypeStruct &&master);

		static TypeStruct Cast(::Udm::Object &&a);
		TypeStruct& operator=(TypeStruct &&a);

#endif
		static TypeStruct Cast(const ::Udm::Object &a);
		static TypeStruct Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeStruct CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeStruct> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeStruct, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeStruct, Pred>(impl); };
		TypeStruct CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeStruct> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeStruct, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeStruct, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeStruct> Archetype() const;
		::Udm::IntegerAttr MemberCount() const;
		::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> TypeBaseRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred> TypeBaseRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred>(impl, meta_TypeBaseRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> TypeBaseRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred> TypeBaseRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Types> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_MemberCount;
		static ::Uml::CompositionChildRole meta_TypeBaseRef_children;

	};

	class Matrix :  public TypeBase {
	public:
		Matrix();
		Matrix(::Udm::ObjectImpl *impl);
		Matrix(const Matrix &master);

#ifdef UDM_RVALUE
		Matrix(Matrix &&master);

		static Matrix Cast(::Udm::Object &&a);
		Matrix& operator=(Matrix &&a);

#endif
		static Matrix Cast(const ::Udm::Object &a);
		static Matrix Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Matrix CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Matrix> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Matrix, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Matrix, Pred>(impl); };
		Matrix CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Matrix> Derived();
		template <class Pred> ::Udm::DerivedAttr< Matrix, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Matrix, Pred>(impl); };
		::Udm::ArchetypeAttr< Matrix> Archetype() const;
		::Udm::StringAttr Type() const;
		::Udm::IntegerAttr rows() const;
		::Udm::IntegerAttr columns() const;
		::Udm::ParentAttr< ::ESMoL::Types> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Type;
		static ::Uml::Attribute meta_rows;
		static ::Uml::Attribute meta_columns;

	};

	class TypeBaseRef :  public MgaObject {
	public:
		TypeBaseRef();
		TypeBaseRef(::Udm::ObjectImpl *impl);
		TypeBaseRef(const TypeBaseRef &master);

#ifdef UDM_RVALUE
		TypeBaseRef(TypeBaseRef &&master);

		static TypeBaseRef Cast(::Udm::Object &&a);
		TypeBaseRef& operator=(TypeBaseRef &&a);

#endif
		static TypeBaseRef Cast(const ::Udm::Object &a);
		static TypeBaseRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TypeBaseRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TypeBaseRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TypeBaseRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TypeBaseRef, Pred>(impl); };
		TypeBaseRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TypeBaseRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< TypeBaseRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TypeBaseRef, Pred>(impl); };
		::Udm::ArchetypeAttr< TypeBaseRef> Archetype() const;
		::Udm::IntegerAttr MemberIndex() const;
		::Udm::PointerAttr< TypeBase> ref() const;
		::Udm::CrossPointerAttr< ::SFC::LocalVar> lvar() const;
		::Udm::ParentAttr< ::ESMoL::TypeStruct> TypeStruct_parent() const;
		::Udm::ParentAttr< ::ESMoL::Port> Port_parent() const;
		::Udm::ParentAttr< ::ESMoL::StateDE> StateDE_parent() const;
		::Udm::ParentAttr< ::ESMoL::MgaObject> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_MemberIndex;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::AssociationRole meta_lvar;
		static ::Uml::CompositionParentRole meta_TypeStruct_parent;
		static ::Uml::CompositionParentRole meta_Port_parent;
		static ::Uml::CompositionParentRole meta_StateDE_parent;

	};

	class Annotation :  public MgaObject {
	public:
		Annotation();
		Annotation(::Udm::ObjectImpl *impl);
		Annotation(const Annotation &master);

#ifdef UDM_RVALUE
		Annotation(Annotation &&master);

		static Annotation Cast(::Udm::Object &&a);
		Annotation& operator=(Annotation &&a);

#endif
		static Annotation Cast(const ::Udm::Object &a);
		static Annotation Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Annotation CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Annotation> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Annotation, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Annotation, Pred>(impl); };
		Annotation CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Annotation> Derived();
		template <class Pred> ::Udm::DerivedAttr< Annotation, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Annotation, Pred>(impl); };
		::Udm::ArchetypeAttr< Annotation> Archetype() const;
		::Udm::StringAttr Text() const;
		::Udm::ParentAttr< ::ESMoL::Block> Block_parent() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Text;
		static ::Uml::CompositionParentRole meta_Block_parent;

	};

	class HasRefId :  virtual  public MgaObject {
	public:
		HasRefId();
		HasRefId(::Udm::ObjectImpl *impl);
		HasRefId(const HasRefId &master);

#ifdef UDM_RVALUE
		HasRefId(HasRefId &&master);

		static HasRefId Cast(::Udm::Object &&a);
		HasRefId& operator=(HasRefId &&a);

#endif
		static HasRefId Cast(const ::Udm::Object &a);
		static HasRefId Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		HasRefId CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< HasRefId> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< HasRefId, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< HasRefId, Pred>(impl); };
		HasRefId CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< HasRefId> Derived();
		template <class Pred> ::Udm::DerivedAttr< HasRefId, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< HasRefId, Pred>(impl); };
		::Udm::ArchetypeAttr< HasRefId> Archetype() const;
		::Udm::StringAttr RefId() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_RefId;

	};

	class Block :  public HasRefId {
	public:
		Block();
		Block(::Udm::ObjectImpl *impl);
		Block(const Block &master);

#ifdef UDM_RVALUE
		Block(Block &&master);

		static Block Cast(::Udm::Object &&a);
		Block& operator=(Block &&a);

#endif
		static Block Cast(const ::Udm::Object &a);
		static Block Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Block CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Block> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Block, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Block, Pred>(impl); };
		Block CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Block> Derived();
		template <class Pred> ::Udm::DerivedAttr< Block, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Block, Pred>(impl); };
		::Udm::ArchetypeAttr< Block> Archetype() const;
		::Udm::StringAttr BlockType() const;
		::Udm::StringAttr Tag() const;
		::Udm::StringAttr Name() const;
		::Udm::StringAttr Description() const;
		::Udm::IntegerAttr Priority() const;
		::Udm::RealAttr SampleTime() const;
		::Udm::StringAttr UserData() const;
		::Udm::ChildrenAttr< ::ESMoL::Parameter> Parameter() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Parameter, Pred> Parameter_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Parameter, Pred>(impl, meta_Parameter); };
		::Udm::ChildrenAttr< ::ESMoL::Line> Line() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Line, Pred> Line_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Line, Pred>(impl, meta_Line); };
		::Udm::ChildrenAttr< ::ESMoL::Annotation> Annotation_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Annotation, Pred> Annotation_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Annotation, Pred>(impl, meta_Annotation_children); };
		::Udm::ChildrenAttr< ::ESMoL::ConnectorRef> ConnectorRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef, Pred> ConnectorRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef, Pred>(impl, meta_ConnectorRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::Port> Port_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Port, Pred> Port_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Port, Pred>(impl, meta_Port_children); };
		::Udm::ChildrenAttr< ::ESMoL::Parameter> Parameter_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Parameter, Pred> Parameter_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Parameter, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Annotation> Annotation_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Annotation, Pred> Annotation_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Annotation, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Line> Line_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Line, Pred> Line_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Line, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutputPort> OutputPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutputPort, Pred> OutputPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutputPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OutPort> OutPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OutPort, Pred> OutPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OutPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::StatePort> StatePort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::StatePort, Pred> StatePort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::StatePort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Port> Port_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Port, Pred> Port_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Port, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::EnablePort> EnablePort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::EnablePort, Pred> EnablePort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::EnablePort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TriggerPort> TriggerPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TriggerPort, Pred> TriggerPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TriggerPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::InputPort> InputPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::InputPort, Pred> InputPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::InputPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::InPort> InPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::InPort, Pred> InPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::InPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ActionPort> ActionPort_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ActionPort, Pred> ActionPort_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ActionPort, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HasRefId> HasRefId_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred> HasRefId_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ConnectorRef> ConnectorRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef, Pred> ConnectorRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TransConnector> TransConnector_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred> TransConnector_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Subsystem> Subsystem_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_BlockType;
		static ::Uml::Attribute meta_Tag;
		static ::Uml::Attribute meta_Name;
		static ::Uml::Attribute meta_Description;
		static ::Uml::Attribute meta_Priority;
		static ::Uml::Attribute meta_SampleTime;
		static ::Uml::Attribute meta_UserData;
		static ::Uml::CompositionChildRole meta_Parameter;
		static ::Uml::CompositionChildRole meta_Line;
		static ::Uml::CompositionChildRole meta_Annotation_children;
		static ::Uml::CompositionChildRole meta_ConnectorRef_children;
		static ::Uml::CompositionChildRole meta_Port_children;
		static ::Uml::CompositionParentRole meta_Subsystem_parent;
		static ::Uml::Constraint meta_UniqueConnectorNames;

	};

	class Primitive :  public Block {
	public:
		Primitive();
		Primitive(::Udm::ObjectImpl *impl);
		Primitive(const Primitive &master);

#ifdef UDM_RVALUE
		Primitive(Primitive &&master);

		static Primitive Cast(::Udm::Object &&a);
		Primitive& operator=(Primitive &&a);

#endif
		static Primitive Cast(const ::Udm::Object &a);
		static Primitive Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Primitive CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Primitive> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Primitive, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Primitive, Pred>(impl); };
		Primitive CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Primitive> Derived();
		template <class Pred> ::Udm::DerivedAttr< Primitive, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Primitive, Pred>(impl); };
		::Udm::ArchetypeAttr< Primitive> Archetype() const;
		::Udm::CrossPointerAttr< ::SFC::LocalVar> ifval() const;
		::Udm::ParentAttr< ::ESMoL::Subsystem> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ifval;

	};

	class Parameter :  public HasRefId {
	public:
		Parameter();
		Parameter(::Udm::ObjectImpl *impl);
		Parameter(const Parameter &master);

#ifdef UDM_RVALUE
		Parameter(Parameter &&master);

		static Parameter Cast(::Udm::Object &&a);
		Parameter& operator=(Parameter &&a);

#endif
		static Parameter Cast(const ::Udm::Object &a);
		static Parameter Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Parameter CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Parameter> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Parameter, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Parameter, Pred>(impl); };
		Parameter CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Parameter> Derived();
		template <class Pred> ::Udm::DerivedAttr< Parameter, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Parameter, Pred>(impl); };
		::Udm::ArchetypeAttr< Parameter> Archetype() const;
		::Udm::StringAttr Value() const;
		::Udm::CrossPointerAttr< ::SFC::Arg> arg() const;
		::Udm::CrossPointerAttr< ::SFC::LocalVar> memb() const;
		::Udm::ParentAttr< ::ESMoL::Block> Parameter_Block_parent() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Value;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::AssociationRole meta_memb;
		static ::Uml::CompositionParentRole meta_Parameter_Block_parent;

	};

	class Reference :  public Block {
	public:
		Reference();
		Reference(::Udm::ObjectImpl *impl);
		Reference(const Reference &master);

#ifdef UDM_RVALUE
		Reference(Reference &&master);

		static Reference Cast(::Udm::Object &&a);
		Reference& operator=(Reference &&a);

#endif
		static Reference Cast(const ::Udm::Object &a);
		static Reference Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Reference CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Reference> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Reference, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Reference, Pred>(impl); };
		Reference CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Reference> Derived();
		template <class Pred> ::Udm::DerivedAttr< Reference, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Reference, Pred>(impl); };
		::Udm::ArchetypeAttr< Reference> Archetype() const;
		::Udm::StringAttr SourceType() const;
		::Udm::StringAttr SourceBlock() const;
		::Udm::ParentAttr< ::ESMoL::Subsystem> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_SourceType;
		static ::Uml::Attribute meta_SourceBlock;

	};

	class Line :  public HasRefId {
	public:
		Line();
		Line(::Udm::ObjectImpl *impl);
		Line(const Line &master);

#ifdef UDM_RVALUE
		Line(Line &&master);

		static Line Cast(::Udm::Object &&a);
		Line& operator=(Line &&a);

#endif
		static Line Cast(const ::Udm::Object &a);
		static Line Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Line CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Line> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Line, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Line, Pred>(impl); };
		Line CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Line> Derived();
		template <class Pred> ::Udm::DerivedAttr< Line, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Line, Pred>(impl); };
		::Udm::ArchetypeAttr< Line> Archetype() const;
		::Udm::StringAttr Name() const;
		::Udm::ParentAttr< ::ESMoL::Block> Line_Block_parent() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::Port> srcLine_end() const;
		::Udm::AssocEndAttr< ::ESMoL::Port> dstLine_end() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Name;
		static ::Uml::CompositionParentRole meta_Line_Block_parent;
		static ::Uml::AssociationRole meta_srcLine_end_;
		static ::Uml::AssociationRole meta_dstLine_end_;

	};

	class Subsystem :  public Block,  public ComponentBase {
	public:
		Subsystem();
		Subsystem(::Udm::ObjectImpl *impl);
		Subsystem(const Subsystem &master);

#ifdef UDM_RVALUE
		Subsystem(Subsystem &&master);

		static Subsystem Cast(::Udm::Object &&a);
		Subsystem& operator=(Subsystem &&a);

#endif
		static Subsystem Cast(const ::Udm::Object &a);
		static Subsystem Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Subsystem CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Subsystem> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Subsystem, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Subsystem, Pred>(impl); };
		Subsystem CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Subsystem> Derived();
		template <class Pred> ::Udm::DerivedAttr< Subsystem, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Subsystem, Pred>(impl); };
		::Udm::ArchetypeAttr< Subsystem> Archetype() const;
		::Udm::AssocAttr< SubsystemRef> referedbySubsystemRef() const;
		template <class Pred> ::Udm::AssocAttr< SubsystemRef, Pred> referedbySubsystemRef_sorted(const Pred &) const { return ::Udm::AssocAttr< SubsystemRef, Pred>(impl, meta_referedbySubsystemRef); };
		::Udm::CrossPointerAttr< ::SFC::Function> init() const;
		::Udm::CrossPointerAttr< ::SFC::Function> main() const;
		::Udm::CrossPointerAttr< ::SFC::LocalVar> memb() const;
		::Udm::CrossAssocAttr< ::SFC::FunctionCall> mcall() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::SFC::FunctionCall, Pred> mcall_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::SFC::FunctionCall, Pred>(impl, meta_mcall); };
		::Udm::CrossPointerAttr< ::SFC::Class> cls() const;
		::Udm::ChildrenAttr< ::ESMoL::Block> Block_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Block, Pred> Block_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Block, Pred>(impl, meta_Block_children); };
		::Udm::ChildrenAttr< ::ESMoL::Primitive> Primitive_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Primitive, Pred> Primitive_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Primitive, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Block> Block_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Block, Pred> Block_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Block, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Reference> Reference_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Reference, Pred> Reference_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Reference, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Subsystem> Subsystem_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred> Subsystem_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HasRefId> HasRefId_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred> HasRefId_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Dataflow> Dataflow_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbySubsystemRef;
		static ::Uml::AssociationRole meta_init;
		static ::Uml::AssociationRole meta_main;
		static ::Uml::AssociationRole meta_memb;
		static ::Uml::AssociationRole meta_mcall;
		static ::Uml::AssociationRole meta_cls;
		static ::Uml::CompositionChildRole meta_Block_children;
		static ::Uml::CompositionParentRole meta_Dataflow_parent;
		static ::Uml::Constraint meta_UniqueConnectorNames1;

	};

	class Port :  public HasRefId {
	public:
		Port();
		Port(::Udm::ObjectImpl *impl);
		Port(const Port &master);

#ifdef UDM_RVALUE
		Port(Port &&master);

		static Port Cast(::Udm::Object &&a);
		Port& operator=(Port &&a);

#endif
		static Port Cast(const ::Udm::Object &a);
		static Port Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Port CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Port> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Port, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Port, Pred>(impl); };
		Port CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Port> Derived();
		template <class Pred> ::Udm::DerivedAttr< Port, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Port, Pred>(impl); };
		::Udm::ArchetypeAttr< Port> Archetype() const;
		::Udm::AClassAssocAttr< Line, Port> dstLine() const;
		template <class Pred> ::Udm::AClassAssocAttr< Line, Port, Pred> dstLine_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Line, Port, Pred>(impl, meta_dstLine, meta_dstLine_rev); };
		::Udm::AClassAssocAttr< Line, Port> srcLine() const;
		template <class Pred> ::Udm::AClassAssocAttr< Line, Port, Pred> srcLine_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Line, Port, Pred>(impl, meta_srcLine, meta_srcLine_rev); };
		::Udm::CrossAssocAttr< ::SFC::Arg> arg() const;
		template <class Pred> ::Udm::CrossAssocAttr< ::SFC::Arg, Pred> arg_sorted(const Pred &) const { return ::Udm::CrossAssocAttr< ::SFC::Arg, Pred>(impl, meta_arg); };
		::Udm::CrossPointerAttr< ::SFC::ArgDeclBase> argdecl() const;
		::Udm::ChildAttr< ::ESMoL::TypeBaseRef> TypeBaseRef_child() const;
		::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> TypeBaseRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred> TypeBaseRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Block> Block_parent() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstLine;
		static ::Uml::AssociationRole meta_dstLine_rev;
		static ::Uml::AssociationRole meta_srcLine;
		static ::Uml::AssociationRole meta_srcLine_rev;
		static ::Uml::AssociationRole meta_arg;
		static ::Uml::AssociationRole meta_argdecl;
		static ::Uml::CompositionChildRole meta_TypeBaseRef_child;
		static ::Uml::CompositionParentRole meta_Block_parent;

	};

	class OutPort :  public Port {
	public:
		OutPort();
		OutPort(::Udm::ObjectImpl *impl);
		OutPort(const OutPort &master);

#ifdef UDM_RVALUE
		OutPort(OutPort &&master);

		static OutPort Cast(::Udm::Object &&a);
		OutPort& operator=(OutPort &&a);

#endif
		static OutPort Cast(const ::Udm::Object &a);
		static OutPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutPort, Pred>(impl); };
		OutPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutPort, Pred>(impl); };
		::Udm::ArchetypeAttr< OutPort> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;

	};

	class OutputPort :  public OutPort,  public Output {
	public:
		OutputPort();
		OutputPort(::Udm::ObjectImpl *impl);
		OutputPort(const OutputPort &master);

#ifdef UDM_RVALUE
		OutputPort(OutputPort &&master);

		static OutputPort Cast(::Udm::Object &&a);
		OutputPort& operator=(OutputPort &&a);

#endif
		static OutputPort Cast(const ::Udm::Object &a);
		static OutputPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OutputPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OutputPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OutputPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OutputPort, Pred>(impl); };
		OutputPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OutputPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< OutputPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OutputPort, Pred>(impl); };
		::Udm::ArchetypeAttr< OutputPort> Archetype() const;
		::Udm::IntegerAttr Number() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Number;
		static ::Uml::Constraint meta_NestedOPtoOPorNestedOPtoIP;

	};

	class StatePort :  public OutPort {
	public:
		StatePort();
		StatePort(::Udm::ObjectImpl *impl);
		StatePort(const StatePort &master);

#ifdef UDM_RVALUE
		StatePort(StatePort &&master);

		static StatePort Cast(::Udm::Object &&a);
		StatePort& operator=(StatePort &&a);

#endif
		static StatePort Cast(const ::Udm::Object &a);
		static StatePort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StatePort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StatePort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StatePort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StatePort, Pred>(impl); };
		StatePort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StatePort> Derived();
		template <class Pred> ::Udm::DerivedAttr< StatePort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StatePort, Pred>(impl); };
		::Udm::ArchetypeAttr< StatePort> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;

	};

	class InPort :  public Port {
	public:
		InPort();
		InPort(::Udm::ObjectImpl *impl);
		InPort(const InPort &master);

#ifdef UDM_RVALUE
		InPort(InPort &&master);

		static InPort Cast(::Udm::Object &&a);
		InPort& operator=(InPort &&a);

#endif
		static InPort Cast(const ::Udm::Object &a);
		static InPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		InPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< InPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< InPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< InPort, Pred>(impl); };
		InPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< InPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< InPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< InPort, Pred>(impl); };
		::Udm::ArchetypeAttr< InPort> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;

	};

	class EnablePort :  public InPort {
	public:
		EnablePort();
		EnablePort(::Udm::ObjectImpl *impl);
		EnablePort(const EnablePort &master);

#ifdef UDM_RVALUE
		EnablePort(EnablePort &&master);

		static EnablePort Cast(::Udm::Object &&a);
		EnablePort& operator=(EnablePort &&a);

#endif
		static EnablePort Cast(const ::Udm::Object &a);
		static EnablePort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		EnablePort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< EnablePort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< EnablePort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< EnablePort, Pred>(impl); };
		EnablePort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< EnablePort> Derived();
		template <class Pred> ::Udm::DerivedAttr< EnablePort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< EnablePort, Pred>(impl); };
		::Udm::ArchetypeAttr< EnablePort> Archetype() const;
		::Udm::StringAttr StatesWhenEnabling() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_StatesWhenEnabling;
		static ::Uml::Constraint meta_EPtoNestedIPTPEPBPOnly;
		static ::Uml::Constraint meta_EPConnectedByPortInParentParent;
		static ::Uml::Constraint meta_OnlyOneEP;
		static ::Uml::Constraint meta_EPParentIsSubsystemOrSystem;
		static ::Uml::Constraint meta_EPInSubsystemOnlyConnectToEPInSystem;
		static ::Uml::Constraint meta_EPConnectedAsDstAtLeastOnce;
		static ::Uml::Constraint meta_EnableParentInSubsystemMustConnectDownToSystem;

	};

	class TriggerPort :  public InPort {
	public:
		TriggerPort();
		TriggerPort(::Udm::ObjectImpl *impl);
		TriggerPort(const TriggerPort &master);

#ifdef UDM_RVALUE
		TriggerPort(TriggerPort &&master);

		static TriggerPort Cast(::Udm::Object &&a);
		TriggerPort& operator=(TriggerPort &&a);

#endif
		static TriggerPort Cast(const ::Udm::Object &a);
		static TriggerPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TriggerPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TriggerPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TriggerPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TriggerPort, Pred>(impl); };
		TriggerPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TriggerPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< TriggerPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TriggerPort, Pred>(impl); };
		::Udm::ArchetypeAttr< TriggerPort> Archetype() const;
		::Udm::StringAttr TriggerType() const;
		::Udm::CrossPointerAttr< ::SFC::LocalVar> memb() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_TriggerType;
		static ::Uml::AssociationRole meta_memb;
		static ::Uml::Constraint meta_OnlyOneTP;
		static ::Uml::Constraint meta_TPConnectedAsDstAtLeastOnce;
		static ::Uml::Constraint meta_TPtoNestedIPTPEPBPOnly;
		static ::Uml::Constraint meta_TPConnectedByPortInParentParent;
		static ::Uml::Constraint meta_TPInSubsystemOnlyConnectToTPInSystem;
		static ::Uml::Constraint meta_TPParentIsSubsystemOrSystem;
		static ::Uml::Constraint meta_TriggerParentInSubsystemMustConnectDownToSystem;

	};

	class InputPort :  public InPort,  public Input {
	public:
		InputPort();
		InputPort(::Udm::ObjectImpl *impl);
		InputPort(const InputPort &master);

#ifdef UDM_RVALUE
		InputPort(InputPort &&master);

		static InputPort Cast(::Udm::Object &&a);
		InputPort& operator=(InputPort &&a);

#endif
		static InputPort Cast(const ::Udm::Object &a);
		static InputPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		InputPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< InputPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< InputPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< InputPort, Pred>(impl); };
		InputPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< InputPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< InputPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< InputPort, Pred>(impl); };
		::Udm::ArchetypeAttr< InputPort> Archetype() const;
		::Udm::IntegerAttr Number() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Number;
		static ::Uml::Constraint meta_IPtoNestedIPTPEPBPOnly;
		static ::Uml::Constraint meta_IPInSubsystemOnlyConnectToIPInSystem;
		static ::Uml::Constraint meta_IPConnectedAsDstAtLeastOnce;

	};

	class ActionPort :  public InPort {
	public:
		ActionPort();
		ActionPort(::Udm::ObjectImpl *impl);
		ActionPort(const ActionPort &master);

#ifdef UDM_RVALUE
		ActionPort(ActionPort &&master);

		static ActionPort Cast(::Udm::Object &&a);
		ActionPort& operator=(ActionPort &&a);

#endif
		static ActionPort Cast(const ::Udm::Object &a);
		static ActionPort Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ActionPort CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ActionPort> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ActionPort, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ActionPort, Pred>(impl); };
		ActionPort CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ActionPort> Derived();
		template <class Pred> ::Udm::DerivedAttr< ActionPort, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ActionPort, Pred>(impl); };
		::Udm::ArchetypeAttr< ActionPort> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Block> parent() const;

		static ::Uml::Class meta;

	};

	class Transition :  public HasRefId {
	public:
		Transition();
		Transition(::Udm::ObjectImpl *impl);
		Transition(const Transition &master);

#ifdef UDM_RVALUE
		Transition(Transition &&master);

		static Transition Cast(::Udm::Object &&a);
		Transition& operator=(Transition &&a);

#endif
		static Transition Cast(const ::Udm::Object &a);
		static Transition Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Transition CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Transition> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Transition, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Transition, Pred>(impl); };
		Transition CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Transition> Derived();
		template <class Pred> ::Udm::DerivedAttr< Transition, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Transition, Pred>(impl); };
		::Udm::ArchetypeAttr< Transition> Archetype() const;
		::Udm::StringAttr Trigger() const;
		::Udm::StringAttr Guard() const;
		::Udm::StringAttr Action() const;
		::Udm::StringAttr ConditionAction() const;
		::Udm::StringAttr Order() const;
		::Udm::ParentAttr< ::ESMoL::State> Transition_State_parent() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::TransConnector> srcTransition_end() const;
		::Udm::AssocEndAttr< ::ESMoL::TransConnector> dstTransition_end() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Trigger;
		static ::Uml::Attribute meta_Guard;
		static ::Uml::Attribute meta_Action;
		static ::Uml::Attribute meta_ConditionAction;
		static ::Uml::Attribute meta_Order;
		static ::Uml::CompositionParentRole meta_Transition_State_parent;
		static ::Uml::AssociationRole meta_srcTransition_end_;
		static ::Uml::AssociationRole meta_dstTransition_end_;

	};

	class TransConnector :  public HasRefId {
	public:
		TransConnector();
		TransConnector(::Udm::ObjectImpl *impl);
		TransConnector(const TransConnector &master);

#ifdef UDM_RVALUE
		TransConnector(TransConnector &&master);

		static TransConnector Cast(::Udm::Object &&a);
		TransConnector& operator=(TransConnector &&a);

#endif
		static TransConnector Cast(const ::Udm::Object &a);
		static TransConnector Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TransConnector CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TransConnector> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TransConnector, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TransConnector, Pred>(impl); };
		TransConnector CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TransConnector> Derived();
		template <class Pred> ::Udm::DerivedAttr< TransConnector, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TransConnector, Pred>(impl); };
		::Udm::ArchetypeAttr< TransConnector> Archetype() const;
		::Udm::AssocAttr< ConnectorRef> referedbyConnectorRef() const;
		template <class Pred> ::Udm::AssocAttr< ConnectorRef, Pred> referedbyConnectorRef_sorted(const Pred &) const { return ::Udm::AssocAttr< ConnectorRef, Pred>(impl, meta_referedbyConnectorRef); };
		::Udm::AClassAssocAttr< Transition, TransConnector> dstTransition() const;
		template <class Pred> ::Udm::AClassAssocAttr< Transition, TransConnector, Pred> dstTransition_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Transition, TransConnector, Pred>(impl, meta_dstTransition, meta_dstTransition_rev); };
		::Udm::AClassAssocAttr< Transition, TransConnector> srcTransition() const;
		template <class Pred> ::Udm::AClassAssocAttr< Transition, TransConnector, Pred> srcTransition_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Transition, TransConnector, Pred>(impl, meta_srcTransition, meta_srcTransition_rev); };
		::Udm::ParentAttr< ::ESMoL::State> State_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyConnectorRef;
		static ::Uml::AssociationRole meta_dstTransition;
		static ::Uml::AssociationRole meta_dstTransition_rev;
		static ::Uml::AssociationRole meta_srcTransition;
		static ::Uml::AssociationRole meta_srcTransition_rev;
		static ::Uml::CompositionParentRole meta_State_parent;

	};

	class State :  public TransConnector {
	public:
		State();
		State(::Udm::ObjectImpl *impl);
		State(const State &master);

#ifdef UDM_RVALUE
		State(State &&master);

		static State Cast(::Udm::Object &&a);
		State& operator=(State &&a);

#endif
		static State Cast(const ::Udm::Object &a);
		static State Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		State CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< State> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< State, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< State, Pred>(impl); };
		State CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< State> Derived();
		template <class Pred> ::Udm::DerivedAttr< State, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< State, Pred>(impl); };
		::Udm::ArchetypeAttr< State> Archetype() const;
		::Udm::StringAttr Decomposition() const;
		::Udm::StringAttr Name() const;
		::Udm::StringAttr EnterAction() const;
		::Udm::StringAttr DuringAction() const;
		::Udm::StringAttr ExitAction() const;
		::Udm::StringAttr Order() const;
		::Udm::StringAttr Description() const;
		::Udm::StringAttr Methods() const;
		::Udm::ChildrenAttr< ::ESMoL::Transition> Transition() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Transition, Pred> Transition_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Transition, Pred>(impl, meta_Transition); };
		::Udm::ChildrenAttr< ::ESMoL::TransConnector> TransConnector_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred> TransConnector_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred>(impl, meta_TransConnector_children); };
		::Udm::ChildrenAttr< ::ESMoL::StateDE> StateDE_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::StateDE, Pred> StateDE_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::StateDE, Pred>(impl, meta_StateDE_children); };
		::Udm::ChildrenAttr< ::ESMoL::HasRefId> HasRefId_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred> HasRefId_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::State> State_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::State, Pred> State_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::State, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Transition> Transition_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Transition, Pred> Transition_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Transition, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::History> History_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::History, Pred> History_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::History, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TransStart> TransStart_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransStart, Pred> TransStart_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransStart, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Junction> Junction_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Junction, Pred> Junction_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Junction, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ConnectorRef> ConnectorRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef, Pred> ConnectorRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TransConnector> TransConnector_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred> TransConnector_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Data> Data_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Data, Pred> Data_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Data, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Event> Event_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Event, Pred> Event_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Event, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::StateDE> StateDE_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::StateDE, Pred> StateDE_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::StateDE, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Conditional> Conditional_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Conditional, Pred> Conditional_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Conditional, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ShallowHistory> ShallowHistory_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ShallowHistory, Pred> ShallowHistory_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ShallowHistory, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::DeepHistory> DeepHistory_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::DeepHistory, Pred> DeepHistory_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::DeepHistory, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Join> Join_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Join, Pred> Join_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Join, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Fork> Fork_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Fork, Pred> Fork_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Fork, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Choice> Choice_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Choice, Pred> Choice_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Choice, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Entry> Entry_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Entry, Pred> Entry_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Entry, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Exit> Exit_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Exit, Pred> Exit_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Exit, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Terminate> Terminate_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Terminate, Pred> Terminate_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Terminate, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::Stateflow> Stateflow_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Decomposition;
		static ::Uml::Attribute meta_Name;
		static ::Uml::Attribute meta_EnterAction;
		static ::Uml::Attribute meta_DuringAction;
		static ::Uml::Attribute meta_ExitAction;
		static ::Uml::Attribute meta_Order;
		static ::Uml::Attribute meta_Description;
		static ::Uml::Attribute meta_Methods;
		static ::Uml::CompositionChildRole meta_Transition;
		static ::Uml::CompositionChildRole meta_TransConnector_children;
		static ::Uml::CompositionChildRole meta_StateDE_children;
		static ::Uml::CompositionParentRole meta_Stateflow_parent;
		static ::Uml::Constraint meta_SingleHistory;

	};

	class History :  public TransConnector {
	public:
		History();
		History(::Udm::ObjectImpl *impl);
		History(const History &master);

#ifdef UDM_RVALUE
		History(History &&master);

		static History Cast(::Udm::Object &&a);
		History& operator=(History &&a);

#endif
		static History Cast(const ::Udm::Object &a);
		static History Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		History CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< History> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< History, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< History, Pred>(impl); };
		History CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< History> Derived();
		template <class Pred> ::Udm::DerivedAttr< History, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< History, Pred>(impl); };
		::Udm::ArchetypeAttr< History> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class TransStart :  public TransConnector {
	public:
		TransStart();
		TransStart(::Udm::ObjectImpl *impl);
		TransStart(const TransStart &master);

#ifdef UDM_RVALUE
		TransStart(TransStart &&master);

		static TransStart Cast(::Udm::Object &&a);
		TransStart& operator=(TransStart &&a);

#endif
		static TransStart Cast(const ::Udm::Object &a);
		static TransStart Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TransStart CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TransStart> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TransStart, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TransStart, Pred>(impl); };
		TransStart CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TransStart> Derived();
		template <class Pred> ::Udm::DerivedAttr< TransStart, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TransStart, Pred>(impl); };
		::Udm::ArchetypeAttr< TransStart> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Constraint meta_TransStartRestrict;

	};

	class Junction :  public TransConnector {
	public:
		Junction();
		Junction(::Udm::ObjectImpl *impl);
		Junction(const Junction &master);

#ifdef UDM_RVALUE
		Junction(Junction &&master);

		static Junction Cast(::Udm::Object &&a);
		Junction& operator=(Junction &&a);

#endif
		static Junction Cast(const ::Udm::Object &a);
		static Junction Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Junction CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Junction> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Junction, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Junction, Pred>(impl); };
		Junction CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Junction> Derived();
		template <class Pred> ::Udm::DerivedAttr< Junction, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Junction, Pred>(impl); };
		::Udm::ArchetypeAttr< Junction> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Constraint meta_JunctNotToSelf;

	};

	class ConnectorRef :  public TransConnector {
	public:
		ConnectorRef();
		ConnectorRef(::Udm::ObjectImpl *impl);
		ConnectorRef(const ConnectorRef &master);

#ifdef UDM_RVALUE
		ConnectorRef(ConnectorRef &&master);

		static ConnectorRef Cast(::Udm::Object &&a);
		ConnectorRef& operator=(ConnectorRef &&a);

#endif
		static ConnectorRef Cast(const ::Udm::Object &a);
		static ConnectorRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ConnectorRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ConnectorRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ConnectorRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ConnectorRef, Pred>(impl); };
		ConnectorRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ConnectorRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< ConnectorRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ConnectorRef, Pred>(impl); };
		::Udm::ArchetypeAttr< ConnectorRef> Archetype() const;
		::Udm::PointerAttr< TransConnector> ref() const;
		::Udm::ParentAttr< ::ESMoL::Block> Block_parent() const;
		::Udm::ParentAttr< ::ESMoL::HasRefId> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_Block_parent;

	};

	class StateDE :  public HasRefId {
	public:
		StateDE();
		StateDE(::Udm::ObjectImpl *impl);
		StateDE(const StateDE &master);

#ifdef UDM_RVALUE
		StateDE(StateDE &&master);

		static StateDE Cast(::Udm::Object &&a);
		StateDE& operator=(StateDE &&a);

#endif
		static StateDE Cast(const ::Udm::Object &a);
		static StateDE Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		StateDE CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< StateDE> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< StateDE, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< StateDE, Pred>(impl); };
		StateDE CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< StateDE> Derived();
		template <class Pred> ::Udm::DerivedAttr< StateDE, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< StateDE, Pred>(impl); };
		::Udm::ArchetypeAttr< StateDE> Archetype() const;
		::Udm::ChildAttr< ::ESMoL::TypeBaseRef> TypeBaseRef_child() const;
		::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> TypeBaseRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred> TypeBaseRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::State> State_parent() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_TypeBaseRef_child;
		static ::Uml::CompositionParentRole meta_State_parent;

	};

	class Data :  public StateDE {
	public:
		Data();
		Data(::Udm::ObjectImpl *impl);
		Data(const Data &master);

#ifdef UDM_RVALUE
		Data(Data &&master);

		static Data Cast(::Udm::Object &&a);
		Data& operator=(Data &&a);

#endif
		static Data Cast(const ::Udm::Object &a);
		static Data Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Data CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Data> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Data, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Data, Pred>(impl); };
		Data CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Data> Derived();
		template <class Pred> ::Udm::DerivedAttr< Data, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Data, Pred>(impl); };
		::Udm::ArchetypeAttr< Data> Archetype() const;
		::Udm::StringAttr Description() const;
		::Udm::StringAttr Name() const;
		::Udm::StringAttr DataType() const;
		::Udm::IntegerAttr Port() const;
		::Udm::StringAttr Units() const;
		::Udm::StringAttr InitialValue() const;
		::Udm::StringAttr Min() const;
		::Udm::StringAttr Max() const;
		::Udm::StringAttr ArraySize() const;
		::Udm::StringAttr ArrayFirstIndex() const;
		::Udm::StringAttr Scope() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Description;
		static ::Uml::Attribute meta_Name;
		static ::Uml::Attribute meta_DataType;
		static ::Uml::Attribute meta_Port;
		static ::Uml::Attribute meta_Units;
		static ::Uml::Attribute meta_InitialValue;
		static ::Uml::Attribute meta_Min;
		static ::Uml::Attribute meta_Max;
		static ::Uml::Attribute meta_ArraySize;
		static ::Uml::Attribute meta_ArrayFirstIndex;
		static ::Uml::Attribute meta_Scope;

	};

	class Event :  public StateDE {
	public:
		Event();
		Event(::Udm::ObjectImpl *impl);
		Event(const Event &master);

#ifdef UDM_RVALUE
		Event(Event &&master);

		static Event Cast(::Udm::Object &&a);
		Event& operator=(Event &&a);

#endif
		static Event Cast(const ::Udm::Object &a);
		static Event Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Event CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Event> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Event, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Event, Pred>(impl); };
		Event CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Event> Derived();
		template <class Pred> ::Udm::DerivedAttr< Event, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Event, Pred>(impl); };
		::Udm::ArchetypeAttr< Event> Archetype() const;
		::Udm::StringAttr Description() const;
		::Udm::StringAttr Name() const;
		::Udm::StringAttr Scope() const;
		::Udm::StringAttr Trigger() const;
		::Udm::IntegerAttr Port() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Description;
		static ::Uml::Attribute meta_Name;
		static ::Uml::Attribute meta_Scope;
		static ::Uml::Attribute meta_Trigger;
		static ::Uml::Attribute meta_Port;

	};

	class Conditional :  public TransConnector {
	public:
		Conditional();
		Conditional(::Udm::ObjectImpl *impl);
		Conditional(const Conditional &master);

#ifdef UDM_RVALUE
		Conditional(Conditional &&master);

		static Conditional Cast(::Udm::Object &&a);
		Conditional& operator=(Conditional &&a);

#endif
		static Conditional Cast(const ::Udm::Object &a);
		static Conditional Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Conditional CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Conditional> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Conditional, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Conditional, Pred>(impl); };
		Conditional CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Conditional> Derived();
		template <class Pred> ::Udm::DerivedAttr< Conditional, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Conditional, Pred>(impl); };
		::Udm::ArchetypeAttr< Conditional> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class ShallowHistory :  public History {
	public:
		ShallowHistory();
		ShallowHistory(::Udm::ObjectImpl *impl);
		ShallowHistory(const ShallowHistory &master);

#ifdef UDM_RVALUE
		ShallowHistory(ShallowHistory &&master);

		static ShallowHistory Cast(::Udm::Object &&a);
		ShallowHistory& operator=(ShallowHistory &&a);

#endif
		static ShallowHistory Cast(const ::Udm::Object &a);
		static ShallowHistory Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ShallowHistory CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ShallowHistory> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ShallowHistory, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ShallowHistory, Pred>(impl); };
		ShallowHistory CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ShallowHistory> Derived();
		template <class Pred> ::Udm::DerivedAttr< ShallowHistory, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ShallowHistory, Pred>(impl); };
		::Udm::ArchetypeAttr< ShallowHistory> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class DeepHistory :  public History {
	public:
		DeepHistory();
		DeepHistory(::Udm::ObjectImpl *impl);
		DeepHistory(const DeepHistory &master);

#ifdef UDM_RVALUE
		DeepHistory(DeepHistory &&master);

		static DeepHistory Cast(::Udm::Object &&a);
		DeepHistory& operator=(DeepHistory &&a);

#endif
		static DeepHistory Cast(const ::Udm::Object &a);
		static DeepHistory Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		DeepHistory CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< DeepHistory> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< DeepHistory, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< DeepHistory, Pred>(impl); };
		DeepHistory CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< DeepHistory> Derived();
		template <class Pred> ::Udm::DerivedAttr< DeepHistory, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< DeepHistory, Pred>(impl); };
		::Udm::ArchetypeAttr< DeepHistory> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class Join :  public TransConnector {
	public:
		Join();
		Join(::Udm::ObjectImpl *impl);
		Join(const Join &master);

#ifdef UDM_RVALUE
		Join(Join &&master);

		static Join Cast(::Udm::Object &&a);
		Join& operator=(Join &&a);

#endif
		static Join Cast(const ::Udm::Object &a);
		static Join Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Join CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Join> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Join, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Join, Pred>(impl); };
		Join CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Join> Derived();
		template <class Pred> ::Udm::DerivedAttr< Join, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Join, Pred>(impl); };
		::Udm::ArchetypeAttr< Join> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class Fork :  public TransConnector {
	public:
		Fork();
		Fork(::Udm::ObjectImpl *impl);
		Fork(const Fork &master);

#ifdef UDM_RVALUE
		Fork(Fork &&master);

		static Fork Cast(::Udm::Object &&a);
		Fork& operator=(Fork &&a);

#endif
		static Fork Cast(const ::Udm::Object &a);
		static Fork Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Fork CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Fork> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Fork, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Fork, Pred>(impl); };
		Fork CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Fork> Derived();
		template <class Pred> ::Udm::DerivedAttr< Fork, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Fork, Pred>(impl); };
		::Udm::ArchetypeAttr< Fork> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class Choice :  public TransConnector {
	public:
		Choice();
		Choice(::Udm::ObjectImpl *impl);
		Choice(const Choice &master);

#ifdef UDM_RVALUE
		Choice(Choice &&master);

		static Choice Cast(::Udm::Object &&a);
		Choice& operator=(Choice &&a);

#endif
		static Choice Cast(const ::Udm::Object &a);
		static Choice Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Choice CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Choice> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Choice, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Choice, Pred>(impl); };
		Choice CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Choice> Derived();
		template <class Pred> ::Udm::DerivedAttr< Choice, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Choice, Pred>(impl); };
		::Udm::ArchetypeAttr< Choice> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class Entry :  public TransConnector {
	public:
		Entry();
		Entry(::Udm::ObjectImpl *impl);
		Entry(const Entry &master);

#ifdef UDM_RVALUE
		Entry(Entry &&master);

		static Entry Cast(::Udm::Object &&a);
		Entry& operator=(Entry &&a);

#endif
		static Entry Cast(const ::Udm::Object &a);
		static Entry Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Entry CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Entry> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Entry, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Entry, Pred>(impl); };
		Entry CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Entry> Derived();
		template <class Pred> ::Udm::DerivedAttr< Entry, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Entry, Pred>(impl); };
		::Udm::ArchetypeAttr< Entry> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class Exit :  public TransConnector {
	public:
		Exit();
		Exit(::Udm::ObjectImpl *impl);
		Exit(const Exit &master);

#ifdef UDM_RVALUE
		Exit(Exit &&master);

		static Exit Cast(::Udm::Object &&a);
		Exit& operator=(Exit &&a);

#endif
		static Exit Cast(const ::Udm::Object &a);
		static Exit Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Exit CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Exit> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Exit, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Exit, Pred>(impl); };
		Exit CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Exit> Derived();
		template <class Pred> ::Udm::DerivedAttr< Exit, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Exit, Pred>(impl); };
		::Udm::ArchetypeAttr< Exit> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class Terminate :  public TransConnector {
	public:
		Terminate();
		Terminate(::Udm::ObjectImpl *impl);
		Terminate(const Terminate &master);

#ifdef UDM_RVALUE
		Terminate(Terminate &&master);

		static Terminate Cast(::Udm::Object &&a);
		Terminate& operator=(Terminate &&a);

#endif
		static Terminate Cast(const ::Udm::Object &a);
		static Terminate Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Terminate CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Terminate> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Terminate, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Terminate, Pred>(impl); };
		Terminate CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Terminate> Derived();
		template <class Pred> ::Udm::DerivedAttr< Terminate, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Terminate, Pred>(impl); };
		::Udm::ArchetypeAttr< Terminate> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::State> parent() const;

		static ::Uml::Class meta;

	};

	class OS :  public MgaObject {
	public:
		OS();
		OS(::Udm::ObjectImpl *impl);
		OS(const OS &master);

#ifdef UDM_RVALUE
		OS(OS &&master);

		static OS Cast(::Udm::Object &&a);
		OS& operator=(OS &&a);

#endif
		static OS Cast(const ::Udm::Object &a);
		static OS Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OS CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OS> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OS, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OS, Pred>(impl); };
		OS CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OS> Derived();
		template <class Pred> ::Udm::DerivedAttr< OS, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OS, Pred>(impl); };
		::Udm::ArchetypeAttr< OS> Archetype() const;
		::Udm::StringAttr ContextSwitchTime() const;
		::Udm::StringAttr SendOverheadTime() const;
		::Udm::StringAttr RecvOverheadTime() const;
		::Udm::StringAttr TickResolution() const;
		::Udm::IntegerAttr MaxTaskNumber() const;
		::Udm::StringAttr SchedulingAlgorithm() const;
		::Udm::StringAttr ISROverheadTime() const;
		::Udm::ParentAttr< ::ESMoL::Node> Node_parent() const;
		::Udm::ParentAttr< ::ESMoL::Node> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_ContextSwitchTime;
		static ::Uml::Attribute meta_SendOverheadTime;
		static ::Uml::Attribute meta_RecvOverheadTime;
		static ::Uml::Attribute meta_TickResolution;
		static ::Uml::Attribute meta_MaxTaskNumber;
		static ::Uml::Attribute meta_SchedulingAlgorithm;
		static ::Uml::Attribute meta_ISROverheadTime;
		static ::Uml::CompositionParentRole meta_Node_parent;

	};

	class Wire :  public MgaObject {
	public:
		Wire();
		Wire(::Udm::ObjectImpl *impl);
		Wire(const Wire &master);

#ifdef UDM_RVALUE
		Wire(Wire &&master);

		static Wire Cast(::Udm::Object &&a);
		Wire& operator=(Wire &&a);

#endif
		static Wire Cast(const ::Udm::Object &a);
		static Wire Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Wire CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Wire> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Wire, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Wire, Pred>(impl); };
		Wire CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Wire> Derived();
		template <class Pred> ::Udm::DerivedAttr< Wire, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Wire, Pred>(impl); };
		::Udm::ArchetypeAttr< Wire> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::Connectable> srcWire_end() const;
		::Udm::AssocEndAttr< ::ESMoL::Connectable> dstWire_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;
		static ::Uml::AssociationRole meta_srcWire_end_;
		static ::Uml::AssociationRole meta_dstWire_end_;

	};

	class Connectable :  virtual  public MgaObject {
	public:
		Connectable();
		Connectable(::Udm::ObjectImpl *impl);
		Connectable(const Connectable &master);

#ifdef UDM_RVALUE
		Connectable(Connectable &&master);

		static Connectable Cast(::Udm::Object &&a);
		Connectable& operator=(Connectable &&a);

#endif
		static Connectable Cast(const ::Udm::Object &a);
		static Connectable Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Connectable CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Connectable> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Connectable, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Connectable, Pred>(impl); };
		Connectable CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Connectable> Derived();
		template <class Pred> ::Udm::DerivedAttr< Connectable, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Connectable, Pred>(impl); };
		::Udm::ArchetypeAttr< Connectable> Archetype() const;
		::Udm::AClassAssocAttr< Wire, Connectable> dstWire() const;
		template <class Pred> ::Udm::AClassAssocAttr< Wire, Connectable, Pred> dstWire_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Wire, Connectable, Pred>(impl, meta_dstWire, meta_dstWire_rev); };
		::Udm::AClassAssocAttr< Wire, Connectable> srcWire() const;
		template <class Pred> ::Udm::AClassAssocAttr< Wire, Connectable, Pred> srcWire_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< Wire, Connectable, Pred>(impl, meta_srcWire, meta_srcWire_rev); };
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstWire;
		static ::Uml::AssociationRole meta_dstWire_rev;
		static ::Uml::AssociationRole meta_srcWire;
		static ::Uml::AssociationRole meta_srcWire_rev;

	};

	class HWElement :  virtual  public MgaObject {
	public:
		HWElement();
		HWElement(::Udm::ObjectImpl *impl);
		HWElement(const HWElement &master);

#ifdef UDM_RVALUE
		HWElement(HWElement &&master);

		static HWElement Cast(::Udm::Object &&a);
		HWElement& operator=(HWElement &&a);

#endif
		static HWElement Cast(const ::Udm::Object &a);
		static HWElement Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		HWElement CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< HWElement> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< HWElement, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< HWElement, Pred>(impl); };
		HWElement CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< HWElement> Derived();
		template <class Pred> ::Udm::DerivedAttr< HWElement, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< HWElement, Pred>(impl); };
		::Udm::ArchetypeAttr< HWElement> Archetype() const;
		::Udm::StringAttr Configuration() const;
		::Udm::ChildrenAttr< ::ESMoL::ExecutionContext> ExecutionContext_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionContext, Pred> ExecutionContext_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionContext, Pred>(impl, meta_ExecutionContext_children); };
		::Udm::ChildrenAttr< ::ESMoL::ExecutionContext> ExecutionContext_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionContext, Pred> ExecutionContext_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionContext, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TTExecContext> TTExecContext_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TTExecContext, Pred> TTExecContext_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TTExecContext, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Configuration;
		static ::Uml::CompositionChildRole meta_ExecutionContext_children;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;

	};

	class HardwareUnit :  public HWElement {
	public:
		HardwareUnit();
		HardwareUnit(::Udm::ObjectImpl *impl);
		HardwareUnit(const HardwareUnit &master);

#ifdef UDM_RVALUE
		HardwareUnit(HardwareUnit &&master);

		static HardwareUnit Cast(::Udm::Object &&a);
		HardwareUnit& operator=(HardwareUnit &&a);

#endif
		static HardwareUnit Cast(const ::Udm::Object &a);
		static HardwareUnit Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		HardwareUnit CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< HardwareUnit> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< HardwareUnit, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< HardwareUnit, Pred>(impl); };
		HardwareUnit CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< HardwareUnit> Derived();
		template <class Pred> ::Udm::DerivedAttr< HardwareUnit, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< HardwareUnit, Pred>(impl); };
		::Udm::ArchetypeAttr< HardwareUnit> Archetype() const;
		::Udm::ChildrenAttr< ::ESMoL::Wire> Wire_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Wire, Pred> Wire_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Wire, Pred>(impl, meta_Wire_children); };
		::Udm::ChildrenAttr< ::ESMoL::HWElement> HWElement_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred> HWElement_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred>(impl, meta_HWElement_children); };
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, meta_Channel_children); };
		::Udm::ChildrenAttr< ::ESMoL::Plant> Plant_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Plant, Pred> Plant_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Plant, Pred>(impl, meta_Plant_children); };
		::Udm::ChildrenAttr< ::ESMoL::PhysConnection> PhysConnection_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PhysConnection, Pred> PhysConnection_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PhysConnection, Pred>(impl, meta_PhysConnection_children); };
		::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection> AcquisitionConnection_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection, Pred> AcquisitionConnection_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection, Pred>(impl, meta_AcquisitionConnection_children); };
		::Udm::ChildrenAttr< ::ESMoL::ActuationConnection> ActuationConnection_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ActuationConnection, Pred> ActuationConnection_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ActuationConnection, Pred>(impl, meta_ActuationConnection_children); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> CommMapping_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred> CommMapping_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Executable> Executable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred> Executable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TTBus> TTBus_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TTBus, Pred> TTBus_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TTBus, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OldBus> OldBus_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OldBus, Pred> OldBus_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OldBus, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CANBus> CANBus_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CANBus, Pred> CANBus_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CANBus, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Link> Link_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Link, Pred> Link_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Link, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::SerialLink> SerialLink_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SerialLink, Pred> SerialLink_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SerialLink, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Wire> Wire_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Wire, Pred> Wire_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Wire, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> HardwareUnit_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred> HardwareUnit_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Network> Network_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Network, Pred> Network_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Network, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connectable> Connectable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred> Connectable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::HWElement> HWElement_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred> HWElement_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IChan> IChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IChan, Pred> IChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OChan> OChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OChan, Pred> OChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::BChan> BChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred> BChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Bus> Bus_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Bus, Pred> Bus_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Bus, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Plant> Plant_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Plant, Pred> Plant_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Plant, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IODevice> IODevice_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IODevice, Pred> IODevice_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IODevice, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PhysConnection> PhysConnection_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PhysConnection, Pred> PhysConnection_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PhysConnection, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection> AcquisitionConnection_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection, Pred> AcquisitionConnection_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ActuationConnection> ActuationConnection_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ActuationConnection, Pred> ActuationConnection_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ActuationConnection, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PhysInterface> PhysInterface_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PhysInterface, Pred> PhysInterface_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PhysInterface, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Node> Node_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Node, Pred> Node_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Node, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::PlatformLibrary> PlatformLibrary_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionChildRole meta_Wire_children;
		static ::Uml::CompositionChildRole meta_HWElement_children;
		static ::Uml::CompositionChildRole meta_Channel_children;
		static ::Uml::CompositionChildRole meta_Plant_children;
		static ::Uml::CompositionChildRole meta_PhysConnection_children;
		static ::Uml::CompositionChildRole meta_AcquisitionConnection_children;
		static ::Uml::CompositionChildRole meta_ActuationConnection_children;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;
		static ::Uml::CompositionParentRole meta_PlatformLibrary_parent;

	};

	class Network :  public HWElement {
	public:
		Network();
		Network(::Udm::ObjectImpl *impl);
		Network(const Network &master);

#ifdef UDM_RVALUE
		Network(Network &&master);

		static Network Cast(::Udm::Object &&a);
		Network& operator=(Network &&a);

#endif
		static Network Cast(const ::Udm::Object &a);
		static Network Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Network CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Network> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Network, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Network, Pred>(impl); };
		Network CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Network> Derived();
		template <class Pred> ::Udm::DerivedAttr< Network, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Network, Pred>(impl); };
		::Udm::ArchetypeAttr< Network> Archetype() const;
		::Udm::StringAttr DataRate() const;
		::Udm::ChildrenAttr< ::ESMoL::BChan> BChan_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred> BChan_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred>(impl, meta_BChan_children); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> CommMapping_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred> CommMapping_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Executable> Executable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred> Executable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connectable> Connectable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred> Connectable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::BChan> BChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred> BChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_DataRate;
		static ::Uml::CompositionChildRole meta_BChan_children;

	};

	class Bus :  public Connectable,  public HWElement {
	public:
		Bus();
		Bus(::Udm::ObjectImpl *impl);
		Bus(const Bus &master);

#ifdef UDM_RVALUE
		Bus(Bus &&master);

		static Bus Cast(::Udm::Object &&a);
		Bus& operator=(Bus &&a);

#endif
		static Bus Cast(const ::Udm::Object &a);
		static Bus Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Bus CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Bus> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Bus, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Bus, Pred>(impl); };
		Bus CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Bus> Derived();
		template <class Pred> ::Udm::DerivedAttr< Bus, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Bus, Pred>(impl); };
		::Udm::ArchetypeAttr< Bus> Archetype() const;
		::Udm::StringAttr DataRate() const;
		::Udm::StringAttr DeprecatedOH() const;
		::Udm::StringAttr MinFrameSize() const;
		::Udm::StringAttr SwitchMemorySize() const;
		::Udm::IntegerAttr ID() const;
		::Udm::StringAttr SetupTime() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_DataRate;
		static ::Uml::Attribute meta_DeprecatedOH;
		static ::Uml::Attribute meta_MinFrameSize;
		static ::Uml::Attribute meta_SwitchMemorySize;
		static ::Uml::Attribute meta_ID;
		static ::Uml::Attribute meta_SetupTime;

	};

	class TTBus :  public Bus {
	public:
		TTBus();
		TTBus(::Udm::ObjectImpl *impl);
		TTBus(const TTBus &master);

#ifdef UDM_RVALUE
		TTBus(TTBus &&master);

		static TTBus Cast(::Udm::Object &&a);
		TTBus& operator=(TTBus &&a);

#endif
		static TTBus Cast(const ::Udm::Object &a);
		static TTBus Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		TTBus CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< TTBus> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< TTBus, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< TTBus, Pred>(impl); };
		TTBus CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< TTBus> Derived();
		template <class Pred> ::Udm::DerivedAttr< TTBus, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< TTBus, Pred>(impl); };
		::Udm::ArchetypeAttr< TTBus> Archetype() const;
		::Udm::StringAttr Hyperperiod() const;
		::Udm::StringAttr TTSetupTime() const;
		::Udm::StringAttr SlotSize() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Hyperperiod;
		static ::Uml::Attribute meta_TTSetupTime;
		static ::Uml::Attribute meta_SlotSize;

	};

	class OldBus :  public Bus {
	public:
		OldBus();
		OldBus(::Udm::ObjectImpl *impl);
		OldBus(const OldBus &master);

#ifdef UDM_RVALUE
		OldBus(OldBus &&master);

		static OldBus Cast(::Udm::Object &&a);
		OldBus& operator=(OldBus &&a);

#endif
		static OldBus Cast(const ::Udm::Object &a);
		static OldBus Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OldBus CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OldBus> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OldBus, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OldBus, Pred>(impl); };
		OldBus CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OldBus> Derived();
		template <class Pred> ::Udm::DerivedAttr< OldBus, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OldBus, Pred>(impl); };
		::Udm::ArchetypeAttr< OldBus> Archetype() const;
		::Udm::StringAttr Medium() const;
		::Udm::IntegerAttr FrameSize() const;
		::Udm::StringAttr OverheadTime() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Medium;
		static ::Uml::Attribute meta_FrameSize;
		static ::Uml::Attribute meta_OverheadTime;

	};

	class CANBus :  public Bus {
	public:
		CANBus();
		CANBus(::Udm::ObjectImpl *impl);
		CANBus(const CANBus &master);

#ifdef UDM_RVALUE
		CANBus(CANBus &&master);

		static CANBus Cast(::Udm::Object &&a);
		CANBus& operator=(CANBus &&a);

#endif
		static CANBus Cast(const ::Udm::Object &a);
		static CANBus Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CANBus CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CANBus> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CANBus, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CANBus, Pred>(impl); };
		CANBus CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CANBus> Derived();
		template <class Pred> ::Udm::DerivedAttr< CANBus, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CANBus, Pred>(impl); };
		::Udm::ArchetypeAttr< CANBus> Archetype() const;
		::Udm::StringAttr Hyperperiod() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Hyperperiod;

	};

	class Link :  public Bus {
	public:
		Link();
		Link(::Udm::ObjectImpl *impl);
		Link(const Link &master);

#ifdef UDM_RVALUE
		Link(Link &&master);

		static Link Cast(::Udm::Object &&a);
		Link& operator=(Link &&a);

#endif
		static Link Cast(const ::Udm::Object &a);
		static Link Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Link CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Link> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Link, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Link, Pred>(impl); };
		Link CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Link> Derived();
		template <class Pred> ::Udm::DerivedAttr< Link, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Link, Pred>(impl); };
		::Udm::ArchetypeAttr< Link> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;

	};

	class SerialLink :  public Link {
	public:
		SerialLink();
		SerialLink(::Udm::ObjectImpl *impl);
		SerialLink(const SerialLink &master);

#ifdef UDM_RVALUE
		SerialLink(SerialLink &&master);

		static SerialLink Cast(::Udm::Object &&a);
		SerialLink& operator=(SerialLink &&a);

#endif
		static SerialLink Cast(const ::Udm::Object &a);
		static SerialLink Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		SerialLink CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< SerialLink> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< SerialLink, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< SerialLink, Pred>(impl); };
		SerialLink CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< SerialLink> Derived();
		template <class Pred> ::Udm::DerivedAttr< SerialLink, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< SerialLink, Pred>(impl); };
		::Udm::ArchetypeAttr< SerialLink> Archetype() const;
		::Udm::IntegerAttr DataBits() const;
		::Udm::BooleanAttr Parity() const;
		::Udm::IntegerAttr StopBits() const;
		::Udm::StringAttr FlowControl() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_DataBits;
		static ::Uml::Attribute meta_Parity;
		static ::Uml::Attribute meta_StopBits;
		static ::Uml::Attribute meta_FlowControl;

	};

	class PhysConnection :  public MgaObject {
	public:
		PhysConnection();
		PhysConnection(::Udm::ObjectImpl *impl);
		PhysConnection(const PhysConnection &master);

#ifdef UDM_RVALUE
		PhysConnection(PhysConnection &&master);

		static PhysConnection Cast(::Udm::Object &&a);
		PhysConnection& operator=(PhysConnection &&a);

#endif
		static PhysConnection Cast(const ::Udm::Object &a);
		static PhysConnection Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PhysConnection CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PhysConnection> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PhysConnection, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PhysConnection, Pred>(impl); };
		PhysConnection CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PhysConnection> Derived();
		template <class Pred> ::Udm::DerivedAttr< PhysConnection, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PhysConnection, Pred>(impl); };
		::Udm::ArchetypeAttr< PhysConnection> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::PhysInterface> srcPhysConnection_end() const;
		::Udm::AssocEndAttr< ::ESMoL::PhysInterface> dstPhysConnection_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;
		static ::Uml::AssociationRole meta_srcPhysConnection_end_;
		static ::Uml::AssociationRole meta_dstPhysConnection_end_;

	};

	class AcquisitionConnection :  public MgaObject {
	public:
		AcquisitionConnection();
		AcquisitionConnection(::Udm::ObjectImpl *impl);
		AcquisitionConnection(const AcquisitionConnection &master);

#ifdef UDM_RVALUE
		AcquisitionConnection(AcquisitionConnection &&master);

		static AcquisitionConnection Cast(::Udm::Object &&a);
		AcquisitionConnection& operator=(AcquisitionConnection &&a);

#endif
		static AcquisitionConnection Cast(const ::Udm::Object &a);
		static AcquisitionConnection Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		AcquisitionConnection CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< AcquisitionConnection> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< AcquisitionConnection, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< AcquisitionConnection, Pred>(impl); };
		AcquisitionConnection CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< AcquisitionConnection> Derived();
		template <class Pred> ::Udm::DerivedAttr< AcquisitionConnection, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< AcquisitionConnection, Pred>(impl); };
		::Udm::ArchetypeAttr< AcquisitionConnection> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::IODevice> srcAcquisitionConnection_end() const;
		::Udm::AssocEndAttr< ::ESMoL::IChan> dstAcquisitionConnection_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;
		static ::Uml::AssociationRole meta_srcAcquisitionConnection_end_;
		static ::Uml::AssociationRole meta_dstAcquisitionConnection_end_;

	};

	class ActuationConnection :  public MgaObject {
	public:
		ActuationConnection();
		ActuationConnection(::Udm::ObjectImpl *impl);
		ActuationConnection(const ActuationConnection &master);

#ifdef UDM_RVALUE
		ActuationConnection(ActuationConnection &&master);

		static ActuationConnection Cast(::Udm::Object &&a);
		ActuationConnection& operator=(ActuationConnection &&a);

#endif
		static ActuationConnection Cast(const ::Udm::Object &a);
		static ActuationConnection Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ActuationConnection CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ActuationConnection> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ActuationConnection, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ActuationConnection, Pred>(impl); };
		ActuationConnection CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ActuationConnection> Derived();
		template <class Pred> ::Udm::DerivedAttr< ActuationConnection, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ActuationConnection, Pred>(impl); };
		::Udm::ArchetypeAttr< ActuationConnection> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::OChan> srcActuationConnection_end() const;
		::Udm::AssocEndAttr< ::ESMoL::IODevice> dstActuationConnection_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;
		static ::Uml::AssociationRole meta_srcActuationConnection_end_;
		static ::Uml::AssociationRole meta_dstActuationConnection_end_;

	};

	class PhysInterface :  virtual  public MgaObject {
	public:
		PhysInterface();
		PhysInterface(::Udm::ObjectImpl *impl);
		PhysInterface(const PhysInterface &master);

#ifdef UDM_RVALUE
		PhysInterface(PhysInterface &&master);

		static PhysInterface Cast(::Udm::Object &&a);
		PhysInterface& operator=(PhysInterface &&a);

#endif
		static PhysInterface Cast(const ::Udm::Object &a);
		static PhysInterface Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PhysInterface CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PhysInterface> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PhysInterface, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PhysInterface, Pred>(impl); };
		PhysInterface CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PhysInterface> Derived();
		template <class Pred> ::Udm::DerivedAttr< PhysInterface, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PhysInterface, Pred>(impl); };
		::Udm::ArchetypeAttr< PhysInterface> Archetype() const;
		::Udm::AClassAssocAttr< PhysConnection, PhysInterface> dstPhysConnection() const;
		template <class Pred> ::Udm::AClassAssocAttr< PhysConnection, PhysInterface, Pred> dstPhysConnection_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< PhysConnection, PhysInterface, Pred>(impl, meta_dstPhysConnection, meta_dstPhysConnection_rev); };
		::Udm::AClassAssocAttr< PhysConnection, PhysInterface> srcPhysConnection() const;
		template <class Pred> ::Udm::AClassAssocAttr< PhysConnection, PhysInterface, Pred> srcPhysConnection_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< PhysConnection, PhysInterface, Pred>(impl, meta_srcPhysConnection, meta_srcPhysConnection_rev); };
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstPhysConnection;
		static ::Uml::AssociationRole meta_dstPhysConnection_rev;
		static ::Uml::AssociationRole meta_srcPhysConnection;
		static ::Uml::AssociationRole meta_srcPhysConnection_rev;

	};

	class Plant :  public PhysInterface {
	public:
		Plant();
		Plant(::Udm::ObjectImpl *impl);
		Plant(const Plant &master);

#ifdef UDM_RVALUE
		Plant(Plant &&master);

		static Plant Cast(::Udm::Object &&a);
		Plant& operator=(Plant &&a);

#endif
		static Plant Cast(const ::Udm::Object &a);
		static Plant Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Plant CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Plant> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Plant, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Plant, Pred>(impl); };
		Plant CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Plant> Derived();
		template <class Pred> ::Udm::DerivedAttr< Plant, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Plant, Pred>(impl); };
		::Udm::ArchetypeAttr< Plant> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;

	};

	class IODevice :  public HWElement,  public PhysInterface {
	public:
		IODevice();
		IODevice(::Udm::ObjectImpl *impl);
		IODevice(const IODevice &master);

#ifdef UDM_RVALUE
		IODevice(IODevice &&master);

		static IODevice Cast(::Udm::Object &&a);
		IODevice& operator=(IODevice &&a);

#endif
		static IODevice Cast(const ::Udm::Object &a);
		static IODevice Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IODevice CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IODevice> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IODevice, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IODevice, Pred>(impl); };
		IODevice CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IODevice> Derived();
		template <class Pred> ::Udm::DerivedAttr< IODevice, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IODevice, Pred>(impl); };
		::Udm::ArchetypeAttr< IODevice> Archetype() const;
		::Udm::StringAttr DeviceType() const;
		::Udm::AClassAssocAttr< ActuationConnection, OChan> srcActuationConnection() const;
		template <class Pred> ::Udm::AClassAssocAttr< ActuationConnection, OChan, Pred> srcActuationConnection_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< ActuationConnection, OChan, Pred>(impl, meta_srcActuationConnection, meta_srcActuationConnection_rev); };
		::Udm::AClassAssocAttr< AcquisitionConnection, IChan> dstAcquisitionConnection() const;
		template <class Pred> ::Udm::AClassAssocAttr< AcquisitionConnection, IChan, Pred> dstAcquisitionConnection_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< AcquisitionConnection, IChan, Pred>(impl, meta_dstAcquisitionConnection, meta_dstAcquisitionConnection_rev); };
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, meta_Channel_children); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> CommMapping_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred> CommMapping_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Executable> Executable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred> Executable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connectable> Connectable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred> Connectable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IChan> IChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IChan, Pred> IChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OChan> OChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OChan, Pred> OChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::BChan> BChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred> BChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_DeviceType;
		static ::Uml::AssociationRole meta_srcActuationConnection;
		static ::Uml::AssociationRole meta_srcActuationConnection_rev;
		static ::Uml::AssociationRole meta_dstAcquisitionConnection;
		static ::Uml::AssociationRole meta_dstAcquisitionConnection_rev;
		static ::Uml::CompositionChildRole meta_Channel_children;

	};

	class Node :  public HWElement {
	public:
		Node();
		Node(::Udm::ObjectImpl *impl);
		Node(const Node &master);

#ifdef UDM_RVALUE
		Node(Node &&master);

		static Node Cast(::Udm::Object &&a);
		Node& operator=(Node &&a);

#endif
		static Node Cast(const ::Udm::Object &a);
		static Node Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Node CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Node> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Node, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Node, Pred>(impl); };
		Node CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Node> Derived();
		template <class Pred> ::Udm::DerivedAttr< Node, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Node, Pred>(impl); };
		::Udm::ArchetypeAttr< Node> Archetype() const;
		::Udm::StringAttr Simulator() const;
		::Udm::IntegerAttr ROM() const;
		::Udm::IntegerAttr RAM() const;
		::Udm::IntegerAttr Speed() const;
		::Udm::StringAttr CPU() const;
		::Udm::StringAttr PlatformType() const;
		::Udm::StringAttr BusIDList() const;
		::Udm::AssocAttr< NodeRef> referedbyNodeRef() const;
		template <class Pred> ::Udm::AssocAttr< NodeRef, Pred> referedbyNodeRef_sorted(const Pred &) const { return ::Udm::AssocAttr< NodeRef, Pred>(impl, meta_referedbyNodeRef); };
		::Udm::ChildAttr< ::ESMoL::OS> OS_child() const;
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, meta_Channel_children); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> CommMapping_Members_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred> CommMapping_Members_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Executable> Executable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred> Executable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OS> OS_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OS, Pred> OS_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OS, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Connectable> Connectable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred> Connectable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::IChan> IChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::IChan, Pred> IChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::IChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::OChan> OChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::OChan, Pred> OChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::OChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::BChan> BChan_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred> BChan_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::BChan, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Channel> Channel_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred> Channel_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Channel, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Simulator;
		static ::Uml::Attribute meta_ROM;
		static ::Uml::Attribute meta_RAM;
		static ::Uml::Attribute meta_Speed;
		static ::Uml::Attribute meta_CPU;
		static ::Uml::Attribute meta_PlatformType;
		static ::Uml::Attribute meta_BusIDList;
		static ::Uml::AssociationRole meta_referedbyNodeRef;
		static ::Uml::CompositionChildRole meta_OS_child;
		static ::Uml::CompositionChildRole meta_Channel_children;

	};

	class Channel :  public CommMapping_Members_Base,  public Connectable,  public Executable {
	public:
		Channel();
		Channel(::Udm::ObjectImpl *impl);
		Channel(const Channel &master);

#ifdef UDM_RVALUE
		Channel(Channel &&master);

		static Channel Cast(::Udm::Object &&a);
		Channel& operator=(Channel &&a);

#endif
		static Channel Cast(const ::Udm::Object &a);
		static Channel Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Channel CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Channel> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Channel, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Channel, Pred>(impl); };
		Channel CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Channel> Derived();
		template <class Pred> ::Udm::DerivedAttr< Channel, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Channel, Pred>(impl); };
		::Udm::ArchetypeAttr< Channel> Archetype() const;
		::Udm::StringAttr Configuration() const;
		::Udm::IntegerAttr ChanNum() const;
		::Udm::ParentAttr< ::ESMoL::HardwareUnit> HardwareUnit_parent() const;
		::Udm::ParentAttr< ::ESMoL::IODevice> IODevice_parent() const;
		::Udm::ParentAttr< ::ESMoL::Node> Node_parent() const;
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::Attribute meta_Configuration;
		static ::Uml::Attribute meta_ChanNum;
		static ::Uml::CompositionParentRole meta_HardwareUnit_parent;
		static ::Uml::CompositionParentRole meta_IODevice_parent;
		static ::Uml::CompositionParentRole meta_Node_parent;

	};

	class IChan :  public Channel {
	public:
		IChan();
		IChan(::Udm::ObjectImpl *impl);
		IChan(const IChan &master);

#ifdef UDM_RVALUE
		IChan(IChan &&master);

		static IChan Cast(::Udm::Object &&a);
		IChan& operator=(IChan &&a);

#endif
		static IChan Cast(const ::Udm::Object &a);
		static IChan Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		IChan CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< IChan> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< IChan, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< IChan, Pred>(impl); };
		IChan CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< IChan> Derived();
		template <class Pred> ::Udm::DerivedAttr< IChan, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< IChan, Pred>(impl); };
		::Udm::ArchetypeAttr< IChan> Archetype() const;
		::Udm::AClassAssocAttr< AcquisitionConnection, IODevice> srcAcquisitionConnection() const;
		template <class Pred> ::Udm::AClassAssocAttr< AcquisitionConnection, IODevice, Pred> srcAcquisitionConnection_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< AcquisitionConnection, IODevice, Pred>(impl, meta_srcAcquisitionConnection, meta_srcAcquisitionConnection_rev); };
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcAcquisitionConnection;
		static ::Uml::AssociationRole meta_srcAcquisitionConnection_rev;

	};

	class OChan :  public Channel {
	public:
		OChan();
		OChan(::Udm::ObjectImpl *impl);
		OChan(const OChan &master);

#ifdef UDM_RVALUE
		OChan(OChan &&master);

		static OChan Cast(::Udm::Object &&a);
		OChan& operator=(OChan &&a);

#endif
		static OChan Cast(const ::Udm::Object &a);
		static OChan Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		OChan CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< OChan> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< OChan, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< OChan, Pred>(impl); };
		OChan CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< OChan> Derived();
		template <class Pred> ::Udm::DerivedAttr< OChan, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< OChan, Pred>(impl); };
		::Udm::ArchetypeAttr< OChan> Archetype() const;
		::Udm::AClassAssocAttr< ActuationConnection, IODevice> dstActuationConnection() const;
		template <class Pred> ::Udm::AClassAssocAttr< ActuationConnection, IODevice, Pred> dstActuationConnection_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< ActuationConnection, IODevice, Pred>(impl, meta_dstActuationConnection, meta_dstActuationConnection_rev); };
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_dstActuationConnection;
		static ::Uml::AssociationRole meta_dstActuationConnection_rev;

	};

	class BChan :  public Channel {
	public:
		BChan();
		BChan(::Udm::ObjectImpl *impl);
		BChan(const BChan &master);

#ifdef UDM_RVALUE
		BChan(BChan &&master);

		static BChan Cast(::Udm::Object &&a);
		BChan& operator=(BChan &&a);

#endif
		static BChan Cast(const ::Udm::Object &a);
		static BChan Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		BChan CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< BChan> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< BChan, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< BChan, Pred>(impl); };
		BChan CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< BChan> Derived();
		template <class Pred> ::Udm::DerivedAttr< BChan, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< BChan, Pred>(impl); };
		::Udm::ArchetypeAttr< BChan> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::Network> Network_parent() const;
		::Udm::ParentAttr< ::ESMoL::HWElement> parent() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_Network_parent;

	};

	class System :  public MgaObject {
	public:
		System();
		System(::Udm::ObjectImpl *impl);
		System(const System &master);

#ifdef UDM_RVALUE
		System(System &&master);

		static System Cast(::Udm::Object &&a);
		System& operator=(System &&a);

#endif
		static System Cast(const ::Udm::Object &a);
		static System Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		System CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< System> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< System, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< System, Pred>(impl); };
		System CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< System> Derived();
		template <class Pred> ::Udm::DerivedAttr< System, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< System, Pred>(impl); };
		::Udm::ArchetypeAttr< System> Archetype() const;
		::Udm::AssocAttr< DesignReference> referedbyDesignReference() const;
		template <class Pred> ::Udm::AssocAttr< DesignReference, Pred> referedbyDesignReference_sorted(const Pred &) const { return ::Udm::AssocAttr< DesignReference, Pred>(impl, meta_referedbyDesignReference); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentRef> ComponentRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentRef, Pred> ComponentRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef, Pred>(impl, meta_ComponentRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::NodeRef> NodeRef_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::NodeRef, Pred> NodeRef_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::NodeRef, Pred>(impl, meta_NodeRef_children); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping> CommMapping_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping, Pred> CommMapping_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping, Pred>(impl, meta_CommMapping_children); };
		::Udm::ChildrenAttr< ::ESMoL::Dependency> Dependency_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Dependency, Pred> Dependency_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Dependency, Pred>(impl, meta_Dependency_children); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment> ComponentAssignment_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment, Pred> ComponentAssignment_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment, Pred>(impl, meta_ComponentAssignment_children); };
		::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo> ExecutionInfo_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo, Pred> ExecutionInfo_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo, Pred>(impl, meta_ExecutionInfo_children); };
		::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment> ExecutionAssignment_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment, Pred> ExecutionAssignment_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment, Pred>(impl, meta_ExecutionAssignment_children); };
		::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base, Pred> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_srcCommMapping_RPContainer_Base> CommMapping_srcCommMapping_RPContainer_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_srcCommMapping_RPContainer_Base, Pred> CommMapping_srcCommMapping_RPContainer_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_srcCommMapping_RPContainer_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping_dstCommMapping_RPContainer_Base> CommMapping_dstCommMapping_RPContainer_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping_dstCommMapping_RPContainer_Base, Pred> CommMapping_dstCommMapping_RPContainer_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_dstCommMapping_RPContainer_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base> ComponentRef_RefersTo_Base_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base, Pred> ComponentRef_RefersTo_Base_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo> ExecutionInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo, Pred> ExecutionInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::TTExecInfo> TTExecInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::TTExecInfo, Pred> TTExecInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::TTExecInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::AsyncPeriodicExecInfo> AsyncPeriodicExecInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::AsyncPeriodicExecInfo, Pred> AsyncPeriodicExecInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::AsyncPeriodicExecInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PeriodicExecInfo> PeriodicExecInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PeriodicExecInfo, Pred> PeriodicExecInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PeriodicExecInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment> ExecutionAssignment_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment, Pred> ExecutionAssignment_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Executable> Executable_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred> Executable_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Executable, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::AperiodicExecInfo> AperiodicExecInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::AperiodicExecInfo, Pred> AperiodicExecInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::AperiodicExecInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::SporadicExecInfo> SporadicExecInfo_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::SporadicExecInfo, Pred> SporadicExecInfo_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::SporadicExecInfo, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::NodeRef> NodeRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::NodeRef, Pred> NodeRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::NodeRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentRef> ComponentRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentRef, Pred> ComponentRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::CommMapping> CommMapping_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::CommMapping, Pred> CommMapping_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::Dependency> Dependency_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::Dependency, Pred> Dependency_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::Dependency, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment> ComponentAssignment_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment, Pred> ComponentAssignment_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::PlantComponentRef> PlantComponentRef_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::PlantComponentRef, Pred> PlantComponentRef_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::PlantComponentRef, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ChildrenAttr< ::ESMoL::MgaObject> MgaObject_kind_children() const;
		template <class Pred> ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred> MgaObject_kind_children_sorted(const Pred &) const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject, Pred>(impl, ::Udm::NULLCHILDROLE); };
		::Udm::ParentAttr< ::ESMoL::DesignFolder> DesignFolder_parent() const;
		::Udm::ParentAttr< ::ESMoL::DeploymentLibrary> DeploymentLibrary_parent() const;
		::Udm::ParentAttr< ::Udm::Object> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyDesignReference;
		static ::Uml::CompositionChildRole meta_ComponentRef_children;
		static ::Uml::CompositionChildRole meta_NodeRef_children;
		static ::Uml::CompositionChildRole meta_CommMapping_children;
		static ::Uml::CompositionChildRole meta_Dependency_children;
		static ::Uml::CompositionChildRole meta_ComponentAssignment_children;
		static ::Uml::CompositionChildRole meta_ExecutionInfo_children;
		static ::Uml::CompositionChildRole meta_ExecutionAssignment_children;
		static ::Uml::CompositionParentRole meta_DesignFolder_parent;
		static ::Uml::CompositionParentRole meta_DeploymentLibrary_parent;

	};

	class NodeRef :  public CommMapping_dstCommMapping_RPContainer_Base,  public CommMapping_srcCommMapping_RPContainer_Base,  public ExecutionAssignment_dstExecutionAssignment_RPContainer_Base,  public MgaObject {
	public:
		NodeRef();
		NodeRef(::Udm::ObjectImpl *impl);
		NodeRef(const NodeRef &master);

#ifdef UDM_RVALUE
		NodeRef(NodeRef &&master);

		static NodeRef Cast(::Udm::Object &&a);
		NodeRef& operator=(NodeRef &&a);

#endif
		static NodeRef Cast(const ::Udm::Object &a);
		static NodeRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		NodeRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< NodeRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< NodeRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< NodeRef, Pred>(impl); };
		NodeRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< NodeRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< NodeRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< NodeRef, Pred>(impl); };
		::Udm::ArchetypeAttr< NodeRef> Archetype() const;
		::Udm::PointerAttr< Node> ref() const;
		::Udm::AClassAssocAttr< ComponentAssignment, ComponentRef> srcComponentAssignment() const;
		template <class Pred> ::Udm::AClassAssocAttr< ComponentAssignment, ComponentRef, Pred> srcComponentAssignment_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< ComponentAssignment, ComponentRef, Pred>(impl, meta_srcComponentAssignment, meta_srcComponentAssignment_rev); };
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::AssociationRole meta_srcComponentAssignment;
		static ::Uml::AssociationRole meta_srcComponentAssignment_rev;
		static ::Uml::CompositionParentRole meta_System_parent;

	};

	class ComponentRef :  public CommMapping_dstCommMapping_RPContainer_Base,  public CommMapping_srcCommMapping_RPContainer_Base,  public ComponentRef_RefersTo_Base,  public Executable,  public ExecutionAssignment_dstExecutionAssignment_RPContainer_Base {
	public:
		ComponentRef();
		ComponentRef(::Udm::ObjectImpl *impl);
		ComponentRef(const ComponentRef &master);

#ifdef UDM_RVALUE
		ComponentRef(ComponentRef &&master);

		static ComponentRef Cast(::Udm::Object &&a);
		ComponentRef& operator=(ComponentRef &&a);

#endif
		static ComponentRef Cast(const ::Udm::Object &a);
		static ComponentRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ComponentRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ComponentRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ComponentRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ComponentRef, Pred>(impl); };
		ComponentRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ComponentRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< ComponentRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ComponentRef, Pred>(impl); };
		::Udm::ArchetypeAttr< ComponentRef> Archetype() const;
		::Udm::AssocAttr< TaskInst> referedbyTaskInst() const;
		template <class Pred> ::Udm::AssocAttr< TaskInst, Pred> referedbyTaskInst_sorted(const Pred &) const { return ::Udm::AssocAttr< TaskInst, Pred>(impl, meta_referedbyTaskInst); };
		::Udm::AssocAttr< Action> referedbyAction() const;
		template <class Pred> ::Udm::AssocAttr< Action, Pred> referedbyAction_sorted(const Pred &) const { return ::Udm::AssocAttr< Action, Pred>(impl, meta_referedbyAction); };
		::Udm::AssocAttr< FaultMgrTask> referedbyFaultMgrTask() const;
		template <class Pred> ::Udm::AssocAttr< FaultMgrTask, Pred> referedbyFaultMgrTask_sorted(const Pred &) const { return ::Udm::AssocAttr< FaultMgrTask, Pred>(impl, meta_referedbyFaultMgrTask); };
		::Udm::AssocAttr< Dependency> srcDependency__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< Dependency, Pred> srcDependency__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< Dependency, Pred>(impl, meta_srcDependency__rp_helper_rev); };
		::Udm::AssocAttr< Dependency> dstDependency__rp_helper_rev() const;
		template <class Pred> ::Udm::AssocAttr< Dependency, Pred> dstDependency__rp_helper_rev_sorted(const Pred &) const { return ::Udm::AssocAttr< Dependency, Pred>(impl, meta_dstDependency__rp_helper_rev); };
		::Udm::AClassAssocAttr< ComponentAssignment, NodeRef> dstComponentAssignment() const;
		template <class Pred> ::Udm::AClassAssocAttr< ComponentAssignment, NodeRef, Pred> dstComponentAssignment_sorted(const Pred &) const { return ::Udm::AClassAssocAttr< ComponentAssignment, NodeRef, Pred>(impl, meta_dstComponentAssignment, meta_dstComponentAssignment_rev); };
		::Udm::PointerAttr< ComponentRef_RefersTo_Base> ref() const;
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_referedbyTaskInst;
		static ::Uml::AssociationRole meta_referedbyAction;
		static ::Uml::AssociationRole meta_referedbyFaultMgrTask;
		static ::Uml::AssociationRole meta_srcDependency__rp_helper_rev;
		static ::Uml::AssociationRole meta_dstDependency__rp_helper_rev;
		static ::Uml::AssociationRole meta_dstComponentAssignment;
		static ::Uml::AssociationRole meta_dstComponentAssignment_rev;
		static ::Uml::AssociationRole meta_ref;
		static ::Uml::CompositionParentRole meta_System_parent;

	};

	class CommMapping :  public MgaObject {
	public:
		typedef std::pair< ::ESMoL::CommMapping_Members_Base, std::vector< ::Udm::Object> > srcCommMapping_chain_t;
		typedef std::pair< ::ESMoL::CommMapping_Members_Base, std::vector< ::Udm::Object> > dstCommMapping_chain_t;

		CommMapping();
		CommMapping(::Udm::ObjectImpl *impl);
		CommMapping(const CommMapping &master);

#ifdef UDM_RVALUE
		CommMapping(CommMapping &&master);

		static CommMapping Cast(::Udm::Object &&a);
		CommMapping& operator=(CommMapping &&a);

#endif
		static CommMapping Cast(const ::Udm::Object &a);
		static CommMapping Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		CommMapping CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< CommMapping> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< CommMapping, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< CommMapping, Pred>(impl); };
		CommMapping CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< CommMapping> Derived();
		template <class Pred> ::Udm::DerivedAttr< CommMapping, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< CommMapping, Pred>(impl); };
		::Udm::ArchetypeAttr< CommMapping> Archetype() const;
		::Udm::PointerAttr< CommMapping_srcCommMapping_RPContainer_Base> srcCommMapping__rp_helper() const;
		::Udm::PointerAttr< CommMapping_dstCommMapping_RPContainer_Base> dstCommMapping__rp_helper() const;
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::CommMapping_Members_Base> srcCommMapping_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::CommMapping_Members_Base, srcCommMapping_chain_t > srcCommMapping_chain() const;
		::Udm::AssocEndAttr< ::ESMoL::CommMapping_Members_Base> dstCommMapping_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::CommMapping_Members_Base, dstCommMapping_chain_t > dstCommMapping_chain() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcCommMapping__rp_helper;
		static ::Uml::AssociationRole meta_dstCommMapping__rp_helper;
		static ::Uml::CompositionParentRole meta_System_parent;
		static ::Uml::AssociationRole meta_srcCommMapping_end_;
		static ::Uml::AssociationRole meta_dstCommMapping_end_;

	};

	class Dependency :  public MgaObject {
	public:
		typedef std::pair< ::ESMoL::MessageRef, std::vector< ::Udm::Object> > srcDependency_chain_t;
		typedef std::pair< ::ESMoL::MessageRef, std::vector< ::Udm::Object> > dstDependency_chain_t;

		Dependency();
		Dependency(::Udm::ObjectImpl *impl);
		Dependency(const Dependency &master);

#ifdef UDM_RVALUE
		Dependency(Dependency &&master);

		static Dependency Cast(::Udm::Object &&a);
		Dependency& operator=(Dependency &&a);

#endif
		static Dependency Cast(const ::Udm::Object &a);
		static Dependency Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		Dependency CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< Dependency> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< Dependency, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< Dependency, Pred>(impl); };
		Dependency CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< Dependency> Derived();
		template <class Pred> ::Udm::DerivedAttr< Dependency, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< Dependency, Pred>(impl); };
		::Udm::ArchetypeAttr< Dependency> Archetype() const;
		::Udm::PointerAttr< ComponentRef> srcDependency__rp_helper() const;
		::Udm::PointerAttr< ComponentRef> dstDependency__rp_helper() const;
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::MessageRef> srcDependency_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::MessageRef, srcDependency_chain_t > srcDependency_chain() const;
		::Udm::AssocEndAttr< ::ESMoL::MessageRef> dstDependency_end() const;
		::Udm::AssocEndChainAttr< ::ESMoL::MessageRef, dstDependency_chain_t > dstDependency_chain() const;

		static ::Uml::Class meta;
		static ::Uml::AssociationRole meta_srcDependency__rp_helper;
		static ::Uml::AssociationRole meta_dstDependency__rp_helper;
		static ::Uml::CompositionParentRole meta_System_parent;
		static ::Uml::AssociationRole meta_srcDependency_end_;
		static ::Uml::AssociationRole meta_dstDependency_end_;

	};

	class ComponentAssignment :  public MgaObject {
	public:
		ComponentAssignment();
		ComponentAssignment(::Udm::ObjectImpl *impl);
		ComponentAssignment(const ComponentAssignment &master);

#ifdef UDM_RVALUE
		ComponentAssignment(ComponentAssignment &&master);

		static ComponentAssignment Cast(::Udm::Object &&a);
		ComponentAssignment& operator=(ComponentAssignment &&a);

#endif
		static ComponentAssignment Cast(const ::Udm::Object &a);
		static ComponentAssignment Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		ComponentAssignment CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< ComponentAssignment> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< ComponentAssignment, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< ComponentAssignment, Pred>(impl); };
		ComponentAssignment CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< ComponentAssignment> Derived();
		template <class Pred> ::Udm::DerivedAttr< ComponentAssignment, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< ComponentAssignment, Pred>(impl); };
		::Udm::ArchetypeAttr< ComponentAssignment> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::System> System_parent() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;
		::Udm::AssocEndAttr< ::ESMoL::ComponentRef> srcComponentAssignment_end() const;
		::Udm::AssocEndAttr< ::ESMoL::NodeRef> dstComponentAssignment_end() const;

		static ::Uml::Class meta;
		static ::Uml::CompositionParentRole meta_System_parent;
		static ::Uml::AssociationRole meta_srcComponentAssignment_end_;
		static ::Uml::AssociationRole meta_dstComponentAssignment_end_;

	};

	class PlantComponentRef :  public ComponentRef {
	public:
		PlantComponentRef();
		PlantComponentRef(::Udm::ObjectImpl *impl);
		PlantComponentRef(const PlantComponentRef &master);

#ifdef UDM_RVALUE
		PlantComponentRef(PlantComponentRef &&master);

		static PlantComponentRef Cast(::Udm::Object &&a);
		PlantComponentRef& operator=(PlantComponentRef &&a);

#endif
		static PlantComponentRef Cast(const ::Udm::Object &a);
		static PlantComponentRef Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		PlantComponentRef CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::InstantiatedAttr< PlantComponentRef> Instances();
		template <class Pred> ::Udm::InstantiatedAttr< PlantComponentRef, Pred> Instances_sorted(const Pred &) { return ::Udm::InstantiatedAttr< PlantComponentRef, Pred>(impl); };
		PlantComponentRef CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role = ::Udm::NULLCHILDROLE);
		::Udm::DerivedAttr< PlantComponentRef> Derived();
		template <class Pred> ::Udm::DerivedAttr< PlantComponentRef, Pred> Derived_sorted(const Pred &) { return ::Udm::DerivedAttr< PlantComponentRef, Pred>(impl); };
		::Udm::ArchetypeAttr< PlantComponentRef> Archetype() const;
		::Udm::ParentAttr< ::ESMoL::System> parent() const;

		static ::Uml::Class meta;

	};

}

#endif // MOBIES_ESMOL_H
