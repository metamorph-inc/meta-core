// cpp (meta datanetwork format) source file ESMoL.cpp
// generated from diagram ESMoL
// generated on Mon Jul 23 16:50:57 2012

#include "ESMoL.h"
#include <UmlExt.h>
#include <UdmStatic.h>

#include <UdmDom.h>
#include "ESMoL_xsd.h"
using namespace std;

// cross-package metainformation header file
#include "ESM2SLC.h"

namespace ESMoL {

	FaultToInput_Members_Base::FaultToInput_Members_Base() {}
	FaultToInput_Members_Base::FaultToInput_Members_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	FaultToInput_Members_Base::FaultToInput_Members_Base(const FaultToInput_Members_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultToInput_Members_Base::FaultToInput_Members_Base(FaultToInput_Members_Base &&master) : UDM_OBJECT(master) {};

	FaultToInput_Members_Base FaultToInput_Members_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultToInput_Members_Base& FaultToInput_Members_Base::operator=(FaultToInput_Members_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultToInput_Members_Base FaultToInput_Members_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultToInput_Members_Base FaultToInput_Members_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultToInput_Members_Base FaultToInput_Members_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultToInput_Members_Base> FaultToInput_Members_Base::Instances() { return ::Udm::InstantiatedAttr< FaultToInput_Members_Base>(impl); }
	FaultToInput_Members_Base FaultToInput_Members_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultToInput_Members_Base> FaultToInput_Members_Base::Derived() { return ::Udm::DerivedAttr< FaultToInput_Members_Base>(impl); }
	::Udm::ArchetypeAttr< FaultToInput_Members_Base> FaultToInput_Members_Base::Archetype() const { return ::Udm::ArchetypeAttr< FaultToInput_Members_Base>(impl); }
	::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base> FaultToInput_Members_Base::dstFaultToInput() const { return ::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base>(impl, meta_dstFaultToInput, meta_dstFaultToInput_rev); }
	::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base> FaultToInput_Members_Base::srcFaultToInput() const { return ::Udm::AClassAssocAttr< FaultToInput, FaultToInput_Members_Base>(impl, meta_srcFaultToInput, meta_srcFaultToInput_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> FaultToInput_Members_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultToInput_Members_Base::meta;
	::Uml::AssociationRole FaultToInput_Members_Base::meta_dstFaultToInput;
	::Uml::AssociationRole FaultToInput_Members_Base::meta_dstFaultToInput_rev;
	::Uml::AssociationRole FaultToInput_Members_Base::meta_srcFaultToInput;
	::Uml::AssociationRole FaultToInput_Members_Base::meta_srcFaultToInput_rev;

	OutputToFault_Members_Base::OutputToFault_Members_Base() {}
	OutputToFault_Members_Base::OutputToFault_Members_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	OutputToFault_Members_Base::OutputToFault_Members_Base(const OutputToFault_Members_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OutputToFault_Members_Base::OutputToFault_Members_Base(OutputToFault_Members_Base &&master) : UDM_OBJECT(master) {};

	OutputToFault_Members_Base OutputToFault_Members_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutputToFault_Members_Base& OutputToFault_Members_Base::operator=(OutputToFault_Members_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutputToFault_Members_Base OutputToFault_Members_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutputToFault_Members_Base OutputToFault_Members_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutputToFault_Members_Base OutputToFault_Members_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutputToFault_Members_Base> OutputToFault_Members_Base::Instances() { return ::Udm::InstantiatedAttr< OutputToFault_Members_Base>(impl); }
	OutputToFault_Members_Base OutputToFault_Members_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutputToFault_Members_Base> OutputToFault_Members_Base::Derived() { return ::Udm::DerivedAttr< OutputToFault_Members_Base>(impl); }
	::Udm::ArchetypeAttr< OutputToFault_Members_Base> OutputToFault_Members_Base::Archetype() const { return ::Udm::ArchetypeAttr< OutputToFault_Members_Base>(impl); }
	::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base> OutputToFault_Members_Base::dstOutputToFault() const { return ::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base>(impl, meta_dstOutputToFault, meta_dstOutputToFault_rev); }
	::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base> OutputToFault_Members_Base::srcOutputToFault() const { return ::Udm::AClassAssocAttr< OutputToFault, OutputToFault_Members_Base>(impl, meta_srcOutputToFault, meta_srcOutputToFault_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> OutputToFault_Members_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OutputToFault_Members_Base::meta;
	::Uml::AssociationRole OutputToFault_Members_Base::meta_dstOutputToFault;
	::Uml::AssociationRole OutputToFault_Members_Base::meta_dstOutputToFault_rev;
	::Uml::AssociationRole OutputToFault_Members_Base::meta_srcOutputToFault;
	::Uml::AssociationRole OutputToFault_Members_Base::meta_srcOutputToFault_rev;

	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base() {}
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(const ExecutionAssignment_dstExecutionAssignment_RPContainer_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base &&master) : UDM_OBJECT(master) {};

	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base& ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::operator=(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::Instances() { return ::Udm::InstantiatedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base>(impl); }
	ExecutionAssignment_dstExecutionAssignment_RPContainer_Base ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::Derived() { return ::Udm::DerivedAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base>(impl); }
	::Udm::ArchetypeAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::Archetype() const { return ::Udm::ArchetypeAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base>(impl); }
	::Udm::AssocAttr< ExecutionAssignment> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::dstExecutionAssignment__rp_helper_rev() const { return ::Udm::AssocAttr< ExecutionAssignment>(impl, meta_dstExecutionAssignment__rp_helper_rev); }
	::Udm::ParentAttr< ::ESMoL::System> ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta;
	::Uml::AssociationRole ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta_dstExecutionAssignment__rp_helper_rev;

	Connector_srcConnector_RPContainer_Base::Connector_srcConnector_RPContainer_Base() {}
	Connector_srcConnector_RPContainer_Base::Connector_srcConnector_RPContainer_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Connector_srcConnector_RPContainer_Base::Connector_srcConnector_RPContainer_Base(const Connector_srcConnector_RPContainer_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Connector_srcConnector_RPContainer_Base::Connector_srcConnector_RPContainer_Base(Connector_srcConnector_RPContainer_Base &&master) : UDM_OBJECT(master) {};

	Connector_srcConnector_RPContainer_Base Connector_srcConnector_RPContainer_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Connector_srcConnector_RPContainer_Base& Connector_srcConnector_RPContainer_Base::operator=(Connector_srcConnector_RPContainer_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Connector_srcConnector_RPContainer_Base Connector_srcConnector_RPContainer_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Connector_srcConnector_RPContainer_Base Connector_srcConnector_RPContainer_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Connector_srcConnector_RPContainer_Base Connector_srcConnector_RPContainer_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Connector_srcConnector_RPContainer_Base> Connector_srcConnector_RPContainer_Base::Instances() { return ::Udm::InstantiatedAttr< Connector_srcConnector_RPContainer_Base>(impl); }
	Connector_srcConnector_RPContainer_Base Connector_srcConnector_RPContainer_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Connector_srcConnector_RPContainer_Base> Connector_srcConnector_RPContainer_Base::Derived() { return ::Udm::DerivedAttr< Connector_srcConnector_RPContainer_Base>(impl); }
	::Udm::ArchetypeAttr< Connector_srcConnector_RPContainer_Base> Connector_srcConnector_RPContainer_Base::Archetype() const { return ::Udm::ArchetypeAttr< Connector_srcConnector_RPContainer_Base>(impl); }
	::Udm::AssocAttr< Connector> Connector_srcConnector_RPContainer_Base::srcConnector__rp_helper_rev() const { return ::Udm::AssocAttr< Connector>(impl, meta_srcConnector__rp_helper_rev); }
	::Udm::ParentAttr< ::ESMoL::Component> Connector_srcConnector_RPContainer_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Connector_srcConnector_RPContainer_Base::meta;
	::Uml::AssociationRole Connector_srcConnector_RPContainer_Base::meta_srcConnector__rp_helper_rev;

	Connector_dstConnector_RPContainer_Base::Connector_dstConnector_RPContainer_Base() {}
	Connector_dstConnector_RPContainer_Base::Connector_dstConnector_RPContainer_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Connector_dstConnector_RPContainer_Base::Connector_dstConnector_RPContainer_Base(const Connector_dstConnector_RPContainer_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Connector_dstConnector_RPContainer_Base::Connector_dstConnector_RPContainer_Base(Connector_dstConnector_RPContainer_Base &&master) : UDM_OBJECT(master) {};

	Connector_dstConnector_RPContainer_Base Connector_dstConnector_RPContainer_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Connector_dstConnector_RPContainer_Base& Connector_dstConnector_RPContainer_Base::operator=(Connector_dstConnector_RPContainer_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Connector_dstConnector_RPContainer_Base Connector_dstConnector_RPContainer_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Connector_dstConnector_RPContainer_Base Connector_dstConnector_RPContainer_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Connector_dstConnector_RPContainer_Base Connector_dstConnector_RPContainer_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Connector_dstConnector_RPContainer_Base> Connector_dstConnector_RPContainer_Base::Instances() { return ::Udm::InstantiatedAttr< Connector_dstConnector_RPContainer_Base>(impl); }
	Connector_dstConnector_RPContainer_Base Connector_dstConnector_RPContainer_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Connector_dstConnector_RPContainer_Base> Connector_dstConnector_RPContainer_Base::Derived() { return ::Udm::DerivedAttr< Connector_dstConnector_RPContainer_Base>(impl); }
	::Udm::ArchetypeAttr< Connector_dstConnector_RPContainer_Base> Connector_dstConnector_RPContainer_Base::Archetype() const { return ::Udm::ArchetypeAttr< Connector_dstConnector_RPContainer_Base>(impl); }
	::Udm::AssocAttr< Connector> Connector_dstConnector_RPContainer_Base::dstConnector__rp_helper_rev() const { return ::Udm::AssocAttr< Connector>(impl, meta_dstConnector__rp_helper_rev); }
	::Udm::ParentAttr< ::ESMoL::Component> Connector_dstConnector_RPContainer_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Connector_dstConnector_RPContainer_Base::meta;
	::Uml::AssociationRole Connector_dstConnector_RPContainer_Base::meta_dstConnector__rp_helper_rev;

	MessageRef_RefersTo_Base::MessageRef_RefersTo_Base() {}
	MessageRef_RefersTo_Base::MessageRef_RefersTo_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	MessageRef_RefersTo_Base::MessageRef_RefersTo_Base(const MessageRef_RefersTo_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	MessageRef_RefersTo_Base::MessageRef_RefersTo_Base(MessageRef_RefersTo_Base &&master) : UDM_OBJECT(master) {};

	MessageRef_RefersTo_Base MessageRef_RefersTo_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	MessageRef_RefersTo_Base& MessageRef_RefersTo_Base::operator=(MessageRef_RefersTo_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	MessageRef_RefersTo_Base MessageRef_RefersTo_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	MessageRef_RefersTo_Base MessageRef_RefersTo_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	MessageRef_RefersTo_Base MessageRef_RefersTo_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< MessageRef_RefersTo_Base> MessageRef_RefersTo_Base::Instances() { return ::Udm::InstantiatedAttr< MessageRef_RefersTo_Base>(impl); }
	MessageRef_RefersTo_Base MessageRef_RefersTo_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< MessageRef_RefersTo_Base> MessageRef_RefersTo_Base::Derived() { return ::Udm::DerivedAttr< MessageRef_RefersTo_Base>(impl); }
	::Udm::ArchetypeAttr< MessageRef_RefersTo_Base> MessageRef_RefersTo_Base::Archetype() const { return ::Udm::ArchetypeAttr< MessageRef_RefersTo_Base>(impl); }
	::Udm::AssocAttr< MessageRef> MessageRef_RefersTo_Base::referedbyBusMessageRef() const { return ::Udm::AssocAttr< MessageRef>(impl, meta_referedbyBusMessageRef); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> MessageRef_RefersTo_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class MessageRef_RefersTo_Base::meta;
	::Uml::AssociationRole MessageRef_RefersTo_Base::meta_referedbyBusMessageRef;

	CommMapping_srcCommMapping_RPContainer_Base::CommMapping_srcCommMapping_RPContainer_Base() {}
	CommMapping_srcCommMapping_RPContainer_Base::CommMapping_srcCommMapping_RPContainer_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	CommMapping_srcCommMapping_RPContainer_Base::CommMapping_srcCommMapping_RPContainer_Base(const CommMapping_srcCommMapping_RPContainer_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CommMapping_srcCommMapping_RPContainer_Base::CommMapping_srcCommMapping_RPContainer_Base(CommMapping_srcCommMapping_RPContainer_Base &&master) : UDM_OBJECT(master) {};

	CommMapping_srcCommMapping_RPContainer_Base CommMapping_srcCommMapping_RPContainer_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CommMapping_srcCommMapping_RPContainer_Base& CommMapping_srcCommMapping_RPContainer_Base::operator=(CommMapping_srcCommMapping_RPContainer_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CommMapping_srcCommMapping_RPContainer_Base CommMapping_srcCommMapping_RPContainer_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CommMapping_srcCommMapping_RPContainer_Base CommMapping_srcCommMapping_RPContainer_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CommMapping_srcCommMapping_RPContainer_Base CommMapping_srcCommMapping_RPContainer_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CommMapping_srcCommMapping_RPContainer_Base> CommMapping_srcCommMapping_RPContainer_Base::Instances() { return ::Udm::InstantiatedAttr< CommMapping_srcCommMapping_RPContainer_Base>(impl); }
	CommMapping_srcCommMapping_RPContainer_Base CommMapping_srcCommMapping_RPContainer_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CommMapping_srcCommMapping_RPContainer_Base> CommMapping_srcCommMapping_RPContainer_Base::Derived() { return ::Udm::DerivedAttr< CommMapping_srcCommMapping_RPContainer_Base>(impl); }
	::Udm::ArchetypeAttr< CommMapping_srcCommMapping_RPContainer_Base> CommMapping_srcCommMapping_RPContainer_Base::Archetype() const { return ::Udm::ArchetypeAttr< CommMapping_srcCommMapping_RPContainer_Base>(impl); }
	::Udm::AssocAttr< CommMapping> CommMapping_srcCommMapping_RPContainer_Base::srcCommMapping__rp_helper_rev() const { return ::Udm::AssocAttr< CommMapping>(impl, meta_srcCommMapping__rp_helper_rev); }
	::Udm::ParentAttr< ::ESMoL::System> CommMapping_srcCommMapping_RPContainer_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CommMapping_srcCommMapping_RPContainer_Base::meta;
	::Uml::AssociationRole CommMapping_srcCommMapping_RPContainer_Base::meta_srcCommMapping__rp_helper_rev;

	CommMapping_dstCommMapping_RPContainer_Base::CommMapping_dstCommMapping_RPContainer_Base() {}
	CommMapping_dstCommMapping_RPContainer_Base::CommMapping_dstCommMapping_RPContainer_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	CommMapping_dstCommMapping_RPContainer_Base::CommMapping_dstCommMapping_RPContainer_Base(const CommMapping_dstCommMapping_RPContainer_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CommMapping_dstCommMapping_RPContainer_Base::CommMapping_dstCommMapping_RPContainer_Base(CommMapping_dstCommMapping_RPContainer_Base &&master) : UDM_OBJECT(master) {};

	CommMapping_dstCommMapping_RPContainer_Base CommMapping_dstCommMapping_RPContainer_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CommMapping_dstCommMapping_RPContainer_Base& CommMapping_dstCommMapping_RPContainer_Base::operator=(CommMapping_dstCommMapping_RPContainer_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CommMapping_dstCommMapping_RPContainer_Base CommMapping_dstCommMapping_RPContainer_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CommMapping_dstCommMapping_RPContainer_Base CommMapping_dstCommMapping_RPContainer_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CommMapping_dstCommMapping_RPContainer_Base CommMapping_dstCommMapping_RPContainer_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CommMapping_dstCommMapping_RPContainer_Base> CommMapping_dstCommMapping_RPContainer_Base::Instances() { return ::Udm::InstantiatedAttr< CommMapping_dstCommMapping_RPContainer_Base>(impl); }
	CommMapping_dstCommMapping_RPContainer_Base CommMapping_dstCommMapping_RPContainer_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CommMapping_dstCommMapping_RPContainer_Base> CommMapping_dstCommMapping_RPContainer_Base::Derived() { return ::Udm::DerivedAttr< CommMapping_dstCommMapping_RPContainer_Base>(impl); }
	::Udm::ArchetypeAttr< CommMapping_dstCommMapping_RPContainer_Base> CommMapping_dstCommMapping_RPContainer_Base::Archetype() const { return ::Udm::ArchetypeAttr< CommMapping_dstCommMapping_RPContainer_Base>(impl); }
	::Udm::AssocAttr< CommMapping> CommMapping_dstCommMapping_RPContainer_Base::dstCommMapping__rp_helper_rev() const { return ::Udm::AssocAttr< CommMapping>(impl, meta_dstCommMapping__rp_helper_rev); }
	::Udm::ParentAttr< ::ESMoL::System> CommMapping_dstCommMapping_RPContainer_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CommMapping_dstCommMapping_RPContainer_Base::meta;
	::Uml::AssociationRole CommMapping_dstCommMapping_RPContainer_Base::meta_dstCommMapping__rp_helper_rev;

	CommMapping_Members_Base::CommMapping_Members_Base() {}
	CommMapping_Members_Base::CommMapping_Members_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	CommMapping_Members_Base::CommMapping_Members_Base(const CommMapping_Members_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CommMapping_Members_Base::CommMapping_Members_Base(CommMapping_Members_Base &&master) : UDM_OBJECT(master) {};

	CommMapping_Members_Base CommMapping_Members_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CommMapping_Members_Base& CommMapping_Members_Base::operator=(CommMapping_Members_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CommMapping_Members_Base CommMapping_Members_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CommMapping_Members_Base CommMapping_Members_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CommMapping_Members_Base CommMapping_Members_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CommMapping_Members_Base> CommMapping_Members_Base::Instances() { return ::Udm::InstantiatedAttr< CommMapping_Members_Base>(impl); }
	CommMapping_Members_Base CommMapping_Members_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CommMapping_Members_Base> CommMapping_Members_Base::Derived() { return ::Udm::DerivedAttr< CommMapping_Members_Base>(impl); }
	::Udm::ArchetypeAttr< CommMapping_Members_Base> CommMapping_Members_Base::Archetype() const { return ::Udm::ArchetypeAttr< CommMapping_Members_Base>(impl); }
	::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base> CommMapping_Members_Base::dstCommMapping() const { return ::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base>(impl, meta_dstCommMapping, meta_dstCommMapping_rev); }
	::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base> CommMapping_Members_Base::srcCommMapping() const { return ::Udm::AClassAssocAttr< CommMapping, CommMapping_Members_Base>(impl, meta_srcCommMapping, meta_srcCommMapping_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> CommMapping_Members_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CommMapping_Members_Base::meta;
	::Uml::AssociationRole CommMapping_Members_Base::meta_dstCommMapping;
	::Uml::AssociationRole CommMapping_Members_Base::meta_dstCommMapping_rev;
	::Uml::AssociationRole CommMapping_Members_Base::meta_srcCommMapping;
	::Uml::AssociationRole CommMapping_Members_Base::meta_srcCommMapping_rev;

	ComponentRef_RefersTo_Base::ComponentRef_RefersTo_Base() {}
	ComponentRef_RefersTo_Base::ComponentRef_RefersTo_Base(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ComponentRef_RefersTo_Base::ComponentRef_RefersTo_Base(const ComponentRef_RefersTo_Base &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ComponentRef_RefersTo_Base::ComponentRef_RefersTo_Base(ComponentRef_RefersTo_Base &&master) : UDM_OBJECT(master) {};

	ComponentRef_RefersTo_Base ComponentRef_RefersTo_Base::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ComponentRef_RefersTo_Base& ComponentRef_RefersTo_Base::operator=(ComponentRef_RefersTo_Base &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ComponentRef_RefersTo_Base ComponentRef_RefersTo_Base::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ComponentRef_RefersTo_Base ComponentRef_RefersTo_Base::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ComponentRef_RefersTo_Base ComponentRef_RefersTo_Base::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ComponentRef_RefersTo_Base> ComponentRef_RefersTo_Base::Instances() { return ::Udm::InstantiatedAttr< ComponentRef_RefersTo_Base>(impl); }
	ComponentRef_RefersTo_Base ComponentRef_RefersTo_Base::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ComponentRef_RefersTo_Base> ComponentRef_RefersTo_Base::Derived() { return ::Udm::DerivedAttr< ComponentRef_RefersTo_Base>(impl); }
	::Udm::ArchetypeAttr< ComponentRef_RefersTo_Base> ComponentRef_RefersTo_Base::Archetype() const { return ::Udm::ArchetypeAttr< ComponentRef_RefersTo_Base>(impl); }
	::Udm::AssocAttr< ComponentRef> ComponentRef_RefersTo_Base::referedbyComponentRef() const { return ::Udm::AssocAttr< ComponentRef>(impl, meta_referedbyComponentRef); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> ComponentRef_RefersTo_Base::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ComponentRef_RefersTo_Base::meta;
	::Uml::AssociationRole ComponentRef_RefersTo_Base::meta_referedbyComponentRef;

	FaultScenario::FaultScenario() {}
	FaultScenario::FaultScenario(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultScenario::FaultScenario(const FaultScenario &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultScenario::FaultScenario(FaultScenario &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultScenario FaultScenario::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultScenario& FaultScenario::operator=(FaultScenario &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultScenario FaultScenario::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultScenario FaultScenario::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultScenario FaultScenario::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultScenario> FaultScenario::Instances() { return ::Udm::InstantiatedAttr< FaultScenario>(impl); }
	FaultScenario FaultScenario::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultScenario> FaultScenario::Derived() { return ::Udm::DerivedAttr< FaultScenario>(impl); }
	::Udm::ArchetypeAttr< FaultScenario> FaultScenario::Archetype() const { return ::Udm::ArchetypeAttr< FaultScenario>(impl); }
	::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo> FaultScenario::ScenarioInfo_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo>(impl, meta_ScenarioInfo_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultTrigger> FaultScenario::FaultTrigger_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultTrigger>(impl, meta_FaultTrigger_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultCondition> FaultScenario::FaultCondition_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultCondition>(impl, meta_FaultCondition_children); }
	::Udm::ChildrenAttr< ::ESMoL::TaskInst> FaultScenario::TaskInst_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TaskInst>(impl, meta_TaskInst_children); }
	::Udm::ChildrenAttr< ::ESMoL::Action> FaultScenario::Action_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Action>(impl, meta_Action_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask> FaultScenario::FaultMgrTask_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask>(impl, meta_FaultMgrTask_children); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentBase> FaultScenario::ComponentBase_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase>(impl, meta_ComponentBase_children); }
	::Udm::ChildrenAttr< ::ESMoL::CompBreakout> FaultScenario::CompBreakout_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CompBreakout>(impl, meta_CompBreakout_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultScenario::FaultModel_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel>(impl, meta_FaultModel_children); }
	::Udm::ChildrenAttr< ::ESMoL::DesignReference> FaultScenario::DesignReference_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DesignReference>(impl, meta_DesignReference_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput> FaultScenario::FaultToInput_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput>(impl, meta_FaultToInput_children); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault> FaultScenario::OutputToFault_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault>(impl, meta_OutputToFault_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModelRef> FaultScenario::FaultModelRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelRef>(impl, meta_FaultModelRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo> FaultScenario::ScenarioInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ScenarioInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultTrigger> FaultScenario::FaultTrigger_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultTrigger>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultCondition> FaultScenario::FaultCondition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultCondition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ConditionEvent> FaultScenario::ConditionEvent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ConditionEvent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Precondition> FaultScenario::Precondition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Precondition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Postcondition> FaultScenario::Postcondition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Postcondition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::DetectionCondition> FaultScenario::DetectionCondition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DetectionCondition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MitigationCondition> FaultScenario::MitigationCondition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MitigationCondition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TaskInst> FaultScenario::TaskInst_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TaskInst>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Action> FaultScenario::Action_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Action>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::DetectionAction> FaultScenario::DetectionAction_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DetectionAction>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MitigationAction> FaultScenario::MitigationAction_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MitigationAction>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask> FaultScenario::FaultMgrTask_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultMgrTask>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CompBreakout> FaultScenario::CompBreakout_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CompBreakout>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::DesignReference> FaultScenario::DesignReference_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DesignReference>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput> FaultScenario::FaultToInput_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault> FaultScenario::OutputToFault_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModelRef> FaultScenario::FaultModelRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultScenario::FaultModel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PetriNet> FaultScenario::PetriNet_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CCode> FaultScenario::CCode_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CCode>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::SubsystemRef> FaultScenario::SubsystemRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SubsystemRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PetriNetRef> FaultScenario::PetriNetRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNetRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentBase> FaultScenario::ComponentBase_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Subsystem> FaultScenario::Subsystem_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> FaultScenario::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> FaultScenario::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> FaultScenario::parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultScenario::meta;
	::Uml::CompositionChildRole FaultScenario::meta_ScenarioInfo_children;
	::Uml::CompositionChildRole FaultScenario::meta_FaultTrigger_children;
	::Uml::CompositionChildRole FaultScenario::meta_FaultCondition_children;
	::Uml::CompositionChildRole FaultScenario::meta_TaskInst_children;
	::Uml::CompositionChildRole FaultScenario::meta_Action_children;
	::Uml::CompositionChildRole FaultScenario::meta_FaultMgrTask_children;
	::Uml::CompositionChildRole FaultScenario::meta_ComponentBase_children;
	::Uml::CompositionChildRole FaultScenario::meta_CompBreakout_children;
	::Uml::CompositionChildRole FaultScenario::meta_FaultModel_children;
	::Uml::CompositionChildRole FaultScenario::meta_DesignReference_children;
	::Uml::CompositionChildRole FaultScenario::meta_FaultToInput_children;
	::Uml::CompositionChildRole FaultScenario::meta_OutputToFault_children;
	::Uml::CompositionChildRole FaultScenario::meta_FaultModelRef_children;
	::Uml::CompositionParentRole FaultScenario::meta_DesignFolder_parent;

	ScenarioInfo::ScenarioInfo() {}
	ScenarioInfo::ScenarioInfo(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ScenarioInfo::ScenarioInfo(const ScenarioInfo &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ScenarioInfo::ScenarioInfo(ScenarioInfo &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ScenarioInfo ScenarioInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ScenarioInfo& ScenarioInfo::operator=(ScenarioInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ScenarioInfo ScenarioInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ScenarioInfo ScenarioInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ScenarioInfo ScenarioInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ScenarioInfo> ScenarioInfo::Instances() { return ::Udm::InstantiatedAttr< ScenarioInfo>(impl); }
	ScenarioInfo ScenarioInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ScenarioInfo> ScenarioInfo::Derived() { return ::Udm::DerivedAttr< ScenarioInfo>(impl); }
	::Udm::ArchetypeAttr< ScenarioInfo> ScenarioInfo::Archetype() const { return ::Udm::ArchetypeAttr< ScenarioInfo>(impl); }
	::Udm::StringAttr ScenarioInfo::Requirements() const { return ::Udm::StringAttr(impl, meta_Requirements); }
	::Udm::StringAttr ScenarioInfo::ScenarioDescription() const { return ::Udm::StringAttr(impl, meta_ScenarioDescription); }
	::Udm::StringAttr ScenarioInfo::Criticality() const { return ::Udm::StringAttr(impl, meta_Criticality); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> ScenarioInfo::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> ScenarioInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ScenarioInfo::meta;
	::Uml::Attribute ScenarioInfo::meta_Requirements;
	::Uml::Attribute ScenarioInfo::meta_ScenarioDescription;
	::Uml::Attribute ScenarioInfo::meta_Criticality;
	::Uml::CompositionParentRole ScenarioInfo::meta_FaultScenario_parent;

	FaultEvent::FaultEvent() {}
	FaultEvent::FaultEvent(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultEvent::FaultEvent(const FaultEvent &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultEvent::FaultEvent(FaultEvent &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultEvent FaultEvent::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultEvent& FaultEvent::operator=(FaultEvent &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultEvent FaultEvent::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultEvent FaultEvent::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultEvent FaultEvent::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultEvent> FaultEvent::Instances() { return ::Udm::InstantiatedAttr< FaultEvent>(impl); }
	FaultEvent FaultEvent::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultEvent> FaultEvent::Derived() { return ::Udm::DerivedAttr< FaultEvent>(impl); }
	::Udm::ArchetypeAttr< FaultEvent> FaultEvent::Archetype() const { return ::Udm::ArchetypeAttr< FaultEvent>(impl); }
	::Udm::AssocAttr< FaultTrigger> FaultEvent::referedbyFaultTrigger() const { return ::Udm::AssocAttr< FaultTrigger>(impl, meta_referedbyFaultTrigger); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> FaultEvent::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultEvent::meta;
	::Uml::AssociationRole FaultEvent::meta_referedbyFaultTrigger;

	FaultTrigger::FaultTrigger() {}
	FaultTrigger::FaultTrigger(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultTrigger::FaultTrigger(const FaultTrigger &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultTrigger::FaultTrigger(FaultTrigger &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultTrigger FaultTrigger::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultTrigger& FaultTrigger::operator=(FaultTrigger &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultTrigger FaultTrigger::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultTrigger FaultTrigger::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultTrigger FaultTrigger::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultTrigger> FaultTrigger::Instances() { return ::Udm::InstantiatedAttr< FaultTrigger>(impl); }
	FaultTrigger FaultTrigger::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultTrigger> FaultTrigger::Derived() { return ::Udm::DerivedAttr< FaultTrigger>(impl); }
	::Udm::ArchetypeAttr< FaultTrigger> FaultTrigger::Archetype() const { return ::Udm::ArchetypeAttr< FaultTrigger>(impl); }
	::Udm::PointerAttr< FaultEvent> FaultTrigger::ref() const { return ::Udm::PointerAttr< FaultEvent>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultTrigger::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultTrigger::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultTrigger::meta;
	::Uml::AssociationRole FaultTrigger::meta_ref;
	::Uml::CompositionParentRole FaultTrigger::meta_FaultScenario_parent;

	FaultCondition::FaultCondition() {}
	FaultCondition::FaultCondition(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultCondition::FaultCondition(const FaultCondition &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultCondition::FaultCondition(FaultCondition &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultCondition FaultCondition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultCondition& FaultCondition::operator=(FaultCondition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultCondition FaultCondition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultCondition FaultCondition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultCondition FaultCondition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultCondition> FaultCondition::Instances() { return ::Udm::InstantiatedAttr< FaultCondition>(impl); }
	FaultCondition FaultCondition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultCondition> FaultCondition::Derived() { return ::Udm::DerivedAttr< FaultCondition>(impl); }
	::Udm::ArchetypeAttr< FaultCondition> FaultCondition::Archetype() const { return ::Udm::ArchetypeAttr< FaultCondition>(impl); }
	::Udm::StringAttr FaultCondition::Expression() const { return ::Udm::StringAttr(impl, meta_Expression); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultCondition::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultCondition::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultCondition::meta;
	::Uml::Attribute FaultCondition::meta_Expression;
	::Uml::CompositionParentRole FaultCondition::meta_FaultScenario_parent;

	ConditionEvent::ConditionEvent() {}
	ConditionEvent::ConditionEvent(::Udm::ObjectImpl *impl) : FaultEvent(impl),FaultCondition(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	ConditionEvent::ConditionEvent(const ConditionEvent &master) : FaultEvent(master),FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ConditionEvent::ConditionEvent(ConditionEvent &&master) : FaultEvent(master),FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {};

	ConditionEvent ConditionEvent::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ConditionEvent& ConditionEvent::operator=(ConditionEvent &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ConditionEvent ConditionEvent::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ConditionEvent ConditionEvent::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ConditionEvent ConditionEvent::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ConditionEvent> ConditionEvent::Instances() { return ::Udm::InstantiatedAttr< ConditionEvent>(impl); }
	ConditionEvent ConditionEvent::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ConditionEvent> ConditionEvent::Derived() { return ::Udm::DerivedAttr< ConditionEvent>(impl); }
	::Udm::ArchetypeAttr< ConditionEvent> ConditionEvent::Archetype() const { return ::Udm::ArchetypeAttr< ConditionEvent>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> ConditionEvent::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ConditionEvent::meta;

	Precondition::Precondition() {}
	Precondition::Precondition(::Udm::ObjectImpl *impl) : FaultCondition(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Precondition::Precondition(const Precondition &master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Precondition::Precondition(Precondition &&master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {};

	Precondition Precondition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Precondition& Precondition::operator=(Precondition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Precondition Precondition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Precondition Precondition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Precondition Precondition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Precondition> Precondition::Instances() { return ::Udm::InstantiatedAttr< Precondition>(impl); }
	Precondition Precondition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Precondition> Precondition::Derived() { return ::Udm::DerivedAttr< Precondition>(impl); }
	::Udm::ArchetypeAttr< Precondition> Precondition::Archetype() const { return ::Udm::ArchetypeAttr< Precondition>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> Precondition::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Precondition::meta;

	Postcondition::Postcondition() {}
	Postcondition::Postcondition(::Udm::ObjectImpl *impl) : FaultCondition(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Postcondition::Postcondition(const Postcondition &master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Postcondition::Postcondition(Postcondition &&master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {};

	Postcondition Postcondition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Postcondition& Postcondition::operator=(Postcondition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Postcondition Postcondition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Postcondition Postcondition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Postcondition Postcondition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Postcondition> Postcondition::Instances() { return ::Udm::InstantiatedAttr< Postcondition>(impl); }
	Postcondition Postcondition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Postcondition> Postcondition::Derived() { return ::Udm::DerivedAttr< Postcondition>(impl); }
	::Udm::ArchetypeAttr< Postcondition> Postcondition::Archetype() const { return ::Udm::ArchetypeAttr< Postcondition>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> Postcondition::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Postcondition::meta;

	DetectionCondition::DetectionCondition() {}
	DetectionCondition::DetectionCondition(::Udm::ObjectImpl *impl) : FaultCondition(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	DetectionCondition::DetectionCondition(const DetectionCondition &master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DetectionCondition::DetectionCondition(DetectionCondition &&master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {};

	DetectionCondition DetectionCondition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DetectionCondition& DetectionCondition::operator=(DetectionCondition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DetectionCondition DetectionCondition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DetectionCondition DetectionCondition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DetectionCondition DetectionCondition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DetectionCondition> DetectionCondition::Instances() { return ::Udm::InstantiatedAttr< DetectionCondition>(impl); }
	DetectionCondition DetectionCondition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DetectionCondition> DetectionCondition::Derived() { return ::Udm::DerivedAttr< DetectionCondition>(impl); }
	::Udm::ArchetypeAttr< DetectionCondition> DetectionCondition::Archetype() const { return ::Udm::ArchetypeAttr< DetectionCondition>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> DetectionCondition::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DetectionCondition::meta;

	MitigationCondition::MitigationCondition() {}
	MitigationCondition::MitigationCondition(::Udm::ObjectImpl *impl) : FaultCondition(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	MitigationCondition::MitigationCondition(const MitigationCondition &master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	MitigationCondition::MitigationCondition(MitigationCondition &&master) : FaultCondition(master), MgaObject(master), UDM_OBJECT(master) {};

	MitigationCondition MitigationCondition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	MitigationCondition& MitigationCondition::operator=(MitigationCondition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	MitigationCondition MitigationCondition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	MitigationCondition MitigationCondition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	MitigationCondition MitigationCondition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< MitigationCondition> MitigationCondition::Instances() { return ::Udm::InstantiatedAttr< MitigationCondition>(impl); }
	MitigationCondition MitigationCondition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< MitigationCondition> MitigationCondition::Derived() { return ::Udm::DerivedAttr< MitigationCondition>(impl); }
	::Udm::ArchetypeAttr< MitigationCondition> MitigationCondition::Archetype() const { return ::Udm::ArchetypeAttr< MitigationCondition>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> MitigationCondition::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class MitigationCondition::meta;

	TaskInst::TaskInst() {}
	TaskInst::TaskInst(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TaskInst::TaskInst(const TaskInst &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TaskInst::TaskInst(TaskInst &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TaskInst TaskInst::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TaskInst& TaskInst::operator=(TaskInst &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TaskInst TaskInst::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TaskInst TaskInst::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TaskInst TaskInst::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TaskInst> TaskInst::Instances() { return ::Udm::InstantiatedAttr< TaskInst>(impl); }
	TaskInst TaskInst::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TaskInst> TaskInst::Derived() { return ::Udm::DerivedAttr< TaskInst>(impl); }
	::Udm::ArchetypeAttr< TaskInst> TaskInst::Archetype() const { return ::Udm::ArchetypeAttr< TaskInst>(impl); }
	::Udm::PointerAttr< ComponentRef> TaskInst::ref() const { return ::Udm::PointerAttr< ComponentRef>(impl, meta_ref); }
	::Udm::AClassAssocAttr< CompBreakout, ComponentBase> TaskInst::srcCompBreakout() const { return ::Udm::AClassAssocAttr< CompBreakout, ComponentBase>(impl, meta_srcCompBreakout, meta_srcCompBreakout_rev); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> TaskInst::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> TaskInst::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TaskInst::meta;
	::Uml::AssociationRole TaskInst::meta_ref;
	::Uml::AssociationRole TaskInst::meta_srcCompBreakout;
	::Uml::AssociationRole TaskInst::meta_srcCompBreakout_rev;
	::Uml::CompositionParentRole TaskInst::meta_FaultScenario_parent;

	Action::Action() {}
	Action::Action(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Action::Action(const Action &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Action::Action(Action &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Action Action::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Action& Action::operator=(Action &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Action Action::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Action Action::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Action Action::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Action> Action::Instances() { return ::Udm::InstantiatedAttr< Action>(impl); }
	Action Action::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Action> Action::Derived() { return ::Udm::DerivedAttr< Action>(impl); }
	::Udm::ArchetypeAttr< Action> Action::Archetype() const { return ::Udm::ArchetypeAttr< Action>(impl); }
	::Udm::PointerAttr< ComponentRef> Action::ref() const { return ::Udm::PointerAttr< ComponentRef>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> Action::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> Action::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Action::meta;
	::Uml::AssociationRole Action::meta_ref;
	::Uml::CompositionParentRole Action::meta_FaultScenario_parent;

	DetectionAction::DetectionAction() {}
	DetectionAction::DetectionAction(::Udm::ObjectImpl *impl) : Action(impl), UDM_OBJECT(impl) {}
	DetectionAction::DetectionAction(const DetectionAction &master) : Action(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DetectionAction::DetectionAction(DetectionAction &&master) : Action(master), UDM_OBJECT(master) {};

	DetectionAction DetectionAction::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DetectionAction& DetectionAction::operator=(DetectionAction &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DetectionAction DetectionAction::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DetectionAction DetectionAction::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DetectionAction DetectionAction::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DetectionAction> DetectionAction::Instances() { return ::Udm::InstantiatedAttr< DetectionAction>(impl); }
	DetectionAction DetectionAction::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DetectionAction> DetectionAction::Derived() { return ::Udm::DerivedAttr< DetectionAction>(impl); }
	::Udm::ArchetypeAttr< DetectionAction> DetectionAction::Archetype() const { return ::Udm::ArchetypeAttr< DetectionAction>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> DetectionAction::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DetectionAction::meta;

	MitigationAction::MitigationAction() {}
	MitigationAction::MitigationAction(::Udm::ObjectImpl *impl) : Action(impl), UDM_OBJECT(impl) {}
	MitigationAction::MitigationAction(const MitigationAction &master) : Action(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	MitigationAction::MitigationAction(MitigationAction &&master) : Action(master), UDM_OBJECT(master) {};

	MitigationAction MitigationAction::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	MitigationAction& MitigationAction::operator=(MitigationAction &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	MitigationAction MitigationAction::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	MitigationAction MitigationAction::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	MitigationAction MitigationAction::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< MitigationAction> MitigationAction::Instances() { return ::Udm::InstantiatedAttr< MitigationAction>(impl); }
	MitigationAction MitigationAction::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< MitigationAction> MitigationAction::Derived() { return ::Udm::DerivedAttr< MitigationAction>(impl); }
	::Udm::ArchetypeAttr< MitigationAction> MitigationAction::Archetype() const { return ::Udm::ArchetypeAttr< MitigationAction>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> MitigationAction::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class MitigationAction::meta;

	FaultMgrTask::FaultMgrTask() {}
	FaultMgrTask::FaultMgrTask(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultMgrTask::FaultMgrTask(const FaultMgrTask &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultMgrTask::FaultMgrTask(FaultMgrTask &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultMgrTask FaultMgrTask::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultMgrTask& FaultMgrTask::operator=(FaultMgrTask &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultMgrTask FaultMgrTask::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultMgrTask FaultMgrTask::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultMgrTask FaultMgrTask::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultMgrTask> FaultMgrTask::Instances() { return ::Udm::InstantiatedAttr< FaultMgrTask>(impl); }
	FaultMgrTask FaultMgrTask::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultMgrTask> FaultMgrTask::Derived() { return ::Udm::DerivedAttr< FaultMgrTask>(impl); }
	::Udm::ArchetypeAttr< FaultMgrTask> FaultMgrTask::Archetype() const { return ::Udm::ArchetypeAttr< FaultMgrTask>(impl); }
	::Udm::PointerAttr< ComponentRef> FaultMgrTask::ref() const { return ::Udm::PointerAttr< ComponentRef>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultMgrTask::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultMgrTask::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultMgrTask::meta;
	::Uml::AssociationRole FaultMgrTask::meta_ref;
	::Uml::CompositionParentRole FaultMgrTask::meta_FaultScenario_parent;

	CompBreakout::CompBreakout() {}
	CompBreakout::CompBreakout(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	CompBreakout::CompBreakout(const CompBreakout &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CompBreakout::CompBreakout(CompBreakout &&master) : MgaObject(master), UDM_OBJECT(master) {};

	CompBreakout CompBreakout::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CompBreakout& CompBreakout::operator=(CompBreakout &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CompBreakout CompBreakout::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CompBreakout CompBreakout::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CompBreakout CompBreakout::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CompBreakout> CompBreakout::Instances() { return ::Udm::InstantiatedAttr< CompBreakout>(impl); }
	CompBreakout CompBreakout::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CompBreakout> CompBreakout::Derived() { return ::Udm::DerivedAttr< CompBreakout>(impl); }
	::Udm::ArchetypeAttr< CompBreakout> CompBreakout::Archetype() const { return ::Udm::ArchetypeAttr< CompBreakout>(impl); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> CompBreakout::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> CompBreakout::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::ComponentBase> CompBreakout::srcCompBreakout_end() const { return ::Udm::AssocEndAttr< ::ESMoL::ComponentBase>(impl, meta_srcCompBreakout_end_); }
	::Udm::AssocEndAttr< ::ESMoL::TaskInst> CompBreakout::dstCompBreakout_end() const { return ::Udm::AssocEndAttr< ::ESMoL::TaskInst>(impl, meta_dstCompBreakout_end_); }

	::Uml::Class CompBreakout::meta;
	::Uml::CompositionParentRole CompBreakout::meta_FaultScenario_parent;
	::Uml::AssociationRole CompBreakout::meta_srcCompBreakout_end_;
	::Uml::AssociationRole CompBreakout::meta_dstCompBreakout_end_;

	DesignReference::DesignReference() {}
	DesignReference::DesignReference(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	DesignReference::DesignReference(const DesignReference &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DesignReference::DesignReference(DesignReference &&master) : MgaObject(master), UDM_OBJECT(master) {};

	DesignReference DesignReference::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DesignReference& DesignReference::operator=(DesignReference &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DesignReference DesignReference::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DesignReference DesignReference::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DesignReference DesignReference::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DesignReference> DesignReference::Instances() { return ::Udm::InstantiatedAttr< DesignReference>(impl); }
	DesignReference DesignReference::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DesignReference> DesignReference::Derived() { return ::Udm::DerivedAttr< DesignReference>(impl); }
	::Udm::ArchetypeAttr< DesignReference> DesignReference::Archetype() const { return ::Udm::ArchetypeAttr< DesignReference>(impl); }
	::Udm::PointerAttr< System> DesignReference::ref() const { return ::Udm::PointerAttr< System>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> DesignReference::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> DesignReference::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DesignReference::meta;
	::Uml::AssociationRole DesignReference::meta_ref;
	::Uml::CompositionParentRole DesignReference::meta_FaultScenario_parent;

	FaultToInput::FaultToInput() {}
	FaultToInput::FaultToInput(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultToInput::FaultToInput(const FaultToInput &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultToInput::FaultToInput(FaultToInput &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultToInput FaultToInput::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultToInput& FaultToInput::operator=(FaultToInput &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultToInput FaultToInput::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultToInput FaultToInput::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultToInput FaultToInput::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultToInput> FaultToInput::Instances() { return ::Udm::InstantiatedAttr< FaultToInput>(impl); }
	FaultToInput FaultToInput::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultToInput> FaultToInput::Derived() { return ::Udm::DerivedAttr< FaultToInput>(impl); }
	::Udm::ArchetypeAttr< FaultToInput> FaultToInput::Archetype() const { return ::Udm::ArchetypeAttr< FaultToInput>(impl); }
	::Udm::StringAttr FaultToInput::VectorIndex() const { return ::Udm::StringAttr(impl, meta_VectorIndex); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultToInput::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultToInput::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput::srcFaultToInput_end() const { return ::Udm::AssocEndAttr< ::ESMoL::FaultToInput_Members_Base>(impl, meta_srcFaultToInput_end_); }
	::Udm::AssocEndAttr< ::ESMoL::FaultToInput_Members_Base> FaultToInput::dstFaultToInput_end() const { return ::Udm::AssocEndAttr< ::ESMoL::FaultToInput_Members_Base>(impl, meta_dstFaultToInput_end_); }

	::Uml::Class FaultToInput::meta;
	::Uml::Attribute FaultToInput::meta_VectorIndex;
	::Uml::CompositionParentRole FaultToInput::meta_FaultScenario_parent;
	::Uml::AssociationRole FaultToInput::meta_srcFaultToInput_end_;
	::Uml::AssociationRole FaultToInput::meta_dstFaultToInput_end_;

	OutputToFault::OutputToFault() {}
	OutputToFault::OutputToFault(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	OutputToFault::OutputToFault(const OutputToFault &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OutputToFault::OutputToFault(OutputToFault &&master) : MgaObject(master), UDM_OBJECT(master) {};

	OutputToFault OutputToFault::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutputToFault& OutputToFault::operator=(OutputToFault &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutputToFault OutputToFault::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutputToFault OutputToFault::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutputToFault OutputToFault::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutputToFault> OutputToFault::Instances() { return ::Udm::InstantiatedAttr< OutputToFault>(impl); }
	OutputToFault OutputToFault::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutputToFault> OutputToFault::Derived() { return ::Udm::DerivedAttr< OutputToFault>(impl); }
	::Udm::ArchetypeAttr< OutputToFault> OutputToFault::Archetype() const { return ::Udm::ArchetypeAttr< OutputToFault>(impl); }
	::Udm::StringAttr OutputToFault::VectorIndex() const { return ::Udm::StringAttr(impl, meta_VectorIndex); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> OutputToFault::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> OutputToFault::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault::srcOutputToFault_end() const { return ::Udm::AssocEndAttr< ::ESMoL::OutputToFault_Members_Base>(impl, meta_srcOutputToFault_end_); }
	::Udm::AssocEndAttr< ::ESMoL::OutputToFault_Members_Base> OutputToFault::dstOutputToFault_end() const { return ::Udm::AssocEndAttr< ::ESMoL::OutputToFault_Members_Base>(impl, meta_dstOutputToFault_end_); }

	::Uml::Class OutputToFault::meta;
	::Uml::Attribute OutputToFault::meta_VectorIndex;
	::Uml::CompositionParentRole OutputToFault::meta_FaultScenario_parent;
	::Uml::AssociationRole OutputToFault::meta_srcOutputToFault_end_;
	::Uml::AssociationRole OutputToFault::meta_dstOutputToFault_end_;

	FaultModelRef::FaultModelRef() {}
	FaultModelRef::FaultModelRef(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultModelRef::FaultModelRef(const FaultModelRef &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultModelRef::FaultModelRef(FaultModelRef &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultModelRef FaultModelRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultModelRef& FaultModelRef::operator=(FaultModelRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultModelRef FaultModelRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultModelRef FaultModelRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultModelRef FaultModelRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultModelRef> FaultModelRef::Instances() { return ::Udm::InstantiatedAttr< FaultModelRef>(impl); }
	FaultModelRef FaultModelRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultModelRef> FaultModelRef::Derived() { return ::Udm::DerivedAttr< FaultModelRef>(impl); }
	::Udm::ArchetypeAttr< FaultModelRef> FaultModelRef::Archetype() const { return ::Udm::ArchetypeAttr< FaultModelRef>(impl); }
	::Udm::PointerAttr< FaultModel> FaultModelRef::ref() const { return ::Udm::PointerAttr< FaultModel>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultModelRef::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultModelRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultModelRef::meta;
	::Uml::AssociationRole FaultModelRef::meta_ref;
	::Uml::CompositionParentRole FaultModelRef::meta_FaultScenario_parent;

	FaultModel::FaultModel() {}
	FaultModel::FaultModel(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FaultModel::FaultModel(const FaultModel &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultModel::FaultModel(FaultModel &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FaultModel FaultModel::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultModel& FaultModel::operator=(FaultModel &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultModel FaultModel::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultModel FaultModel::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultModel FaultModel::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultModel> FaultModel::Instances() { return ::Udm::InstantiatedAttr< FaultModel>(impl); }
	FaultModel FaultModel::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultModel> FaultModel::Derived() { return ::Udm::DerivedAttr< FaultModel>(impl); }
	::Udm::ArchetypeAttr< FaultModel> FaultModel::Archetype() const { return ::Udm::ArchetypeAttr< FaultModel>(impl); }
	::Udm::AssocAttr< FaultModelRef> FaultModel::referedbyFaultModelRef() const { return ::Udm::AssocAttr< FaultModelRef>(impl, meta_referedbyFaultModelRef); }
	::Udm::ChildrenAttr< ::ESMoL::Variable> FaultModel::Variable_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Variable>(impl, meta_Variable_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> FaultModel::FaultToInput_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> FaultModel::OutputToFault_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Variable> FaultModel::Variable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Variable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> FaultModel::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> FaultModel::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultModelFolder> FaultModel::FaultModelFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultModelFolder>(impl, meta_FaultModelFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> FaultModel::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::Udm::Object> FaultModel::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultModel::meta;
	::Uml::AssociationRole FaultModel::meta_referedbyFaultModelRef;
	::Uml::CompositionChildRole FaultModel::meta_Variable_children;
	::Uml::CompositionParentRole FaultModel::meta_FaultScenario_parent;
	::Uml::CompositionParentRole FaultModel::meta_FaultModelFolder_parent;
	::Uml::CompositionParentRole FaultModel::meta_DesignFolder_parent;

	Additive::Additive() {}
	Additive::Additive(::Udm::ObjectImpl *impl) : Incorporation(impl), UDM_OBJECT(impl) {}
	Additive::Additive(const Additive &master) : Incorporation(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Additive::Additive(Additive &&master) : Incorporation(master), UDM_OBJECT(master) {};

	Additive Additive::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Additive& Additive::operator=(Additive &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Additive Additive::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Additive Additive::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Additive Additive::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Additive> Additive::Instances() { return ::Udm::InstantiatedAttr< Additive>(impl); }
	Additive Additive::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Additive> Additive::Derived() { return ::Udm::DerivedAttr< Additive>(impl); }
	::Udm::ArchetypeAttr< Additive> Additive::Archetype() const { return ::Udm::ArchetypeAttr< Additive>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Additive::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Additive::meta;

	Substitutive::Substitutive() {}
	Substitutive::Substitutive(::Udm::ObjectImpl *impl) : Incorporation(impl), UDM_OBJECT(impl) {}
	Substitutive::Substitutive(const Substitutive &master) : Incorporation(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Substitutive::Substitutive(Substitutive &&master) : Incorporation(master), UDM_OBJECT(master) {};

	Substitutive Substitutive::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Substitutive& Substitutive::operator=(Substitutive &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Substitutive Substitutive::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Substitutive Substitutive::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Substitutive Substitutive::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Substitutive> Substitutive::Instances() { return ::Udm::InstantiatedAttr< Substitutive>(impl); }
	Substitutive Substitutive::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Substitutive> Substitutive::Derived() { return ::Udm::DerivedAttr< Substitutive>(impl); }
	::Udm::ArchetypeAttr< Substitutive> Substitutive::Archetype() const { return ::Udm::ArchetypeAttr< Substitutive>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Substitutive::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Substitutive::meta;

	Incorporation::Incorporation() {}
	Incorporation::Incorporation(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Incorporation::Incorporation(const Incorporation &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Incorporation::Incorporation(Incorporation &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Incorporation Incorporation::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Incorporation& Incorporation::operator=(Incorporation &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Incorporation Incorporation::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Incorporation Incorporation::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Incorporation Incorporation::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Incorporation> Incorporation::Instances() { return ::Udm::InstantiatedAttr< Incorporation>(impl); }
	Incorporation Incorporation::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Incorporation> Incorporation::Derived() { return ::Udm::DerivedAttr< Incorporation>(impl); }
	::Udm::ArchetypeAttr< Incorporation> Incorporation::Archetype() const { return ::Udm::ArchetypeAttr< Incorporation>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Incorporation::Variable_parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, meta_Variable_parent); }
	::Udm::ParentAttr< ::ESMoL::Variable> Incorporation::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Incorporation::meta;
	::Uml::CompositionParentRole Incorporation::meta_Variable_parent;

	Occurrence::Occurrence() {}
	Occurrence::Occurrence(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Occurrence::Occurrence(const Occurrence &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Occurrence::Occurrence(Occurrence &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Occurrence Occurrence::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Occurrence& Occurrence::operator=(Occurrence &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Occurrence Occurrence::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Occurrence Occurrence::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Occurrence Occurrence::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Occurrence> Occurrence::Instances() { return ::Udm::InstantiatedAttr< Occurrence>(impl); }
	Occurrence Occurrence::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Occurrence> Occurrence::Derived() { return ::Udm::DerivedAttr< Occurrence>(impl); }
	::Udm::ArchetypeAttr< Occurrence> Occurrence::Archetype() const { return ::Udm::ArchetypeAttr< Occurrence>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Occurrence::Variable_parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, meta_Variable_parent); }
	::Udm::ParentAttr< ::ESMoL::Variable> Occurrence::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Occurrence::meta;
	::Uml::CompositionParentRole Occurrence::meta_Variable_parent;

	Continuous::Continuous() {}
	Continuous::Continuous(::Udm::ObjectImpl *impl) : Occurrence(impl), UDM_OBJECT(impl) {}
	Continuous::Continuous(const Continuous &master) : Occurrence(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Continuous::Continuous(Continuous &&master) : Occurrence(master), UDM_OBJECT(master) {};

	Continuous Continuous::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Continuous& Continuous::operator=(Continuous &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Continuous Continuous::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Continuous Continuous::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Continuous Continuous::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Continuous> Continuous::Instances() { return ::Udm::InstantiatedAttr< Continuous>(impl); }
	Continuous Continuous::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Continuous> Continuous::Derived() { return ::Udm::DerivedAttr< Continuous>(impl); }
	::Udm::ArchetypeAttr< Continuous> Continuous::Archetype() const { return ::Udm::ArchetypeAttr< Continuous>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Continuous::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Continuous::meta;

	Periodic::Periodic() {}
	Periodic::Periodic(::Udm::ObjectImpl *impl) : Occurrence(impl), UDM_OBJECT(impl) {}
	Periodic::Periodic(const Periodic &master) : Occurrence(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Periodic::Periodic(Periodic &&master) : Occurrence(master), UDM_OBJECT(master) {};

	Periodic Periodic::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Periodic& Periodic::operator=(Periodic &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Periodic Periodic::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Periodic Periodic::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Periodic Periodic::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Periodic> Periodic::Instances() { return ::Udm::InstantiatedAttr< Periodic>(impl); }
	Periodic Periodic::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Periodic> Periodic::Derived() { return ::Udm::DerivedAttr< Periodic>(impl); }
	::Udm::ArchetypeAttr< Periodic> Periodic::Archetype() const { return ::Udm::ArchetypeAttr< Periodic>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Periodic::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Periodic::meta;

	Intermittent::Intermittent() {}
	Intermittent::Intermittent(::Udm::ObjectImpl *impl) : Occurrence(impl), UDM_OBJECT(impl) {}
	Intermittent::Intermittent(const Intermittent &master) : Occurrence(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Intermittent::Intermittent(Intermittent &&master) : Occurrence(master), UDM_OBJECT(master) {};

	Intermittent Intermittent::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Intermittent& Intermittent::operator=(Intermittent &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Intermittent Intermittent::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Intermittent Intermittent::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Intermittent Intermittent::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Intermittent> Intermittent::Instances() { return ::Udm::InstantiatedAttr< Intermittent>(impl); }
	Intermittent Intermittent::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Intermittent> Intermittent::Derived() { return ::Udm::DerivedAttr< Intermittent>(impl); }
	::Udm::ArchetypeAttr< Intermittent> Intermittent::Archetype() const { return ::Udm::ArchetypeAttr< Intermittent>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Intermittent::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Intermittent::meta;

	Multiplicative::Multiplicative() {}
	Multiplicative::Multiplicative(::Udm::ObjectImpl *impl) : Incorporation(impl), UDM_OBJECT(impl) {}
	Multiplicative::Multiplicative(const Multiplicative &master) : Incorporation(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Multiplicative::Multiplicative(Multiplicative &&master) : Incorporation(master), UDM_OBJECT(master) {};

	Multiplicative Multiplicative::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Multiplicative& Multiplicative::operator=(Multiplicative &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Multiplicative Multiplicative::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Multiplicative Multiplicative::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Multiplicative Multiplicative::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Multiplicative> Multiplicative::Instances() { return ::Udm::InstantiatedAttr< Multiplicative>(impl); }
	Multiplicative Multiplicative::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Multiplicative> Multiplicative::Derived() { return ::Udm::DerivedAttr< Multiplicative>(impl); }
	::Udm::ArchetypeAttr< Multiplicative> Multiplicative::Archetype() const { return ::Udm::ArchetypeAttr< Multiplicative>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Multiplicative::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Multiplicative::meta;

	Variable::Variable() {}
	Variable::Variable(::Udm::ObjectImpl *impl) : FaultToInput_Members_Base(impl),OutputToFault_Members_Base(impl),MgaObject(impl), UDM_OBJECT(impl) {}
	Variable::Variable(const Variable &master) : FaultToInput_Members_Base(master),OutputToFault_Members_Base(master),MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Variable::Variable(Variable &&master) : FaultToInput_Members_Base(master),OutputToFault_Members_Base(master),MgaObject(master), UDM_OBJECT(master) {};

	Variable Variable::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Variable& Variable::operator=(Variable &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Variable Variable::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Variable Variable::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Variable Variable::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Variable> Variable::Instances() { return ::Udm::InstantiatedAttr< Variable>(impl); }
	Variable Variable::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Variable> Variable::Derived() { return ::Udm::DerivedAttr< Variable>(impl); }
	::Udm::ArchetypeAttr< Variable> Variable::Archetype() const { return ::Udm::ArchetypeAttr< Variable>(impl); }
	::Udm::ChildrenAttr< ::ESMoL::Occurrence> Variable::Occurrence_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Occurrence>(impl, meta_Occurrence_children); }
	::Udm::ChildrenAttr< ::ESMoL::Incorporation> Variable::Incorporation_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Incorporation>(impl, meta_Incorporation_children); }
	::Udm::ChildrenAttr< ::ESMoL::ValueObject> Variable::ValueObject_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ValueObject>(impl, meta_ValueObject_children); }
	::Udm::ChildrenAttr< ::ESMoL::Additive> Variable::Additive_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Additive>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Substitutive> Variable::Substitutive_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Substitutive>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Incorporation> Variable::Incorporation_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Incorporation>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Occurrence> Variable::Occurrence_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Occurrence>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Continuous> Variable::Continuous_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Continuous>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Periodic> Variable::Periodic_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Periodic>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Intermittent> Variable::Intermittent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Intermittent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Multiplicative> Variable::Multiplicative_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Multiplicative>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::RandomDistribution> Variable::RandomDistribution_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::RandomDistribution>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Constant> Variable::Constant_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Constant>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Uniform> Variable::Uniform_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Uniform>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Normal> Variable::Normal_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Normal>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Exponential> Variable::Exponential_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Exponential>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Step> Variable::Step_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Step>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Pulse> Variable::Pulse_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Pulse>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ValueObject> Variable::ValueObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ValueObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Functions> Variable::Functions_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Functions>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Sinusoid> Variable::Sinusoid_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Sinusoid>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Variable::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::FaultModel> Variable::FaultModel_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultModel>(impl, meta_FaultModel_parent); }
	::Udm::ParentAttr< ::ESMoL::FaultModel> Variable::parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultModel>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Variable::meta;
	::Uml::CompositionChildRole Variable::meta_Occurrence_children;
	::Uml::CompositionChildRole Variable::meta_Incorporation_children;
	::Uml::CompositionChildRole Variable::meta_ValueObject_children;
	::Uml::CompositionParentRole Variable::meta_FaultModel_parent;

	FaultModelFolder::FaultModelFolder() {}
	FaultModelFolder::FaultModelFolder(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	FaultModelFolder::FaultModelFolder(const FaultModelFolder &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FaultModelFolder::FaultModelFolder(FaultModelFolder &&master) : UDM_OBJECT(master) {};

	FaultModelFolder FaultModelFolder::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FaultModelFolder& FaultModelFolder::operator=(FaultModelFolder &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FaultModelFolder FaultModelFolder::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FaultModelFolder FaultModelFolder::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FaultModelFolder FaultModelFolder::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FaultModelFolder> FaultModelFolder::Instances() { return ::Udm::InstantiatedAttr< FaultModelFolder>(impl); }
	FaultModelFolder FaultModelFolder::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FaultModelFolder> FaultModelFolder::Derived() { return ::Udm::DerivedAttr< FaultModelFolder>(impl); }
	::Udm::ArchetypeAttr< FaultModelFolder> FaultModelFolder::Archetype() const { return ::Udm::ArchetypeAttr< FaultModelFolder>(impl); }
	::Udm::StringAttr FaultModelFolder::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModelFolder::FaultModel_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel>(impl, meta_FaultModel_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModel> FaultModelFolder::FaultModel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> FaultModelFolder::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> FaultModelFolder::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> FaultModelFolder::parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FaultModelFolder::meta;
	::Uml::Attribute FaultModelFolder::meta_name;
	::Uml::CompositionChildRole FaultModelFolder::meta_FaultModel_children;
	::Uml::CompositionParentRole FaultModelFolder::meta_DesignFolder_parent;

	RandomDistribution::RandomDistribution() {}
	RandomDistribution::RandomDistribution(::Udm::ObjectImpl *impl) : ValueObject(impl), UDM_OBJECT(impl) {}
	RandomDistribution::RandomDistribution(const RandomDistribution &master) : ValueObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	RandomDistribution::RandomDistribution(RandomDistribution &&master) : ValueObject(master), UDM_OBJECT(master) {};

	RandomDistribution RandomDistribution::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	RandomDistribution& RandomDistribution::operator=(RandomDistribution &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	RandomDistribution RandomDistribution::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	RandomDistribution RandomDistribution::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	RandomDistribution RandomDistribution::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< RandomDistribution> RandomDistribution::Instances() { return ::Udm::InstantiatedAttr< RandomDistribution>(impl); }
	RandomDistribution RandomDistribution::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< RandomDistribution> RandomDistribution::Derived() { return ::Udm::DerivedAttr< RandomDistribution>(impl); }
	::Udm::ArchetypeAttr< RandomDistribution> RandomDistribution::Archetype() const { return ::Udm::ArchetypeAttr< RandomDistribution>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> RandomDistribution::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class RandomDistribution::meta;

	Constant::Constant() {}
	Constant::Constant(::Udm::ObjectImpl *impl) : ValueObject(impl), UDM_OBJECT(impl) {}
	Constant::Constant(const Constant &master) : ValueObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Constant::Constant(Constant &&master) : ValueObject(master), UDM_OBJECT(master) {};

	Constant Constant::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Constant& Constant::operator=(Constant &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Constant Constant::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Constant Constant::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Constant Constant::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Constant> Constant::Instances() { return ::Udm::InstantiatedAttr< Constant>(impl); }
	Constant Constant::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Constant> Constant::Derived() { return ::Udm::DerivedAttr< Constant>(impl); }
	::Udm::ArchetypeAttr< Constant> Constant::Archetype() const { return ::Udm::ArchetypeAttr< Constant>(impl); }
	::Udm::StringAttr Constant::Value() const { return ::Udm::StringAttr(impl, meta_Value); }
	::Udm::ParentAttr< ::ESMoL::Variable> Constant::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Constant::meta;
	::Uml::Attribute Constant::meta_Value;

	Interval::Interval() {}
	Interval::Interval(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Interval::Interval(const Interval &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Interval::Interval(Interval &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Interval Interval::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Interval& Interval::operator=(Interval &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Interval Interval::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Interval Interval::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Interval Interval::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Interval> Interval::Instances() { return ::Udm::InstantiatedAttr< Interval>(impl); }
	Interval Interval::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Interval> Interval::Derived() { return ::Udm::DerivedAttr< Interval>(impl); }
	::Udm::ArchetypeAttr< Interval> Interval::Archetype() const { return ::Udm::ArchetypeAttr< Interval>(impl); }
	::Udm::StringAttr Interval::Range() const { return ::Udm::StringAttr(impl, meta_Range); }
	::Udm::ParentAttr< ::Udm::Object> Interval::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Interval::meta;
	::Uml::Attribute Interval::meta_Range;

	Uniform::Uniform() {}
	Uniform::Uniform(::Udm::ObjectImpl *impl) : RandomDistribution(impl), UDM_OBJECT(impl) {}
	Uniform::Uniform(const Uniform &master) : RandomDistribution(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Uniform::Uniform(Uniform &&master) : RandomDistribution(master), UDM_OBJECT(master) {};

	Uniform Uniform::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Uniform& Uniform::operator=(Uniform &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Uniform Uniform::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Uniform Uniform::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Uniform Uniform::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Uniform> Uniform::Instances() { return ::Udm::InstantiatedAttr< Uniform>(impl); }
	Uniform Uniform::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Uniform> Uniform::Derived() { return ::Udm::DerivedAttr< Uniform>(impl); }
	::Udm::ArchetypeAttr< Uniform> Uniform::Archetype() const { return ::Udm::ArchetypeAttr< Uniform>(impl); }
	::Udm::StringAttr Uniform::LowerBound() const { return ::Udm::StringAttr(impl, meta_LowerBound); }
	::Udm::StringAttr Uniform::UpperBound() const { return ::Udm::StringAttr(impl, meta_UpperBound); }
	::Udm::ParentAttr< ::ESMoL::Variable> Uniform::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Uniform::meta;
	::Uml::Attribute Uniform::meta_LowerBound;
	::Uml::Attribute Uniform::meta_UpperBound;

	Normal::Normal() {}
	Normal::Normal(::Udm::ObjectImpl *impl) : RandomDistribution(impl), UDM_OBJECT(impl) {}
	Normal::Normal(const Normal &master) : RandomDistribution(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Normal::Normal(Normal &&master) : RandomDistribution(master), UDM_OBJECT(master) {};

	Normal Normal::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Normal& Normal::operator=(Normal &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Normal Normal::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Normal Normal::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Normal Normal::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Normal> Normal::Instances() { return ::Udm::InstantiatedAttr< Normal>(impl); }
	Normal Normal::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Normal> Normal::Derived() { return ::Udm::DerivedAttr< Normal>(impl); }
	::Udm::ArchetypeAttr< Normal> Normal::Archetype() const { return ::Udm::ArchetypeAttr< Normal>(impl); }
	::Udm::StringAttr Normal::Mean() const { return ::Udm::StringAttr(impl, meta_Mean); }
	::Udm::StringAttr Normal::StdDev() const { return ::Udm::StringAttr(impl, meta_StdDev); }
	::Udm::ParentAttr< ::ESMoL::Variable> Normal::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Normal::meta;
	::Uml::Attribute Normal::meta_Mean;
	::Uml::Attribute Normal::meta_StdDev;

	Exponential::Exponential() {}
	Exponential::Exponential(::Udm::ObjectImpl *impl) : RandomDistribution(impl), UDM_OBJECT(impl) {}
	Exponential::Exponential(const Exponential &master) : RandomDistribution(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Exponential::Exponential(Exponential &&master) : RandomDistribution(master), UDM_OBJECT(master) {};

	Exponential Exponential::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Exponential& Exponential::operator=(Exponential &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Exponential Exponential::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Exponential Exponential::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Exponential Exponential::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Exponential> Exponential::Instances() { return ::Udm::InstantiatedAttr< Exponential>(impl); }
	Exponential Exponential::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Exponential> Exponential::Derived() { return ::Udm::DerivedAttr< Exponential>(impl); }
	::Udm::ArchetypeAttr< Exponential> Exponential::Archetype() const { return ::Udm::ArchetypeAttr< Exponential>(impl); }
	::Udm::StringAttr Exponential::Rate() const { return ::Udm::StringAttr(impl, meta_Rate); }
	::Udm::ParentAttr< ::ESMoL::Variable> Exponential::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Exponential::meta;
	::Uml::Attribute Exponential::meta_Rate;

	Step::Step() {}
	Step::Step(::Udm::ObjectImpl *impl) : Functions(impl), UDM_OBJECT(impl) {}
	Step::Step(const Step &master) : Functions(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Step::Step(Step &&master) : Functions(master), UDM_OBJECT(master) {};

	Step Step::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Step& Step::operator=(Step &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Step Step::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Step Step::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Step Step::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Step> Step::Instances() { return ::Udm::InstantiatedAttr< Step>(impl); }
	Step Step::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Step> Step::Derived() { return ::Udm::DerivedAttr< Step>(impl); }
	::Udm::ArchetypeAttr< Step> Step::Archetype() const { return ::Udm::ArchetypeAttr< Step>(impl); }
	::Udm::StringAttr Step::Shift() const { return ::Udm::StringAttr(impl, meta_Shift); }
	::Udm::ParentAttr< ::ESMoL::Variable> Step::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Step::meta;
	::Uml::Attribute Step::meta_Shift;

	Pulse::Pulse() {}
	Pulse::Pulse(::Udm::ObjectImpl *impl) : Functions(impl), UDM_OBJECT(impl) {}
	Pulse::Pulse(const Pulse &master) : Functions(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Pulse::Pulse(Pulse &&master) : Functions(master), UDM_OBJECT(master) {};

	Pulse Pulse::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Pulse& Pulse::operator=(Pulse &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Pulse Pulse::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Pulse Pulse::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Pulse Pulse::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Pulse> Pulse::Instances() { return ::Udm::InstantiatedAttr< Pulse>(impl); }
	Pulse Pulse::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Pulse> Pulse::Derived() { return ::Udm::DerivedAttr< Pulse>(impl); }
	::Udm::ArchetypeAttr< Pulse> Pulse::Archetype() const { return ::Udm::ArchetypeAttr< Pulse>(impl); }
	::Udm::StringAttr Pulse::Shift() const { return ::Udm::StringAttr(impl, meta_Shift); }
	::Udm::StringAttr Pulse::Duration() const { return ::Udm::StringAttr(impl, meta_Duration); }
	::Udm::ParentAttr< ::ESMoL::Variable> Pulse::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Pulse::meta;
	::Uml::Attribute Pulse::meta_Shift;
	::Uml::Attribute Pulse::meta_Duration;

	ValueObject::ValueObject() {}
	ValueObject::ValueObject(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ValueObject::ValueObject(const ValueObject &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ValueObject::ValueObject(ValueObject &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ValueObject ValueObject::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ValueObject& ValueObject::operator=(ValueObject &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ValueObject ValueObject::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ValueObject ValueObject::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ValueObject ValueObject::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ValueObject> ValueObject::Instances() { return ::Udm::InstantiatedAttr< ValueObject>(impl); }
	ValueObject ValueObject::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ValueObject> ValueObject::Derived() { return ::Udm::DerivedAttr< ValueObject>(impl); }
	::Udm::ArchetypeAttr< ValueObject> ValueObject::Archetype() const { return ::Udm::ArchetypeAttr< ValueObject>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> ValueObject::Variable_parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, meta_Variable_parent); }
	::Udm::ParentAttr< ::ESMoL::Variable> ValueObject::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ValueObject::meta;
	::Uml::CompositionParentRole ValueObject::meta_Variable_parent;

	Functions::Functions() {}
	Functions::Functions(::Udm::ObjectImpl *impl) : ValueObject(impl), UDM_OBJECT(impl) {}
	Functions::Functions(const Functions &master) : ValueObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Functions::Functions(Functions &&master) : ValueObject(master), UDM_OBJECT(master) {};

	Functions Functions::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Functions& Functions::operator=(Functions &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Functions Functions::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Functions Functions::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Functions Functions::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Functions> Functions::Instances() { return ::Udm::InstantiatedAttr< Functions>(impl); }
	Functions Functions::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Functions> Functions::Derived() { return ::Udm::DerivedAttr< Functions>(impl); }
	::Udm::ArchetypeAttr< Functions> Functions::Archetype() const { return ::Udm::ArchetypeAttr< Functions>(impl); }
	::Udm::ParentAttr< ::ESMoL::Variable> Functions::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Functions::meta;

	Sinusoid::Sinusoid() {}
	Sinusoid::Sinusoid(::Udm::ObjectImpl *impl) : Functions(impl), UDM_OBJECT(impl) {}
	Sinusoid::Sinusoid(const Sinusoid &master) : Functions(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Sinusoid::Sinusoid(Sinusoid &&master) : Functions(master), UDM_OBJECT(master) {};

	Sinusoid Sinusoid::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Sinusoid& Sinusoid::operator=(Sinusoid &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Sinusoid Sinusoid::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Sinusoid Sinusoid::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Sinusoid Sinusoid::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Sinusoid> Sinusoid::Instances() { return ::Udm::InstantiatedAttr< Sinusoid>(impl); }
	Sinusoid Sinusoid::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Sinusoid> Sinusoid::Derived() { return ::Udm::DerivedAttr< Sinusoid>(impl); }
	::Udm::ArchetypeAttr< Sinusoid> Sinusoid::Archetype() const { return ::Udm::ArchetypeAttr< Sinusoid>(impl); }
	::Udm::StringAttr Sinusoid::Frequency() const { return ::Udm::StringAttr(impl, meta_Frequency); }
	::Udm::StringAttr Sinusoid::Phase() const { return ::Udm::StringAttr(impl, meta_Phase); }
	::Udm::ParentAttr< ::ESMoL::Variable> Sinusoid::parent() const { return ::Udm::ParentAttr< ::ESMoL::Variable>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Sinusoid::meta;
	::Uml::Attribute Sinusoid::meta_Frequency;
	::Uml::Attribute Sinusoid::meta_Phase;

	TransitionToState::TransitionToState() {}
	TransitionToState::TransitionToState(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TransitionToState::TransitionToState(const TransitionToState &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TransitionToState::TransitionToState(TransitionToState &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TransitionToState TransitionToState::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TransitionToState& TransitionToState::operator=(TransitionToState &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TransitionToState TransitionToState::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TransitionToState TransitionToState::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TransitionToState TransitionToState::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TransitionToState> TransitionToState::Instances() { return ::Udm::InstantiatedAttr< TransitionToState>(impl); }
	TransitionToState TransitionToState::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TransitionToState> TransitionToState::Derived() { return ::Udm::DerivedAttr< TransitionToState>(impl); }
	::Udm::ArchetypeAttr< TransitionToState> TransitionToState::Archetype() const { return ::Udm::ArchetypeAttr< TransitionToState>(impl); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> TransitionToState::PetriNet_parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_parent); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> TransitionToState::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::PNTransition> TransitionToState::srcTransitionToState_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PNTransition>(impl, meta_srcTransitionToState_end_); }
	::Udm::AssocEndAttr< ::ESMoL::PNState> TransitionToState::dstTransitionToState_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PNState>(impl, meta_dstTransitionToState_end_); }

	::Uml::Class TransitionToState::meta;
	::Uml::CompositionParentRole TransitionToState::meta_PetriNet_parent;
	::Uml::AssociationRole TransitionToState::meta_srcTransitionToState_end_;
	::Uml::AssociationRole TransitionToState::meta_dstTransitionToState_end_;

	StateToTransition::StateToTransition() {}
	StateToTransition::StateToTransition(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	StateToTransition::StateToTransition(const StateToTransition &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StateToTransition::StateToTransition(StateToTransition &&master) : MgaObject(master), UDM_OBJECT(master) {};

	StateToTransition StateToTransition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateToTransition& StateToTransition::operator=(StateToTransition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateToTransition StateToTransition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateToTransition StateToTransition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateToTransition StateToTransition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateToTransition> StateToTransition::Instances() { return ::Udm::InstantiatedAttr< StateToTransition>(impl); }
	StateToTransition StateToTransition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateToTransition> StateToTransition::Derived() { return ::Udm::DerivedAttr< StateToTransition>(impl); }
	::Udm::ArchetypeAttr< StateToTransition> StateToTransition::Archetype() const { return ::Udm::ArchetypeAttr< StateToTransition>(impl); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> StateToTransition::PetriNet_parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_parent); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> StateToTransition::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::PNState> StateToTransition::srcStateToTransition_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PNState>(impl, meta_srcStateToTransition_end_); }
	::Udm::AssocEndAttr< ::ESMoL::PNTransition> StateToTransition::dstStateToTransition_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PNTransition>(impl, meta_dstStateToTransition_end_); }

	::Uml::Class StateToTransition::meta;
	::Uml::CompositionParentRole StateToTransition::meta_PetriNet_parent;
	::Uml::AssociationRole StateToTransition::meta_srcStateToTransition_end_;
	::Uml::AssociationRole StateToTransition::meta_dstStateToTransition_end_;

	PNTransition::PNTransition() {}
	PNTransition::PNTransition(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	PNTransition::PNTransition(const PNTransition &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PNTransition::PNTransition(PNTransition &&master) : MgaObject(master), UDM_OBJECT(master) {};

	PNTransition PNTransition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PNTransition& PNTransition::operator=(PNTransition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PNTransition PNTransition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PNTransition PNTransition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PNTransition PNTransition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PNTransition> PNTransition::Instances() { return ::Udm::InstantiatedAttr< PNTransition>(impl); }
	PNTransition PNTransition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PNTransition> PNTransition::Derived() { return ::Udm::DerivedAttr< PNTransition>(impl); }
	::Udm::ArchetypeAttr< PNTransition> PNTransition::Archetype() const { return ::Udm::ArchetypeAttr< PNTransition>(impl); }
	::Udm::StringAttr PNTransition::guard() const { return ::Udm::StringAttr(impl, meta_guard); }
	::Udm::StringAttr PNTransition::action() const { return ::Udm::StringAttr(impl, meta_action); }
	::Udm::AClassAssocAttr< TransitionToState, PNState> PNTransition::dstTransitionToState() const { return ::Udm::AClassAssocAttr< TransitionToState, PNState>(impl, meta_dstTransitionToState, meta_dstTransitionToState_rev); }
	::Udm::AClassAssocAttr< StateToTransition, PNState> PNTransition::srcStateToTransition() const { return ::Udm::AClassAssocAttr< StateToTransition, PNState>(impl, meta_srcStateToTransition, meta_srcStateToTransition_rev); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNTransition::PetriNet_parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_parent); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNTransition::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PNTransition::meta;
	::Uml::Attribute PNTransition::meta_guard;
	::Uml::Attribute PNTransition::meta_action;
	::Uml::AssociationRole PNTransition::meta_dstTransitionToState;
	::Uml::AssociationRole PNTransition::meta_dstTransitionToState_rev;
	::Uml::AssociationRole PNTransition::meta_srcStateToTransition;
	::Uml::AssociationRole PNTransition::meta_srcStateToTransition_rev;
	::Uml::CompositionParentRole PNTransition::meta_PetriNet_parent;

	PNState::PNState() {}
	PNState::PNState(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	PNState::PNState(const PNState &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PNState::PNState(PNState &&master) : MgaObject(master), UDM_OBJECT(master) {};

	PNState PNState::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PNState& PNState::operator=(PNState &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PNState PNState::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PNState PNState::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PNState PNState::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PNState> PNState::Instances() { return ::Udm::InstantiatedAttr< PNState>(impl); }
	PNState PNState::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PNState> PNState::Derived() { return ::Udm::DerivedAttr< PNState>(impl); }
	::Udm::ArchetypeAttr< PNState> PNState::Archetype() const { return ::Udm::ArchetypeAttr< PNState>(impl); }
	::Udm::BooleanAttr PNState::initial() const { return ::Udm::BooleanAttr(impl, meta_initial); }
	::Udm::AClassAssocAttr< TransitionToState, PNTransition> PNState::srcTransitionToState() const { return ::Udm::AClassAssocAttr< TransitionToState, PNTransition>(impl, meta_srcTransitionToState, meta_srcTransitionToState_rev); }
	::Udm::AClassAssocAttr< StateToTransition, PNTransition> PNState::dstStateToTransition() const { return ::Udm::AClassAssocAttr< StateToTransition, PNTransition>(impl, meta_dstStateToTransition, meta_dstStateToTransition_rev); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNState::PetriNet_parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_parent); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNState::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PNState::meta;
	::Uml::Attribute PNState::meta_initial;
	::Uml::AssociationRole PNState::meta_srcTransitionToState;
	::Uml::AssociationRole PNState::meta_srcTransitionToState_rev;
	::Uml::AssociationRole PNState::meta_dstStateToTransition;
	::Uml::AssociationRole PNState::meta_dstStateToTransition_rev;
	::Uml::CompositionParentRole PNState::meta_PetriNet_parent;

	BIPConnector::BIPConnector() {}
	BIPConnector::BIPConnector(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	BIPConnector::BIPConnector(const BIPConnector &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	BIPConnector::BIPConnector(BIPConnector &&master) : MgaObject(master), UDM_OBJECT(master) {};

	BIPConnector BIPConnector::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BIPConnector& BIPConnector::operator=(BIPConnector &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BIPConnector BIPConnector::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BIPConnector BIPConnector::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BIPConnector BIPConnector::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BIPConnector> BIPConnector::Instances() { return ::Udm::InstantiatedAttr< BIPConnector>(impl); }
	BIPConnector BIPConnector::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BIPConnector> BIPConnector::Derived() { return ::Udm::DerivedAttr< BIPConnector>(impl); }
	::Udm::ArchetypeAttr< BIPConnector> BIPConnector::Archetype() const { return ::Udm::ArchetypeAttr< BIPConnector>(impl); }
	::Udm::ParentAttr< ::ESMoL::Module> BIPConnector::Module_parent() const { return ::Udm::ParentAttr< ::ESMoL::Module>(impl, meta_Module_parent); }
	::Udm::ParentAttr< ::ESMoL::Module> BIPConnector::parent() const { return ::Udm::ParentAttr< ::ESMoL::Module>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::PNPort> BIPConnector::srcPortToPort_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PNPort>(impl, meta_srcPortToPort_end_); }
	::Udm::AssocEndAttr< ::ESMoL::PNPort> BIPConnector::dstPortToPort_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PNPort>(impl, meta_dstPortToPort_end_); }

	::Uml::Class BIPConnector::meta;
	::Uml::CompositionParentRole BIPConnector::meta_Module_parent;
	::Uml::AssociationRole BIPConnector::meta_srcPortToPort_end_;
	::Uml::AssociationRole BIPConnector::meta_dstPortToPort_end_;

	PNVarRef::PNVarRef() {}
	PNVarRef::PNVarRef(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	PNVarRef::PNVarRef(const PNVarRef &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PNVarRef::PNVarRef(PNVarRef &&master) : MgaObject(master), UDM_OBJECT(master) {};

	PNVarRef PNVarRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PNVarRef& PNVarRef::operator=(PNVarRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PNVarRef PNVarRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PNVarRef PNVarRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PNVarRef PNVarRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PNVarRef> PNVarRef::Instances() { return ::Udm::InstantiatedAttr< PNVarRef>(impl); }
	PNVarRef PNVarRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PNVarRef> PNVarRef::Derived() { return ::Udm::DerivedAttr< PNVarRef>(impl); }
	::Udm::ArchetypeAttr< PNVarRef> PNVarRef::Archetype() const { return ::Udm::ArchetypeAttr< PNVarRef>(impl); }
	::Udm::PointerAttr< PNVariable> PNVarRef::ref() const { return ::Udm::PointerAttr< PNVariable>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::PNPort> PNVarRef::PNPort_parent() const { return ::Udm::ParentAttr< ::ESMoL::PNPort>(impl, meta_PNPort_parent); }
	::Udm::ParentAttr< ::ESMoL::PNPort> PNVarRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::PNPort>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PNVarRef::meta;
	::Uml::AssociationRole PNVarRef::meta_ref;
	::Uml::CompositionParentRole PNVarRef::meta_PNPort_parent;

	Module::Module() {}
	Module::Module(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Module::Module(const Module &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Module::Module(Module &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Module Module::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Module& Module::operator=(Module &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Module Module::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Module Module::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Module Module::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Module> Module::Instances() { return ::Udm::InstantiatedAttr< Module>(impl); }
	Module Module::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Module> Module::Derived() { return ::Udm::DerivedAttr< Module>(impl); }
	::Udm::ArchetypeAttr< Module> Module::Archetype() const { return ::Udm::ArchetypeAttr< Module>(impl); }
	::Udm::ChildrenAttr< ::ESMoL::BIPConnector> Module::BIPConnector_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BIPConnector>(impl, meta_BIPConnector_children); }
	::Udm::ChildrenAttr< ::ESMoL::PetriNet> Module::PetriNet_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_children); }
	::Udm::ChildrenAttr< ::ESMoL::BIPConnector> Module::BIPConnector_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BIPConnector>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PetriNet> Module::PetriNet_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentBase> Module::ComponentBase_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Module::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> Module::ModelsFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, meta_ModelsFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> Module::parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Module::meta;
	::Uml::CompositionChildRole Module::meta_BIPConnector_children;
	::Uml::CompositionChildRole Module::meta_PetriNet_children;
	::Uml::CompositionParentRole Module::meta_ModelsFolder_parent;

	PetriNet::PetriNet() {}
	PetriNet::PetriNet(::Udm::ObjectImpl *impl) : ComponentBase(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	PetriNet::PetriNet(const PetriNet &master) : ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PetriNet::PetriNet(PetriNet &&master) : ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {};

	PetriNet PetriNet::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PetriNet& PetriNet::operator=(PetriNet &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PetriNet PetriNet::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PetriNet PetriNet::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PetriNet PetriNet::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PetriNet> PetriNet::Instances() { return ::Udm::InstantiatedAttr< PetriNet>(impl); }
	PetriNet PetriNet::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PetriNet> PetriNet::Derived() { return ::Udm::DerivedAttr< PetriNet>(impl); }
	::Udm::ArchetypeAttr< PetriNet> PetriNet::Archetype() const { return ::Udm::ArchetypeAttr< PetriNet>(impl); }
	::Udm::StringAttr PetriNet::action() const { return ::Udm::StringAttr(impl, meta_action); }
	::Udm::AssocAttr< PetriNetRef> PetriNet::referedbyPetriNetRef() const { return ::Udm::AssocAttr< PetriNetRef>(impl, meta_referedbyPetriNetRef); }
	::Udm::ChildrenAttr< ::ESMoL::StateToTransition> PetriNet::StateToTransition_children() const { return ::Udm::ChildrenAttr< ::ESMoL::StateToTransition>(impl, meta_StateToTransition_children); }
	::Udm::ChildrenAttr< ::ESMoL::PNTransition> PetriNet::PNTransition_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNTransition>(impl, meta_PNTransition_children); }
	::Udm::ChildrenAttr< ::ESMoL::TransitionToState> PetriNet::TransitionToState_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransitionToState>(impl, meta_TransitionToState_children); }
	::Udm::ChildrenAttr< ::ESMoL::PNState> PetriNet::PNState_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNState>(impl, meta_PNState_children); }
	::Udm::ChildrenAttr< ::ESMoL::PNVariable> PetriNet::PNVariable_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNVariable>(impl, meta_PNVariable_children); }
	::Udm::ChildrenAttr< ::ESMoL::PNPort> PetriNet::PNPort_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNPort>(impl, meta_PNPort_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> PetriNet::FaultToInput_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> PetriNet::OutputToFault_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultEvent> PetriNet::FaultEvent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultEvent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TransitionToState> PetriNet::TransitionToState_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransitionToState>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::StateToTransition> PetriNet::StateToTransition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::StateToTransition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PNTransition> PetriNet::PNTransition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNTransition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PNState> PetriNet::PNState_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNState>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PNPort> PetriNet::PNPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PNVariable> PetriNet::PNVariable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNVariable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IOPortExp> PetriNet::IOPortExp_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Output> PetriNet::Output_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Output>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Input> PetriNet::Input_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Input>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputEvent> PetriNet::OutputEvent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputEvent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::InputEvent> PetriNet::InputEvent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::InputEvent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> PetriNet::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Module> PetriNet::Module_parent() const { return ::Udm::ParentAttr< ::ESMoL::Module>(impl, meta_Module_parent); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> PetriNet::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PetriNet::meta;
	::Uml::Attribute PetriNet::meta_action;
	::Uml::AssociationRole PetriNet::meta_referedbyPetriNetRef;
	::Uml::CompositionChildRole PetriNet::meta_StateToTransition_children;
	::Uml::CompositionChildRole PetriNet::meta_PNTransition_children;
	::Uml::CompositionChildRole PetriNet::meta_TransitionToState_children;
	::Uml::CompositionChildRole PetriNet::meta_PNState_children;
	::Uml::CompositionChildRole PetriNet::meta_PNVariable_children;
	::Uml::CompositionChildRole PetriNet::meta_PNPort_children;
	::Uml::CompositionParentRole PetriNet::meta_Module_parent;

	PNPort::PNPort() {}
	PNPort::PNPort(::Udm::ObjectImpl *impl) : FaultEvent(impl),OutputEvent(impl),InputEvent(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	PNPort::PNPort(const PNPort &master) : FaultEvent(master),OutputEvent(master),InputEvent(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PNPort::PNPort(PNPort &&master) : FaultEvent(master),OutputEvent(master),InputEvent(master), MgaObject(master), UDM_OBJECT(master) {};

	PNPort PNPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PNPort& PNPort::operator=(PNPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PNPort PNPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PNPort PNPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PNPort PNPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PNPort> PNPort::Instances() { return ::Udm::InstantiatedAttr< PNPort>(impl); }
	PNPort PNPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PNPort> PNPort::Derived() { return ::Udm::DerivedAttr< PNPort>(impl); }
	::Udm::ArchetypeAttr< PNPort> PNPort::Archetype() const { return ::Udm::ArchetypeAttr< PNPort>(impl); }
	::Udm::BooleanAttr PNPort::visible() const { return ::Udm::BooleanAttr(impl, meta_visible); }
	::Udm::AClassAssocAttr< BIPConnector, PNPort> PNPort::dstPortToPort() const { return ::Udm::AClassAssocAttr< BIPConnector, PNPort>(impl, meta_dstPortToPort, meta_dstPortToPort_rev); }
	::Udm::AClassAssocAttr< BIPConnector, PNPort> PNPort::srcPortToPort() const { return ::Udm::AClassAssocAttr< BIPConnector, PNPort>(impl, meta_srcPortToPort, meta_srcPortToPort_rev); }
	::Udm::ChildrenAttr< ::ESMoL::PNVarRef> PNPort::PNVarRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNVarRef>(impl, meta_PNVarRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::PNVarRef> PNPort::PNVarRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PNVarRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> PNPort::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNPort::PetriNet_parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_parent); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PNPort::meta;
	::Uml::Attribute PNPort::meta_visible;
	::Uml::AssociationRole PNPort::meta_dstPortToPort;
	::Uml::AssociationRole PNPort::meta_dstPortToPort_rev;
	::Uml::AssociationRole PNPort::meta_srcPortToPort;
	::Uml::AssociationRole PNPort::meta_srcPortToPort_rev;
	::Uml::CompositionChildRole PNPort::meta_PNVarRef_children;
	::Uml::CompositionParentRole PNPort::meta_PetriNet_parent;

	PNVariable::PNVariable() {}
	PNVariable::PNVariable(::Udm::ObjectImpl *impl) : Output(impl),Input(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	PNVariable::PNVariable(const PNVariable &master) : Output(master),Input(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PNVariable::PNVariable(PNVariable &&master) : Output(master),Input(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	PNVariable PNVariable::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PNVariable& PNVariable::operator=(PNVariable &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PNVariable PNVariable::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PNVariable PNVariable::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PNVariable PNVariable::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PNVariable> PNVariable::Instances() { return ::Udm::InstantiatedAttr< PNVariable>(impl); }
	PNVariable PNVariable::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PNVariable> PNVariable::Derived() { return ::Udm::DerivedAttr< PNVariable>(impl); }
	::Udm::ArchetypeAttr< PNVariable> PNVariable::Archetype() const { return ::Udm::ArchetypeAttr< PNVariable>(impl); }
	::Udm::StringAttr PNVariable::datatype() const { return ::Udm::StringAttr(impl, meta_datatype); }
	::Udm::AssocAttr< PNVarRef> PNVariable::referedbyPNVarRef() const { return ::Udm::AssocAttr< PNVarRef>(impl, meta_referedbyPNVarRef); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNVariable::PetriNet_parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, meta_PetriNet_parent); }
	::Udm::ParentAttr< ::ESMoL::PetriNet> PNVariable::parent() const { return ::Udm::ParentAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PNVariable::meta;
	::Uml::Attribute PNVariable::meta_datatype;
	::Uml::AssociationRole PNVariable::meta_referedbyPNVarRef;
	::Uml::CompositionParentRole PNVariable::meta_PetriNet_parent;

	ModelsFolder::ModelsFolder() {}
	ModelsFolder::ModelsFolder(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ModelsFolder::ModelsFolder(const ModelsFolder &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ModelsFolder::ModelsFolder(ModelsFolder &&master) : UDM_OBJECT(master) {};

	ModelsFolder ModelsFolder::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ModelsFolder& ModelsFolder::operator=(ModelsFolder &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ModelsFolder ModelsFolder::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ModelsFolder ModelsFolder::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ModelsFolder ModelsFolder::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ModelsFolder> ModelsFolder::Instances() { return ::Udm::InstantiatedAttr< ModelsFolder>(impl); }
	ModelsFolder ModelsFolder::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ModelsFolder> ModelsFolder::Derived() { return ::Udm::DerivedAttr< ModelsFolder>(impl); }
	::Udm::ArchetypeAttr< ModelsFolder> ModelsFolder::Archetype() const { return ::Udm::ArchetypeAttr< ModelsFolder>(impl); }
	::Udm::StringAttr ModelsFolder::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::Dataflow> ModelsFolder::Dataflow_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Dataflow>(impl, meta_Dataflow_children); }
	::Udm::ChildrenAttr< ::ESMoL::Stateflow> ModelsFolder::Stateflow_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Stateflow>(impl, meta_Stateflow_children); }
	::Udm::ChildrenAttr< ::ESMoL::ModelInfo> ModelsFolder::ModelInfo_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ModelInfo>(impl, meta_ModelInfo_children); }
	::Udm::ChildrenAttr< ::ESMoL::Module> ModelsFolder::Module_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Module>(impl, meta_Module_children); }
	::Udm::ChildrenAttr< ::ESMoL::Module> ModelsFolder::Module_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Module>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ModelInfo> ModelsFolder::ModelInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ModelInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Dataflow> ModelsFolder::Dataflow_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Dataflow>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Stateflow> ModelsFolder::Stateflow_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Stateflow>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> ModelsFolder::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> ModelsFolder::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> ModelsFolder::parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ModelsFolder::meta;
	::Uml::Attribute ModelsFolder::meta_name;
	::Uml::CompositionChildRole ModelsFolder::meta_Dataflow_children;
	::Uml::CompositionChildRole ModelsFolder::meta_Stateflow_children;
	::Uml::CompositionChildRole ModelsFolder::meta_ModelInfo_children;
	::Uml::CompositionChildRole ModelsFolder::meta_Module_children;
	::Uml::CompositionParentRole ModelsFolder::meta_DesignFolder_parent;

	ModelInfo::ModelInfo() {}
	ModelInfo::ModelInfo(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ModelInfo::ModelInfo(const ModelInfo &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ModelInfo::ModelInfo(ModelInfo &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ModelInfo ModelInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ModelInfo& ModelInfo::operator=(ModelInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ModelInfo ModelInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ModelInfo ModelInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ModelInfo ModelInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ModelInfo> ModelInfo::Instances() { return ::Udm::InstantiatedAttr< ModelInfo>(impl); }
	ModelInfo ModelInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ModelInfo> ModelInfo::Derived() { return ::Udm::DerivedAttr< ModelInfo>(impl); }
	::Udm::ArchetypeAttr< ModelInfo> ModelInfo::Archetype() const { return ::Udm::ArchetypeAttr< ModelInfo>(impl); }
	::Udm::StringAttr ModelInfo::ModelPath() const { return ::Udm::StringAttr(impl, meta_ModelPath); }
	::Udm::StringAttr ModelInfo::DateTimeStamp() const { return ::Udm::StringAttr(impl, meta_DateTimeStamp); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> ModelInfo::ModelsFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, meta_ModelsFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> ModelInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ModelInfo::meta;
	::Uml::Attribute ModelInfo::meta_ModelPath;
	::Uml::Attribute ModelInfo::meta_DateTimeStamp;
	::Uml::CompositionParentRole ModelInfo::meta_ModelsFolder_parent;

	ExecutionInfo::ExecutionInfo() {}
	ExecutionInfo::ExecutionInfo(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ExecutionInfo::ExecutionInfo(const ExecutionInfo &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ExecutionInfo::ExecutionInfo(ExecutionInfo &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ExecutionInfo ExecutionInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ExecutionInfo& ExecutionInfo::operator=(ExecutionInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ExecutionInfo ExecutionInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ExecutionInfo ExecutionInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ExecutionInfo ExecutionInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ExecutionInfo> ExecutionInfo::Instances() { return ::Udm::InstantiatedAttr< ExecutionInfo>(impl); }
	ExecutionInfo ExecutionInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ExecutionInfo> ExecutionInfo::Derived() { return ::Udm::DerivedAttr< ExecutionInfo>(impl); }
	::Udm::ArchetypeAttr< ExecutionInfo> ExecutionInfo::Archetype() const { return ::Udm::ArchetypeAttr< ExecutionInfo>(impl); }
	::Udm::StringAttr ExecutionInfo::WCDuration() const { return ::Udm::StringAttr(impl, meta_WCDuration); }
	::Udm::StringAttr ExecutionInfo::RelDeadline() const { return ::Udm::StringAttr(impl, meta_RelDeadline); }
	::Udm::AClassAssocAttr< ExecutionAssignment, Executable> ExecutionInfo::dstExecutionAssignment() const { return ::Udm::AClassAssocAttr< ExecutionAssignment, Executable>(impl, meta_dstExecutionAssignment, meta_dstExecutionAssignment_rev); }
	::Udm::ParentAttr< ::ESMoL::System> ExecutionInfo::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> ExecutionInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ExecutionInfo::meta;
	::Uml::Attribute ExecutionInfo::meta_WCDuration;
	::Uml::Attribute ExecutionInfo::meta_RelDeadline;
	::Uml::AssociationRole ExecutionInfo::meta_dstExecutionAssignment;
	::Uml::AssociationRole ExecutionInfo::meta_dstExecutionAssignment_rev;
	::Uml::CompositionParentRole ExecutionInfo::meta_System_parent;

	TTExecInfo::TTExecInfo() {}
	TTExecInfo::TTExecInfo(::Udm::ObjectImpl *impl) : PeriodicExecInfo(impl), UDM_OBJECT(impl) {}
	TTExecInfo::TTExecInfo(const TTExecInfo &master) : PeriodicExecInfo(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TTExecInfo::TTExecInfo(TTExecInfo &&master) : PeriodicExecInfo(master), UDM_OBJECT(master) {};

	TTExecInfo TTExecInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TTExecInfo& TTExecInfo::operator=(TTExecInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TTExecInfo TTExecInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TTExecInfo TTExecInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TTExecInfo TTExecInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TTExecInfo> TTExecInfo::Instances() { return ::Udm::InstantiatedAttr< TTExecInfo>(impl); }
	TTExecInfo TTExecInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TTExecInfo> TTExecInfo::Derived() { return ::Udm::DerivedAttr< TTExecInfo>(impl); }
	::Udm::ArchetypeAttr< TTExecInfo> TTExecInfo::Archetype() const { return ::Udm::ArchetypeAttr< TTExecInfo>(impl); }
	::Udm::StringAttr TTExecInfo::TTSchedule() const { return ::Udm::StringAttr(impl, meta_TTSchedule); }
	::Udm::ParentAttr< ::ESMoL::System> TTExecInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TTExecInfo::meta;
	::Uml::Attribute TTExecInfo::meta_TTSchedule;

	AsyncPeriodicExecInfo::AsyncPeriodicExecInfo() {}
	AsyncPeriodicExecInfo::AsyncPeriodicExecInfo(::Udm::ObjectImpl *impl) : PeriodicExecInfo(impl), UDM_OBJECT(impl) {}
	AsyncPeriodicExecInfo::AsyncPeriodicExecInfo(const AsyncPeriodicExecInfo &master) : PeriodicExecInfo(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	AsyncPeriodicExecInfo::AsyncPeriodicExecInfo(AsyncPeriodicExecInfo &&master) : PeriodicExecInfo(master), UDM_OBJECT(master) {};

	AsyncPeriodicExecInfo AsyncPeriodicExecInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	AsyncPeriodicExecInfo& AsyncPeriodicExecInfo::operator=(AsyncPeriodicExecInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	AsyncPeriodicExecInfo AsyncPeriodicExecInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	AsyncPeriodicExecInfo AsyncPeriodicExecInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	AsyncPeriodicExecInfo AsyncPeriodicExecInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< AsyncPeriodicExecInfo> AsyncPeriodicExecInfo::Instances() { return ::Udm::InstantiatedAttr< AsyncPeriodicExecInfo>(impl); }
	AsyncPeriodicExecInfo AsyncPeriodicExecInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< AsyncPeriodicExecInfo> AsyncPeriodicExecInfo::Derived() { return ::Udm::DerivedAttr< AsyncPeriodicExecInfo>(impl); }
	::Udm::ArchetypeAttr< AsyncPeriodicExecInfo> AsyncPeriodicExecInfo::Archetype() const { return ::Udm::ArchetypeAttr< AsyncPeriodicExecInfo>(impl); }
	::Udm::StringAttr AsyncPeriodicExecInfo::TerminationTime() const { return ::Udm::StringAttr(impl, meta_TerminationTime); }
	::Udm::ParentAttr< ::ESMoL::System> AsyncPeriodicExecInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class AsyncPeriodicExecInfo::meta;
	::Uml::Attribute AsyncPeriodicExecInfo::meta_TerminationTime;

	ExecutionContext::ExecutionContext() {}
	ExecutionContext::ExecutionContext(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ExecutionContext::ExecutionContext(const ExecutionContext &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ExecutionContext::ExecutionContext(ExecutionContext &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ExecutionContext ExecutionContext::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ExecutionContext& ExecutionContext::operator=(ExecutionContext &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ExecutionContext ExecutionContext::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ExecutionContext ExecutionContext::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ExecutionContext ExecutionContext::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ExecutionContext> ExecutionContext::Instances() { return ::Udm::InstantiatedAttr< ExecutionContext>(impl); }
	ExecutionContext ExecutionContext::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ExecutionContext> ExecutionContext::Derived() { return ::Udm::DerivedAttr< ExecutionContext>(impl); }
	::Udm::ArchetypeAttr< ExecutionContext> ExecutionContext::Archetype() const { return ::Udm::ArchetypeAttr< ExecutionContext>(impl); }
	::Udm::ParentAttr< ::ESMoL::HWElement> ExecutionContext::HWElement_parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, meta_HWElement_parent); }
	::Udm::ParentAttr< ::ESMoL::HWElement> ExecutionContext::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ExecutionContext::meta;
	::Uml::CompositionParentRole ExecutionContext::meta_HWElement_parent;

	TTExecContext::TTExecContext() {}
	TTExecContext::TTExecContext(::Udm::ObjectImpl *impl) : ExecutionContext(impl), UDM_OBJECT(impl) {}
	TTExecContext::TTExecContext(const TTExecContext &master) : ExecutionContext(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TTExecContext::TTExecContext(TTExecContext &&master) : ExecutionContext(master), UDM_OBJECT(master) {};

	TTExecContext TTExecContext::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TTExecContext& TTExecContext::operator=(TTExecContext &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TTExecContext TTExecContext::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TTExecContext TTExecContext::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TTExecContext TTExecContext::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TTExecContext> TTExecContext::Instances() { return ::Udm::InstantiatedAttr< TTExecContext>(impl); }
	TTExecContext TTExecContext::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TTExecContext> TTExecContext::Derived() { return ::Udm::DerivedAttr< TTExecContext>(impl); }
	::Udm::ArchetypeAttr< TTExecContext> TTExecContext::Archetype() const { return ::Udm::ArchetypeAttr< TTExecContext>(impl); }
	::Udm::StringAttr TTExecContext::Hyperperiod() const { return ::Udm::StringAttr(impl, meta_Hyperperiod); }
	::Udm::ParentAttr< ::ESMoL::HWElement> TTExecContext::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TTExecContext::meta;
	::Uml::Attribute TTExecContext::meta_Hyperperiod;

	PeriodicExecInfo::PeriodicExecInfo() {}
	PeriodicExecInfo::PeriodicExecInfo(::Udm::ObjectImpl *impl) : ExecutionInfo(impl), UDM_OBJECT(impl) {}
	PeriodicExecInfo::PeriodicExecInfo(const PeriodicExecInfo &master) : ExecutionInfo(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PeriodicExecInfo::PeriodicExecInfo(PeriodicExecInfo &&master) : ExecutionInfo(master), UDM_OBJECT(master) {};

	PeriodicExecInfo PeriodicExecInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PeriodicExecInfo& PeriodicExecInfo::operator=(PeriodicExecInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PeriodicExecInfo PeriodicExecInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PeriodicExecInfo PeriodicExecInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PeriodicExecInfo PeriodicExecInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PeriodicExecInfo> PeriodicExecInfo::Instances() { return ::Udm::InstantiatedAttr< PeriodicExecInfo>(impl); }
	PeriodicExecInfo PeriodicExecInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PeriodicExecInfo> PeriodicExecInfo::Derived() { return ::Udm::DerivedAttr< PeriodicExecInfo>(impl); }
	::Udm::ArchetypeAttr< PeriodicExecInfo> PeriodicExecInfo::Archetype() const { return ::Udm::ArchetypeAttr< PeriodicExecInfo>(impl); }
	::Udm::StringAttr PeriodicExecInfo::ExecPeriod() const { return ::Udm::StringAttr(impl, meta_ExecPeriod); }
	::Udm::StringAttr PeriodicExecInfo::DesiredOffset() const { return ::Udm::StringAttr(impl, meta_DesiredOffset); }
	::Udm::ParentAttr< ::ESMoL::System> PeriodicExecInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PeriodicExecInfo::meta;
	::Uml::Attribute PeriodicExecInfo::meta_ExecPeriod;
	::Uml::Attribute PeriodicExecInfo::meta_DesiredOffset;

	ExecutionAssignment::ExecutionAssignment() {}
	ExecutionAssignment::ExecutionAssignment(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ExecutionAssignment::ExecutionAssignment(const ExecutionAssignment &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ExecutionAssignment::ExecutionAssignment(ExecutionAssignment &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ExecutionAssignment ExecutionAssignment::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ExecutionAssignment& ExecutionAssignment::operator=(ExecutionAssignment &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ExecutionAssignment ExecutionAssignment::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ExecutionAssignment ExecutionAssignment::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ExecutionAssignment ExecutionAssignment::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ExecutionAssignment> ExecutionAssignment::Instances() { return ::Udm::InstantiatedAttr< ExecutionAssignment>(impl); }
	ExecutionAssignment ExecutionAssignment::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ExecutionAssignment> ExecutionAssignment::Derived() { return ::Udm::DerivedAttr< ExecutionAssignment>(impl); }
	::Udm::ArchetypeAttr< ExecutionAssignment> ExecutionAssignment::Archetype() const { return ::Udm::ArchetypeAttr< ExecutionAssignment>(impl); }
	::Udm::PointerAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> ExecutionAssignment::dstExecutionAssignment__rp_helper() const { return ::Udm::PointerAttr< ExecutionAssignment_dstExecutionAssignment_RPContainer_Base>(impl, meta_dstExecutionAssignment__rp_helper); }
	::Udm::ParentAttr< ::ESMoL::System> ExecutionAssignment::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> ExecutionAssignment::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::ExecutionInfo> ExecutionAssignment::srcExecutionAssignment_end() const { return ::Udm::AssocEndAttr< ::ESMoL::ExecutionInfo>(impl, meta_srcExecutionAssignment_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::ExecutionInfo, ExecutionAssignment::srcExecutionAssignment_chain_t > ExecutionAssignment::srcExecutionAssignment_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::ExecutionInfo, ExecutionAssignment::srcExecutionAssignment_chain_t >(impl, meta_srcExecutionAssignment_end_); }
	::Udm::AssocEndAttr< ::ESMoL::Executable> ExecutionAssignment::dstExecutionAssignment_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Executable>(impl, meta_dstExecutionAssignment_end_); }

	::Uml::Class ExecutionAssignment::meta;
	::Uml::AssociationRole ExecutionAssignment::meta_dstExecutionAssignment__rp_helper;
	::Uml::CompositionParentRole ExecutionAssignment::meta_System_parent;
	::Uml::AssociationRole ExecutionAssignment::meta_srcExecutionAssignment_end_;
	::Uml::AssociationRole ExecutionAssignment::meta_dstExecutionAssignment_end_;

	Executable::Executable() {}
	Executable::Executable(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Executable::Executable(const Executable &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Executable::Executable(Executable &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Executable Executable::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Executable& Executable::operator=(Executable &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Executable Executable::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Executable Executable::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Executable Executable::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Executable> Executable::Instances() { return ::Udm::InstantiatedAttr< Executable>(impl); }
	Executable Executable::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Executable> Executable::Derived() { return ::Udm::DerivedAttr< Executable>(impl); }
	::Udm::ArchetypeAttr< Executable> Executable::Archetype() const { return ::Udm::ArchetypeAttr< Executable>(impl); }
	::Udm::AClassAssocAttr< ExecutionAssignment, ExecutionInfo> Executable::srcExecutionAssignment() const { return ::Udm::AClassAssocAttr< ExecutionAssignment, ExecutionInfo>(impl, meta_srcExecutionAssignment, meta_srcExecutionAssignment_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> Executable::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Executable::meta;
	::Uml::AssociationRole Executable::meta_srcExecutionAssignment;
	::Uml::AssociationRole Executable::meta_srcExecutionAssignment_rev;

	AperiodicExecInfo::AperiodicExecInfo() {}
	AperiodicExecInfo::AperiodicExecInfo(::Udm::ObjectImpl *impl) : ExecutionInfo(impl), UDM_OBJECT(impl) {}
	AperiodicExecInfo::AperiodicExecInfo(const AperiodicExecInfo &master) : ExecutionInfo(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	AperiodicExecInfo::AperiodicExecInfo(AperiodicExecInfo &&master) : ExecutionInfo(master), UDM_OBJECT(master) {};

	AperiodicExecInfo AperiodicExecInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	AperiodicExecInfo& AperiodicExecInfo::operator=(AperiodicExecInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	AperiodicExecInfo AperiodicExecInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	AperiodicExecInfo AperiodicExecInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	AperiodicExecInfo AperiodicExecInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< AperiodicExecInfo> AperiodicExecInfo::Instances() { return ::Udm::InstantiatedAttr< AperiodicExecInfo>(impl); }
	AperiodicExecInfo AperiodicExecInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< AperiodicExecInfo> AperiodicExecInfo::Derived() { return ::Udm::DerivedAttr< AperiodicExecInfo>(impl); }
	::Udm::ArchetypeAttr< AperiodicExecInfo> AperiodicExecInfo::Archetype() const { return ::Udm::ArchetypeAttr< AperiodicExecInfo>(impl); }
	::Udm::ParentAttr< ::ESMoL::System> AperiodicExecInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class AperiodicExecInfo::meta;

	SporadicExecInfo::SporadicExecInfo() {}
	SporadicExecInfo::SporadicExecInfo(::Udm::ObjectImpl *impl) : AperiodicExecInfo(impl), UDM_OBJECT(impl) {}
	SporadicExecInfo::SporadicExecInfo(const SporadicExecInfo &master) : AperiodicExecInfo(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SporadicExecInfo::SporadicExecInfo(SporadicExecInfo &&master) : AperiodicExecInfo(master), UDM_OBJECT(master) {};

	SporadicExecInfo SporadicExecInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SporadicExecInfo& SporadicExecInfo::operator=(SporadicExecInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SporadicExecInfo SporadicExecInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SporadicExecInfo SporadicExecInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SporadicExecInfo SporadicExecInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SporadicExecInfo> SporadicExecInfo::Instances() { return ::Udm::InstantiatedAttr< SporadicExecInfo>(impl); }
	SporadicExecInfo SporadicExecInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SporadicExecInfo> SporadicExecInfo::Derived() { return ::Udm::DerivedAttr< SporadicExecInfo>(impl); }
	::Udm::ArchetypeAttr< SporadicExecInfo> SporadicExecInfo::Archetype() const { return ::Udm::ArchetypeAttr< SporadicExecInfo>(impl); }
	::Udm::StringAttr SporadicExecInfo::MinimumPeriod() const { return ::Udm::StringAttr(impl, meta_MinimumPeriod); }
	::Udm::ParentAttr< ::ESMoL::System> SporadicExecInfo::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class SporadicExecInfo::meta;
	::Uml::Attribute SporadicExecInfo::meta_MinimumPeriod;

	CCode::CCode() {}
	CCode::CCode(::Udm::ObjectImpl *impl) : ComponentBase(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	CCode::CCode(const CCode &master) : ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CCode::CCode(CCode &&master) : ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {};

	CCode CCode::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CCode& CCode::operator=(CCode &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CCode CCode::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CCode CCode::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CCode CCode::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CCode> CCode::Instances() { return ::Udm::InstantiatedAttr< CCode>(impl); }
	CCode CCode::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CCode> CCode::Derived() { return ::Udm::DerivedAttr< CCode>(impl); }
	::Udm::ArchetypeAttr< CCode> CCode::Archetype() const { return ::Udm::ArchetypeAttr< CCode>(impl); }
	::Udm::StringAttr CCode::CodeInfo() const { return ::Udm::StringAttr(impl, meta_CodeInfo); }
	::Udm::ChildrenAttr< ::ESMoL::COutputPort> CCode::COutputPort_children() const { return ::Udm::ChildrenAttr< ::ESMoL::COutputPort>(impl, meta_COutputPort_children); }
	::Udm::ChildrenAttr< ::ESMoL::CInputPort> CCode::CInputPort_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CInputPort>(impl, meta_CInputPort_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> CCode::FaultToInput_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> CCode::OutputToFault_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::COutputPort> CCode::COutputPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::COutputPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CInputPort> CCode::CInputPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CInputPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IOPortExp> CCode::IOPortExp_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Output> CCode::Output_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Output>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Input> CCode::Input_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Input>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> CCode::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> CCode::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CCode::meta;
	::Uml::Attribute CCode::meta_CodeInfo;
	::Uml::CompositionChildRole CCode::meta_COutputPort_children;
	::Uml::CompositionChildRole CCode::meta_CInputPort_children;

	SubsystemRef::SubsystemRef() {}
	SubsystemRef::SubsystemRef(::Udm::ObjectImpl *impl) : Connector_srcConnector_RPContainer_Base(impl),Connector_dstConnector_RPContainer_Base(impl),ComponentBase(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	SubsystemRef::SubsystemRef(const SubsystemRef &master) : Connector_srcConnector_RPContainer_Base(master),Connector_dstConnector_RPContainer_Base(master),ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SubsystemRef::SubsystemRef(SubsystemRef &&master) : Connector_srcConnector_RPContainer_Base(master),Connector_dstConnector_RPContainer_Base(master),ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {};

	SubsystemRef SubsystemRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SubsystemRef& SubsystemRef::operator=(SubsystemRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SubsystemRef SubsystemRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SubsystemRef SubsystemRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SubsystemRef SubsystemRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SubsystemRef> SubsystemRef::Instances() { return ::Udm::InstantiatedAttr< SubsystemRef>(impl); }
	SubsystemRef SubsystemRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SubsystemRef> SubsystemRef::Derived() { return ::Udm::DerivedAttr< SubsystemRef>(impl); }
	::Udm::ArchetypeAttr< SubsystemRef> SubsystemRef::Archetype() const { return ::Udm::ArchetypeAttr< SubsystemRef>(impl); }
	::Udm::PointerAttr< Subsystem> SubsystemRef::ref() const { return ::Udm::PointerAttr< Subsystem>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> SubsystemRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class SubsystemRef::meta;
	::Uml::AssociationRole SubsystemRef::meta_ref;

	COutputPort::COutputPort() {}
	COutputPort::COutputPort(::Udm::ObjectImpl *impl) : Output(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	COutputPort::COutputPort(const COutputPort &master) : Output(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	COutputPort::COutputPort(COutputPort &&master) : Output(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	COutputPort COutputPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	COutputPort& COutputPort::operator=(COutputPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	COutputPort COutputPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	COutputPort COutputPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	COutputPort COutputPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< COutputPort> COutputPort::Instances() { return ::Udm::InstantiatedAttr< COutputPort>(impl); }
	COutputPort COutputPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< COutputPort> COutputPort::Derived() { return ::Udm::DerivedAttr< COutputPort>(impl); }
	::Udm::ArchetypeAttr< COutputPort> COutputPort::Archetype() const { return ::Udm::ArchetypeAttr< COutputPort>(impl); }
	::Udm::StringAttr COutputPort::CPortType() const { return ::Udm::StringAttr(impl, meta_CPortType); }
	::Udm::ParentAttr< ::ESMoL::CCode> COutputPort::CCode_parent() const { return ::Udm::ParentAttr< ::ESMoL::CCode>(impl, meta_CCode_parent); }
	::Udm::ParentAttr< ::ESMoL::CCode> COutputPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::CCode>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class COutputPort::meta;
	::Uml::Attribute COutputPort::meta_CPortType;
	::Uml::CompositionParentRole COutputPort::meta_CCode_parent;

	CInputPort::CInputPort() {}
	CInputPort::CInputPort(::Udm::ObjectImpl *impl) : Input(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	CInputPort::CInputPort(const CInputPort &master) : Input(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CInputPort::CInputPort(CInputPort &&master) : Input(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	CInputPort CInputPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CInputPort& CInputPort::operator=(CInputPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CInputPort CInputPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CInputPort CInputPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CInputPort CInputPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CInputPort> CInputPort::Instances() { return ::Udm::InstantiatedAttr< CInputPort>(impl); }
	CInputPort CInputPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CInputPort> CInputPort::Derived() { return ::Udm::DerivedAttr< CInputPort>(impl); }
	::Udm::ArchetypeAttr< CInputPort> CInputPort::Archetype() const { return ::Udm::ArchetypeAttr< CInputPort>(impl); }
	::Udm::StringAttr CInputPort::CPortType() const { return ::Udm::StringAttr(impl, meta_CPortType); }
	::Udm::ParentAttr< ::ESMoL::CCode> CInputPort::CCode_parent() const { return ::Udm::ParentAttr< ::ESMoL::CCode>(impl, meta_CCode_parent); }
	::Udm::ParentAttr< ::ESMoL::CCode> CInputPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::CCode>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CInputPort::meta;
	::Uml::Attribute CInputPort::meta_CPortType;
	::Uml::CompositionParentRole CInputPort::meta_CCode_parent;

	PetriNetRef::PetriNetRef() {}
	PetriNetRef::PetriNetRef(::Udm::ObjectImpl *impl) : Connector_srcConnector_RPContainer_Base(impl),Connector_dstConnector_RPContainer_Base(impl),ComponentBase(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	PetriNetRef::PetriNetRef(const PetriNetRef &master) : Connector_srcConnector_RPContainer_Base(master),Connector_dstConnector_RPContainer_Base(master),ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PetriNetRef::PetriNetRef(PetriNetRef &&master) : Connector_srcConnector_RPContainer_Base(master),Connector_dstConnector_RPContainer_Base(master),ComponentBase(master), MgaObject(master), UDM_OBJECT(master) {};

	PetriNetRef PetriNetRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PetriNetRef& PetriNetRef::operator=(PetriNetRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PetriNetRef PetriNetRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PetriNetRef PetriNetRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PetriNetRef PetriNetRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PetriNetRef> PetriNetRef::Instances() { return ::Udm::InstantiatedAttr< PetriNetRef>(impl); }
	PetriNetRef PetriNetRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PetriNetRef> PetriNetRef::Derived() { return ::Udm::DerivedAttr< PetriNetRef>(impl); }
	::Udm::ArchetypeAttr< PetriNetRef> PetriNetRef::Archetype() const { return ::Udm::ArchetypeAttr< PetriNetRef>(impl); }
	::Udm::PointerAttr< PetriNet> PetriNetRef::ref() const { return ::Udm::PointerAttr< PetriNet>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> PetriNetRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PetriNetRef::meta;
	::Uml::AssociationRole PetriNetRef::meta_ref;

	CANMessage::CANMessage() {}
	CANMessage::CANMessage(::Udm::ObjectImpl *impl) : Message(impl), UDM_OBJECT(impl) {}
	CANMessage::CANMessage(const CANMessage &master) : Message(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CANMessage::CANMessage(CANMessage &&master) : Message(master), UDM_OBJECT(master) {};

	CANMessage CANMessage::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CANMessage& CANMessage::operator=(CANMessage &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CANMessage CANMessage::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CANMessage CANMessage::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CANMessage CANMessage::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CANMessage> CANMessage::Instances() { return ::Udm::InstantiatedAttr< CANMessage>(impl); }
	CANMessage CANMessage::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CANMessage> CANMessage::Derived() { return ::Udm::DerivedAttr< CANMessage>(impl); }
	::Udm::ArchetypeAttr< CANMessage> CANMessage::Archetype() const { return ::Udm::ArchetypeAttr< CANMessage>(impl); }
	::Udm::IntegerAttr CANMessage::Priority() const { return ::Udm::IntegerAttr(impl, meta_Priority); }
	::Udm::StringAttr CANMessage::Period() const { return ::Udm::StringAttr(impl, meta_Period); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> CANMessage::parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CANMessage::meta;
	::Uml::Attribute CANMessage::meta_Priority;
	::Uml::Attribute CANMessage::meta_Period;

	AutoCANParam::AutoCANParam() {}
	AutoCANParam::AutoCANParam(::Udm::ObjectImpl *impl) : MsgPort(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	AutoCANParam::AutoCANParam(const AutoCANParam &master) : MsgPort(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	AutoCANParam::AutoCANParam(AutoCANParam &&master) : MsgPort(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	AutoCANParam AutoCANParam::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	AutoCANParam& AutoCANParam::operator=(AutoCANParam &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	AutoCANParam AutoCANParam::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	AutoCANParam AutoCANParam::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	AutoCANParam AutoCANParam::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< AutoCANParam> AutoCANParam::Instances() { return ::Udm::InstantiatedAttr< AutoCANParam>(impl); }
	AutoCANParam AutoCANParam::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< AutoCANParam> AutoCANParam::Derived() { return ::Udm::DerivedAttr< AutoCANParam>(impl); }
	::Udm::ArchetypeAttr< AutoCANParam> AutoCANParam::Archetype() const { return ::Udm::ArchetypeAttr< AutoCANParam>(impl); }
	::Udm::IntegerAttr AutoCANParam::SPN() const { return ::Udm::IntegerAttr(impl, meta_SPN); }
	::Udm::ParentAttr< ::ESMoL::Message> AutoCANParam::parent() const { return ::Udm::ParentAttr< ::ESMoL::Message>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class AutoCANParam::meta;
	::Uml::Attribute AutoCANParam::meta_SPN;

	AutoCANMessage::AutoCANMessage() {}
	AutoCANMessage::AutoCANMessage(::Udm::ObjectImpl *impl) : CANMessage(impl), UDM_OBJECT(impl) {}
	AutoCANMessage::AutoCANMessage(const AutoCANMessage &master) : CANMessage(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	AutoCANMessage::AutoCANMessage(AutoCANMessage &&master) : CANMessage(master), UDM_OBJECT(master) {};

	AutoCANMessage AutoCANMessage::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	AutoCANMessage& AutoCANMessage::operator=(AutoCANMessage &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	AutoCANMessage AutoCANMessage::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	AutoCANMessage AutoCANMessage::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	AutoCANMessage AutoCANMessage::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< AutoCANMessage> AutoCANMessage::Instances() { return ::Udm::InstantiatedAttr< AutoCANMessage>(impl); }
	AutoCANMessage AutoCANMessage::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< AutoCANMessage> AutoCANMessage::Derived() { return ::Udm::DerivedAttr< AutoCANMessage>(impl); }
	::Udm::ArchetypeAttr< AutoCANMessage> AutoCANMessage::Archetype() const { return ::Udm::ArchetypeAttr< AutoCANMessage>(impl); }
	::Udm::IntegerAttr AutoCANMessage::PGN() const { return ::Udm::IntegerAttr(impl, meta_PGN); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> AutoCANMessage::parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class AutoCANMessage::meta;
	::Uml::Attribute AutoCANMessage::meta_PGN;

	FieldDataType::FieldDataType() {}
	FieldDataType::FieldDataType(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	FieldDataType::FieldDataType(const FieldDataType &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	FieldDataType::FieldDataType(FieldDataType &&master) : MgaObject(master), UDM_OBJECT(master) {};

	FieldDataType FieldDataType::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	FieldDataType& FieldDataType::operator=(FieldDataType &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	FieldDataType FieldDataType::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	FieldDataType FieldDataType::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	FieldDataType FieldDataType::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< FieldDataType> FieldDataType::Instances() { return ::Udm::InstantiatedAttr< FieldDataType>(impl); }
	FieldDataType FieldDataType::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< FieldDataType> FieldDataType::Derived() { return ::Udm::DerivedAttr< FieldDataType>(impl); }
	::Udm::ArchetypeAttr< FieldDataType> FieldDataType::Archetype() const { return ::Udm::ArchetypeAttr< FieldDataType>(impl); }
	::Udm::IntegerAttr FieldDataType::NumBits() const { return ::Udm::IntegerAttr(impl, meta_NumBits); }
	::Udm::StringAttr FieldDataType::InitialValue() const { return ::Udm::StringAttr(impl, meta_InitialValue); }
	::Udm::ParentAttr< ::ESMoL::MsgPort> FieldDataType::MsgPort_parent() const { return ::Udm::ParentAttr< ::ESMoL::MsgPort>(impl, meta_MsgPort_parent); }
	::Udm::ParentAttr< ::ESMoL::MsgPort> FieldDataType::parent() const { return ::Udm::ParentAttr< ::ESMoL::MsgPort>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class FieldDataType::meta;
	::Uml::Attribute FieldDataType::meta_NumBits;
	::Uml::Attribute FieldDataType::meta_InitialValue;
	::Uml::CompositionParentRole FieldDataType::meta_MsgPort_parent;

	BitField::BitField() {}
	BitField::BitField(::Udm::ObjectImpl *impl) : FieldDataType(impl), UDM_OBJECT(impl) {}
	BitField::BitField(const BitField &master) : FieldDataType(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	BitField::BitField(BitField &&master) : FieldDataType(master), UDM_OBJECT(master) {};

	BitField BitField::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BitField& BitField::operator=(BitField &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BitField BitField::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BitField BitField::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BitField BitField::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BitField> BitField::Instances() { return ::Udm::InstantiatedAttr< BitField>(impl); }
	BitField BitField::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BitField> BitField::Derived() { return ::Udm::DerivedAttr< BitField>(impl); }
	::Udm::ArchetypeAttr< BitField> BitField::Archetype() const { return ::Udm::ArchetypeAttr< BitField>(impl); }
	::Udm::ParentAttr< ::ESMoL::MsgPort> BitField::parent() const { return ::Udm::ParentAttr< ::ESMoL::MsgPort>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BitField::meta;

	ValueType::ValueType() {}
	ValueType::ValueType(::Udm::ObjectImpl *impl) : FieldDataType(impl), UDM_OBJECT(impl) {}
	ValueType::ValueType(const ValueType &master) : FieldDataType(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ValueType::ValueType(ValueType &&master) : FieldDataType(master), UDM_OBJECT(master) {};

	ValueType ValueType::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ValueType& ValueType::operator=(ValueType &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ValueType ValueType::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ValueType ValueType::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ValueType ValueType::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ValueType> ValueType::Instances() { return ::Udm::InstantiatedAttr< ValueType>(impl); }
	ValueType ValueType::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ValueType> ValueType::Derived() { return ::Udm::DerivedAttr< ValueType>(impl); }
	::Udm::ArchetypeAttr< ValueType> ValueType::Archetype() const { return ::Udm::ArchetypeAttr< ValueType>(impl); }
	::Udm::StringAttr ValueType::Scale() const { return ::Udm::StringAttr(impl, meta_Scale); }
	::Udm::BooleanAttr ValueType::Signed() const { return ::Udm::BooleanAttr(impl, meta_Signed); }
	::Udm::StringAttr ValueType::DataType() const { return ::Udm::StringAttr(impl, meta_DataType); }
	::Udm::StringAttr ValueType::MinValue() const { return ::Udm::StringAttr(impl, meta_MinValue); }
	::Udm::StringAttr ValueType::MaxValue() const { return ::Udm::StringAttr(impl, meta_MaxValue); }
	::Udm::StringAttr ValueType::Units() const { return ::Udm::StringAttr(impl, meta_Units); }
	::Udm::StringAttr ValueType::Offset() const { return ::Udm::StringAttr(impl, meta_Offset); }
	::Udm::ParentAttr< ::ESMoL::MsgPort> ValueType::parent() const { return ::Udm::ParentAttr< ::ESMoL::MsgPort>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ValueType::meta;
	::Uml::Attribute ValueType::meta_Scale;
	::Uml::Attribute ValueType::meta_Signed;
	::Uml::Attribute ValueType::meta_DataType;
	::Uml::Attribute ValueType::meta_MinValue;
	::Uml::Attribute ValueType::meta_MaxValue;
	::Uml::Attribute ValueType::meta_Units;
	::Uml::Attribute ValueType::meta_Offset;

	TTBus::TTBus() {}
	TTBus::TTBus(::Udm::ObjectImpl *impl) : Bus(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	TTBus::TTBus(const TTBus &master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TTBus::TTBus(TTBus &&master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {};

	TTBus TTBus::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TTBus& TTBus::operator=(TTBus &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TTBus TTBus::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TTBus TTBus::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TTBus TTBus::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TTBus> TTBus::Instances() { return ::Udm::InstantiatedAttr< TTBus>(impl); }
	TTBus TTBus::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TTBus> TTBus::Derived() { return ::Udm::DerivedAttr< TTBus>(impl); }
	::Udm::ArchetypeAttr< TTBus> TTBus::Archetype() const { return ::Udm::ArchetypeAttr< TTBus>(impl); }
	::Udm::StringAttr TTBus::Hyperperiod() const { return ::Udm::StringAttr(impl, meta_Hyperperiod); }
	::Udm::StringAttr TTBus::TTSetupTime() const { return ::Udm::StringAttr(impl, meta_TTSetupTime); }
	::Udm::StringAttr TTBus::SlotSize() const { return ::Udm::StringAttr(impl, meta_SlotSize); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> TTBus::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TTBus::meta;
	::Uml::Attribute TTBus::meta_Hyperperiod;
	::Uml::Attribute TTBus::meta_TTSetupTime;
	::Uml::Attribute TTBus::meta_SlotSize;

	OldBus::OldBus() {}
	OldBus::OldBus(::Udm::ObjectImpl *impl) : Bus(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	OldBus::OldBus(const OldBus &master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OldBus::OldBus(OldBus &&master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {};

	OldBus OldBus::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OldBus& OldBus::operator=(OldBus &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OldBus OldBus::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OldBus OldBus::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OldBus OldBus::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OldBus> OldBus::Instances() { return ::Udm::InstantiatedAttr< OldBus>(impl); }
	OldBus OldBus::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OldBus> OldBus::Derived() { return ::Udm::DerivedAttr< OldBus>(impl); }
	::Udm::ArchetypeAttr< OldBus> OldBus::Archetype() const { return ::Udm::ArchetypeAttr< OldBus>(impl); }
	::Udm::StringAttr OldBus::Medium() const { return ::Udm::StringAttr(impl, meta_Medium); }
	::Udm::IntegerAttr OldBus::FrameSize() const { return ::Udm::IntegerAttr(impl, meta_FrameSize); }
	::Udm::StringAttr OldBus::OverheadTime() const { return ::Udm::StringAttr(impl, meta_OverheadTime); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> OldBus::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OldBus::meta;
	::Uml::Attribute OldBus::meta_Medium;
	::Uml::Attribute OldBus::meta_FrameSize;
	::Uml::Attribute OldBus::meta_OverheadTime;

	CANBus::CANBus() {}
	CANBus::CANBus(::Udm::ObjectImpl *impl) : Bus(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	CANBus::CANBus(const CANBus &master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CANBus::CANBus(CANBus &&master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {};

	CANBus CANBus::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CANBus& CANBus::operator=(CANBus &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CANBus CANBus::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CANBus CANBus::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CANBus CANBus::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CANBus> CANBus::Instances() { return ::Udm::InstantiatedAttr< CANBus>(impl); }
	CANBus CANBus::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CANBus> CANBus::Derived() { return ::Udm::DerivedAttr< CANBus>(impl); }
	::Udm::ArchetypeAttr< CANBus> CANBus::Archetype() const { return ::Udm::ArchetypeAttr< CANBus>(impl); }
	::Udm::StringAttr CANBus::Hyperperiod() const { return ::Udm::StringAttr(impl, meta_Hyperperiod); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> CANBus::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class CANBus::meta;
	::Uml::Attribute CANBus::meta_Hyperperiod;

	Link::Link() {}
	Link::Link(::Udm::ObjectImpl *impl) : Bus(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Link::Link(const Link &master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Link::Link(Link &&master) : Bus(master), MgaObject(master), UDM_OBJECT(master) {};

	Link Link::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Link& Link::operator=(Link &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Link Link::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Link Link::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Link Link::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Link> Link::Instances() { return ::Udm::InstantiatedAttr< Link>(impl); }
	Link Link::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Link> Link::Derived() { return ::Udm::DerivedAttr< Link>(impl); }
	::Udm::ArchetypeAttr< Link> Link::Archetype() const { return ::Udm::ArchetypeAttr< Link>(impl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Link::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Link::meta;

	SerialLink::SerialLink() {}
	SerialLink::SerialLink(::Udm::ObjectImpl *impl) : Link(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	SerialLink::SerialLink(const SerialLink &master) : Link(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SerialLink::SerialLink(SerialLink &&master) : Link(master), MgaObject(master), UDM_OBJECT(master) {};

	SerialLink SerialLink::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SerialLink& SerialLink::operator=(SerialLink &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SerialLink SerialLink::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SerialLink SerialLink::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SerialLink SerialLink::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SerialLink> SerialLink::Instances() { return ::Udm::InstantiatedAttr< SerialLink>(impl); }
	SerialLink SerialLink::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SerialLink> SerialLink::Derived() { return ::Udm::DerivedAttr< SerialLink>(impl); }
	::Udm::ArchetypeAttr< SerialLink> SerialLink::Archetype() const { return ::Udm::ArchetypeAttr< SerialLink>(impl); }
	::Udm::IntegerAttr SerialLink::DataBits() const { return ::Udm::IntegerAttr(impl, meta_DataBits); }
	::Udm::BooleanAttr SerialLink::Parity() const { return ::Udm::BooleanAttr(impl, meta_Parity); }
	::Udm::IntegerAttr SerialLink::StopBits() const { return ::Udm::IntegerAttr(impl, meta_StopBits); }
	::Udm::StringAttr SerialLink::FlowControl() const { return ::Udm::StringAttr(impl, meta_FlowControl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> SerialLink::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class SerialLink::meta;
	::Uml::Attribute SerialLink::meta_DataBits;
	::Uml::Attribute SerialLink::meta_Parity;
	::Uml::Attribute SerialLink::meta_StopBits;
	::Uml::Attribute SerialLink::meta_FlowControl;

	IOPortExp::IOPortExp() {}
	IOPortExp::IOPortExp(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	IOPortExp::IOPortExp(const IOPortExp &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IOPortExp::IOPortExp(IOPortExp &&master) : MgaObject(master), UDM_OBJECT(master) {};

	IOPortExp IOPortExp::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IOPortExp& IOPortExp::operator=(IOPortExp &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IOPortExp IOPortExp::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IOPortExp IOPortExp::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IOPortExp IOPortExp::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IOPortExp> IOPortExp::Instances() { return ::Udm::InstantiatedAttr< IOPortExp>(impl); }
	IOPortExp IOPortExp::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IOPortExp> IOPortExp::Derived() { return ::Udm::DerivedAttr< IOPortExp>(impl); }
	::Udm::ArchetypeAttr< IOPortExp> IOPortExp::Archetype() const { return ::Udm::ArchetypeAttr< IOPortExp>(impl); }
	::Udm::AClassAssocAttr< IOPortAssignment, IOPortInfoBase> IOPortExp::srcIOPortAssignment() const { return ::Udm::AClassAssocAttr< IOPortAssignment, IOPortInfoBase>(impl, meta_srcIOPortAssignment, meta_srcIOPortAssignment_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> IOPortExp::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IOPortExp::meta;
	::Uml::AssociationRole IOPortExp::meta_srcIOPortAssignment;
	::Uml::AssociationRole IOPortExp::meta_srcIOPortAssignment_rev;

	IOPortInfo::IOPortInfo() {}
	IOPortInfo::IOPortInfo(::Udm::ObjectImpl *impl) : IOPortInfoBase(impl), UDM_OBJECT(impl) {}
	IOPortInfo::IOPortInfo(const IOPortInfo &master) : IOPortInfoBase(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IOPortInfo::IOPortInfo(IOPortInfo &&master) : IOPortInfoBase(master), UDM_OBJECT(master) {};

	IOPortInfo IOPortInfo::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IOPortInfo& IOPortInfo::operator=(IOPortInfo &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IOPortInfo IOPortInfo::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IOPortInfo IOPortInfo::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IOPortInfo IOPortInfo::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IOPortInfo> IOPortInfo::Instances() { return ::Udm::InstantiatedAttr< IOPortInfo>(impl); }
	IOPortInfo IOPortInfo::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IOPortInfo> IOPortInfo::Derived() { return ::Udm::DerivedAttr< IOPortInfo>(impl); }
	::Udm::ArchetypeAttr< IOPortInfo> IOPortInfo::Archetype() const { return ::Udm::ArchetypeAttr< IOPortInfo>(impl); }
	::Udm::StringAttr IOPortInfo::DataSize() const { return ::Udm::StringAttr(impl, meta_DataSize); }
	::Udm::StringAttr IOPortInfo::DataInit() const { return ::Udm::StringAttr(impl, meta_DataInit); }
	::Udm::StringAttr IOPortInfo::DataMin() const { return ::Udm::StringAttr(impl, meta_DataMin); }
	::Udm::StringAttr IOPortInfo::DataMax() const { return ::Udm::StringAttr(impl, meta_DataMax); }
	::Udm::StringAttr IOPortInfo::Scale() const { return ::Udm::StringAttr(impl, meta_Scale); }
	::Udm::StringAttr IOPortInfo::Offset() const { return ::Udm::StringAttr(impl, meta_Offset); }
	::Udm::AssocAttr< IOPortInfoRef> IOPortInfo::referedbyIOPortInfoRef() const { return ::Udm::AssocAttr< IOPortInfoRef>(impl, meta_referedbyIOPortInfoRef); }
	::Udm::ParentAttr< ::Udm::Object> IOPortInfo::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IOPortInfo::meta;
	::Uml::Attribute IOPortInfo::meta_DataSize;
	::Uml::Attribute IOPortInfo::meta_DataInit;
	::Uml::Attribute IOPortInfo::meta_DataMin;
	::Uml::Attribute IOPortInfo::meta_DataMax;
	::Uml::Attribute IOPortInfo::meta_Scale;
	::Uml::Attribute IOPortInfo::meta_Offset;
	::Uml::AssociationRole IOPortInfo::meta_referedbyIOPortInfoRef;

	IOPortInfoRef::IOPortInfoRef() {}
	IOPortInfoRef::IOPortInfoRef(::Udm::ObjectImpl *impl) : IOPortInfoBase(impl), UDM_OBJECT(impl) {}
	IOPortInfoRef::IOPortInfoRef(const IOPortInfoRef &master) : IOPortInfoBase(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IOPortInfoRef::IOPortInfoRef(IOPortInfoRef &&master) : IOPortInfoBase(master), UDM_OBJECT(master) {};

	IOPortInfoRef IOPortInfoRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IOPortInfoRef& IOPortInfoRef::operator=(IOPortInfoRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IOPortInfoRef IOPortInfoRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IOPortInfoRef IOPortInfoRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IOPortInfoRef IOPortInfoRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IOPortInfoRef> IOPortInfoRef::Instances() { return ::Udm::InstantiatedAttr< IOPortInfoRef>(impl); }
	IOPortInfoRef IOPortInfoRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IOPortInfoRef> IOPortInfoRef::Derived() { return ::Udm::DerivedAttr< IOPortInfoRef>(impl); }
	::Udm::ArchetypeAttr< IOPortInfoRef> IOPortInfoRef::Archetype() const { return ::Udm::ArchetypeAttr< IOPortInfoRef>(impl); }
	::Udm::PointerAttr< IOPortInfo> IOPortInfoRef::ref() const { return ::Udm::PointerAttr< IOPortInfo>(impl, meta_ref); }
	::Udm::ParentAttr< ::Udm::Object> IOPortInfoRef::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IOPortInfoRef::meta;
	::Uml::AssociationRole IOPortInfoRef::meta_ref;

	IOPortAssignment::IOPortAssignment() {}
	IOPortAssignment::IOPortAssignment(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	IOPortAssignment::IOPortAssignment(const IOPortAssignment &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IOPortAssignment::IOPortAssignment(IOPortAssignment &&master) : MgaObject(master), UDM_OBJECT(master) {};

	IOPortAssignment IOPortAssignment::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IOPortAssignment& IOPortAssignment::operator=(IOPortAssignment &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IOPortAssignment IOPortAssignment::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IOPortAssignment IOPortAssignment::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IOPortAssignment IOPortAssignment::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IOPortAssignment> IOPortAssignment::Instances() { return ::Udm::InstantiatedAttr< IOPortAssignment>(impl); }
	IOPortAssignment IOPortAssignment::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IOPortAssignment> IOPortAssignment::Derived() { return ::Udm::DerivedAttr< IOPortAssignment>(impl); }
	::Udm::ArchetypeAttr< IOPortAssignment> IOPortAssignment::Archetype() const { return ::Udm::ArchetypeAttr< IOPortAssignment>(impl); }
	::Udm::ParentAttr< ::Udm::Object> IOPortAssignment::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::IOPortInfoBase> IOPortAssignment::srcIOPortAssignment_end() const { return ::Udm::AssocEndAttr< ::ESMoL::IOPortInfoBase>(impl, meta_srcIOPortAssignment_end_); }
	::Udm::AssocEndAttr< ::ESMoL::IOPortExp> IOPortAssignment::dstIOPortAssignment_end() const { return ::Udm::AssocEndAttr< ::ESMoL::IOPortExp>(impl, meta_dstIOPortAssignment_end_); }

	::Uml::Class IOPortAssignment::meta;
	::Uml::AssociationRole IOPortAssignment::meta_srcIOPortAssignment_end_;
	::Uml::AssociationRole IOPortAssignment::meta_dstIOPortAssignment_end_;

	IOPortInfoBase::IOPortInfoBase() {}
	IOPortInfoBase::IOPortInfoBase(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	IOPortInfoBase::IOPortInfoBase(const IOPortInfoBase &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IOPortInfoBase::IOPortInfoBase(IOPortInfoBase &&master) : MgaObject(master), UDM_OBJECT(master) {};

	IOPortInfoBase IOPortInfoBase::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IOPortInfoBase& IOPortInfoBase::operator=(IOPortInfoBase &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IOPortInfoBase IOPortInfoBase::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IOPortInfoBase IOPortInfoBase::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IOPortInfoBase IOPortInfoBase::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IOPortInfoBase> IOPortInfoBase::Instances() { return ::Udm::InstantiatedAttr< IOPortInfoBase>(impl); }
	IOPortInfoBase IOPortInfoBase::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IOPortInfoBase> IOPortInfoBase::Derived() { return ::Udm::DerivedAttr< IOPortInfoBase>(impl); }
	::Udm::ArchetypeAttr< IOPortInfoBase> IOPortInfoBase::Archetype() const { return ::Udm::ArchetypeAttr< IOPortInfoBase>(impl); }
	::Udm::AClassAssocAttr< IOPortAssignment, IOPortExp> IOPortInfoBase::dstIOPortAssignment() const { return ::Udm::AClassAssocAttr< IOPortAssignment, IOPortExp>(impl, meta_dstIOPortAssignment, meta_dstIOPortAssignment_rev); }
	::Udm::ParentAttr< ::Udm::Object> IOPortInfoBase::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IOPortInfoBase::meta;
	::Uml::AssociationRole IOPortInfoBase::meta_dstIOPortAssignment;
	::Uml::AssociationRole IOPortInfoBase::meta_dstIOPortAssignment_rev;

	OldTask::OldTask() {}
	OldTask::OldTask(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	OldTask::OldTask(const OldTask &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OldTask::OldTask(OldTask &&master) : MgaObject(master), UDM_OBJECT(master) {};

	OldTask OldTask::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OldTask& OldTask::operator=(OldTask &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OldTask OldTask::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OldTask OldTask::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OldTask OldTask::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OldTask> OldTask::Instances() { return ::Udm::InstantiatedAttr< OldTask>(impl); }
	OldTask OldTask::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OldTask> OldTask::Derived() { return ::Udm::DerivedAttr< OldTask>(impl); }
	::Udm::ArchetypeAttr< OldTask> OldTask::Archetype() const { return ::Udm::ArchetypeAttr< OldTask>(impl); }
	::Udm::IntegerAttr OldTask::Priority() const { return ::Udm::IntegerAttr(impl, meta_Priority); }
	::Udm::StringAttr OldTask::TaskType() const { return ::Udm::StringAttr(impl, meta_TaskType); }
	::Udm::IntegerAttr OldTask::Activation() const { return ::Udm::IntegerAttr(impl, meta_Activation); }
	::Udm::BooleanAttr OldTask::AutoStart() const { return ::Udm::BooleanAttr(impl, meta_AutoStart); }
	::Udm::StringAttr OldTask::Preemption() const { return ::Udm::StringAttr(impl, meta_Preemption); }
	::Udm::BooleanAttr OldTask::Cyclic() const { return ::Udm::BooleanAttr(impl, meta_Cyclic); }
	::Udm::IntegerAttr OldTask::CycleTime() const { return ::Udm::IntegerAttr(impl, meta_CycleTime); }
	::Udm::ParentAttr< ::Udm::Object> OldTask::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OldTask::meta;
	::Uml::Attribute OldTask::meta_Priority;
	::Uml::Attribute OldTask::meta_TaskType;
	::Uml::Attribute OldTask::meta_Activation;
	::Uml::Attribute OldTask::meta_AutoStart;
	::Uml::Attribute OldTask::meta_Preemption;
	::Uml::Attribute OldTask::meta_Cyclic;
	::Uml::Attribute OldTask::meta_CycleTime;

	ArchitectureLibrary::ArchitectureLibrary() {}
	ArchitectureLibrary::ArchitectureLibrary(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	ArchitectureLibrary::ArchitectureLibrary(const ArchitectureLibrary &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ArchitectureLibrary::ArchitectureLibrary(ArchitectureLibrary &&master) : UDM_OBJECT(master) {};

	ArchitectureLibrary ArchitectureLibrary::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ArchitectureLibrary& ArchitectureLibrary::operator=(ArchitectureLibrary &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ArchitectureLibrary ArchitectureLibrary::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ArchitectureLibrary ArchitectureLibrary::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ArchitectureLibrary ArchitectureLibrary::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ArchitectureLibrary> ArchitectureLibrary::Instances() { return ::Udm::InstantiatedAttr< ArchitectureLibrary>(impl); }
	ArchitectureLibrary ArchitectureLibrary::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ArchitectureLibrary> ArchitectureLibrary::Derived() { return ::Udm::DerivedAttr< ArchitectureLibrary>(impl); }
	::Udm::ArchetypeAttr< ArchitectureLibrary> ArchitectureLibrary::Archetype() const { return ::Udm::ArchetypeAttr< ArchitectureLibrary>(impl); }
	::Udm::StringAttr ArchitectureLibrary::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::SystemTypes> ArchitectureLibrary::SystemTypes_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes>(impl, meta_SystemTypes_children); }
	::Udm::ChildrenAttr< ::ESMoL::SystemTypes> ArchitectureLibrary::SystemTypes_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> ArchitectureLibrary::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> ArchitectureLibrary::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> ArchitectureLibrary::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ArchitectureLibrary::meta;
	::Uml::Attribute ArchitectureLibrary::meta_name;
	::Uml::CompositionChildRole ArchitectureLibrary::meta_SystemTypes_children;
	::Uml::CompositionParentRole ArchitectureLibrary::meta_RootFolder_parent;

	SystemTypes::SystemTypes() {}
	SystemTypes::SystemTypes(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	SystemTypes::SystemTypes(const SystemTypes &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	SystemTypes::SystemTypes(SystemTypes &&master) : MgaObject(master), UDM_OBJECT(master) {};

	SystemTypes SystemTypes::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	SystemTypes& SystemTypes::operator=(SystemTypes &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	SystemTypes SystemTypes::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	SystemTypes SystemTypes::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	SystemTypes SystemTypes::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< SystemTypes> SystemTypes::Instances() { return ::Udm::InstantiatedAttr< SystemTypes>(impl); }
	SystemTypes SystemTypes::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< SystemTypes> SystemTypes::Derived() { return ::Udm::DerivedAttr< SystemTypes>(impl); }
	::Udm::ArchetypeAttr< SystemTypes> SystemTypes::Archetype() const { return ::Udm::ArchetypeAttr< SystemTypes>(impl); }
	::Udm::ChildrenAttr< ::ESMoL::Message> SystemTypes::Message_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Message>(impl, meta_Message_children); }
	::Udm::ChildrenAttr< ::ESMoL::Component> SystemTypes::Component_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Component>(impl, meta_Component_children); }
	::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base> SystemTypes::MessageRef_RefersTo_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base> SystemTypes::ComponentRef_RefersTo_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CANMessage> SystemTypes::CANMessage_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CANMessage>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::AutoCANMessage> SystemTypes::AutoCANMessage_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::AutoCANMessage>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Message> SystemTypes::Message_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Message>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PlantComponent> SystemTypes::PlantComponent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PlantComponent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Component> SystemTypes::Component_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Component>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> SystemTypes::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::ArchitectureLibrary> SystemTypes::ArchitectureLibrary_parent() const { return ::Udm::ParentAttr< ::ESMoL::ArchitectureLibrary>(impl, meta_ArchitectureLibrary_parent); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> SystemTypes::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::Udm::Object> SystemTypes::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class SystemTypes::meta;
	::Uml::CompositionChildRole SystemTypes::meta_Message_children;
	::Uml::CompositionChildRole SystemTypes::meta_Component_children;
	::Uml::CompositionParentRole SystemTypes::meta_ArchitectureLibrary_parent;
	::Uml::CompositionParentRole SystemTypes::meta_DesignFolder_parent;

	Connector::Connector() {}
	Connector::Connector(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Connector::Connector(const Connector &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Connector::Connector(Connector &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Connector Connector::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Connector& Connector::operator=(Connector &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Connector Connector::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Connector Connector::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Connector Connector::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Connector> Connector::Instances() { return ::Udm::InstantiatedAttr< Connector>(impl); }
	Connector Connector::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Connector> Connector::Derived() { return ::Udm::DerivedAttr< Connector>(impl); }
	::Udm::ArchetypeAttr< Connector> Connector::Archetype() const { return ::Udm::ArchetypeAttr< Connector>(impl); }
	::Udm::StringAttr Connector::ConnectionType() const { return ::Udm::StringAttr(impl, meta_ConnectionType); }
	::Udm::PointerAttr< Connector_dstConnector_RPContainer_Base> Connector::dstConnector__rp_helper() const { return ::Udm::PointerAttr< Connector_dstConnector_RPContainer_Base>(impl, meta_dstConnector__rp_helper); }
	::Udm::PointerAttr< Connector_srcConnector_RPContainer_Base> Connector::srcConnector__rp_helper() const { return ::Udm::PointerAttr< Connector_srcConnector_RPContainer_Base>(impl, meta_srcConnector__rp_helper); }
	::Udm::ParentAttr< ::ESMoL::Component> Connector::Component_parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, meta_Component_parent); }
	::Udm::ParentAttr< ::ESMoL::Component> Connector::parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::Output> Connector::srcConnector_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Output>(impl, meta_srcConnector_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::Output, Connector::srcConnector_chain_t > Connector::srcConnector_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::Output, Connector::srcConnector_chain_t >(impl, meta_srcConnector_end_); }
	::Udm::AssocEndAttr< ::ESMoL::Input> Connector::dstConnector_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Input>(impl, meta_dstConnector_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::Input, Connector::dstConnector_chain_t > Connector::dstConnector_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::Input, Connector::dstConnector_chain_t >(impl, meta_dstConnector_end_); }

	::Uml::Class Connector::meta;
	::Uml::Attribute Connector::meta_ConnectionType;
	::Uml::AssociationRole Connector::meta_dstConnector__rp_helper;
	::Uml::AssociationRole Connector::meta_srcConnector__rp_helper;
	::Uml::CompositionParentRole Connector::meta_Component_parent;
	::Uml::AssociationRole Connector::meta_srcConnector_end_;
	::Uml::AssociationRole Connector::meta_dstConnector_end_;

	ComponentBase::ComponentBase() {}
	ComponentBase::ComponentBase(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ComponentBase::ComponentBase(const ComponentBase &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ComponentBase::ComponentBase(ComponentBase &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ComponentBase ComponentBase::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ComponentBase& ComponentBase::operator=(ComponentBase &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ComponentBase ComponentBase::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ComponentBase ComponentBase::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ComponentBase ComponentBase::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ComponentBase> ComponentBase::Instances() { return ::Udm::InstantiatedAttr< ComponentBase>(impl); }
	ComponentBase ComponentBase::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ComponentBase> ComponentBase::Derived() { return ::Udm::DerivedAttr< ComponentBase>(impl); }
	::Udm::ArchetypeAttr< ComponentBase> ComponentBase::Archetype() const { return ::Udm::ArchetypeAttr< ComponentBase>(impl); }
	::Udm::IntegerAttr ComponentBase::Period() const { return ::Udm::IntegerAttr(impl, meta_Period); }
	::Udm::IntegerAttr ComponentBase::Deadline() const { return ::Udm::IntegerAttr(impl, meta_Deadline); }
	::Udm::AClassAssocAttr< CompBreakout, TaskInst> ComponentBase::dstCompBreakout() const { return ::Udm::AClassAssocAttr< CompBreakout, TaskInst>(impl, meta_dstCompBreakout, meta_dstCompBreakout_rev); }
	::Udm::ParentAttr< ::ESMoL::FaultScenario> ComponentBase::FaultScenario_parent() const { return ::Udm::ParentAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_parent); }
	::Udm::ParentAttr< ::ESMoL::Component> ComponentBase::Component_parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, meta_Component_parent); }
	::Udm::ParentAttr< ::Udm::Object> ComponentBase::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ComponentBase::meta;
	::Uml::Attribute ComponentBase::meta_Period;
	::Uml::Attribute ComponentBase::meta_Deadline;
	::Uml::AssociationRole ComponentBase::meta_dstCompBreakout;
	::Uml::AssociationRole ComponentBase::meta_dstCompBreakout_rev;
	::Uml::CompositionParentRole ComponentBase::meta_FaultScenario_parent;
	::Uml::CompositionParentRole ComponentBase::meta_Component_parent;

	Message::Message() {}
	Message::Message(::Udm::ObjectImpl *impl) : MessageRef_RefersTo_Base(impl),MgaObject(impl), UDM_OBJECT(impl) {}
	Message::Message(const Message &master) : MessageRef_RefersTo_Base(master),MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Message::Message(Message &&master) : MessageRef_RefersTo_Base(master),MgaObject(master), UDM_OBJECT(master) {};

	Message Message::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Message& Message::operator=(Message &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Message Message::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Message Message::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Message Message::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Message> Message::Instances() { return ::Udm::InstantiatedAttr< Message>(impl); }
	Message Message::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Message> Message::Derived() { return ::Udm::DerivedAttr< Message>(impl); }
	::Udm::ArchetypeAttr< Message> Message::Archetype() const { return ::Udm::ArchetypeAttr< Message>(impl); }
	::Udm::StringAttr Message::MsgSize() const { return ::Udm::StringAttr(impl, meta_MsgSize); }
	::Udm::StringAttr Message::MsgMetaData() const { return ::Udm::StringAttr(impl, meta_MsgMetaData); }
	::Udm::ChildrenAttr< ::ESMoL::MsgPort> Message::MsgPort_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MsgPort>(impl, meta_MsgPort_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> Message::FaultToInput_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> Message::OutputToFault_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::AutoCANParam> Message::AutoCANParam_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::AutoCANParam>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IOPortExp> Message::IOPortExp_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MsgPort> Message::MsgPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MsgPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Output> Message::Output_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Output>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Input> Message::Input_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Input>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Message::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> Message::SystemTypes_parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, meta_SystemTypes_parent); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> Message::parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Message::meta;
	::Uml::Attribute Message::meta_MsgSize;
	::Uml::Attribute Message::meta_MsgMetaData;
	::Uml::CompositionChildRole Message::meta_MsgPort_children;
	::Uml::CompositionParentRole Message::meta_SystemTypes_parent;

	MsgPort::MsgPort() {}
	MsgPort::MsgPort(::Udm::ObjectImpl *impl) : Output(impl),Input(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	MsgPort::MsgPort(const MsgPort &master) : Output(master),Input(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	MsgPort::MsgPort(MsgPort &&master) : Output(master),Input(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	MsgPort MsgPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	MsgPort& MsgPort::operator=(MsgPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	MsgPort MsgPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	MsgPort MsgPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	MsgPort MsgPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< MsgPort> MsgPort::Instances() { return ::Udm::InstantiatedAttr< MsgPort>(impl); }
	MsgPort MsgPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< MsgPort> MsgPort::Derived() { return ::Udm::DerivedAttr< MsgPort>(impl); }
	::Udm::ArchetypeAttr< MsgPort> MsgPort::Archetype() const { return ::Udm::ArchetypeAttr< MsgPort>(impl); }
	::Udm::IntegerAttr MsgPort::MsgPortNum() const { return ::Udm::IntegerAttr(impl, meta_MsgPortNum); }
	::Udm::StringAttr MsgPort::FieldMetaData() const { return ::Udm::StringAttr(impl, meta_FieldMetaData); }
	::Udm::ChildrenAttr< ::ESMoL::FieldDataType> MsgPort::FieldDataType_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FieldDataType>(impl, meta_FieldDataType_children); }
	::Udm::ChildrenAttr< ::ESMoL::FieldDataType> MsgPort::FieldDataType_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FieldDataType>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::BitField> MsgPort::BitField_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BitField>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ValueType> MsgPort::ValueType_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ValueType>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> MsgPort::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Message> MsgPort::Message_parent() const { return ::Udm::ParentAttr< ::ESMoL::Message>(impl, meta_Message_parent); }
	::Udm::ParentAttr< ::ESMoL::Message> MsgPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Message>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class MsgPort::meta;
	::Uml::Attribute MsgPort::meta_MsgPortNum;
	::Uml::Attribute MsgPort::meta_FieldMetaData;
	::Uml::CompositionChildRole MsgPort::meta_FieldDataType_children;
	::Uml::CompositionParentRole MsgPort::meta_Message_parent;

	Output::Output() {}
	Output::Output(::Udm::ObjectImpl *impl) : OutputToFault_Members_Base(impl),IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Output::Output(const Output &master) : OutputToFault_Members_Base(master),IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Output::Output(Output &&master) : OutputToFault_Members_Base(master),IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	Output Output::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Output& Output::operator=(Output &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Output Output::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Output Output::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Output Output::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Output> Output::Instances() { return ::Udm::InstantiatedAttr< Output>(impl); }
	Output Output::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Output> Output::Derived() { return ::Udm::DerivedAttr< Output>(impl); }
	::Udm::ArchetypeAttr< Output> Output::Archetype() const { return ::Udm::ArchetypeAttr< Output>(impl); }
	::Udm::AClassAssocAttr< Connector, Input> Output::dstConnector() const { return ::Udm::AClassAssocAttr< Connector, Input>(impl, meta_dstConnector, meta_dstConnector_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> Output::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Output::meta;
	::Uml::AssociationRole Output::meta_dstConnector;
	::Uml::AssociationRole Output::meta_dstConnector_rev;

	Input::Input() {}
	Input::Input(::Udm::ObjectImpl *impl) : FaultToInput_Members_Base(impl),IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Input::Input(const Input &master) : FaultToInput_Members_Base(master),IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Input::Input(Input &&master) : FaultToInput_Members_Base(master),IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	Input Input::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Input& Input::operator=(Input &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Input Input::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Input Input::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Input Input::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Input> Input::Instances() { return ::Udm::InstantiatedAttr< Input>(impl); }
	Input Input::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Input> Input::Derived() { return ::Udm::DerivedAttr< Input>(impl); }
	::Udm::ArchetypeAttr< Input> Input::Archetype() const { return ::Udm::ArchetypeAttr< Input>(impl); }
	::Udm::AClassAssocAttr< Connector, Output> Input::srcConnector() const { return ::Udm::AClassAssocAttr< Connector, Output>(impl, meta_srcConnector, meta_srcConnector_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> Input::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Input::meta;
	::Uml::AssociationRole Input::meta_srcConnector;
	::Uml::AssociationRole Input::meta_srcConnector_rev;

	OutputEvent::OutputEvent() {}
	OutputEvent::OutputEvent(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	OutputEvent::OutputEvent(const OutputEvent &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OutputEvent::OutputEvent(OutputEvent &&master) : MgaObject(master), UDM_OBJECT(master) {};

	OutputEvent OutputEvent::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutputEvent& OutputEvent::operator=(OutputEvent &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutputEvent OutputEvent::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutputEvent OutputEvent::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutputEvent OutputEvent::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutputEvent> OutputEvent::Instances() { return ::Udm::InstantiatedAttr< OutputEvent>(impl); }
	OutputEvent OutputEvent::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutputEvent> OutputEvent::Derived() { return ::Udm::DerivedAttr< OutputEvent>(impl); }
	::Udm::ArchetypeAttr< OutputEvent> OutputEvent::Archetype() const { return ::Udm::ArchetypeAttr< OutputEvent>(impl); }
	::Udm::AClassAssocAttr< Trigger, InputEvent> OutputEvent::dstTrigger() const { return ::Udm::AClassAssocAttr< Trigger, InputEvent>(impl, meta_dstTrigger, meta_dstTrigger_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> OutputEvent::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OutputEvent::meta;
	::Uml::AssociationRole OutputEvent::meta_dstTrigger;
	::Uml::AssociationRole OutputEvent::meta_dstTrigger_rev;

	InputEvent::InputEvent() {}
	InputEvent::InputEvent(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	InputEvent::InputEvent(const InputEvent &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	InputEvent::InputEvent(InputEvent &&master) : MgaObject(master), UDM_OBJECT(master) {};

	InputEvent InputEvent::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	InputEvent& InputEvent::operator=(InputEvent &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	InputEvent InputEvent::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	InputEvent InputEvent::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	InputEvent InputEvent::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< InputEvent> InputEvent::Instances() { return ::Udm::InstantiatedAttr< InputEvent>(impl); }
	InputEvent InputEvent::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< InputEvent> InputEvent::Derived() { return ::Udm::DerivedAttr< InputEvent>(impl); }
	::Udm::ArchetypeAttr< InputEvent> InputEvent::Archetype() const { return ::Udm::ArchetypeAttr< InputEvent>(impl); }
	::Udm::AClassAssocAttr< Trigger, OutputEvent> InputEvent::srcTrigger() const { return ::Udm::AClassAssocAttr< Trigger, OutputEvent>(impl, meta_srcTrigger, meta_srcTrigger_rev); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> InputEvent::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class InputEvent::meta;
	::Uml::AssociationRole InputEvent::meta_srcTrigger;
	::Uml::AssociationRole InputEvent::meta_srcTrigger_rev;

	Trigger::Trigger() {}
	Trigger::Trigger(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Trigger::Trigger(const Trigger &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Trigger::Trigger(Trigger &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Trigger Trigger::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Trigger& Trigger::operator=(Trigger &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Trigger Trigger::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Trigger Trigger::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Trigger Trigger::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Trigger> Trigger::Instances() { return ::Udm::InstantiatedAttr< Trigger>(impl); }
	Trigger Trigger::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Trigger> Trigger::Derived() { return ::Udm::DerivedAttr< Trigger>(impl); }
	::Udm::ArchetypeAttr< Trigger> Trigger::Archetype() const { return ::Udm::ArchetypeAttr< Trigger>(impl); }
	::Udm::ParentAttr< ::ESMoL::Component> Trigger::Component_parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, meta_Component_parent); }
	::Udm::ParentAttr< ::ESMoL::Component> Trigger::parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::OutputEvent> Trigger::srcTrigger_end() const { return ::Udm::AssocEndAttr< ::ESMoL::OutputEvent>(impl, meta_srcTrigger_end_); }
	::Udm::AssocEndAttr< ::ESMoL::InputEvent> Trigger::dstTrigger_end() const { return ::Udm::AssocEndAttr< ::ESMoL::InputEvent>(impl, meta_dstTrigger_end_); }

	::Uml::Class Trigger::meta;
	::Uml::CompositionParentRole Trigger::meta_Component_parent;
	::Uml::AssociationRole Trigger::meta_srcTrigger_end_;
	::Uml::AssociationRole Trigger::meta_dstTrigger_end_;

	PlantComponent::PlantComponent() {}
	PlantComponent::PlantComponent(::Udm::ObjectImpl *impl) : Component(impl), UDM_OBJECT(impl) {}
	PlantComponent::PlantComponent(const PlantComponent &master) : Component(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PlantComponent::PlantComponent(PlantComponent &&master) : Component(master), UDM_OBJECT(master) {};

	PlantComponent PlantComponent::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PlantComponent& PlantComponent::operator=(PlantComponent &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PlantComponent PlantComponent::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PlantComponent PlantComponent::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PlantComponent PlantComponent::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PlantComponent> PlantComponent::Instances() { return ::Udm::InstantiatedAttr< PlantComponent>(impl); }
	PlantComponent PlantComponent::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PlantComponent> PlantComponent::Derived() { return ::Udm::DerivedAttr< PlantComponent>(impl); }
	::Udm::ArchetypeAttr< PlantComponent> PlantComponent::Archetype() const { return ::Udm::ArchetypeAttr< PlantComponent>(impl); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> PlantComponent::parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PlantComponent::meta;

	DesignFolder::DesignFolder() {}
	DesignFolder::DesignFolder(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	DesignFolder::DesignFolder(const DesignFolder &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DesignFolder::DesignFolder(DesignFolder &&master) : UDM_OBJECT(master) {};

	DesignFolder DesignFolder::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DesignFolder& DesignFolder::operator=(DesignFolder &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DesignFolder DesignFolder::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DesignFolder DesignFolder::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DesignFolder DesignFolder::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DesignFolder> DesignFolder::Instances() { return ::Udm::InstantiatedAttr< DesignFolder>(impl); }
	DesignFolder DesignFolder::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DesignFolder> DesignFolder::Derived() { return ::Udm::DerivedAttr< DesignFolder>(impl); }
	::Udm::ArchetypeAttr< DesignFolder> DesignFolder::Archetype() const { return ::Udm::ArchetypeAttr< DesignFolder>(impl); }
	::Udm::StringAttr DesignFolder::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::SystemTypes> DesignFolder::SystemTypes_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes>(impl, meta_SystemTypes_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModel> DesignFolder::FaultModel_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel>(impl, meta_FaultModel_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder> DesignFolder::FaultModelFolder_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder>(impl, meta_FaultModelFolder_children); }
	::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> DesignFolder::HardwareUnit_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_children); }
	::Udm::ChildrenAttr< ::ESMoL::TimingSheet> DesignFolder::TimingSheet_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet>(impl, meta_TimingSheet_children); }
	::Udm::ChildrenAttr< ::ESMoL::System> DesignFolder::System_children() const { return ::Udm::ChildrenAttr< ::ESMoL::System>(impl, meta_System_children); }
	::Udm::ChildrenAttr< ::ESMoL::ModelsFolder> DesignFolder::ModelsFolder_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ModelsFolder>(impl, meta_ModelsFolder_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultScenario> DesignFolder::FaultScenario_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultScenario>(impl, meta_FaultScenario_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultScenario> DesignFolder::FaultScenario_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultScenario>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModel> DesignFolder::FaultModel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder> DesignFolder::FaultModelFolder_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultModelFolder>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ModelsFolder> DesignFolder::ModelsFolder_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ModelsFolder>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::SystemTypes> DesignFolder::SystemTypes_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TimingSheet> DesignFolder::TimingSheet_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> DesignFolder::HardwareUnit_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HWElement> DesignFolder::HWElement_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::System> DesignFolder::System_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::System>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> DesignFolder::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> DesignFolder::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> DesignFolder::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DesignFolder::meta;
	::Uml::Attribute DesignFolder::meta_name;
	::Uml::CompositionChildRole DesignFolder::meta_SystemTypes_children;
	::Uml::CompositionChildRole DesignFolder::meta_FaultModel_children;
	::Uml::CompositionChildRole DesignFolder::meta_FaultModelFolder_children;
	::Uml::CompositionChildRole DesignFolder::meta_HardwareUnit_children;
	::Uml::CompositionChildRole DesignFolder::meta_TimingSheet_children;
	::Uml::CompositionChildRole DesignFolder::meta_System_children;
	::Uml::CompositionChildRole DesignFolder::meta_ModelsFolder_children;
	::Uml::CompositionChildRole DesignFolder::meta_FaultScenario_children;
	::Uml::CompositionParentRole DesignFolder::meta_RootFolder_parent;

	Component::Component() {}
	Component::Component(::Udm::ObjectImpl *impl) : ComponentRef_RefersTo_Base(impl),MgaObject(impl), UDM_OBJECT(impl) {}
	Component::Component(const Component &master) : ComponentRef_RefersTo_Base(master),MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Component::Component(Component &&master) : ComponentRef_RefersTo_Base(master),MgaObject(master), UDM_OBJECT(master) {};

	Component Component::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Component& Component::operator=(Component &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Component Component::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Component Component::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Component Component::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Component> Component::Instances() { return ::Udm::InstantiatedAttr< Component>(impl); }
	Component Component::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Component> Component::Derived() { return ::Udm::DerivedAttr< Component>(impl); }
	::Udm::ArchetypeAttr< Component> Component::Archetype() const { return ::Udm::ArchetypeAttr< Component>(impl); }
	::Udm::StringAttr Component::HeaderFiles() const { return ::Udm::StringAttr(impl, meta_HeaderFiles); }
	::Udm::StringAttr Component::SourceFiles() const { return ::Udm::StringAttr(impl, meta_SourceFiles); }
	::Udm::AssocAttr< TaskRef> Component::referedbyTaskRef() const { return ::Udm::AssocAttr< TaskRef>(impl, meta_referedbyTaskRef); }
	::Udm::ChildrenAttr< ::ESMoL::Trigger> Component::Trigger_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Trigger>(impl, meta_Trigger_children); }
	::Udm::ChildrenAttr< ::ESMoL::MessageRef> Component::MessageRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef>(impl, meta_MessageRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentBase> Component::ComponentBase_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase>(impl, meta_ComponentBase_children); }
	::Udm::ChildrenAttr< ::ESMoL::Connector> Component::Connector_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connector>(impl, meta_Connector_children); }
	::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base> Component::FaultToInput_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::FaultToInput_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base> Component::OutputToFault_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputToFault_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connector_srcConnector_RPContainer_Base> Component::Connector_srcConnector_RPContainer_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connector_srcConnector_RPContainer_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connector_dstConnector_RPContainer_Base> Component::Connector_dstConnector_RPContainer_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connector_dstConnector_RPContainer_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base> Component::MessageRef_RefersTo_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef_RefersTo_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> Component::CommMapping_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PetriNet> Component::PetriNet_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNet>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Executable> Component::Executable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Executable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CCode> Component::CCode_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CCode>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::SubsystemRef> Component::SubsystemRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SubsystemRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PetriNetRef> Component::PetriNetRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PetriNetRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IOPortExp> Component::IOPortExp_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IOPortExp>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connector> Component::Connector_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connector>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentBase> Component::ComponentBase_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Output> Component::Output_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Output>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Input> Component::Input_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Input>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputEvent> Component::OutputEvent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputEvent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::InputEvent> Component::InputEvent_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::InputEvent>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Trigger> Component::Trigger_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Trigger>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MessageRef> Component::MessageRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MessageRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Subsystem> Component::Subsystem_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Component::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> Component::SystemTypes_parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, meta_SystemTypes_parent); }
	::Udm::ParentAttr< ::ESMoL::SystemTypes> Component::parent() const { return ::Udm::ParentAttr< ::ESMoL::SystemTypes>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Component::meta;
	::Uml::Attribute Component::meta_HeaderFiles;
	::Uml::Attribute Component::meta_SourceFiles;
	::Uml::AssociationRole Component::meta_referedbyTaskRef;
	::Uml::CompositionChildRole Component::meta_Trigger_children;
	::Uml::CompositionChildRole Component::meta_MessageRef_children;
	::Uml::CompositionChildRole Component::meta_ComponentBase_children;
	::Uml::CompositionChildRole Component::meta_Connector_children;
	::Uml::CompositionParentRole Component::meta_SystemTypes_parent;

	MessageRef::MessageRef() {}
	MessageRef::MessageRef(::Udm::ObjectImpl *impl) : Connector_srcConnector_RPContainer_Base(impl),Connector_dstConnector_RPContainer_Base(impl),MessageRef_RefersTo_Base(impl),CommMapping_Members_Base(impl),Executable(impl),Output(impl),Input(impl),OutputEvent(impl),InputEvent(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	MessageRef::MessageRef(const MessageRef &master) : Connector_srcConnector_RPContainer_Base(master),Connector_dstConnector_RPContainer_Base(master),MessageRef_RefersTo_Base(master),CommMapping_Members_Base(master),Executable(master),Output(master),Input(master),OutputEvent(master),InputEvent(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	MessageRef::MessageRef(MessageRef &&master) : Connector_srcConnector_RPContainer_Base(master),Connector_dstConnector_RPContainer_Base(master),MessageRef_RefersTo_Base(master),CommMapping_Members_Base(master),Executable(master),Output(master),Input(master),OutputEvent(master),InputEvent(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	MessageRef MessageRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	MessageRef& MessageRef::operator=(MessageRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	MessageRef MessageRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	MessageRef MessageRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	MessageRef MessageRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< MessageRef> MessageRef::Instances() { return ::Udm::InstantiatedAttr< MessageRef>(impl); }
	MessageRef MessageRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< MessageRef> MessageRef::Derived() { return ::Udm::DerivedAttr< MessageRef>(impl); }
	::Udm::ArchetypeAttr< MessageRef> MessageRef::Archetype() const { return ::Udm::ArchetypeAttr< MessageRef>(impl); }
	::Udm::PointerAttr< MessageRef_RefersTo_Base> MessageRef::ref() const { return ::Udm::PointerAttr< MessageRef_RefersTo_Base>(impl, meta_ref); }
	::Udm::AClassAssocAttr< Dependency, MessageRef> MessageRef::dstDependency() const { return ::Udm::AClassAssocAttr< Dependency, MessageRef>(impl, meta_dstDependency, meta_dstDependency_rev); }
	::Udm::AClassAssocAttr< Dependency, MessageRef> MessageRef::srcDependency() const { return ::Udm::AClassAssocAttr< Dependency, MessageRef>(impl, meta_srcDependency, meta_srcDependency_rev); }
	::Udm::ParentAttr< ::ESMoL::Component> MessageRef::Component_parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, meta_Component_parent); }
	::Udm::ParentAttr< ::ESMoL::Component> MessageRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::Component>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class MessageRef::meta;
	::Uml::AssociationRole MessageRef::meta_ref;
	::Uml::AssociationRole MessageRef::meta_dstDependency;
	::Uml::AssociationRole MessageRef::meta_dstDependency_rev;
	::Uml::AssociationRole MessageRef::meta_srcDependency;
	::Uml::AssociationRole MessageRef::meta_srcDependency_rev;
	::Uml::CompositionParentRole MessageRef::meta_Component_parent;

	TimingConstraint::TimingConstraint() {}
	TimingConstraint::TimingConstraint(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TimingConstraint::TimingConstraint(const TimingConstraint &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TimingConstraint::TimingConstraint(TimingConstraint &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TimingConstraint TimingConstraint::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TimingConstraint& TimingConstraint::operator=(TimingConstraint &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TimingConstraint TimingConstraint::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TimingConstraint TimingConstraint::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TimingConstraint TimingConstraint::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TimingConstraint> TimingConstraint::Instances() { return ::Udm::InstantiatedAttr< TimingConstraint>(impl); }
	TimingConstraint TimingConstraint::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TimingConstraint> TimingConstraint::Derived() { return ::Udm::DerivedAttr< TimingConstraint>(impl); }
	::Udm::ArchetypeAttr< TimingConstraint> TimingConstraint::Archetype() const { return ::Udm::ArchetypeAttr< TimingConstraint>(impl); }
	::Udm::StringAttr TimingConstraint::Latency() const { return ::Udm::StringAttr(impl, meta_Latency); }
	::Udm::ParentAttr< ::ESMoL::TimingSheet> TimingConstraint::TimingSheet_parent() const { return ::Udm::ParentAttr< ::ESMoL::TimingSheet>(impl, meta_TimingSheet_parent); }
	::Udm::ParentAttr< ::ESMoL::TimingSheet> TimingConstraint::parent() const { return ::Udm::ParentAttr< ::ESMoL::TimingSheet>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::TaskRef> TimingConstraint::srcTimingConstraint_end() const { return ::Udm::AssocEndAttr< ::ESMoL::TaskRef>(impl, meta_srcTimingConstraint_end_); }
	::Udm::AssocEndAttr< ::ESMoL::TaskRef> TimingConstraint::dstTimingConstraint_end() const { return ::Udm::AssocEndAttr< ::ESMoL::TaskRef>(impl, meta_dstTimingConstraint_end_); }

	::Uml::Class TimingConstraint::meta;
	::Uml::Attribute TimingConstraint::meta_Latency;
	::Uml::CompositionParentRole TimingConstraint::meta_TimingSheet_parent;
	::Uml::AssociationRole TimingConstraint::meta_srcTimingConstraint_end_;
	::Uml::AssociationRole TimingConstraint::meta_dstTimingConstraint_end_;

	RequirementsLibrary::RequirementsLibrary() {}
	RequirementsLibrary::RequirementsLibrary(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	RequirementsLibrary::RequirementsLibrary(const RequirementsLibrary &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	RequirementsLibrary::RequirementsLibrary(RequirementsLibrary &&master) : UDM_OBJECT(master) {};

	RequirementsLibrary RequirementsLibrary::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	RequirementsLibrary& RequirementsLibrary::operator=(RequirementsLibrary &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	RequirementsLibrary RequirementsLibrary::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	RequirementsLibrary RequirementsLibrary::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	RequirementsLibrary RequirementsLibrary::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< RequirementsLibrary> RequirementsLibrary::Instances() { return ::Udm::InstantiatedAttr< RequirementsLibrary>(impl); }
	RequirementsLibrary RequirementsLibrary::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< RequirementsLibrary> RequirementsLibrary::Derived() { return ::Udm::DerivedAttr< RequirementsLibrary>(impl); }
	::Udm::ArchetypeAttr< RequirementsLibrary> RequirementsLibrary::Archetype() const { return ::Udm::ArchetypeAttr< RequirementsLibrary>(impl); }
	::Udm::StringAttr RequirementsLibrary::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::TimingSheet> RequirementsLibrary::TimingSheet_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet>(impl, meta_TimingSheet_children); }
	::Udm::ChildrenAttr< ::ESMoL::TimingSheet> RequirementsLibrary::TimingSheet_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TimingSheet>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> RequirementsLibrary::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> RequirementsLibrary::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> RequirementsLibrary::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class RequirementsLibrary::meta;
	::Uml::Attribute RequirementsLibrary::meta_name;
	::Uml::CompositionChildRole RequirementsLibrary::meta_TimingSheet_children;
	::Uml::CompositionParentRole RequirementsLibrary::meta_RootFolder_parent;

	TimingSheet::TimingSheet() {}
	TimingSheet::TimingSheet(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TimingSheet::TimingSheet(const TimingSheet &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TimingSheet::TimingSheet(TimingSheet &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TimingSheet TimingSheet::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TimingSheet& TimingSheet::operator=(TimingSheet &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TimingSheet TimingSheet::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TimingSheet TimingSheet::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TimingSheet TimingSheet::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TimingSheet> TimingSheet::Instances() { return ::Udm::InstantiatedAttr< TimingSheet>(impl); }
	TimingSheet TimingSheet::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TimingSheet> TimingSheet::Derived() { return ::Udm::DerivedAttr< TimingSheet>(impl); }
	::Udm::ArchetypeAttr< TimingSheet> TimingSheet::Archetype() const { return ::Udm::ArchetypeAttr< TimingSheet>(impl); }
	::Udm::ChildrenAttr< ::ESMoL::TaskRef> TimingSheet::TaskRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TaskRef>(impl, meta_TaskRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::TimingConstraint> TimingSheet::TimingConstraint_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TimingConstraint>(impl, meta_TimingConstraint_children); }
	::Udm::ChildrenAttr< ::ESMoL::TimingConstraint> TimingSheet::TimingConstraint_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TimingConstraint>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TaskRef> TimingSheet::TaskRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TaskRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> TimingSheet::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> TimingSheet::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RequirementsLibrary> TimingSheet::RequirementsLibrary_parent() const { return ::Udm::ParentAttr< ::ESMoL::RequirementsLibrary>(impl, meta_RequirementsLibrary_parent); }
	::Udm::ParentAttr< ::Udm::Object> TimingSheet::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TimingSheet::meta;
	::Uml::CompositionChildRole TimingSheet::meta_TaskRef_children;
	::Uml::CompositionChildRole TimingSheet::meta_TimingConstraint_children;
	::Uml::CompositionParentRole TimingSheet::meta_DesignFolder_parent;
	::Uml::CompositionParentRole TimingSheet::meta_RequirementsLibrary_parent;

	TaskRef::TaskRef() {}
	TaskRef::TaskRef(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TaskRef::TaskRef(const TaskRef &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TaskRef::TaskRef(TaskRef &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TaskRef TaskRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TaskRef& TaskRef::operator=(TaskRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TaskRef TaskRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TaskRef TaskRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TaskRef TaskRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TaskRef> TaskRef::Instances() { return ::Udm::InstantiatedAttr< TaskRef>(impl); }
	TaskRef TaskRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TaskRef> TaskRef::Derived() { return ::Udm::DerivedAttr< TaskRef>(impl); }
	::Udm::ArchetypeAttr< TaskRef> TaskRef::Archetype() const { return ::Udm::ArchetypeAttr< TaskRef>(impl); }
	::Udm::AClassAssocAttr< TimingConstraint, TaskRef> TaskRef::dstTimingConstraint() const { return ::Udm::AClassAssocAttr< TimingConstraint, TaskRef>(impl, meta_dstTimingConstraint, meta_dstTimingConstraint_rev); }
	::Udm::AClassAssocAttr< TimingConstraint, TaskRef> TaskRef::srcTimingConstraint() const { return ::Udm::AClassAssocAttr< TimingConstraint, TaskRef>(impl, meta_srcTimingConstraint, meta_srcTimingConstraint_rev); }
	::Udm::PointerAttr< Component> TaskRef::ref() const { return ::Udm::PointerAttr< Component>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::TimingSheet> TaskRef::TimingSheet_parent() const { return ::Udm::ParentAttr< ::ESMoL::TimingSheet>(impl, meta_TimingSheet_parent); }
	::Udm::ParentAttr< ::ESMoL::TimingSheet> TaskRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::TimingSheet>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TaskRef::meta;
	::Uml::AssociationRole TaskRef::meta_dstTimingConstraint;
	::Uml::AssociationRole TaskRef::meta_dstTimingConstraint_rev;
	::Uml::AssociationRole TaskRef::meta_srcTimingConstraint;
	::Uml::AssociationRole TaskRef::meta_srcTimingConstraint_rev;
	::Uml::AssociationRole TaskRef::meta_ref;
	::Uml::CompositionParentRole TaskRef::meta_TimingSheet_parent;

	Types::Types() {}
	Types::Types(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Types::Types(const Types &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Types::Types(Types &&master) : UDM_OBJECT(master) {};

	Types Types::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Types& Types::operator=(Types &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Types Types::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Types Types::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Types Types::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Types> Types::Instances() { return ::Udm::InstantiatedAttr< Types>(impl); }
	Types Types::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Types> Types::Derived() { return ::Udm::DerivedAttr< Types>(impl); }
	::Udm::ArchetypeAttr< Types> Types::Archetype() const { return ::Udm::ArchetypeAttr< Types>(impl); }
	::Udm::StringAttr Types::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::TypeBase> Types::TypeBase_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBase>(impl, meta_TypeBase_children); }
	::Udm::ChildrenAttr< ::ESMoL::TypeStruct> Types::TypeStruct_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeStruct>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Matrix> Types::Matrix_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Matrix>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TypeBase> Types::TypeBase_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Types::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> Types::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> Types::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Types::meta;
	::Uml::Attribute Types::meta_name;
	::Uml::CompositionChildRole Types::meta_TypeBase_children;
	::Uml::CompositionParentRole Types::meta_RootFolder_parent;

	TypeStruct::TypeStruct() {}
	TypeStruct::TypeStruct(::Udm::ObjectImpl *impl) : TypeBase(impl), UDM_OBJECT(impl) {}
	TypeStruct::TypeStruct(const TypeStruct &master) : TypeBase(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeStruct::TypeStruct(TypeStruct &&master) : TypeBase(master), UDM_OBJECT(master) {};

	TypeStruct TypeStruct::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeStruct& TypeStruct::operator=(TypeStruct &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeStruct TypeStruct::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeStruct TypeStruct::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeStruct TypeStruct::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeStruct> TypeStruct::Instances() { return ::Udm::InstantiatedAttr< TypeStruct>(impl); }
	TypeStruct TypeStruct::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeStruct> TypeStruct::Derived() { return ::Udm::DerivedAttr< TypeStruct>(impl); }
	::Udm::ArchetypeAttr< TypeStruct> TypeStruct::Archetype() const { return ::Udm::ArchetypeAttr< TypeStruct>(impl); }
	::Udm::IntegerAttr TypeStruct::MemberCount() const { return ::Udm::IntegerAttr(impl, meta_MemberCount); }
	::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> TypeStruct::TypeBaseRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef>(impl, meta_TypeBaseRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> TypeStruct::TypeBaseRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> TypeStruct::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Types> TypeStruct::parent() const { return ::Udm::ParentAttr< ::ESMoL::Types>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeStruct::meta;
	::Uml::Attribute TypeStruct::meta_MemberCount;
	::Uml::CompositionChildRole TypeStruct::meta_TypeBaseRef_children;

	Matrix::Matrix() {}
	Matrix::Matrix(::Udm::ObjectImpl *impl) : TypeBase(impl), UDM_OBJECT(impl) {}
	Matrix::Matrix(const Matrix &master) : TypeBase(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Matrix::Matrix(Matrix &&master) : TypeBase(master), UDM_OBJECT(master) {};

	Matrix Matrix::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Matrix& Matrix::operator=(Matrix &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Matrix Matrix::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Matrix Matrix::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Matrix Matrix::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Matrix> Matrix::Instances() { return ::Udm::InstantiatedAttr< Matrix>(impl); }
	Matrix Matrix::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Matrix> Matrix::Derived() { return ::Udm::DerivedAttr< Matrix>(impl); }
	::Udm::ArchetypeAttr< Matrix> Matrix::Archetype() const { return ::Udm::ArchetypeAttr< Matrix>(impl); }
	::Udm::StringAttr Matrix::Type() const { return ::Udm::StringAttr(impl, meta_Type); }
	::Udm::IntegerAttr Matrix::rows() const { return ::Udm::IntegerAttr(impl, meta_rows); }
	::Udm::IntegerAttr Matrix::columns() const { return ::Udm::IntegerAttr(impl, meta_columns); }
	::Udm::ParentAttr< ::ESMoL::Types> Matrix::parent() const { return ::Udm::ParentAttr< ::ESMoL::Types>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Matrix::meta;
	::Uml::Attribute Matrix::meta_Type;
	::Uml::Attribute Matrix::meta_rows;
	::Uml::Attribute Matrix::meta_columns;

	TypeBase::TypeBase() {}
	TypeBase::TypeBase(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TypeBase::TypeBase(const TypeBase &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeBase::TypeBase(TypeBase &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TypeBase TypeBase::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeBase& TypeBase::operator=(TypeBase &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeBase TypeBase::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeBase TypeBase::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeBase TypeBase::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeBase> TypeBase::Instances() { return ::Udm::InstantiatedAttr< TypeBase>(impl); }
	TypeBase TypeBase::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeBase> TypeBase::Derived() { return ::Udm::DerivedAttr< TypeBase>(impl); }
	::Udm::ArchetypeAttr< TypeBase> TypeBase::Archetype() const { return ::Udm::ArchetypeAttr< TypeBase>(impl); }
	::Udm::AssocAttr< TypeBaseRef> TypeBase::referedbyTypeStructRef() const { return ::Udm::AssocAttr< TypeBaseRef>(impl, meta_referedbyTypeStructRef); }
	::Udm::CrossPointerAttr< ::SFC::DT> TypeBase::dt() const { return ::Udm::CrossPointerAttr< ::SFC::DT>(impl, meta_dt); }
	::Udm::ParentAttr< ::ESMoL::Types> TypeBase::Types_parent() const { return ::Udm::ParentAttr< ::ESMoL::Types>(impl, meta_Types_parent); }
	::Udm::ParentAttr< ::ESMoL::Types> TypeBase::parent() const { return ::Udm::ParentAttr< ::ESMoL::Types>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeBase::meta;
	::Uml::AssociationRole TypeBase::meta_referedbyTypeStructRef;
	::Uml::AssociationRole TypeBase::meta_dt;
	::Uml::CompositionParentRole TypeBase::meta_Types_parent;

	TypeBaseRef::TypeBaseRef() {}
	TypeBaseRef::TypeBaseRef(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	TypeBaseRef::TypeBaseRef(const TypeBaseRef &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TypeBaseRef::TypeBaseRef(TypeBaseRef &&master) : MgaObject(master), UDM_OBJECT(master) {};

	TypeBaseRef TypeBaseRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TypeBaseRef& TypeBaseRef::operator=(TypeBaseRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TypeBaseRef TypeBaseRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TypeBaseRef TypeBaseRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TypeBaseRef TypeBaseRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TypeBaseRef> TypeBaseRef::Instances() { return ::Udm::InstantiatedAttr< TypeBaseRef>(impl); }
	TypeBaseRef TypeBaseRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TypeBaseRef> TypeBaseRef::Derived() { return ::Udm::DerivedAttr< TypeBaseRef>(impl); }
	::Udm::ArchetypeAttr< TypeBaseRef> TypeBaseRef::Archetype() const { return ::Udm::ArchetypeAttr< TypeBaseRef>(impl); }
	::Udm::IntegerAttr TypeBaseRef::MemberIndex() const { return ::Udm::IntegerAttr(impl, meta_MemberIndex); }
	::Udm::PointerAttr< TypeBase> TypeBaseRef::ref() const { return ::Udm::PointerAttr< TypeBase>(impl, meta_ref); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> TypeBaseRef::lvar() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_lvar); }
	::Udm::ParentAttr< ::ESMoL::TypeStruct> TypeBaseRef::TypeStruct_parent() const { return ::Udm::ParentAttr< ::ESMoL::TypeStruct>(impl, meta_TypeStruct_parent); }
	::Udm::ParentAttr< ::ESMoL::Port> TypeBaseRef::Port_parent() const { return ::Udm::ParentAttr< ::ESMoL::Port>(impl, meta_Port_parent); }
	::Udm::ParentAttr< ::ESMoL::StateDE> TypeBaseRef::StateDE_parent() const { return ::Udm::ParentAttr< ::ESMoL::StateDE>(impl, meta_StateDE_parent); }
	::Udm::ParentAttr< ::ESMoL::MgaObject> TypeBaseRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TypeBaseRef::meta;
	::Uml::Attribute TypeBaseRef::meta_MemberIndex;
	::Uml::AssociationRole TypeBaseRef::meta_ref;
	::Uml::AssociationRole TypeBaseRef::meta_lvar;
	::Uml::CompositionParentRole TypeBaseRef::meta_TypeStruct_parent;
	::Uml::CompositionParentRole TypeBaseRef::meta_Port_parent;
	::Uml::CompositionParentRole TypeBaseRef::meta_StateDE_parent;

	Primitive::Primitive() {}
	Primitive::Primitive(::Udm::ObjectImpl *impl) : Block(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Primitive::Primitive(const Primitive &master) : Block(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Primitive::Primitive(Primitive &&master) : Block(master), MgaObject(master), UDM_OBJECT(master) {};

	Primitive Primitive::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Primitive& Primitive::operator=(Primitive &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Primitive Primitive::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Primitive Primitive::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Primitive Primitive::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Primitive> Primitive::Instances() { return ::Udm::InstantiatedAttr< Primitive>(impl); }
	Primitive Primitive::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Primitive> Primitive::Derived() { return ::Udm::DerivedAttr< Primitive>(impl); }
	::Udm::ArchetypeAttr< Primitive> Primitive::Archetype() const { return ::Udm::ArchetypeAttr< Primitive>(impl); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> Primitive::ifval() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_ifval); }
	::Udm::ParentAttr< ::ESMoL::Subsystem> Primitive::parent() const { return ::Udm::ParentAttr< ::ESMoL::Subsystem>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Primitive::meta;
	::Uml::AssociationRole Primitive::meta_ifval;

	Block::Block() {}
	Block::Block(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Block::Block(const Block &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Block::Block(Block &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	Block Block::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Block& Block::operator=(Block &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Block Block::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Block Block::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Block Block::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Block> Block::Instances() { return ::Udm::InstantiatedAttr< Block>(impl); }
	Block Block::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Block> Block::Derived() { return ::Udm::DerivedAttr< Block>(impl); }
	::Udm::ArchetypeAttr< Block> Block::Archetype() const { return ::Udm::ArchetypeAttr< Block>(impl); }
	::Udm::StringAttr Block::BlockType() const { return ::Udm::StringAttr(impl, meta_BlockType); }
	::Udm::StringAttr Block::Tag() const { return ::Udm::StringAttr(impl, meta_Tag); }
	::Udm::StringAttr Block::Name() const { return ::Udm::StringAttr(impl, meta_Name); }
	::Udm::StringAttr Block::Description() const { return ::Udm::StringAttr(impl, meta_Description); }
	::Udm::IntegerAttr Block::Priority() const { return ::Udm::IntegerAttr(impl, meta_Priority); }
	::Udm::RealAttr Block::SampleTime() const { return ::Udm::RealAttr(impl, meta_SampleTime); }
	::Udm::StringAttr Block::UserData() const { return ::Udm::StringAttr(impl, meta_UserData); }
	::Udm::ChildrenAttr< ::ESMoL::Parameter> Block::Parameter() const { return ::Udm::ChildrenAttr< ::ESMoL::Parameter>(impl, meta_Parameter); }
	::Udm::ChildrenAttr< ::ESMoL::Line> Block::Line() const { return ::Udm::ChildrenAttr< ::ESMoL::Line>(impl, meta_Line); }
	::Udm::ChildrenAttr< ::ESMoL::Annotation> Block::Annotation_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Annotation>(impl, meta_Annotation_children); }
	::Udm::ChildrenAttr< ::ESMoL::ConnectorRef> Block::ConnectorRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef>(impl, meta_ConnectorRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::Port> Block::Port_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Port>(impl, meta_Port_children); }
	::Udm::ChildrenAttr< ::ESMoL::Parameter> Block::Parameter_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Parameter>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Annotation> Block::Annotation_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Annotation>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Line> Block::Line_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Line>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutputPort> Block::OutputPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutputPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OutPort> Block::OutPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OutPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::StatePort> Block::StatePort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::StatePort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Port> Block::Port_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Port>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::EnablePort> Block::EnablePort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::EnablePort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TriggerPort> Block::TriggerPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TriggerPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::InputPort> Block::InputPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::InputPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::InPort> Block::InPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::InPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ActionPort> Block::ActionPort_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ActionPort>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HasRefId> Block::HasRefId_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ConnectorRef> Block::ConnectorRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TransConnector> Block::TransConnector_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Block::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Subsystem> Block::Subsystem_parent() const { return ::Udm::ParentAttr< ::ESMoL::Subsystem>(impl, meta_Subsystem_parent); }
	::Udm::ParentAttr< ::Udm::Object> Block::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Block::meta;
	::Uml::Attribute Block::meta_BlockType;
	::Uml::Attribute Block::meta_Tag;
	::Uml::Attribute Block::meta_Name;
	::Uml::Attribute Block::meta_Description;
	::Uml::Attribute Block::meta_Priority;
	::Uml::Attribute Block::meta_SampleTime;
	::Uml::Attribute Block::meta_UserData;
	::Uml::CompositionChildRole Block::meta_Parameter;
	::Uml::CompositionChildRole Block::meta_Line;
	::Uml::CompositionChildRole Block::meta_Annotation_children;
	::Uml::CompositionChildRole Block::meta_ConnectorRef_children;
	::Uml::CompositionChildRole Block::meta_Port_children;
	::Uml::CompositionParentRole Block::meta_Subsystem_parent;
	::Uml::Constraint Block::meta_UniqueConnectorNames;

	Parameter::Parameter() {}
	Parameter::Parameter(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Parameter::Parameter(const Parameter &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Parameter::Parameter(Parameter &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	Parameter Parameter::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Parameter& Parameter::operator=(Parameter &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Parameter Parameter::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Parameter Parameter::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Parameter Parameter::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Parameter> Parameter::Instances() { return ::Udm::InstantiatedAttr< Parameter>(impl); }
	Parameter Parameter::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Parameter> Parameter::Derived() { return ::Udm::DerivedAttr< Parameter>(impl); }
	::Udm::ArchetypeAttr< Parameter> Parameter::Archetype() const { return ::Udm::ArchetypeAttr< Parameter>(impl); }
	::Udm::StringAttr Parameter::Value() const { return ::Udm::StringAttr(impl, meta_Value); }
	::Udm::CrossPointerAttr< ::SFC::Arg> Parameter::arg() const { return ::Udm::CrossPointerAttr< ::SFC::Arg>(impl, meta_arg); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> Parameter::memb() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_memb); }
	::Udm::ParentAttr< ::ESMoL::Block> Parameter::Parameter_Block_parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, meta_Parameter_Block_parent); }
	::Udm::ParentAttr< ::ESMoL::Block> Parameter::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Parameter::meta;
	::Uml::Attribute Parameter::meta_Value;
	::Uml::AssociationRole Parameter::meta_arg;
	::Uml::AssociationRole Parameter::meta_memb;
	::Uml::CompositionParentRole Parameter::meta_Parameter_Block_parent;

	Reference::Reference() {}
	Reference::Reference(::Udm::ObjectImpl *impl) : Block(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Reference::Reference(const Reference &master) : Block(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Reference::Reference(Reference &&master) : Block(master), MgaObject(master), UDM_OBJECT(master) {};

	Reference Reference::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Reference& Reference::operator=(Reference &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Reference Reference::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Reference Reference::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Reference Reference::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Reference> Reference::Instances() { return ::Udm::InstantiatedAttr< Reference>(impl); }
	Reference Reference::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Reference> Reference::Derived() { return ::Udm::DerivedAttr< Reference>(impl); }
	::Udm::ArchetypeAttr< Reference> Reference::Archetype() const { return ::Udm::ArchetypeAttr< Reference>(impl); }
	::Udm::StringAttr Reference::SourceType() const { return ::Udm::StringAttr(impl, meta_SourceType); }
	::Udm::StringAttr Reference::SourceBlock() const { return ::Udm::StringAttr(impl, meta_SourceBlock); }
	::Udm::ParentAttr< ::ESMoL::Subsystem> Reference::parent() const { return ::Udm::ParentAttr< ::ESMoL::Subsystem>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Reference::meta;
	::Uml::Attribute Reference::meta_SourceType;
	::Uml::Attribute Reference::meta_SourceBlock;

	Annotation::Annotation() {}
	Annotation::Annotation(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Annotation::Annotation(const Annotation &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Annotation::Annotation(Annotation &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Annotation Annotation::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Annotation& Annotation::operator=(Annotation &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Annotation Annotation::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Annotation Annotation::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Annotation Annotation::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Annotation> Annotation::Instances() { return ::Udm::InstantiatedAttr< Annotation>(impl); }
	Annotation Annotation::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Annotation> Annotation::Derived() { return ::Udm::DerivedAttr< Annotation>(impl); }
	::Udm::ArchetypeAttr< Annotation> Annotation::Archetype() const { return ::Udm::ArchetypeAttr< Annotation>(impl); }
	::Udm::StringAttr Annotation::Text() const { return ::Udm::StringAttr(impl, meta_Text); }
	::Udm::ParentAttr< ::ESMoL::Block> Annotation::Block_parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, meta_Block_parent); }
	::Udm::ParentAttr< ::ESMoL::Block> Annotation::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Annotation::meta;
	::Uml::Attribute Annotation::meta_Text;
	::Uml::CompositionParentRole Annotation::meta_Block_parent;

	Line::Line() {}
	Line::Line(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Line::Line(const Line &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Line::Line(Line &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	Line Line::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Line& Line::operator=(Line &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Line Line::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Line Line::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Line Line::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Line> Line::Instances() { return ::Udm::InstantiatedAttr< Line>(impl); }
	Line Line::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Line> Line::Derived() { return ::Udm::DerivedAttr< Line>(impl); }
	::Udm::ArchetypeAttr< Line> Line::Archetype() const { return ::Udm::ArchetypeAttr< Line>(impl); }
	::Udm::StringAttr Line::Name() const { return ::Udm::StringAttr(impl, meta_Name); }
	::Udm::ParentAttr< ::ESMoL::Block> Line::Line_Block_parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, meta_Line_Block_parent); }
	::Udm::ParentAttr< ::ESMoL::Block> Line::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::Port> Line::srcLine_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Port>(impl, meta_srcLine_end_); }
	::Udm::AssocEndAttr< ::ESMoL::Port> Line::dstLine_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Port>(impl, meta_dstLine_end_); }

	::Uml::Class Line::meta;
	::Uml::Attribute Line::meta_Name;
	::Uml::CompositionParentRole Line::meta_Line_Block_parent;
	::Uml::AssociationRole Line::meta_srcLine_end_;
	::Uml::AssociationRole Line::meta_dstLine_end_;

	Dataflow::Dataflow() {}
	Dataflow::Dataflow(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Dataflow::Dataflow(const Dataflow &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Dataflow::Dataflow(Dataflow &&master) : UDM_OBJECT(master) {};

	Dataflow Dataflow::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Dataflow& Dataflow::operator=(Dataflow &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Dataflow Dataflow::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Dataflow Dataflow::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Dataflow Dataflow::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Dataflow> Dataflow::Instances() { return ::Udm::InstantiatedAttr< Dataflow>(impl); }
	Dataflow Dataflow::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Dataflow> Dataflow::Derived() { return ::Udm::DerivedAttr< Dataflow>(impl); }
	::Udm::ArchetypeAttr< Dataflow> Dataflow::Archetype() const { return ::Udm::ArchetypeAttr< Dataflow>(impl); }
	::Udm::StringAttr Dataflow::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::Subsystem> Dataflow::Subsystem_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem>(impl, meta_Subsystem_children); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentBase> Dataflow::ComponentBase_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentBase>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Block> Dataflow::Block_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Block>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Subsystem> Dataflow::Subsystem_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HasRefId> Dataflow::HasRefId_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Dataflow::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> Dataflow::ModelsFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, meta_ModelsFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> Dataflow::parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Dataflow::meta;
	::Uml::Attribute Dataflow::meta_name;
	::Uml::CompositionChildRole Dataflow::meta_Subsystem_children;
	::Uml::CompositionParentRole Dataflow::meta_ModelsFolder_parent;

	Subsystem::Subsystem() {}
	Subsystem::Subsystem(::Udm::ObjectImpl *impl) : ComponentBase(impl),Block(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Subsystem::Subsystem(const Subsystem &master) : ComponentBase(master),Block(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Subsystem::Subsystem(Subsystem &&master) : ComponentBase(master),Block(master), MgaObject(master), UDM_OBJECT(master) {};

	Subsystem Subsystem::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Subsystem& Subsystem::operator=(Subsystem &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Subsystem Subsystem::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Subsystem Subsystem::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Subsystem Subsystem::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Subsystem> Subsystem::Instances() { return ::Udm::InstantiatedAttr< Subsystem>(impl); }
	Subsystem Subsystem::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Subsystem> Subsystem::Derived() { return ::Udm::DerivedAttr< Subsystem>(impl); }
	::Udm::ArchetypeAttr< Subsystem> Subsystem::Archetype() const { return ::Udm::ArchetypeAttr< Subsystem>(impl); }
	::Udm::AssocAttr< SubsystemRef> Subsystem::referedbySubsystemRef() const { return ::Udm::AssocAttr< SubsystemRef>(impl, meta_referedbySubsystemRef); }
	::Udm::CrossPointerAttr< ::SFC::Function> Subsystem::init() const { return ::Udm::CrossPointerAttr< ::SFC::Function>(impl, meta_init); }
	::Udm::CrossPointerAttr< ::SFC::Function> Subsystem::main() const { return ::Udm::CrossPointerAttr< ::SFC::Function>(impl, meta_main); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> Subsystem::memb() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_memb); }
	::Udm::CrossAssocAttr< ::SFC::FunctionCall> Subsystem::mcall() const { return ::Udm::CrossAssocAttr< ::SFC::FunctionCall>(impl, meta_mcall); }
	::Udm::CrossPointerAttr< ::SFC::Class> Subsystem::cls() const { return ::Udm::CrossPointerAttr< ::SFC::Class>(impl, meta_cls); }
	::Udm::ChildrenAttr< ::ESMoL::Block> Subsystem::Block_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Block>(impl, meta_Block_children); }
	::Udm::ChildrenAttr< ::ESMoL::Primitive> Subsystem::Primitive_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Primitive>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Block> Subsystem::Block_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Block>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Reference> Subsystem::Reference_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Reference>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Subsystem> Subsystem::Subsystem_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Subsystem>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HasRefId> Subsystem::HasRefId_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Subsystem::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Dataflow> Subsystem::Dataflow_parent() const { return ::Udm::ParentAttr< ::ESMoL::Dataflow>(impl, meta_Dataflow_parent); }
	::Udm::ParentAttr< ::Udm::Object> Subsystem::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Subsystem::meta;
	::Uml::AssociationRole Subsystem::meta_referedbySubsystemRef;
	::Uml::AssociationRole Subsystem::meta_init;
	::Uml::AssociationRole Subsystem::meta_main;
	::Uml::AssociationRole Subsystem::meta_memb;
	::Uml::AssociationRole Subsystem::meta_mcall;
	::Uml::AssociationRole Subsystem::meta_cls;
	::Uml::CompositionChildRole Subsystem::meta_Block_children;
	::Uml::CompositionParentRole Subsystem::meta_Dataflow_parent;
	::Uml::Constraint Subsystem::meta_UniqueConnectorNames1;

	OutputPort::OutputPort() {}
	OutputPort::OutputPort(::Udm::ObjectImpl *impl) : Output(impl),OutPort(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	OutputPort::OutputPort(const OutputPort &master) : Output(master),OutPort(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OutputPort::OutputPort(OutputPort &&master) : Output(master),OutPort(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	OutputPort OutputPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutputPort& OutputPort::operator=(OutputPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutputPort OutputPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutputPort OutputPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutputPort OutputPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutputPort> OutputPort::Instances() { return ::Udm::InstantiatedAttr< OutputPort>(impl); }
	OutputPort OutputPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutputPort> OutputPort::Derived() { return ::Udm::DerivedAttr< OutputPort>(impl); }
	::Udm::ArchetypeAttr< OutputPort> OutputPort::Archetype() const { return ::Udm::ArchetypeAttr< OutputPort>(impl); }
	::Udm::IntegerAttr OutputPort::Number() const { return ::Udm::IntegerAttr(impl, meta_Number); }
	::Udm::ParentAttr< ::ESMoL::Block> OutputPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OutputPort::meta;
	::Uml::Attribute OutputPort::meta_Number;
	::Uml::Constraint OutputPort::meta_NestedOPtoOPorNestedOPtoIP;

	OutPort::OutPort() {}
	OutPort::OutPort(::Udm::ObjectImpl *impl) : Port(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	OutPort::OutPort(const OutPort &master) : Port(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OutPort::OutPort(OutPort &&master) : Port(master), MgaObject(master), UDM_OBJECT(master) {};

	OutPort OutPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OutPort& OutPort::operator=(OutPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OutPort OutPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OutPort OutPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OutPort OutPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OutPort> OutPort::Instances() { return ::Udm::InstantiatedAttr< OutPort>(impl); }
	OutPort OutPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OutPort> OutPort::Derived() { return ::Udm::DerivedAttr< OutPort>(impl); }
	::Udm::ArchetypeAttr< OutPort> OutPort::Archetype() const { return ::Udm::ArchetypeAttr< OutPort>(impl); }
	::Udm::ParentAttr< ::ESMoL::Block> OutPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OutPort::meta;

	StatePort::StatePort() {}
	StatePort::StatePort(::Udm::ObjectImpl *impl) : OutPort(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	StatePort::StatePort(const StatePort &master) : OutPort(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StatePort::StatePort(StatePort &&master) : OutPort(master), MgaObject(master), UDM_OBJECT(master) {};

	StatePort StatePort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StatePort& StatePort::operator=(StatePort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StatePort StatePort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StatePort StatePort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StatePort StatePort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StatePort> StatePort::Instances() { return ::Udm::InstantiatedAttr< StatePort>(impl); }
	StatePort StatePort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StatePort> StatePort::Derived() { return ::Udm::DerivedAttr< StatePort>(impl); }
	::Udm::ArchetypeAttr< StatePort> StatePort::Archetype() const { return ::Udm::ArchetypeAttr< StatePort>(impl); }
	::Udm::ParentAttr< ::ESMoL::Block> StatePort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StatePort::meta;

	Port::Port() {}
	Port::Port(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Port::Port(const Port &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Port::Port(Port &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	Port Port::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Port& Port::operator=(Port &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Port Port::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Port Port::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Port Port::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Port> Port::Instances() { return ::Udm::InstantiatedAttr< Port>(impl); }
	Port Port::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Port> Port::Derived() { return ::Udm::DerivedAttr< Port>(impl); }
	::Udm::ArchetypeAttr< Port> Port::Archetype() const { return ::Udm::ArchetypeAttr< Port>(impl); }
	::Udm::AClassAssocAttr< Line, Port> Port::dstLine() const { return ::Udm::AClassAssocAttr< Line, Port>(impl, meta_dstLine, meta_dstLine_rev); }
	::Udm::AClassAssocAttr< Line, Port> Port::srcLine() const { return ::Udm::AClassAssocAttr< Line, Port>(impl, meta_srcLine, meta_srcLine_rev); }
	::Udm::CrossAssocAttr< ::SFC::Arg> Port::arg() const { return ::Udm::CrossAssocAttr< ::SFC::Arg>(impl, meta_arg); }
	::Udm::CrossPointerAttr< ::SFC::ArgDeclBase> Port::argdecl() const { return ::Udm::CrossPointerAttr< ::SFC::ArgDeclBase>(impl, meta_argdecl); }
	::Udm::ChildAttr< ::ESMoL::TypeBaseRef> Port::TypeBaseRef_child() const { return ::Udm::ChildAttr< ::ESMoL::TypeBaseRef>(impl, meta_TypeBaseRef_child); }
	::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> Port::TypeBaseRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Port::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Block> Port::Block_parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, meta_Block_parent); }
	::Udm::ParentAttr< ::ESMoL::Block> Port::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Port::meta;
	::Uml::AssociationRole Port::meta_dstLine;
	::Uml::AssociationRole Port::meta_dstLine_rev;
	::Uml::AssociationRole Port::meta_srcLine;
	::Uml::AssociationRole Port::meta_srcLine_rev;
	::Uml::AssociationRole Port::meta_arg;
	::Uml::AssociationRole Port::meta_argdecl;
	::Uml::CompositionChildRole Port::meta_TypeBaseRef_child;
	::Uml::CompositionParentRole Port::meta_Block_parent;

	EnablePort::EnablePort() {}
	EnablePort::EnablePort(::Udm::ObjectImpl *impl) : InPort(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	EnablePort::EnablePort(const EnablePort &master) : InPort(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	EnablePort::EnablePort(EnablePort &&master) : InPort(master), MgaObject(master), UDM_OBJECT(master) {};

	EnablePort EnablePort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	EnablePort& EnablePort::operator=(EnablePort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	EnablePort EnablePort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	EnablePort EnablePort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	EnablePort EnablePort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< EnablePort> EnablePort::Instances() { return ::Udm::InstantiatedAttr< EnablePort>(impl); }
	EnablePort EnablePort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< EnablePort> EnablePort::Derived() { return ::Udm::DerivedAttr< EnablePort>(impl); }
	::Udm::ArchetypeAttr< EnablePort> EnablePort::Archetype() const { return ::Udm::ArchetypeAttr< EnablePort>(impl); }
	::Udm::StringAttr EnablePort::StatesWhenEnabling() const { return ::Udm::StringAttr(impl, meta_StatesWhenEnabling); }
	::Udm::ParentAttr< ::ESMoL::Block> EnablePort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class EnablePort::meta;
	::Uml::Attribute EnablePort::meta_StatesWhenEnabling;
	::Uml::Constraint EnablePort::meta_EPtoNestedIPTPEPBPOnly;
	::Uml::Constraint EnablePort::meta_EPConnectedByPortInParentParent;
	::Uml::Constraint EnablePort::meta_OnlyOneEP;
	::Uml::Constraint EnablePort::meta_EPParentIsSubsystemOrSystem;
	::Uml::Constraint EnablePort::meta_EPInSubsystemOnlyConnectToEPInSystem;
	::Uml::Constraint EnablePort::meta_EPConnectedAsDstAtLeastOnce;
	::Uml::Constraint EnablePort::meta_EnableParentInSubsystemMustConnectDownToSystem;

	TriggerPort::TriggerPort() {}
	TriggerPort::TriggerPort(::Udm::ObjectImpl *impl) : InPort(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	TriggerPort::TriggerPort(const TriggerPort &master) : InPort(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TriggerPort::TriggerPort(TriggerPort &&master) : InPort(master), MgaObject(master), UDM_OBJECT(master) {};

	TriggerPort TriggerPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TriggerPort& TriggerPort::operator=(TriggerPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TriggerPort TriggerPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TriggerPort TriggerPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TriggerPort TriggerPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TriggerPort> TriggerPort::Instances() { return ::Udm::InstantiatedAttr< TriggerPort>(impl); }
	TriggerPort TriggerPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TriggerPort> TriggerPort::Derived() { return ::Udm::DerivedAttr< TriggerPort>(impl); }
	::Udm::ArchetypeAttr< TriggerPort> TriggerPort::Archetype() const { return ::Udm::ArchetypeAttr< TriggerPort>(impl); }
	::Udm::StringAttr TriggerPort::TriggerType() const { return ::Udm::StringAttr(impl, meta_TriggerType); }
	::Udm::CrossPointerAttr< ::SFC::LocalVar> TriggerPort::memb() const { return ::Udm::CrossPointerAttr< ::SFC::LocalVar>(impl, meta_memb); }
	::Udm::ParentAttr< ::ESMoL::Block> TriggerPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TriggerPort::meta;
	::Uml::Attribute TriggerPort::meta_TriggerType;
	::Uml::AssociationRole TriggerPort::meta_memb;
	::Uml::Constraint TriggerPort::meta_OnlyOneTP;
	::Uml::Constraint TriggerPort::meta_TPConnectedAsDstAtLeastOnce;
	::Uml::Constraint TriggerPort::meta_TPtoNestedIPTPEPBPOnly;
	::Uml::Constraint TriggerPort::meta_TPConnectedByPortInParentParent;
	::Uml::Constraint TriggerPort::meta_TPInSubsystemOnlyConnectToTPInSystem;
	::Uml::Constraint TriggerPort::meta_TPParentIsSubsystemOrSystem;
	::Uml::Constraint TriggerPort::meta_TriggerParentInSubsystemMustConnectDownToSystem;

	InputPort::InputPort() {}
	InputPort::InputPort(::Udm::ObjectImpl *impl) : Input(impl),InPort(impl), IOPortExp(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	InputPort::InputPort(const InputPort &master) : Input(master),InPort(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	InputPort::InputPort(InputPort &&master) : Input(master),InPort(master), IOPortExp(master), MgaObject(master), UDM_OBJECT(master) {};

	InputPort InputPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	InputPort& InputPort::operator=(InputPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	InputPort InputPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	InputPort InputPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	InputPort InputPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< InputPort> InputPort::Instances() { return ::Udm::InstantiatedAttr< InputPort>(impl); }
	InputPort InputPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< InputPort> InputPort::Derived() { return ::Udm::DerivedAttr< InputPort>(impl); }
	::Udm::ArchetypeAttr< InputPort> InputPort::Archetype() const { return ::Udm::ArchetypeAttr< InputPort>(impl); }
	::Udm::IntegerAttr InputPort::Number() const { return ::Udm::IntegerAttr(impl, meta_Number); }
	::Udm::ParentAttr< ::ESMoL::Block> InputPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class InputPort::meta;
	::Uml::Attribute InputPort::meta_Number;
	::Uml::Constraint InputPort::meta_IPtoNestedIPTPEPBPOnly;
	::Uml::Constraint InputPort::meta_IPInSubsystemOnlyConnectToIPInSystem;
	::Uml::Constraint InputPort::meta_IPConnectedAsDstAtLeastOnce;

	InPort::InPort() {}
	InPort::InPort(::Udm::ObjectImpl *impl) : Port(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	InPort::InPort(const InPort &master) : Port(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	InPort::InPort(InPort &&master) : Port(master), MgaObject(master), UDM_OBJECT(master) {};

	InPort InPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	InPort& InPort::operator=(InPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	InPort InPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	InPort InPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	InPort InPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< InPort> InPort::Instances() { return ::Udm::InstantiatedAttr< InPort>(impl); }
	InPort InPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< InPort> InPort::Derived() { return ::Udm::DerivedAttr< InPort>(impl); }
	::Udm::ArchetypeAttr< InPort> InPort::Archetype() const { return ::Udm::ArchetypeAttr< InPort>(impl); }
	::Udm::ParentAttr< ::ESMoL::Block> InPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class InPort::meta;

	ActionPort::ActionPort() {}
	ActionPort::ActionPort(::Udm::ObjectImpl *impl) : InPort(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	ActionPort::ActionPort(const ActionPort &master) : InPort(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ActionPort::ActionPort(ActionPort &&master) : InPort(master), MgaObject(master), UDM_OBJECT(master) {};

	ActionPort ActionPort::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ActionPort& ActionPort::operator=(ActionPort &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ActionPort ActionPort::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ActionPort ActionPort::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ActionPort ActionPort::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ActionPort> ActionPort::Instances() { return ::Udm::InstantiatedAttr< ActionPort>(impl); }
	ActionPort ActionPort::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ActionPort> ActionPort::Derived() { return ::Udm::DerivedAttr< ActionPort>(impl); }
	::Udm::ArchetypeAttr< ActionPort> ActionPort::Archetype() const { return ::Udm::ArchetypeAttr< ActionPort>(impl); }
	::Udm::ParentAttr< ::ESMoL::Block> ActionPort::parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ActionPort::meta;

	HasRefId::HasRefId() {}
	HasRefId::HasRefId(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	HasRefId::HasRefId(const HasRefId &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	HasRefId::HasRefId(HasRefId &&master) : MgaObject(master), UDM_OBJECT(master) {};

	HasRefId HasRefId::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	HasRefId& HasRefId::operator=(HasRefId &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	HasRefId HasRefId::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	HasRefId HasRefId::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	HasRefId HasRefId::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< HasRefId> HasRefId::Instances() { return ::Udm::InstantiatedAttr< HasRefId>(impl); }
	HasRefId HasRefId::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< HasRefId> HasRefId::Derived() { return ::Udm::DerivedAttr< HasRefId>(impl); }
	::Udm::ArchetypeAttr< HasRefId> HasRefId::Archetype() const { return ::Udm::ArchetypeAttr< HasRefId>(impl); }
	::Udm::StringAttr HasRefId::RefId() const { return ::Udm::StringAttr(impl, meta_RefId); }
	::Udm::ParentAttr< ::Udm::Object> HasRefId::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class HasRefId::meta;
	::Uml::Attribute HasRefId::meta_RefId;

	State::State() {}
	State::State(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	State::State(const State &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	State::State(State &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	State State::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	State& State::operator=(State &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	State State::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	State State::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	State State::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< State> State::Instances() { return ::Udm::InstantiatedAttr< State>(impl); }
	State State::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< State> State::Derived() { return ::Udm::DerivedAttr< State>(impl); }
	::Udm::ArchetypeAttr< State> State::Archetype() const { return ::Udm::ArchetypeAttr< State>(impl); }
	::Udm::StringAttr State::Decomposition() const { return ::Udm::StringAttr(impl, meta_Decomposition); }
	::Udm::StringAttr State::Name() const { return ::Udm::StringAttr(impl, meta_Name); }
	::Udm::StringAttr State::EnterAction() const { return ::Udm::StringAttr(impl, meta_EnterAction); }
	::Udm::StringAttr State::DuringAction() const { return ::Udm::StringAttr(impl, meta_DuringAction); }
	::Udm::StringAttr State::ExitAction() const { return ::Udm::StringAttr(impl, meta_ExitAction); }
	::Udm::StringAttr State::Order() const { return ::Udm::StringAttr(impl, meta_Order); }
	::Udm::StringAttr State::Description() const { return ::Udm::StringAttr(impl, meta_Description); }
	::Udm::StringAttr State::Methods() const { return ::Udm::StringAttr(impl, meta_Methods); }
	::Udm::ChildrenAttr< ::ESMoL::Transition> State::Transition() const { return ::Udm::ChildrenAttr< ::ESMoL::Transition>(impl, meta_Transition); }
	::Udm::ChildrenAttr< ::ESMoL::TransConnector> State::TransConnector_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector>(impl, meta_TransConnector_children); }
	::Udm::ChildrenAttr< ::ESMoL::StateDE> State::StateDE_children() const { return ::Udm::ChildrenAttr< ::ESMoL::StateDE>(impl, meta_StateDE_children); }
	::Udm::ChildrenAttr< ::ESMoL::HasRefId> State::HasRefId_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::State> State::State_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::State>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Transition> State::Transition_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Transition>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::History> State::History_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::History>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TransStart> State::TransStart_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransStart>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Junction> State::Junction_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Junction>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ConnectorRef> State::ConnectorRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ConnectorRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TransConnector> State::TransConnector_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Data> State::Data_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Data>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Event> State::Event_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Event>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::StateDE> State::StateDE_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::StateDE>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Conditional> State::Conditional_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Conditional>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ShallowHistory> State::ShallowHistory_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ShallowHistory>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::DeepHistory> State::DeepHistory_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DeepHistory>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Join> State::Join_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Join>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Fork> State::Fork_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Fork>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Choice> State::Choice_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Choice>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Entry> State::Entry_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Entry>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Exit> State::Exit_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Exit>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Terminate> State::Terminate_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Terminate>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> State::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::Stateflow> State::Stateflow_parent() const { return ::Udm::ParentAttr< ::ESMoL::Stateflow>(impl, meta_Stateflow_parent); }
	::Udm::ParentAttr< ::Udm::Object> State::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class State::meta;
	::Uml::Attribute State::meta_Decomposition;
	::Uml::Attribute State::meta_Name;
	::Uml::Attribute State::meta_EnterAction;
	::Uml::Attribute State::meta_DuringAction;
	::Uml::Attribute State::meta_ExitAction;
	::Uml::Attribute State::meta_Order;
	::Uml::Attribute State::meta_Description;
	::Uml::Attribute State::meta_Methods;
	::Uml::CompositionChildRole State::meta_Transition;
	::Uml::CompositionChildRole State::meta_TransConnector_children;
	::Uml::CompositionChildRole State::meta_StateDE_children;
	::Uml::CompositionParentRole State::meta_Stateflow_parent;
	::Uml::Constraint State::meta_SingleHistory;

	Transition::Transition() {}
	Transition::Transition(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Transition::Transition(const Transition &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Transition::Transition(Transition &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	Transition Transition::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Transition& Transition::operator=(Transition &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Transition Transition::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Transition Transition::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Transition Transition::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Transition> Transition::Instances() { return ::Udm::InstantiatedAttr< Transition>(impl); }
	Transition Transition::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Transition> Transition::Derived() { return ::Udm::DerivedAttr< Transition>(impl); }
	::Udm::ArchetypeAttr< Transition> Transition::Archetype() const { return ::Udm::ArchetypeAttr< Transition>(impl); }
	::Udm::StringAttr Transition::Trigger() const { return ::Udm::StringAttr(impl, meta_Trigger); }
	::Udm::StringAttr Transition::Guard() const { return ::Udm::StringAttr(impl, meta_Guard); }
	::Udm::StringAttr Transition::Action() const { return ::Udm::StringAttr(impl, meta_Action); }
	::Udm::StringAttr Transition::ConditionAction() const { return ::Udm::StringAttr(impl, meta_ConditionAction); }
	::Udm::StringAttr Transition::Order() const { return ::Udm::StringAttr(impl, meta_Order); }
	::Udm::ParentAttr< ::ESMoL::State> Transition::Transition_State_parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, meta_Transition_State_parent); }
	::Udm::ParentAttr< ::ESMoL::State> Transition::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::TransConnector> Transition::srcTransition_end() const { return ::Udm::AssocEndAttr< ::ESMoL::TransConnector>(impl, meta_srcTransition_end_); }
	::Udm::AssocEndAttr< ::ESMoL::TransConnector> Transition::dstTransition_end() const { return ::Udm::AssocEndAttr< ::ESMoL::TransConnector>(impl, meta_dstTransition_end_); }

	::Uml::Class Transition::meta;
	::Uml::Attribute Transition::meta_Trigger;
	::Uml::Attribute Transition::meta_Guard;
	::Uml::Attribute Transition::meta_Action;
	::Uml::Attribute Transition::meta_ConditionAction;
	::Uml::Attribute Transition::meta_Order;
	::Uml::CompositionParentRole Transition::meta_Transition_State_parent;
	::Uml::AssociationRole Transition::meta_srcTransition_end_;
	::Uml::AssociationRole Transition::meta_dstTransition_end_;

	History::History() {}
	History::History(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	History::History(const History &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	History::History(History &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	History History::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	History& History::operator=(History &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	History History::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	History History::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	History History::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< History> History::Instances() { return ::Udm::InstantiatedAttr< History>(impl); }
	History History::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< History> History::Derived() { return ::Udm::DerivedAttr< History>(impl); }
	::Udm::ArchetypeAttr< History> History::Archetype() const { return ::Udm::ArchetypeAttr< History>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> History::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class History::meta;

	TransStart::TransStart() {}
	TransStart::TransStart(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	TransStart::TransStart(const TransStart &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TransStart::TransStart(TransStart &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	TransStart TransStart::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TransStart& TransStart::operator=(TransStart &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TransStart TransStart::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TransStart TransStart::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TransStart TransStart::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TransStart> TransStart::Instances() { return ::Udm::InstantiatedAttr< TransStart>(impl); }
	TransStart TransStart::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TransStart> TransStart::Derived() { return ::Udm::DerivedAttr< TransStart>(impl); }
	::Udm::ArchetypeAttr< TransStart> TransStart::Archetype() const { return ::Udm::ArchetypeAttr< TransStart>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> TransStart::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TransStart::meta;
	::Uml::Constraint TransStart::meta_TransStartRestrict;

	Junction::Junction() {}
	Junction::Junction(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Junction::Junction(const Junction &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Junction::Junction(Junction &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Junction Junction::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Junction& Junction::operator=(Junction &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Junction Junction::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Junction Junction::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Junction Junction::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Junction> Junction::Instances() { return ::Udm::InstantiatedAttr< Junction>(impl); }
	Junction Junction::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Junction> Junction::Derived() { return ::Udm::DerivedAttr< Junction>(impl); }
	::Udm::ArchetypeAttr< Junction> Junction::Archetype() const { return ::Udm::ArchetypeAttr< Junction>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Junction::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Junction::meta;
	::Uml::Constraint Junction::meta_JunctNotToSelf;

	ConnectorRef::ConnectorRef() {}
	ConnectorRef::ConnectorRef(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	ConnectorRef::ConnectorRef(const ConnectorRef &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ConnectorRef::ConnectorRef(ConnectorRef &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	ConnectorRef ConnectorRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ConnectorRef& ConnectorRef::operator=(ConnectorRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ConnectorRef ConnectorRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ConnectorRef ConnectorRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ConnectorRef ConnectorRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ConnectorRef> ConnectorRef::Instances() { return ::Udm::InstantiatedAttr< ConnectorRef>(impl); }
	ConnectorRef ConnectorRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ConnectorRef> ConnectorRef::Derived() { return ::Udm::DerivedAttr< ConnectorRef>(impl); }
	::Udm::ArchetypeAttr< ConnectorRef> ConnectorRef::Archetype() const { return ::Udm::ArchetypeAttr< ConnectorRef>(impl); }
	::Udm::PointerAttr< TransConnector> ConnectorRef::ref() const { return ::Udm::PointerAttr< TransConnector>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::Block> ConnectorRef::Block_parent() const { return ::Udm::ParentAttr< ::ESMoL::Block>(impl, meta_Block_parent); }
	::Udm::ParentAttr< ::ESMoL::HasRefId> ConnectorRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::HasRefId>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ConnectorRef::meta;
	::Uml::AssociationRole ConnectorRef::meta_ref;
	::Uml::CompositionParentRole ConnectorRef::meta_Block_parent;

	Stateflow::Stateflow() {}
	Stateflow::Stateflow(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	Stateflow::Stateflow(const Stateflow &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Stateflow::Stateflow(Stateflow &&master) : UDM_OBJECT(master) {};

	Stateflow Stateflow::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Stateflow& Stateflow::operator=(Stateflow &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Stateflow Stateflow::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Stateflow Stateflow::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Stateflow Stateflow::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Stateflow> Stateflow::Instances() { return ::Udm::InstantiatedAttr< Stateflow>(impl); }
	Stateflow Stateflow::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Stateflow> Stateflow::Derived() { return ::Udm::DerivedAttr< Stateflow>(impl); }
	::Udm::ArchetypeAttr< Stateflow> Stateflow::Archetype() const { return ::Udm::ArchetypeAttr< Stateflow>(impl); }
	::Udm::StringAttr Stateflow::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::State> Stateflow::State_children() const { return ::Udm::ChildrenAttr< ::ESMoL::State>(impl, meta_State_children); }
	::Udm::ChildrenAttr< ::ESMoL::HasRefId> Stateflow::HasRefId_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HasRefId>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::State> Stateflow::State_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::State>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TransConnector> Stateflow::TransConnector_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TransConnector>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Stateflow::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> Stateflow::ModelsFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, meta_ModelsFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::ModelsFolder> Stateflow::parent() const { return ::Udm::ParentAttr< ::ESMoL::ModelsFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Stateflow::meta;
	::Uml::Attribute Stateflow::meta_name;
	::Uml::CompositionChildRole Stateflow::meta_State_children;
	::Uml::CompositionParentRole Stateflow::meta_ModelsFolder_parent;

	TransConnector::TransConnector() {}
	TransConnector::TransConnector(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	TransConnector::TransConnector(const TransConnector &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	TransConnector::TransConnector(TransConnector &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	TransConnector TransConnector::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	TransConnector& TransConnector::operator=(TransConnector &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	TransConnector TransConnector::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	TransConnector TransConnector::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	TransConnector TransConnector::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< TransConnector> TransConnector::Instances() { return ::Udm::InstantiatedAttr< TransConnector>(impl); }
	TransConnector TransConnector::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< TransConnector> TransConnector::Derived() { return ::Udm::DerivedAttr< TransConnector>(impl); }
	::Udm::ArchetypeAttr< TransConnector> TransConnector::Archetype() const { return ::Udm::ArchetypeAttr< TransConnector>(impl); }
	::Udm::AssocAttr< ConnectorRef> TransConnector::referedbyConnectorRef() const { return ::Udm::AssocAttr< ConnectorRef>(impl, meta_referedbyConnectorRef); }
	::Udm::AClassAssocAttr< Transition, TransConnector> TransConnector::dstTransition() const { return ::Udm::AClassAssocAttr< Transition, TransConnector>(impl, meta_dstTransition, meta_dstTransition_rev); }
	::Udm::AClassAssocAttr< Transition, TransConnector> TransConnector::srcTransition() const { return ::Udm::AClassAssocAttr< Transition, TransConnector>(impl, meta_srcTransition, meta_srcTransition_rev); }
	::Udm::ParentAttr< ::ESMoL::State> TransConnector::State_parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, meta_State_parent); }
	::Udm::ParentAttr< ::Udm::Object> TransConnector::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class TransConnector::meta;
	::Uml::AssociationRole TransConnector::meta_referedbyConnectorRef;
	::Uml::AssociationRole TransConnector::meta_dstTransition;
	::Uml::AssociationRole TransConnector::meta_dstTransition_rev;
	::Uml::AssociationRole TransConnector::meta_srcTransition;
	::Uml::AssociationRole TransConnector::meta_srcTransition_rev;
	::Uml::CompositionParentRole TransConnector::meta_State_parent;

	Data::Data() {}
	Data::Data(::Udm::ObjectImpl *impl) : StateDE(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Data::Data(const Data &master) : StateDE(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Data::Data(Data &&master) : StateDE(master), MgaObject(master), UDM_OBJECT(master) {};

	Data Data::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Data& Data::operator=(Data &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Data Data::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Data Data::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Data Data::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Data> Data::Instances() { return ::Udm::InstantiatedAttr< Data>(impl); }
	Data Data::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Data> Data::Derived() { return ::Udm::DerivedAttr< Data>(impl); }
	::Udm::ArchetypeAttr< Data> Data::Archetype() const { return ::Udm::ArchetypeAttr< Data>(impl); }
	::Udm::StringAttr Data::Description() const { return ::Udm::StringAttr(impl, meta_Description); }
	::Udm::StringAttr Data::Name() const { return ::Udm::StringAttr(impl, meta_Name); }
	::Udm::StringAttr Data::DataType() const { return ::Udm::StringAttr(impl, meta_DataType); }
	::Udm::IntegerAttr Data::Port() const { return ::Udm::IntegerAttr(impl, meta_Port); }
	::Udm::StringAttr Data::Units() const { return ::Udm::StringAttr(impl, meta_Units); }
	::Udm::StringAttr Data::InitialValue() const { return ::Udm::StringAttr(impl, meta_InitialValue); }
	::Udm::StringAttr Data::Min() const { return ::Udm::StringAttr(impl, meta_Min); }
	::Udm::StringAttr Data::Max() const { return ::Udm::StringAttr(impl, meta_Max); }
	::Udm::StringAttr Data::ArraySize() const { return ::Udm::StringAttr(impl, meta_ArraySize); }
	::Udm::StringAttr Data::ArrayFirstIndex() const { return ::Udm::StringAttr(impl, meta_ArrayFirstIndex); }
	::Udm::StringAttr Data::Scope() const { return ::Udm::StringAttr(impl, meta_Scope); }
	::Udm::ParentAttr< ::ESMoL::State> Data::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Data::meta;
	::Uml::Attribute Data::meta_Description;
	::Uml::Attribute Data::meta_Name;
	::Uml::Attribute Data::meta_DataType;
	::Uml::Attribute Data::meta_Port;
	::Uml::Attribute Data::meta_Units;
	::Uml::Attribute Data::meta_InitialValue;
	::Uml::Attribute Data::meta_Min;
	::Uml::Attribute Data::meta_Max;
	::Uml::Attribute Data::meta_ArraySize;
	::Uml::Attribute Data::meta_ArrayFirstIndex;
	::Uml::Attribute Data::meta_Scope;

	Event::Event() {}
	Event::Event(::Udm::ObjectImpl *impl) : StateDE(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Event::Event(const Event &master) : StateDE(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Event::Event(Event &&master) : StateDE(master), MgaObject(master), UDM_OBJECT(master) {};

	Event Event::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Event& Event::operator=(Event &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Event Event::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Event Event::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Event Event::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Event> Event::Instances() { return ::Udm::InstantiatedAttr< Event>(impl); }
	Event Event::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Event> Event::Derived() { return ::Udm::DerivedAttr< Event>(impl); }
	::Udm::ArchetypeAttr< Event> Event::Archetype() const { return ::Udm::ArchetypeAttr< Event>(impl); }
	::Udm::StringAttr Event::Description() const { return ::Udm::StringAttr(impl, meta_Description); }
	::Udm::StringAttr Event::Name() const { return ::Udm::StringAttr(impl, meta_Name); }
	::Udm::StringAttr Event::Scope() const { return ::Udm::StringAttr(impl, meta_Scope); }
	::Udm::StringAttr Event::Trigger() const { return ::Udm::StringAttr(impl, meta_Trigger); }
	::Udm::IntegerAttr Event::Port() const { return ::Udm::IntegerAttr(impl, meta_Port); }
	::Udm::ParentAttr< ::ESMoL::State> Event::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Event::meta;
	::Uml::Attribute Event::meta_Description;
	::Uml::Attribute Event::meta_Name;
	::Uml::Attribute Event::meta_Scope;
	::Uml::Attribute Event::meta_Trigger;
	::Uml::Attribute Event::meta_Port;

	StateDE::StateDE() {}
	StateDE::StateDE(::Udm::ObjectImpl *impl) : HasRefId(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	StateDE::StateDE(const StateDE &master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	StateDE::StateDE(StateDE &&master) : HasRefId(master), MgaObject(master), UDM_OBJECT(master) {};

	StateDE StateDE::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	StateDE& StateDE::operator=(StateDE &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	StateDE StateDE::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	StateDE StateDE::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	StateDE StateDE::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< StateDE> StateDE::Instances() { return ::Udm::InstantiatedAttr< StateDE>(impl); }
	StateDE StateDE::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< StateDE> StateDE::Derived() { return ::Udm::DerivedAttr< StateDE>(impl); }
	::Udm::ArchetypeAttr< StateDE> StateDE::Archetype() const { return ::Udm::ArchetypeAttr< StateDE>(impl); }
	::Udm::ChildAttr< ::ESMoL::TypeBaseRef> StateDE::TypeBaseRef_child() const { return ::Udm::ChildAttr< ::ESMoL::TypeBaseRef>(impl, meta_TypeBaseRef_child); }
	::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef> StateDE::TypeBaseRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TypeBaseRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> StateDE::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::State> StateDE::State_parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, meta_State_parent); }
	::Udm::ParentAttr< ::ESMoL::State> StateDE::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class StateDE::meta;
	::Uml::CompositionChildRole StateDE::meta_TypeBaseRef_child;
	::Uml::CompositionParentRole StateDE::meta_State_parent;

	Conditional::Conditional() {}
	Conditional::Conditional(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Conditional::Conditional(const Conditional &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Conditional::Conditional(Conditional &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Conditional Conditional::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Conditional& Conditional::operator=(Conditional &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Conditional Conditional::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Conditional Conditional::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Conditional Conditional::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Conditional> Conditional::Instances() { return ::Udm::InstantiatedAttr< Conditional>(impl); }
	Conditional Conditional::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Conditional> Conditional::Derived() { return ::Udm::DerivedAttr< Conditional>(impl); }
	::Udm::ArchetypeAttr< Conditional> Conditional::Archetype() const { return ::Udm::ArchetypeAttr< Conditional>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Conditional::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Conditional::meta;

	ShallowHistory::ShallowHistory() {}
	ShallowHistory::ShallowHistory(::Udm::ObjectImpl *impl) : History(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	ShallowHistory::ShallowHistory(const ShallowHistory &master) : History(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ShallowHistory::ShallowHistory(ShallowHistory &&master) : History(master), MgaObject(master), UDM_OBJECT(master) {};

	ShallowHistory ShallowHistory::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ShallowHistory& ShallowHistory::operator=(ShallowHistory &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ShallowHistory ShallowHistory::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ShallowHistory ShallowHistory::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ShallowHistory ShallowHistory::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ShallowHistory> ShallowHistory::Instances() { return ::Udm::InstantiatedAttr< ShallowHistory>(impl); }
	ShallowHistory ShallowHistory::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ShallowHistory> ShallowHistory::Derived() { return ::Udm::DerivedAttr< ShallowHistory>(impl); }
	::Udm::ArchetypeAttr< ShallowHistory> ShallowHistory::Archetype() const { return ::Udm::ArchetypeAttr< ShallowHistory>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> ShallowHistory::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ShallowHistory::meta;

	DeepHistory::DeepHistory() {}
	DeepHistory::DeepHistory(::Udm::ObjectImpl *impl) : History(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	DeepHistory::DeepHistory(const DeepHistory &master) : History(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DeepHistory::DeepHistory(DeepHistory &&master) : History(master), MgaObject(master), UDM_OBJECT(master) {};

	DeepHistory DeepHistory::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DeepHistory& DeepHistory::operator=(DeepHistory &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DeepHistory DeepHistory::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DeepHistory DeepHistory::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DeepHistory DeepHistory::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DeepHistory> DeepHistory::Instances() { return ::Udm::InstantiatedAttr< DeepHistory>(impl); }
	DeepHistory DeepHistory::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DeepHistory> DeepHistory::Derived() { return ::Udm::DerivedAttr< DeepHistory>(impl); }
	::Udm::ArchetypeAttr< DeepHistory> DeepHistory::Archetype() const { return ::Udm::ArchetypeAttr< DeepHistory>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> DeepHistory::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DeepHistory::meta;

	Join::Join() {}
	Join::Join(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Join::Join(const Join &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Join::Join(Join &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Join Join::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Join& Join::operator=(Join &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Join Join::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Join Join::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Join Join::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Join> Join::Instances() { return ::Udm::InstantiatedAttr< Join>(impl); }
	Join Join::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Join> Join::Derived() { return ::Udm::DerivedAttr< Join>(impl); }
	::Udm::ArchetypeAttr< Join> Join::Archetype() const { return ::Udm::ArchetypeAttr< Join>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Join::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Join::meta;

	Fork::Fork() {}
	Fork::Fork(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Fork::Fork(const Fork &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Fork::Fork(Fork &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Fork Fork::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Fork& Fork::operator=(Fork &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Fork Fork::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Fork Fork::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Fork Fork::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Fork> Fork::Instances() { return ::Udm::InstantiatedAttr< Fork>(impl); }
	Fork Fork::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Fork> Fork::Derived() { return ::Udm::DerivedAttr< Fork>(impl); }
	::Udm::ArchetypeAttr< Fork> Fork::Archetype() const { return ::Udm::ArchetypeAttr< Fork>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Fork::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Fork::meta;

	Choice::Choice() {}
	Choice::Choice(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Choice::Choice(const Choice &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Choice::Choice(Choice &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Choice Choice::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Choice& Choice::operator=(Choice &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Choice Choice::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Choice Choice::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Choice Choice::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Choice> Choice::Instances() { return ::Udm::InstantiatedAttr< Choice>(impl); }
	Choice Choice::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Choice> Choice::Derived() { return ::Udm::DerivedAttr< Choice>(impl); }
	::Udm::ArchetypeAttr< Choice> Choice::Archetype() const { return ::Udm::ArchetypeAttr< Choice>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Choice::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Choice::meta;

	Entry::Entry() {}
	Entry::Entry(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Entry::Entry(const Entry &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Entry::Entry(Entry &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Entry Entry::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Entry& Entry::operator=(Entry &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Entry Entry::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Entry Entry::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Entry Entry::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Entry> Entry::Instances() { return ::Udm::InstantiatedAttr< Entry>(impl); }
	Entry Entry::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Entry> Entry::Derived() { return ::Udm::DerivedAttr< Entry>(impl); }
	::Udm::ArchetypeAttr< Entry> Entry::Archetype() const { return ::Udm::ArchetypeAttr< Entry>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Entry::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Entry::meta;

	Exit::Exit() {}
	Exit::Exit(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Exit::Exit(const Exit &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Exit::Exit(Exit &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Exit Exit::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Exit& Exit::operator=(Exit &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Exit Exit::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Exit Exit::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Exit Exit::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Exit> Exit::Instances() { return ::Udm::InstantiatedAttr< Exit>(impl); }
	Exit Exit::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Exit> Exit::Derived() { return ::Udm::DerivedAttr< Exit>(impl); }
	::Udm::ArchetypeAttr< Exit> Exit::Archetype() const { return ::Udm::ArchetypeAttr< Exit>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Exit::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Exit::meta;

	Terminate::Terminate() {}
	Terminate::Terminate(::Udm::ObjectImpl *impl) : TransConnector(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Terminate::Terminate(const Terminate &master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Terminate::Terminate(Terminate &&master) : TransConnector(master), MgaObject(master), UDM_OBJECT(master) {};

	Terminate Terminate::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Terminate& Terminate::operator=(Terminate &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Terminate Terminate::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Terminate Terminate::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Terminate Terminate::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Terminate> Terminate::Instances() { return ::Udm::InstantiatedAttr< Terminate>(impl); }
	Terminate Terminate::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Terminate> Terminate::Derived() { return ::Udm::DerivedAttr< Terminate>(impl); }
	::Udm::ArchetypeAttr< Terminate> Terminate::Archetype() const { return ::Udm::ArchetypeAttr< Terminate>(impl); }
	::Udm::ParentAttr< ::ESMoL::State> Terminate::parent() const { return ::Udm::ParentAttr< ::ESMoL::State>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Terminate::meta;

	OS::OS() {}
	OS::OS(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	OS::OS(const OS &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OS::OS(OS &&master) : MgaObject(master), UDM_OBJECT(master) {};

	OS OS::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OS& OS::operator=(OS &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OS OS::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OS OS::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OS OS::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OS> OS::Instances() { return ::Udm::InstantiatedAttr< OS>(impl); }
	OS OS::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OS> OS::Derived() { return ::Udm::DerivedAttr< OS>(impl); }
	::Udm::ArchetypeAttr< OS> OS::Archetype() const { return ::Udm::ArchetypeAttr< OS>(impl); }
	::Udm::StringAttr OS::ContextSwitchTime() const { return ::Udm::StringAttr(impl, meta_ContextSwitchTime); }
	::Udm::StringAttr OS::SendOverheadTime() const { return ::Udm::StringAttr(impl, meta_SendOverheadTime); }
	::Udm::StringAttr OS::RecvOverheadTime() const { return ::Udm::StringAttr(impl, meta_RecvOverheadTime); }
	::Udm::StringAttr OS::TickResolution() const { return ::Udm::StringAttr(impl, meta_TickResolution); }
	::Udm::IntegerAttr OS::MaxTaskNumber() const { return ::Udm::IntegerAttr(impl, meta_MaxTaskNumber); }
	::Udm::StringAttr OS::SchedulingAlgorithm() const { return ::Udm::StringAttr(impl, meta_SchedulingAlgorithm); }
	::Udm::StringAttr OS::ISROverheadTime() const { return ::Udm::StringAttr(impl, meta_ISROverheadTime); }
	::Udm::ParentAttr< ::ESMoL::Node> OS::Node_parent() const { return ::Udm::ParentAttr< ::ESMoL::Node>(impl, meta_Node_parent); }
	::Udm::ParentAttr< ::ESMoL::Node> OS::parent() const { return ::Udm::ParentAttr< ::ESMoL::Node>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OS::meta;
	::Uml::Attribute OS::meta_ContextSwitchTime;
	::Uml::Attribute OS::meta_SendOverheadTime;
	::Uml::Attribute OS::meta_RecvOverheadTime;
	::Uml::Attribute OS::meta_TickResolution;
	::Uml::Attribute OS::meta_MaxTaskNumber;
	::Uml::Attribute OS::meta_SchedulingAlgorithm;
	::Uml::Attribute OS::meta_ISROverheadTime;
	::Uml::CompositionParentRole OS::meta_Node_parent;

	Wire::Wire() {}
	Wire::Wire(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Wire::Wire(const Wire &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Wire::Wire(Wire &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Wire Wire::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Wire& Wire::operator=(Wire &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Wire Wire::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Wire Wire::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Wire Wire::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Wire> Wire::Instances() { return ::Udm::InstantiatedAttr< Wire>(impl); }
	Wire Wire::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Wire> Wire::Derived() { return ::Udm::DerivedAttr< Wire>(impl); }
	::Udm::ArchetypeAttr< Wire> Wire::Archetype() const { return ::Udm::ArchetypeAttr< Wire>(impl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Wire::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Wire::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::Connectable> Wire::srcWire_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Connectable>(impl, meta_srcWire_end_); }
	::Udm::AssocEndAttr< ::ESMoL::Connectable> Wire::dstWire_end() const { return ::Udm::AssocEndAttr< ::ESMoL::Connectable>(impl, meta_dstWire_end_); }

	::Uml::Class Wire::meta;
	::Uml::CompositionParentRole Wire::meta_HardwareUnit_parent;
	::Uml::AssociationRole Wire::meta_srcWire_end_;
	::Uml::AssociationRole Wire::meta_dstWire_end_;

	HardwareUnit::HardwareUnit() {}
	HardwareUnit::HardwareUnit(::Udm::ObjectImpl *impl) : HWElement(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	HardwareUnit::HardwareUnit(const HardwareUnit &master) : HWElement(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	HardwareUnit::HardwareUnit(HardwareUnit &&master) : HWElement(master), MgaObject(master), UDM_OBJECT(master) {};

	HardwareUnit HardwareUnit::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	HardwareUnit& HardwareUnit::operator=(HardwareUnit &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	HardwareUnit HardwareUnit::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	HardwareUnit HardwareUnit::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	HardwareUnit HardwareUnit::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< HardwareUnit> HardwareUnit::Instances() { return ::Udm::InstantiatedAttr< HardwareUnit>(impl); }
	HardwareUnit HardwareUnit::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< HardwareUnit> HardwareUnit::Derived() { return ::Udm::DerivedAttr< HardwareUnit>(impl); }
	::Udm::ArchetypeAttr< HardwareUnit> HardwareUnit::Archetype() const { return ::Udm::ArchetypeAttr< HardwareUnit>(impl); }
	::Udm::ChildrenAttr< ::ESMoL::Wire> HardwareUnit::Wire_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Wire>(impl, meta_Wire_children); }
	::Udm::ChildrenAttr< ::ESMoL::HWElement> HardwareUnit::HWElement_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement>(impl, meta_HWElement_children); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> HardwareUnit::Channel_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, meta_Channel_children); }
	::Udm::ChildrenAttr< ::ESMoL::Plant> HardwareUnit::Plant_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Plant>(impl, meta_Plant_children); }
	::Udm::ChildrenAttr< ::ESMoL::PhysConnection> HardwareUnit::PhysConnection_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PhysConnection>(impl, meta_PhysConnection_children); }
	::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection> HardwareUnit::AcquisitionConnection_children() const { return ::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection>(impl, meta_AcquisitionConnection_children); }
	::Udm::ChildrenAttr< ::ESMoL::ActuationConnection> HardwareUnit::ActuationConnection_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ActuationConnection>(impl, meta_ActuationConnection_children); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> HardwareUnit::CommMapping_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Executable> HardwareUnit::Executable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Executable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TTBus> HardwareUnit::TTBus_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TTBus>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OldBus> HardwareUnit::OldBus_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OldBus>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CANBus> HardwareUnit::CANBus_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CANBus>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Link> HardwareUnit::Link_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Link>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::SerialLink> HardwareUnit::SerialLink_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SerialLink>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Wire> HardwareUnit::Wire_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Wire>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> HardwareUnit::HardwareUnit_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Network> HardwareUnit::Network_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Network>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connectable> HardwareUnit::Connectable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HWElement> HardwareUnit::HWElement_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IChan> HardwareUnit::IChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OChan> HardwareUnit::OChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::BChan> HardwareUnit::BChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Bus> HardwareUnit::Bus_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Bus>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Plant> HardwareUnit::Plant_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Plant>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IODevice> HardwareUnit::IODevice_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IODevice>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PhysConnection> HardwareUnit::PhysConnection_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PhysConnection>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection> HardwareUnit::AcquisitionConnection_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::AcquisitionConnection>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ActuationConnection> HardwareUnit::ActuationConnection_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ActuationConnection>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PhysInterface> HardwareUnit::PhysInterface_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PhysInterface>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Node> HardwareUnit::Node_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Node>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> HardwareUnit::Channel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> HardwareUnit::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> HardwareUnit::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::PlatformLibrary> HardwareUnit::PlatformLibrary_parent() const { return ::Udm::ParentAttr< ::ESMoL::PlatformLibrary>(impl, meta_PlatformLibrary_parent); }
	::Udm::ParentAttr< ::Udm::Object> HardwareUnit::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class HardwareUnit::meta;
	::Uml::CompositionChildRole HardwareUnit::meta_Wire_children;
	::Uml::CompositionChildRole HardwareUnit::meta_HWElement_children;
	::Uml::CompositionChildRole HardwareUnit::meta_Channel_children;
	::Uml::CompositionChildRole HardwareUnit::meta_Plant_children;
	::Uml::CompositionChildRole HardwareUnit::meta_PhysConnection_children;
	::Uml::CompositionChildRole HardwareUnit::meta_AcquisitionConnection_children;
	::Uml::CompositionChildRole HardwareUnit::meta_ActuationConnection_children;
	::Uml::CompositionParentRole HardwareUnit::meta_DesignFolder_parent;
	::Uml::CompositionParentRole HardwareUnit::meta_PlatformLibrary_parent;

	PlatformLibrary::PlatformLibrary() {}
	PlatformLibrary::PlatformLibrary(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	PlatformLibrary::PlatformLibrary(const PlatformLibrary &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PlatformLibrary::PlatformLibrary(PlatformLibrary &&master) : UDM_OBJECT(master) {};

	PlatformLibrary PlatformLibrary::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PlatformLibrary& PlatformLibrary::operator=(PlatformLibrary &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PlatformLibrary PlatformLibrary::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PlatformLibrary PlatformLibrary::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PlatformLibrary PlatformLibrary::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PlatformLibrary> PlatformLibrary::Instances() { return ::Udm::InstantiatedAttr< PlatformLibrary>(impl); }
	PlatformLibrary PlatformLibrary::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PlatformLibrary> PlatformLibrary::Derived() { return ::Udm::DerivedAttr< PlatformLibrary>(impl); }
	::Udm::ArchetypeAttr< PlatformLibrary> PlatformLibrary::Archetype() const { return ::Udm::ArchetypeAttr< PlatformLibrary>(impl); }
	::Udm::StringAttr PlatformLibrary::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> PlatformLibrary::HardwareUnit_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_children); }
	::Udm::ChildrenAttr< ::ESMoL::HardwareUnit> PlatformLibrary::HardwareUnit_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::HWElement> PlatformLibrary::HWElement_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> PlatformLibrary::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> PlatformLibrary::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> PlatformLibrary::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PlatformLibrary::meta;
	::Uml::Attribute PlatformLibrary::meta_name;
	::Uml::CompositionChildRole PlatformLibrary::meta_HardwareUnit_children;
	::Uml::CompositionParentRole PlatformLibrary::meta_RootFolder_parent;

	Network::Network() {}
	Network::Network(::Udm::ObjectImpl *impl) : HWElement(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Network::Network(const Network &master) : HWElement(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Network::Network(Network &&master) : HWElement(master), MgaObject(master), UDM_OBJECT(master) {};

	Network Network::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Network& Network::operator=(Network &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Network Network::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Network Network::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Network Network::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Network> Network::Instances() { return ::Udm::InstantiatedAttr< Network>(impl); }
	Network Network::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Network> Network::Derived() { return ::Udm::DerivedAttr< Network>(impl); }
	::Udm::ArchetypeAttr< Network> Network::Archetype() const { return ::Udm::ArchetypeAttr< Network>(impl); }
	::Udm::StringAttr Network::DataRate() const { return ::Udm::StringAttr(impl, meta_DataRate); }
	::Udm::ChildrenAttr< ::ESMoL::BChan> Network::BChan_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BChan>(impl, meta_BChan_children); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> Network::CommMapping_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Executable> Network::Executable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Executable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connectable> Network::Connectable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::BChan> Network::BChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> Network::Channel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Network::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Network::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Network::meta;
	::Uml::Attribute Network::meta_DataRate;
	::Uml::CompositionChildRole Network::meta_BChan_children;

	Connectable::Connectable() {}
	Connectable::Connectable(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Connectable::Connectable(const Connectable &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Connectable::Connectable(Connectable &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Connectable Connectable::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Connectable& Connectable::operator=(Connectable &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Connectable Connectable::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Connectable Connectable::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Connectable Connectable::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Connectable> Connectable::Instances() { return ::Udm::InstantiatedAttr< Connectable>(impl); }
	Connectable Connectable::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Connectable> Connectable::Derived() { return ::Udm::DerivedAttr< Connectable>(impl); }
	::Udm::ArchetypeAttr< Connectable> Connectable::Archetype() const { return ::Udm::ArchetypeAttr< Connectable>(impl); }
	::Udm::AClassAssocAttr< Wire, Connectable> Connectable::dstWire() const { return ::Udm::AClassAssocAttr< Wire, Connectable>(impl, meta_dstWire, meta_dstWire_rev); }
	::Udm::AClassAssocAttr< Wire, Connectable> Connectable::srcWire() const { return ::Udm::AClassAssocAttr< Wire, Connectable>(impl, meta_srcWire, meta_srcWire_rev); }
	::Udm::ParentAttr< ::ESMoL::HWElement> Connectable::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Connectable::meta;
	::Uml::AssociationRole Connectable::meta_dstWire;
	::Uml::AssociationRole Connectable::meta_dstWire_rev;
	::Uml::AssociationRole Connectable::meta_srcWire;
	::Uml::AssociationRole Connectable::meta_srcWire_rev;

	HWElement::HWElement() {}
	HWElement::HWElement(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	HWElement::HWElement(const HWElement &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	HWElement::HWElement(HWElement &&master) : MgaObject(master), UDM_OBJECT(master) {};

	HWElement HWElement::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	HWElement& HWElement::operator=(HWElement &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	HWElement HWElement::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	HWElement HWElement::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	HWElement HWElement::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< HWElement> HWElement::Instances() { return ::Udm::InstantiatedAttr< HWElement>(impl); }
	HWElement HWElement::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< HWElement> HWElement::Derived() { return ::Udm::DerivedAttr< HWElement>(impl); }
	::Udm::ArchetypeAttr< HWElement> HWElement::Archetype() const { return ::Udm::ArchetypeAttr< HWElement>(impl); }
	::Udm::StringAttr HWElement::Configuration() const { return ::Udm::StringAttr(impl, meta_Configuration); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionContext> HWElement::ExecutionContext_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionContext>(impl, meta_ExecutionContext_children); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionContext> HWElement::ExecutionContext_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionContext>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TTExecContext> HWElement::TTExecContext_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TTExecContext>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> HWElement::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> HWElement::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::Udm::Object> HWElement::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class HWElement::meta;
	::Uml::Attribute HWElement::meta_Configuration;
	::Uml::CompositionChildRole HWElement::meta_ExecutionContext_children;
	::Uml::CompositionParentRole HWElement::meta_HardwareUnit_parent;

	IChan::IChan() {}
	IChan::IChan(::Udm::ObjectImpl *impl) : Channel(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	IChan::IChan(const IChan &master) : Channel(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IChan::IChan(IChan &&master) : Channel(master), MgaObject(master), UDM_OBJECT(master) {};

	IChan IChan::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IChan& IChan::operator=(IChan &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IChan IChan::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IChan IChan::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IChan IChan::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IChan> IChan::Instances() { return ::Udm::InstantiatedAttr< IChan>(impl); }
	IChan IChan::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IChan> IChan::Derived() { return ::Udm::DerivedAttr< IChan>(impl); }
	::Udm::ArchetypeAttr< IChan> IChan::Archetype() const { return ::Udm::ArchetypeAttr< IChan>(impl); }
	::Udm::AClassAssocAttr< AcquisitionConnection, IODevice> IChan::srcAcquisitionConnection() const { return ::Udm::AClassAssocAttr< AcquisitionConnection, IODevice>(impl, meta_srcAcquisitionConnection, meta_srcAcquisitionConnection_rev); }
	::Udm::ParentAttr< ::ESMoL::HWElement> IChan::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IChan::meta;
	::Uml::AssociationRole IChan::meta_srcAcquisitionConnection;
	::Uml::AssociationRole IChan::meta_srcAcquisitionConnection_rev;

	OChan::OChan() {}
	OChan::OChan(::Udm::ObjectImpl *impl) : Channel(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	OChan::OChan(const OChan &master) : Channel(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	OChan::OChan(OChan &&master) : Channel(master), MgaObject(master), UDM_OBJECT(master) {};

	OChan OChan::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	OChan& OChan::operator=(OChan &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	OChan OChan::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	OChan OChan::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	OChan OChan::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< OChan> OChan::Instances() { return ::Udm::InstantiatedAttr< OChan>(impl); }
	OChan OChan::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< OChan> OChan::Derived() { return ::Udm::DerivedAttr< OChan>(impl); }
	::Udm::ArchetypeAttr< OChan> OChan::Archetype() const { return ::Udm::ArchetypeAttr< OChan>(impl); }
	::Udm::AClassAssocAttr< ActuationConnection, IODevice> OChan::dstActuationConnection() const { return ::Udm::AClassAssocAttr< ActuationConnection, IODevice>(impl, meta_dstActuationConnection, meta_dstActuationConnection_rev); }
	::Udm::ParentAttr< ::ESMoL::HWElement> OChan::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class OChan::meta;
	::Uml::AssociationRole OChan::meta_dstActuationConnection;
	::Uml::AssociationRole OChan::meta_dstActuationConnection_rev;

	BChan::BChan() {}
	BChan::BChan(::Udm::ObjectImpl *impl) : Channel(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	BChan::BChan(const BChan &master) : Channel(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	BChan::BChan(BChan &&master) : Channel(master), MgaObject(master), UDM_OBJECT(master) {};

	BChan BChan::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	BChan& BChan::operator=(BChan &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	BChan BChan::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	BChan BChan::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	BChan BChan::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< BChan> BChan::Instances() { return ::Udm::InstantiatedAttr< BChan>(impl); }
	BChan BChan::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< BChan> BChan::Derived() { return ::Udm::DerivedAttr< BChan>(impl); }
	::Udm::ArchetypeAttr< BChan> BChan::Archetype() const { return ::Udm::ArchetypeAttr< BChan>(impl); }
	::Udm::ParentAttr< ::ESMoL::Network> BChan::Network_parent() const { return ::Udm::ParentAttr< ::ESMoL::Network>(impl, meta_Network_parent); }
	::Udm::ParentAttr< ::ESMoL::HWElement> BChan::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class BChan::meta;
	::Uml::CompositionParentRole BChan::meta_Network_parent;

	Bus::Bus() {}
	Bus::Bus(::Udm::ObjectImpl *impl) : Connectable(impl),HWElement(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Bus::Bus(const Bus &master) : Connectable(master),HWElement(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Bus::Bus(Bus &&master) : Connectable(master),HWElement(master), MgaObject(master), UDM_OBJECT(master) {};

	Bus Bus::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Bus& Bus::operator=(Bus &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Bus Bus::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Bus Bus::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Bus Bus::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Bus> Bus::Instances() { return ::Udm::InstantiatedAttr< Bus>(impl); }
	Bus Bus::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Bus> Bus::Derived() { return ::Udm::DerivedAttr< Bus>(impl); }
	::Udm::ArchetypeAttr< Bus> Bus::Archetype() const { return ::Udm::ArchetypeAttr< Bus>(impl); }
	::Udm::StringAttr Bus::DataRate() const { return ::Udm::StringAttr(impl, meta_DataRate); }
	::Udm::StringAttr Bus::DeprecatedOH() const { return ::Udm::StringAttr(impl, meta_DeprecatedOH); }
	::Udm::StringAttr Bus::MinFrameSize() const { return ::Udm::StringAttr(impl, meta_MinFrameSize); }
	::Udm::StringAttr Bus::SwitchMemorySize() const { return ::Udm::StringAttr(impl, meta_SwitchMemorySize); }
	::Udm::IntegerAttr Bus::ID() const { return ::Udm::IntegerAttr(impl, meta_ID); }
	::Udm::StringAttr Bus::SetupTime() const { return ::Udm::StringAttr(impl, meta_SetupTime); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Bus::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Bus::meta;
	::Uml::Attribute Bus::meta_DataRate;
	::Uml::Attribute Bus::meta_DeprecatedOH;
	::Uml::Attribute Bus::meta_MinFrameSize;
	::Uml::Attribute Bus::meta_SwitchMemorySize;
	::Uml::Attribute Bus::meta_ID;
	::Uml::Attribute Bus::meta_SetupTime;

	Plant::Plant() {}
	Plant::Plant(::Udm::ObjectImpl *impl) : PhysInterface(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Plant::Plant(const Plant &master) : PhysInterface(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Plant::Plant(Plant &&master) : PhysInterface(master), MgaObject(master), UDM_OBJECT(master) {};

	Plant Plant::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Plant& Plant::operator=(Plant &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Plant Plant::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Plant Plant::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Plant Plant::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Plant> Plant::Instances() { return ::Udm::InstantiatedAttr< Plant>(impl); }
	Plant Plant::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Plant> Plant::Derived() { return ::Udm::DerivedAttr< Plant>(impl); }
	::Udm::ArchetypeAttr< Plant> Plant::Archetype() const { return ::Udm::ArchetypeAttr< Plant>(impl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Plant::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Plant::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Plant::meta;
	::Uml::CompositionParentRole Plant::meta_HardwareUnit_parent;

	IODevice::IODevice() {}
	IODevice::IODevice(::Udm::ObjectImpl *impl) : HWElement(impl),PhysInterface(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	IODevice::IODevice(const IODevice &master) : HWElement(master),PhysInterface(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	IODevice::IODevice(IODevice &&master) : HWElement(master),PhysInterface(master), MgaObject(master), UDM_OBJECT(master) {};

	IODevice IODevice::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	IODevice& IODevice::operator=(IODevice &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	IODevice IODevice::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	IODevice IODevice::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	IODevice IODevice::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< IODevice> IODevice::Instances() { return ::Udm::InstantiatedAttr< IODevice>(impl); }
	IODevice IODevice::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< IODevice> IODevice::Derived() { return ::Udm::DerivedAttr< IODevice>(impl); }
	::Udm::ArchetypeAttr< IODevice> IODevice::Archetype() const { return ::Udm::ArchetypeAttr< IODevice>(impl); }
	::Udm::StringAttr IODevice::DeviceType() const { return ::Udm::StringAttr(impl, meta_DeviceType); }
	::Udm::AClassAssocAttr< ActuationConnection, OChan> IODevice::srcActuationConnection() const { return ::Udm::AClassAssocAttr< ActuationConnection, OChan>(impl, meta_srcActuationConnection, meta_srcActuationConnection_rev); }
	::Udm::AClassAssocAttr< AcquisitionConnection, IChan> IODevice::dstAcquisitionConnection() const { return ::Udm::AClassAssocAttr< AcquisitionConnection, IChan>(impl, meta_dstAcquisitionConnection, meta_dstAcquisitionConnection_rev); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> IODevice::Channel_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, meta_Channel_children); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> IODevice::CommMapping_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Executable> IODevice::Executable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Executable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connectable> IODevice::Connectable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IChan> IODevice::IChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OChan> IODevice::OChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::BChan> IODevice::BChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> IODevice::Channel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> IODevice::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> IODevice::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class IODevice::meta;
	::Uml::Attribute IODevice::meta_DeviceType;
	::Uml::AssociationRole IODevice::meta_srcActuationConnection;
	::Uml::AssociationRole IODevice::meta_srcActuationConnection_rev;
	::Uml::AssociationRole IODevice::meta_dstAcquisitionConnection;
	::Uml::AssociationRole IODevice::meta_dstAcquisitionConnection_rev;
	::Uml::CompositionChildRole IODevice::meta_Channel_children;

	PhysConnection::PhysConnection() {}
	PhysConnection::PhysConnection(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	PhysConnection::PhysConnection(const PhysConnection &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PhysConnection::PhysConnection(PhysConnection &&master) : MgaObject(master), UDM_OBJECT(master) {};

	PhysConnection PhysConnection::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PhysConnection& PhysConnection::operator=(PhysConnection &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PhysConnection PhysConnection::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PhysConnection PhysConnection::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PhysConnection PhysConnection::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PhysConnection> PhysConnection::Instances() { return ::Udm::InstantiatedAttr< PhysConnection>(impl); }
	PhysConnection PhysConnection::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PhysConnection> PhysConnection::Derived() { return ::Udm::DerivedAttr< PhysConnection>(impl); }
	::Udm::ArchetypeAttr< PhysConnection> PhysConnection::Archetype() const { return ::Udm::ArchetypeAttr< PhysConnection>(impl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> PhysConnection::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> PhysConnection::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::PhysInterface> PhysConnection::srcPhysConnection_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PhysInterface>(impl, meta_srcPhysConnection_end_); }
	::Udm::AssocEndAttr< ::ESMoL::PhysInterface> PhysConnection::dstPhysConnection_end() const { return ::Udm::AssocEndAttr< ::ESMoL::PhysInterface>(impl, meta_dstPhysConnection_end_); }

	::Uml::Class PhysConnection::meta;
	::Uml::CompositionParentRole PhysConnection::meta_HardwareUnit_parent;
	::Uml::AssociationRole PhysConnection::meta_srcPhysConnection_end_;
	::Uml::AssociationRole PhysConnection::meta_dstPhysConnection_end_;

	AcquisitionConnection::AcquisitionConnection() {}
	AcquisitionConnection::AcquisitionConnection(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	AcquisitionConnection::AcquisitionConnection(const AcquisitionConnection &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	AcquisitionConnection::AcquisitionConnection(AcquisitionConnection &&master) : MgaObject(master), UDM_OBJECT(master) {};

	AcquisitionConnection AcquisitionConnection::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	AcquisitionConnection& AcquisitionConnection::operator=(AcquisitionConnection &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	AcquisitionConnection AcquisitionConnection::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	AcquisitionConnection AcquisitionConnection::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	AcquisitionConnection AcquisitionConnection::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< AcquisitionConnection> AcquisitionConnection::Instances() { return ::Udm::InstantiatedAttr< AcquisitionConnection>(impl); }
	AcquisitionConnection AcquisitionConnection::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< AcquisitionConnection> AcquisitionConnection::Derived() { return ::Udm::DerivedAttr< AcquisitionConnection>(impl); }
	::Udm::ArchetypeAttr< AcquisitionConnection> AcquisitionConnection::Archetype() const { return ::Udm::ArchetypeAttr< AcquisitionConnection>(impl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> AcquisitionConnection::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> AcquisitionConnection::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::IODevice> AcquisitionConnection::srcAcquisitionConnection_end() const { return ::Udm::AssocEndAttr< ::ESMoL::IODevice>(impl, meta_srcAcquisitionConnection_end_); }
	::Udm::AssocEndAttr< ::ESMoL::IChan> AcquisitionConnection::dstAcquisitionConnection_end() const { return ::Udm::AssocEndAttr< ::ESMoL::IChan>(impl, meta_dstAcquisitionConnection_end_); }

	::Uml::Class AcquisitionConnection::meta;
	::Uml::CompositionParentRole AcquisitionConnection::meta_HardwareUnit_parent;
	::Uml::AssociationRole AcquisitionConnection::meta_srcAcquisitionConnection_end_;
	::Uml::AssociationRole AcquisitionConnection::meta_dstAcquisitionConnection_end_;

	ActuationConnection::ActuationConnection() {}
	ActuationConnection::ActuationConnection(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ActuationConnection::ActuationConnection(const ActuationConnection &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ActuationConnection::ActuationConnection(ActuationConnection &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ActuationConnection ActuationConnection::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ActuationConnection& ActuationConnection::operator=(ActuationConnection &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ActuationConnection ActuationConnection::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ActuationConnection ActuationConnection::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ActuationConnection ActuationConnection::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ActuationConnection> ActuationConnection::Instances() { return ::Udm::InstantiatedAttr< ActuationConnection>(impl); }
	ActuationConnection ActuationConnection::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ActuationConnection> ActuationConnection::Derived() { return ::Udm::DerivedAttr< ActuationConnection>(impl); }
	::Udm::ArchetypeAttr< ActuationConnection> ActuationConnection::Archetype() const { return ::Udm::ArchetypeAttr< ActuationConnection>(impl); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> ActuationConnection::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> ActuationConnection::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::OChan> ActuationConnection::srcActuationConnection_end() const { return ::Udm::AssocEndAttr< ::ESMoL::OChan>(impl, meta_srcActuationConnection_end_); }
	::Udm::AssocEndAttr< ::ESMoL::IODevice> ActuationConnection::dstActuationConnection_end() const { return ::Udm::AssocEndAttr< ::ESMoL::IODevice>(impl, meta_dstActuationConnection_end_); }

	::Uml::Class ActuationConnection::meta;
	::Uml::CompositionParentRole ActuationConnection::meta_HardwareUnit_parent;
	::Uml::AssociationRole ActuationConnection::meta_srcActuationConnection_end_;
	::Uml::AssociationRole ActuationConnection::meta_dstActuationConnection_end_;

	PhysInterface::PhysInterface() {}
	PhysInterface::PhysInterface(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	PhysInterface::PhysInterface(const PhysInterface &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PhysInterface::PhysInterface(PhysInterface &&master) : MgaObject(master), UDM_OBJECT(master) {};

	PhysInterface PhysInterface::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PhysInterface& PhysInterface::operator=(PhysInterface &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PhysInterface PhysInterface::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PhysInterface PhysInterface::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PhysInterface PhysInterface::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PhysInterface> PhysInterface::Instances() { return ::Udm::InstantiatedAttr< PhysInterface>(impl); }
	PhysInterface PhysInterface::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PhysInterface> PhysInterface::Derived() { return ::Udm::DerivedAttr< PhysInterface>(impl); }
	::Udm::ArchetypeAttr< PhysInterface> PhysInterface::Archetype() const { return ::Udm::ArchetypeAttr< PhysInterface>(impl); }
	::Udm::AClassAssocAttr< PhysConnection, PhysInterface> PhysInterface::dstPhysConnection() const { return ::Udm::AClassAssocAttr< PhysConnection, PhysInterface>(impl, meta_dstPhysConnection, meta_dstPhysConnection_rev); }
	::Udm::AClassAssocAttr< PhysConnection, PhysInterface> PhysInterface::srcPhysConnection() const { return ::Udm::AClassAssocAttr< PhysConnection, PhysInterface>(impl, meta_srcPhysConnection, meta_srcPhysConnection_rev); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> PhysInterface::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PhysInterface::meta;
	::Uml::AssociationRole PhysInterface::meta_dstPhysConnection;
	::Uml::AssociationRole PhysInterface::meta_dstPhysConnection_rev;
	::Uml::AssociationRole PhysInterface::meta_srcPhysConnection;
	::Uml::AssociationRole PhysInterface::meta_srcPhysConnection_rev;

	Node::Node() {}
	Node::Node(::Udm::ObjectImpl *impl) : HWElement(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Node::Node(const Node &master) : HWElement(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Node::Node(Node &&master) : HWElement(master), MgaObject(master), UDM_OBJECT(master) {};

	Node Node::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Node& Node::operator=(Node &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Node Node::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Node Node::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Node Node::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Node> Node::Instances() { return ::Udm::InstantiatedAttr< Node>(impl); }
	Node Node::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Node> Node::Derived() { return ::Udm::DerivedAttr< Node>(impl); }
	::Udm::ArchetypeAttr< Node> Node::Archetype() const { return ::Udm::ArchetypeAttr< Node>(impl); }
	::Udm::StringAttr Node::Simulator() const { return ::Udm::StringAttr(impl, meta_Simulator); }
	::Udm::IntegerAttr Node::ROM() const { return ::Udm::IntegerAttr(impl, meta_ROM); }
	::Udm::IntegerAttr Node::RAM() const { return ::Udm::IntegerAttr(impl, meta_RAM); }
	::Udm::IntegerAttr Node::Speed() const { return ::Udm::IntegerAttr(impl, meta_Speed); }
	::Udm::StringAttr Node::CPU() const { return ::Udm::StringAttr(impl, meta_CPU); }
	::Udm::StringAttr Node::PlatformType() const { return ::Udm::StringAttr(impl, meta_PlatformType); }
	::Udm::StringAttr Node::BusIDList() const { return ::Udm::StringAttr(impl, meta_BusIDList); }
	::Udm::AssocAttr< NodeRef> Node::referedbyNodeRef() const { return ::Udm::AssocAttr< NodeRef>(impl, meta_referedbyNodeRef); }
	::Udm::ChildAttr< ::ESMoL::OS> Node::OS_child() const { return ::Udm::ChildAttr< ::ESMoL::OS>(impl, meta_OS_child); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> Node::Channel_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, meta_Channel_children); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base> Node::CommMapping_Members_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_Members_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Executable> Node::Executable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Executable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OS> Node::OS_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OS>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Connectable> Node::Connectable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Connectable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::IChan> Node::IChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::IChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::OChan> Node::OChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::OChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::BChan> Node::BChan_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::BChan>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Channel> Node::Channel_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Channel>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> Node::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Node::parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Node::meta;
	::Uml::Attribute Node::meta_Simulator;
	::Uml::Attribute Node::meta_ROM;
	::Uml::Attribute Node::meta_RAM;
	::Uml::Attribute Node::meta_Speed;
	::Uml::Attribute Node::meta_CPU;
	::Uml::Attribute Node::meta_PlatformType;
	::Uml::Attribute Node::meta_BusIDList;
	::Uml::AssociationRole Node::meta_referedbyNodeRef;
	::Uml::CompositionChildRole Node::meta_OS_child;
	::Uml::CompositionChildRole Node::meta_Channel_children;

	Channel::Channel() {}
	Channel::Channel(::Udm::ObjectImpl *impl) : CommMapping_Members_Base(impl),Executable(impl),Connectable(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	Channel::Channel(const Channel &master) : CommMapping_Members_Base(master),Executable(master),Connectable(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Channel::Channel(Channel &&master) : CommMapping_Members_Base(master),Executable(master),Connectable(master), MgaObject(master), UDM_OBJECT(master) {};

	Channel Channel::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Channel& Channel::operator=(Channel &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Channel Channel::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Channel Channel::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Channel Channel::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Channel> Channel::Instances() { return ::Udm::InstantiatedAttr< Channel>(impl); }
	Channel Channel::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Channel> Channel::Derived() { return ::Udm::DerivedAttr< Channel>(impl); }
	::Udm::ArchetypeAttr< Channel> Channel::Archetype() const { return ::Udm::ArchetypeAttr< Channel>(impl); }
	::Udm::StringAttr Channel::Configuration() const { return ::Udm::StringAttr(impl, meta_Configuration); }
	::Udm::IntegerAttr Channel::ChanNum() const { return ::Udm::IntegerAttr(impl, meta_ChanNum); }
	::Udm::ParentAttr< ::ESMoL::HardwareUnit> Channel::HardwareUnit_parent() const { return ::Udm::ParentAttr< ::ESMoL::HardwareUnit>(impl, meta_HardwareUnit_parent); }
	::Udm::ParentAttr< ::ESMoL::IODevice> Channel::IODevice_parent() const { return ::Udm::ParentAttr< ::ESMoL::IODevice>(impl, meta_IODevice_parent); }
	::Udm::ParentAttr< ::ESMoL::Node> Channel::Node_parent() const { return ::Udm::ParentAttr< ::ESMoL::Node>(impl, meta_Node_parent); }
	::Udm::ParentAttr< ::ESMoL::HWElement> Channel::parent() const { return ::Udm::ParentAttr< ::ESMoL::HWElement>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class Channel::meta;
	::Uml::Attribute Channel::meta_Configuration;
	::Uml::Attribute Channel::meta_ChanNum;
	::Uml::CompositionParentRole Channel::meta_HardwareUnit_parent;
	::Uml::CompositionParentRole Channel::meta_IODevice_parent;
	::Uml::CompositionParentRole Channel::meta_Node_parent;

	DeploymentLibrary::DeploymentLibrary() {}
	DeploymentLibrary::DeploymentLibrary(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	DeploymentLibrary::DeploymentLibrary(const DeploymentLibrary &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	DeploymentLibrary::DeploymentLibrary(DeploymentLibrary &&master) : UDM_OBJECT(master) {};

	DeploymentLibrary DeploymentLibrary::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	DeploymentLibrary& DeploymentLibrary::operator=(DeploymentLibrary &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	DeploymentLibrary DeploymentLibrary::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	DeploymentLibrary DeploymentLibrary::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	DeploymentLibrary DeploymentLibrary::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< DeploymentLibrary> DeploymentLibrary::Instances() { return ::Udm::InstantiatedAttr< DeploymentLibrary>(impl); }
	DeploymentLibrary DeploymentLibrary::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< DeploymentLibrary> DeploymentLibrary::Derived() { return ::Udm::DerivedAttr< DeploymentLibrary>(impl); }
	::Udm::ArchetypeAttr< DeploymentLibrary> DeploymentLibrary::Archetype() const { return ::Udm::ArchetypeAttr< DeploymentLibrary>(impl); }
	::Udm::StringAttr DeploymentLibrary::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::System> DeploymentLibrary::System_children() const { return ::Udm::ChildrenAttr< ::ESMoL::System>(impl, meta_System_children); }
	::Udm::ChildrenAttr< ::ESMoL::System> DeploymentLibrary::System_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::System>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> DeploymentLibrary::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> DeploymentLibrary::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> DeploymentLibrary::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class DeploymentLibrary::meta;
	::Uml::Attribute DeploymentLibrary::meta_name;
	::Uml::CompositionChildRole DeploymentLibrary::meta_System_children;
	::Uml::CompositionParentRole DeploymentLibrary::meta_RootFolder_parent;

	System::System() {}
	System::System(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	System::System(const System &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	System::System(System &&master) : MgaObject(master), UDM_OBJECT(master) {};

	System System::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	System& System::operator=(System &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	System System::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	System System::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	System System::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< System> System::Instances() { return ::Udm::InstantiatedAttr< System>(impl); }
	System System::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< System> System::Derived() { return ::Udm::DerivedAttr< System>(impl); }
	::Udm::ArchetypeAttr< System> System::Archetype() const { return ::Udm::ArchetypeAttr< System>(impl); }
	::Udm::AssocAttr< DesignReference> System::referedbyDesignReference() const { return ::Udm::AssocAttr< DesignReference>(impl, meta_referedbyDesignReference); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentRef> System::ComponentRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef>(impl, meta_ComponentRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::NodeRef> System::NodeRef_children() const { return ::Udm::ChildrenAttr< ::ESMoL::NodeRef>(impl, meta_NodeRef_children); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping> System::CommMapping_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping>(impl, meta_CommMapping_children); }
	::Udm::ChildrenAttr< ::ESMoL::Dependency> System::Dependency_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Dependency>(impl, meta_Dependency_children); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment> System::ComponentAssignment_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment>(impl, meta_ComponentAssignment_children); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo> System::ExecutionInfo_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo>(impl, meta_ExecutionInfo_children); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment> System::ExecutionAssignment_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment>(impl, meta_ExecutionAssignment_children); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base> System::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment_dstExecutionAssignment_RPContainer_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_srcCommMapping_RPContainer_Base> System::CommMapping_srcCommMapping_RPContainer_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_srcCommMapping_RPContainer_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping_dstCommMapping_RPContainer_Base> System::CommMapping_dstCommMapping_RPContainer_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping_dstCommMapping_RPContainer_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base> System::ComponentRef_RefersTo_Base_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef_RefersTo_Base>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo> System::ExecutionInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::TTExecInfo> System::TTExecInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::TTExecInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::AsyncPeriodicExecInfo> System::AsyncPeriodicExecInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::AsyncPeriodicExecInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PeriodicExecInfo> System::PeriodicExecInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PeriodicExecInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment> System::ExecutionAssignment_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ExecutionAssignment>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Executable> System::Executable_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Executable>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::AperiodicExecInfo> System::AperiodicExecInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::AperiodicExecInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::SporadicExecInfo> System::SporadicExecInfo_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::SporadicExecInfo>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::NodeRef> System::NodeRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::NodeRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentRef> System::ComponentRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::CommMapping> System::CommMapping_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::CommMapping>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Dependency> System::Dependency_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Dependency>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment> System::ComponentAssignment_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ComponentAssignment>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PlantComponentRef> System::PlantComponentRef_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PlantComponentRef>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::MgaObject> System::MgaObject_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::MgaObject>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::DesignFolder> System::DesignFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::DeploymentLibrary> System::DeploymentLibrary_parent() const { return ::Udm::ParentAttr< ::ESMoL::DeploymentLibrary>(impl, meta_DeploymentLibrary_parent); }
	::Udm::ParentAttr< ::Udm::Object> System::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class System::meta;
	::Uml::AssociationRole System::meta_referedbyDesignReference;
	::Uml::CompositionChildRole System::meta_ComponentRef_children;
	::Uml::CompositionChildRole System::meta_NodeRef_children;
	::Uml::CompositionChildRole System::meta_CommMapping_children;
	::Uml::CompositionChildRole System::meta_Dependency_children;
	::Uml::CompositionChildRole System::meta_ComponentAssignment_children;
	::Uml::CompositionChildRole System::meta_ExecutionInfo_children;
	::Uml::CompositionChildRole System::meta_ExecutionAssignment_children;
	::Uml::CompositionParentRole System::meta_DesignFolder_parent;
	::Uml::CompositionParentRole System::meta_DeploymentLibrary_parent;

	NodeRef::NodeRef() {}
	NodeRef::NodeRef(::Udm::ObjectImpl *impl) : ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(impl),CommMapping_srcCommMapping_RPContainer_Base(impl),CommMapping_dstCommMapping_RPContainer_Base(impl),MgaObject(impl), UDM_OBJECT(impl) {}
	NodeRef::NodeRef(const NodeRef &master) : ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(master),CommMapping_srcCommMapping_RPContainer_Base(master),CommMapping_dstCommMapping_RPContainer_Base(master),MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	NodeRef::NodeRef(NodeRef &&master) : ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(master),CommMapping_srcCommMapping_RPContainer_Base(master),CommMapping_dstCommMapping_RPContainer_Base(master),MgaObject(master), UDM_OBJECT(master) {};

	NodeRef NodeRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	NodeRef& NodeRef::operator=(NodeRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	NodeRef NodeRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	NodeRef NodeRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	NodeRef NodeRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< NodeRef> NodeRef::Instances() { return ::Udm::InstantiatedAttr< NodeRef>(impl); }
	NodeRef NodeRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< NodeRef> NodeRef::Derived() { return ::Udm::DerivedAttr< NodeRef>(impl); }
	::Udm::ArchetypeAttr< NodeRef> NodeRef::Archetype() const { return ::Udm::ArchetypeAttr< NodeRef>(impl); }
	::Udm::PointerAttr< Node> NodeRef::ref() const { return ::Udm::PointerAttr< Node>(impl, meta_ref); }
	::Udm::AClassAssocAttr< ComponentAssignment, ComponentRef> NodeRef::srcComponentAssignment() const { return ::Udm::AClassAssocAttr< ComponentAssignment, ComponentRef>(impl, meta_srcComponentAssignment, meta_srcComponentAssignment_rev); }
	::Udm::ParentAttr< ::ESMoL::System> NodeRef::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> NodeRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class NodeRef::meta;
	::Uml::AssociationRole NodeRef::meta_ref;
	::Uml::AssociationRole NodeRef::meta_srcComponentAssignment;
	::Uml::AssociationRole NodeRef::meta_srcComponentAssignment_rev;
	::Uml::CompositionParentRole NodeRef::meta_System_parent;

	ComponentRef::ComponentRef() {}
	ComponentRef::ComponentRef(::Udm::ObjectImpl *impl) : ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(impl),CommMapping_srcCommMapping_RPContainer_Base(impl),CommMapping_dstCommMapping_RPContainer_Base(impl),ComponentRef_RefersTo_Base(impl),Executable(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	ComponentRef::ComponentRef(const ComponentRef &master) : ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(master),CommMapping_srcCommMapping_RPContainer_Base(master),CommMapping_dstCommMapping_RPContainer_Base(master),ComponentRef_RefersTo_Base(master),Executable(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ComponentRef::ComponentRef(ComponentRef &&master) : ExecutionAssignment_dstExecutionAssignment_RPContainer_Base(master),CommMapping_srcCommMapping_RPContainer_Base(master),CommMapping_dstCommMapping_RPContainer_Base(master),ComponentRef_RefersTo_Base(master),Executable(master), MgaObject(master), UDM_OBJECT(master) {};

	ComponentRef ComponentRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ComponentRef& ComponentRef::operator=(ComponentRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ComponentRef ComponentRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ComponentRef ComponentRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ComponentRef ComponentRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ComponentRef> ComponentRef::Instances() { return ::Udm::InstantiatedAttr< ComponentRef>(impl); }
	ComponentRef ComponentRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ComponentRef> ComponentRef::Derived() { return ::Udm::DerivedAttr< ComponentRef>(impl); }
	::Udm::ArchetypeAttr< ComponentRef> ComponentRef::Archetype() const { return ::Udm::ArchetypeAttr< ComponentRef>(impl); }
	::Udm::AssocAttr< TaskInst> ComponentRef::referedbyTaskInst() const { return ::Udm::AssocAttr< TaskInst>(impl, meta_referedbyTaskInst); }
	::Udm::AssocAttr< Action> ComponentRef::referedbyAction() const { return ::Udm::AssocAttr< Action>(impl, meta_referedbyAction); }
	::Udm::AssocAttr< FaultMgrTask> ComponentRef::referedbyFaultMgrTask() const { return ::Udm::AssocAttr< FaultMgrTask>(impl, meta_referedbyFaultMgrTask); }
	::Udm::AssocAttr< Dependency> ComponentRef::srcDependency__rp_helper_rev() const { return ::Udm::AssocAttr< Dependency>(impl, meta_srcDependency__rp_helper_rev); }
	::Udm::AssocAttr< Dependency> ComponentRef::dstDependency__rp_helper_rev() const { return ::Udm::AssocAttr< Dependency>(impl, meta_dstDependency__rp_helper_rev); }
	::Udm::AClassAssocAttr< ComponentAssignment, NodeRef> ComponentRef::dstComponentAssignment() const { return ::Udm::AClassAssocAttr< ComponentAssignment, NodeRef>(impl, meta_dstComponentAssignment, meta_dstComponentAssignment_rev); }
	::Udm::PointerAttr< ComponentRef_RefersTo_Base> ComponentRef::ref() const { return ::Udm::PointerAttr< ComponentRef_RefersTo_Base>(impl, meta_ref); }
	::Udm::ParentAttr< ::ESMoL::System> ComponentRef::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> ComponentRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class ComponentRef::meta;
	::Uml::AssociationRole ComponentRef::meta_referedbyTaskInst;
	::Uml::AssociationRole ComponentRef::meta_referedbyAction;
	::Uml::AssociationRole ComponentRef::meta_referedbyFaultMgrTask;
	::Uml::AssociationRole ComponentRef::meta_srcDependency__rp_helper_rev;
	::Uml::AssociationRole ComponentRef::meta_dstDependency__rp_helper_rev;
	::Uml::AssociationRole ComponentRef::meta_dstComponentAssignment;
	::Uml::AssociationRole ComponentRef::meta_dstComponentAssignment_rev;
	::Uml::AssociationRole ComponentRef::meta_ref;
	::Uml::CompositionParentRole ComponentRef::meta_System_parent;

	CommMapping::CommMapping() {}
	CommMapping::CommMapping(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	CommMapping::CommMapping(const CommMapping &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	CommMapping::CommMapping(CommMapping &&master) : MgaObject(master), UDM_OBJECT(master) {};

	CommMapping CommMapping::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	CommMapping& CommMapping::operator=(CommMapping &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	CommMapping CommMapping::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	CommMapping CommMapping::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	CommMapping CommMapping::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< CommMapping> CommMapping::Instances() { return ::Udm::InstantiatedAttr< CommMapping>(impl); }
	CommMapping CommMapping::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< CommMapping> CommMapping::Derived() { return ::Udm::DerivedAttr< CommMapping>(impl); }
	::Udm::ArchetypeAttr< CommMapping> CommMapping::Archetype() const { return ::Udm::ArchetypeAttr< CommMapping>(impl); }
	::Udm::PointerAttr< CommMapping_srcCommMapping_RPContainer_Base> CommMapping::srcCommMapping__rp_helper() const { return ::Udm::PointerAttr< CommMapping_srcCommMapping_RPContainer_Base>(impl, meta_srcCommMapping__rp_helper); }
	::Udm::PointerAttr< CommMapping_dstCommMapping_RPContainer_Base> CommMapping::dstCommMapping__rp_helper() const { return ::Udm::PointerAttr< CommMapping_dstCommMapping_RPContainer_Base>(impl, meta_dstCommMapping__rp_helper); }
	::Udm::ParentAttr< ::ESMoL::System> CommMapping::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> CommMapping::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::CommMapping_Members_Base> CommMapping::srcCommMapping_end() const { return ::Udm::AssocEndAttr< ::ESMoL::CommMapping_Members_Base>(impl, meta_srcCommMapping_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::CommMapping_Members_Base, CommMapping::srcCommMapping_chain_t > CommMapping::srcCommMapping_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::CommMapping_Members_Base, CommMapping::srcCommMapping_chain_t >(impl, meta_srcCommMapping_end_); }
	::Udm::AssocEndAttr< ::ESMoL::CommMapping_Members_Base> CommMapping::dstCommMapping_end() const { return ::Udm::AssocEndAttr< ::ESMoL::CommMapping_Members_Base>(impl, meta_dstCommMapping_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::CommMapping_Members_Base, CommMapping::dstCommMapping_chain_t > CommMapping::dstCommMapping_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::CommMapping_Members_Base, CommMapping::dstCommMapping_chain_t >(impl, meta_dstCommMapping_end_); }

	::Uml::Class CommMapping::meta;
	::Uml::AssociationRole CommMapping::meta_srcCommMapping__rp_helper;
	::Uml::AssociationRole CommMapping::meta_dstCommMapping__rp_helper;
	::Uml::CompositionParentRole CommMapping::meta_System_parent;
	::Uml::AssociationRole CommMapping::meta_srcCommMapping_end_;
	::Uml::AssociationRole CommMapping::meta_dstCommMapping_end_;

	Dependency::Dependency() {}
	Dependency::Dependency(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	Dependency::Dependency(const Dependency &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	Dependency::Dependency(Dependency &&master) : MgaObject(master), UDM_OBJECT(master) {};

	Dependency Dependency::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	Dependency& Dependency::operator=(Dependency &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	Dependency Dependency::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	Dependency Dependency::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	Dependency Dependency::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< Dependency> Dependency::Instances() { return ::Udm::InstantiatedAttr< Dependency>(impl); }
	Dependency Dependency::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< Dependency> Dependency::Derived() { return ::Udm::DerivedAttr< Dependency>(impl); }
	::Udm::ArchetypeAttr< Dependency> Dependency::Archetype() const { return ::Udm::ArchetypeAttr< Dependency>(impl); }
	::Udm::PointerAttr< ComponentRef> Dependency::srcDependency__rp_helper() const { return ::Udm::PointerAttr< ComponentRef>(impl, meta_srcDependency__rp_helper); }
	::Udm::PointerAttr< ComponentRef> Dependency::dstDependency__rp_helper() const { return ::Udm::PointerAttr< ComponentRef>(impl, meta_dstDependency__rp_helper); }
	::Udm::ParentAttr< ::ESMoL::System> Dependency::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> Dependency::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::MessageRef> Dependency::srcDependency_end() const { return ::Udm::AssocEndAttr< ::ESMoL::MessageRef>(impl, meta_srcDependency_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::MessageRef, Dependency::srcDependency_chain_t > Dependency::srcDependency_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::MessageRef, Dependency::srcDependency_chain_t >(impl, meta_srcDependency_end_); }
	::Udm::AssocEndAttr< ::ESMoL::MessageRef> Dependency::dstDependency_end() const { return ::Udm::AssocEndAttr< ::ESMoL::MessageRef>(impl, meta_dstDependency_end_); }
	::Udm::AssocEndChainAttr< ::ESMoL::MessageRef, Dependency::dstDependency_chain_t > Dependency::dstDependency_chain() const { return ::Udm::AssocEndChainAttr< ::ESMoL::MessageRef, Dependency::dstDependency_chain_t >(impl, meta_dstDependency_end_); }

	::Uml::Class Dependency::meta;
	::Uml::AssociationRole Dependency::meta_srcDependency__rp_helper;
	::Uml::AssociationRole Dependency::meta_dstDependency__rp_helper;
	::Uml::CompositionParentRole Dependency::meta_System_parent;
	::Uml::AssociationRole Dependency::meta_srcDependency_end_;
	::Uml::AssociationRole Dependency::meta_dstDependency_end_;

	ComponentAssignment::ComponentAssignment() {}
	ComponentAssignment::ComponentAssignment(::Udm::ObjectImpl *impl) : MgaObject(impl), UDM_OBJECT(impl) {}
	ComponentAssignment::ComponentAssignment(const ComponentAssignment &master) : MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	ComponentAssignment::ComponentAssignment(ComponentAssignment &&master) : MgaObject(master), UDM_OBJECT(master) {};

	ComponentAssignment ComponentAssignment::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	ComponentAssignment& ComponentAssignment::operator=(ComponentAssignment &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	ComponentAssignment ComponentAssignment::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	ComponentAssignment ComponentAssignment::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	ComponentAssignment ComponentAssignment::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< ComponentAssignment> ComponentAssignment::Instances() { return ::Udm::InstantiatedAttr< ComponentAssignment>(impl); }
	ComponentAssignment ComponentAssignment::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< ComponentAssignment> ComponentAssignment::Derived() { return ::Udm::DerivedAttr< ComponentAssignment>(impl); }
	::Udm::ArchetypeAttr< ComponentAssignment> ComponentAssignment::Archetype() const { return ::Udm::ArchetypeAttr< ComponentAssignment>(impl); }
	::Udm::ParentAttr< ::ESMoL::System> ComponentAssignment::System_parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, meta_System_parent); }
	::Udm::ParentAttr< ::ESMoL::System> ComponentAssignment::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }
	::Udm::AssocEndAttr< ::ESMoL::ComponentRef> ComponentAssignment::srcComponentAssignment_end() const { return ::Udm::AssocEndAttr< ::ESMoL::ComponentRef>(impl, meta_srcComponentAssignment_end_); }
	::Udm::AssocEndAttr< ::ESMoL::NodeRef> ComponentAssignment::dstComponentAssignment_end() const { return ::Udm::AssocEndAttr< ::ESMoL::NodeRef>(impl, meta_dstComponentAssignment_end_); }

	::Uml::Class ComponentAssignment::meta;
	::Uml::CompositionParentRole ComponentAssignment::meta_System_parent;
	::Uml::AssociationRole ComponentAssignment::meta_srcComponentAssignment_end_;
	::Uml::AssociationRole ComponentAssignment::meta_dstComponentAssignment_end_;

	PlantComponentRef::PlantComponentRef() {}
	PlantComponentRef::PlantComponentRef(::Udm::ObjectImpl *impl) : ComponentRef(impl), MgaObject(impl), UDM_OBJECT(impl) {}
	PlantComponentRef::PlantComponentRef(const PlantComponentRef &master) : ComponentRef(master), MgaObject(master), UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	PlantComponentRef::PlantComponentRef(PlantComponentRef &&master) : ComponentRef(master), MgaObject(master), UDM_OBJECT(master) {};

	PlantComponentRef PlantComponentRef::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	PlantComponentRef& PlantComponentRef::operator=(PlantComponentRef &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	PlantComponentRef PlantComponentRef::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	PlantComponentRef PlantComponentRef::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	PlantComponentRef PlantComponentRef::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< PlantComponentRef> PlantComponentRef::Instances() { return ::Udm::InstantiatedAttr< PlantComponentRef>(impl); }
	PlantComponentRef PlantComponentRef::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< PlantComponentRef> PlantComponentRef::Derived() { return ::Udm::DerivedAttr< PlantComponentRef>(impl); }
	::Udm::ArchetypeAttr< PlantComponentRef> PlantComponentRef::Archetype() const { return ::Udm::ArchetypeAttr< PlantComponentRef>(impl); }
	::Udm::ParentAttr< ::ESMoL::System> PlantComponentRef::parent() const { return ::Udm::ParentAttr< ::ESMoL::System>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class PlantComponentRef::meta;

	RootFolder::RootFolder() {}
	RootFolder::RootFolder(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	RootFolder::RootFolder(const RootFolder &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	RootFolder::RootFolder(RootFolder &&master) : UDM_OBJECT(master) {};

	RootFolder RootFolder::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	RootFolder& RootFolder::operator=(RootFolder &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	RootFolder RootFolder::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	RootFolder RootFolder::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	RootFolder RootFolder::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< RootFolder> RootFolder::Instances() { return ::Udm::InstantiatedAttr< RootFolder>(impl); }
	RootFolder RootFolder::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< RootFolder> RootFolder::Derived() { return ::Udm::DerivedAttr< RootFolder>(impl); }
	::Udm::ArchetypeAttr< RootFolder> RootFolder::Archetype() const { return ::Udm::ArchetypeAttr< RootFolder>(impl); }
	::Udm::StringAttr RootFolder::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary> RootFolder::ArchitectureLibrary_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary>(impl, meta_ArchitectureLibrary_children); }
	::Udm::ChildrenAttr< ::ESMoL::DesignFolder> RootFolder::DesignFolder_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DesignFolder>(impl, meta_DesignFolder_children); }
	::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary> RootFolder::RequirementsLibrary_children() const { return ::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary>(impl, meta_RequirementsLibrary_children); }
	::Udm::ChildrenAttr< ::ESMoL::Types> RootFolder::Types_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Types>(impl, meta_Types_children); }
	::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary> RootFolder::PlatformLibrary_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary>(impl, meta_PlatformLibrary_children); }
	::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary> RootFolder::DeploymentLibrary_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary>(impl, meta_DeploymentLibrary_children); }
	::Udm::ChildrenAttr< ::ESMoL::RootFolder> RootFolder::RootFolder_children() const { return ::Udm::ChildrenAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_children); }
	::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary> RootFolder::ArchitectureLibrary_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::ArchitectureLibrary>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::DesignFolder> RootFolder::DesignFolder_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DesignFolder>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary> RootFolder::RequirementsLibrary_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::RequirementsLibrary>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::Types> RootFolder::Types_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::Types>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary> RootFolder::PlatformLibrary_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::PlatformLibrary>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary> RootFolder::DeploymentLibrary_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::DeploymentLibrary>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ChildrenAttr< ::ESMoL::RootFolder> RootFolder::RootFolder_kind_children() const { return ::Udm::ChildrenAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLCHILDROLE); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder::RootFolder_parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, meta_RootFolder_parent); }
	::Udm::ParentAttr< ::ESMoL::RootFolder> RootFolder::parent() const { return ::Udm::ParentAttr< ::ESMoL::RootFolder>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class RootFolder::meta;
	::Uml::Attribute RootFolder::meta_name;
	::Uml::CompositionChildRole RootFolder::meta_ArchitectureLibrary_children;
	::Uml::CompositionChildRole RootFolder::meta_DesignFolder_children;
	::Uml::CompositionChildRole RootFolder::meta_RequirementsLibrary_children;
	::Uml::CompositionChildRole RootFolder::meta_Types_children;
	::Uml::CompositionChildRole RootFolder::meta_PlatformLibrary_children;
	::Uml::CompositionChildRole RootFolder::meta_DeploymentLibrary_children;
	::Uml::CompositionChildRole RootFolder::meta_RootFolder_children;
	::Uml::CompositionParentRole RootFolder::meta_RootFolder_parent;

	MgaObject::MgaObject() {}
	MgaObject::MgaObject(::Udm::ObjectImpl *impl) : UDM_OBJECT(impl) {}
	MgaObject::MgaObject(const MgaObject &master) : UDM_OBJECT(master) {}

#ifdef UDM_RVALUE
	MgaObject::MgaObject(MgaObject &&master) : UDM_OBJECT(master) {};

	MgaObject MgaObject::Cast(::Udm::Object &&a) { return __Cast(std::move(a), meta); };
	MgaObject& MgaObject::operator=(MgaObject &&a) { ::Udm::Object::operator =(std::move(a)); return *this; };

#endif
	MgaObject MgaObject::Cast(const ::Udm::Object &a) { return __Cast(a, meta); }
	MgaObject MgaObject::Create(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role); }
	MgaObject MgaObject::CreateInstance(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl); }
	::Udm::InstantiatedAttr< MgaObject> MgaObject::Instances() { return ::Udm::InstantiatedAttr< MgaObject>(impl); }
	MgaObject MgaObject::CreateDerived(const ::Udm::Object &parent, const ::Uml::CompositionChildRole &role) { return __Create(meta, parent, role, impl, true); }
	::Udm::DerivedAttr< MgaObject> MgaObject::Derived() { return ::Udm::DerivedAttr< MgaObject>(impl); }
	::Udm::ArchetypeAttr< MgaObject> MgaObject::Archetype() const { return ::Udm::ArchetypeAttr< MgaObject>(impl); }
	::Udm::StringAttr MgaObject::name() const { return ::Udm::StringAttr(impl, meta_name); }
	::Udm::StringAttr MgaObject::position() const { return ::Udm::StringAttr(impl, meta_position); }
	::Udm::ParentAttr< ::Udm::Object> MgaObject::parent() const { return ::Udm::ParentAttr< ::Udm::Object>(impl, ::Udm::NULLPARENTROLE); }

	::Uml::Class MgaObject::meta;
	::Uml::Attribute MgaObject::meta_name;
	::Uml::Attribute MgaObject::meta_position;

	::Uml::Diagram meta;

	void CreateMeta() {
		// classes, with attributes, constraints and constraint definitions
		AcquisitionConnection::meta = ::Uml::Class::Create(meta);

		Action::meta = ::Uml::Class::Create(meta);

		ActionPort::meta = ::Uml::Class::Create(meta);

		ActuationConnection::meta = ::Uml::Class::Create(meta);

		Additive::meta = ::Uml::Class::Create(meta);

		Annotation::meta = ::Uml::Class::Create(meta);
		Annotation::meta_Text = ::Uml::Attribute::Create(Annotation::meta);

		AperiodicExecInfo::meta = ::Uml::Class::Create(meta);

		ArchitectureLibrary::meta = ::Uml::Class::Create(meta);
		ArchitectureLibrary::meta_name = ::Uml::Attribute::Create(ArchitectureLibrary::meta);

		AsyncPeriodicExecInfo::meta = ::Uml::Class::Create(meta);
		AsyncPeriodicExecInfo::meta_TerminationTime = ::Uml::Attribute::Create(AsyncPeriodicExecInfo::meta);

		AutoCANMessage::meta = ::Uml::Class::Create(meta);
		AutoCANMessage::meta_PGN = ::Uml::Attribute::Create(AutoCANMessage::meta);

		AutoCANParam::meta = ::Uml::Class::Create(meta);
		AutoCANParam::meta_SPN = ::Uml::Attribute::Create(AutoCANParam::meta);

		BChan::meta = ::Uml::Class::Create(meta);

		BIPConnector::meta = ::Uml::Class::Create(meta);

		BitField::meta = ::Uml::Class::Create(meta);

		Block::meta = ::Uml::Class::Create(meta);
		Block::meta_BlockType = ::Uml::Attribute::Create(Block::meta);
		Block::meta_Tag = ::Uml::Attribute::Create(Block::meta);
		Block::meta_Name = ::Uml::Attribute::Create(Block::meta);
		Block::meta_Description = ::Uml::Attribute::Create(Block::meta);
		Block::meta_Priority = ::Uml::Attribute::Create(Block::meta);
		Block::meta_SampleTime = ::Uml::Attribute::Create(Block::meta);
		Block::meta_UserData = ::Uml::Attribute::Create(Block::meta);
		Block::meta_UniqueConnectorNames = ::Uml::Constraint::Create(Block::meta);

		Bus::meta = ::Uml::Class::Create(meta);
		Bus::meta_DataRate = ::Uml::Attribute::Create(Bus::meta);
		Bus::meta_DeprecatedOH = ::Uml::Attribute::Create(Bus::meta);
		Bus::meta_MinFrameSize = ::Uml::Attribute::Create(Bus::meta);
		Bus::meta_SwitchMemorySize = ::Uml::Attribute::Create(Bus::meta);
		Bus::meta_ID = ::Uml::Attribute::Create(Bus::meta);
		Bus::meta_SetupTime = ::Uml::Attribute::Create(Bus::meta);

		CANBus::meta = ::Uml::Class::Create(meta);
		CANBus::meta_Hyperperiod = ::Uml::Attribute::Create(CANBus::meta);

		CANMessage::meta = ::Uml::Class::Create(meta);
		CANMessage::meta_Priority = ::Uml::Attribute::Create(CANMessage::meta);
		CANMessage::meta_Period = ::Uml::Attribute::Create(CANMessage::meta);

		CCode::meta = ::Uml::Class::Create(meta);
		CCode::meta_CodeInfo = ::Uml::Attribute::Create(CCode::meta);

		CInputPort::meta = ::Uml::Class::Create(meta);
		CInputPort::meta_CPortType = ::Uml::Attribute::Create(CInputPort::meta);

		COutputPort::meta = ::Uml::Class::Create(meta);
		COutputPort::meta_CPortType = ::Uml::Attribute::Create(COutputPort::meta);

		Channel::meta = ::Uml::Class::Create(meta);
		Channel::meta_Configuration = ::Uml::Attribute::Create(Channel::meta);
		Channel::meta_ChanNum = ::Uml::Attribute::Create(Channel::meta);

		Choice::meta = ::Uml::Class::Create(meta);

		CommMapping::meta = ::Uml::Class::Create(meta);

		CommMapping_Members_Base::meta = ::Uml::Class::Create(meta);

		CommMapping_dstCommMapping_RPContainer_Base::meta = ::Uml::Class::Create(meta);

		CommMapping_srcCommMapping_RPContainer_Base::meta = ::Uml::Class::Create(meta);

		CompBreakout::meta = ::Uml::Class::Create(meta);

		Component::meta = ::Uml::Class::Create(meta);
		Component::meta_HeaderFiles = ::Uml::Attribute::Create(Component::meta);
		Component::meta_SourceFiles = ::Uml::Attribute::Create(Component::meta);

		ComponentAssignment::meta = ::Uml::Class::Create(meta);

		ComponentBase::meta = ::Uml::Class::Create(meta);
		ComponentBase::meta_Period = ::Uml::Attribute::Create(ComponentBase::meta);
		ComponentBase::meta_Deadline = ::Uml::Attribute::Create(ComponentBase::meta);

		ComponentRef::meta = ::Uml::Class::Create(meta);

		ComponentRef_RefersTo_Base::meta = ::Uml::Class::Create(meta);

		ConditionEvent::meta = ::Uml::Class::Create(meta);

		Conditional::meta = ::Uml::Class::Create(meta);

		Connectable::meta = ::Uml::Class::Create(meta);

		Connector::meta = ::Uml::Class::Create(meta);
		Connector::meta_ConnectionType = ::Uml::Attribute::Create(Connector::meta);

		ConnectorRef::meta = ::Uml::Class::Create(meta);

		Connector_dstConnector_RPContainer_Base::meta = ::Uml::Class::Create(meta);

		Connector_srcConnector_RPContainer_Base::meta = ::Uml::Class::Create(meta);

		Constant::meta = ::Uml::Class::Create(meta);
		Constant::meta_Value = ::Uml::Attribute::Create(Constant::meta);

		Continuous::meta = ::Uml::Class::Create(meta);

		Data::meta = ::Uml::Class::Create(meta);
		Data::meta_Description = ::Uml::Attribute::Create(Data::meta);
		Data::meta_Name = ::Uml::Attribute::Create(Data::meta);
		Data::meta_DataType = ::Uml::Attribute::Create(Data::meta);
		Data::meta_Port = ::Uml::Attribute::Create(Data::meta);
		Data::meta_Units = ::Uml::Attribute::Create(Data::meta);
		Data::meta_InitialValue = ::Uml::Attribute::Create(Data::meta);
		Data::meta_Min = ::Uml::Attribute::Create(Data::meta);
		Data::meta_Max = ::Uml::Attribute::Create(Data::meta);
		Data::meta_ArraySize = ::Uml::Attribute::Create(Data::meta);
		Data::meta_ArrayFirstIndex = ::Uml::Attribute::Create(Data::meta);
		Data::meta_Scope = ::Uml::Attribute::Create(Data::meta);

		Dataflow::meta = ::Uml::Class::Create(meta);
		Dataflow::meta_name = ::Uml::Attribute::Create(Dataflow::meta);

		DeepHistory::meta = ::Uml::Class::Create(meta);

		Dependency::meta = ::Uml::Class::Create(meta);

		DeploymentLibrary::meta = ::Uml::Class::Create(meta);
		DeploymentLibrary::meta_name = ::Uml::Attribute::Create(DeploymentLibrary::meta);

		DesignFolder::meta = ::Uml::Class::Create(meta);
		DesignFolder::meta_name = ::Uml::Attribute::Create(DesignFolder::meta);

		DesignReference::meta = ::Uml::Class::Create(meta);

		DetectionAction::meta = ::Uml::Class::Create(meta);

		DetectionCondition::meta = ::Uml::Class::Create(meta);

		EnablePort::meta = ::Uml::Class::Create(meta);
		EnablePort::meta_StatesWhenEnabling = ::Uml::Attribute::Create(EnablePort::meta);
		EnablePort::meta_EPtoNestedIPTPEPBPOnly = ::Uml::Constraint::Create(EnablePort::meta);
		EnablePort::meta_EPConnectedByPortInParentParent = ::Uml::Constraint::Create(EnablePort::meta);
		EnablePort::meta_OnlyOneEP = ::Uml::Constraint::Create(EnablePort::meta);
		EnablePort::meta_EPParentIsSubsystemOrSystem = ::Uml::Constraint::Create(EnablePort::meta);
		EnablePort::meta_EPInSubsystemOnlyConnectToEPInSystem = ::Uml::Constraint::Create(EnablePort::meta);
		EnablePort::meta_EPConnectedAsDstAtLeastOnce = ::Uml::Constraint::Create(EnablePort::meta);
		EnablePort::meta_EnableParentInSubsystemMustConnectDownToSystem = ::Uml::Constraint::Create(EnablePort::meta);

		Entry::meta = ::Uml::Class::Create(meta);

		Event::meta = ::Uml::Class::Create(meta);
		Event::meta_Description = ::Uml::Attribute::Create(Event::meta);
		Event::meta_Name = ::Uml::Attribute::Create(Event::meta);
		Event::meta_Scope = ::Uml::Attribute::Create(Event::meta);
		Event::meta_Trigger = ::Uml::Attribute::Create(Event::meta);
		Event::meta_Port = ::Uml::Attribute::Create(Event::meta);

		Executable::meta = ::Uml::Class::Create(meta);

		ExecutionAssignment::meta = ::Uml::Class::Create(meta);

		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta = ::Uml::Class::Create(meta);

		ExecutionContext::meta = ::Uml::Class::Create(meta);

		ExecutionInfo::meta = ::Uml::Class::Create(meta);
		ExecutionInfo::meta_WCDuration = ::Uml::Attribute::Create(ExecutionInfo::meta);
		ExecutionInfo::meta_RelDeadline = ::Uml::Attribute::Create(ExecutionInfo::meta);

		Exit::meta = ::Uml::Class::Create(meta);

		Exponential::meta = ::Uml::Class::Create(meta);
		Exponential::meta_Rate = ::Uml::Attribute::Create(Exponential::meta);

		FaultCondition::meta = ::Uml::Class::Create(meta);
		FaultCondition::meta_Expression = ::Uml::Attribute::Create(FaultCondition::meta);

		FaultEvent::meta = ::Uml::Class::Create(meta);

		FaultMgrTask::meta = ::Uml::Class::Create(meta);

		FaultModel::meta = ::Uml::Class::Create(meta);

		FaultModelFolder::meta = ::Uml::Class::Create(meta);
		FaultModelFolder::meta_name = ::Uml::Attribute::Create(FaultModelFolder::meta);

		FaultModelRef::meta = ::Uml::Class::Create(meta);

		FaultScenario::meta = ::Uml::Class::Create(meta);

		FaultToInput::meta = ::Uml::Class::Create(meta);
		FaultToInput::meta_VectorIndex = ::Uml::Attribute::Create(FaultToInput::meta);

		FaultToInput_Members_Base::meta = ::Uml::Class::Create(meta);

		FaultTrigger::meta = ::Uml::Class::Create(meta);

		FieldDataType::meta = ::Uml::Class::Create(meta);
		FieldDataType::meta_NumBits = ::Uml::Attribute::Create(FieldDataType::meta);
		FieldDataType::meta_InitialValue = ::Uml::Attribute::Create(FieldDataType::meta);

		Fork::meta = ::Uml::Class::Create(meta);

		Functions::meta = ::Uml::Class::Create(meta);

		HWElement::meta = ::Uml::Class::Create(meta);
		HWElement::meta_Configuration = ::Uml::Attribute::Create(HWElement::meta);

		HardwareUnit::meta = ::Uml::Class::Create(meta);

		HasRefId::meta = ::Uml::Class::Create(meta);
		HasRefId::meta_RefId = ::Uml::Attribute::Create(HasRefId::meta);

		History::meta = ::Uml::Class::Create(meta);

		IChan::meta = ::Uml::Class::Create(meta);

		IODevice::meta = ::Uml::Class::Create(meta);
		IODevice::meta_DeviceType = ::Uml::Attribute::Create(IODevice::meta);

		IOPortAssignment::meta = ::Uml::Class::Create(meta);

		IOPortExp::meta = ::Uml::Class::Create(meta);

		IOPortInfo::meta = ::Uml::Class::Create(meta);
		IOPortInfo::meta_DataSize = ::Uml::Attribute::Create(IOPortInfo::meta);
		IOPortInfo::meta_DataInit = ::Uml::Attribute::Create(IOPortInfo::meta);
		IOPortInfo::meta_DataMin = ::Uml::Attribute::Create(IOPortInfo::meta);
		IOPortInfo::meta_DataMax = ::Uml::Attribute::Create(IOPortInfo::meta);
		IOPortInfo::meta_Scale = ::Uml::Attribute::Create(IOPortInfo::meta);
		IOPortInfo::meta_Offset = ::Uml::Attribute::Create(IOPortInfo::meta);

		IOPortInfoBase::meta = ::Uml::Class::Create(meta);

		IOPortInfoRef::meta = ::Uml::Class::Create(meta);

		InPort::meta = ::Uml::Class::Create(meta);

		Incorporation::meta = ::Uml::Class::Create(meta);

		Input::meta = ::Uml::Class::Create(meta);

		InputEvent::meta = ::Uml::Class::Create(meta);

		InputPort::meta = ::Uml::Class::Create(meta);
		InputPort::meta_Number = ::Uml::Attribute::Create(InputPort::meta);
		InputPort::meta_IPtoNestedIPTPEPBPOnly = ::Uml::Constraint::Create(InputPort::meta);
		InputPort::meta_IPInSubsystemOnlyConnectToIPInSystem = ::Uml::Constraint::Create(InputPort::meta);
		InputPort::meta_IPConnectedAsDstAtLeastOnce = ::Uml::Constraint::Create(InputPort::meta);

		Intermittent::meta = ::Uml::Class::Create(meta);

		Interval::meta = ::Uml::Class::Create(meta);
		Interval::meta_Range = ::Uml::Attribute::Create(Interval::meta);

		Join::meta = ::Uml::Class::Create(meta);

		Junction::meta = ::Uml::Class::Create(meta);
		Junction::meta_JunctNotToSelf = ::Uml::Constraint::Create(Junction::meta);

		Line::meta = ::Uml::Class::Create(meta);
		Line::meta_Name = ::Uml::Attribute::Create(Line::meta);

		Link::meta = ::Uml::Class::Create(meta);

		Matrix::meta = ::Uml::Class::Create(meta);
		Matrix::meta_Type = ::Uml::Attribute::Create(Matrix::meta);
		Matrix::meta_rows = ::Uml::Attribute::Create(Matrix::meta);
		Matrix::meta_columns = ::Uml::Attribute::Create(Matrix::meta);

		Message::meta = ::Uml::Class::Create(meta);
		Message::meta_MsgSize = ::Uml::Attribute::Create(Message::meta);
		Message::meta_MsgMetaData = ::Uml::Attribute::Create(Message::meta);

		MessageRef::meta = ::Uml::Class::Create(meta);

		MessageRef_RefersTo_Base::meta = ::Uml::Class::Create(meta);

		MgaObject::meta = ::Uml::Class::Create(meta);
		MgaObject::meta_name = ::Uml::Attribute::Create(MgaObject::meta);
		MgaObject::meta_position = ::Uml::Attribute::Create(MgaObject::meta);

		MitigationAction::meta = ::Uml::Class::Create(meta);

		MitigationCondition::meta = ::Uml::Class::Create(meta);

		ModelInfo::meta = ::Uml::Class::Create(meta);
		ModelInfo::meta_ModelPath = ::Uml::Attribute::Create(ModelInfo::meta);
		ModelInfo::meta_DateTimeStamp = ::Uml::Attribute::Create(ModelInfo::meta);

		ModelsFolder::meta = ::Uml::Class::Create(meta);
		ModelsFolder::meta_name = ::Uml::Attribute::Create(ModelsFolder::meta);

		Module::meta = ::Uml::Class::Create(meta);

		MsgPort::meta = ::Uml::Class::Create(meta);
		MsgPort::meta_MsgPortNum = ::Uml::Attribute::Create(MsgPort::meta);
		MsgPort::meta_FieldMetaData = ::Uml::Attribute::Create(MsgPort::meta);

		Multiplicative::meta = ::Uml::Class::Create(meta);

		Network::meta = ::Uml::Class::Create(meta);
		Network::meta_DataRate = ::Uml::Attribute::Create(Network::meta);

		Node::meta = ::Uml::Class::Create(meta);
		Node::meta_Simulator = ::Uml::Attribute::Create(Node::meta);
		Node::meta_ROM = ::Uml::Attribute::Create(Node::meta);
		Node::meta_RAM = ::Uml::Attribute::Create(Node::meta);
		Node::meta_Speed = ::Uml::Attribute::Create(Node::meta);
		Node::meta_CPU = ::Uml::Attribute::Create(Node::meta);
		Node::meta_PlatformType = ::Uml::Attribute::Create(Node::meta);
		Node::meta_BusIDList = ::Uml::Attribute::Create(Node::meta);

		NodeRef::meta = ::Uml::Class::Create(meta);

		Normal::meta = ::Uml::Class::Create(meta);
		Normal::meta_Mean = ::Uml::Attribute::Create(Normal::meta);
		Normal::meta_StdDev = ::Uml::Attribute::Create(Normal::meta);

		OChan::meta = ::Uml::Class::Create(meta);

		OS::meta = ::Uml::Class::Create(meta);
		OS::meta_ContextSwitchTime = ::Uml::Attribute::Create(OS::meta);
		OS::meta_SendOverheadTime = ::Uml::Attribute::Create(OS::meta);
		OS::meta_RecvOverheadTime = ::Uml::Attribute::Create(OS::meta);
		OS::meta_TickResolution = ::Uml::Attribute::Create(OS::meta);
		OS::meta_MaxTaskNumber = ::Uml::Attribute::Create(OS::meta);
		OS::meta_SchedulingAlgorithm = ::Uml::Attribute::Create(OS::meta);
		OS::meta_ISROverheadTime = ::Uml::Attribute::Create(OS::meta);

		Occurrence::meta = ::Uml::Class::Create(meta);

		OldBus::meta = ::Uml::Class::Create(meta);
		OldBus::meta_Medium = ::Uml::Attribute::Create(OldBus::meta);
		OldBus::meta_FrameSize = ::Uml::Attribute::Create(OldBus::meta);
		OldBus::meta_OverheadTime = ::Uml::Attribute::Create(OldBus::meta);

		OldTask::meta = ::Uml::Class::Create(meta);
		OldTask::meta_Priority = ::Uml::Attribute::Create(OldTask::meta);
		OldTask::meta_TaskType = ::Uml::Attribute::Create(OldTask::meta);
		OldTask::meta_Activation = ::Uml::Attribute::Create(OldTask::meta);
		OldTask::meta_AutoStart = ::Uml::Attribute::Create(OldTask::meta);
		OldTask::meta_Preemption = ::Uml::Attribute::Create(OldTask::meta);
		OldTask::meta_Cyclic = ::Uml::Attribute::Create(OldTask::meta);
		OldTask::meta_CycleTime = ::Uml::Attribute::Create(OldTask::meta);

		OutPort::meta = ::Uml::Class::Create(meta);

		Output::meta = ::Uml::Class::Create(meta);

		OutputEvent::meta = ::Uml::Class::Create(meta);

		OutputPort::meta = ::Uml::Class::Create(meta);
		OutputPort::meta_Number = ::Uml::Attribute::Create(OutputPort::meta);
		OutputPort::meta_NestedOPtoOPorNestedOPtoIP = ::Uml::Constraint::Create(OutputPort::meta);

		OutputToFault::meta = ::Uml::Class::Create(meta);
		OutputToFault::meta_VectorIndex = ::Uml::Attribute::Create(OutputToFault::meta);

		OutputToFault_Members_Base::meta = ::Uml::Class::Create(meta);

		PNPort::meta = ::Uml::Class::Create(meta);
		PNPort::meta_visible = ::Uml::Attribute::Create(PNPort::meta);

		PNState::meta = ::Uml::Class::Create(meta);
		PNState::meta_initial = ::Uml::Attribute::Create(PNState::meta);

		PNTransition::meta = ::Uml::Class::Create(meta);
		PNTransition::meta_guard = ::Uml::Attribute::Create(PNTransition::meta);
		PNTransition::meta_action = ::Uml::Attribute::Create(PNTransition::meta);

		PNVarRef::meta = ::Uml::Class::Create(meta);

		PNVariable::meta = ::Uml::Class::Create(meta);
		PNVariable::meta_datatype = ::Uml::Attribute::Create(PNVariable::meta);

		Parameter::meta = ::Uml::Class::Create(meta);
		Parameter::meta_Value = ::Uml::Attribute::Create(Parameter::meta);

		Periodic::meta = ::Uml::Class::Create(meta);

		PeriodicExecInfo::meta = ::Uml::Class::Create(meta);
		PeriodicExecInfo::meta_ExecPeriod = ::Uml::Attribute::Create(PeriodicExecInfo::meta);
		PeriodicExecInfo::meta_DesiredOffset = ::Uml::Attribute::Create(PeriodicExecInfo::meta);

		PetriNet::meta = ::Uml::Class::Create(meta);
		PetriNet::meta_action = ::Uml::Attribute::Create(PetriNet::meta);

		PetriNetRef::meta = ::Uml::Class::Create(meta);

		PhysConnection::meta = ::Uml::Class::Create(meta);

		PhysInterface::meta = ::Uml::Class::Create(meta);

		Plant::meta = ::Uml::Class::Create(meta);

		PlantComponent::meta = ::Uml::Class::Create(meta);

		PlantComponentRef::meta = ::Uml::Class::Create(meta);

		PlatformLibrary::meta = ::Uml::Class::Create(meta);
		PlatformLibrary::meta_name = ::Uml::Attribute::Create(PlatformLibrary::meta);

		Port::meta = ::Uml::Class::Create(meta);

		Postcondition::meta = ::Uml::Class::Create(meta);

		Precondition::meta = ::Uml::Class::Create(meta);

		Primitive::meta = ::Uml::Class::Create(meta);

		Pulse::meta = ::Uml::Class::Create(meta);
		Pulse::meta_Shift = ::Uml::Attribute::Create(Pulse::meta);
		Pulse::meta_Duration = ::Uml::Attribute::Create(Pulse::meta);

		RandomDistribution::meta = ::Uml::Class::Create(meta);

		Reference::meta = ::Uml::Class::Create(meta);
		Reference::meta_SourceType = ::Uml::Attribute::Create(Reference::meta);
		Reference::meta_SourceBlock = ::Uml::Attribute::Create(Reference::meta);

		RequirementsLibrary::meta = ::Uml::Class::Create(meta);
		RequirementsLibrary::meta_name = ::Uml::Attribute::Create(RequirementsLibrary::meta);

		RootFolder::meta = ::Uml::Class::Create(meta);
		RootFolder::meta_name = ::Uml::Attribute::Create(RootFolder::meta);

		ScenarioInfo::meta = ::Uml::Class::Create(meta);
		ScenarioInfo::meta_Requirements = ::Uml::Attribute::Create(ScenarioInfo::meta);
		ScenarioInfo::meta_ScenarioDescription = ::Uml::Attribute::Create(ScenarioInfo::meta);
		ScenarioInfo::meta_Criticality = ::Uml::Attribute::Create(ScenarioInfo::meta);

		SerialLink::meta = ::Uml::Class::Create(meta);
		SerialLink::meta_DataBits = ::Uml::Attribute::Create(SerialLink::meta);
		SerialLink::meta_Parity = ::Uml::Attribute::Create(SerialLink::meta);
		SerialLink::meta_StopBits = ::Uml::Attribute::Create(SerialLink::meta);
		SerialLink::meta_FlowControl = ::Uml::Attribute::Create(SerialLink::meta);

		ShallowHistory::meta = ::Uml::Class::Create(meta);

		Sinusoid::meta = ::Uml::Class::Create(meta);
		Sinusoid::meta_Frequency = ::Uml::Attribute::Create(Sinusoid::meta);
		Sinusoid::meta_Phase = ::Uml::Attribute::Create(Sinusoid::meta);

		SporadicExecInfo::meta = ::Uml::Class::Create(meta);
		SporadicExecInfo::meta_MinimumPeriod = ::Uml::Attribute::Create(SporadicExecInfo::meta);

		State::meta = ::Uml::Class::Create(meta);
		State::meta_Decomposition = ::Uml::Attribute::Create(State::meta);
		State::meta_Name = ::Uml::Attribute::Create(State::meta);
		State::meta_EnterAction = ::Uml::Attribute::Create(State::meta);
		State::meta_DuringAction = ::Uml::Attribute::Create(State::meta);
		State::meta_ExitAction = ::Uml::Attribute::Create(State::meta);
		State::meta_Order = ::Uml::Attribute::Create(State::meta);
		State::meta_Description = ::Uml::Attribute::Create(State::meta);
		State::meta_Methods = ::Uml::Attribute::Create(State::meta);
		State::meta_SingleHistory = ::Uml::Constraint::Create(State::meta);

		StateDE::meta = ::Uml::Class::Create(meta);

		StatePort::meta = ::Uml::Class::Create(meta);

		StateToTransition::meta = ::Uml::Class::Create(meta);

		Stateflow::meta = ::Uml::Class::Create(meta);
		Stateflow::meta_name = ::Uml::Attribute::Create(Stateflow::meta);

		Step::meta = ::Uml::Class::Create(meta);
		Step::meta_Shift = ::Uml::Attribute::Create(Step::meta);

		Substitutive::meta = ::Uml::Class::Create(meta);

		Subsystem::meta = ::Uml::Class::Create(meta);
		Subsystem::meta_UniqueConnectorNames1 = ::Uml::Constraint::Create(Subsystem::meta);

		SubsystemRef::meta = ::Uml::Class::Create(meta);

		System::meta = ::Uml::Class::Create(meta);

		SystemTypes::meta = ::Uml::Class::Create(meta);

		TTBus::meta = ::Uml::Class::Create(meta);
		TTBus::meta_Hyperperiod = ::Uml::Attribute::Create(TTBus::meta);
		TTBus::meta_TTSetupTime = ::Uml::Attribute::Create(TTBus::meta);
		TTBus::meta_SlotSize = ::Uml::Attribute::Create(TTBus::meta);

		TTExecContext::meta = ::Uml::Class::Create(meta);
		TTExecContext::meta_Hyperperiod = ::Uml::Attribute::Create(TTExecContext::meta);

		TTExecInfo::meta = ::Uml::Class::Create(meta);
		TTExecInfo::meta_TTSchedule = ::Uml::Attribute::Create(TTExecInfo::meta);

		TaskInst::meta = ::Uml::Class::Create(meta);

		TaskRef::meta = ::Uml::Class::Create(meta);

		Terminate::meta = ::Uml::Class::Create(meta);

		TimingConstraint::meta = ::Uml::Class::Create(meta);
		TimingConstraint::meta_Latency = ::Uml::Attribute::Create(TimingConstraint::meta);

		TimingSheet::meta = ::Uml::Class::Create(meta);

		TransConnector::meta = ::Uml::Class::Create(meta);

		TransStart::meta = ::Uml::Class::Create(meta);
		TransStart::meta_TransStartRestrict = ::Uml::Constraint::Create(TransStart::meta);

		Transition::meta = ::Uml::Class::Create(meta);
		Transition::meta_Trigger = ::Uml::Attribute::Create(Transition::meta);
		Transition::meta_Guard = ::Uml::Attribute::Create(Transition::meta);
		Transition::meta_Action = ::Uml::Attribute::Create(Transition::meta);
		Transition::meta_ConditionAction = ::Uml::Attribute::Create(Transition::meta);
		Transition::meta_Order = ::Uml::Attribute::Create(Transition::meta);

		TransitionToState::meta = ::Uml::Class::Create(meta);

		Trigger::meta = ::Uml::Class::Create(meta);

		TriggerPort::meta = ::Uml::Class::Create(meta);
		TriggerPort::meta_TriggerType = ::Uml::Attribute::Create(TriggerPort::meta);
		TriggerPort::meta_OnlyOneTP = ::Uml::Constraint::Create(TriggerPort::meta);
		TriggerPort::meta_TPConnectedAsDstAtLeastOnce = ::Uml::Constraint::Create(TriggerPort::meta);
		TriggerPort::meta_TPtoNestedIPTPEPBPOnly = ::Uml::Constraint::Create(TriggerPort::meta);
		TriggerPort::meta_TPConnectedByPortInParentParent = ::Uml::Constraint::Create(TriggerPort::meta);
		TriggerPort::meta_TPInSubsystemOnlyConnectToTPInSystem = ::Uml::Constraint::Create(TriggerPort::meta);
		TriggerPort::meta_TPParentIsSubsystemOrSystem = ::Uml::Constraint::Create(TriggerPort::meta);
		TriggerPort::meta_TriggerParentInSubsystemMustConnectDownToSystem = ::Uml::Constraint::Create(TriggerPort::meta);

		TypeBase::meta = ::Uml::Class::Create(meta);

		TypeBaseRef::meta = ::Uml::Class::Create(meta);
		TypeBaseRef::meta_MemberIndex = ::Uml::Attribute::Create(TypeBaseRef::meta);

		TypeStruct::meta = ::Uml::Class::Create(meta);
		TypeStruct::meta_MemberCount = ::Uml::Attribute::Create(TypeStruct::meta);

		Types::meta = ::Uml::Class::Create(meta);
		Types::meta_name = ::Uml::Attribute::Create(Types::meta);

		Uniform::meta = ::Uml::Class::Create(meta);
		Uniform::meta_LowerBound = ::Uml::Attribute::Create(Uniform::meta);
		Uniform::meta_UpperBound = ::Uml::Attribute::Create(Uniform::meta);

		ValueObject::meta = ::Uml::Class::Create(meta);

		ValueType::meta = ::Uml::Class::Create(meta);
		ValueType::meta_Scale = ::Uml::Attribute::Create(ValueType::meta);
		ValueType::meta_Signed = ::Uml::Attribute::Create(ValueType::meta);
		ValueType::meta_DataType = ::Uml::Attribute::Create(ValueType::meta);
		ValueType::meta_MinValue = ::Uml::Attribute::Create(ValueType::meta);
		ValueType::meta_MaxValue = ::Uml::Attribute::Create(ValueType::meta);
		ValueType::meta_Units = ::Uml::Attribute::Create(ValueType::meta);
		ValueType::meta_Offset = ::Uml::Attribute::Create(ValueType::meta);

		Variable::meta = ::Uml::Class::Create(meta);

		Wire::meta = ::Uml::Class::Create(meta);

	}

	void InitMeta() {
		// classes, with attributes, constraints and constraint definitions
		::Uml::InitClassProps(AcquisitionConnection::meta, "AcquisitionConnection", false, "Connection", NULL);

		::Uml::InitClassProps(Action::meta, "Action", true, "Reference", NULL);

		::Uml::InitClassProps(ActionPort::meta, "ActionPort", false, "Model", NULL);

		::Uml::InitClassProps(ActuationConnection::meta, "ActuationConnection", false, "Connection", NULL);

		::Uml::InitClassProps(Additive::meta, "Additive", false, "Model", NULL);

		::Uml::InitClassProps(Annotation::meta, "Annotation", false, "Atom", NULL);
		::Uml::InitAttributeProps(Annotation::meta_Text, "Text", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(AperiodicExecInfo::meta, "AperiodicExecInfo", true, "Model", NULL);

		::Uml::InitClassProps(ArchitectureLibrary::meta, "ArchitectureLibrary", false, "Folder", NULL);
		::Uml::InitAttributeProps(ArchitectureLibrary::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(AsyncPeriodicExecInfo::meta, "AsyncPeriodicExecInfo", false, "Model", NULL);
		::Uml::InitAttributeProps(AsyncPeriodicExecInfo::meta_TerminationTime, "TerminationTime", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(AutoCANMessage::meta, "AutoCANMessage", false, "Model", NULL);
		::Uml::InitAttributeProps(AutoCANMessage::meta_PGN, "PGN", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(AutoCANParam::meta, "AutoCANParam", false, "Model", NULL);
		::Uml::InitAttributeProps(AutoCANParam::meta_SPN, "SPN", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(BChan::meta, "BChan", false, "Atom", NULL);

		::Uml::InitClassProps(BIPConnector::meta, "BIPConnector", false, "Connection", NULL);

		::Uml::InitClassProps(BitField::meta, "BitField", false, "Model", NULL);

		::Uml::InitClassProps(Block::meta, "Block", true, "Model", NULL);
		::Uml::InitAttributeProps(Block::meta_BlockType, "BlockType", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Block::meta_Tag, "Tag", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Block::meta_Name, "Name", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Block::meta_Description, "Description", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Block::meta_Priority, "Priority", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Block::meta_SampleTime, "SampleTime", "Real", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Block::meta_UserData, "UserData", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitConstraintProps(Block::meta_UniqueConnectorNames, "UniqueConnectorNames", "This Block's Port objects must be uniquely named.", "let ports = self.modelParts( InputPort ) + self.modelParts( OutputPort ) + self.modelParts( TriggerPort ) + self.modelParts( EnablePort ) in\nports->isUnique( p | p.name )\n");

		::Uml::InitClassProps(Bus::meta, "Bus", true, "Model", NULL);
		vector<string> Bus_DataRate_dva;
		Bus_DataRate_dva.push_back("1b");
		::Uml::InitAttributeProps(Bus::meta_DataRate, "DataRate", "String", false, false, 1, 1, false, "public", Bus_DataRate_dva);
		vector<string> Bus_DeprecatedOH_dva;
		Bus_DeprecatedOH_dva.push_back("0s");
		::Uml::InitAttributeProps(Bus::meta_DeprecatedOH, "DeprecatedOH", "String", false, false, 1, 1, false, "public", Bus_DeprecatedOH_dva);
		vector<string> Bus_MinFrameSize_dva;
		Bus_MinFrameSize_dva.push_back("512B");
		::Uml::InitAttributeProps(Bus::meta_MinFrameSize, "MinFrameSize", "String", false, false, 1, 1, false, "public", Bus_MinFrameSize_dva);
		vector<string> Bus_SwitchMemorySize_dva;
		Bus_SwitchMemorySize_dva.push_back("80MB");
		::Uml::InitAttributeProps(Bus::meta_SwitchMemorySize, "SwitchMemorySize", "String", false, false, 1, 1, false, "public", Bus_SwitchMemorySize_dva);
		::Uml::InitAttributeProps(Bus::meta_ID, "ID", "Integer", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Bus_SetupTime_dva;
		Bus_SetupTime_dva.push_back("0s");
		::Uml::InitAttributeProps(Bus::meta_SetupTime, "SetupTime", "String", false, false, 1, 1, false, "public", Bus_SetupTime_dva);

		::Uml::InitClassProps(CANBus::meta, "CANBus", false, "Model", NULL);
		vector<string> CANBus_Hyperperiod_dva;
		CANBus_Hyperperiod_dva.push_back("0s");
		::Uml::InitAttributeProps(CANBus::meta_Hyperperiod, "Hyperperiod", "String", false, false, 1, 1, false, "public", CANBus_Hyperperiod_dva);

		::Uml::InitClassProps(CANMessage::meta, "CANMessage", false, "Model", NULL);
		::Uml::InitAttributeProps(CANMessage::meta_Priority, "Priority", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(CANMessage::meta_Period, "Period", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(CCode::meta, "CCode", false, "Model", NULL);
		::Uml::InitAttributeProps(CCode::meta_CodeInfo, "CodeInfo", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(CInputPort::meta, "CInputPort", false, "Model", NULL);
		::Uml::InitAttributeProps(CInputPort::meta_CPortType, "CPortType", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(COutputPort::meta, "COutputPort", false, "Model", NULL);
		::Uml::InitAttributeProps(COutputPort::meta_CPortType, "CPortType", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Channel::meta, "Channel", true, "Atom", NULL);
		::Uml::InitAttributeProps(Channel::meta_Configuration, "Configuration", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Channel_ChanNum_dva;
		Channel_ChanNum_dva.push_back("-1");
		::Uml::InitAttributeProps(Channel::meta_ChanNum, "ChanNum", "Integer", false, false, 1, 1, false, "public", Channel_ChanNum_dva);

		::Uml::InitClassProps(Choice::meta, "Choice", false, "Atom", NULL);

		::Uml::InitClassProps(CommMapping::meta, "CommMapping", false, "Connection", NULL);

		::Uml::InitClassProps(CommMapping_Members_Base::meta, "CommMapping_Members_Base", true, "FCO", NULL);

		::Uml::InitClassProps(CommMapping_dstCommMapping_RPContainer_Base::meta, "CommMapping_dstCommMapping_RPContainer_Base", true, "FCO", NULL);

		::Uml::InitClassProps(CommMapping_srcCommMapping_RPContainer_Base::meta, "CommMapping_srcCommMapping_RPContainer_Base", true, "FCO", NULL);

		::Uml::InitClassProps(CompBreakout::meta, "CompBreakout", false, "Connection", NULL);

		::Uml::InitClassProps(Component::meta, "Component", false, "Model", NULL);
		::Uml::InitAttributeProps(Component::meta_HeaderFiles, "HeaderFiles", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Component::meta_SourceFiles, "SourceFiles", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ComponentAssignment::meta, "ComponentAssignment", false, "Connection", NULL);

		::Uml::InitClassProps(ComponentBase::meta, "ComponentBase", true, "FCO", NULL);
		::Uml::InitAttributeProps(ComponentBase::meta_Period, "Period", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ComponentBase::meta_Deadline, "Deadline", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ComponentRef::meta, "ComponentRef", false, "Reference", NULL);

		::Uml::InitClassProps(ComponentRef_RefersTo_Base::meta, "ComponentRef_RefersTo_Base", true, "FCO", NULL);

		::Uml::InitClassProps(ConditionEvent::meta, "ConditionEvent", false, "Model", NULL);

		::Uml::InitClassProps(Conditional::meta, "Conditional", false, "Atom", NULL);

		::Uml::InitClassProps(Connectable::meta, "Connectable", true, "FCO", NULL);

		::Uml::InitClassProps(Connector::meta, "Connector", false, "Connection", NULL);
		::Uml::InitAttributeProps(Connector::meta_ConnectionType, "ConnectionType", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ConnectorRef::meta, "ConnectorRef", false, "Reference", NULL);

		::Uml::InitClassProps(Connector_dstConnector_RPContainer_Base::meta, "Connector_dstConnector_RPContainer_Base", true, "FCO", NULL);

		::Uml::InitClassProps(Connector_srcConnector_RPContainer_Base::meta, "Connector_srcConnector_RPContainer_Base", true, "FCO", NULL);

		::Uml::InitClassProps(Constant::meta, "Constant", false, "Model", NULL);
		::Uml::InitAttributeProps(Constant::meta_Value, "Value", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Continuous::meta, "Continuous", false, "Model", NULL);

		::Uml::InitClassProps(Data::meta, "Data", false, "Model", NULL);
		::Uml::InitAttributeProps(Data::meta_Description, "Description", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_Name, "Name", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_DataType, "DataType", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_Port, "Port", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_Units, "Units", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_InitialValue, "InitialValue", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_Min, "Min", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_Max, "Max", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_ArraySize, "ArraySize", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Data::meta_ArrayFirstIndex, "ArrayFirstIndex", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Data_Scope_dva;
		Data_Scope_dva.push_back("LOCAL_DATA");
		::Uml::InitAttributeProps(Data::meta_Scope, "Scope", "String", false, false, 1, 1, false, "public", Data_Scope_dva);

		::Uml::InitClassProps(Dataflow::meta, "Dataflow", false, "Folder", NULL);
		::Uml::InitAttributeProps(Dataflow::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(DeepHistory::meta, "DeepHistory", false, "Atom", NULL);

		::Uml::InitClassProps(Dependency::meta, "Dependency", false, "Connection", NULL);

		::Uml::InitClassProps(DeploymentLibrary::meta, "DeploymentLibrary", false, "Folder", NULL);
		::Uml::InitAttributeProps(DeploymentLibrary::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(DesignFolder::meta, "DesignFolder", false, "Folder", NULL);
		::Uml::InitAttributeProps(DesignFolder::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(DesignReference::meta, "DesignReference", false, "Reference", NULL);

		::Uml::InitClassProps(DetectionAction::meta, "DetectionAction", false, "Reference", NULL);

		::Uml::InitClassProps(DetectionCondition::meta, "DetectionCondition", false, "Model", NULL);

		::Uml::InitClassProps(EnablePort::meta, "EnablePort", false, "Model", NULL);
		vector<string> EnablePort_StatesWhenEnabling_dva;
		EnablePort_StatesWhenEnabling_dva.push_back("held");
		::Uml::InitAttributeProps(EnablePort::meta_StatesWhenEnabling, "StatesWhenEnabling", "String", false, false, 1, 1, false, "public", EnablePort_StatesWhenEnabling_dva);
		::Uml::InitConstraintProps(EnablePort::meta_EPtoNestedIPTPEPBPOnly, "EPtoNestedIPTPEPBPOnly", "This EnablePort may only connect to an InputPort/TriggerPort/EnablePort of a nested Subsystem, Reference or Primitive.", "let parent = self.parent() in\nself.reverseConnectedFCOs( \"src\" ) -> \n   forAll( p |\n      p.parent().parent() = parent and (  p.oclIsKindOf( InputPort ) or p.oclIsKindOf( TriggerPort ) or p.oclIsKindOf( EnablePort )  )\n   )");
		::Uml::InitConstraintProps(EnablePort::meta_EPConnectedByPortInParentParent, "EPConnectedByPortInParentParent", "This EnablePort may only be connected by a Connector in the parent's parent.", "let parent2 = self.parent().parent() in\nself.reverseConnectedFCOs( \"dst\" ) -> forAll(  p | p.parent() = parent2 or p.oclIsKindOf( OutputPort )  )");
		::Uml::InitConstraintProps(EnablePort::meta_OnlyOneEP, "OnlyOneEP", "There can only be, at most, one EnablePort created in here.", "self.parent().oclAsType( gme::Model ).modelParts( EnablePort ) -> size < 2");
		::Uml::InitConstraintProps(EnablePort::meta_EPParentIsSubsystemOrSystem, "EPParentIsSubsystemOrSystem", "This EnablePort can not be inside a Primitive.", "let p = self.parent() in\np.oclIsKindOf( System ) or p.oclIsKindOf( Reference )");
		::Uml::InitConstraintProps(EnablePort::meta_EPInSubsystemOnlyConnectToEPInSystem, "EPInSubsystemOnlyConnectToEPInSystem", "An EnablePort in a Subsystem can only connect to an EnablePort in the nested System.", "let parent = self.parent() in\nparent.oclIsKindOf( System )\nimplies\nself.reverseConnectedFCOs( \"src\" ) -> forAll( p | p.oclIsKindOf( EnablePort ) and p.parent().parent() = parent )\n");
		::Uml::InitConstraintProps(EnablePort::meta_EPConnectedAsDstAtLeastOnce, "EPConnectedAsDstAtLeastOnce", "This EnablePort must be connected as a destination object.", "self.reverseConnectedFCOs( \"dst\" )->size > 0\n");
		::Uml::InitConstraintProps(EnablePort::meta_EnableParentInSubsystemMustConnectDownToSystem, "EnableParentInSubsystemMustConnectDownToSystem", "This EnablePort must connect to an EnablePort inside a nested System.", "let parent : gme::Model = self.parent() in\nif ( parent.oclIsKindOf( System ) and parent.modelParts() -> size > 0 ) then\n   let srcs = self.reverseConnectedFCOs( \"src\" ) in\n   srcs->size = 1 and srcs->forAll(  p | p.oclIsKindOf( EnablePort )  )\nelse\n   true\nendif");

		::Uml::InitClassProps(Entry::meta, "Entry", false, "Atom", NULL);

		::Uml::InitClassProps(Event::meta, "Event", false, "Model", NULL);
		::Uml::InitAttributeProps(Event::meta_Description, "Description", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Event::meta_Name, "Name", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> Event_Scope_dva;
		Event_Scope_dva.push_back("LOCAL_EVENT");
		::Uml::InitAttributeProps(Event::meta_Scope, "Scope", "String", false, false, 1, 1, false, "public", Event_Scope_dva);
		vector<string> Event_Trigger_dva;
		Event_Trigger_dva.push_back("EITHER_EDGE_EVENT");
		::Uml::InitAttributeProps(Event::meta_Trigger, "Trigger", "String", false, false, 1, 1, false, "public", Event_Trigger_dva);
		::Uml::InitAttributeProps(Event::meta_Port, "Port", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Executable::meta, "Executable", true, "FCO", NULL);

		::Uml::InitClassProps(ExecutionAssignment::meta, "ExecutionAssignment", false, "Connection", NULL);

		::Uml::InitClassProps(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta, "ExecutionAssignment_dstExecutionAssignment_RPContainer_Base", true, "FCO", NULL);

		::Uml::InitClassProps(ExecutionContext::meta, "ExecutionContext", true, "Model", NULL);

		::Uml::InitClassProps(ExecutionInfo::meta, "ExecutionInfo", true, "Model", NULL);
		::Uml::InitAttributeProps(ExecutionInfo::meta_WCDuration, "WCDuration", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ExecutionInfo::meta_RelDeadline, "RelDeadline", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Exit::meta, "Exit", false, "Atom", NULL);

		::Uml::InitClassProps(Exponential::meta, "Exponential", false, "Model", NULL);
		::Uml::InitAttributeProps(Exponential::meta_Rate, "Rate", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(FaultCondition::meta, "FaultCondition", false, "Model", NULL);
		::Uml::InitAttributeProps(FaultCondition::meta_Expression, "Expression", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(FaultEvent::meta, "FaultEvent", false, "Model", NULL);

		::Uml::InitClassProps(FaultMgrTask::meta, "FaultMgrTask", false, "Reference", NULL);

		::Uml::InitClassProps(FaultModel::meta, "FaultModel", false, "Model", NULL);

		::Uml::InitClassProps(FaultModelFolder::meta, "FaultModelFolder", false, "Folder", NULL);
		::Uml::InitAttributeProps(FaultModelFolder::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(FaultModelRef::meta, "FaultModelRef", false, "Reference", NULL);

		::Uml::InitClassProps(FaultScenario::meta, "FaultScenario", false, "Model", NULL);

		::Uml::InitClassProps(FaultToInput::meta, "FaultToInput", false, "Connection", NULL);
		::Uml::InitAttributeProps(FaultToInput::meta_VectorIndex, "VectorIndex", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(FaultToInput_Members_Base::meta, "FaultToInput_Members_Base", true, "FCO", NULL);

		::Uml::InitClassProps(FaultTrigger::meta, "FaultTrigger", false, "Reference", NULL);

		::Uml::InitClassProps(FieldDataType::meta, "FieldDataType", true, "Model", NULL);
		::Uml::InitAttributeProps(FieldDataType::meta_NumBits, "NumBits", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(FieldDataType::meta_InitialValue, "InitialValue", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Fork::meta, "Fork", false, "Atom", NULL);

		::Uml::InitClassProps(Functions::meta, "Functions", true, "Model", NULL);

		::Uml::InitClassProps(HWElement::meta, "HWElement", true, "Model", NULL);
		::Uml::InitAttributeProps(HWElement::meta_Configuration, "Configuration", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(HardwareUnit::meta, "HardwareUnit", false, "Model", NULL);

		::Uml::InitClassProps(HasRefId::meta, "HasRefId", true, "FCO", NULL);
		::Uml::InitAttributeProps(HasRefId::meta_RefId, "RefId", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(History::meta, "History", false, "Atom", NULL);

		::Uml::InitClassProps(IChan::meta, "IChan", false, "Atom", NULL);

		::Uml::InitClassProps(IODevice::meta, "IODevice", false, "Model", NULL);
		::Uml::InitAttributeProps(IODevice::meta_DeviceType, "DeviceType", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(IOPortAssignment::meta, "IOPortAssignment", false, "Connection", NULL);

		::Uml::InitClassProps(IOPortExp::meta, "IOPortExp", true, "FCO", NULL);

		::Uml::InitClassProps(IOPortInfo::meta, "IOPortInfo", false, "Model", NULL);
		::Uml::InitAttributeProps(IOPortInfo::meta_DataSize, "DataSize", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(IOPortInfo::meta_DataInit, "DataInit", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(IOPortInfo::meta_DataMin, "DataMin", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(IOPortInfo::meta_DataMax, "DataMax", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(IOPortInfo::meta_Scale, "Scale", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(IOPortInfo::meta_Offset, "Offset", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(IOPortInfoBase::meta, "IOPortInfoBase", true, "FCO", NULL);

		::Uml::InitClassProps(IOPortInfoRef::meta, "IOPortInfoRef", false, "Reference", NULL);

		::Uml::InitClassProps(InPort::meta, "InPort", true, "Model", NULL);

		::Uml::InitClassProps(Incorporation::meta, "Incorporation", true, "Model", NULL);

		::Uml::InitClassProps(Input::meta, "Input", true, "FCO", NULL);

		::Uml::InitClassProps(InputEvent::meta, "InputEvent", true, "FCO", NULL);

		::Uml::InitClassProps(InputPort::meta, "InputPort", false, "Model", NULL);
		::Uml::InitAttributeProps(InputPort::meta_Number, "Number", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitConstraintProps(InputPort::meta_IPtoNestedIPTPEPBPOnly, "IPtoNestedIPTPEPBPOnly", "This InputPort may only connect to an InputPort/TriggerPort/EnablePort of a nested Subsystem, Reference or Primitive.  It may also connect  to an OutputPort in the same parent.", "let parent = self.parent() in\nself.reverseConnectedFCOs( \"src\" ) -> forAll( p|\n   let pParent = p.parent() in\n   pParent.parent() = parent and (  p.oclIsKindOf( InputPort ) or p.oclIsKindOf( TriggerPort ) or p.oclIsKindOf( EnablePort )  )\n   or\n   p.oclIsKindOf( OutputPort ) and pParent = parent and parent.oclIsKindOf( System )\n)");
		::Uml::InitConstraintProps(InputPort::meta_IPInSubsystemOnlyConnectToIPInSystem, "IPInSubsystemOnlyConnectToIPInSystem", "An InputPort in a Subsystem can only connect to an InputPort in the nested System.", "let parent  = self.parent() in\nparent.oclIsKindOf( System )\nimplies\nself.reverseConnectedFCOs( \"src\" ) -> forAll( p | p.oclIsKindOf( InputPort ) and p.parent().parent() = parent )\n");
		::Uml::InitConstraintProps(InputPort::meta_IPConnectedAsDstAtLeastOnce, "IPConnectedAsDstAtLeastOnce", "This InputPort must be connected as a destination object.", "self.reverseConnectedFCOs( \"dst\" ) -> size > 0\n");

		::Uml::InitClassProps(Intermittent::meta, "Intermittent", false, "Model", NULL);

		::Uml::InitClassProps(Interval::meta, "Interval", false, "Model", NULL);
		::Uml::InitAttributeProps(Interval::meta_Range, "Range", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Join::meta, "Join", false, "Atom", NULL);

		::Uml::InitClassProps(Junction::meta, "Junction", false, "Atom", NULL);
		::Uml::InitConstraintProps(Junction::meta_JunctNotToSelf, "JunctNotToSelf", "Junction may not connect to itself.", "self.connectedFCOs() -> forAll( c | c <> self )");

		::Uml::InitClassProps(Line::meta, "Line", false, "Connection", NULL);
		::Uml::InitAttributeProps(Line::meta_Name, "Name", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Link::meta, "Link", true, "Model", NULL);

		::Uml::InitClassProps(Matrix::meta, "Matrix", false, "Atom", NULL);
		::Uml::InitAttributeProps(Matrix::meta_Type, "Type", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Matrix::meta_rows, "rows", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Matrix::meta_columns, "columns", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Message::meta, "Message", false, "Model", NULL);
		vector<string> Message_MsgSize_dva;
		Message_MsgSize_dva.push_back("1B");
		::Uml::InitAttributeProps(Message::meta_MsgSize, "MsgSize", "String", false, false, 1, 1, false, "public", Message_MsgSize_dva);
		::Uml::InitAttributeProps(Message::meta_MsgMetaData, "MsgMetaData", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(MessageRef::meta, "MessageRef", false, "Reference", NULL);

		::Uml::InitClassProps(MessageRef_RefersTo_Base::meta, "MessageRef_RefersTo_Base", true, "FCO", NULL);

		::Uml::InitClassProps(MgaObject::meta, "MgaObject", true, NULL, NULL);
		::Uml::InitAttributeProps(MgaObject::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(MgaObject::meta_position, "position", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(MitigationAction::meta, "MitigationAction", false, "Reference", NULL);

		::Uml::InitClassProps(MitigationCondition::meta, "MitigationCondition", false, "Model", NULL);

		::Uml::InitClassProps(ModelInfo::meta, "ModelInfo", false, "Atom", NULL);
		::Uml::InitAttributeProps(ModelInfo::meta_ModelPath, "ModelPath", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ModelInfo::meta_DateTimeStamp, "DateTimeStamp", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ModelsFolder::meta, "ModelsFolder", false, "Folder", NULL);
		::Uml::InitAttributeProps(ModelsFolder::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Module::meta, "Module", false, "Model", NULL);

		::Uml::InitClassProps(MsgPort::meta, "MsgPort", false, "Model", NULL);
		vector<string> MsgPort_MsgPortNum_dva;
		MsgPort_MsgPortNum_dva.push_back("-1");
		::Uml::InitAttributeProps(MsgPort::meta_MsgPortNum, "MsgPortNum", "Integer", false, false, 1, 1, false, "public", MsgPort_MsgPortNum_dva);
		::Uml::InitAttributeProps(MsgPort::meta_FieldMetaData, "FieldMetaData", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Multiplicative::meta, "Multiplicative", false, "Model", NULL);

		::Uml::InitClassProps(Network::meta, "Network", false, "Model", NULL);
		vector<string> Network_DataRate_dva;
		Network_DataRate_dva.push_back("1b");
		::Uml::InitAttributeProps(Network::meta_DataRate, "DataRate", "String", false, false, 1, 1, false, "public", Network_DataRate_dva);

		::Uml::InitClassProps(Node::meta, "Node", false, "Model", NULL);
		::Uml::InitAttributeProps(Node::meta_Simulator, "Simulator", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Node::meta_ROM, "ROM", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Node::meta_RAM, "RAM", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Node::meta_Speed, "Speed", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Node::meta_CPU, "CPU", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Node::meta_PlatformType, "PlatformType", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Node::meta_BusIDList, "BusIDList", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(NodeRef::meta, "NodeRef", false, "Reference", NULL);

		::Uml::InitClassProps(Normal::meta, "Normal", false, "Model", NULL);
		::Uml::InitAttributeProps(Normal::meta_Mean, "Mean", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Normal::meta_StdDev, "StdDev", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(OChan::meta, "OChan", false, "Atom", NULL);

		::Uml::InitClassProps(OS::meta, "OS", false, "Atom", NULL);
		vector<string> OS_ContextSwitchTime_dva;
		OS_ContextSwitchTime_dva.push_back("0s");
		::Uml::InitAttributeProps(OS::meta_ContextSwitchTime, "ContextSwitchTime", "String", false, false, 1, 1, false, "public", OS_ContextSwitchTime_dva);
		vector<string> OS_SendOverheadTime_dva;
		OS_SendOverheadTime_dva.push_back("0s");
		::Uml::InitAttributeProps(OS::meta_SendOverheadTime, "SendOverheadTime", "String", false, false, 1, 1, false, "public", OS_SendOverheadTime_dva);
		vector<string> OS_RecvOverheadTime_dva;
		OS_RecvOverheadTime_dva.push_back("0s");
		::Uml::InitAttributeProps(OS::meta_RecvOverheadTime, "RecvOverheadTime", "String", false, false, 1, 1, false, "public", OS_RecvOverheadTime_dva);
		vector<string> OS_TickResolution_dva;
		OS_TickResolution_dva.push_back("1ms");
		::Uml::InitAttributeProps(OS::meta_TickResolution, "TickResolution", "String", false, false, 1, 1, false, "public", OS_TickResolution_dva);
		vector<string> OS_MaxTaskNumber_dva;
		OS_MaxTaskNumber_dva.push_back("1048576");
		::Uml::InitAttributeProps(OS::meta_MaxTaskNumber, "MaxTaskNumber", "Integer", false, false, 1, 1, false, "public", OS_MaxTaskNumber_dva);
		vector<string> OS_SchedulingAlgorithm_dva;
		OS_SchedulingAlgorithm_dva.push_back("Static");
		::Uml::InitAttributeProps(OS::meta_SchedulingAlgorithm, "SchedulingAlgorithm", "String", false, false, 1, 1, false, "public", OS_SchedulingAlgorithm_dva);
		vector<string> OS_ISROverheadTime_dva;
		OS_ISROverheadTime_dva.push_back("0s");
		::Uml::InitAttributeProps(OS::meta_ISROverheadTime, "ISROverheadTime", "String", false, false, 1, 1, false, "public", OS_ISROverheadTime_dva);

		::Uml::InitClassProps(Occurrence::meta, "Occurrence", true, "Model", NULL);

		::Uml::InitClassProps(OldBus::meta, "OldBus", false, "Model", NULL);
		::Uml::InitAttributeProps(OldBus::meta_Medium, "Medium", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(OldBus::meta_FrameSize, "FrameSize", "Integer", false, false, 1, 1, false, "public", vector<string>());
		vector<string> OldBus_OverheadTime_dva;
		OldBus_OverheadTime_dva.push_back("0s");
		::Uml::InitAttributeProps(OldBus::meta_OverheadTime, "OverheadTime", "String", false, false, 1, 1, false, "public", OldBus_OverheadTime_dva);

		::Uml::InitClassProps(OldTask::meta, "OldTask", false, "Model", NULL);
		::Uml::InitAttributeProps(OldTask::meta_Priority, "Priority", "Integer", false, false, 1, 1, false, "public", vector<string>());
		vector<string> OldTask_TaskType_dva;
		OldTask_TaskType_dva.push_back("AUTO");
		::Uml::InitAttributeProps(OldTask::meta_TaskType, "TaskType", "String", false, false, 1, 1, false, "public", OldTask_TaskType_dva);
		vector<string> OldTask_Activation_dva;
		OldTask_Activation_dva.push_back("1");
		::Uml::InitAttributeProps(OldTask::meta_Activation, "Activation", "Integer", false, false, 1, 1, false, "public", OldTask_Activation_dva);
		vector<string> OldTask_AutoStart_dva;
		OldTask_AutoStart_dva.push_back("true");
		::Uml::InitAttributeProps(OldTask::meta_AutoStart, "AutoStart", "Boolean", false, false, 1, 1, false, "public", OldTask_AutoStart_dva);
		vector<string> OldTask_Preemption_dva;
		OldTask_Preemption_dva.push_back("FULL");
		::Uml::InitAttributeProps(OldTask::meta_Preemption, "Preemption", "String", false, false, 1, 1, false, "public", OldTask_Preemption_dva);
		vector<string> OldTask_Cyclic_dva;
		OldTask_Cyclic_dva.push_back("false");
		::Uml::InitAttributeProps(OldTask::meta_Cyclic, "Cyclic", "Boolean", false, false, 1, 1, false, "public", OldTask_Cyclic_dva);
		::Uml::InitAttributeProps(OldTask::meta_CycleTime, "CycleTime", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(OutPort::meta, "OutPort", true, "Model", NULL);

		::Uml::InitClassProps(Output::meta, "Output", true, "FCO", NULL);

		::Uml::InitClassProps(OutputEvent::meta, "OutputEvent", true, "FCO", NULL);

		::Uml::InitClassProps(OutputPort::meta, "OutputPort", false, "Model", NULL);
		::Uml::InitAttributeProps(OutputPort::meta_Number, "Number", "Integer", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitConstraintProps(OutputPort::meta_NestedOPtoOPorNestedOPtoIP, "NestedOPtoOPorNestedOPtoIP", "This OutputPort may only connect to a nested InputPort/TriggerPort/EnablePort or to an OutputPort in the parent System or Subsystem.", "let parent2 = self.parent().parent() in\nself.reverseConnectedFCOs( \"src\" ) -> forAll( p |\n   let pParent = p.parent() in\n   pParent = parent2 and p.oclIsKindOf( OutputPort )\n   or\n   pParent.parent() = parent2 and (  p.oclIsKindOf( InputPort ) or p.oclIsKindOf( TriggerPort ) or p.oclIsKindOf( EnablePort )  )\n)");

		::Uml::InitClassProps(OutputToFault::meta, "OutputToFault", false, "Connection", NULL);
		::Uml::InitAttributeProps(OutputToFault::meta_VectorIndex, "VectorIndex", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(OutputToFault_Members_Base::meta, "OutputToFault_Members_Base", true, "FCO", NULL);

		::Uml::InitClassProps(PNPort::meta, "PNPort", false, "Model", NULL);
		vector<string> PNPort_visible_dva;
		PNPort_visible_dva.push_back("false");
		::Uml::InitAttributeProps(PNPort::meta_visible, "visible", "Boolean", false, false, 1, 1, false, "public", PNPort_visible_dva);

		::Uml::InitClassProps(PNState::meta, "PNState", false, "Model", NULL);
		vector<string> PNState_initial_dva;
		PNState_initial_dva.push_back("false");
		::Uml::InitAttributeProps(PNState::meta_initial, "initial", "Boolean", false, false, 1, 1, false, "public", PNState_initial_dva);

		::Uml::InitClassProps(PNTransition::meta, "PNTransition", false, "Model", NULL);
		::Uml::InitAttributeProps(PNTransition::meta_guard, "guard", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(PNTransition::meta_action, "action", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(PNVarRef::meta, "PNVarRef", false, "Reference", NULL);

		::Uml::InitClassProps(PNVariable::meta, "PNVariable", false, "Model", NULL);
		::Uml::InitAttributeProps(PNVariable::meta_datatype, "datatype", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Parameter::meta, "Parameter", false, "Atom", NULL);
		::Uml::InitAttributeProps(Parameter::meta_Value, "Value", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Periodic::meta, "Periodic", false, "Model", NULL);

		::Uml::InitClassProps(PeriodicExecInfo::meta, "PeriodicExecInfo", true, "Model", NULL);
		::Uml::InitAttributeProps(PeriodicExecInfo::meta_ExecPeriod, "ExecPeriod", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(PeriodicExecInfo::meta_DesiredOffset, "DesiredOffset", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(PetriNet::meta, "PetriNet", false, "Model", NULL);
		::Uml::InitAttributeProps(PetriNet::meta_action, "action", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(PetriNetRef::meta, "PetriNetRef", false, "Reference", NULL);

		::Uml::InitClassProps(PhysConnection::meta, "PhysConnection", false, "Connection", NULL);

		::Uml::InitClassProps(PhysInterface::meta, "PhysInterface", true, "Model", NULL);

		::Uml::InitClassProps(Plant::meta, "Plant", false, "Model", NULL);

		::Uml::InitClassProps(PlantComponent::meta, "PlantComponent", false, "Model", NULL);

		::Uml::InitClassProps(PlantComponentRef::meta, "PlantComponentRef", false, "Reference", NULL);

		::Uml::InitClassProps(PlatformLibrary::meta, "PlatformLibrary", false, "Folder", NULL);
		::Uml::InitAttributeProps(PlatformLibrary::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Port::meta, "Port", true, "Model", NULL);

		::Uml::InitClassProps(Postcondition::meta, "Postcondition", false, "Model", NULL);

		::Uml::InitClassProps(Precondition::meta, "Precondition", false, "Model", NULL);

		::Uml::InitClassProps(Primitive::meta, "Primitive", false, "Model", NULL);

		::Uml::InitClassProps(Pulse::meta, "Pulse", false, "Model", NULL);
		::Uml::InitAttributeProps(Pulse::meta_Shift, "Shift", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Pulse::meta_Duration, "Duration", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(RandomDistribution::meta, "RandomDistribution", true, "Model", NULL);

		::Uml::InitClassProps(Reference::meta, "Reference", false, "Model", NULL);
		::Uml::InitAttributeProps(Reference::meta_SourceType, "SourceType", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Reference::meta_SourceBlock, "SourceBlock", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(RequirementsLibrary::meta, "RequirementsLibrary", false, "Folder", NULL);
		::Uml::InitAttributeProps(RequirementsLibrary::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(RootFolder::meta, "RootFolder", false, "Folder", NULL);
		::Uml::InitAttributeProps(RootFolder::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ScenarioInfo::meta, "ScenarioInfo", false, "Atom", NULL);
		::Uml::InitAttributeProps(ScenarioInfo::meta_Requirements, "Requirements", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ScenarioInfo::meta_ScenarioDescription, "ScenarioDescription", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> ScenarioInfo_Criticality_dva;
		ScenarioInfo_Criticality_dva.push_back("C");
		::Uml::InitAttributeProps(ScenarioInfo::meta_Criticality, "Criticality", "String", false, false, 1, 1, false, "public", ScenarioInfo_Criticality_dva);

		::Uml::InitClassProps(SerialLink::meta, "SerialLink", false, "Model", NULL);
		vector<string> SerialLink_DataBits_dva;
		SerialLink_DataBits_dva.push_back("8");
		::Uml::InitAttributeProps(SerialLink::meta_DataBits, "DataBits", "Integer", false, false, 1, 1, false, "public", SerialLink_DataBits_dva);
		vector<string> SerialLink_Parity_dva;
		SerialLink_Parity_dva.push_back("false");
		::Uml::InitAttributeProps(SerialLink::meta_Parity, "Parity", "Boolean", false, false, 1, 1, false, "public", SerialLink_Parity_dva);
		vector<string> SerialLink_StopBits_dva;
		SerialLink_StopBits_dva.push_back("1");
		::Uml::InitAttributeProps(SerialLink::meta_StopBits, "StopBits", "Integer", false, false, 1, 1, false, "public", SerialLink_StopBits_dva);
		vector<string> SerialLink_FlowControl_dva;
		SerialLink_FlowControl_dva.push_back("None");
		::Uml::InitAttributeProps(SerialLink::meta_FlowControl, "FlowControl", "String", false, false, 1, 1, false, "public", SerialLink_FlowControl_dva);

		::Uml::InitClassProps(ShallowHistory::meta, "ShallowHistory", false, "Atom", NULL);

		::Uml::InitClassProps(Sinusoid::meta, "Sinusoid", false, "Model", NULL);
		::Uml::InitAttributeProps(Sinusoid::meta_Frequency, "Frequency", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Sinusoid::meta_Phase, "Phase", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(SporadicExecInfo::meta, "SporadicExecInfo", false, "Model", NULL);
		::Uml::InitAttributeProps(SporadicExecInfo::meta_MinimumPeriod, "MinimumPeriod", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(State::meta, "State", false, "Model", NULL);
		vector<string> State_Decomposition_dva;
		State_Decomposition_dva.push_back("OR_STATE");
		::Uml::InitAttributeProps(State::meta_Decomposition, "Decomposition", "String", false, false, 1, 1, false, "public", State_Decomposition_dva);
		::Uml::InitAttributeProps(State::meta_Name, "Name", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State::meta_EnterAction, "EnterAction", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State::meta_DuringAction, "DuringAction", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State::meta_ExitAction, "ExitAction", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State::meta_Order, "Order", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State::meta_Description, "Description", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(State::meta_Methods, "Methods", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitConstraintProps(State::meta_SingleHistory, "SingleHistory", "A state cannot have multiple history connectors.", "self.atomParts( History ) -> size <= 1");

		::Uml::InitClassProps(StateDE::meta, "StateDE", true, "Model", NULL);

		::Uml::InitClassProps(StatePort::meta, "StatePort", false, "Model", NULL);

		::Uml::InitClassProps(StateToTransition::meta, "StateToTransition", false, "Connection", NULL);

		::Uml::InitClassProps(Stateflow::meta, "Stateflow", false, "Folder", NULL);
		::Uml::InitAttributeProps(Stateflow::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Step::meta, "Step", false, "Model", NULL);
		::Uml::InitAttributeProps(Step::meta_Shift, "Shift", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Substitutive::meta, "Substitutive", false, "Model", NULL);

		::Uml::InitClassProps(Subsystem::meta, "Subsystem", false, "Model", NULL);
		::Uml::InitConstraintProps(Subsystem::meta_UniqueConnectorNames1, "UniqueConnectorNames1", "This System's Port objects must be uniquely named.", "let ports = self.modelParts( InputPort ) + self.modelParts( OutputPort ) + self.modelParts( TriggerPort ) + self.modelParts( EnablePort ) in\nports->isUnique( p | p.name )\n");

		::Uml::InitClassProps(SubsystemRef::meta, "SubsystemRef", false, "Reference", NULL);

		::Uml::InitClassProps(System::meta, "System", false, "Model", NULL);

		::Uml::InitClassProps(SystemTypes::meta, "SystemTypes", false, "Model", NULL);

		::Uml::InitClassProps(TTBus::meta, "TTBus", false, "Model", NULL);
		vector<string> TTBus_Hyperperiod_dva;
		TTBus_Hyperperiod_dva.push_back("0s");
		::Uml::InitAttributeProps(TTBus::meta_Hyperperiod, "Hyperperiod", "String", false, false, 1, 1, false, "public", TTBus_Hyperperiod_dva);
		vector<string> TTBus_TTSetupTime_dva;
		TTBus_TTSetupTime_dva.push_back("0s");
		::Uml::InitAttributeProps(TTBus::meta_TTSetupTime, "TTSetupTime", "String", false, false, 1, 1, false, "public", TTBus_TTSetupTime_dva);
		vector<string> TTBus_SlotSize_dva;
		TTBus_SlotSize_dva.push_back("512B");
		::Uml::InitAttributeProps(TTBus::meta_SlotSize, "SlotSize", "String", false, false, 1, 1, false, "public", TTBus_SlotSize_dva);

		::Uml::InitClassProps(TTExecContext::meta, "TTExecContext", false, "Model", NULL);
		::Uml::InitAttributeProps(TTExecContext::meta_Hyperperiod, "Hyperperiod", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TTExecInfo::meta, "TTExecInfo", false, "Model", NULL);
		::Uml::InitAttributeProps(TTExecInfo::meta_TTSchedule, "TTSchedule", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TaskInst::meta, "TaskInst", false, "Reference", NULL);

		::Uml::InitClassProps(TaskRef::meta, "TaskRef", false, "Reference", NULL);

		::Uml::InitClassProps(Terminate::meta, "Terminate", false, "Atom", NULL);

		::Uml::InitClassProps(TimingConstraint::meta, "TimingConstraint", false, "Connection", NULL);
		vector<string> TimingConstraint_Latency_dva;
		TimingConstraint_Latency_dva.push_back("1s");
		::Uml::InitAttributeProps(TimingConstraint::meta_Latency, "Latency", "String", false, false, 1, 1, false, "public", TimingConstraint_Latency_dva);

		::Uml::InitClassProps(TimingSheet::meta, "TimingSheet", false, "Model", NULL);

		::Uml::InitClassProps(TransConnector::meta, "TransConnector", true, "FCO", NULL);

		::Uml::InitClassProps(TransStart::meta, "TransStart", false, "Atom", NULL);
		::Uml::InitConstraintProps(TransStart::meta_TransStartRestrict, "TransStartRestrict", "A TransStart cannot be a transition destination.", "self.reverseConnectedFCOs( \"dst\" ) -> size = 0");

		::Uml::InitClassProps(Transition::meta, "Transition", false, "Connection", NULL);
		::Uml::InitAttributeProps(Transition::meta_Trigger, "Trigger", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Transition::meta_Guard, "Guard", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Transition::meta_Action, "Action", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Transition::meta_ConditionAction, "ConditionAction", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Transition::meta_Order, "Order", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TransitionToState::meta, "TransitionToState", false, "Connection", NULL);

		::Uml::InitClassProps(Trigger::meta, "Trigger", false, "Connection", NULL);

		::Uml::InitClassProps(TriggerPort::meta, "TriggerPort", false, "Model", NULL);
		vector<string> TriggerPort_TriggerType_dva;
		TriggerPort_TriggerType_dva.push_back("rising");
		::Uml::InitAttributeProps(TriggerPort::meta_TriggerType, "TriggerType", "String", false, false, 1, 1, false, "public", TriggerPort_TriggerType_dva);
		::Uml::InitConstraintProps(TriggerPort::meta_OnlyOneTP, "OnlyOneTP", "There can only be, at most, one TriggerPort created in here.", "self.parent().oclAsType( gme::Model ).modelParts( TriggerPort ) -> size < 2");
		::Uml::InitConstraintProps(TriggerPort::meta_TPConnectedAsDstAtLeastOnce, "TPConnectedAsDstAtLeastOnce", "This TriggerPort must be connected as a destination object.", "self.reverseConnectedFCOs( \"dst\" ) -> size > 0\n");
		::Uml::InitConstraintProps(TriggerPort::meta_TPtoNestedIPTPEPBPOnly, "TPtoNestedIPTPEPBPOnly", "This TriggerPort may only connect to an InputPort/TriggerPort/EnablePort of a nested Subsystem, Reference or Primitive.", "let parent = self.parent() in\nself.reverseConnectedFCOs( \"src\" ) -> forAll( p |\n   p.parent().parent() = parent and (  p.oclIsKindOf( InputPort ) or p.oclIsKindOf( TriggerPort ) or p.oclIsKindOf( EnablePort )  )\n)");
		::Uml::InitConstraintProps(TriggerPort::meta_TPConnectedByPortInParentParent, "TPConnectedByPortInParentParent", "This TriggerPort may only be connected by a Connector in the parent's parent.", "let parent2 = self.parent().parent() in\nself.reverseConnectedFCOs( \"dst\" ) -> forAll(  p | p.parent() = parent2 or p.oclIsKindOf( OutputPort )  )");
		::Uml::InitConstraintProps(TriggerPort::meta_TPInSubsystemOnlyConnectToTPInSystem, "TPInSubsystemOnlyConnectToTPInSystem", "A TriggerPort in a Subsystem can only connect to a TriggerPort in the nested System.", "let parent = self.parent() in\nparent.oclIsKindOf( System )\nimplies\nself.reverseConnectedFCOs( \"src\" ) -> forAll( p | p.oclIsKindOf( TriggerPort ) and p.parent().parent() = parent )\n");
		::Uml::InitConstraintProps(TriggerPort::meta_TPParentIsSubsystemOrSystem, "TPParentIsSubsystemOrSystem", "This TriggerPort can not be inside a Primitive.", "let p = self.parent() in\np.oclIsKindOf( System ) or p.oclIsKindOf( Reference )");
		::Uml::InitConstraintProps(TriggerPort::meta_TriggerParentInSubsystemMustConnectDownToSystem, "TriggerParentInSubsystemMustConnectDownToSystem", "This TriggerPort must connect to an TriggerPort inside a nested System.", "let parent : gme::Model = self.parent() in\nif ( parent.oclIsKindOf( System ) and parent.modelParts() -> size > 0 ) then\n   let srcs = self.reverseConnectedFCOs( \"src\" ) in\n   srcs -> size = 1 \n   and\n   srcs -> forAll(  p | p.oclIsKindOf( TriggerPort )  )\nelse\n   true\nendif");

		::Uml::InitClassProps(TypeBase::meta, "TypeBase", true, "FCO", NULL);

		::Uml::InitClassProps(TypeBaseRef::meta, "TypeBaseRef", false, "Reference", NULL);
		::Uml::InitAttributeProps(TypeBaseRef::meta_MemberIndex, "MemberIndex", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(TypeStruct::meta, "TypeStruct", false, "Model", NULL);
		::Uml::InitAttributeProps(TypeStruct::meta_MemberCount, "MemberCount", "Integer", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Types::meta, "Types", false, "Folder", NULL);
		::Uml::InitAttributeProps(Types::meta_name, "name", "String", false, false, 0, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Uniform::meta, "Uniform", false, "Model", NULL);
		::Uml::InitAttributeProps(Uniform::meta_LowerBound, "LowerBound", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(Uniform::meta_UpperBound, "UpperBound", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(ValueObject::meta, "ValueObject", true, "Model", NULL);

		::Uml::InitClassProps(ValueType::meta, "ValueType", false, "Model", NULL);
		::Uml::InitAttributeProps(ValueType::meta_Scale, "Scale", "String", false, false, 1, 1, false, "public", vector<string>());
		vector<string> ValueType_Signed_dva;
		ValueType_Signed_dva.push_back("false");
		::Uml::InitAttributeProps(ValueType::meta_Signed, "Signed", "Boolean", false, false, 1, 1, false, "public", ValueType_Signed_dva);
		::Uml::InitAttributeProps(ValueType::meta_DataType, "DataType", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ValueType::meta_MinValue, "MinValue", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ValueType::meta_MaxValue, "MaxValue", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ValueType::meta_Units, "Units", "String", false, false, 1, 1, false, "public", vector<string>());
		::Uml::InitAttributeProps(ValueType::meta_Offset, "Offset", "String", false, false, 1, 1, false, "public", vector<string>());

		::Uml::InitClassProps(Variable::meta, "Variable", false, "Model", NULL);

		::Uml::InitClassProps(Wire::meta, "Wire", false, "Connection", NULL);

		// associations
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "FaultToInput");
			FaultToInput_Members_Base::meta_dstFaultToInput = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultToInput_Members_Base::meta_dstFaultToInput, "dstFaultToInput", true, false, 0, -1);
			FaultToInput_Members_Base::meta_srcFaultToInput = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultToInput_Members_Base::meta_srcFaultToInput, "srcFaultToInput", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "OutputToFault");
			OutputToFault_Members_Base::meta_dstOutputToFault = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(OutputToFault_Members_Base::meta_dstOutputToFault, "dstOutputToFault", true, false, 0, -1);
			OutputToFault_Members_Base::meta_srcOutputToFault = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(OutputToFault_Members_Base::meta_srcOutputToFault, "srcOutputToFault", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "CommMapping");
			CommMapping_Members_Base::meta_dstCommMapping = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CommMapping_Members_Base::meta_dstCommMapping, "dstCommMapping", true, false, 0, -1);
			CommMapping_Members_Base::meta_srcCommMapping = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CommMapping_Members_Base::meta_srcCommMapping, "srcCommMapping", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			CommMapping::meta_srcCommMapping__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CommMapping::meta_srcCommMapping__rp_helper, "srcCommMapping__rp_helper", true, false, 0, 1);
			CommMapping_srcCommMapping_RPContainer_Base::meta_srcCommMapping__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CommMapping_srcCommMapping_RPContainer_Base::meta_srcCommMapping__rp_helper_rev, "srcCommMapping__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			CommMapping::meta_dstCommMapping__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CommMapping::meta_dstCommMapping__rp_helper, "dstCommMapping__rp_helper", true, false, 0, 1);
			CommMapping_dstCommMapping_RPContainer_Base::meta_dstCommMapping__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(CommMapping_dstCommMapping_RPContainer_Base::meta_dstCommMapping__rp_helper_rev, "dstCommMapping__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			FaultTrigger::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultTrigger::meta_ref, "ref", true, false, 0, 1);
			FaultEvent::meta_referedbyFaultTrigger = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultEvent::meta_referedbyFaultTrigger, "referedbyFaultTrigger", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			TaskInst::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TaskInst::meta_ref, "ref", true, false, 0, 1);
			ComponentRef::meta_referedbyTaskInst = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_referedbyTaskInst, "referedbyTaskInst", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			Action::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Action::meta_ref, "ref", true, false, 0, 1);
			ComponentRef::meta_referedbyAction = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_referedbyAction, "referedbyAction", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			FaultMgrTask::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultMgrTask::meta_ref, "ref", true, false, 0, 1);
			ComponentRef::meta_referedbyFaultMgrTask = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_referedbyFaultMgrTask, "referedbyFaultMgrTask", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			DesignReference::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(DesignReference::meta_ref, "ref", true, false, 0, 1);
			System::meta_referedbyDesignReference = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(System::meta_referedbyDesignReference, "referedbyDesignReference", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			FaultModelRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultModelRef::meta_ref, "ref", true, false, 0, 1);
			FaultModel::meta_referedbyFaultModelRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(FaultModel::meta_referedbyFaultModelRef, "referedbyFaultModelRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "TransitionToState");
			PNTransition::meta_dstTransitionToState = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNTransition::meta_dstTransitionToState, "dstTransitionToState", true, false, 0, -1);
			PNState::meta_srcTransitionToState = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNState::meta_srcTransitionToState, "srcTransitionToState", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "StateToTransition");
			PNState::meta_dstStateToTransition = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNState::meta_dstStateToTransition, "dstStateToTransition", true, false, 0, -1);
			PNTransition::meta_srcStateToTransition = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNTransition::meta_srcStateToTransition, "srcStateToTransition", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			PNVarRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNVarRef::meta_ref, "ref", true, false, 0, 1);
			PNVariable::meta_referedbyPNVarRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNVariable::meta_referedbyPNVarRef, "referedbyPNVarRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "BIPConnector");
			PNPort::meta_dstPortToPort = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNPort::meta_dstPortToPort, "dstPortToPort", true, false, 0, -1);
			PNPort::meta_srcPortToPort = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PNPort::meta_srcPortToPort, "srcPortToPort", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "ExecutionAssignment");
			ExecutionInfo::meta_dstExecutionAssignment = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ExecutionInfo::meta_dstExecutionAssignment, "dstExecutionAssignment", true, false, 0, -1);
			Executable::meta_srcExecutionAssignment = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Executable::meta_srcExecutionAssignment, "srcExecutionAssignment", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			ExecutionAssignment::meta_dstExecutionAssignment__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ExecutionAssignment::meta_dstExecutionAssignment__rp_helper, "dstExecutionAssignment__rp_helper", true, false, 0, 1);
			ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta_dstExecutionAssignment__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta_dstExecutionAssignment__rp_helper_rev, "dstExecutionAssignment__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			SubsystemRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(SubsystemRef::meta_ref, "ref", true, false, 0, 1);
			Subsystem::meta_referedbySubsystemRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Subsystem::meta_referedbySubsystemRef, "referedbySubsystemRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			PetriNetRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PetriNetRef::meta_ref, "ref", true, false, 0, 1);
			PetriNet::meta_referedbyPetriNetRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PetriNet::meta_referedbyPetriNetRef, "referedbyPetriNetRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			IOPortInfoRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IOPortInfoRef::meta_ref, "ref", true, false, 0, 1);
			IOPortInfo::meta_referedbyIOPortInfoRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IOPortInfo::meta_referedbyIOPortInfoRef, "referedbyIOPortInfoRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "IOPortAssignment");
			IOPortInfoBase::meta_dstIOPortAssignment = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IOPortInfoBase::meta_dstIOPortAssignment, "dstIOPortAssignment", true, false, 0, -1);
			IOPortExp::meta_srcIOPortAssignment = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IOPortExp::meta_srcIOPortAssignment, "srcIOPortAssignment", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			Connector::meta_dstConnector__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Connector::meta_dstConnector__rp_helper, "dstConnector__rp_helper", true, false, 0, 1);
			Connector_dstConnector_RPContainer_Base::meta_dstConnector__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Connector_dstConnector_RPContainer_Base::meta_dstConnector__rp_helper_rev, "dstConnector__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			Connector::meta_srcConnector__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Connector::meta_srcConnector__rp_helper, "srcConnector__rp_helper", true, false, 0, 1);
			Connector_srcConnector_RPContainer_Base::meta_srcConnector__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Connector_srcConnector_RPContainer_Base::meta_srcConnector__rp_helper_rev, "srcConnector__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "CompBreakout");
			ComponentBase::meta_dstCompBreakout = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentBase::meta_dstCompBreakout, "dstCompBreakout", true, false, 0, -1);
			TaskInst::meta_srcCompBreakout = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TaskInst::meta_srcCompBreakout, "srcCompBreakout", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Connector");
			Output::meta_dstConnector = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Output::meta_dstConnector, "dstConnector", true, false, 0, -1);
			Input::meta_srcConnector = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Input::meta_srcConnector, "srcConnector", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Trigger");
			OutputEvent::meta_dstTrigger = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(OutputEvent::meta_dstTrigger, "dstTrigger", true, false, 0, -1);
			InputEvent::meta_srcTrigger = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(InputEvent::meta_srcTrigger, "srcTrigger", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			MessageRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(MessageRef::meta_ref, "ref", true, false, 0, 1);
			MessageRef_RefersTo_Base::meta_referedbyBusMessageRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(MessageRef_RefersTo_Base::meta_referedbyBusMessageRef, "referedbyBusMessageRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Dependency");
			MessageRef::meta_dstDependency = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(MessageRef::meta_dstDependency, "dstDependency", true, false, 0, -1);
			MessageRef::meta_srcDependency = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(MessageRef::meta_srcDependency, "srcDependency", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			Dependency::meta_srcDependency__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Dependency::meta_srcDependency__rp_helper, "srcDependency__rp_helper", true, false, 0, 1);
			ComponentRef::meta_srcDependency__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_srcDependency__rp_helper_rev, "srcDependency__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			Dependency::meta_dstDependency__rp_helper = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Dependency::meta_dstDependency__rp_helper, "dstDependency__rp_helper", true, false, 0, 1);
			ComponentRef::meta_dstDependency__rp_helper_rev = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_dstDependency__rp_helper_rev, "dstDependency__rp_helper_rev", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "TimingConstraint");
			TaskRef::meta_dstTimingConstraint = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TaskRef::meta_dstTimingConstraint, "dstTimingConstraint", true, false, 0, -1);
			TaskRef::meta_srcTimingConstraint = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TaskRef::meta_srcTimingConstraint, "srcTimingConstraint", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			TaskRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TaskRef::meta_ref, "ref", true, false, 0, 1);
			Component::meta_referedbyTaskRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Component::meta_referedbyTaskRef, "referedbyTaskRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			TypeBaseRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypeBaseRef::meta_ref, "ref", true, false, 0, 1);
			TypeBase::meta_referedbyTypeStructRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TypeBase::meta_referedbyTypeStructRef, "referedbyTypeStructRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Line");
			Port::meta_dstLine = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Port::meta_dstLine, "dstLine", true, false, 0, -1);
			Port::meta_srcLine = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Port::meta_srcLine, "srcLine", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			ConnectorRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ConnectorRef::meta_ref, "ref", true, false, 0, 1);
			TransConnector::meta_referedbyConnectorRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TransConnector::meta_referedbyConnectorRef, "referedbyConnectorRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Transition");
			TransConnector::meta_dstTransition = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TransConnector::meta_dstTransition, "dstTransition", true, false, 0, -1);
			TransConnector::meta_srcTransition = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(TransConnector::meta_srcTransition, "srcTransition", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "Wire");
			Connectable::meta_dstWire = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Connectable::meta_dstWire, "dstWire", true, false, 0, -1);
			Connectable::meta_srcWire = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Connectable::meta_srcWire, "srcWire", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "ActuationConnection");
			OChan::meta_dstActuationConnection = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(OChan::meta_dstActuationConnection, "dstActuationConnection", true, false, 0, -1);
			IODevice::meta_srcActuationConnection = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IODevice::meta_srcActuationConnection, "srcActuationConnection", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "AcquisitionConnection");
			IODevice::meta_dstAcquisitionConnection = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IODevice::meta_dstAcquisitionConnection, "dstAcquisitionConnection", true, false, 0, -1);
			IChan::meta_srcAcquisitionConnection = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(IChan::meta_srcAcquisitionConnection, "srcAcquisitionConnection", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "PhysConnection");
			PhysInterface::meta_dstPhysConnection = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PhysInterface::meta_dstPhysConnection, "dstPhysConnection", true, false, 0, -1);
			PhysInterface::meta_srcPhysConnection = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(PhysInterface::meta_srcPhysConnection, "srcPhysConnection", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			NodeRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(NodeRef::meta_ref, "ref", true, false, 0, 1);
			Node::meta_referedbyNodeRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(Node::meta_referedbyNodeRef, "referedbyNodeRef", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "ComponentAssignment");
			ComponentRef::meta_dstComponentAssignment = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_dstComponentAssignment, "dstComponentAssignment", true, false, 0, -1);
			NodeRef::meta_srcComponentAssignment = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(NodeRef::meta_srcComponentAssignment, "srcComponentAssignment", true, false, 0, -1);

		}
		{
			::Uml::Association ass = ::Uml::Association::Create(meta);
			::Uml::InitAssociationProps(ass, "");
			ComponentRef::meta_ref = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef::meta_ref, "ref", true, false, 0, 1);
			ComponentRef_RefersTo_Base::meta_referedbyComponentRef = ::Uml::AssociationRole::Create(ass);
			::Uml::InitAssociationRoleProps(ComponentRef_RefersTo_Base::meta_referedbyComponentRef, "referedbyComponentRef", true, false, 0, -1);

		}

		// compositions
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ScenarioInfo::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ScenarioInfo::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_ScenarioInfo_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_ScenarioInfo_children, "ScenarioInfo", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultTrigger::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultTrigger::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_FaultTrigger_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_FaultTrigger_children, "FaultTrigger", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultCondition::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultCondition::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_FaultCondition_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_FaultCondition_children, "FaultCondition", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TaskInst::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TaskInst::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_TaskInst_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_TaskInst_children, "TaskInst", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Action::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Action::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_Action_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_Action_children, "Action", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultMgrTask::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultMgrTask::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_FaultMgrTask_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_FaultMgrTask_children, "FaultMgrTask", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ComponentBase::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ComponentBase::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_ComponentBase_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_ComponentBase_children, "ComponentBase", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			CompBreakout::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(CompBreakout::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_CompBreakout_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_CompBreakout_children, "CompBreakout", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultModel::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultModel::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_FaultModel_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_FaultModel_children, "FaultModel", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			DesignReference::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(DesignReference::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_DesignReference_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_DesignReference_children, "DesignReference", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultToInput::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultToInput::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_FaultToInput_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_FaultToInput_children, "FaultToInput", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			OutputToFault::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(OutputToFault::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_OutputToFault_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_OutputToFault_children, "OutputToFault", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultModelRef::meta_FaultScenario_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultModelRef::meta_FaultScenario_parent, "FaultScenario_parent", true);
			FaultScenario::meta_FaultModelRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultScenario::meta_FaultModelRef_children, "FaultModelRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Variable::meta_FaultModel_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Variable::meta_FaultModel_parent, "FaultModel_parent", true);
			FaultModel::meta_Variable_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultModel::meta_Variable_children, "Variable", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Occurrence::meta_Variable_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Occurrence::meta_Variable_parent, "Variable_parent", true);
			Variable::meta_Occurrence_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Variable::meta_Occurrence_children, "Occurrence", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Incorporation::meta_Variable_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Incorporation::meta_Variable_parent, "Variable_parent", true);
			Variable::meta_Incorporation_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Variable::meta_Incorporation_children, "Incorporation", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ValueObject::meta_Variable_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ValueObject::meta_Variable_parent, "Variable_parent", true);
			Variable::meta_ValueObject_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Variable::meta_ValueObject_children, "ValueObject", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultModel::meta_FaultModelFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultModel::meta_FaultModelFolder_parent, "FaultModelFolder_parent", true);
			FaultModelFolder::meta_FaultModel_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(FaultModelFolder::meta_FaultModel_children, "FaultModel", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			BIPConnector::meta_Module_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(BIPConnector::meta_Module_parent, "Module_parent", true);
			Module::meta_BIPConnector_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Module::meta_BIPConnector_children, "BIPConnector", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PetriNet::meta_Module_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PetriNet::meta_Module_parent, "Module_parent", true);
			Module::meta_PetriNet_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Module::meta_PetriNet_children, "PetriNet", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			StateToTransition::meta_PetriNet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(StateToTransition::meta_PetriNet_parent, "PetriNet_parent", true);
			PetriNet::meta_StateToTransition_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PetriNet::meta_StateToTransition_children, "StateToTransition", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PNTransition::meta_PetriNet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PNTransition::meta_PetriNet_parent, "PetriNet_parent", true);
			PetriNet::meta_PNTransition_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PetriNet::meta_PNTransition_children, "PNTransition", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TransitionToState::meta_PetriNet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TransitionToState::meta_PetriNet_parent, "PetriNet_parent", true);
			PetriNet::meta_TransitionToState_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PetriNet::meta_TransitionToState_children, "TransitionToState", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PNState::meta_PetriNet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PNState::meta_PetriNet_parent, "PetriNet_parent", true);
			PetriNet::meta_PNState_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PetriNet::meta_PNState_children, "PNState", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PNVariable::meta_PetriNet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PNVariable::meta_PetriNet_parent, "PetriNet_parent", true);
			PetriNet::meta_PNVariable_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PetriNet::meta_PNVariable_children, "PNVariable", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PNPort::meta_PetriNet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PNPort::meta_PetriNet_parent, "PetriNet_parent", true);
			PetriNet::meta_PNPort_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PetriNet::meta_PNPort_children, "PNPort", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PNVarRef::meta_PNPort_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PNVarRef::meta_PNPort_parent, "PNPort_parent", true);
			PNPort::meta_PNVarRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PNPort::meta_PNVarRef_children, "PNVarRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Dataflow::meta_ModelsFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Dataflow::meta_ModelsFolder_parent, "ModelsFolder_parent", true);
			ModelsFolder::meta_Dataflow_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ModelsFolder::meta_Dataflow_children, "Dataflow", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Stateflow::meta_ModelsFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Stateflow::meta_ModelsFolder_parent, "ModelsFolder_parent", true);
			ModelsFolder::meta_Stateflow_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ModelsFolder::meta_Stateflow_children, "Stateflow", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ModelInfo::meta_ModelsFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ModelInfo::meta_ModelsFolder_parent, "ModelsFolder_parent", true);
			ModelsFolder::meta_ModelInfo_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ModelsFolder::meta_ModelInfo_children, "ModelInfo", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Module::meta_ModelsFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Module::meta_ModelsFolder_parent, "ModelsFolder_parent", true);
			ModelsFolder::meta_Module_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ModelsFolder::meta_Module_children, "Module", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			COutputPort::meta_CCode_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(COutputPort::meta_CCode_parent, "CCode_parent", true);
			CCode::meta_COutputPort_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(CCode::meta_COutputPort_children, "COutputPort", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			CInputPort::meta_CCode_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(CInputPort::meta_CCode_parent, "CCode_parent", true);
			CCode::meta_CInputPort_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(CCode::meta_CInputPort_children, "CInputPort", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			SystemTypes::meta_ArchitectureLibrary_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(SystemTypes::meta_ArchitectureLibrary_parent, "ArchitectureLibrary_parent", true);
			ArchitectureLibrary::meta_SystemTypes_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(ArchitectureLibrary::meta_SystemTypes_children, "SystemTypes", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Message::meta_SystemTypes_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Message::meta_SystemTypes_parent, "SystemTypes_parent", true);
			SystemTypes::meta_Message_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(SystemTypes::meta_Message_children, "Message", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Component::meta_SystemTypes_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Component::meta_SystemTypes_parent, "SystemTypes_parent", true);
			SystemTypes::meta_Component_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(SystemTypes::meta_Component_children, "Component", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			MsgPort::meta_Message_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(MsgPort::meta_Message_parent, "Message_parent", true);
			Message::meta_MsgPort_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Message::meta_MsgPort_children, "MsgPort", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FieldDataType::meta_MsgPort_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FieldDataType::meta_MsgPort_parent, "MsgPort_parent", true);
			MsgPort::meta_FieldDataType_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(MsgPort::meta_FieldDataType_children, "FieldDataType", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			SystemTypes::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(SystemTypes::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_SystemTypes_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_SystemTypes_children, "SystemTypes", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultModel::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultModel::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_FaultModel_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_FaultModel_children, "FaultModel", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultModelFolder::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultModelFolder::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_FaultModelFolder_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_FaultModelFolder_children, "FaultModelFolder", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			HardwareUnit::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(HardwareUnit::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_HardwareUnit_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_HardwareUnit_children, "HardwareUnit", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TimingSheet::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TimingSheet::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_TimingSheet_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_TimingSheet_children, "TimingSheet", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			System::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(System::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_System_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_System_children, "System", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ModelsFolder::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ModelsFolder::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_ModelsFolder_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_ModelsFolder_children, "ModelsFolder", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			FaultScenario::meta_DesignFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(FaultScenario::meta_DesignFolder_parent, "DesignFolder_parent", true);
			DesignFolder::meta_FaultScenario_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DesignFolder::meta_FaultScenario_children, "FaultScenario", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Trigger::meta_Component_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Trigger::meta_Component_parent, "Component_parent", true);
			Component::meta_Trigger_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Component::meta_Trigger_children, "Trigger", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			MessageRef::meta_Component_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(MessageRef::meta_Component_parent, "Component_parent", true);
			Component::meta_MessageRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Component::meta_MessageRef_children, "MessageRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ComponentBase::meta_Component_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ComponentBase::meta_Component_parent, "Component_parent", true);
			Component::meta_ComponentBase_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Component::meta_ComponentBase_children, "ComponentBase", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Connector::meta_Component_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Connector::meta_Component_parent, "Component_parent", true);
			Component::meta_Connector_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Component::meta_Connector_children, "Connector", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TimingSheet::meta_RequirementsLibrary_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TimingSheet::meta_RequirementsLibrary_parent, "RequirementsLibrary_parent", true);
			RequirementsLibrary::meta_TimingSheet_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RequirementsLibrary::meta_TimingSheet_children, "TimingSheet", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TaskRef::meta_TimingSheet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TaskRef::meta_TimingSheet_parent, "TimingSheet_parent", true);
			TimingSheet::meta_TaskRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(TimingSheet::meta_TaskRef_children, "TaskRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TimingConstraint::meta_TimingSheet_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TimingConstraint::meta_TimingSheet_parent, "TimingSheet_parent", true);
			TimingSheet::meta_TimingConstraint_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(TimingSheet::meta_TimingConstraint_children, "TimingConstraint", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBase::meta_Types_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBase::meta_Types_parent, "Types_parent", true);
			Types::meta_TypeBase_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Types::meta_TypeBase_children, "TypeBase", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBaseRef::meta_TypeStruct_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBaseRef::meta_TypeStruct_parent, "TypeStruct_parent", true);
			TypeStruct::meta_TypeBaseRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(TypeStruct::meta_TypeBaseRef_children, "TypeBaseRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Parameter::meta_Parameter_Block_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Parameter::meta_Parameter_Block_parent, "Parameter_Block_parent", true);
			Block::meta_Parameter = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Block::meta_Parameter, "Parameter", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Line::meta_Line_Block_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Line::meta_Line_Block_parent, "Line_Block_parent", true);
			Block::meta_Line = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Block::meta_Line, "Line", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Annotation::meta_Block_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Annotation::meta_Block_parent, "Block_parent", true);
			Block::meta_Annotation_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Block::meta_Annotation_children, "Annotation", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ConnectorRef::meta_Block_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ConnectorRef::meta_Block_parent, "Block_parent", true);
			Block::meta_ConnectorRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Block::meta_ConnectorRef_children, "ConnectorRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Port::meta_Block_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Port::meta_Block_parent, "Block_parent", true);
			Block::meta_Port_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Block::meta_Port_children, "Port", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Subsystem::meta_Dataflow_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Subsystem::meta_Dataflow_parent, "Dataflow_parent", true);
			Dataflow::meta_Subsystem_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Dataflow::meta_Subsystem_children, "Subsystem", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Block::meta_Subsystem_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Block::meta_Subsystem_parent, "Subsystem_parent", true);
			Subsystem::meta_Block_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Subsystem::meta_Block_children, "Block", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBaseRef::meta_Port_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBaseRef::meta_Port_parent, "Port_parent", true);
			Port::meta_TypeBaseRef_child = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Port::meta_TypeBaseRef_child, "TypeBaseRef", true, 0, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Transition::meta_Transition_State_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Transition::meta_Transition_State_parent, "Transition_State_parent", true);
			State::meta_Transition = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(State::meta_Transition, "Transition", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TransConnector::meta_State_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TransConnector::meta_State_parent, "State_parent", true);
			State::meta_TransConnector_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(State::meta_TransConnector_children, "TransConnector", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			StateDE::meta_State_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(StateDE::meta_State_parent, "State_parent", true);
			State::meta_StateDE_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(State::meta_StateDE_children, "StateDE", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			State::meta_Stateflow_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(State::meta_Stateflow_parent, "Stateflow_parent", true);
			Stateflow::meta_State_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Stateflow::meta_State_children, "State", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			TypeBaseRef::meta_StateDE_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(TypeBaseRef::meta_StateDE_parent, "StateDE_parent", true);
			StateDE::meta_TypeBaseRef_child = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(StateDE::meta_TypeBaseRef_child, "TypeBaseRef", true, 0, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Wire::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Wire::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_Wire_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_Wire_children, "Wire", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			HWElement::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(HWElement::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_HWElement_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_HWElement_children, "HWElement", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Channel::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Channel::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_Channel_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_Channel_children, "Channel", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Plant::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Plant::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_Plant_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_Plant_children, "Plant", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PhysConnection::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PhysConnection::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_PhysConnection_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_PhysConnection_children, "PhysConnection", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			AcquisitionConnection::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(AcquisitionConnection::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_AcquisitionConnection_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_AcquisitionConnection_children, "AcquisitionConnection", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ActuationConnection::meta_HardwareUnit_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ActuationConnection::meta_HardwareUnit_parent, "HardwareUnit_parent", true);
			HardwareUnit::meta_ActuationConnection_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HardwareUnit::meta_ActuationConnection_children, "ActuationConnection", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			HardwareUnit::meta_PlatformLibrary_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(HardwareUnit::meta_PlatformLibrary_parent, "PlatformLibrary_parent", true);
			PlatformLibrary::meta_HardwareUnit_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(PlatformLibrary::meta_HardwareUnit_children, "HardwareUnit", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			BChan::meta_Network_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(BChan::meta_Network_parent, "Network_parent", true);
			Network::meta_BChan_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Network::meta_BChan_children, "BChan", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ExecutionContext::meta_HWElement_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ExecutionContext::meta_HWElement_parent, "HWElement_parent", true);
			HWElement::meta_ExecutionContext_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(HWElement::meta_ExecutionContext_children, "ExecutionContext", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Channel::meta_IODevice_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Channel::meta_IODevice_parent, "IODevice_parent", true);
			IODevice::meta_Channel_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(IODevice::meta_Channel_children, "Channel", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			OS::meta_Node_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(OS::meta_Node_parent, "Node_parent", true);
			Node::meta_OS_child = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Node::meta_OS_child, "OS", true, 0, 1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Channel::meta_Node_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Channel::meta_Node_parent, "Node_parent", true);
			Node::meta_Channel_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(Node::meta_Channel_children, "Channel", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			System::meta_DeploymentLibrary_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(System::meta_DeploymentLibrary_parent, "DeploymentLibrary_parent", true);
			DeploymentLibrary::meta_System_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(DeploymentLibrary::meta_System_children, "System", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ComponentRef::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ComponentRef::meta_System_parent, "System_parent", true);
			System::meta_ComponentRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_ComponentRef_children, "ComponentRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			NodeRef::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(NodeRef::meta_System_parent, "System_parent", true);
			System::meta_NodeRef_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_NodeRef_children, "NodeRef", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			CommMapping::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(CommMapping::meta_System_parent, "System_parent", true);
			System::meta_CommMapping_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_CommMapping_children, "CommMapping", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Dependency::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Dependency::meta_System_parent, "System_parent", true);
			System::meta_Dependency_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_Dependency_children, "Dependency", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ComponentAssignment::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ComponentAssignment::meta_System_parent, "System_parent", true);
			System::meta_ComponentAssignment_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_ComponentAssignment_children, "ComponentAssignment", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ExecutionInfo::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ExecutionInfo::meta_System_parent, "System_parent", true);
			System::meta_ExecutionInfo_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_ExecutionInfo_children, "ExecutionInfo", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ExecutionAssignment::meta_System_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ExecutionAssignment::meta_System_parent, "System_parent", true);
			System::meta_ExecutionAssignment_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(System::meta_ExecutionAssignment_children, "ExecutionAssignment", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			ArchitectureLibrary::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(ArchitectureLibrary::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_ArchitectureLibrary_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_ArchitectureLibrary_children, "ArchitectureLibrary", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			DesignFolder::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(DesignFolder::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_DesignFolder_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_DesignFolder_children, "DesignFolder", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			RequirementsLibrary::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(RequirementsLibrary::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_RequirementsLibrary_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_RequirementsLibrary_children, "RequirementsLibrary", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			Types::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(Types::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_Types_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_Types_children, "Types", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			PlatformLibrary::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(PlatformLibrary::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_PlatformLibrary_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_PlatformLibrary_children, "PlatformLibrary", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			DeploymentLibrary::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(DeploymentLibrary::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_DeploymentLibrary_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_DeploymentLibrary_children, "DeploymentLibrary", true, 0, -1);

		}
		{
			::Uml::Composition comp = ::Uml::Composition::Create(meta);
			::Uml::InitCompositionProps(comp, "", false);
			RootFolder::meta_RootFolder_parent = ::Uml::CompositionParentRole::Create(comp);
			::Uml::InitCompositionParentRoleProps(RootFolder::meta_RootFolder_parent, "RootFolder_parent", true);
			RootFolder::meta_RootFolder_children = ::Uml::CompositionChildRole::Create(comp);
			::Uml::InitCompositionChildRoleProps(RootFolder::meta_RootFolder_children, "RootFolder", true, 0, -1);

		}

	}

	void InitMetaLinks() {
		HardwareUnit::meta_AcquisitionConnection_children.target() = AcquisitionConnection::meta;
		AcquisitionConnection::meta.association() = IODevice::meta_dstAcquisitionConnection.parent();
		AcquisitionConnection::meta_dstAcquisitionConnection_end_ = IChan::meta_srcAcquisitionConnection_rev = IODevice::meta_dstAcquisitionConnection;
		AcquisitionConnection::meta_srcAcquisitionConnection_end_ = IODevice::meta_dstAcquisitionConnection_rev = IChan::meta_srcAcquisitionConnection;

		Action::meta_ref.target() = ComponentRef::meta;
		FaultScenario::meta_Action_children.target() = Action::meta;
		Action::meta.subTypes() += DetectionAction::meta;
		Action::meta.subTypes() += MitigationAction::meta;

		HardwareUnit::meta_ActuationConnection_children.target() = ActuationConnection::meta;
		ActuationConnection::meta.association() = OChan::meta_dstActuationConnection.parent();
		ActuationConnection::meta_dstActuationConnection_end_ = IODevice::meta_srcActuationConnection_rev = OChan::meta_dstActuationConnection;
		ActuationConnection::meta_srcActuationConnection_end_ = OChan::meta_dstActuationConnection_rev = IODevice::meta_srcActuationConnection;

		Block::meta_Annotation_children.target() = Annotation::meta;

		AperiodicExecInfo::meta.subTypes() += SporadicExecInfo::meta;

		SystemTypes::meta_ArchitectureLibrary_parent.target() = ArchitectureLibrary::meta;
		RootFolder::meta_ArchitectureLibrary_children.target() = ArchitectureLibrary::meta;

		Network::meta_BChan_children.target() = BChan::meta;

		Module::meta_BIPConnector_children.target() = BIPConnector::meta;
		BIPConnector::meta.association() = PNPort::meta_dstPortToPort.parent();
		BIPConnector::meta_dstPortToPort_end_ = PNPort::meta_srcPortToPort_rev = PNPort::meta_dstPortToPort;
		BIPConnector::meta_srcPortToPort_end_ = PNPort::meta_dstPortToPort_rev = PNPort::meta_srcPortToPort;

		Parameter::meta_Parameter_Block_parent.target() = Block::meta;
		Line::meta_Line_Block_parent.target() = Block::meta;
		Annotation::meta_Block_parent.target() = Block::meta;
		ConnectorRef::meta_Block_parent.target() = Block::meta;
		Port::meta_Block_parent.target() = Block::meta;
		Subsystem::meta_Block_children.target() = Block::meta;
		Block::meta.subTypes() += Primitive::meta;
		Block::meta.subTypes() += Reference::meta;
		Block::meta.subTypes() += Subsystem::meta;

		Bus::meta.subTypes() += TTBus::meta;
		Bus::meta.subTypes() += OldBus::meta;
		Bus::meta.subTypes() += CANBus::meta;
		Bus::meta.subTypes() += Link::meta;

		CANMessage::meta.subTypes() += AutoCANMessage::meta;

		COutputPort::meta_CCode_parent.target() = CCode::meta;
		CInputPort::meta_CCode_parent.target() = CCode::meta;

		CCode::meta_CInputPort_children.target() = CInputPort::meta;

		CCode::meta_COutputPort_children.target() = COutputPort::meta;

		HardwareUnit::meta_Channel_children.target() = Channel::meta;
		IODevice::meta_Channel_children.target() = Channel::meta;
		Node::meta_Channel_children.target() = Channel::meta;
		Channel::meta.subTypes() += IChan::meta;
		Channel::meta.subTypes() += OChan::meta;
		Channel::meta.subTypes() += BChan::meta;

		CommMapping::meta_srcCommMapping__rp_helper.target() = CommMapping_srcCommMapping_RPContainer_Base::meta;
		CommMapping::meta_dstCommMapping__rp_helper.target() = CommMapping_dstCommMapping_RPContainer_Base::meta;
		System::meta_CommMapping_children.target() = CommMapping::meta;
		CommMapping::meta.association() = CommMapping_Members_Base::meta_dstCommMapping.parent();
		CommMapping::meta_dstCommMapping_end_ = CommMapping_Members_Base::meta_srcCommMapping_rev = CommMapping_Members_Base::meta_dstCommMapping;
		CommMapping::meta_dstCommMapping_end_.rp_helper() = CommMapping::meta_dstCommMapping__rp_helper;
		CommMapping::meta_srcCommMapping_end_ = CommMapping_Members_Base::meta_dstCommMapping_rev = CommMapping_Members_Base::meta_srcCommMapping;
		CommMapping::meta_srcCommMapping_end_.rp_helper() = CommMapping::meta_srcCommMapping__rp_helper;

		CommMapping_Members_Base::meta_dstCommMapping.target() = CommMapping_Members_Base::meta;
		CommMapping_Members_Base::meta_srcCommMapping.target() = CommMapping_Members_Base::meta;
		CommMapping_Members_Base::meta.subTypes() += MessageRef::meta;
		CommMapping_Members_Base::meta.subTypes() += Channel::meta;

		CommMapping_dstCommMapping_RPContainer_Base::meta_dstCommMapping__rp_helper_rev.target() = CommMapping::meta;
		CommMapping_dstCommMapping_RPContainer_Base::meta.subTypes() += NodeRef::meta;
		CommMapping_dstCommMapping_RPContainer_Base::meta.subTypes() += ComponentRef::meta;

		CommMapping_srcCommMapping_RPContainer_Base::meta_srcCommMapping__rp_helper_rev.target() = CommMapping::meta;
		CommMapping_srcCommMapping_RPContainer_Base::meta.subTypes() += NodeRef::meta;
		CommMapping_srcCommMapping_RPContainer_Base::meta.subTypes() += ComponentRef::meta;

		FaultScenario::meta_CompBreakout_children.target() = CompBreakout::meta;
		CompBreakout::meta.association() = ComponentBase::meta_dstCompBreakout.parent();
		CompBreakout::meta_dstCompBreakout_end_ = TaskInst::meta_srcCompBreakout_rev = ComponentBase::meta_dstCompBreakout;
		CompBreakout::meta_srcCompBreakout_end_ = ComponentBase::meta_dstCompBreakout_rev = TaskInst::meta_srcCompBreakout;

		Component::meta_referedbyTaskRef.target() = TaskRef::meta;
		Trigger::meta_Component_parent.target() = Component::meta;
		MessageRef::meta_Component_parent.target() = Component::meta;
		ComponentBase::meta_Component_parent.target() = Component::meta;
		Connector::meta_Component_parent.target() = Component::meta;
		SystemTypes::meta_Component_children.target() = Component::meta;
		Component::meta.subTypes() += PlantComponent::meta;

		System::meta_ComponentAssignment_children.target() = ComponentAssignment::meta;
		ComponentAssignment::meta.association() = ComponentRef::meta_dstComponentAssignment.parent();
		ComponentAssignment::meta_dstComponentAssignment_end_ = NodeRef::meta_srcComponentAssignment_rev = ComponentRef::meta_dstComponentAssignment;
		ComponentAssignment::meta_srcComponentAssignment_end_ = ComponentRef::meta_dstComponentAssignment_rev = NodeRef::meta_srcComponentAssignment;

		ComponentBase::meta_dstCompBreakout.target() = TaskInst::meta;
		FaultScenario::meta_ComponentBase_children.target() = ComponentBase::meta;
		Component::meta_ComponentBase_children.target() = ComponentBase::meta;
		ComponentBase::meta.subTypes() += PetriNet::meta;
		ComponentBase::meta.subTypes() += CCode::meta;
		ComponentBase::meta.subTypes() += SubsystemRef::meta;
		ComponentBase::meta.subTypes() += PetriNetRef::meta;
		ComponentBase::meta.subTypes() += Subsystem::meta;

		ComponentRef::meta_referedbyTaskInst.target() = TaskInst::meta;
		ComponentRef::meta_referedbyAction.target() = Action::meta;
		ComponentRef::meta_referedbyFaultMgrTask.target() = FaultMgrTask::meta;
		ComponentRef::meta_srcDependency__rp_helper_rev.target() = Dependency::meta;
		ComponentRef::meta_dstDependency__rp_helper_rev.target() = Dependency::meta;
		ComponentRef::meta_dstComponentAssignment.target() = NodeRef::meta;
		ComponentRef::meta_ref.target() = ComponentRef_RefersTo_Base::meta;
		System::meta_ComponentRef_children.target() = ComponentRef::meta;
		ComponentRef::meta.subTypes() += PlantComponentRef::meta;

		ComponentRef_RefersTo_Base::meta_referedbyComponentRef.target() = ComponentRef::meta;
		ComponentRef_RefersTo_Base::meta.subTypes() += Component::meta;
		ComponentRef_RefersTo_Base::meta.subTypes() += ComponentRef::meta;

		Connectable::meta_dstWire.target() = Connectable::meta;
		Connectable::meta_srcWire.target() = Connectable::meta;
		Connectable::meta.subTypes() += Bus::meta;
		Connectable::meta.subTypes() += Channel::meta;

		Connector::meta_dstConnector__rp_helper.target() = Connector_dstConnector_RPContainer_Base::meta;
		Connector::meta_srcConnector__rp_helper.target() = Connector_srcConnector_RPContainer_Base::meta;
		Component::meta_Connector_children.target() = Connector::meta;
		Connector::meta.association() = Output::meta_dstConnector.parent();
		Connector::meta_dstConnector_end_ = Input::meta_srcConnector_rev = Output::meta_dstConnector;
		Connector::meta_dstConnector_end_.rp_helper() = Connector::meta_dstConnector__rp_helper;
		Connector::meta_srcConnector_end_ = Output::meta_dstConnector_rev = Input::meta_srcConnector;
		Connector::meta_srcConnector_end_.rp_helper() = Connector::meta_srcConnector__rp_helper;

		ConnectorRef::meta_ref.target() = TransConnector::meta;
		Block::meta_ConnectorRef_children.target() = ConnectorRef::meta;

		Connector_dstConnector_RPContainer_Base::meta_dstConnector__rp_helper_rev.target() = Connector::meta;
		Connector_dstConnector_RPContainer_Base::meta.subTypes() += SubsystemRef::meta;
		Connector_dstConnector_RPContainer_Base::meta.subTypes() += PetriNetRef::meta;
		Connector_dstConnector_RPContainer_Base::meta.subTypes() += MessageRef::meta;

		Connector_srcConnector_RPContainer_Base::meta_srcConnector__rp_helper_rev.target() = Connector::meta;
		Connector_srcConnector_RPContainer_Base::meta.subTypes() += SubsystemRef::meta;
		Connector_srcConnector_RPContainer_Base::meta.subTypes() += PetriNetRef::meta;
		Connector_srcConnector_RPContainer_Base::meta.subTypes() += MessageRef::meta;

		Subsystem::meta_Dataflow_parent.target() = Dataflow::meta;
		ModelsFolder::meta_Dataflow_children.target() = Dataflow::meta;

		Dependency::meta_srcDependency__rp_helper.target() = ComponentRef::meta;
		Dependency::meta_dstDependency__rp_helper.target() = ComponentRef::meta;
		System::meta_Dependency_children.target() = Dependency::meta;
		Dependency::meta.association() = MessageRef::meta_dstDependency.parent();
		Dependency::meta_dstDependency_end_ = MessageRef::meta_srcDependency_rev = MessageRef::meta_dstDependency;
		Dependency::meta_dstDependency_end_.rp_helper() = Dependency::meta_dstDependency__rp_helper;
		Dependency::meta_srcDependency_end_ = MessageRef::meta_dstDependency_rev = MessageRef::meta_srcDependency;
		Dependency::meta_srcDependency_end_.rp_helper() = Dependency::meta_srcDependency__rp_helper;

		System::meta_DeploymentLibrary_parent.target() = DeploymentLibrary::meta;
		RootFolder::meta_DeploymentLibrary_children.target() = DeploymentLibrary::meta;

		SystemTypes::meta_DesignFolder_parent.target() = DesignFolder::meta;
		FaultModel::meta_DesignFolder_parent.target() = DesignFolder::meta;
		FaultModelFolder::meta_DesignFolder_parent.target() = DesignFolder::meta;
		HardwareUnit::meta_DesignFolder_parent.target() = DesignFolder::meta;
		TimingSheet::meta_DesignFolder_parent.target() = DesignFolder::meta;
		System::meta_DesignFolder_parent.target() = DesignFolder::meta;
		ModelsFolder::meta_DesignFolder_parent.target() = DesignFolder::meta;
		FaultScenario::meta_DesignFolder_parent.target() = DesignFolder::meta;
		RootFolder::meta_DesignFolder_children.target() = DesignFolder::meta;

		DesignReference::meta_ref.target() = System::meta;
		FaultScenario::meta_DesignReference_children.target() = DesignReference::meta;

		Executable::meta_srcExecutionAssignment.target() = ExecutionInfo::meta;
		Executable::meta.subTypes() += MessageRef::meta;
		Executable::meta.subTypes() += Channel::meta;
		Executable::meta.subTypes() += ComponentRef::meta;

		ExecutionAssignment::meta_dstExecutionAssignment__rp_helper.target() = ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta;
		System::meta_ExecutionAssignment_children.target() = ExecutionAssignment::meta;
		ExecutionAssignment::meta.association() = ExecutionInfo::meta_dstExecutionAssignment.parent();
		ExecutionAssignment::meta_dstExecutionAssignment_end_ = Executable::meta_srcExecutionAssignment_rev = ExecutionInfo::meta_dstExecutionAssignment;
		ExecutionAssignment::meta_dstExecutionAssignment_end_.rp_helper() = ExecutionAssignment::meta_dstExecutionAssignment__rp_helper;
		ExecutionAssignment::meta_srcExecutionAssignment_end_ = ExecutionInfo::meta_dstExecutionAssignment_rev = Executable::meta_srcExecutionAssignment;

		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta_dstExecutionAssignment__rp_helper_rev.target() = ExecutionAssignment::meta;
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta.subTypes() += NodeRef::meta;
		ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta.subTypes() += ComponentRef::meta;

		HWElement::meta_ExecutionContext_children.target() = ExecutionContext::meta;
		ExecutionContext::meta.subTypes() += TTExecContext::meta;

		ExecutionInfo::meta_dstExecutionAssignment.target() = Executable::meta;
		System::meta_ExecutionInfo_children.target() = ExecutionInfo::meta;
		ExecutionInfo::meta.subTypes() += PeriodicExecInfo::meta;
		ExecutionInfo::meta.subTypes() += AperiodicExecInfo::meta;

		FaultScenario::meta_FaultCondition_children.target() = FaultCondition::meta;
		FaultCondition::meta.subTypes() += ConditionEvent::meta;
		FaultCondition::meta.subTypes() += Precondition::meta;
		FaultCondition::meta.subTypes() += Postcondition::meta;
		FaultCondition::meta.subTypes() += DetectionCondition::meta;
		FaultCondition::meta.subTypes() += MitigationCondition::meta;

		FaultEvent::meta_referedbyFaultTrigger.target() = FaultTrigger::meta;
		FaultEvent::meta.subTypes() += ConditionEvent::meta;
		FaultEvent::meta.subTypes() += PNPort::meta;

		FaultMgrTask::meta_ref.target() = ComponentRef::meta;
		FaultScenario::meta_FaultMgrTask_children.target() = FaultMgrTask::meta;

		FaultModel::meta_referedbyFaultModelRef.target() = FaultModelRef::meta;
		Variable::meta_FaultModel_parent.target() = FaultModel::meta;
		FaultScenario::meta_FaultModel_children.target() = FaultModel::meta;
		FaultModelFolder::meta_FaultModel_children.target() = FaultModel::meta;
		DesignFolder::meta_FaultModel_children.target() = FaultModel::meta;

		FaultModel::meta_FaultModelFolder_parent.target() = FaultModelFolder::meta;
		DesignFolder::meta_FaultModelFolder_children.target() = FaultModelFolder::meta;

		FaultModelRef::meta_ref.target() = FaultModel::meta;
		FaultScenario::meta_FaultModelRef_children.target() = FaultModelRef::meta;

		ScenarioInfo::meta_FaultScenario_parent.target() = FaultScenario::meta;
		FaultTrigger::meta_FaultScenario_parent.target() = FaultScenario::meta;
		FaultCondition::meta_FaultScenario_parent.target() = FaultScenario::meta;
		TaskInst::meta_FaultScenario_parent.target() = FaultScenario::meta;
		Action::meta_FaultScenario_parent.target() = FaultScenario::meta;
		FaultMgrTask::meta_FaultScenario_parent.target() = FaultScenario::meta;
		ComponentBase::meta_FaultScenario_parent.target() = FaultScenario::meta;
		CompBreakout::meta_FaultScenario_parent.target() = FaultScenario::meta;
		FaultModel::meta_FaultScenario_parent.target() = FaultScenario::meta;
		DesignReference::meta_FaultScenario_parent.target() = FaultScenario::meta;
		FaultToInput::meta_FaultScenario_parent.target() = FaultScenario::meta;
		OutputToFault::meta_FaultScenario_parent.target() = FaultScenario::meta;
		FaultModelRef::meta_FaultScenario_parent.target() = FaultScenario::meta;
		DesignFolder::meta_FaultScenario_children.target() = FaultScenario::meta;

		FaultScenario::meta_FaultToInput_children.target() = FaultToInput::meta;
		FaultToInput::meta.association() = FaultToInput_Members_Base::meta_dstFaultToInput.parent();
		FaultToInput::meta_dstFaultToInput_end_ = FaultToInput_Members_Base::meta_srcFaultToInput_rev = FaultToInput_Members_Base::meta_dstFaultToInput;
		FaultToInput::meta_srcFaultToInput_end_ = FaultToInput_Members_Base::meta_dstFaultToInput_rev = FaultToInput_Members_Base::meta_srcFaultToInput;

		FaultToInput_Members_Base::meta_dstFaultToInput.target() = FaultToInput_Members_Base::meta;
		FaultToInput_Members_Base::meta_srcFaultToInput.target() = FaultToInput_Members_Base::meta;
		FaultToInput_Members_Base::meta.subTypes() += Variable::meta;
		FaultToInput_Members_Base::meta.subTypes() += Input::meta;

		FaultTrigger::meta_ref.target() = FaultEvent::meta;
		FaultScenario::meta_FaultTrigger_children.target() = FaultTrigger::meta;

		MsgPort::meta_FieldDataType_children.target() = FieldDataType::meta;
		FieldDataType::meta.subTypes() += BitField::meta;
		FieldDataType::meta.subTypes() += ValueType::meta;

		Functions::meta.subTypes() += Step::meta;
		Functions::meta.subTypes() += Pulse::meta;
		Functions::meta.subTypes() += Sinusoid::meta;

		ExecutionContext::meta_HWElement_parent.target() = HWElement::meta;
		HardwareUnit::meta_HWElement_children.target() = HWElement::meta;
		HWElement::meta.subTypes() += HardwareUnit::meta;
		HWElement::meta.subTypes() += Network::meta;
		HWElement::meta.subTypes() += Bus::meta;
		HWElement::meta.subTypes() += IODevice::meta;
		HWElement::meta.subTypes() += Node::meta;

		Wire::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		HWElement::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		Channel::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		Plant::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		PhysConnection::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		AcquisitionConnection::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		ActuationConnection::meta_HardwareUnit_parent.target() = HardwareUnit::meta;
		DesignFolder::meta_HardwareUnit_children.target() = HardwareUnit::meta;
		PlatformLibrary::meta_HardwareUnit_children.target() = HardwareUnit::meta;

		HasRefId::meta.subTypes() += Block::meta;
		HasRefId::meta.subTypes() += Parameter::meta;
		HasRefId::meta.subTypes() += Line::meta;
		HasRefId::meta.subTypes() += Port::meta;
		HasRefId::meta.subTypes() += Transition::meta;
		HasRefId::meta.subTypes() += TransConnector::meta;
		HasRefId::meta.subTypes() += StateDE::meta;

		History::meta.subTypes() += ShallowHistory::meta;
		History::meta.subTypes() += DeepHistory::meta;

		IChan::meta_srcAcquisitionConnection.target() = IODevice::meta;

		IODevice::meta_srcActuationConnection.target() = OChan::meta;
		IODevice::meta_dstAcquisitionConnection.target() = IChan::meta;
		Channel::meta_IODevice_parent.target() = IODevice::meta;

		IOPortAssignment::meta.association() = IOPortInfoBase::meta_dstIOPortAssignment.parent();
		IOPortAssignment::meta_dstIOPortAssignment_end_ = IOPortExp::meta_srcIOPortAssignment_rev = IOPortInfoBase::meta_dstIOPortAssignment;
		IOPortAssignment::meta_srcIOPortAssignment_end_ = IOPortInfoBase::meta_dstIOPortAssignment_rev = IOPortExp::meta_srcIOPortAssignment;

		IOPortExp::meta_srcIOPortAssignment.target() = IOPortInfoBase::meta;
		IOPortExp::meta.subTypes() += Output::meta;
		IOPortExp::meta.subTypes() += Input::meta;

		IOPortInfo::meta_referedbyIOPortInfoRef.target() = IOPortInfoRef::meta;

		IOPortInfoBase::meta_dstIOPortAssignment.target() = IOPortExp::meta;
		IOPortInfoBase::meta.subTypes() += IOPortInfo::meta;
		IOPortInfoBase::meta.subTypes() += IOPortInfoRef::meta;

		IOPortInfoRef::meta_ref.target() = IOPortInfo::meta;

		InPort::meta.subTypes() += EnablePort::meta;
		InPort::meta.subTypes() += TriggerPort::meta;
		InPort::meta.subTypes() += InputPort::meta;
		InPort::meta.subTypes() += ActionPort::meta;

		Variable::meta_Incorporation_children.target() = Incorporation::meta;
		Incorporation::meta.subTypes() += Additive::meta;
		Incorporation::meta.subTypes() += Substitutive::meta;
		Incorporation::meta.subTypes() += Multiplicative::meta;

		Input::meta_srcConnector.target() = Output::meta;
		Input::meta.subTypes() += PNVariable::meta;
		Input::meta.subTypes() += CInputPort::meta;
		Input::meta.subTypes() += MsgPort::meta;
		Input::meta.subTypes() += MessageRef::meta;
		Input::meta.subTypes() += InputPort::meta;

		InputEvent::meta_srcTrigger.target() = OutputEvent::meta;
		InputEvent::meta.subTypes() += PNPort::meta;
		InputEvent::meta.subTypes() += MessageRef::meta;

		Block::meta_Line.target() = Line::meta;
		Line::meta.association() = Port::meta_dstLine.parent();
		Line::meta_dstLine_end_ = Port::meta_srcLine_rev = Port::meta_dstLine;
		Line::meta_srcLine_end_ = Port::meta_dstLine_rev = Port::meta_srcLine;

		Link::meta.subTypes() += SerialLink::meta;

		MsgPort::meta_Message_parent.target() = Message::meta;
		SystemTypes::meta_Message_children.target() = Message::meta;
		Message::meta.subTypes() += CANMessage::meta;

		MessageRef::meta_ref.target() = MessageRef_RefersTo_Base::meta;
		MessageRef::meta_dstDependency.target() = MessageRef::meta;
		MessageRef::meta_srcDependency.target() = MessageRef::meta;
		Component::meta_MessageRef_children.target() = MessageRef::meta;

		MessageRef_RefersTo_Base::meta_referedbyBusMessageRef.target() = MessageRef::meta;
		MessageRef_RefersTo_Base::meta.subTypes() += Message::meta;
		MessageRef_RefersTo_Base::meta.subTypes() += MessageRef::meta;

		MgaObject::meta.subTypes() += FaultScenario::meta;
		MgaObject::meta.subTypes() += ScenarioInfo::meta;
		MgaObject::meta.subTypes() += FaultEvent::meta;
		MgaObject::meta.subTypes() += FaultTrigger::meta;
		MgaObject::meta.subTypes() += FaultCondition::meta;
		MgaObject::meta.subTypes() += TaskInst::meta;
		MgaObject::meta.subTypes() += Action::meta;
		MgaObject::meta.subTypes() += FaultMgrTask::meta;
		MgaObject::meta.subTypes() += CompBreakout::meta;
		MgaObject::meta.subTypes() += DesignReference::meta;
		MgaObject::meta.subTypes() += FaultToInput::meta;
		MgaObject::meta.subTypes() += OutputToFault::meta;
		MgaObject::meta.subTypes() += FaultModelRef::meta;
		MgaObject::meta.subTypes() += FaultModel::meta;
		MgaObject::meta.subTypes() += Incorporation::meta;
		MgaObject::meta.subTypes() += Occurrence::meta;
		MgaObject::meta.subTypes() += Variable::meta;
		MgaObject::meta.subTypes() += Interval::meta;
		MgaObject::meta.subTypes() += ValueObject::meta;
		MgaObject::meta.subTypes() += TransitionToState::meta;
		MgaObject::meta.subTypes() += StateToTransition::meta;
		MgaObject::meta.subTypes() += PNTransition::meta;
		MgaObject::meta.subTypes() += PNState::meta;
		MgaObject::meta.subTypes() += BIPConnector::meta;
		MgaObject::meta.subTypes() += PNVarRef::meta;
		MgaObject::meta.subTypes() += Module::meta;
		MgaObject::meta.subTypes() += ModelInfo::meta;
		MgaObject::meta.subTypes() += ExecutionInfo::meta;
		MgaObject::meta.subTypes() += ExecutionContext::meta;
		MgaObject::meta.subTypes() += ExecutionAssignment::meta;
		MgaObject::meta.subTypes() += Executable::meta;
		MgaObject::meta.subTypes() += FieldDataType::meta;
		MgaObject::meta.subTypes() += IOPortExp::meta;
		MgaObject::meta.subTypes() += IOPortAssignment::meta;
		MgaObject::meta.subTypes() += IOPortInfoBase::meta;
		MgaObject::meta.subTypes() += OldTask::meta;
		MgaObject::meta.subTypes() += SystemTypes::meta;
		MgaObject::meta.subTypes() += Connector::meta;
		MgaObject::meta.subTypes() += ComponentBase::meta;
		MgaObject::meta.subTypes() += Message::meta;
		MgaObject::meta.subTypes() += OutputEvent::meta;
		MgaObject::meta.subTypes() += InputEvent::meta;
		MgaObject::meta.subTypes() += Trigger::meta;
		MgaObject::meta.subTypes() += Component::meta;
		MgaObject::meta.subTypes() += TimingConstraint::meta;
		MgaObject::meta.subTypes() += TimingSheet::meta;
		MgaObject::meta.subTypes() += TaskRef::meta;
		MgaObject::meta.subTypes() += TypeBase::meta;
		MgaObject::meta.subTypes() += TypeBaseRef::meta;
		MgaObject::meta.subTypes() += Annotation::meta;
		MgaObject::meta.subTypes() += HasRefId::meta;
		MgaObject::meta.subTypes() += OS::meta;
		MgaObject::meta.subTypes() += Wire::meta;
		MgaObject::meta.subTypes() += Connectable::meta;
		MgaObject::meta.subTypes() += HWElement::meta;
		MgaObject::meta.subTypes() += PhysConnection::meta;
		MgaObject::meta.subTypes() += AcquisitionConnection::meta;
		MgaObject::meta.subTypes() += ActuationConnection::meta;
		MgaObject::meta.subTypes() += PhysInterface::meta;
		MgaObject::meta.subTypes() += System::meta;
		MgaObject::meta.subTypes() += NodeRef::meta;
		MgaObject::meta.subTypes() += CommMapping::meta;
		MgaObject::meta.subTypes() += Dependency::meta;
		MgaObject::meta.subTypes() += ComponentAssignment::meta;

		ModelsFolder::meta_ModelInfo_children.target() = ModelInfo::meta;

		Dataflow::meta_ModelsFolder_parent.target() = ModelsFolder::meta;
		Stateflow::meta_ModelsFolder_parent.target() = ModelsFolder::meta;
		ModelInfo::meta_ModelsFolder_parent.target() = ModelsFolder::meta;
		Module::meta_ModelsFolder_parent.target() = ModelsFolder::meta;
		DesignFolder::meta_ModelsFolder_children.target() = ModelsFolder::meta;

		BIPConnector::meta_Module_parent.target() = Module::meta;
		PetriNet::meta_Module_parent.target() = Module::meta;
		ModelsFolder::meta_Module_children.target() = Module::meta;

		FieldDataType::meta_MsgPort_parent.target() = MsgPort::meta;
		Message::meta_MsgPort_children.target() = MsgPort::meta;
		MsgPort::meta.subTypes() += AutoCANParam::meta;

		BChan::meta_Network_parent.target() = Network::meta;

		Node::meta_referedbyNodeRef.target() = NodeRef::meta;
		OS::meta_Node_parent.target() = Node::meta;
		Channel::meta_Node_parent.target() = Node::meta;

		NodeRef::meta_ref.target() = Node::meta;
		NodeRef::meta_srcComponentAssignment.target() = ComponentRef::meta;
		System::meta_NodeRef_children.target() = NodeRef::meta;

		OChan::meta_dstActuationConnection.target() = IODevice::meta;

		Node::meta_OS_child.target() = OS::meta;

		Variable::meta_Occurrence_children.target() = Occurrence::meta;
		Occurrence::meta.subTypes() += Continuous::meta;
		Occurrence::meta.subTypes() += Periodic::meta;
		Occurrence::meta.subTypes() += Intermittent::meta;

		OutPort::meta.subTypes() += OutputPort::meta;
		OutPort::meta.subTypes() += StatePort::meta;

		Output::meta_dstConnector.target() = Input::meta;
		Output::meta.subTypes() += PNVariable::meta;
		Output::meta.subTypes() += COutputPort::meta;
		Output::meta.subTypes() += MsgPort::meta;
		Output::meta.subTypes() += MessageRef::meta;
		Output::meta.subTypes() += OutputPort::meta;

		OutputEvent::meta_dstTrigger.target() = InputEvent::meta;
		OutputEvent::meta.subTypes() += PNPort::meta;
		OutputEvent::meta.subTypes() += MessageRef::meta;

		FaultScenario::meta_OutputToFault_children.target() = OutputToFault::meta;
		OutputToFault::meta.association() = OutputToFault_Members_Base::meta_dstOutputToFault.parent();
		OutputToFault::meta_dstOutputToFault_end_ = OutputToFault_Members_Base::meta_srcOutputToFault_rev = OutputToFault_Members_Base::meta_dstOutputToFault;
		OutputToFault::meta_srcOutputToFault_end_ = OutputToFault_Members_Base::meta_dstOutputToFault_rev = OutputToFault_Members_Base::meta_srcOutputToFault;

		OutputToFault_Members_Base::meta_dstOutputToFault.target() = OutputToFault_Members_Base::meta;
		OutputToFault_Members_Base::meta_srcOutputToFault.target() = OutputToFault_Members_Base::meta;
		OutputToFault_Members_Base::meta.subTypes() += Variable::meta;
		OutputToFault_Members_Base::meta.subTypes() += Output::meta;

		PNPort::meta_dstPortToPort.target() = PNPort::meta;
		PNPort::meta_srcPortToPort.target() = PNPort::meta;
		PNVarRef::meta_PNPort_parent.target() = PNPort::meta;
		PetriNet::meta_PNPort_children.target() = PNPort::meta;

		PNState::meta_srcTransitionToState.target() = PNTransition::meta;
		PNState::meta_dstStateToTransition.target() = PNTransition::meta;
		PetriNet::meta_PNState_children.target() = PNState::meta;

		PNTransition::meta_dstTransitionToState.target() = PNState::meta;
		PNTransition::meta_srcStateToTransition.target() = PNState::meta;
		PetriNet::meta_PNTransition_children.target() = PNTransition::meta;

		PNVarRef::meta_ref.target() = PNVariable::meta;
		PNPort::meta_PNVarRef_children.target() = PNVarRef::meta;

		PNVariable::meta_referedbyPNVarRef.target() = PNVarRef::meta;
		PetriNet::meta_PNVariable_children.target() = PNVariable::meta;

		Parameter::meta_arg = ::ESM2SLC::Parameter_cross_ph_ESMoL::meta_arg;
		Parameter::meta_memb = ::ESM2SLC::Parameter_cross_ph_ESMoL::meta_memb;
		Block::meta_Parameter.target() = Parameter::meta;

		PeriodicExecInfo::meta.subTypes() += TTExecInfo::meta;
		PeriodicExecInfo::meta.subTypes() += AsyncPeriodicExecInfo::meta;

		PetriNet::meta_referedbyPetriNetRef.target() = PetriNetRef::meta;
		StateToTransition::meta_PetriNet_parent.target() = PetriNet::meta;
		PNTransition::meta_PetriNet_parent.target() = PetriNet::meta;
		TransitionToState::meta_PetriNet_parent.target() = PetriNet::meta;
		PNState::meta_PetriNet_parent.target() = PetriNet::meta;
		PNVariable::meta_PetriNet_parent.target() = PetriNet::meta;
		PNPort::meta_PetriNet_parent.target() = PetriNet::meta;
		Module::meta_PetriNet_children.target() = PetriNet::meta;

		PetriNetRef::meta_ref.target() = PetriNet::meta;

		HardwareUnit::meta_PhysConnection_children.target() = PhysConnection::meta;
		PhysConnection::meta.association() = PhysInterface::meta_dstPhysConnection.parent();
		PhysConnection::meta_dstPhysConnection_end_ = PhysInterface::meta_srcPhysConnection_rev = PhysInterface::meta_dstPhysConnection;
		PhysConnection::meta_srcPhysConnection_end_ = PhysInterface::meta_dstPhysConnection_rev = PhysInterface::meta_srcPhysConnection;

		PhysInterface::meta_dstPhysConnection.target() = PhysInterface::meta;
		PhysInterface::meta_srcPhysConnection.target() = PhysInterface::meta;
		PhysInterface::meta.subTypes() += Plant::meta;
		PhysInterface::meta.subTypes() += IODevice::meta;

		HardwareUnit::meta_Plant_children.target() = Plant::meta;

		HardwareUnit::meta_PlatformLibrary_parent.target() = PlatformLibrary::meta;
		RootFolder::meta_PlatformLibrary_children.target() = PlatformLibrary::meta;

		Port::meta_dstLine.target() = Port::meta;
		Port::meta_srcLine.target() = Port::meta;
		Port::meta_arg = ::ESM2SLC::Port_cross_ph_ESMoL::meta_arg;
		Port::meta_argdecl = ::ESM2SLC::Port_cross_ph_ESMoL::meta_argdecl;
		TypeBaseRef::meta_Port_parent.target() = Port::meta;
		Block::meta_Port_children.target() = Port::meta;
		Port::meta.subTypes() += OutPort::meta;
		Port::meta.subTypes() += InPort::meta;

		Primitive::meta_ifval = ::ESM2SLC::Primitive_cross_ph_ESMoL::meta_ifval;

		RandomDistribution::meta.subTypes() += Uniform::meta;
		RandomDistribution::meta.subTypes() += Normal::meta;
		RandomDistribution::meta.subTypes() += Exponential::meta;

		TimingSheet::meta_RequirementsLibrary_parent.target() = RequirementsLibrary::meta;
		RootFolder::meta_RequirementsLibrary_children.target() = RequirementsLibrary::meta;

		ArchitectureLibrary::meta_RootFolder_parent.target() = RootFolder::meta;
		DesignFolder::meta_RootFolder_parent.target() = RootFolder::meta;
		RequirementsLibrary::meta_RootFolder_parent.target() = RootFolder::meta;
		Types::meta_RootFolder_parent.target() = RootFolder::meta;
		PlatformLibrary::meta_RootFolder_parent.target() = RootFolder::meta;
		DeploymentLibrary::meta_RootFolder_parent.target() = RootFolder::meta;
		RootFolder::meta_RootFolder_parent.target() = RootFolder::meta;
		RootFolder::meta_RootFolder_children.target() = RootFolder::meta;

		FaultScenario::meta_ScenarioInfo_children.target() = ScenarioInfo::meta;

		Transition::meta_Transition_State_parent.target() = State::meta;
		TransConnector::meta_State_parent.target() = State::meta;
		StateDE::meta_State_parent.target() = State::meta;
		Stateflow::meta_State_children.target() = State::meta;

		TypeBaseRef::meta_StateDE_parent.target() = StateDE::meta;
		State::meta_StateDE_children.target() = StateDE::meta;
		StateDE::meta.subTypes() += Data::meta;
		StateDE::meta.subTypes() += Event::meta;

		PetriNet::meta_StateToTransition_children.target() = StateToTransition::meta;
		StateToTransition::meta.association() = PNState::meta_dstStateToTransition.parent();
		StateToTransition::meta_dstStateToTransition_end_ = PNTransition::meta_srcStateToTransition_rev = PNState::meta_dstStateToTransition;
		StateToTransition::meta_srcStateToTransition_end_ = PNState::meta_dstStateToTransition_rev = PNTransition::meta_srcStateToTransition;

		State::meta_Stateflow_parent.target() = Stateflow::meta;
		ModelsFolder::meta_Stateflow_children.target() = Stateflow::meta;

		Subsystem::meta_referedbySubsystemRef.target() = SubsystemRef::meta;
		Subsystem::meta_init = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_init;
		Subsystem::meta_main = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_main;
		Subsystem::meta_memb = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_memb;
		Subsystem::meta_mcall = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_mcall;
		Subsystem::meta_cls = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_cls;
		Block::meta_Subsystem_parent.target() = Subsystem::meta;
		Dataflow::meta_Subsystem_children.target() = Subsystem::meta;

		SubsystemRef::meta_ref.target() = Subsystem::meta;

		System::meta_referedbyDesignReference.target() = DesignReference::meta;
		ComponentRef::meta_System_parent.target() = System::meta;
		NodeRef::meta_System_parent.target() = System::meta;
		CommMapping::meta_System_parent.target() = System::meta;
		Dependency::meta_System_parent.target() = System::meta;
		ComponentAssignment::meta_System_parent.target() = System::meta;
		ExecutionInfo::meta_System_parent.target() = System::meta;
		ExecutionAssignment::meta_System_parent.target() = System::meta;
		DesignFolder::meta_System_children.target() = System::meta;
		DeploymentLibrary::meta_System_children.target() = System::meta;

		Message::meta_SystemTypes_parent.target() = SystemTypes::meta;
		Component::meta_SystemTypes_parent.target() = SystemTypes::meta;
		ArchitectureLibrary::meta_SystemTypes_children.target() = SystemTypes::meta;
		DesignFolder::meta_SystemTypes_children.target() = SystemTypes::meta;

		TaskInst::meta_ref.target() = ComponentRef::meta;
		TaskInst::meta_srcCompBreakout.target() = ComponentBase::meta;
		FaultScenario::meta_TaskInst_children.target() = TaskInst::meta;

		TaskRef::meta_dstTimingConstraint.target() = TaskRef::meta;
		TaskRef::meta_srcTimingConstraint.target() = TaskRef::meta;
		TaskRef::meta_ref.target() = Component::meta;
		TimingSheet::meta_TaskRef_children.target() = TaskRef::meta;

		TimingSheet::meta_TimingConstraint_children.target() = TimingConstraint::meta;
		TimingConstraint::meta.association() = TaskRef::meta_dstTimingConstraint.parent();
		TimingConstraint::meta_dstTimingConstraint_end_ = TaskRef::meta_srcTimingConstraint_rev = TaskRef::meta_dstTimingConstraint;
		TimingConstraint::meta_srcTimingConstraint_end_ = TaskRef::meta_dstTimingConstraint_rev = TaskRef::meta_srcTimingConstraint;

		TaskRef::meta_TimingSheet_parent.target() = TimingSheet::meta;
		TimingConstraint::meta_TimingSheet_parent.target() = TimingSheet::meta;
		DesignFolder::meta_TimingSheet_children.target() = TimingSheet::meta;
		RequirementsLibrary::meta_TimingSheet_children.target() = TimingSheet::meta;

		TransConnector::meta_referedbyConnectorRef.target() = ConnectorRef::meta;
		TransConnector::meta_dstTransition.target() = TransConnector::meta;
		TransConnector::meta_srcTransition.target() = TransConnector::meta;
		State::meta_TransConnector_children.target() = TransConnector::meta;
		TransConnector::meta.subTypes() += State::meta;
		TransConnector::meta.subTypes() += History::meta;
		TransConnector::meta.subTypes() += TransStart::meta;
		TransConnector::meta.subTypes() += Junction::meta;
		TransConnector::meta.subTypes() += ConnectorRef::meta;
		TransConnector::meta.subTypes() += Conditional::meta;
		TransConnector::meta.subTypes() += Join::meta;
		TransConnector::meta.subTypes() += Fork::meta;
		TransConnector::meta.subTypes() += Choice::meta;
		TransConnector::meta.subTypes() += Entry::meta;
		TransConnector::meta.subTypes() += Exit::meta;
		TransConnector::meta.subTypes() += Terminate::meta;

		State::meta_Transition.target() = Transition::meta;
		Transition::meta.association() = TransConnector::meta_dstTransition.parent();
		Transition::meta_dstTransition_end_ = TransConnector::meta_srcTransition_rev = TransConnector::meta_dstTransition;
		Transition::meta_srcTransition_end_ = TransConnector::meta_dstTransition_rev = TransConnector::meta_srcTransition;

		PetriNet::meta_TransitionToState_children.target() = TransitionToState::meta;
		TransitionToState::meta.association() = PNTransition::meta_dstTransitionToState.parent();
		TransitionToState::meta_dstTransitionToState_end_ = PNState::meta_srcTransitionToState_rev = PNTransition::meta_dstTransitionToState;
		TransitionToState::meta_srcTransitionToState_end_ = PNTransition::meta_dstTransitionToState_rev = PNState::meta_srcTransitionToState;

		Component::meta_Trigger_children.target() = Trigger::meta;
		Trigger::meta.association() = OutputEvent::meta_dstTrigger.parent();
		Trigger::meta_dstTrigger_end_ = InputEvent::meta_srcTrigger_rev = OutputEvent::meta_dstTrigger;
		Trigger::meta_srcTrigger_end_ = OutputEvent::meta_dstTrigger_rev = InputEvent::meta_srcTrigger;

		TriggerPort::meta_memb = ::ESM2SLC::TriggerPort_cross_ph_ESMoL::meta_memb;

		TypeBase::meta_referedbyTypeStructRef.target() = TypeBaseRef::meta;
		TypeBase::meta_dt = ::ESM2SLC::TypeBase_cross_ph_ESMoL::meta_dt;
		Types::meta_TypeBase_children.target() = TypeBase::meta;
		TypeBase::meta.subTypes() += TypeStruct::meta;
		TypeBase::meta.subTypes() += Matrix::meta;

		TypeBaseRef::meta_ref.target() = TypeBase::meta;
		TypeBaseRef::meta_lvar = ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL::meta_lvar;
		TypeStruct::meta_TypeBaseRef_children.target() = TypeBaseRef::meta;
		Port::meta_TypeBaseRef_child.target() = TypeBaseRef::meta;
		StateDE::meta_TypeBaseRef_child.target() = TypeBaseRef::meta;

		TypeBaseRef::meta_TypeStruct_parent.target() = TypeStruct::meta;

		TypeBase::meta_Types_parent.target() = Types::meta;
		RootFolder::meta_Types_children.target() = Types::meta;

		Variable::meta_ValueObject_children.target() = ValueObject::meta;
		ValueObject::meta.subTypes() += RandomDistribution::meta;
		ValueObject::meta.subTypes() += Constant::meta;
		ValueObject::meta.subTypes() += Functions::meta;

		Occurrence::meta_Variable_parent.target() = Variable::meta;
		Incorporation::meta_Variable_parent.target() = Variable::meta;
		ValueObject::meta_Variable_parent.target() = Variable::meta;
		FaultModel::meta_Variable_children.target() = Variable::meta;

		HardwareUnit::meta_Wire_children.target() = Wire::meta;
		Wire::meta.association() = Connectable::meta_dstWire.parent();
		Wire::meta_dstWire_end_ = Connectable::meta_srcWire_rev = Connectable::meta_dstWire;
		Wire::meta_srcWire_end_ = Connectable::meta_dstWire_rev = Connectable::meta_srcWire;

	}

	void InitMeta(const ::Uml::Diagram &parent) {
		// classes, with attributes, constraints and constraint definitions
		::Uml::SetClass(AcquisitionConnection::meta, parent, "AcquisitionConnection");

		::Uml::SetClass(Action::meta, parent, "Action");

		::Uml::SetClass(ActionPort::meta, parent, "ActionPort");

		::Uml::SetClass(ActuationConnection::meta, parent, "ActuationConnection");

		::Uml::SetClass(Additive::meta, parent, "Additive");

		::Uml::SetClass(Annotation::meta, parent, "Annotation");
		::Uml::SetAttribute(Annotation::meta_Text, Annotation::meta, "Text");

		::Uml::SetClass(AperiodicExecInfo::meta, parent, "AperiodicExecInfo");

		::Uml::SetClass(ArchitectureLibrary::meta, parent, "ArchitectureLibrary");
		::Uml::SetAttribute(ArchitectureLibrary::meta_name, ArchitectureLibrary::meta, "name");

		::Uml::SetClass(AsyncPeriodicExecInfo::meta, parent, "AsyncPeriodicExecInfo");
		::Uml::SetAttribute(AsyncPeriodicExecInfo::meta_TerminationTime, AsyncPeriodicExecInfo::meta, "TerminationTime");

		::Uml::SetClass(AutoCANMessage::meta, parent, "AutoCANMessage");
		::Uml::SetAttribute(AutoCANMessage::meta_PGN, AutoCANMessage::meta, "PGN");

		::Uml::SetClass(AutoCANParam::meta, parent, "AutoCANParam");
		::Uml::SetAttribute(AutoCANParam::meta_SPN, AutoCANParam::meta, "SPN");

		::Uml::SetClass(BChan::meta, parent, "BChan");

		::Uml::SetClass(BIPConnector::meta, parent, "BIPConnector");

		::Uml::SetClass(BitField::meta, parent, "BitField");

		::Uml::SetClass(Block::meta, parent, "Block");
		::Uml::SetAttribute(Block::meta_BlockType, Block::meta, "BlockType");
		::Uml::SetAttribute(Block::meta_Tag, Block::meta, "Tag");
		::Uml::SetAttribute(Block::meta_Name, Block::meta, "Name");
		::Uml::SetAttribute(Block::meta_Description, Block::meta, "Description");
		::Uml::SetAttribute(Block::meta_Priority, Block::meta, "Priority");
		::Uml::SetAttribute(Block::meta_SampleTime, Block::meta, "SampleTime");
		::Uml::SetAttribute(Block::meta_UserData, Block::meta, "UserData");
		::Uml::SetConstraint(Block::meta_UniqueConnectorNames, Block::meta, "UniqueConnectorNames");

		::Uml::SetClass(Bus::meta, parent, "Bus");
		::Uml::SetAttribute(Bus::meta_DataRate, Bus::meta, "DataRate");
		::Uml::SetAttribute(Bus::meta_DeprecatedOH, Bus::meta, "DeprecatedOH");
		::Uml::SetAttribute(Bus::meta_MinFrameSize, Bus::meta, "MinFrameSize");
		::Uml::SetAttribute(Bus::meta_SwitchMemorySize, Bus::meta, "SwitchMemorySize");
		::Uml::SetAttribute(Bus::meta_ID, Bus::meta, "ID");
		::Uml::SetAttribute(Bus::meta_SetupTime, Bus::meta, "SetupTime");

		::Uml::SetClass(CANBus::meta, parent, "CANBus");
		::Uml::SetAttribute(CANBus::meta_Hyperperiod, CANBus::meta, "Hyperperiod");

		::Uml::SetClass(CANMessage::meta, parent, "CANMessage");
		::Uml::SetAttribute(CANMessage::meta_Priority, CANMessage::meta, "Priority");
		::Uml::SetAttribute(CANMessage::meta_Period, CANMessage::meta, "Period");

		::Uml::SetClass(CCode::meta, parent, "CCode");
		::Uml::SetAttribute(CCode::meta_CodeInfo, CCode::meta, "CodeInfo");

		::Uml::SetClass(CInputPort::meta, parent, "CInputPort");
		::Uml::SetAttribute(CInputPort::meta_CPortType, CInputPort::meta, "CPortType");

		::Uml::SetClass(COutputPort::meta, parent, "COutputPort");
		::Uml::SetAttribute(COutputPort::meta_CPortType, COutputPort::meta, "CPortType");

		::Uml::SetClass(Channel::meta, parent, "Channel");
		::Uml::SetAttribute(Channel::meta_Configuration, Channel::meta, "Configuration");
		::Uml::SetAttribute(Channel::meta_ChanNum, Channel::meta, "ChanNum");

		::Uml::SetClass(Choice::meta, parent, "Choice");

		::Uml::SetClass(CommMapping::meta, parent, "CommMapping");

		::Uml::SetClass(CommMapping_Members_Base::meta, parent, "CommMapping_Members_Base");

		::Uml::SetClass(CommMapping_dstCommMapping_RPContainer_Base::meta, parent, "CommMapping_dstCommMapping_RPContainer_Base");

		::Uml::SetClass(CommMapping_srcCommMapping_RPContainer_Base::meta, parent, "CommMapping_srcCommMapping_RPContainer_Base");

		::Uml::SetClass(CompBreakout::meta, parent, "CompBreakout");

		::Uml::SetClass(Component::meta, parent, "Component");
		::Uml::SetAttribute(Component::meta_HeaderFiles, Component::meta, "HeaderFiles");
		::Uml::SetAttribute(Component::meta_SourceFiles, Component::meta, "SourceFiles");

		::Uml::SetClass(ComponentAssignment::meta, parent, "ComponentAssignment");

		::Uml::SetClass(ComponentBase::meta, parent, "ComponentBase");
		::Uml::SetAttribute(ComponentBase::meta_Period, ComponentBase::meta, "Period");
		::Uml::SetAttribute(ComponentBase::meta_Deadline, ComponentBase::meta, "Deadline");

		::Uml::SetClass(ComponentRef::meta, parent, "ComponentRef");

		::Uml::SetClass(ComponentRef_RefersTo_Base::meta, parent, "ComponentRef_RefersTo_Base");

		::Uml::SetClass(ConditionEvent::meta, parent, "ConditionEvent");

		::Uml::SetClass(Conditional::meta, parent, "Conditional");

		::Uml::SetClass(Connectable::meta, parent, "Connectable");

		::Uml::SetClass(Connector::meta, parent, "Connector");
		::Uml::SetAttribute(Connector::meta_ConnectionType, Connector::meta, "ConnectionType");

		::Uml::SetClass(ConnectorRef::meta, parent, "ConnectorRef");

		::Uml::SetClass(Connector_dstConnector_RPContainer_Base::meta, parent, "Connector_dstConnector_RPContainer_Base");

		::Uml::SetClass(Connector_srcConnector_RPContainer_Base::meta, parent, "Connector_srcConnector_RPContainer_Base");

		::Uml::SetClass(Constant::meta, parent, "Constant");
		::Uml::SetAttribute(Constant::meta_Value, Constant::meta, "Value");

		::Uml::SetClass(Continuous::meta, parent, "Continuous");

		::Uml::SetClass(Data::meta, parent, "Data");
		::Uml::SetAttribute(Data::meta_Description, Data::meta, "Description");
		::Uml::SetAttribute(Data::meta_Name, Data::meta, "Name");
		::Uml::SetAttribute(Data::meta_DataType, Data::meta, "DataType");
		::Uml::SetAttribute(Data::meta_Port, Data::meta, "Port");
		::Uml::SetAttribute(Data::meta_Units, Data::meta, "Units");
		::Uml::SetAttribute(Data::meta_InitialValue, Data::meta, "InitialValue");
		::Uml::SetAttribute(Data::meta_Min, Data::meta, "Min");
		::Uml::SetAttribute(Data::meta_Max, Data::meta, "Max");
		::Uml::SetAttribute(Data::meta_ArraySize, Data::meta, "ArraySize");
		::Uml::SetAttribute(Data::meta_ArrayFirstIndex, Data::meta, "ArrayFirstIndex");
		::Uml::SetAttribute(Data::meta_Scope, Data::meta, "Scope");

		::Uml::SetClass(Dataflow::meta, parent, "Dataflow");
		::Uml::SetAttribute(Dataflow::meta_name, Dataflow::meta, "name");

		::Uml::SetClass(DeepHistory::meta, parent, "DeepHistory");

		::Uml::SetClass(Dependency::meta, parent, "Dependency");

		::Uml::SetClass(DeploymentLibrary::meta, parent, "DeploymentLibrary");
		::Uml::SetAttribute(DeploymentLibrary::meta_name, DeploymentLibrary::meta, "name");

		::Uml::SetClass(DesignFolder::meta, parent, "DesignFolder");
		::Uml::SetAttribute(DesignFolder::meta_name, DesignFolder::meta, "name");

		::Uml::SetClass(DesignReference::meta, parent, "DesignReference");

		::Uml::SetClass(DetectionAction::meta, parent, "DetectionAction");

		::Uml::SetClass(DetectionCondition::meta, parent, "DetectionCondition");

		::Uml::SetClass(EnablePort::meta, parent, "EnablePort");
		::Uml::SetAttribute(EnablePort::meta_StatesWhenEnabling, EnablePort::meta, "StatesWhenEnabling");
		::Uml::SetConstraint(EnablePort::meta_EPtoNestedIPTPEPBPOnly, EnablePort::meta, "EPtoNestedIPTPEPBPOnly");
		::Uml::SetConstraint(EnablePort::meta_EPConnectedByPortInParentParent, EnablePort::meta, "EPConnectedByPortInParentParent");
		::Uml::SetConstraint(EnablePort::meta_OnlyOneEP, EnablePort::meta, "OnlyOneEP");
		::Uml::SetConstraint(EnablePort::meta_EPParentIsSubsystemOrSystem, EnablePort::meta, "EPParentIsSubsystemOrSystem");
		::Uml::SetConstraint(EnablePort::meta_EPInSubsystemOnlyConnectToEPInSystem, EnablePort::meta, "EPInSubsystemOnlyConnectToEPInSystem");
		::Uml::SetConstraint(EnablePort::meta_EPConnectedAsDstAtLeastOnce, EnablePort::meta, "EPConnectedAsDstAtLeastOnce");
		::Uml::SetConstraint(EnablePort::meta_EnableParentInSubsystemMustConnectDownToSystem, EnablePort::meta, "EnableParentInSubsystemMustConnectDownToSystem");

		::Uml::SetClass(Entry::meta, parent, "Entry");

		::Uml::SetClass(Event::meta, parent, "Event");
		::Uml::SetAttribute(Event::meta_Description, Event::meta, "Description");
		::Uml::SetAttribute(Event::meta_Name, Event::meta, "Name");
		::Uml::SetAttribute(Event::meta_Scope, Event::meta, "Scope");
		::Uml::SetAttribute(Event::meta_Trigger, Event::meta, "Trigger");
		::Uml::SetAttribute(Event::meta_Port, Event::meta, "Port");

		::Uml::SetClass(Executable::meta, parent, "Executable");

		::Uml::SetClass(ExecutionAssignment::meta, parent, "ExecutionAssignment");

		::Uml::SetClass(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta, parent, "ExecutionAssignment_dstExecutionAssignment_RPContainer_Base");

		::Uml::SetClass(ExecutionContext::meta, parent, "ExecutionContext");

		::Uml::SetClass(ExecutionInfo::meta, parent, "ExecutionInfo");
		::Uml::SetAttribute(ExecutionInfo::meta_WCDuration, ExecutionInfo::meta, "WCDuration");
		::Uml::SetAttribute(ExecutionInfo::meta_RelDeadline, ExecutionInfo::meta, "RelDeadline");

		::Uml::SetClass(Exit::meta, parent, "Exit");

		::Uml::SetClass(Exponential::meta, parent, "Exponential");
		::Uml::SetAttribute(Exponential::meta_Rate, Exponential::meta, "Rate");

		::Uml::SetClass(FaultCondition::meta, parent, "FaultCondition");
		::Uml::SetAttribute(FaultCondition::meta_Expression, FaultCondition::meta, "Expression");

		::Uml::SetClass(FaultEvent::meta, parent, "FaultEvent");

		::Uml::SetClass(FaultMgrTask::meta, parent, "FaultMgrTask");

		::Uml::SetClass(FaultModel::meta, parent, "FaultModel");

		::Uml::SetClass(FaultModelFolder::meta, parent, "FaultModelFolder");
		::Uml::SetAttribute(FaultModelFolder::meta_name, FaultModelFolder::meta, "name");

		::Uml::SetClass(FaultModelRef::meta, parent, "FaultModelRef");

		::Uml::SetClass(FaultScenario::meta, parent, "FaultScenario");

		::Uml::SetClass(FaultToInput::meta, parent, "FaultToInput");
		::Uml::SetAttribute(FaultToInput::meta_VectorIndex, FaultToInput::meta, "VectorIndex");

		::Uml::SetClass(FaultToInput_Members_Base::meta, parent, "FaultToInput_Members_Base");

		::Uml::SetClass(FaultTrigger::meta, parent, "FaultTrigger");

		::Uml::SetClass(FieldDataType::meta, parent, "FieldDataType");
		::Uml::SetAttribute(FieldDataType::meta_NumBits, FieldDataType::meta, "NumBits");
		::Uml::SetAttribute(FieldDataType::meta_InitialValue, FieldDataType::meta, "InitialValue");

		::Uml::SetClass(Fork::meta, parent, "Fork");

		::Uml::SetClass(Functions::meta, parent, "Functions");

		::Uml::SetClass(HWElement::meta, parent, "HWElement");
		::Uml::SetAttribute(HWElement::meta_Configuration, HWElement::meta, "Configuration");

		::Uml::SetClass(HardwareUnit::meta, parent, "HardwareUnit");

		::Uml::SetClass(HasRefId::meta, parent, "HasRefId");
		::Uml::SetAttribute(HasRefId::meta_RefId, HasRefId::meta, "RefId");

		::Uml::SetClass(History::meta, parent, "History");

		::Uml::SetClass(IChan::meta, parent, "IChan");

		::Uml::SetClass(IODevice::meta, parent, "IODevice");
		::Uml::SetAttribute(IODevice::meta_DeviceType, IODevice::meta, "DeviceType");

		::Uml::SetClass(IOPortAssignment::meta, parent, "IOPortAssignment");

		::Uml::SetClass(IOPortExp::meta, parent, "IOPortExp");

		::Uml::SetClass(IOPortInfo::meta, parent, "IOPortInfo");
		::Uml::SetAttribute(IOPortInfo::meta_DataSize, IOPortInfo::meta, "DataSize");
		::Uml::SetAttribute(IOPortInfo::meta_DataInit, IOPortInfo::meta, "DataInit");
		::Uml::SetAttribute(IOPortInfo::meta_DataMin, IOPortInfo::meta, "DataMin");
		::Uml::SetAttribute(IOPortInfo::meta_DataMax, IOPortInfo::meta, "DataMax");
		::Uml::SetAttribute(IOPortInfo::meta_Scale, IOPortInfo::meta, "Scale");
		::Uml::SetAttribute(IOPortInfo::meta_Offset, IOPortInfo::meta, "Offset");

		::Uml::SetClass(IOPortInfoBase::meta, parent, "IOPortInfoBase");

		::Uml::SetClass(IOPortInfoRef::meta, parent, "IOPortInfoRef");

		::Uml::SetClass(InPort::meta, parent, "InPort");

		::Uml::SetClass(Incorporation::meta, parent, "Incorporation");

		::Uml::SetClass(Input::meta, parent, "Input");

		::Uml::SetClass(InputEvent::meta, parent, "InputEvent");

		::Uml::SetClass(InputPort::meta, parent, "InputPort");
		::Uml::SetAttribute(InputPort::meta_Number, InputPort::meta, "Number");
		::Uml::SetConstraint(InputPort::meta_IPtoNestedIPTPEPBPOnly, InputPort::meta, "IPtoNestedIPTPEPBPOnly");
		::Uml::SetConstraint(InputPort::meta_IPInSubsystemOnlyConnectToIPInSystem, InputPort::meta, "IPInSubsystemOnlyConnectToIPInSystem");
		::Uml::SetConstraint(InputPort::meta_IPConnectedAsDstAtLeastOnce, InputPort::meta, "IPConnectedAsDstAtLeastOnce");

		::Uml::SetClass(Intermittent::meta, parent, "Intermittent");

		::Uml::SetClass(Interval::meta, parent, "Interval");
		::Uml::SetAttribute(Interval::meta_Range, Interval::meta, "Range");

		::Uml::SetClass(Join::meta, parent, "Join");

		::Uml::SetClass(Junction::meta, parent, "Junction");
		::Uml::SetConstraint(Junction::meta_JunctNotToSelf, Junction::meta, "JunctNotToSelf");

		::Uml::SetClass(Line::meta, parent, "Line");
		::Uml::SetAttribute(Line::meta_Name, Line::meta, "Name");

		::Uml::SetClass(Link::meta, parent, "Link");

		::Uml::SetClass(Matrix::meta, parent, "Matrix");
		::Uml::SetAttribute(Matrix::meta_Type, Matrix::meta, "Type");
		::Uml::SetAttribute(Matrix::meta_rows, Matrix::meta, "rows");
		::Uml::SetAttribute(Matrix::meta_columns, Matrix::meta, "columns");

		::Uml::SetClass(Message::meta, parent, "Message");
		::Uml::SetAttribute(Message::meta_MsgSize, Message::meta, "MsgSize");
		::Uml::SetAttribute(Message::meta_MsgMetaData, Message::meta, "MsgMetaData");

		::Uml::SetClass(MessageRef::meta, parent, "MessageRef");

		::Uml::SetClass(MessageRef_RefersTo_Base::meta, parent, "MessageRef_RefersTo_Base");

		::Uml::SetClass(MgaObject::meta, parent, "MgaObject");
		::Uml::SetAttribute(MgaObject::meta_name, MgaObject::meta, "name");
		::Uml::SetAttribute(MgaObject::meta_position, MgaObject::meta, "position");

		::Uml::SetClass(MitigationAction::meta, parent, "MitigationAction");

		::Uml::SetClass(MitigationCondition::meta, parent, "MitigationCondition");

		::Uml::SetClass(ModelInfo::meta, parent, "ModelInfo");
		::Uml::SetAttribute(ModelInfo::meta_ModelPath, ModelInfo::meta, "ModelPath");
		::Uml::SetAttribute(ModelInfo::meta_DateTimeStamp, ModelInfo::meta, "DateTimeStamp");

		::Uml::SetClass(ModelsFolder::meta, parent, "ModelsFolder");
		::Uml::SetAttribute(ModelsFolder::meta_name, ModelsFolder::meta, "name");

		::Uml::SetClass(Module::meta, parent, "Module");

		::Uml::SetClass(MsgPort::meta, parent, "MsgPort");
		::Uml::SetAttribute(MsgPort::meta_MsgPortNum, MsgPort::meta, "MsgPortNum");
		::Uml::SetAttribute(MsgPort::meta_FieldMetaData, MsgPort::meta, "FieldMetaData");

		::Uml::SetClass(Multiplicative::meta, parent, "Multiplicative");

		::Uml::SetClass(Network::meta, parent, "Network");
		::Uml::SetAttribute(Network::meta_DataRate, Network::meta, "DataRate");

		::Uml::SetClass(Node::meta, parent, "Node");
		::Uml::SetAttribute(Node::meta_Simulator, Node::meta, "Simulator");
		::Uml::SetAttribute(Node::meta_ROM, Node::meta, "ROM");
		::Uml::SetAttribute(Node::meta_RAM, Node::meta, "RAM");
		::Uml::SetAttribute(Node::meta_Speed, Node::meta, "Speed");
		::Uml::SetAttribute(Node::meta_CPU, Node::meta, "CPU");
		::Uml::SetAttribute(Node::meta_PlatformType, Node::meta, "PlatformType");
		::Uml::SetAttribute(Node::meta_BusIDList, Node::meta, "BusIDList");

		::Uml::SetClass(NodeRef::meta, parent, "NodeRef");

		::Uml::SetClass(Normal::meta, parent, "Normal");
		::Uml::SetAttribute(Normal::meta_Mean, Normal::meta, "Mean");
		::Uml::SetAttribute(Normal::meta_StdDev, Normal::meta, "StdDev");

		::Uml::SetClass(OChan::meta, parent, "OChan");

		::Uml::SetClass(OS::meta, parent, "OS");
		::Uml::SetAttribute(OS::meta_ContextSwitchTime, OS::meta, "ContextSwitchTime");
		::Uml::SetAttribute(OS::meta_SendOverheadTime, OS::meta, "SendOverheadTime");
		::Uml::SetAttribute(OS::meta_RecvOverheadTime, OS::meta, "RecvOverheadTime");
		::Uml::SetAttribute(OS::meta_TickResolution, OS::meta, "TickResolution");
		::Uml::SetAttribute(OS::meta_MaxTaskNumber, OS::meta, "MaxTaskNumber");
		::Uml::SetAttribute(OS::meta_SchedulingAlgorithm, OS::meta, "SchedulingAlgorithm");
		::Uml::SetAttribute(OS::meta_ISROverheadTime, OS::meta, "ISROverheadTime");

		::Uml::SetClass(Occurrence::meta, parent, "Occurrence");

		::Uml::SetClass(OldBus::meta, parent, "OldBus");
		::Uml::SetAttribute(OldBus::meta_Medium, OldBus::meta, "Medium");
		::Uml::SetAttribute(OldBus::meta_FrameSize, OldBus::meta, "FrameSize");
		::Uml::SetAttribute(OldBus::meta_OverheadTime, OldBus::meta, "OverheadTime");

		::Uml::SetClass(OldTask::meta, parent, "OldTask");
		::Uml::SetAttribute(OldTask::meta_Priority, OldTask::meta, "Priority");
		::Uml::SetAttribute(OldTask::meta_TaskType, OldTask::meta, "TaskType");
		::Uml::SetAttribute(OldTask::meta_Activation, OldTask::meta, "Activation");
		::Uml::SetAttribute(OldTask::meta_AutoStart, OldTask::meta, "AutoStart");
		::Uml::SetAttribute(OldTask::meta_Preemption, OldTask::meta, "Preemption");
		::Uml::SetAttribute(OldTask::meta_Cyclic, OldTask::meta, "Cyclic");
		::Uml::SetAttribute(OldTask::meta_CycleTime, OldTask::meta, "CycleTime");

		::Uml::SetClass(OutPort::meta, parent, "OutPort");

		::Uml::SetClass(Output::meta, parent, "Output");

		::Uml::SetClass(OutputEvent::meta, parent, "OutputEvent");

		::Uml::SetClass(OutputPort::meta, parent, "OutputPort");
		::Uml::SetAttribute(OutputPort::meta_Number, OutputPort::meta, "Number");
		::Uml::SetConstraint(OutputPort::meta_NestedOPtoOPorNestedOPtoIP, OutputPort::meta, "NestedOPtoOPorNestedOPtoIP");

		::Uml::SetClass(OutputToFault::meta, parent, "OutputToFault");
		::Uml::SetAttribute(OutputToFault::meta_VectorIndex, OutputToFault::meta, "VectorIndex");

		::Uml::SetClass(OutputToFault_Members_Base::meta, parent, "OutputToFault_Members_Base");

		::Uml::SetClass(PNPort::meta, parent, "PNPort");
		::Uml::SetAttribute(PNPort::meta_visible, PNPort::meta, "visible");

		::Uml::SetClass(PNState::meta, parent, "PNState");
		::Uml::SetAttribute(PNState::meta_initial, PNState::meta, "initial");

		::Uml::SetClass(PNTransition::meta, parent, "PNTransition");
		::Uml::SetAttribute(PNTransition::meta_guard, PNTransition::meta, "guard");
		::Uml::SetAttribute(PNTransition::meta_action, PNTransition::meta, "action");

		::Uml::SetClass(PNVarRef::meta, parent, "PNVarRef");

		::Uml::SetClass(PNVariable::meta, parent, "PNVariable");
		::Uml::SetAttribute(PNVariable::meta_datatype, PNVariable::meta, "datatype");

		::Uml::SetClass(Parameter::meta, parent, "Parameter");
		::Uml::SetAttribute(Parameter::meta_Value, Parameter::meta, "Value");

		::Uml::SetClass(Periodic::meta, parent, "Periodic");

		::Uml::SetClass(PeriodicExecInfo::meta, parent, "PeriodicExecInfo");
		::Uml::SetAttribute(PeriodicExecInfo::meta_ExecPeriod, PeriodicExecInfo::meta, "ExecPeriod");
		::Uml::SetAttribute(PeriodicExecInfo::meta_DesiredOffset, PeriodicExecInfo::meta, "DesiredOffset");

		::Uml::SetClass(PetriNet::meta, parent, "PetriNet");
		::Uml::SetAttribute(PetriNet::meta_action, PetriNet::meta, "action");

		::Uml::SetClass(PetriNetRef::meta, parent, "PetriNetRef");

		::Uml::SetClass(PhysConnection::meta, parent, "PhysConnection");

		::Uml::SetClass(PhysInterface::meta, parent, "PhysInterface");

		::Uml::SetClass(Plant::meta, parent, "Plant");

		::Uml::SetClass(PlantComponent::meta, parent, "PlantComponent");

		::Uml::SetClass(PlantComponentRef::meta, parent, "PlantComponentRef");

		::Uml::SetClass(PlatformLibrary::meta, parent, "PlatformLibrary");
		::Uml::SetAttribute(PlatformLibrary::meta_name, PlatformLibrary::meta, "name");

		::Uml::SetClass(Port::meta, parent, "Port");

		::Uml::SetClass(Postcondition::meta, parent, "Postcondition");

		::Uml::SetClass(Precondition::meta, parent, "Precondition");

		::Uml::SetClass(Primitive::meta, parent, "Primitive");

		::Uml::SetClass(Pulse::meta, parent, "Pulse");
		::Uml::SetAttribute(Pulse::meta_Shift, Pulse::meta, "Shift");
		::Uml::SetAttribute(Pulse::meta_Duration, Pulse::meta, "Duration");

		::Uml::SetClass(RandomDistribution::meta, parent, "RandomDistribution");

		::Uml::SetClass(Reference::meta, parent, "Reference");
		::Uml::SetAttribute(Reference::meta_SourceType, Reference::meta, "SourceType");
		::Uml::SetAttribute(Reference::meta_SourceBlock, Reference::meta, "SourceBlock");

		::Uml::SetClass(RequirementsLibrary::meta, parent, "RequirementsLibrary");
		::Uml::SetAttribute(RequirementsLibrary::meta_name, RequirementsLibrary::meta, "name");

		::Uml::SetClass(RootFolder::meta, parent, "RootFolder");
		::Uml::SetAttribute(RootFolder::meta_name, RootFolder::meta, "name");

		::Uml::SetClass(ScenarioInfo::meta, parent, "ScenarioInfo");
		::Uml::SetAttribute(ScenarioInfo::meta_Requirements, ScenarioInfo::meta, "Requirements");
		::Uml::SetAttribute(ScenarioInfo::meta_ScenarioDescription, ScenarioInfo::meta, "ScenarioDescription");
		::Uml::SetAttribute(ScenarioInfo::meta_Criticality, ScenarioInfo::meta, "Criticality");

		::Uml::SetClass(SerialLink::meta, parent, "SerialLink");
		::Uml::SetAttribute(SerialLink::meta_DataBits, SerialLink::meta, "DataBits");
		::Uml::SetAttribute(SerialLink::meta_Parity, SerialLink::meta, "Parity");
		::Uml::SetAttribute(SerialLink::meta_StopBits, SerialLink::meta, "StopBits");
		::Uml::SetAttribute(SerialLink::meta_FlowControl, SerialLink::meta, "FlowControl");

		::Uml::SetClass(ShallowHistory::meta, parent, "ShallowHistory");

		::Uml::SetClass(Sinusoid::meta, parent, "Sinusoid");
		::Uml::SetAttribute(Sinusoid::meta_Frequency, Sinusoid::meta, "Frequency");
		::Uml::SetAttribute(Sinusoid::meta_Phase, Sinusoid::meta, "Phase");

		::Uml::SetClass(SporadicExecInfo::meta, parent, "SporadicExecInfo");
		::Uml::SetAttribute(SporadicExecInfo::meta_MinimumPeriod, SporadicExecInfo::meta, "MinimumPeriod");

		::Uml::SetClass(State::meta, parent, "State");
		::Uml::SetAttribute(State::meta_Decomposition, State::meta, "Decomposition");
		::Uml::SetAttribute(State::meta_Name, State::meta, "Name");
		::Uml::SetAttribute(State::meta_EnterAction, State::meta, "EnterAction");
		::Uml::SetAttribute(State::meta_DuringAction, State::meta, "DuringAction");
		::Uml::SetAttribute(State::meta_ExitAction, State::meta, "ExitAction");
		::Uml::SetAttribute(State::meta_Order, State::meta, "Order");
		::Uml::SetAttribute(State::meta_Description, State::meta, "Description");
		::Uml::SetAttribute(State::meta_Methods, State::meta, "Methods");
		::Uml::SetConstraint(State::meta_SingleHistory, State::meta, "SingleHistory");

		::Uml::SetClass(StateDE::meta, parent, "StateDE");

		::Uml::SetClass(StatePort::meta, parent, "StatePort");

		::Uml::SetClass(StateToTransition::meta, parent, "StateToTransition");

		::Uml::SetClass(Stateflow::meta, parent, "Stateflow");
		::Uml::SetAttribute(Stateflow::meta_name, Stateflow::meta, "name");

		::Uml::SetClass(Step::meta, parent, "Step");
		::Uml::SetAttribute(Step::meta_Shift, Step::meta, "Shift");

		::Uml::SetClass(Substitutive::meta, parent, "Substitutive");

		::Uml::SetClass(Subsystem::meta, parent, "Subsystem");
		::Uml::SetConstraint(Subsystem::meta_UniqueConnectorNames1, Subsystem::meta, "UniqueConnectorNames1");

		::Uml::SetClass(SubsystemRef::meta, parent, "SubsystemRef");

		::Uml::SetClass(System::meta, parent, "System");

		::Uml::SetClass(SystemTypes::meta, parent, "SystemTypes");

		::Uml::SetClass(TTBus::meta, parent, "TTBus");
		::Uml::SetAttribute(TTBus::meta_Hyperperiod, TTBus::meta, "Hyperperiod");
		::Uml::SetAttribute(TTBus::meta_TTSetupTime, TTBus::meta, "TTSetupTime");
		::Uml::SetAttribute(TTBus::meta_SlotSize, TTBus::meta, "SlotSize");

		::Uml::SetClass(TTExecContext::meta, parent, "TTExecContext");
		::Uml::SetAttribute(TTExecContext::meta_Hyperperiod, TTExecContext::meta, "Hyperperiod");

		::Uml::SetClass(TTExecInfo::meta, parent, "TTExecInfo");
		::Uml::SetAttribute(TTExecInfo::meta_TTSchedule, TTExecInfo::meta, "TTSchedule");

		::Uml::SetClass(TaskInst::meta, parent, "TaskInst");

		::Uml::SetClass(TaskRef::meta, parent, "TaskRef");

		::Uml::SetClass(Terminate::meta, parent, "Terminate");

		::Uml::SetClass(TimingConstraint::meta, parent, "TimingConstraint");
		::Uml::SetAttribute(TimingConstraint::meta_Latency, TimingConstraint::meta, "Latency");

		::Uml::SetClass(TimingSheet::meta, parent, "TimingSheet");

		::Uml::SetClass(TransConnector::meta, parent, "TransConnector");

		::Uml::SetClass(TransStart::meta, parent, "TransStart");
		::Uml::SetConstraint(TransStart::meta_TransStartRestrict, TransStart::meta, "TransStartRestrict");

		::Uml::SetClass(Transition::meta, parent, "Transition");
		::Uml::SetAttribute(Transition::meta_Trigger, Transition::meta, "Trigger");
		::Uml::SetAttribute(Transition::meta_Guard, Transition::meta, "Guard");
		::Uml::SetAttribute(Transition::meta_Action, Transition::meta, "Action");
		::Uml::SetAttribute(Transition::meta_ConditionAction, Transition::meta, "ConditionAction");
		::Uml::SetAttribute(Transition::meta_Order, Transition::meta, "Order");

		::Uml::SetClass(TransitionToState::meta, parent, "TransitionToState");

		::Uml::SetClass(Trigger::meta, parent, "Trigger");

		::Uml::SetClass(TriggerPort::meta, parent, "TriggerPort");
		::Uml::SetAttribute(TriggerPort::meta_TriggerType, TriggerPort::meta, "TriggerType");
		::Uml::SetConstraint(TriggerPort::meta_OnlyOneTP, TriggerPort::meta, "OnlyOneTP");
		::Uml::SetConstraint(TriggerPort::meta_TPConnectedAsDstAtLeastOnce, TriggerPort::meta, "TPConnectedAsDstAtLeastOnce");
		::Uml::SetConstraint(TriggerPort::meta_TPtoNestedIPTPEPBPOnly, TriggerPort::meta, "TPtoNestedIPTPEPBPOnly");
		::Uml::SetConstraint(TriggerPort::meta_TPConnectedByPortInParentParent, TriggerPort::meta, "TPConnectedByPortInParentParent");
		::Uml::SetConstraint(TriggerPort::meta_TPInSubsystemOnlyConnectToTPInSystem, TriggerPort::meta, "TPInSubsystemOnlyConnectToTPInSystem");
		::Uml::SetConstraint(TriggerPort::meta_TPParentIsSubsystemOrSystem, TriggerPort::meta, "TPParentIsSubsystemOrSystem");
		::Uml::SetConstraint(TriggerPort::meta_TriggerParentInSubsystemMustConnectDownToSystem, TriggerPort::meta, "TriggerParentInSubsystemMustConnectDownToSystem");

		::Uml::SetClass(TypeBase::meta, parent, "TypeBase");

		::Uml::SetClass(TypeBaseRef::meta, parent, "TypeBaseRef");
		::Uml::SetAttribute(TypeBaseRef::meta_MemberIndex, TypeBaseRef::meta, "MemberIndex");

		::Uml::SetClass(TypeStruct::meta, parent, "TypeStruct");
		::Uml::SetAttribute(TypeStruct::meta_MemberCount, TypeStruct::meta, "MemberCount");

		::Uml::SetClass(Types::meta, parent, "Types");
		::Uml::SetAttribute(Types::meta_name, Types::meta, "name");

		::Uml::SetClass(Uniform::meta, parent, "Uniform");
		::Uml::SetAttribute(Uniform::meta_LowerBound, Uniform::meta, "LowerBound");
		::Uml::SetAttribute(Uniform::meta_UpperBound, Uniform::meta, "UpperBound");

		::Uml::SetClass(ValueObject::meta, parent, "ValueObject");

		::Uml::SetClass(ValueType::meta, parent, "ValueType");
		::Uml::SetAttribute(ValueType::meta_Scale, ValueType::meta, "Scale");
		::Uml::SetAttribute(ValueType::meta_Signed, ValueType::meta, "Signed");
		::Uml::SetAttribute(ValueType::meta_DataType, ValueType::meta, "DataType");
		::Uml::SetAttribute(ValueType::meta_MinValue, ValueType::meta, "MinValue");
		::Uml::SetAttribute(ValueType::meta_MaxValue, ValueType::meta, "MaxValue");
		::Uml::SetAttribute(ValueType::meta_Units, ValueType::meta, "Units");
		::Uml::SetAttribute(ValueType::meta_Offset, ValueType::meta, "Offset");

		::Uml::SetClass(Variable::meta, parent, "Variable");

		::Uml::SetClass(Wire::meta, parent, "Wire");

	}

	void InitMetaLinks(const ::Uml::Diagram &parent) {
		// classes
		::Uml::SetParentRole(AcquisitionConnection::meta_HardwareUnit_parent, AcquisitionConnection::meta, HardwareUnit::meta, "", "");

		::Uml::SetAssocRole(Action::meta_ref, Action::meta, ComponentRef::meta, "referedbyAction");
		::Uml::SetParentRole(Action::meta_FaultScenario_parent, Action::meta, FaultScenario::meta, "", "");

		::Uml::SetParentRole(ActuationConnection::meta_HardwareUnit_parent, ActuationConnection::meta, HardwareUnit::meta, "", "");

		::Uml::SetParentRole(Annotation::meta_Block_parent, Annotation::meta, Block::meta, "", "");

		::Uml::SetChildRole(ArchitectureLibrary::meta_SystemTypes_children, ArchitectureLibrary::meta, SystemTypes::meta, "", "");
		::Uml::SetParentRole(ArchitectureLibrary::meta_RootFolder_parent, ArchitectureLibrary::meta, RootFolder::meta, "", "");

		::Uml::SetParentRole(BChan::meta_Network_parent, BChan::meta, Network::meta, "", "");

		::Uml::SetParentRole(BIPConnector::meta_Module_parent, BIPConnector::meta, Module::meta, "", "");

		::Uml::SetChildRole(Block::meta_Parameter, Block::meta, Parameter::meta, "", "Parameter");
		::Uml::SetChildRole(Block::meta_Line, Block::meta, Line::meta, "", "Line");
		::Uml::SetChildRole(Block::meta_Annotation_children, Block::meta, Annotation::meta, "", "");
		::Uml::SetChildRole(Block::meta_ConnectorRef_children, Block::meta, ConnectorRef::meta, "", "");
		::Uml::SetChildRole(Block::meta_Port_children, Block::meta, Port::meta, "", "");
		::Uml::SetParentRole(Block::meta_Subsystem_parent, Block::meta, Subsystem::meta, "", "");

		::Uml::SetChildRole(CCode::meta_COutputPort_children, CCode::meta, COutputPort::meta, "", "");
		::Uml::SetChildRole(CCode::meta_CInputPort_children, CCode::meta, CInputPort::meta, "", "");

		::Uml::SetParentRole(CInputPort::meta_CCode_parent, CInputPort::meta, CCode::meta, "", "");

		::Uml::SetParentRole(COutputPort::meta_CCode_parent, COutputPort::meta, CCode::meta, "", "");

		::Uml::SetParentRole(Channel::meta_HardwareUnit_parent, Channel::meta, HardwareUnit::meta, "", "");
		::Uml::SetParentRole(Channel::meta_IODevice_parent, Channel::meta, IODevice::meta, "", "");
		::Uml::SetParentRole(Channel::meta_Node_parent, Channel::meta, Node::meta, "", "");

		::Uml::SetAssocRole(CommMapping::meta_srcCommMapping__rp_helper, CommMapping::meta, CommMapping_srcCommMapping_RPContainer_Base::meta, "srcCommMapping__rp_helper_rev");
		::Uml::SetAssocRole(CommMapping::meta_dstCommMapping__rp_helper, CommMapping::meta, CommMapping_dstCommMapping_RPContainer_Base::meta, "dstCommMapping__rp_helper_rev");
		::Uml::SetParentRole(CommMapping::meta_System_parent, CommMapping::meta, System::meta, "", "");

		::Uml::SetAssocRole(CommMapping_Members_Base::meta_dstCommMapping, CommMapping_Members_Base::meta, CommMapping_Members_Base::meta, "srcCommMapping");
		CommMapping::meta_dstCommMapping_end_ = CommMapping_Members_Base::meta_srcCommMapping_rev = CommMapping_Members_Base::meta_dstCommMapping;
		::Uml::SetAssocRole(CommMapping_Members_Base::meta_srcCommMapping, CommMapping_Members_Base::meta, CommMapping_Members_Base::meta, "dstCommMapping");
		CommMapping::meta_srcCommMapping_end_ = CommMapping_Members_Base::meta_dstCommMapping_rev = CommMapping_Members_Base::meta_srcCommMapping;

		::Uml::SetAssocRole(CommMapping_dstCommMapping_RPContainer_Base::meta_dstCommMapping__rp_helper_rev, CommMapping_dstCommMapping_RPContainer_Base::meta, CommMapping::meta, "dstCommMapping__rp_helper");

		::Uml::SetAssocRole(CommMapping_srcCommMapping_RPContainer_Base::meta_srcCommMapping__rp_helper_rev, CommMapping_srcCommMapping_RPContainer_Base::meta, CommMapping::meta, "srcCommMapping__rp_helper");

		::Uml::SetParentRole(CompBreakout::meta_FaultScenario_parent, CompBreakout::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(Component::meta_referedbyTaskRef, Component::meta, TaskRef::meta, "ref");
		::Uml::SetChildRole(Component::meta_Trigger_children, Component::meta, Trigger::meta, "", "");
		::Uml::SetChildRole(Component::meta_MessageRef_children, Component::meta, MessageRef::meta, "", "");
		::Uml::SetChildRole(Component::meta_ComponentBase_children, Component::meta, ComponentBase::meta, "", "");
		::Uml::SetChildRole(Component::meta_Connector_children, Component::meta, Connector::meta, "", "");
		::Uml::SetParentRole(Component::meta_SystemTypes_parent, Component::meta, SystemTypes::meta, "", "");

		::Uml::SetParentRole(ComponentAssignment::meta_System_parent, ComponentAssignment::meta, System::meta, "", "");

		::Uml::SetAssocRole(ComponentBase::meta_dstCompBreakout, ComponentBase::meta, TaskInst::meta, "srcCompBreakout");
		CompBreakout::meta_dstCompBreakout_end_ = TaskInst::meta_srcCompBreakout_rev = ComponentBase::meta_dstCompBreakout;
		::Uml::SetParentRole(ComponentBase::meta_FaultScenario_parent, ComponentBase::meta, FaultScenario::meta, "", "");
		::Uml::SetParentRole(ComponentBase::meta_Component_parent, ComponentBase::meta, Component::meta, "", "");

		::Uml::SetAssocRole(ComponentRef::meta_referedbyTaskInst, ComponentRef::meta, TaskInst::meta, "ref");
		::Uml::SetAssocRole(ComponentRef::meta_referedbyAction, ComponentRef::meta, Action::meta, "ref");
		::Uml::SetAssocRole(ComponentRef::meta_referedbyFaultMgrTask, ComponentRef::meta, FaultMgrTask::meta, "ref");
		::Uml::SetAssocRole(ComponentRef::meta_srcDependency__rp_helper_rev, ComponentRef::meta, Dependency::meta, "srcDependency__rp_helper");
		::Uml::SetAssocRole(ComponentRef::meta_dstDependency__rp_helper_rev, ComponentRef::meta, Dependency::meta, "dstDependency__rp_helper");
		::Uml::SetAssocRole(ComponentRef::meta_dstComponentAssignment, ComponentRef::meta, NodeRef::meta, "srcComponentAssignment");
		ComponentAssignment::meta_dstComponentAssignment_end_ = NodeRef::meta_srcComponentAssignment_rev = ComponentRef::meta_dstComponentAssignment;
		::Uml::SetAssocRole(ComponentRef::meta_ref, ComponentRef::meta, ComponentRef_RefersTo_Base::meta, "referedbyComponentRef");
		::Uml::SetParentRole(ComponentRef::meta_System_parent, ComponentRef::meta, System::meta, "", "");

		::Uml::SetAssocRole(ComponentRef_RefersTo_Base::meta_referedbyComponentRef, ComponentRef_RefersTo_Base::meta, ComponentRef::meta, "ref");

		::Uml::SetAssocRole(Connectable::meta_dstWire, Connectable::meta, Connectable::meta, "srcWire");
		Wire::meta_dstWire_end_ = Connectable::meta_srcWire_rev = Connectable::meta_dstWire;
		::Uml::SetAssocRole(Connectable::meta_srcWire, Connectable::meta, Connectable::meta, "dstWire");
		Wire::meta_srcWire_end_ = Connectable::meta_dstWire_rev = Connectable::meta_srcWire;

		::Uml::SetAssocRole(Connector::meta_dstConnector__rp_helper, Connector::meta, Connector_dstConnector_RPContainer_Base::meta, "dstConnector__rp_helper_rev");
		::Uml::SetAssocRole(Connector::meta_srcConnector__rp_helper, Connector::meta, Connector_srcConnector_RPContainer_Base::meta, "srcConnector__rp_helper_rev");
		::Uml::SetParentRole(Connector::meta_Component_parent, Connector::meta, Component::meta, "", "");

		::Uml::SetAssocRole(ConnectorRef::meta_ref, ConnectorRef::meta, TransConnector::meta, "referedbyConnectorRef");
		::Uml::SetParentRole(ConnectorRef::meta_Block_parent, ConnectorRef::meta, Block::meta, "", "");

		::Uml::SetAssocRole(Connector_dstConnector_RPContainer_Base::meta_dstConnector__rp_helper_rev, Connector_dstConnector_RPContainer_Base::meta, Connector::meta, "dstConnector__rp_helper");

		::Uml::SetAssocRole(Connector_srcConnector_RPContainer_Base::meta_srcConnector__rp_helper_rev, Connector_srcConnector_RPContainer_Base::meta, Connector::meta, "srcConnector__rp_helper");

		::Uml::SetChildRole(Dataflow::meta_Subsystem_children, Dataflow::meta, Subsystem::meta, "", "");
		::Uml::SetParentRole(Dataflow::meta_ModelsFolder_parent, Dataflow::meta, ModelsFolder::meta, "", "");

		::Uml::SetAssocRole(Dependency::meta_srcDependency__rp_helper, Dependency::meta, ComponentRef::meta, "srcDependency__rp_helper_rev");
		::Uml::SetAssocRole(Dependency::meta_dstDependency__rp_helper, Dependency::meta, ComponentRef::meta, "dstDependency__rp_helper_rev");
		::Uml::SetParentRole(Dependency::meta_System_parent, Dependency::meta, System::meta, "", "");

		::Uml::SetChildRole(DeploymentLibrary::meta_System_children, DeploymentLibrary::meta, System::meta, "", "");
		::Uml::SetParentRole(DeploymentLibrary::meta_RootFolder_parent, DeploymentLibrary::meta, RootFolder::meta, "", "");

		::Uml::SetChildRole(DesignFolder::meta_SystemTypes_children, DesignFolder::meta, SystemTypes::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_FaultModel_children, DesignFolder::meta, FaultModel::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_FaultModelFolder_children, DesignFolder::meta, FaultModelFolder::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_HardwareUnit_children, DesignFolder::meta, HardwareUnit::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_TimingSheet_children, DesignFolder::meta, TimingSheet::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_System_children, DesignFolder::meta, System::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_ModelsFolder_children, DesignFolder::meta, ModelsFolder::meta, "", "");
		::Uml::SetChildRole(DesignFolder::meta_FaultScenario_children, DesignFolder::meta, FaultScenario::meta, "", "");
		::Uml::SetParentRole(DesignFolder::meta_RootFolder_parent, DesignFolder::meta, RootFolder::meta, "", "");

		::Uml::SetAssocRole(DesignReference::meta_ref, DesignReference::meta, System::meta, "referedbyDesignReference");
		::Uml::SetParentRole(DesignReference::meta_FaultScenario_parent, DesignReference::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(Executable::meta_srcExecutionAssignment, Executable::meta, ExecutionInfo::meta, "dstExecutionAssignment");
		ExecutionAssignment::meta_srcExecutionAssignment_end_ = ExecutionInfo::meta_dstExecutionAssignment_rev = Executable::meta_srcExecutionAssignment;

		::Uml::SetAssocRole(ExecutionAssignment::meta_dstExecutionAssignment__rp_helper, ExecutionAssignment::meta, ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta, "dstExecutionAssignment__rp_helper_rev");
		::Uml::SetParentRole(ExecutionAssignment::meta_System_parent, ExecutionAssignment::meta, System::meta, "", "");

		::Uml::SetAssocRole(ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta_dstExecutionAssignment__rp_helper_rev, ExecutionAssignment_dstExecutionAssignment_RPContainer_Base::meta, ExecutionAssignment::meta, "dstExecutionAssignment__rp_helper");

		::Uml::SetParentRole(ExecutionContext::meta_HWElement_parent, ExecutionContext::meta, HWElement::meta, "", "");

		::Uml::SetAssocRole(ExecutionInfo::meta_dstExecutionAssignment, ExecutionInfo::meta, Executable::meta, "srcExecutionAssignment");
		ExecutionAssignment::meta_dstExecutionAssignment_end_ = Executable::meta_srcExecutionAssignment_rev = ExecutionInfo::meta_dstExecutionAssignment;
		::Uml::SetParentRole(ExecutionInfo::meta_System_parent, ExecutionInfo::meta, System::meta, "", "");

		::Uml::SetParentRole(FaultCondition::meta_FaultScenario_parent, FaultCondition::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(FaultEvent::meta_referedbyFaultTrigger, FaultEvent::meta, FaultTrigger::meta, "ref");

		::Uml::SetAssocRole(FaultMgrTask::meta_ref, FaultMgrTask::meta, ComponentRef::meta, "referedbyFaultMgrTask");
		::Uml::SetParentRole(FaultMgrTask::meta_FaultScenario_parent, FaultMgrTask::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(FaultModel::meta_referedbyFaultModelRef, FaultModel::meta, FaultModelRef::meta, "ref");
		::Uml::SetChildRole(FaultModel::meta_Variable_children, FaultModel::meta, Variable::meta, "", "");
		::Uml::SetParentRole(FaultModel::meta_FaultScenario_parent, FaultModel::meta, FaultScenario::meta, "", "");
		::Uml::SetParentRole(FaultModel::meta_FaultModelFolder_parent, FaultModel::meta, FaultModelFolder::meta, "", "");
		::Uml::SetParentRole(FaultModel::meta_DesignFolder_parent, FaultModel::meta, DesignFolder::meta, "", "");

		::Uml::SetChildRole(FaultModelFolder::meta_FaultModel_children, FaultModelFolder::meta, FaultModel::meta, "", "");
		::Uml::SetParentRole(FaultModelFolder::meta_DesignFolder_parent, FaultModelFolder::meta, DesignFolder::meta, "", "");

		::Uml::SetAssocRole(FaultModelRef::meta_ref, FaultModelRef::meta, FaultModel::meta, "referedbyFaultModelRef");
		::Uml::SetParentRole(FaultModelRef::meta_FaultScenario_parent, FaultModelRef::meta, FaultScenario::meta, "", "");

		::Uml::SetChildRole(FaultScenario::meta_ScenarioInfo_children, FaultScenario::meta, ScenarioInfo::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_FaultTrigger_children, FaultScenario::meta, FaultTrigger::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_FaultCondition_children, FaultScenario::meta, FaultCondition::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_TaskInst_children, FaultScenario::meta, TaskInst::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_Action_children, FaultScenario::meta, Action::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_FaultMgrTask_children, FaultScenario::meta, FaultMgrTask::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_ComponentBase_children, FaultScenario::meta, ComponentBase::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_CompBreakout_children, FaultScenario::meta, CompBreakout::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_FaultModel_children, FaultScenario::meta, FaultModel::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_DesignReference_children, FaultScenario::meta, DesignReference::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_FaultToInput_children, FaultScenario::meta, FaultToInput::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_OutputToFault_children, FaultScenario::meta, OutputToFault::meta, "", "");
		::Uml::SetChildRole(FaultScenario::meta_FaultModelRef_children, FaultScenario::meta, FaultModelRef::meta, "", "");
		::Uml::SetParentRole(FaultScenario::meta_DesignFolder_parent, FaultScenario::meta, DesignFolder::meta, "", "");

		::Uml::SetParentRole(FaultToInput::meta_FaultScenario_parent, FaultToInput::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(FaultToInput_Members_Base::meta_dstFaultToInput, FaultToInput_Members_Base::meta, FaultToInput_Members_Base::meta, "srcFaultToInput");
		FaultToInput::meta_dstFaultToInput_end_ = FaultToInput_Members_Base::meta_srcFaultToInput_rev = FaultToInput_Members_Base::meta_dstFaultToInput;
		::Uml::SetAssocRole(FaultToInput_Members_Base::meta_srcFaultToInput, FaultToInput_Members_Base::meta, FaultToInput_Members_Base::meta, "dstFaultToInput");
		FaultToInput::meta_srcFaultToInput_end_ = FaultToInput_Members_Base::meta_dstFaultToInput_rev = FaultToInput_Members_Base::meta_srcFaultToInput;

		::Uml::SetAssocRole(FaultTrigger::meta_ref, FaultTrigger::meta, FaultEvent::meta, "referedbyFaultTrigger");
		::Uml::SetParentRole(FaultTrigger::meta_FaultScenario_parent, FaultTrigger::meta, FaultScenario::meta, "", "");

		::Uml::SetParentRole(FieldDataType::meta_MsgPort_parent, FieldDataType::meta, MsgPort::meta, "", "");

		::Uml::SetChildRole(HWElement::meta_ExecutionContext_children, HWElement::meta, ExecutionContext::meta, "", "");
		::Uml::SetParentRole(HWElement::meta_HardwareUnit_parent, HWElement::meta, HardwareUnit::meta, "", "");

		::Uml::SetChildRole(HardwareUnit::meta_Wire_children, HardwareUnit::meta, Wire::meta, "", "");
		::Uml::SetChildRole(HardwareUnit::meta_HWElement_children, HardwareUnit::meta, HWElement::meta, "", "");
		::Uml::SetChildRole(HardwareUnit::meta_Channel_children, HardwareUnit::meta, Channel::meta, "", "");
		::Uml::SetChildRole(HardwareUnit::meta_Plant_children, HardwareUnit::meta, Plant::meta, "", "");
		::Uml::SetChildRole(HardwareUnit::meta_PhysConnection_children, HardwareUnit::meta, PhysConnection::meta, "", "");
		::Uml::SetChildRole(HardwareUnit::meta_AcquisitionConnection_children, HardwareUnit::meta, AcquisitionConnection::meta, "", "");
		::Uml::SetChildRole(HardwareUnit::meta_ActuationConnection_children, HardwareUnit::meta, ActuationConnection::meta, "", "");
		::Uml::SetParentRole(HardwareUnit::meta_DesignFolder_parent, HardwareUnit::meta, DesignFolder::meta, "", "");
		::Uml::SetParentRole(HardwareUnit::meta_PlatformLibrary_parent, HardwareUnit::meta, PlatformLibrary::meta, "", "");

		::Uml::SetAssocRole(IChan::meta_srcAcquisitionConnection, IChan::meta, IODevice::meta, "dstAcquisitionConnection");
		AcquisitionConnection::meta_srcAcquisitionConnection_end_ = IODevice::meta_dstAcquisitionConnection_rev = IChan::meta_srcAcquisitionConnection;

		::Uml::SetAssocRole(IODevice::meta_srcActuationConnection, IODevice::meta, OChan::meta, "dstActuationConnection");
		ActuationConnection::meta_srcActuationConnection_end_ = OChan::meta_dstActuationConnection_rev = IODevice::meta_srcActuationConnection;
		::Uml::SetAssocRole(IODevice::meta_dstAcquisitionConnection, IODevice::meta, IChan::meta, "srcAcquisitionConnection");
		AcquisitionConnection::meta_dstAcquisitionConnection_end_ = IChan::meta_srcAcquisitionConnection_rev = IODevice::meta_dstAcquisitionConnection;
		::Uml::SetChildRole(IODevice::meta_Channel_children, IODevice::meta, Channel::meta, "", "");

		::Uml::SetAssocRole(IOPortExp::meta_srcIOPortAssignment, IOPortExp::meta, IOPortInfoBase::meta, "dstIOPortAssignment");
		IOPortAssignment::meta_srcIOPortAssignment_end_ = IOPortInfoBase::meta_dstIOPortAssignment_rev = IOPortExp::meta_srcIOPortAssignment;

		::Uml::SetAssocRole(IOPortInfo::meta_referedbyIOPortInfoRef, IOPortInfo::meta, IOPortInfoRef::meta, "ref");

		::Uml::SetAssocRole(IOPortInfoBase::meta_dstIOPortAssignment, IOPortInfoBase::meta, IOPortExp::meta, "srcIOPortAssignment");
		IOPortAssignment::meta_dstIOPortAssignment_end_ = IOPortExp::meta_srcIOPortAssignment_rev = IOPortInfoBase::meta_dstIOPortAssignment;

		::Uml::SetAssocRole(IOPortInfoRef::meta_ref, IOPortInfoRef::meta, IOPortInfo::meta, "referedbyIOPortInfoRef");

		::Uml::SetParentRole(Incorporation::meta_Variable_parent, Incorporation::meta, Variable::meta, "", "");

		::Uml::SetAssocRole(Input::meta_srcConnector, Input::meta, Output::meta, "dstConnector");
		Connector::meta_srcConnector_end_ = Output::meta_dstConnector_rev = Input::meta_srcConnector;

		::Uml::SetAssocRole(InputEvent::meta_srcTrigger, InputEvent::meta, OutputEvent::meta, "dstTrigger");
		Trigger::meta_srcTrigger_end_ = OutputEvent::meta_dstTrigger_rev = InputEvent::meta_srcTrigger;

		::Uml::SetParentRole(Line::meta_Line_Block_parent, Line::meta, Block::meta, "Line", "");

		::Uml::SetChildRole(Message::meta_MsgPort_children, Message::meta, MsgPort::meta, "", "");
		::Uml::SetParentRole(Message::meta_SystemTypes_parent, Message::meta, SystemTypes::meta, "", "");

		::Uml::SetAssocRole(MessageRef::meta_ref, MessageRef::meta, MessageRef_RefersTo_Base::meta, "referedbyBusMessageRef");
		::Uml::SetAssocRole(MessageRef::meta_dstDependency, MessageRef::meta, MessageRef::meta, "srcDependency");
		Dependency::meta_dstDependency_end_ = MessageRef::meta_srcDependency_rev = MessageRef::meta_dstDependency;
		::Uml::SetAssocRole(MessageRef::meta_srcDependency, MessageRef::meta, MessageRef::meta, "dstDependency");
		Dependency::meta_srcDependency_end_ = MessageRef::meta_dstDependency_rev = MessageRef::meta_srcDependency;
		::Uml::SetParentRole(MessageRef::meta_Component_parent, MessageRef::meta, Component::meta, "", "");

		::Uml::SetAssocRole(MessageRef_RefersTo_Base::meta_referedbyBusMessageRef, MessageRef_RefersTo_Base::meta, MessageRef::meta, "ref");

		::Uml::SetParentRole(ModelInfo::meta_ModelsFolder_parent, ModelInfo::meta, ModelsFolder::meta, "", "");

		::Uml::SetChildRole(ModelsFolder::meta_Dataflow_children, ModelsFolder::meta, Dataflow::meta, "", "");
		::Uml::SetChildRole(ModelsFolder::meta_Stateflow_children, ModelsFolder::meta, Stateflow::meta, "", "");
		::Uml::SetChildRole(ModelsFolder::meta_ModelInfo_children, ModelsFolder::meta, ModelInfo::meta, "", "");
		::Uml::SetChildRole(ModelsFolder::meta_Module_children, ModelsFolder::meta, Module::meta, "", "");
		::Uml::SetParentRole(ModelsFolder::meta_DesignFolder_parent, ModelsFolder::meta, DesignFolder::meta, "", "");

		::Uml::SetChildRole(Module::meta_BIPConnector_children, Module::meta, BIPConnector::meta, "", "");
		::Uml::SetChildRole(Module::meta_PetriNet_children, Module::meta, PetriNet::meta, "", "");
		::Uml::SetParentRole(Module::meta_ModelsFolder_parent, Module::meta, ModelsFolder::meta, "", "");

		::Uml::SetChildRole(MsgPort::meta_FieldDataType_children, MsgPort::meta, FieldDataType::meta, "", "");
		::Uml::SetParentRole(MsgPort::meta_Message_parent, MsgPort::meta, Message::meta, "", "");

		::Uml::SetChildRole(Network::meta_BChan_children, Network::meta, BChan::meta, "", "");

		::Uml::SetAssocRole(Node::meta_referedbyNodeRef, Node::meta, NodeRef::meta, "ref");
		::Uml::SetChildRole(Node::meta_OS_child, Node::meta, OS::meta, "", "");
		::Uml::SetChildRole(Node::meta_Channel_children, Node::meta, Channel::meta, "", "");

		::Uml::SetAssocRole(NodeRef::meta_ref, NodeRef::meta, Node::meta, "referedbyNodeRef");
		::Uml::SetAssocRole(NodeRef::meta_srcComponentAssignment, NodeRef::meta, ComponentRef::meta, "dstComponentAssignment");
		ComponentAssignment::meta_srcComponentAssignment_end_ = ComponentRef::meta_dstComponentAssignment_rev = NodeRef::meta_srcComponentAssignment;
		::Uml::SetParentRole(NodeRef::meta_System_parent, NodeRef::meta, System::meta, "", "");

		::Uml::SetAssocRole(OChan::meta_dstActuationConnection, OChan::meta, IODevice::meta, "srcActuationConnection");
		ActuationConnection::meta_dstActuationConnection_end_ = IODevice::meta_srcActuationConnection_rev = OChan::meta_dstActuationConnection;

		::Uml::SetParentRole(OS::meta_Node_parent, OS::meta, Node::meta, "", "");

		::Uml::SetParentRole(Occurrence::meta_Variable_parent, Occurrence::meta, Variable::meta, "", "");

		::Uml::SetAssocRole(Output::meta_dstConnector, Output::meta, Input::meta, "srcConnector");
		Connector::meta_dstConnector_end_ = Input::meta_srcConnector_rev = Output::meta_dstConnector;

		::Uml::SetAssocRole(OutputEvent::meta_dstTrigger, OutputEvent::meta, InputEvent::meta, "srcTrigger");
		Trigger::meta_dstTrigger_end_ = InputEvent::meta_srcTrigger_rev = OutputEvent::meta_dstTrigger;

		::Uml::SetParentRole(OutputToFault::meta_FaultScenario_parent, OutputToFault::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(OutputToFault_Members_Base::meta_dstOutputToFault, OutputToFault_Members_Base::meta, OutputToFault_Members_Base::meta, "srcOutputToFault");
		OutputToFault::meta_dstOutputToFault_end_ = OutputToFault_Members_Base::meta_srcOutputToFault_rev = OutputToFault_Members_Base::meta_dstOutputToFault;
		::Uml::SetAssocRole(OutputToFault_Members_Base::meta_srcOutputToFault, OutputToFault_Members_Base::meta, OutputToFault_Members_Base::meta, "dstOutputToFault");
		OutputToFault::meta_srcOutputToFault_end_ = OutputToFault_Members_Base::meta_dstOutputToFault_rev = OutputToFault_Members_Base::meta_srcOutputToFault;

		::Uml::SetAssocRole(PNPort::meta_dstPortToPort, PNPort::meta, PNPort::meta, "srcPortToPort");
		BIPConnector::meta_dstPortToPort_end_ = PNPort::meta_srcPortToPort_rev = PNPort::meta_dstPortToPort;
		::Uml::SetAssocRole(PNPort::meta_srcPortToPort, PNPort::meta, PNPort::meta, "dstPortToPort");
		BIPConnector::meta_srcPortToPort_end_ = PNPort::meta_dstPortToPort_rev = PNPort::meta_srcPortToPort;
		::Uml::SetChildRole(PNPort::meta_PNVarRef_children, PNPort::meta, PNVarRef::meta, "", "");
		::Uml::SetParentRole(PNPort::meta_PetriNet_parent, PNPort::meta, PetriNet::meta, "", "");

		::Uml::SetAssocRole(PNState::meta_srcTransitionToState, PNState::meta, PNTransition::meta, "dstTransitionToState");
		TransitionToState::meta_srcTransitionToState_end_ = PNTransition::meta_dstTransitionToState_rev = PNState::meta_srcTransitionToState;
		::Uml::SetAssocRole(PNState::meta_dstStateToTransition, PNState::meta, PNTransition::meta, "srcStateToTransition");
		StateToTransition::meta_dstStateToTransition_end_ = PNTransition::meta_srcStateToTransition_rev = PNState::meta_dstStateToTransition;
		::Uml::SetParentRole(PNState::meta_PetriNet_parent, PNState::meta, PetriNet::meta, "", "");

		::Uml::SetAssocRole(PNTransition::meta_dstTransitionToState, PNTransition::meta, PNState::meta, "srcTransitionToState");
		TransitionToState::meta_dstTransitionToState_end_ = PNState::meta_srcTransitionToState_rev = PNTransition::meta_dstTransitionToState;
		::Uml::SetAssocRole(PNTransition::meta_srcStateToTransition, PNTransition::meta, PNState::meta, "dstStateToTransition");
		StateToTransition::meta_srcStateToTransition_end_ = PNState::meta_dstStateToTransition_rev = PNTransition::meta_srcStateToTransition;
		::Uml::SetParentRole(PNTransition::meta_PetriNet_parent, PNTransition::meta, PetriNet::meta, "", "");

		::Uml::SetAssocRole(PNVarRef::meta_ref, PNVarRef::meta, PNVariable::meta, "referedbyPNVarRef");
		::Uml::SetParentRole(PNVarRef::meta_PNPort_parent, PNVarRef::meta, PNPort::meta, "", "");

		::Uml::SetAssocRole(PNVariable::meta_referedbyPNVarRef, PNVariable::meta, PNVarRef::meta, "ref");
		::Uml::SetParentRole(PNVariable::meta_PetriNet_parent, PNVariable::meta, PetriNet::meta, "", "");

		Parameter::meta_arg = ::ESM2SLC::Parameter_cross_ph_ESMoL::meta_arg;
		Parameter::meta_memb = ::ESM2SLC::Parameter_cross_ph_ESMoL::meta_memb;
		::Uml::SetParentRole(Parameter::meta_Parameter_Block_parent, Parameter::meta, Block::meta, "Parameter", "");

		::Uml::SetAssocRole(PetriNet::meta_referedbyPetriNetRef, PetriNet::meta, PetriNetRef::meta, "ref");
		::Uml::SetChildRole(PetriNet::meta_StateToTransition_children, PetriNet::meta, StateToTransition::meta, "", "");
		::Uml::SetChildRole(PetriNet::meta_PNTransition_children, PetriNet::meta, PNTransition::meta, "", "");
		::Uml::SetChildRole(PetriNet::meta_TransitionToState_children, PetriNet::meta, TransitionToState::meta, "", "");
		::Uml::SetChildRole(PetriNet::meta_PNState_children, PetriNet::meta, PNState::meta, "", "");
		::Uml::SetChildRole(PetriNet::meta_PNVariable_children, PetriNet::meta, PNVariable::meta, "", "");
		::Uml::SetChildRole(PetriNet::meta_PNPort_children, PetriNet::meta, PNPort::meta, "", "");
		::Uml::SetParentRole(PetriNet::meta_Module_parent, PetriNet::meta, Module::meta, "", "");

		::Uml::SetAssocRole(PetriNetRef::meta_ref, PetriNetRef::meta, PetriNet::meta, "referedbyPetriNetRef");

		::Uml::SetParentRole(PhysConnection::meta_HardwareUnit_parent, PhysConnection::meta, HardwareUnit::meta, "", "");

		::Uml::SetAssocRole(PhysInterface::meta_dstPhysConnection, PhysInterface::meta, PhysInterface::meta, "srcPhysConnection");
		PhysConnection::meta_dstPhysConnection_end_ = PhysInterface::meta_srcPhysConnection_rev = PhysInterface::meta_dstPhysConnection;
		::Uml::SetAssocRole(PhysInterface::meta_srcPhysConnection, PhysInterface::meta, PhysInterface::meta, "dstPhysConnection");
		PhysConnection::meta_srcPhysConnection_end_ = PhysInterface::meta_dstPhysConnection_rev = PhysInterface::meta_srcPhysConnection;

		::Uml::SetParentRole(Plant::meta_HardwareUnit_parent, Plant::meta, HardwareUnit::meta, "", "");

		::Uml::SetChildRole(PlatformLibrary::meta_HardwareUnit_children, PlatformLibrary::meta, HardwareUnit::meta, "", "");
		::Uml::SetParentRole(PlatformLibrary::meta_RootFolder_parent, PlatformLibrary::meta, RootFolder::meta, "", "");

		::Uml::SetAssocRole(Port::meta_dstLine, Port::meta, Port::meta, "srcLine");
		Line::meta_dstLine_end_ = Port::meta_srcLine_rev = Port::meta_dstLine;
		::Uml::SetAssocRole(Port::meta_srcLine, Port::meta, Port::meta, "dstLine");
		Line::meta_srcLine_end_ = Port::meta_dstLine_rev = Port::meta_srcLine;
		Port::meta_arg = ::ESM2SLC::Port_cross_ph_ESMoL::meta_arg;
		Port::meta_argdecl = ::ESM2SLC::Port_cross_ph_ESMoL::meta_argdecl;
		::Uml::SetChildRole(Port::meta_TypeBaseRef_child, Port::meta, TypeBaseRef::meta, "", "");
		::Uml::SetParentRole(Port::meta_Block_parent, Port::meta, Block::meta, "", "");

		Primitive::meta_ifval = ::ESM2SLC::Primitive_cross_ph_ESMoL::meta_ifval;

		::Uml::SetChildRole(RequirementsLibrary::meta_TimingSheet_children, RequirementsLibrary::meta, TimingSheet::meta, "", "");
		::Uml::SetParentRole(RequirementsLibrary::meta_RootFolder_parent, RequirementsLibrary::meta, RootFolder::meta, "", "");

		::Uml::SetChildRole(RootFolder::meta_ArchitectureLibrary_children, RootFolder::meta, ArchitectureLibrary::meta, "", "");
		::Uml::SetChildRole(RootFolder::meta_DesignFolder_children, RootFolder::meta, DesignFolder::meta, "", "");
		::Uml::SetChildRole(RootFolder::meta_RequirementsLibrary_children, RootFolder::meta, RequirementsLibrary::meta, "", "");
		::Uml::SetChildRole(RootFolder::meta_Types_children, RootFolder::meta, Types::meta, "", "");
		::Uml::SetChildRole(RootFolder::meta_PlatformLibrary_children, RootFolder::meta, PlatformLibrary::meta, "", "");
		::Uml::SetChildRole(RootFolder::meta_DeploymentLibrary_children, RootFolder::meta, DeploymentLibrary::meta, "", "");
		::Uml::SetChildRole(RootFolder::meta_RootFolder_children, RootFolder::meta, RootFolder::meta, "", "");
		::Uml::SetParentRole(RootFolder::meta_RootFolder_parent, RootFolder::meta, RootFolder::meta, "", "");

		::Uml::SetParentRole(ScenarioInfo::meta_FaultScenario_parent, ScenarioInfo::meta, FaultScenario::meta, "", "");

		::Uml::SetChildRole(State::meta_Transition, State::meta, Transition::meta, "", "Transition");
		::Uml::SetChildRole(State::meta_TransConnector_children, State::meta, TransConnector::meta, "", "");
		::Uml::SetChildRole(State::meta_StateDE_children, State::meta, StateDE::meta, "", "");
		::Uml::SetParentRole(State::meta_Stateflow_parent, State::meta, Stateflow::meta, "", "");

		::Uml::SetChildRole(StateDE::meta_TypeBaseRef_child, StateDE::meta, TypeBaseRef::meta, "", "");
		::Uml::SetParentRole(StateDE::meta_State_parent, StateDE::meta, State::meta, "", "");

		::Uml::SetParentRole(StateToTransition::meta_PetriNet_parent, StateToTransition::meta, PetriNet::meta, "", "");

		::Uml::SetChildRole(Stateflow::meta_State_children, Stateflow::meta, State::meta, "", "");
		::Uml::SetParentRole(Stateflow::meta_ModelsFolder_parent, Stateflow::meta, ModelsFolder::meta, "", "");

		::Uml::SetAssocRole(Subsystem::meta_referedbySubsystemRef, Subsystem::meta, SubsystemRef::meta, "ref");
		Subsystem::meta_init = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_init;
		Subsystem::meta_main = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_main;
		Subsystem::meta_memb = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_memb;
		Subsystem::meta_mcall = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_mcall;
		Subsystem::meta_cls = ::ESM2SLC::Subsystem_cross_ph_ESMoL::meta_cls;
		::Uml::SetChildRole(Subsystem::meta_Block_children, Subsystem::meta, Block::meta, "", "");
		::Uml::SetParentRole(Subsystem::meta_Dataflow_parent, Subsystem::meta, Dataflow::meta, "", "");

		::Uml::SetAssocRole(SubsystemRef::meta_ref, SubsystemRef::meta, Subsystem::meta, "referedbySubsystemRef");

		::Uml::SetAssocRole(System::meta_referedbyDesignReference, System::meta, DesignReference::meta, "ref");
		::Uml::SetChildRole(System::meta_ComponentRef_children, System::meta, ComponentRef::meta, "", "");
		::Uml::SetChildRole(System::meta_NodeRef_children, System::meta, NodeRef::meta, "", "");
		::Uml::SetChildRole(System::meta_CommMapping_children, System::meta, CommMapping::meta, "", "");
		::Uml::SetChildRole(System::meta_Dependency_children, System::meta, Dependency::meta, "", "");
		::Uml::SetChildRole(System::meta_ComponentAssignment_children, System::meta, ComponentAssignment::meta, "", "");
		::Uml::SetChildRole(System::meta_ExecutionInfo_children, System::meta, ExecutionInfo::meta, "", "");
		::Uml::SetChildRole(System::meta_ExecutionAssignment_children, System::meta, ExecutionAssignment::meta, "", "");
		::Uml::SetParentRole(System::meta_DesignFolder_parent, System::meta, DesignFolder::meta, "", "");
		::Uml::SetParentRole(System::meta_DeploymentLibrary_parent, System::meta, DeploymentLibrary::meta, "", "");

		::Uml::SetChildRole(SystemTypes::meta_Message_children, SystemTypes::meta, Message::meta, "", "");
		::Uml::SetChildRole(SystemTypes::meta_Component_children, SystemTypes::meta, Component::meta, "", "");
		::Uml::SetParentRole(SystemTypes::meta_ArchitectureLibrary_parent, SystemTypes::meta, ArchitectureLibrary::meta, "", "");
		::Uml::SetParentRole(SystemTypes::meta_DesignFolder_parent, SystemTypes::meta, DesignFolder::meta, "", "");

		::Uml::SetAssocRole(TaskInst::meta_ref, TaskInst::meta, ComponentRef::meta, "referedbyTaskInst");
		::Uml::SetAssocRole(TaskInst::meta_srcCompBreakout, TaskInst::meta, ComponentBase::meta, "dstCompBreakout");
		CompBreakout::meta_srcCompBreakout_end_ = ComponentBase::meta_dstCompBreakout_rev = TaskInst::meta_srcCompBreakout;
		::Uml::SetParentRole(TaskInst::meta_FaultScenario_parent, TaskInst::meta, FaultScenario::meta, "", "");

		::Uml::SetAssocRole(TaskRef::meta_dstTimingConstraint, TaskRef::meta, TaskRef::meta, "srcTimingConstraint");
		TimingConstraint::meta_dstTimingConstraint_end_ = TaskRef::meta_srcTimingConstraint_rev = TaskRef::meta_dstTimingConstraint;
		::Uml::SetAssocRole(TaskRef::meta_srcTimingConstraint, TaskRef::meta, TaskRef::meta, "dstTimingConstraint");
		TimingConstraint::meta_srcTimingConstraint_end_ = TaskRef::meta_dstTimingConstraint_rev = TaskRef::meta_srcTimingConstraint;
		::Uml::SetAssocRole(TaskRef::meta_ref, TaskRef::meta, Component::meta, "referedbyTaskRef");
		::Uml::SetParentRole(TaskRef::meta_TimingSheet_parent, TaskRef::meta, TimingSheet::meta, "", "");

		::Uml::SetParentRole(TimingConstraint::meta_TimingSheet_parent, TimingConstraint::meta, TimingSheet::meta, "", "");

		::Uml::SetChildRole(TimingSheet::meta_TaskRef_children, TimingSheet::meta, TaskRef::meta, "", "");
		::Uml::SetChildRole(TimingSheet::meta_TimingConstraint_children, TimingSheet::meta, TimingConstraint::meta, "", "");
		::Uml::SetParentRole(TimingSheet::meta_DesignFolder_parent, TimingSheet::meta, DesignFolder::meta, "", "");
		::Uml::SetParentRole(TimingSheet::meta_RequirementsLibrary_parent, TimingSheet::meta, RequirementsLibrary::meta, "", "");

		::Uml::SetAssocRole(TransConnector::meta_referedbyConnectorRef, TransConnector::meta, ConnectorRef::meta, "ref");
		::Uml::SetAssocRole(TransConnector::meta_dstTransition, TransConnector::meta, TransConnector::meta, "srcTransition");
		Transition::meta_dstTransition_end_ = TransConnector::meta_srcTransition_rev = TransConnector::meta_dstTransition;
		::Uml::SetAssocRole(TransConnector::meta_srcTransition, TransConnector::meta, TransConnector::meta, "dstTransition");
		Transition::meta_srcTransition_end_ = TransConnector::meta_dstTransition_rev = TransConnector::meta_srcTransition;
		::Uml::SetParentRole(TransConnector::meta_State_parent, TransConnector::meta, State::meta, "", "");

		::Uml::SetParentRole(Transition::meta_Transition_State_parent, Transition::meta, State::meta, "Transition", "");

		::Uml::SetParentRole(TransitionToState::meta_PetriNet_parent, TransitionToState::meta, PetriNet::meta, "", "");

		::Uml::SetParentRole(Trigger::meta_Component_parent, Trigger::meta, Component::meta, "", "");

		TriggerPort::meta_memb = ::ESM2SLC::TriggerPort_cross_ph_ESMoL::meta_memb;

		::Uml::SetAssocRole(TypeBase::meta_referedbyTypeStructRef, TypeBase::meta, TypeBaseRef::meta, "ref");
		TypeBase::meta_dt = ::ESM2SLC::TypeBase_cross_ph_ESMoL::meta_dt;
		::Uml::SetParentRole(TypeBase::meta_Types_parent, TypeBase::meta, Types::meta, "", "");

		::Uml::SetAssocRole(TypeBaseRef::meta_ref, TypeBaseRef::meta, TypeBase::meta, "referedbyTypeStructRef");
		TypeBaseRef::meta_lvar = ::ESM2SLC::TypeBaseRef_cross_ph_ESMoL::meta_lvar;
		::Uml::SetParentRole(TypeBaseRef::meta_TypeStruct_parent, TypeBaseRef::meta, TypeStruct::meta, "", "");
		::Uml::SetParentRole(TypeBaseRef::meta_Port_parent, TypeBaseRef::meta, Port::meta, "", "");
		::Uml::SetParentRole(TypeBaseRef::meta_StateDE_parent, TypeBaseRef::meta, StateDE::meta, "", "");

		::Uml::SetChildRole(TypeStruct::meta_TypeBaseRef_children, TypeStruct::meta, TypeBaseRef::meta, "", "");

		::Uml::SetChildRole(Types::meta_TypeBase_children, Types::meta, TypeBase::meta, "", "");
		::Uml::SetParentRole(Types::meta_RootFolder_parent, Types::meta, RootFolder::meta, "", "");

		::Uml::SetParentRole(ValueObject::meta_Variable_parent, ValueObject::meta, Variable::meta, "", "");

		::Uml::SetChildRole(Variable::meta_Occurrence_children, Variable::meta, Occurrence::meta, "", "");
		::Uml::SetChildRole(Variable::meta_Incorporation_children, Variable::meta, Incorporation::meta, "", "");
		::Uml::SetChildRole(Variable::meta_ValueObject_children, Variable::meta, ValueObject::meta, "", "");
		::Uml::SetParentRole(Variable::meta_FaultModel_parent, Variable::meta, FaultModel::meta, "", "");

		::Uml::SetParentRole(Wire::meta_HardwareUnit_parent, Wire::meta, HardwareUnit::meta, "", "");

	}

	void _SetXsdStorage()
	{
		UdmDom::str_xsd_storage::StoreXsd("ESMoL.xsd", ESMoL_xsd::getString());
	}

	void Initialize()
	{
		static bool first = true;
		if (!first) return;
		first = false;
		::Uml::Initialize();

		ESM2SLC::Initialize();
	
		UDM_ASSERT( meta == ::Udm::null );

		::UdmStatic::StaticDataNetwork * meta_dn = new ::UdmStatic::StaticDataNetwork(::Uml::diagram);
		meta_dn->CreateNew("ESMoL.mem", "", ::Uml::Diagram::meta, ::Udm::CHANGES_LOST_DEFAULT);
		meta = ::Uml::Diagram::Cast(meta_dn->GetRootObject());

		::Uml::InitDiagramProps(meta, "ESMoL", "1.00");


		CreateMeta();
		InitMeta();
		InitMetaLinks();

		_SetXsdStorage();

	}

	void Initialize(const ::Uml::Diagram &dgr)
	{
		UDM_ASSERT(::ESM2SLC::meta != ::Udm::null);
		if (meta == dgr) return;
		meta = dgr;

		InitMeta(dgr);
		InitMetaLinks(dgr);

		
		_SetXsdStorage();
	}


	 ::Udm::UdmDiagram diagram = { &meta, Initialize };
	static struct _regClass
	{
		_regClass()
		{
			::Udm::MetaDepository::StoreDiagram("ESMoL", diagram);
		}
		~_regClass()
		{
			::Udm::MetaDepository::RemoveDiagram("ESMoL");
		}
	} __regUnUsed;

}

