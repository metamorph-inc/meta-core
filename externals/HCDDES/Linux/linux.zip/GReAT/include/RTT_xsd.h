#ifndef RTT_xsd_H
#define RTT_xsd_H
#include <string>
#pragma warning( disable : 4010)

namespace RTT_xsd
{
const std::string& getString()
{
	static std::string str;
	if (str.empty())
	{
		str +="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		str +="<?udm interface=\"RTT\" version=\"1.00\"?>\n";
		str +="<xsd:schema xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n";
		str +=" elementFormDefault=\"qualified\" \n";
		str +=">\n";
//		str +="<!-- generated on Mon Jul 23 16:50:30 2012 -->\n";
		str +="\n";
		str +="\n";
		str +="	<xsd:complexType name=\"RTTRootType\">\n";
		str +="		<xsd:sequence>\n";
		str +="			<xsd:element name=\"DataNetwork\" type=\"DataNetworkType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="			<xsd:element name=\"ExecuteRule\" type=\"ExecuteRuleType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="			<xsd:element name=\"Sequence\" type=\"SequenceType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="		</xsd:sequence>\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"ExecuteRuleType\">\n";
		str +="		<xsd:sequence>\n";
		str +="			<xsd:element name=\"Group\" type=\"GroupType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="			<xsd:element name=\"TracesTo\" type=\"TracesToType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="			<xsd:element name=\"UdmObject\" type=\"UdmObjectType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="		</xsd:sequence>\n";
		str +="		<xsd:attribute name=\"uniqueObjId\" type=\"xsd:long\" use=\"required\"/>\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"srcSequence\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"dstSequence\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"SequenceType\">\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"srcSequence_end_\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"dstSequence_end_\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"GroupType\">\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"members\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"UdmObjectType\">\n";
		str +="		<xsd:attribute name=\"uniqueObjId\" type=\"xsd:long\" use=\"required\"/>\n";
		str +="		<xsd:attribute name=\"dataNetworkId\" type=\"xsd:long\" use=\"required\"/>\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"srcTracesTo\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"dstTracesTo\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"setGroup\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"TracesToType\">\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"srcTracesTo_end_\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"dstTracesTo_end_\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"DataNetworkType\">\n";
		str +="		<xsd:attribute name=\"dataNetworkId\" type=\"xsd:long\" use=\"required\"/>\n";
		str +="		<xsd:attribute name=\"filePath\" type=\"xsd:string\" use=\"required\"/>\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"position\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +="	<xsd:complexType name=\"RootFolderType\">\n";
		str +="		<xsd:sequence>\n";
		str +="			<xsd:element name=\"RTTRoot\" type=\"RTTRootType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="			<xsd:element name=\"RootFolder\" type=\"RootFolderType\" minOccurs=\"0\" maxOccurs=\"unbounded\"/>\n";
		str +="		</xsd:sequence>\n";
		str +="		<xsd:attribute name=\"name\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_id\" type=\"xsd:ID\"/>\n";
		str +="		<xsd:attribute name=\"_archetype\" type=\"xsd:IDREF\"/>\n";
		str +="		<xsd:attribute name=\"_derived\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_instances\" type=\"xsd:IDREFS\"/>\n";
		str +="		<xsd:attribute name=\"_desynched_atts\" type=\"xsd:string\"/>\n";
		str +="		<xsd:attribute name=\"_real_archetype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_subtype\" type=\"xsd:boolean\"/>\n";
		str +="		<xsd:attribute name=\"_libname\" type=\"xsd:string\"/>\n";
		str +="	</xsd:complexType>\n";
		str +="\n";
		str +=" <xsd:element name=\"RootFolder\" type=\"RootFolderType\"/>\n";
		str +="\n";
		str +="</xsd:schema>\n";
		str +="\n";
	}
		return str;
}
} //namespace
#endif
